+CRSC - third-party components

- FSR 1 (EASU + RCAS) - (c) 2021 Advanced Micro Devices, Inc., MIT License. See licenses/FSR1-MIT.txt
- SGSR 1 - (c) 2023 Qualcomm Innovation Center, Inc., BSD-3-Clause. See licenses/SGSR1-BSD-3-Clause.txt
- The GLSL ES 3.0 ports of these shaders (Shaders.kt) were taken from the Nebula APK that came with
  this project; they use texelFetch instead of textureGather, so OpenGL ES 3.0 is enough.
  If you distribute the app, keep these notices.
- LiteRT (TensorFlow Lite runtime) - Google, Apache License 2.0.
- Real-ESRGAN General x4v3 model (optional, downloaded by the user on request) - Real-ESRGAN, BSD-3-Clause; .tflite export by Qualcomm AI Hub (https://huggingface.co/qualcomm/Real-ESRGAN-General-x4v3).
- Optional super-resolution models downloaded on request: XLSR (BSD-3-Clause), QuickSRNet Small/Medium/Large and SESR-M5 - Qualcomm AI Hub exports (https://huggingface.co/qualcomm), based on the AIMET Model Zoo implementations; check their repository licenses before redistributing the .tflite files.
- dcerpc (SMB share listing) - Rapid7, BSD 3-Clause.
- Game streaming client (module "moonlight"): Artemis / Moonlight Android by ClassicOldSong, cgutman and contributors, GPL-3.0 (licenses/Moonlight-Artemis-GPL-3.0.txt). Because it is included, the whole app is distributed under GPL-3.0 terms. Uses moonlight-common-c, ENet, Opus, OpenSSL, BouncyCastle, OkHttp, jCodec, jmDNS, Gson (see their licenses).
