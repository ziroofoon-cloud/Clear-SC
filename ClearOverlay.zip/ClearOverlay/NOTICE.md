+CRSC - third-party components

- FSR 1 (EASU + RCAS) - (c) 2021 Advanced Micro Devices, Inc., MIT License. See licenses/FSR1-MIT.txt
- SGSR 1 - (c) 2023 Qualcomm Innovation Center, Inc., BSD-3-Clause. See licenses/SGSR1-BSD-3-Clause.txt
- The GLSL ES 3.0 ports of these shaders (Shaders.kt) were taken from the Nebula APK that came with
  this project; they use texelFetch instead of textureGather, so OpenGL ES 3.0 is enough.
  If you distribute the app, keep these notices.
