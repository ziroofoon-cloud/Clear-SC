Clear Overlay - third-party ideas
- Sharpening: contrast-adaptive sharpening, idea from AMD FidelityFX CAS (MIT).
- Upscaling: Catmull-Rom bicubic filter, 9-bilinear-tap form (public technique).
- The official Snapdragon GSR 1 shader (Qualcomm, BSD-3-Clause) is NOT included.
