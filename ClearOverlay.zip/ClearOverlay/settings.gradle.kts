pluginManagement {
    repositories { google(); mavenCentral(); gradlePluginPortal() }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // ShieldControllerExtensions and SearchPreference (used by the embedded Moonlight) are published here
        maven("https://jitpack.io")
    }
}
rootProject.name = "ClearOverlay"
include(":app")
include(":moonlight")
