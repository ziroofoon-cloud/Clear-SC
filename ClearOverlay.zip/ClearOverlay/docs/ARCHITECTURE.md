# Source map (`app/src/main/java/app/clearoverlay`)

**Picture chain**
- `GlPipeline.kt` renders every frame (clean-up, upscale, sharpen, anti-aliasing, colour); `Shaders.kt` holds the GLSL; `Edge.kt`, `Enhance.kt` support it.
- `Fx.kt` is the read-only view of the effect settings (`Cfg`, a snapshot, or the Smooth-live lighter version); `FxCost.kt` estimates how heavy a setting is; `PassTimer.kt` measures the real time of each pass.
- `StreamFx.kt`, `StreamPresets.kt` connect the effects to the game stream; `FxBackup.kt` saves / loads all effect settings as a file.

**Settings and Auto**
- `Cfg.kt` all settings and their storage; `Profiles.kt`, `UserProfiles.kt`, `Looks.kt` quick and personal profiles.
- `Auto.kt`, `FxAuto.kt`, `LookAuto.kt`, `BudgetAuto.kt`, `Optimize.kt`, `SmartOpt.kt` choose and lighten settings automatically.
- `Controls.kt` the settings panel used by the overlay, the player and other screens.

**Screens**
- `MainActivity.kt` start screen; `OverlayService.kt`, `Bubble.kt` the screen overlay and its bubble.
- `PlayerActivity.kt` video / photo player; `GifActivity.kt`; `PhotoEditActivity.kt`, `EditActivity.kt`, `EditHubActivity.kt` editors.
- `LibraryActivity.kt`, `LibStore.kt`, `Covers.kt`, `BookCovers.kt` library; `MangaActivity.kt`, `MangaFx.kt`, `PageSource.kt` manga reader.
- `AudioActivity.kt`, `Music.kt`, `MusicLists.kt`, `MiniPlayer.kt`, `NowPlayingFull.kt`, `Lyrics.kt`, `AudioFx.kt`, `AudioOut.kt`, `AudioPanel.kt`, `AudioEditActivity.kt`, `AudioExport.kt` music.
- `FilesActivity.kt`, `FmProvider.kt`, `FmProviders.kt`, `FmDupes.kt`, `SafFs.kt`, `Storage.kt`, `ShizukuAccess.kt`, `ShizukuFs.kt` file manager; `NetActivity.kt`, `Net.kt` SMB / FTP; `TrashActivity.kt`, `TrashOps.kt` trash and delete / rename.
- `ExportActivity.kt`, `ExportService.kt`, `VideoExport.kt`, `GifExport.kt`, `GifWriter.kt`, `BatchActivity.kt`, `BatchService.kt`, `ShrinkActivity.kt`, `Shrink.kt`, `CleanActivity.kt`, `CleanScan.kt` exports and clean-up.
- `AiSr.kt`, `AiSnap.kt`, `AiSkip.kt`, `VideoAi.kt`, `ModelFiles.kt` on-device AI upscaling.

**Other**
- `Lang.kt`, `Icons.kt`, `EditUi.kt`, `Win.kt`, `IntroSplash.kt`, `LogoView.kt`, `ZoomView.kt` shared UI helpers; `Share.kt`, `History.kt`, `Media.kt`, `Online.kt`, `OnlineVideo.kt` helpers.

# Game streaming module (`moonlight/`)
Artemis v20.2.6 (ClassicOldSong/moonlight-android, branch moonlight-noir) in `com.limelight`. Our changes: `ClearHook.java`, `Game.java`, `GameMenu.java`, `AndroidAudioRenderer.java` (direct mode into `GlPipeline`), the PIP / external-display guards, the play-hold game menu and the pairing backup. Upstream fixes are ported one by one (see `CHANGELOG.md`).
