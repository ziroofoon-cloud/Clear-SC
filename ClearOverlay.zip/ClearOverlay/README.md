# +CRSC 3.99.151

Android app (Android 12+, minSdk 31) that sharpens and upscales video, photos, manga and games on the GPU.
Interface in English and Persian (pick System / English / فارسی on the main screen).

## What it does
- **Screen overlay:** captures the screen and shows a sharpened / upscaled copy in a touch-transparent layer (FSR 1, SGSR 1, NIS, CRSC Edge, Clean upscale, anti-aliasing, de-interlace, denoise, deband, detail, colour tools).
- **Player:** local files, links, HLS / DASH, subtitles, audio tracks; the same picture effects, Auto profiles per video, Smooth live, frame generation.
- **Library, manga reader, music player, file manager (SMB / FTP / Shizuku), trash, editors and exports** (video, audio, GIF, photos, batch, shrink, clean-up).
- **Game streaming:** embedded Artemis / Moonlight client (module `moonlight`) with the picture effects applied directly to the decoded stream.
- **On-device AI upscaling** for photos (LiteRT models, downloaded on request).

## Project layout
| Path | What |
|---|---|
| `app/` | main app, package `app.clearoverlay` (Kotlin) |
| `moonlight/` | game streaming client (Artemis v20.2.6 + our patches), see `moonlight/README.md` |
| `docs/ARCHITECTURE.md` | map of the source files |
| `tools/shader_test` | software-OpenGL scripts that test the shaders |
| `tools/profile_tune` | helpers for tuning the quick profiles |
| `licenses/`, `NOTICE.md` | third-party licenses (the app is distributed under GPL-3.0 because of the streaming client) |
| `CHANGELOG.md` | every change, newest first, plus the older design notes |

## Build
Gradle (Android Gradle Plugin, Kotlin, JDK 17), `compileSdk 35`, `targetSdk 34`. Build the debug or release APK with `./gradlew assembleDebug` / `assembleRelease`
(GitHub Actions does the same). One fixed signing key (`app/crsc.keystore`) is used for both, so a new build installs over the old one.
`versionCode` grows with every build; `versionName` is in `app/build.gradle.kts`.

## Working on it
- Settings live in `Cfg.kt`; the picture chain is `GlPipeline.kt` with the shaders in `Shaders.kt`; Auto picks settings in `Auto.kt` / `Profiles.kt`.
- New text goes into both `res/values/strings.xml` and `res/values-fa/strings.xml`.
- Add each change to the top of `CHANGELOG.md` and bump the version in `app/build.gradle.kts` and on the first line of this file.
