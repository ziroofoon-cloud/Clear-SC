# +CRSC 3.56.1

Tiny Android app. Captures the screen, sharpens / upscales every frame on the GPU (FSR 1, SGSR 1,
or plain bilinear) and shows it in a touch-transparent full-screen overlay. Android 12+ (minSdk 31).
UI is in English or Persian: pick System / English / فارسی on the main screen (res/values + res/values-fa).

## 3.56.1
- **Build fix**: `MusicPlayer.setSpeed()` clashed with the setter of the property `speed` (same JVM name, "Platform declaration clash") and stopped the build. The function is now `changeSpeed()`. This was the only error in the build log; the type-checking step passed for all files.

## 3.56.0
- **Library search**: a magnifier icon at the top opens a search box. Inside a folder or category it filters what is shown by name; at the top level of Videos / Photos / GIFs / Music it searches all files of that section (Manga: filters the folders and books by name). Closing the box shows everything again.
- **Edit photo: hold to compare**: hold a finger on the picture (any tab except Draw) to see the original, let go to see the edit again. **Leaving with unsaved edits asks first** ("Leave without saving?"); no question when nothing was changed or the photo was just saved.
- Not compiled or run here.

## 3.55.0
- **Manga reader: bigger top bar buttons** (FX, settings gear, cloud, page mode, direction, close) about twice as big; the title next to them gets shorter.
- **Draw: eraser and redo** (Edit photo): a third brush "Eraser" removes pen strokes only (never the photo itself) and works on the saved full-size picture too; new Redo button next to Undo.
- **Save with the live quality for manga and photos**: "Enhance to files" has a new quality chip **Live**. It copies the settings you see in the Manga reader (or the photo viewer): upscaler, CRSC level, sharpness, detail, denoise, colour, input and output size, and runs them on every page / picture (manga: one new .cbz). The settings are copied when the job starts, so changing them afterwards (or the screen layer) cannot disturb a running job. Videos, GIFs and songs already had this (3.53.0).
- **Delete in the viewer**: the player's Tools menu has "Delete..." (move to the trash / delete for good) for the open video, GIF or photo; the viewer closes afterwards.
- **"Now playing" bar** also on the Edit screen (it was on the main screen and the Library).
- **Bug fixes**
  - A sleep timer left over from an earlier song could pause the next song a long time later (the timer was only cleared by the bar's stop button, not by the notification's stop or the idle stop). Stopping the player now always clears it.
  - Trash screen: "Delete forever" with nothing chosen means everything; it now asks once ("ALL n items") so one tap cannot empty the trash.
- Checked by script: all text resources used in the code exist, no duplicates, English and Persian have the same names and the same %-arguments, brackets balance in the changed files. Not compiled or run here.

## 3.54.0
- Trash for every section: the Library selection bar has a bin button (Videos, Photos, GIFs, Music), books (manga) have "Delete…" on long-press, songs have it in their long-press menu. Two choices: Move to trash (the phone's own trash, ~30 days, restorable) or Delete forever. Android shows its own allow box. The bin icon at the top of the Library opens the Trash screen: restore, or delete for good (nothing chosen = all).
- Music: a "now playing" bar at the bottom of the Library and the main screen (previous / play-pause / next / stop, progress, tap to open the player). New in the music player: song search, sleep timer, playing speed, long-press menu per song (play next, edit sound, share, delete).

## 3.53.0
- Library: the selection bar now has a Save button on the Videos, GIFs and Music tabs (Photos keeps Enhance). Video / GIF (one file): saved with the live settings of that section (upscaler, CRSC level, sharpness, colour, temporal, frame generation) and the export starts by itself. Music: the sound settings of the music player are baked into new files, one after the other, in the background.

## 3.52.1
- Video / audio editor: a wrong cut range now says "The end must be after the start" instead of the misleading "type the start and end".

## 3.52.0
- Temporal Light / Strong now really differ: the motion vectors stored "no motion" as 0.08 px of shift (8-bit rounding), so the history picture was blurred a little every frame and the Strong level could not do its job. "No motion" is now exactly zero. Offline test on noisy video: static scene, Strong +7 dB over the source (was +1.5), Light +3.
- Frame generation, Light and Very light: they only followed motion up to about 4 px, so with real motion the result was no better than a plain blend (looked like "nothing happens"). They now use a log search (36 matches per block, reach about 30 px, 1 px precision): in the test the Very light / Light result went from 21.7 dB (= plain blend) to 32 dB, the same as Normal, and it costs less than the old search.
- The same exact-zero fix also makes the frame generation picture sharper in still areas.

## 3.51.0
- **Input and Middle now go up to 1440p and 4K** (like Output). A value bigger than the file (or than the picture at that step) does nothing; it can only bring the picture down. Nothing else changed in how the chain works.
- **New choice "NIS Lite soft"** (screen layer / player mode chips, video export upscaler chips; saved files say `NISLiteSoft`): NIS Lite with the push at 40% of normal (`uGain` = 0.4). For dark and soft pictures, where the normal push amplifies noise and softness more than it helps. Mode value 8; the mode is stored in the low 8 bits of the export mode word, so nothing collides (`Stamp.modeName` now reads all 8 bits, it used to read 3).
  - Measured with the real shaders (see below), x2, the 6 real LR / HR pairs from the user, 4 crops each. Dark series frame: PSNR / SSIM normal Lite 39.9 / 0.983, **soft 42.5 / 0.988**, plain Catmull 42.6 / 0.988 (that frame's own reference is soft, so any push costs fidelity). Mean of the 6 pairs: normal 27.67 dB / 0.916 / sharpness 0.98, soft 28.16 dB / 0.913 / 0.88, original NIS 26.13 dB / 0.900 / 1.08, Catmull 27.85 dB / 0.901 / 0.82. On the real 360p test frames (x2 and x3) the same 40% push gave +0.5 dB and +0.013 SSIM. Soft is not "better" in general: it is less sharp (0.88 against 0.98); use it when normal looks noisy or harsh.
  - Tried and dropped: making the push depend on the brightness of the picture (a dark-based gain): +0.3 dB on the dark frame only, and it cannot tell a soft source with a sharp original (the 360p case) from a soft source with a soft original, so it stays a choice.
- **NIS Lite fifth-round retune from the Upscale branch** (real LR / HR pairs: anime, dark series, Deathloop native and FSR, two phone UIs, and two flat-art images): Gaussian sigma x0.8, noise gate up to 0.08, overshoot 0.35, detail strength x1.5. Same cost. About +0.003 SSIM, +0.2 dB, about 15% less halo on those pairs. Mean of the 6 pairs (real shaders): SSIM Lite 0.916 against 0.900 for the original NIS, on every one of the 6 images Lite is ahead in SSIM and PSNR.
- **The shaders were compiled and run for real this time**: both NIS shaders compile and link on a software OpenGL ES 3.2 driver (Mesa llvmpipe), and the NIS Lite output matches the numpy model it was tuned with to within 8-bit rounding (mean difference 0.1 to 0.35 of 255, largest 1.9). The same test run on the original NIS shader gives the numbers the earlier numpy port gave (mean SSIM 0.8995 against 0.900), so that port was right too. The test script is in `tools/shader_test/glrun.py` (needs `EGL_PLATFORM=surfaceless`, Mesa, Python 3 with numpy). A rough speed proxy on that CPU driver (960x540 to 1920x1080): NIS Lite about 35% of the time of the original NIS. A CPU driver says little about a phone GPU; it was not measured on a phone.
- Not compiled or run on a phone here: the Kotlin changes (mode lists, strings, chips) were reviewed by reading only; the GLSL was compiled and run offscreen as described.

## 3.50.0
- **CRSC Edge now works with a chosen output size.** In the player / photo output-size chain CRSC Edge had no branch and silently fell back to plain bilinear + RCAS, i.e. it was identical to Fast, and its quality levels did nothing there. It now runs the real CRSC Edge pipeline (shared function `crscEdge`, same code for both paths).
- **Sharpen is no longer the same as Fast when it enlarges** (chosen output size): Fast stays plain bilinear, Sharpen uses a sharp bicubic (Catmull-Rom, anti-ringing clamp) + RCAS. Offline x3: Sharpen PSNR 26.61 vs Fast 26.39, edge sharpness 0.77 vs 0.71.
- **CRSC Edge levels are evenly stepped now.** Before: Light, Balanced and Strong were almost the same picture (difference 0.7-1.6 of 255), Crisp was far stronger with halos (overshoot 1.16, as high as the original NIS) and Ultra was milder than Crisp. Now every level is one step sharper: edge sharpness 0.71 / 0.76 / 0.81 / 0.87 / 0.91 of the original (Maximum, file only: 0.93), halo overshoot 0.17 / 0.25 / 0.37 / 0.56 / 0.75 (FSR 1: 0.23); on sources that are already sharpened and compressed the top levels halo more (Ultra about 1.8, original NIS 2.1), so use Balanced or Strong there. Each step is about 1 of 255 in mean pixel difference; Maximum is only slightly different from Ultra. Ultra no longer needs 3 back-projection rounds (they gave nothing measurable), so it is no longer heavy: all live levels cost one round.
- **Bug fixed:** the strength of the last RCAS pass left over from a CRSC Edge frame could stay in use in the chosen-size path after switching to another mode. It is reset at the start of every frame.
- Cleaned the README (the 3.49.1 notes were there twice, the title showed 3.47.0).
- Not compiled or run on a phone here. The shaders were compiled and run offscreen with a software OpenGL ES 3.2 driver, and the level tables were measured with the same shaders.

## 3.49.2
- NIS Lite brought to the final state of the separate Upscale branch: third round (edge steepening removed, exactly horizontal / vertical edges are not smoothed along their length) and fourth round (re-tuned on real content). Only the `NIS` shader in `Shaders.kt` changed; every other file is as in 3.49.1.
- Not compiled or run on a phone here; the merged shader was compiled and rendered offscreen with a software OpenGL ES 3.2 driver.

## 3.49.1
- Input resolution below the file's size no longer looks rough: the picture is copied at full size and shrunk with a proper filter (halving steps + 4 taps) instead of one single-tap read. Same filter for the new Middle step and for manga / photo pages.

## 3.49.0
- Resolution chain now has a MIDDLE step: input -> middle -> output. After clean-up the picture is shrunk to the chosen Middle size (clean anti-aliasing), then the chosen upscaler (CRSC Edge etc.) builds it up to the output size. Example: soft 1080p file -> Middle 480p -> Output 1080p. Ignored when Middle is not smaller than the work size. The settings panel info line shows the extra step.

## 3.48.0
- Library: new "Music" tab (audio files), like the other sections.
- Edit photo and Edit audio: pick "From the app's library" or "From the phone's files", like Edit video.
- Edit photo: new "Draw" tab (pen / marker, 7 colours, 4 thicknesses, undo, clear); strokes are saved into the picture at full size.
- Player Tools menu: "Edit" item that opens the right editor for the open file (video / photo / audio).

## 3.47.0
- **Edit photo** (new): turn left / right, mirror, flip, crop (free, 1:1, 4:3, 3:2, 16:9, 3:4, 2:3, 9:16 with zoom and position sliders), auto fix (the app's own Smart fix), brightness, contrast, colour strength, warmth, eight ready-made looks (vivid, black and white, sepia, warm, cool, fade, dramatic), sharpen, saved size (full / 75 / 50 / 25 %) and JPG or PNG. Saved as a NEW picture in Pictures/ClearOverlay, the original is not changed; a Share link appears after saving. It also appears in the system "Edit with" list of other apps.
  - Preview: a small copy (long side 1280 px). Colour changes are a colour-matrix filter on the preview (instant); turn / crop / auto fix / sharpen are rebuilt on a background thread. Saving decodes the photo again (long side at most 3200 px; retried at half size if memory runs out) and runs the same steps, so the file matches the preview. The photo is turned upright by its EXIF tag first.
  - The sharpening row logic was checked against a reference 3x3 unsharp mask (identical output). The rest was only reviewed by reading; not compiled or run here.
- **One "Edit" button** on the main screen (replaces "Edit video" and "Edit audio"): it opens a screen that lists the video, audio and photo editors. Fewer buttons on the main screen. The editors themselves are unchanged.

## 3.46.0
- **NIS Lite**: the NIS upscaler (player, overlay, export, PC stream) was rewritten to be lighter, cleaner and more natural. The old shader is kept in `Shaders.kt` as `NIS_ORIG` (not compiled into a program).
  - Cost per pixel: 16 texel fetches + 1 bilinear tap, no big tables (old: 36 fetches, 4 edge tests, two 384-float tables indexed at run time).
  - Idea: NIS-style edge direction + limited adaptive sharpening, FSR 1-style cleaning along edges (the picture is smoothed *along* an edge, not across it, so stair-steps go but the edge stays sharp), CRSC-style fidelity (the result never goes past the local min / max, big details are soft-limited, flat / noisy areas are not sharpened).
  - Offline test (numpy model of the shader vs a literal port of the old shader; x2; photo and line-art; box, nearest (aliased) and JPEG q45 sources; sharpness slider 50%): old NIS sharpness 1.15-1.31 (x original), halo 0.9-1.8; NIS Lite sharpness 0.99-1.11, halo 0.17-0.5 on photos. PSNR on photos: old 27.7 / 23.8 / 25.4 dB, Lite 30.0 / 25.9 / 26.6 dB (Catmull 29.6 / 26.5 / 26.7). Line art: Lite SSIM 0.894 / 0.857 / 0.738 against old 0.904 / 0.812 / 0.774 (box / aliased / JPEG).
  - The sharpness slider now maps inside the shader (0 = soft, 100% = strong, still limited).
- **Crisper pass (second round)**: closer to the original NIS look. Added edge steepening across the edge (2 more cubic evaluations, pulls the value toward the nearer side of the edge, limited), a second fine-detail unsharp mask and a stronger main one. Cost is still ALU only (same 16 fetches + 1 tap). Model numbers at slider 50% (mean of photo / photo / line art, box / aliased / JPEG sources): sharpness 1.10 (first Lite 0.99, old NIS about 1.15-1.3), halo 1.9 (first Lite 1.1), PSNR 24.8 dB (first Lite 25.7). At slider 80% sharpness 1.20. Lower the slider to go back toward the softer, cleaner first version.
- **NIS (original)** is back as its own choice (screen layer / player mode chips, video export upscaler chips): the old heavy shader, to compare with NIS Lite on the phone. NIS Lite is labelled "NISLite" and the original "NIS" in saved file names.
- **Tuned on real pictures** (the 360p -> 1080p test frames of the user: 3 room and 3 game crops, the 360p frame rebuilt by averaging 3x3 blocks, compared to the real 1080p frame). x3 enlargement, slider 50%: gradient (sharpness) against the real 1080p frame: bilinear 0.65, Catmull 0.68, first NIS Lite 0.72, previous crisp NIS Lite 0.77, **original NIS 0.82, new NIS Lite 0.81**; PSNR 30.1 / 30.4 / 30.7 / 30.5 / 30.2 / **30.4** dB, SSIM 0.860 (original NIS 0.858). So the new NIS Lite is about as sharp as the original at x3 and a little more faithful. At x3 the previous version was too soft; the enlargement factor (new uniform `uFactor`) now widens the soft reference and sets the push: sigma = 0.4 + 0.2 f, detail strength = 1.1 + 0.2 f (x 1.6), edge steepening 0.65 - 0.15 f (same as before at x2).
- The 360p source in the test is a very compressed stream: NIS Lite and FSR 1 outputs differ by only 2.2 / 255 on that frame and both show the same painted / posterised look. That look comes mostly from the source and from the clean-up stages (denoise / deblock), not from the upscaler.
- **NIS Lite, third round (lighter and better than the original NIS in the tests)**:
  - Removed the edge-steepening stage (2 of the 5 cubic evaluations). In every test it gave no measurable gain. Estimated ALU work per pixel about 20% lower (counted by hand, not measured on a phone); fetches unchanged (16 + 1).
  - Edges that are exactly horizontal or vertical (text, UI, HUD) are no longer smoothed along their length: they cannot have stair-steps, and the smoothing only softened thin strokes.
  - Tests (same cases for every method; x2 and x3; photo, YouTube-like x264, dark movie with grain, animation, aliased game render, aliased game stream, text/UI), mean over all: SSIM new Lite 0.811, previous Lite 0.809, original NIS 0.800; PSNR 25.0 / 24.9 / 24.1 dB; halo 1.3 / 1.4 / 2.0. New Lite is ahead of the original NIS in every case except text/UI at x3 (SSIM 0.500 against 0.531). The original NIS is sharper (sharpness 1.17 against 1.04 of the real picture), so on a picture that needs more bite the slider of Lite has to go up.
  - Real 360p -> 1080p test frames (x3): new Lite PSNR 30.53 dB, SSIM 0.861, sharpness 0.82; original NIS 30.24 dB, 0.858, 0.82.
- **Fourth round (tuned on real content)**: test set made from the user's two real 1080p frames (room / chat text / faces / plush; Rust HUD / names / character / grass), shrunk x2 and x3 and compressed with x264 (crf 28), 12 crops each. New Lite beat the original NIS on all 24 crop / scale pairs (SSIM x2 0.898 against 0.883, x3 0.825 against 0.813). Plain Catmull has a higher SSIM than both (0.907 / 0.844) but much lower sharpness (0.85 / 0.75 against 0.97 / 0.94 of Lite; 1.0 = the real picture), so the tuning target was "sharpness near the real picture, then the highest SSIM". Coordinate search over 13 parameters found no real gain beyond: detail strength x1.15 and the second (fine) unsharp mask removed (one Gaussian less per pixel). Real set, mean of x2 and x3: SSIM 0.859, sharpness 0.97. Cost: 3 cubic evaluations + 1 Gaussian + 16 fetches + 1 tap; estimated about 30% less ALU than the first crisp version and about 10% less than the third round (counted by hand).
- Not compiled or run here: the shader was only modelled in numpy. The speed gain is from counting work, not measured on a phone.

## 3.45.0
- **Edit video, better** (still no re-encoding): two sliders (From / To) with the video frame at each end, so the cut points are picked by eye (the text fields still work and stay in sync); **Cut it out** (remove the part between From and To, join the rest) next to the old Keep; **Join another clip** at the end (clips must have the same codec and size, otherwise a clear message). The remux code now writes a list of segments on one continuous timeline.
- Not compiled or run here. Next: photo editor.

## 3.44.0
- **Edit audio** (main screen, under Edit video): pick a song or the sound track of a video, cut a part (from - to), fade in / out (0-8 s, smooth curve), volume (-6 .. +10 dB), optionally run your sound enhancer settings (equaliser, presets), save as a new .m4a in Music/ClearOverlay. The original is not changed. The export code (`AudioExport.run`) got an `Edit` parameter: sample-accurate start / end inside the decoded blocks, the enhancer filters run on the whole block so they stay in step.
- Not compiled or run here. Next: better video editor, photo editor.

## 3.43.0
- **Sound enhancer, more tools**: a 5-band **equaliser** (60 Hz shelf, 250 Hz, 1 kHz, 4 kHz, 12 kHz shelf; -12..+12 dB each; quick shapes Flat / Bass+ / Vocal / Treble+ / V) and a **Dialogue boost** slider (presence lift around 2.8 kHz, up to +7 dB). The presets (Music / Video / Podcast / ASMR) now set these too. Everything works in the music player, the video player, the PC stream and the file export (enhanced copy), and is saved.
- The filter formulas (RBJ biquads) were checked numerically: e.g. +12 dB shelf = 12.1 dB at 20 Hz, 6.0 dB at the corner; peak bands hit exactly their gain at the centre.
- Not compiled or run here; the sound itself is not judged. Next: audio editor.

## 3.42.0
- **Tools button in the video / photo player**: zoom, screenshot, rotate, rotation lock, free rotation and "Edit video" (cut, mute, speed) are now one ✎ button next to FX; the top bar stays clear of the picture. The button turns accent-coloured while zoomed.
- **Text level** (Main screen > Appearance): Full / Light (every explanation cut to its first sentence) / Minimal (explanations hidden, only labels and controls). Works in every screen that builds its text through the shared helper; texts set later in code are not affected.
- Not compiled or run here.

## 3.41.0
- **Repair profile** (Video / Photo / Manga ... quick-profile row, new last chip): for big pictures of poor quality ("fake HD": soft, blocky, noisy). Strong clean-up of blocks, noise and banding at the source size, a wide Detail radius for the softness, light sharpening, CRSC Edge as the upscaler. For really low-resolution files also lower the "source resolution" chip.
- **Save as a new file (video)**: the CRSC Edge level chips only appear when CRSC Edge is the chosen upscaler.
- **Manga reader**: the top bar is much smaller (about 40 %: tighter padding, smaller icons, direction / mode buttons are symbols only), the file name is shown, and the second line shows the page number plus the file format and size.
- Frame generation "Very light" is real: it halves the motion search width, uses a 2 px search range instead of 4 and skips the final 1-px refinement (cheaper, but misses fast motion).
- Not compiled or run here.

## 3.40.1
- **The levels now really differ.** Measured first: in 3.40.0 Balanced vs Strong differed by about 0.1 of 255 (invisible) because the detail step is clamped to the local range, so a bigger amount changed nothing. Now (mean difference to Light on the test pictures, video / photo / text / anime): Balanced 0.7 / 0.7 / 2.0 / 1.7, **Strong about 1.4 / 1.5 / 3.9 / 3.4** (stronger detail boost, wider overshoot, stronger edge step), **Crisp about 3.6 / 3.8 / 6.3 / 7.6** (also wider radius). Light and Balanced are the faithful ones; Strong costs a little fidelity (-0.3 to -0.4 dB), Crisp a lot (-2.5 dB) and is purely a punchy look. Ultra / Maximum stay the faithful heavy ones.
- **Temporal**: Light now 0.5 blend with a strict match window; Strong 0.93 with a wider window. Test (noisy simulated video, static / slow / faster pan): Light +1.0 / +1.0 / +0.8 dB, Strong +3.6 / +2.3 / +2.3 dB, against +2.8 / +1.8 / +1.6 dB for the old Light and +3.2 / +2.1 / +1.8 for the old Strong (those two were hardly different). Strong can leave faint ghost trails on fast moving thin objects.
- Test pictures are synthetic; judge on the phone with FX on / off and Zoom. Not compiled or run here.

## 3.40.0
- **Two heavier CRSC Edge levels.** *Ultra (heavy)* for live use (player, stream): 3 back-projection rounds (gain 1.3) + edge smoothing + detail boost + edge step. *Maximum (file only)*: 6 rounds, only offered in Save as a new file (video export chips; the manga / photo batch "CRSC" quality uses it automatically). In the live panels level 5 is never used (it falls back to Ultra).
- Text and Manga profiles now pick Ultra.
- **Honest numbers** (offline test, x2, 5 content sets, 2 pictures each, PSNR / SSIM): more rounds hardly help. Ultra: text SSIM 0.8474 vs 0.8453 (Strong), manga 0.4131 vs 0.4100, anime +0.06 dB; photo and video: no difference. 6 rounds / interleaved / second final round: at most +0.02 dB more than Ultra. Supersampling (working at 2x and shrinking) was clearly worse (-0.4 to -1 dB). The method is saturated: heavier is not better by these metrics.
- **Strong vs Crisp**: Strong is the more faithful one (measured). Crisp (stronger detail boost + double edge step) scored lowest of all CRSC levels (-0.2 dB vs Balanced) and only *looks* crisper; use it when you want a punchy look. Ultra is the strongest faithful choice.
- Job mode bits: CRSC level now uses 3 bits (21-23).
- Not compiled or run here.

## 3.39.0
- **Best upscaler for each kind of content.** The quick profiles (Video, Stream, Game, Photo, Movie, Anime, Text, Manga) now choose the upscaler and the CRSC Edge level too, not only sharpening / clean-up. Offline test (x2, 6 test sets: photo, x264 video, game-like, anime-like, text screenshots, manga-like screentone; PSNR / SSIM against the original, FSR 1 / SGSR 1 / NIS / bilinear / CRSC levels compared):
  - photo +0.10 dB vs FSR 1 (CRSC balanced best), compressed video +0.08 dB, anime +0.24 dB (SSIM 0.812 vs 0.802), text SSIM 0.845 vs 0.829 (strong), manga SSIM 0.409 vs 0.397 (strong). NIS and SGSR 1 were last everywhere, so they stay optional.
  - Game / stream: on the aliased game-like set plain bilinear scored best and CRSC light second (better than FSR 1); that test is only a rough proxy, so Game and Stream use CRSC *light* (one round, cheapest).
  - Levels: Photo / Video / Movie / Anime balanced, Text / Manga strong, Game / Stream light.
- Photo / Text / Manga profiles always use CRSC Edge when the picture is enlarged; Video / Stream / Game / Anime use it with the Quality budget, otherwise FSR 1. Performance budget stays "Fast".
- Auto (video): sources up to about 1080p30 get the Quality budget (CRSC Edge); 70-150 MP/s Balanced (FSR 1); above 150 MP/s Performance.
- Sections Photo, Video and Manga start with CRSC Edge (once, existing choice is replaced one time); the PC stream section is re-seeded with the Stream profile at the Quality budget.
- The overlay (screen capture) still uses sharpening only: the capture is already at full size.
- Test caveats: synthetic proxies (cartoonised and screentone pictures, x264 of still images), SwiftShader, not a phone. Not compiled or run here.

## 3.38.2
- Merge of 3.38.1 (direct streaming, build fix) with the CRSC Edge of 3.38.0. Offline WebGL test, x2, 4 natural pictures, sharpness 50%: on clean pictures the old CRSC Edge (2 back-projection rounds + edge step) scored 31.13 dB / SSIM 0.9195 vs 31.09 / 0.9144 for the 3.38.0 one; on compressed sources (JPEG q60 / q35, like video and streams) 3.38.0 wins: 28.23 / 27.40 dB vs 27.98 / 27.16 (FSR 1: 28.12 / 27.31). 3.38.0 also needs only one back-projection round, so it is lighter. Since video and streams are always compressed, the 3.38.0 CRSC Edge (GlPipeline.kt, Shaders.kt) is used. A hybrid of both was tested and was worse than either.
- Not compiled or run here.

## 3.38.1
- **Build fix**: the English `moon_hint` text made the resource step fail ("Invalid unicode escape sequence", string/moon_hint). It now uses plain typographic quotes and an apostrophe character instead of backslash escapes, so aapt2 has nothing to trip on.

## 3.38.0
- **PC game streaming goes straight into the +CRSC engine (direct mode, on by default).** The embedded Artemis / Moonlight client no longer has to be captured from the screen: its video decoder now draws into the `GlPipeline` input surface and the pipeline draws the processed picture into the stream window. So the stream gets FSR 1, SGSR 1, NIS, CRSC, sharpening, detail / clean-up, temporal clean-up and **frame generation**, all with no screen-capture permission, no floating layer and no capture delay.
- **Sound:** every decoded audio packet goes through the sound enhancer (clarity / bass / width / loudness / voice, the same as the music and video player) before it reaches the AudioTrack. Stereo only: 5.1 / 7.1 streams are left untouched.
- **In-game menu:** a new entry "Picture & sound (+CRSC)" opens the picture panel (same as the video player), temporal and frame-generation choices and the sound panel, live while playing. The stream has its own picture settings section ("PC streaming"), so the player / screen layer settings are not changed.
- Main screen: a switch "Process the stream inside the app (direct)". Off = the old way (screen layer + bubble). In direct mode the first button just opens the client.
- Safe fallbacks: HDR streams, the switch being off, or the GL engine failing to start all use the original direct rendering. A warning shows if the old screen layer is running at the same time (the picture would be processed twice).
- How it is built: `moonlight/.../ClearHook.java` (small bridge, the module does not depend on the app), `Game.java` (decoder target + release), `GameMenu.java` (menu entry), `AndroidAudioRenderer.java` (audio hook) and `app/.../StreamFx.kt` (the engine side).
- Frame generation adds about one frame of delay (it needs the next frame); it is off by default. Not compiled or run here.

## 3.37.1
- Main screen, PC game streaming card: the first button is now one step: it applies the streaming picture settings, starts the screen layer (the floating bubble = the toolbox: tap on / off, hold for settings) and then opens the streaming client. The second button opens the client alone. The hint text explains the flow.

## 3.37.0 (3.33.0 changes merged into 3.36.0)
- **Manga / CBZ**: a full RAR5 decompressor (`Rar5Unpacker.java`: LZ + Huffman + E8 / E8E9 / ARM / delta filters, solid archives, CRC check). A .cbz / .cbr that is really a compressed RAR5 now opens with all its pages (before, only the few pages stored without compression showed). Tested offline on the libarchive / rarfile sample archives (compressed, solid, multi-file: CRC OK). If a few pages cannot be unpacked a message names how many. Zip entries without a picture extension are always sniffed by their first bytes.
- **NIS** (NVIDIA Image Scaling, MIT licence) as its own upscaler (player, overlay, export): directional polyphase scaler with its own adaptive sharpening. On clean test pictures it scores below FSR 1 in PSNR (it sharpens on purpose), so it is an option, not the default.
- **CRSC Edge quality**: Light (1 round, no edge step) / Balanced (the 3.36.0 setting: 2 rounds + light edge step) / Strong (3 rounds) / Crisp (2 rounds + double edge step). Chip row under the upscaler list; export has its own row (bits 21-22 of the job mode).
- Upscaler review of the merged line (offline WebGL test, 4 natural pictures, x2): FSR 1 31.04 dB; plain back-projection 31.17; noise-aware back-projection (3.36.0) 31.22 and, on JPEG-compressed sources, 28.01 vs 27.85 for the plain one, so the 3.36.0 shaders were kept.
- Not compiled or run here.

## 3.34.0 (merge of three lines)
Built from the bug-fix line (3.33.0) with the other two lines merged in, each part kept only where a PC test showed it is better:
- **Bug fixes** of 3.32.0 (streaming upscale, chip sizes ...): as in the bug-fix line.
- **Sound** (from the sound line): sound enhancer (clarity / bass / width / loudness / voice; Music, Video, Podcast, ASMR), music & sound player with background playback, enhanced .m4a copy, enhancer for the video player's sound, Moonlight card on the main screen.
- **CRSC Edge**: FSR 1 EASU + two rounds of back-projection (as in 3.32.1) + a light shock filter across the edges (new). Test (x2, real pictures, Lanczos standing in for EASU): back-projection 29.52 dB / SSIM 0.898, with the shock step 29.57 / 0.900 and crisper edges. A third back-projection round is dropped (almost no gain, costly).
- **Back-projection is noise-aware**: very small errors (mostly video-compression noise) are no longer pushed back, real edges still are. Test on JPEG-compressed sources: 26.34 -> 26.43 dB, SSIM 0.7625 -> 0.7671; clean sources unchanged (-0.01 dB).
- **Temporal** (3.32.1 version kept, not the rewrite of the sound line): on simulated noisy video it beat the output-size rewrite in every case (the rewrite broke down on sub-pixel pans because the block motion is whole-pixel). One change: the agreement window is narrower (0.12 -> 0.08) and Strong uses 0.85 instead of 0.9, which tested better on slow pans (mean gain over no temporal +0.27 -> +0.37 dB; a perfectly clean slow pan still loses about 0.5 dB, that is the price).
- **Frame generation**: the 3.32.1 interpolation (neighbouring blocks count only when they move alike, more tolerant match test) kept: better in 4 of 5 simulated scenes (+0.4 to +0.9 dB), slightly worse in one (-0.3 dB).
- Not compiled or run here.

## Use
1. Start -> allow "Display over other apps" -> allow screen capture.
2. A floating bubble appears. Tap = effect on/off. Hold = settings panel. Drag = move.
3. Modes: Sharpen (RCAS, full resolution) / FSR 1 / SGSR 1 / Fast (hardware bilinear, cheapest,
   best for very weak GPUs). "Boost" adds a second sharpening pass.
4. Render resolution: pick 1080p / 1440p / 4K to render at that height-class and upscale back to
   the panel's real resolution, or "Custom" for the raw percentage slider. A preset above the panel's own
   resolution (e.g. 1440p on a 1080p phone) is allowed: the frame is captured bigger, sharpened, then
   shrunk back to the panel with a 4-tap filter (supersampling). Custom slider goes 33-200%. In Sharpen mode only values above 100% apply (it never renders below full resolution).
5. Vivid colors: optional saturation + contrast lift applied after upscaling (off by default),
   similar in spirit to a video player's "enhance" filter.
6. Layer opacity (screen overlay panel): how much of the processed layer shows over the real screen (100% = fully processed, lower = blended with the original, a softer effect; changes apply live and are part of saved profiles).
7. Bubble size: slider to resize the floating bubble, applied live.
7. Auto-hide (on by default): after ~2.5s idle, the bubble dims and slides ~37% of its own size
   past the screen edge it is snapped to. The idle delay is adjustable (1-30 s) in the panel. Push the bubble past a side edge and release to put it to sleep instantly. Any touch instantly brings it back; that first touch
   only wakes it, it does not also toggle the effect.

## Library: your own folders and categories (3.8.0)
The Library (main screen > "Library: videos, photos, manga") lists every video and photo on the phone, grouped by folder, without picking files one by one.
- **Add a folder by hand** (＋📁 at the top, or the "Add a folder…" tile): for a folder the phone's media index does not list. Pick it once; sub-folders are included, and the access is remembered. Hand-added folders are marked 📌 and work in Videos, Photos and Manga. Long-press one to remove it from the library (nothing is deleted from the phone). 🔄 scans hand-added folders again.
- **Categories**: "⭐ Favorites" plus any you make (Videos and Photos tabs). Long-press an item to select (tap more to add to the selection), then **★** (toggle favorite), **Add to…** (pick or create a category), **All**, **✕**. Inside a category the selection bar also has **Remove**. Long-press a folder to add everything in it to a category; long-press a category to rename or delete it. Favorites show a ★ on their thumbnail.
- Opening a category plays it as a playlist, like a folder.

## 3.10.9
- **Player, portrait**: the picture view is now sized from the area that is really on screen (it used the previous orientation's size for a moment after a rotation, so the video looked zoomed in) and is rebuilt whenever that area changes. The old saved "Fill" setting is reset to Fit.
- **Picture size** (video): Fit, Fill (crop edges), Stretch to the screen, 16:9, 4:3, 21:9. In the settings panel (Playback section) and in the menu. Photos are always fitted.

## 3.10.8
- Build fixes: FTP binary-mode constant clashed with the app's own `Net.FTP` name; the share-listing library no longer drags in a second BouncyCastle.

## 3.10.7
- **Network > add / edit a SMB server**: *List the shared folders* asks the server for its shares (after the address and login are filled in) and fills the share name when you pick one. Hidden shares ($) are left out. If the server refuses or the helper library does not fit, a message says so and you can still type the name.

## 3.10.6
- **Photos from a link or a network server** are read once and decoded from memory (before, each photo opened 3 separate connections: size, picture, rotation), and web links now time out after 15 / 30 s instead of hanging.

## 3.10.4
- **Manga reader, same tools as the photo viewer**: the cloud button now opens *Enhance this page*: Smart fix, offline AI upscale (with the model list: choose / one-tap download / add from file or link / remove), Online photo x4, Online clearer writing x2, Back to the original page, Save page, Online settings. An enhanced page stays enhanced while you scroll or turn pages, until you choose *Original*. Progress shows in the top bar; tap the cloud button again to cancel.
- **Network manga**: a .cbz / .pdf on an SMB / FTP server is downloaded once into the cache with a progress counter in the top bar (opening it again, or continuing from History, is instant), instead of being copied again on every open.
- **Network scan** (🔍 in Network): found devices show their network name when the router knows it, the form is pre-filled with that name, and servers you already saved are marked ✓.
- Online error HTTP 402 = the Replicate account has no credit (the service is paid; not an app bug). The message now says so in English and Persian.
- Note: the README sections below 3.9.5 describe earlier stages; Network (SMB / FTP, scan, last folder per server), History, Panel size on every panel, low-data online mode and the Manga quick profile are all in the app already.

## 3.22.0
- **Screen direction is separate for photos and videos** in the player (the two keys remember their own state; before, one setting served both). The panel (size, lock, ...) and the effect settings were already separate per photo / video.
- **Screenshot for video**: the camera button in the player's top bar saves the current frame with the effects on (at the chosen output size, or the video's own size) to Pictures/ClearOverlay.
- **Logo**: the four squares around the + keep their sizes, their centres now sit on two horizontal and two vertical lines at the same distance from the plus (app icon, launcher icon and bubble).
- **CBZ in the manga reader**: pages are found again by their entry objects (names that are not valid UTF-8 could not be found again), and an archive that cannot be opened as a random-access zip is now read from the start into the cache instead of failing. RAR5 and 7z are still not supported.

## 3.21.1
- **Upscale a video, tidier**: option rows swipe sideways instead of squeezing (also in Enhance to files and the Library tabs); options are grouped under headings; the *Fully automatic / Custom* switch picks everything by itself (quality, upscaler, encoder, size, speed); frame generation shows *30 fps -> 60 fps*; the *CRSC* entry is gone from Quality (it stays as an Upscaler choice); "(2x frames)" removed from the player switch.
- **Times**: the estimate now says *Processing time (how long the phone works)* and is not skewed by AI / frame-generation runs any more (they no longer teach the speed estimate); *time left* uses the recent speed instead of the average since the start.
- CRSC Lanczos is listed before Fast and Raw in the mode row.

## 3.21.0
- **Offline AI model for video** (Upscale a video > *AI model*): Off / Light / Medium / Heavy. Every frame goes through a small TFLite super-resolution model on the CPU (Light = XLSR / QuickSRNet Small, Medium = QuickSRNet Medium / Large, Heavy = SESR-M5 / Real-ESRGAN General), then the normal FSR / Lanczos / sharpening steps. The frame is shrunk first (360 / 288 / 216 px high), so it is for short, low-resolution clips; expect seconds per frame. *Half the frames* makes it twice as fast; *Test the speed* measures the phone and improves the time estimate; the model is downloaded from the same screen.
- **Stream**: pieces are now 8 seconds long (before: a minute), so the player starts after the first piece, and when the phone is slower than the video it waits for a bigger head start. New settings: *keep this much ready ahead of me* (Auto / 30 s .. 10 min) and *keep this much behind me* (Auto / 10 s .. 2 min); watched pieces are deleted. Seeking works inside the finished pieces; a brief pause between pieces is possible.
- Not compiled or run here.

## 3.20.2
- **Upscale a video**: the Quality list has a sixth choice, *CRSC (own)*: the Best settings with the CRSC Lanczos upscaler.

## 3.20.1
- **Enhance to files** (photos / manga): a fourth quality, *CRSC Lanczos* (own method: Lanczos-3 with anti-ringing + the strong Photo / Manga clean-up).

## 3.20.0
- **CRSC Lanczos**: own upscaler (Lanczos-3, 6x6 taps, anti-ringing clamp, then RCAS). Available as a mode in the overlay / player panel and as an Upscaler choice for video export. No halos; a bit softer than FSR 1 / SGSR 1 and heavier on the GPU.

## 3.19.1
- **Frame generation quality**: Light / Normal / High (High uses smaller 8 px blocks and a 1 px refining search; about twice the work of Normal), in both the export and the player.

## 3.19.0
- **Frame generation modes**: 2x / 3x / 4x frames per source frame, and a *Light* motion search (about a quarter of the work) in both the file export and the live player switch. The LSFG Lossless.dll is not supported (it needs a native Vulkan port; see the chat notes).

## 3.18.1
- **File size option** (Upscale a video): Normal / Small (about 55% of the bit rate) / Smallest (about 32%). Best with H.265. The phone re-encodes with its hardware encoder, which is less efficient than YouTube's VP9/AV1, so the result can still be bigger than the downloaded file.

## 3.18.0
- **Quality options are always visible** (Upscale a video): Quality = Auto / Fast / Balanced / Best / **Maximum** (Best plus a second sharpening pass and the highest bit rate: slowest, heaviest, biggest file), Upscaler = Auto / FSR 1 / SGSR 1, Encoder = Auto / H.264 / H.265, with the sharpness and vivid sliders below. Auto picks for the video and the phone and shows what it picked. (Before, they were hidden behind a *Manual* switch.)
- **Frame generation (own method, not the LSFG app)**: *Upscale a video > Frame generation > 2x frames* builds an extra in-between frame for every frame (30 -> 60 fps) with GPU block matching + warped blending, inside the video file. The player has the same as a live switch (panel > Effect > *Frame generation*): one frame between every two, with a very small delay. Weak spots: very fast motion, scene cuts, small text. Estimate and size account for it (about 1.7x time).
- **Online AI for video (Replicate, paid)**: a button under Start: the video (or the chosen range, cut without re-encoding) is uploaded (limit about 95 MB), a cloud model (default `lucataco/real-esrgan-video`, changeable in the Online settings) upscales it and the result is saved to Movies/ClearOverlay. Resolution choices HD / FHD / 4k (exact values depend on the model). Runs in a background service with a notification. Needs your own token and credit (HTTP 402 = no credit).
- Offline AI/ML models (Real-ESRGAN etc.) for video are not offered: on this phone they take seconds per frame (days per film). They stay for photos and manga.
- Not compiled or run here: build it in GitHub Actions and test.

## 3.17.0
- **Streaming upscale** (Upscale a video > *What to do with the result* > *Watch now (stream)*): instead of making a file, the app upscales only a few minutes **ahead of the spot you are watching**, plays the finished pieces in the player (it opens by itself when the first piece is ready), **deletes the pieces you have already watched** (about one minute behind you is kept) and waits when it is 3 minutes ahead, so it needs very little free space and the phone rests while you pause. Turn on the *part* option and set *From* to start at, for example, minute 14; the window then slides forward as you watch (14-17, 15-18, ...). Nothing is saved as a file, and closing the player stops the work and deletes the pieces. Seeking works inside the finished pieces (about a minute each); the same Auto / Manual quality, pace and encoder settings apply.

## 3.16.1
- **Enhance to files now runs in the background**: it is a foreground service with a progress notification (with a Cancel button), so it goes on with the screen off or the app closed; the screen no longer has to stay on. Tap the notification to come back to the progress and the hold-to-compare preview.
- **Enhance a whole .cbz / .zip / .pdf**: Library > Manga > long-press a book tile (files in your hand-added folders) > *Enhance every page to a new .cbz…*. A PDF is drawn page by page (about 2000 px on the long side) and every page is enhanced; the result is one new .cbz in Download/ClearOverlay. The file is copied to the cache while it works and removed afterwards, so keep some free space for it. RAR / 7z are not handled here.

## 3.16.0
- **Enhance to files (photos and manga)**: Library > Photos > long-press a picture, select more, tap **Enhance**; or long-press a Photos / Manga folder > *Enhance this folder to files…*. Choose **Standard / High / Maximum (offline AI model, then a light polish)**, the size (same, ×1.5, ×2, ×3) and JPEG / PNG; manga can be written as **one new .cbz** (Download/ClearOverlay) or as separate pictures; photos go to Pictures/ClearOverlay/Enhanced. While it runs the last result is shown, and **holding the picture shows the original** to compare. Maximum needs an AI model (downloaded in the photo viewer); without one it runs as High.
- **Library**: the number of tiles per row (pinch) is now remembered separately for Videos, Photos, GIF and Manga (before, a pinch in one section changed all of them, which could leave videos at two per row).

## 3.13.0
- **Upscale a video, new screen**: it reads the file (size, fps, codec, length) and shows the result size, a rough time and the load on the phone (light / medium / heavy). *Auto* picks the cleanup strength and the encoder for this video and this phone; *Manual* adds upscaler (FSR 1 / SGSR 1), quality, encoder, **sharpness** (auto or 0-100%) and **vivid colours**. Sizes: 480p, 720p, 1080p, 1440p.
- **Load on the phone**: Max speed / Balanced / Gentle (rests between frames: slower, cooler).
- **Encoders are really tested** on the phone (a tiny encoder of each type is started): H.264, H.265, AV1, VP9 are shown with hw / sw / not working. H.264 and H.265 can be used for the result.
- The time estimate learns: after an export the real speed of the phone is saved and used next time.

## 3.12.8
- Build fix: a broken text line in Online.kt (3.12.1) stopped the compile.

## 3.12.7
- **Manga tab**: .pdf / .cbz / .cbr / .zip files inside your hand-added folders are now listed (after the folders) and open straight in the reader; before, they could only be opened with *Open PDF / CBZ / ZIP…*.

## 3.12.6
- **Video upscale: choose the upscaler** (FSR 1 or SGSR 1), like in the player. This is the third way to use the effects: *baked into a new file* (besides the screen layer and the live player).

## 3.12.5
- **Video upscale: encoder choice** (*H.264* / *H.265*): H.265 gives a file about 30% smaller at the same look; falls back to H.264 by itself if the phone has no H.265 encoder. The upscaling itself already runs in OpenGL (the same FSR 1 / denoise / sharpen shaders as the player).

## 3.12.4
- **Panels by purpose**: bubble size and bubble auto-hide / delay (they only exist for the screen layer) are no longer listed in the video, photo, manga and GIF settings panels; they stay on the main screen and in the bubble's own panel.

## 3.12.3
- **Video upscale from a network server (SMB / FTP)**: the file is copied to the phone first (the upscaler needs a seekable file), processed, and the copy is deleted afterwards. Make sure the phone has free space for it.

## 3.12.2
- **Video upscale can be resumed**: the finished one-minute pieces are listed on disk. If the app is killed, the phone restarts or the job fails, start the same file with the same size / quality again and it continues after the last finished piece (the progress bar starts there, the finished part is watchable at once). *Cancel* still throws the work away; leftovers older than a week are removed by themselves.

## 3.12.1
- **Manga**: RAR comics now open: .cbr, and RAR files that were only renamed to .cbz (a very common reason a "cbz" would not open). Pictures are unpacked once into the cache. RAR5 (new format) and 7z are still not supported; the message says so.
- **Online enhance**: small pictures go inside the request (one step fewer that can fail), models that do not know "scale" are retried with the image only, official models (no version) are started through their own endpoint, network errors are named, and a hardware bitmap no longer breaks the resize. HTTP 402 still means the Replicate account has no credit.

## 3.12.0
- **Upscale a video to a new file** (Main screen > *Upscale a video to a new file*, or the player's ⋮ menu): the video is decoded, run through the same GPU effects as the player (denoise / deband / FSR 1 / sharpen, from the *Low-res video* or *Anime* quick-profile tables) and re-encoded with the hardware H.264 encoder to **720p or 1080p**, saved in Movies/ClearOverlay. Three tiers: *Fast* (upscale + sharpen), *Balanced* (+ cleanup), *Best quality* (strongest cleanup, finer sharpening, higher bit rate). Frame rate stays the same (60 fps stays 60 fps); sound is copied untouched. It runs in a foreground service with a progress notification, so the screen can be off; the screen shows progress, speed (seconds of video per second of work) and the time left.
- The result is written in pieces of about a minute. **Watch the finished part** plays the finished pieces while the rest is still being made; at the end they are joined into one file.
- Not yet: resuming after the app was killed, videos on a network server (copy to the phone first), neural (AI) upscaling of video (about 2-3 frames per second on a mid-range phone, hours for a normal video).
- Under the hood the GL pipeline can now take its settings from a fixed set (`Fx.kt`), so an export is not affected by sliders moved meanwhile.

## 3.11.6
- **Separate settings per section**: the screen layer (overlay over other apps), video, photo, manga and GIF each keep their own picture settings (mode FSR / SGSR, render and input / output resolution, sharpen, denoise, contrast, anti-aliasing, quick profile, panel size, FX switches ...). Something chosen in the manga reader no longer changes photos or videos, and so on. The first time a section is used it starts as a copy of the screen layer's current settings, so nothing is lost; after that they are independent. The settings panel title shows which section it belongs to ("... · Manga"). Shared by all: the bubble, language, theme, "pause the overlay while playing".
- Saved user profiles are shared: a profile saved in one section can be applied in another.
- The photo / video split follows the file that is open in the player.

## 3.11.5
- **Manga page slider**: a bar at the bottom with the current page and the total; drag it (or tap the track) to jump far in one go. In right-to-left page mode the slider is mirrored, so page 1 is on the right. It shows and hides with the top bar.
- **Keep the FX button on screen** also in the manga reader (switch in the reader's settings panel): when the bars hide, only the FX button stays, top right.
- **.cbz / .zip**: pictures in any sub-folder of the archive are read (sorted by full path, chapter folders included; Windows-style `\` paths and Thumbs.db handled). The archive is copied to the cache once and reused when you open the same file again. If nothing readable is found, the message now says how many files the archive has and shows a few names, so the cause is visible. RAR / 7z archives renamed to .cbz are still not supported (a real RAR needs an extra library).

## 3.11.4
- **Logo (app icon, header, bubble)**: back to the classic layout, one pixel in each of the four corners around the "+" (big top-left, medium top-right and bottom-left, small bottom-right), the "+" keeps its size, the pixels are a bit bigger than the old ones and all sit inside the safe circle so nothing is cut off. The extra glow behind the plus in the launcher icon was removed.

## 3.11.3
- **App icon (launcher)**: it still had the old pixel squares at the very corners, which a round / squircle launcher mask cut off. Redrawn to match the in-app logo: the "+" and the shrinking pixels all sit inside the adaptive icon's safe circle, with a soft glow behind the plus. The themed (monochrome) icon uses the same shapes.

## 3.11.2
- Fixed a compile error in the settings panel (scope of the render-scale hint) introduced with 3.11.0.

## 3.11.1
- The resolution chain (input / output) now also works for **manga pages** (the page is brought to the input size, rendered at the output short side, capped at 6000 px / 20 MP), for **GIFs** (live), and **saving a photo** has a new entry *Save at the output resolution (JPEG)*.

## 3.11.0
- **Resolution chain (player / photo)**: Settings panel > *Resolution: input → output*. **Input** = what the file really is (Auto, 240p ... 1080p; lower than the file brings it down first, good for soft "fake HD" files). **Output** = the size it is rendered at (Auto = screen, 480p ... 4K). Bigger than the screen = supersampling; smaller than the file = **Downscale** (a clean anti-aliasing); smaller source than output = upscale with the chosen mode (FSR 1 / SGSR 1 / Fast). A live line shows the real chain: *file → work → output → screen*. (Before, the player ignored the render-resolution slider, and FSR 1 / SGSR 1 only differed when the file was smaller than the screen.)
- **Contrast** slider (-50 .. +50) next to Vivid colours; saved in your own profiles.
- **Logo**: smaller and redrawn; the pixel squares sit inside the safe circle so the round bubble no longer cuts them.

## 3.9.5
- **History**: videos and manga left half way are listed in Library > Videos / Manga > *History* (newest first, with the saved spot); tap = continue exactly there, long-press = remove (long-press the History tile = clear all). Finished items drop out by themselves.
- **Manga**: PDF now opens (the file picker no longer filters by type; the file type is detected from the file itself), .cbz with non-UTF-8 names opens, RAR / 7z comics (.cbr / .cb7) say clearly that they are not supported.
- **Panel size** (small / medium / large) is in the manga settings panel too (shared chips).
- **Photo panel**: video-only rows (tap = play/pause, auto-next) are hidden while a photo is open.
- **Quick profile "Manga"**.
- **Online enhance**: smaller upload (x4 photos 1024 px, writing 1280 px), data-URI fallback when the file store refuses, version lookup that survives models without "latest version", automatic retry on rate limit (429), a *Test connection* button in Online settings, and errors are shown in full in a copyable dialog.

## 3.9.0 (stage 1)
- **Themes**: Main screen > Appearance: *Follow phone / Dark / Light* and *Modern / Classic* (flat, square-ish, solid accent). The video, photo, manga and GIF screens stay dark (they sit on black).
- **Player**: FX on/off label is a small tag near the top; settings panel size Small / Medium / Large; speed 0.25x-4x with a slider and presets; orientation key = only Landscape <-> Portrait, with a separate lock key (freezes the current direction) and a separate free key (follows the phone in every direction); a start-up watchdog fixes videos that begin black or with a spinner that never ends (re-attaches the picture, nudges the decoder, reloads at the same spot); big videos (e.g. 4K on a 1080p screen) are processed at most 1.5x the screen size, which makes FX much lighter.
- **Quick profiles**: new *Text* profile (readable thin strokes).
- **Library**: cells are always the same square size, so the folder grid can no longer shrink after switching sections.

## 3.9.1
- **FX in the manga reader**: top bar has an FX button (on/off) and a settings button. The full effects panel (profiles, upscaler, sharpen, denoise, Vivid ...) opens at the bottom; pages are processed off screen with the same GL pipeline as photos and shown in both scroll and horizontal modes. Pages are rebuilt a moment after a slider stops.
- **Online enhance (photos in the player)**: Enhance > *Online enhance*: *Photo x4* or *Clearer writing x2*. Uses Replicate (replicate.com): you add your own API token and (optionally) the model names under *Online settings*. The newest version of the model is looked up at run time; default model `nightmareai/real-esrgan`. Pictures are shrunk to 1600 px before upload to keep the price low. Back cancels. Not tested without internet in the build environment: if it fails, the error text shown tells what went wrong (wrong token, no credit, wrong model name).
- **3.9.2 – online enhance elsewhere**: manga reader top bar `☁` (current page: *Photo x4* / *Clearer writing x2* / settings; tap `☁` again while it works to cancel); screen layer: the still-frame tool (long-press the bubble > AI snapshot) has `☁ x4` and `☁ Aa` buttons for the whole frame. Same token and models as the player. GIF and video are not included (a GIF is dozens of frames, video would be far more costly).

## 3.9.3
- **GIF viewer**: `FX` button + settings (gear): every GIF frame goes through the same local effects pipeline as photos (denoise, upscale, sharpen, Vivid ...). Free and offline, so it is the cheap alternative to cloud upscaling for GIFs (and for video the player's FX does the same). Off by default.
- **Hidden items PIN** (optional): long-press the eye icon in the library to set / change / remove a PIN (4+ digits); with a PIN set, the eye asks for it before showing hidden items. It is a privacy lock inside the app, not encryption: the files themselves stay where they are.
- **Manga**: top-bar icons (gear, cloud, close) match the library's line icons; the cloud menu can also save the current page (with FX or online result) to Pictures/ClearOverlay.

## Two ways to use the effects
1. **Whole screen** (bubble): captures the screen and processes it, so it works over any app / video. A full-screen layer, so it can never be as sharp as the real pixels.
2. **Inside the player** ("Video & photo player", or "Open with" on any video / photo / link): the file is decoded here and the effects are applied ONCE directly to the video frames - no screen capture, better quality, a 360p file is upscaled from its real pixels.
While the player is in front the screen effect is paused automatically (switch in the player's settings), so the picture is never processed twice; it is restored when you leave the player.

## Video & photo player
Pipeline: denoise / deband / anti-aliasing -> FSR 1 / SGSR 1 / Fast upscale -> sharpen -> Vivid.
- Engine: Media3 ExoPlayer. Local files, direct links (http/https), HLS (.m3u8), DASH (.mpd); mp4/mkv/webm...
- Top bar: **FX** = effects on/off (compare with the original picture), **rotation** (auto by video / landscape / portrait / follow phone), settings, menu.
- **Zoom**: pinch with two fingers (up to 12x) or tap the zoom button (1x / 2x / 4x / 8x). Zoomed in, one finger pans. The crop is taken from the real source pixels and goes through the whole pipeline, so you can switch FX on/off and compare the result at pixel level.
- Settings panel: effects on/off, "tap = play/pause" on/off (off = a tap only shows/hides the controls), pause screen effect while the player is open, plus all the picture sliders. While a slider is held the panel becomes almost transparent so the picture can be judged; it also closes itself after ~7 s idle (switch: "Fade the panel while adjusting"). In landscape it is a narrow column on the right.
- Subtitles: embedded tracks (CC button) or an external .srt/.vtt/.ass file (menu > Add subtitle file; non-UTF-8 files such as Windows-1256 Persian are converted automatically). Size adjustable in the menu.
- Audio track picker, speed 0.5x-2x, resume position, fit/fill picture.
- Gestures: single tap = play/pause (switchable), double tap left/right = -/+10 s, double tap centre = play/pause, horizontal drag = seek, vertical drag on the left = brightness, on the right = volume, long press = 2x speed while held.
- Photos are capped at 4096 px on the long side.
- Black picture + sound only (fixed in 3.2.0): the picture view used to be created only after the decoder reported a size, which it does not do before it has a surface. The view is now created from the track format, with a 1.5 s fallback.

## Photo tools (3.5.0)
Open a photo in the player; the bottom bar shows three buttons:
- **Enhance**: *Smart fix* (instant, no model: white balance + levels + shadow lift, measured from the photo's own histogram; does nothing if the photo is already balanced) or *AI upscale x4* (offline Real-ESRGAN General x4v3 through LiteRT / TensorFlow Lite on the CPU). Several models can be kept: the built-in one plus any .tflite you add by hand (Enhance > "AI models" > add from file or from a direct link; choose the active one there, remove added ones). No model is bundled in the APK or the zip any more: open Enhance > "AI models" > "Recommended models" and tap one to download it (Real-ESRGAN General x4v3, XLSR, QuickSRNet, SESR-M5). To bundle your own anyway, put it at app/src/main/assets/models/sr.tflite. The photo is cut into overlapping 128 px tiles; progress is shown, Back cancels. Input is limited to 1024 px on the long side so the result stays within 4096 px. Expect tens of seconds for a small photo and a few minutes for a 1024 px one on a mid-range phone.
- **Save**: renders the photo through the whole effect pipeline offscreen at full size (or 2x) and writes JPEG / PNG to Pictures/ClearOverlay (MediaStore, no storage permission). What you see (including the FX on/off state) is what is saved.
- **Original**: back to the decoded file.
- The rotation button now has 5 states: auto, landscape, portrait, follow phone, **locked** (keeps the current orientation). The icon shows the state.

## Updating over an old install
Every build is signed with the same fixed key (app/crsc.keystore, debug and release) and versionCode is the build time in minutes, so a new build installs over the old one as an update. A build signed with a different key (every build before 3.5.0) cannot be updated: uninstall it once, then install 3.5.0; from then on updates work. Keep app/crsc.keystore in your repo/zip - a different key breaks updates again.

## My profiles (3.6.0)
The first row of the settings panel (main screen, bubble panel and player panel all share it). Tune the sliders by hand, tap **＋ Save**, give it a name: every picture setting (mode, sharpness, detail, denoise, deband, anti-aliasing, render scale, vivid, boost) is stored. Tap a saved profile to get exactly those values back; long-press it to update it with the current settings or delete it.
- Quick profiles never touch saved ones. The profile you loaded stays highlighted until you change anything by hand.
- Safety net: when a quick profile is about to replace hand-made settings, the app copies them into **↩ Before quick profile** first, so one tap brings them back.
- Bubble settings (size, auto-hide) are not part of a profile.

## More AI models (3.6.0)
Enhance > "AI models" > **Recommended models**: one tap downloads, unpacks (Qualcomm ships .zip files) and selects a model. All run offline on the CPU, tile by tile; the upscale factor (x2 / x3 / x4) is read from the model itself.
| Model | Size | Notes |
|---|---|---|
| Real-ESRGAN General x4v3 | ~5 MB | best detail, slowest |
| XLSR | ~115 KB | fastest, softest |
| QuickSRNet Small / Medium / Large | 0.1 - 0.4 MB | light; Medium is a good first pick for photos |
| SESR-M5 | ~1.3 MB | better quality, slower than QuickSRNet |
Only **float** .tflite models work (not the w8a8 ones). Direct links (zip or plain .tflite) can also be pasted under "Add model from link", or a downloaded file picked with "Add model from file".
AI is photo-only: running a neural network on every video frame is far beyond a mid-range phone (about 2-3 frames per second at best), so video keeps using the GPU shaders (FSR 1 / SGSR 1 / denoise / deband).

## 3.7.0: library, playlist, panel lock, Auto
- **Library** (main screen, first button; also ⋮ > Library in the player): your videos, photos and manga straight from the phone's media index, no file manager. Tabs Videos / Photos / Manga, folders, thumbnails, duration badges. First run asks for photo/video access (READ_MEDIA_* / READ_EXTERNAL_STORAGE on Android 12). "📂" = the old picker / link entry.
- **Playlist**: opening an item from the library (or "Open with" on a media-store file) builds a playlist of the SAME type in that folder: photos swipe left / right (not when zoomed), videos use ⏮ ⏭ and can auto-play the next one ("Play the next video automatically"). Videos and photos are never mixed.
- **Manga**: any image folder (Manga tab) or a .cbz / .zip opens in the reader: Scroll (webtoon) or Pages (pinch zoom, swipe or tap edges, right-to-left switch). The last page is remembered. The reader has no effects pipeline.
- **Player panel**: 🔒 / 🔓 next to its title: unlocked, drag the panel by the title to move it away from the picture. New settings: panel opacity while adjusting (100% = never dims), "close the panel by itself when idle" on/off.
- **Auto** (top of every settings panel): picks quick profile, strength, GPU budget, anti-aliasing, mode and AI model by itself. Player video: content type from resolution / frame rate / stream, strength from the enlargement, budget from the pixel rate and lowered when frames drop. Photo: strength from size, Quality budget, AI model by size (small = best model; a very small photo is AI-upscaled automatically). Screen overlay: light all-round profile, then a ladder Fast 80% > Performance > Balanced > Quality moved by the measured time per frame. Touch any control and Auto switches off. These are rules of thumb, not measured on a device.

## AI still frame (3.6.0)
Live AI on every screen frame is too heavy for a mid-range phone, but one frame is fine. With the screen effect ON, open the bubble panel and tap **✨ AI frame**:
1. The current screen is grabbed exactly as it is (no effects), the live effect pauses and the picture freezes.
2. **Drag over an area** to enhance just that part (best: the model sees real pixels, and it is much faster), or tap **Whole screen** (the frame is shrunk first so the result stays under ~16 MP). Tap the model name at the top to switch between installed models.
3. The result opens zoomable (pinch, drag, double-tap = fit). **Save** writes a PNG to Pictures/ClearOverlay. **Back** returns to the frozen frame to try another area or model; **Close** resumes the live effect.
Needs at least one downloaded AI model. Files: AiSnap.kt (viewer), GlPipeline.rawFrame(), OverlayService.startAiSnap().

## Quick profiles
Content type x strength (Light / Balanced / Strong, plus Auto in the player) x GPU budget (Performance / Balanced / Quality). Six types: **Low-res video**, **Stream / Moonlight**, **Game**, **Low-quality photo**, **HD movie**, **Anime / cartoon**. Selecting one shows a one-line description of what it is for.
- Values live in `Profiles.kt` as explicit tables (no more "one multiplier for everything"), with two flavours:
  - **Player**: cleanup (denoise / deband / AA) runs on the real source pixels before FSR 1 upscales, so it removes real blocks.
  - **Screen overlay**: the capture already contains the stretched picture, so denoise is lower, Detail uses a wider radius, and AA is mostly off. Always Sharpen mode (the capture stays full size).
- **Strength** = how much help the picture needs. **GPU budget** = how much work per frame (like DLSS):
  - Performance: upscale + sharpen only. Detail / denoise / deband / Edge Smooth off, FXAA stays Fast; in the player the hardware bilinear upscale replaces FSR 1. Cheapest.
  - Balanced: the tables as designed.
  - Quality: FXAA Fast becomes FXAA Quality, and the player uses FSR 1 from 1.02x enlargement instead of 1.15x. A modest step: the app has no heavier algorithm to switch on.
- Game: sharpen + FXAA only, no cleanup passes (cheapest, lowest latency, HUD text stays crisp). Light uses FXAA Fast.
- HD movie: almost transparent. No denoise (it would erase film grain), light deband only.
- Anime: strongest deband, clean flat areas, Edge Smooth on line art (player only).
- In the player FSR 1 is used only when the picture is enlarged more than 1.15x; at about 1:1 plain RCAS is used. Auto picks the strength from the enlargement (<1.2x light, <2.2x balanced, else strong).
- They are starting points derived from what each shader does, not measured optima: use FX + Zoom to judge and fine-tune. Touching any slider switches to custom.

## Build
Android Studio: open the folder, Build > Build APK(s).
GitHub Actions: put ClearOverlay.zip and .github/workflows/build.yml in a repo (workflow unzips it).

## Troubleshooting
- Image repeats like a tunnel / goes black: the overlay could not be hidden from its own capture.
- Touches do not reach the app below: pass-through failed on your ROM.
- A toast with a shader/GL message: send it. Logs: `adb logcat -s CRSC`

## Files
- Shaders.kt: FSR1 / SGSR1 / RCAS (GLSL ES 3.0). GlPipeline.kt: the passes.
- Enhance.kt: Smart fix. AiSr.kt: offline AI tiles (LiteRT). GlPipeline.snapshot(): offscreen render for Save.
- OverlayService.kt: capture + overlay. Bubble.kt: floating bubble + panel. Win.kt: hidden-API tricks.

## 3.23.0
- New "Edit video" screen (main screen): cut a part (from – to), mute the sound, turn the picture. No re-encoding; saved to Movies/ClearOverlay.
- CRSC upscaler: Lanczos + edge refine pass ("CRSC Edge").
- Temporal denoise option (previous frames) for video export and the player; included in the full-auto mode.
- Better frame-generation interpolation; CRSC listed before Raw/Fast.
- Not compiled or tested in this environment.

## 3.24.0
- "Watch now" (stream) is now like a video site: the player shows the whole timeline; only the part around the spot you watch is prepared (the "ahead" setting). Drag the bar to any minute: that spot is prepared and plays after a short wait; pieces far from the viewer (behind or ahead) are deleted.
- Stream worker: jump requests, no double work on pieces that already exist, history reset after a jump (no blending across a cut), fixed a counter bug that could hide new pieces after old ones were deleted.
- Not compiled or tested in this environment.

## 3.25.0
- New logo look: pure white pixel squares with soft shadows, 3D "+" (depth, shadow, light edge) in the app header, bubble and launcher icon.
- Share: player (top bar), library (selection bar) and the finished upscale result open the system share sheet.
- Manga archives: pictures in sub-folders named cover / variant / extra / bonus go after the real pages; the failure message now shows the error type.
- Not compiled or tested in this environment.

## 3.26.0
- Player top bar: buttons shrink on narrow (portrait) screens so ⚙ and ⋮ stay visible; Share moved into the ⋮ menu.
- FG / Temporal / quality / multiplier rows in the player panel are now scrolling chips like the rest of the app (the chosen one is highlighted).
- Orientation: photos and videos are fully separate (the old shared setting is no longer used). Panel size is re-applied when the media kind changes.
- CRSC upscaler rebuilt: edge-directed Lanczos (structure tensor, 6x6 taps stretched along edges) + edge smoothing + edge steepening + RCAS. Fast stays the plain bilinear + RCAS mode.
- Manga archives with several book folders: choose which book to read (or all pages); cover/extra folders go last.
- Frame generation: motion search runs on a copy at most 960 px wide (much less GPU work at 1440p/4K).
- Logo: glossy tile, deeper gradient.
- Not compiled or tested in this environment.

## 3.26.1
- Player panel: the panel size row is now at the top; Temporal and Frame generation have their own sections with the same label style as the rest.

## 3.26.2
- Temporal clean-up was skipped in Raw mode and when a fixed output size was chosen; it now runs before every output path. Stronger blend (light 50 %, strong 78 %) so the difference is visible.

## 3.27.0
- CRSC: smoothing only on clear edges (texture stays crisp), stronger edge steepening, sharper across-edge kernel, two RCAS passes (three with Boost).
- Frame generation: light mode used 8-px steps and missed small motions (it behaved like frame doubling); all levels now search with 4-px steps and finish with a 1-px refinement.

## 3.28.0
- CRSC: new scale-aware finishing sharpen (unsharp mask whose radius follows the enlargement factor; acts on mid-contrast detail, spares flat areas and strong edges, clamped to the local range) before RCAS. Strength follows the Sharpness slider. RCAS is back to one pass (two with Boost).

## 3.28.1
- Logo: colours swapped — the "+" is now white (3D, soft violet depth) and the pixel squares carry the cyan → violet gradient.

## 3.28.2
- Manga: a page that cannot be read the normal way is now read by scanning the archive from the start (odd directories / name encodings); decode errors are shown (once) instead of leaving a blank page; a failed opening shows a dialog with the error and a Copy button.

## 3.28.3
- Manga archives: files without a known picture extension are recognised by their first bytes (JPEG / PNG / GIF / WebP / BMP / AVIF / HEIC), in both the normal and the streaming reader. An empty RAR now reports "no pictures" instead of a blank "No pages found".

## 3.28.4
- Manga: the "no pictures" message lists up to 10 file paths from inside the archive, so the real structure can be seen.

## 3.29.0
- Offline AI for video: the levels now get faster as they get lighter (Light used a bigger input picture than Medium, which made it slower). Input heights: Very light 144, Light 240, Medium 288, Heavy 216 px.
- New "Very light" level and an "Auto" choice: Auto picks the best level that should finish in about 20 minutes (using the saved speed test, the chosen time range and the frame count) and halves the frames if needed.

## 3.29.1
- Export progress: the video length ("x of y", percentage, time left) now comes from the last picture of the video track instead of the stored duration, which is wrong in some files (cut / re-muxed by messengers).

## 3.30.0
- CRSC Edge rebuilt on EASU + edge steepening + scale-aware sharpen (lighter, cleaner).
- Temporal rewritten with neighbourhood clamping (less ghosting, better quality).
- FG: new "very light" quality level.
- Manga: RAR5 (stored) archives named .cbz/.cbr now open; clearer message for compressed RAR5.
- Light theme: bubble settings text now readable.
- "Keep this much" chips only shown for Watch-now streaming.
- Library: pinch zoom on folders no longer crashes / overlaps tiles.

## 3.31.0
- Edit video: new output modes (video / audio only .m4a / single frame JPG), speed change (0.5×–8×, no sound), split into parts every N minutes.
- Launcher icon redesigned: clean gradient ring with a rounded white plus.

## 3.31.1
- In-app logo (LogoView) now matches the launcher icon.

## 3.31.2
- Temporal: only low frequencies averaged over time, moving areas untouched (no softening / odd motion).
- CRSC Edge: removed edge steepening (looked artificial/layered), gentler smoothing and sharpening.

## 3.32.0
- CRSC rebuilt: EASU + iterative back-projection (shrink, compare with the source, add the difference back, range-limited). Measured offline in a WebGL harness: +0.6 dB PSNR and crisper lines vs FSR 1; no artificial edge steepening.
- Temporal: per-pixel recursive filter with motion-compensated history clamped to the neighbourhood and an exponential similarity weight (offline test: +3.5..+5.9 dB on noisy clips, static and panning).
