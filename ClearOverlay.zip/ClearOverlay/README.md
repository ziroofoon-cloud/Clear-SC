# +CRSC 2.6.0

Tiny Android app. Captures the screen, sharpens / upscales every frame on the GPU (FSR 1, SGSR 1,
or plain bilinear) and shows it in a touch-transparent full-screen overlay. Android 12+ (minSdk 31).
UI is in English or Persian depending on the device's system language (res/values + res/values-fa).

## Use
1. Start -> allow "Display over other apps" -> allow screen capture.
2. A floating bubble appears. Tap = effect on/off. Hold = settings panel. Drag = move.
3. Modes: Sharpen (RCAS, full resolution) / FSR 1 / SGSR 1 / Fast (hardware bilinear, cheapest,
   best for very weak GPUs). "Boost" adds a second sharpening pass.
4. Render resolution: pick 1080p / 1440p / 4K to render at that height-class and upscale back to
   the panel's real resolution, or "Custom" for the raw percentage slider. A preset above the panel's own
   resolution (e.g. 1440p on a 1080p phone) is allowed: the frame is captured bigger, sharpened, then
   shrunk back to the panel with a 4-tap filter (supersampling). Custom slider goes 33-200%.
5. Vivid colors: optional saturation + contrast lift applied after upscaling (off by default),
   similar in spirit to a video player's "enhance" filter.
6. Bubble size: slider to resize the floating bubble, applied live.
7. Auto-hide (on by default): after ~2.5s idle, the bubble dims and slides ~37% of its own size
   past the screen edge it is snapped to. Any touch instantly brings it back; that first touch
   only wakes it, it does not also toggle the effect.

## Build
Android Studio: open the folder, Build > Build APK(s).
GitHub Actions: put ClearOverlay.zip and .github/workflows/build.yml in a repo (workflow unzips it).

## Troubleshooting
- Image repeats like a tunnel / goes black: the overlay could not be hidden from its own capture.
- Touches do not reach the app below: pass-through failed on your ROM.
- A toast with a shader/GL message: send it. Logs: `adb logcat -s CRSC`

## Files
- Shaders.kt: FSR1 / SGSR1 / RCAS (GLSL ES 3.0). GlPipeline.kt: the passes.
- OverlayService.kt: capture + overlay. Bubble.kt: floating bubble + panel. Win.kt: hidden-API tricks.
