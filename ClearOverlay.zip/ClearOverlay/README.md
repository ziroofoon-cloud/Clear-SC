# +CRSC 3.8.0

Tiny Android app. Captures the screen, sharpens / upscales every frame on the GPU (FSR 1, SGSR 1,
or plain bilinear) and shows it in a touch-transparent full-screen overlay. Android 12+ (minSdk 31).
UI is in English or Persian: pick System / English / فارسی on the main screen (res/values + res/values-fa).

## Use
1. Start -> allow "Display over other apps" -> allow screen capture.
2. A floating bubble appears. Tap = effect on/off. Hold = settings panel. Drag = move.
3. Modes: Sharpen (RCAS, full resolution) / FSR 1 / SGSR 1 / Fast (hardware bilinear, cheapest,
   best for very weak GPUs). "Boost" adds a second sharpening pass.
4. Render resolution: pick 1080p / 1440p / 4K to render at that height-class and upscale back to
   the panel's real resolution, or "Custom" for the raw percentage slider. A preset above the panel's own
   resolution (e.g. 1440p on a 1080p phone) is allowed: the frame is captured bigger, sharpened, then
   shrunk back to the panel with a 4-tap filter (supersampling). Custom slider goes 33-200%. In Sharpen mode only values above 100% apply (it never renders below full resolution).
5. Vivid colors: optional saturation + contrast lift applied after upscaling (off by default),
   similar in spirit to a video player's "enhance" filter.
6. Layer opacity (screen overlay panel): how much of the processed layer shows over the real screen (100% = fully processed, lower = blended with the original, a softer effect; changes apply live and are part of saved profiles).
7. Bubble size: slider to resize the floating bubble, applied live.
7. Auto-hide (on by default): after ~2.5s idle, the bubble dims and slides ~37% of its own size
   past the screen edge it is snapped to. The idle delay is adjustable (1-30 s) in the panel. Push the bubble past a side edge and release to put it to sleep instantly. Any touch instantly brings it back; that first touch
   only wakes it, it does not also toggle the effect.

## Library: your own folders and categories (3.8.0)
The Library (main screen > "Library: videos, photos, manga") lists every video and photo on the phone, grouped by folder, without picking files one by one.
- **Add a folder by hand** (＋📁 at the top, or the "Add a folder…" tile): for a folder the phone's media index does not list. Pick it once; sub-folders are included, and the access is remembered. Hand-added folders are marked 📌 and work in Videos, Photos and Manga. Long-press one to remove it from the library (nothing is deleted from the phone). 🔄 scans hand-added folders again.
- **Categories**: "⭐ Favorites" plus any you make (Videos and Photos tabs). Long-press an item to select (tap more to add to the selection), then **★** (toggle favorite), **Add to…** (pick or create a category), **All**, **✕**. Inside a category the selection bar also has **Remove**. Long-press a folder to add everything in it to a category; long-press a category to rename or delete it. Favorites show a ★ on their thumbnail.
- Opening a category plays it as a playlist, like a folder.

## Two ways to use the effects
1. **Whole screen** (bubble): captures the screen and processes it, so it works over any app / video. A full-screen layer, so it can never be as sharp as the real pixels.
2. **Inside the player** ("Video & photo player", or "Open with" on any video / photo / link): the file is decoded here and the effects are applied ONCE directly to the video frames - no screen capture, better quality, a 360p file is upscaled from its real pixels.
While the player is in front the screen effect is paused automatically (switch in the player's settings), so the picture is never processed twice; it is restored when you leave the player.

## Video & photo player
Pipeline: denoise / deband / anti-aliasing -> FSR 1 / SGSR 1 / Fast upscale -> sharpen -> Vivid.
- Engine: Media3 ExoPlayer. Local files, direct links (http/https), HLS (.m3u8), DASH (.mpd); mp4/mkv/webm...
- Top bar: **FX** = effects on/off (compare with the original picture), **rotation** (auto by video / landscape / portrait / follow phone), settings, menu.
- **Zoom**: pinch with two fingers (up to 12x) or tap the zoom button (1x / 2x / 4x / 8x). Zoomed in, one finger pans. The crop is taken from the real source pixels and goes through the whole pipeline, so you can switch FX on/off and compare the result at pixel level.
- Settings panel: effects on/off, "tap = play/pause" on/off (off = a tap only shows/hides the controls), pause screen effect while the player is open, plus all the picture sliders. While a slider is held the panel becomes almost transparent so the picture can be judged; it also closes itself after ~7 s idle (switch: "Fade the panel while adjusting"). In landscape it is a narrow column on the right.
- Subtitles: embedded tracks (CC button) or an external .srt/.vtt/.ass file (menu > Add subtitle file; non-UTF-8 files such as Windows-1256 Persian are converted automatically). Size adjustable in the menu.
- Audio track picker, speed 0.5x-2x, resume position, fit/fill picture.
- Gestures: single tap = play/pause (switchable), double tap left/right = -/+10 s, double tap centre = play/pause, horizontal drag = seek, vertical drag on the left = brightness, on the right = volume, long press = 2x speed while held.
- Photos are capped at 4096 px on the long side.
- Black picture + sound only (fixed in 3.2.0): the picture view used to be created only after the decoder reported a size, which it does not do before it has a surface. The view is now created from the track format, with a 1.5 s fallback.

## Photo tools (3.5.0)
Open a photo in the player; the bottom bar shows three buttons:
- **Enhance**: *Smart fix* (instant, no model: white balance + levels + shadow lift, measured from the photo's own histogram; does nothing if the photo is already balanced) or *AI upscale x4* (offline Real-ESRGAN General x4v3 through LiteRT / TensorFlow Lite on the CPU). Several models can be kept: the built-in one plus any .tflite you add by hand (Enhance > "AI models" > add from file or from a direct link; choose the active one there, remove added ones). No model is bundled in the APK or the zip any more: open Enhance > "AI models" > "Recommended models" and tap one to download it (Real-ESRGAN General x4v3, XLSR, QuickSRNet, SESR-M5). To bundle your own anyway, put it at app/src/main/assets/models/sr.tflite. The photo is cut into overlapping 128 px tiles; progress is shown, Back cancels. Input is limited to 1024 px on the long side so the result stays within 4096 px. Expect tens of seconds for a small photo and a few minutes for a 1024 px one on a mid-range phone.
- **Save**: renders the photo through the whole effect pipeline offscreen at full size (or 2x) and writes JPEG / PNG to Pictures/ClearOverlay (MediaStore, no storage permission). What you see (including the FX on/off state) is what is saved.
- **Original**: back to the decoded file.
- The rotation button now has 5 states: auto, landscape, portrait, follow phone, **locked** (keeps the current orientation). The icon shows the state.

## Updating over an old install
Every build is signed with the same fixed key (app/crsc.keystore, debug and release) and versionCode is the build time in minutes, so a new build installs over the old one as an update. A build signed with a different key (every build before 3.5.0) cannot be updated: uninstall it once, then install 3.5.0; from then on updates work. Keep app/crsc.keystore in your repo/zip - a different key breaks updates again.

## My profiles (3.6.0)
The first row of the settings panel (main screen, bubble panel and player panel all share it). Tune the sliders by hand, tap **＋ Save**, give it a name: every picture setting (mode, sharpness, detail, denoise, deband, anti-aliasing, render scale, vivid, boost) is stored. Tap a saved profile to get exactly those values back; long-press it to update it with the current settings or delete it.
- Quick profiles never touch saved ones. The profile you loaded stays highlighted until you change anything by hand.
- Safety net: when a quick profile is about to replace hand-made settings, the app copies them into **↩ Before quick profile** first, so one tap brings them back.
- Bubble settings (size, auto-hide) are not part of a profile.

## More AI models (3.6.0)
Enhance > "AI models" > **Recommended models**: one tap downloads, unpacks (Qualcomm ships .zip files) and selects a model. All run offline on the CPU, tile by tile; the upscale factor (x2 / x3 / x4) is read from the model itself.
| Model | Size | Notes |
|---|---|---|
| Real-ESRGAN General x4v3 | ~5 MB | best detail, slowest |
| XLSR | ~115 KB | fastest, softest |
| QuickSRNet Small / Medium / Large | 0.1 - 0.4 MB | light; Medium is a good first pick for photos |
| SESR-M5 | ~1.3 MB | better quality, slower than QuickSRNet |
Only **float** .tflite models work (not the w8a8 ones). Direct links (zip or plain .tflite) can also be pasted under "Add model from link", or a downloaded file picked with "Add model from file".
AI is photo-only: running a neural network on every video frame is far beyond a mid-range phone (about 2-3 frames per second at best), so video keeps using the GPU shaders (FSR 1 / SGSR 1 / denoise / deband).

## 3.7.0: library, playlist, panel lock, Auto
- **Library** (main screen, first button; also ⋮ > Library in the player): your videos, photos and manga straight from the phone's media index, no file manager. Tabs Videos / Photos / Manga, folders, thumbnails, duration badges. First run asks for photo/video access (READ_MEDIA_* / READ_EXTERNAL_STORAGE on Android 12). "📂" = the old picker / link entry.
- **Playlist**: opening an item from the library (or "Open with" on a media-store file) builds a playlist of the SAME type in that folder: photos swipe left / right (not when zoomed), videos use ⏮ ⏭ and can auto-play the next one ("Play the next video automatically"). Videos and photos are never mixed.
- **Manga**: any image folder (Manga tab) or a .cbz / .zip opens in the reader: Scroll (webtoon) or Pages (pinch zoom, swipe or tap edges, right-to-left switch). The last page is remembered. The reader has no effects pipeline.
- **Player panel**: 🔒 / 🔓 next to its title: unlocked, drag the panel by the title to move it away from the picture. New settings: panel opacity while adjusting (100% = never dims), "close the panel by itself when idle" on/off.
- **Auto** (top of every settings panel): picks quick profile, strength, GPU budget, anti-aliasing, mode and AI model by itself. Player video: content type from resolution / frame rate / stream, strength from the enlargement, budget from the pixel rate and lowered when frames drop. Photo: strength from size, Quality budget, AI model by size (small = best model; a very small photo is AI-upscaled automatically). Screen overlay: light all-round profile, then a ladder Fast 80% > Performance > Balanced > Quality moved by the measured time per frame. Touch any control and Auto switches off. These are rules of thumb, not measured on a device.

## AI still frame (3.6.0)
Live AI on every screen frame is too heavy for a mid-range phone, but one frame is fine. With the screen effect ON, open the bubble panel and tap **✨ AI frame**:
1. The current screen is grabbed exactly as it is (no effects), the live effect pauses and the picture freezes.
2. **Drag over an area** to enhance just that part (best: the model sees real pixels, and it is much faster), or tap **Whole screen** (the frame is shrunk first so the result stays under ~16 MP). Tap the model name at the top to switch between installed models.
3. The result opens zoomable (pinch, drag, double-tap = fit). **Save** writes a PNG to Pictures/ClearOverlay. **Back** returns to the frozen frame to try another area or model; **Close** resumes the live effect.
Needs at least one downloaded AI model. Files: AiSnap.kt (viewer), GlPipeline.rawFrame(), OverlayService.startAiSnap().

## Quick profiles
Content type x strength (Light / Balanced / Strong, plus Auto in the player) x GPU budget (Performance / Balanced / Quality). Six types: **Low-res video**, **Stream / Moonlight**, **Game**, **Low-quality photo**, **HD movie**, **Anime / cartoon**. Selecting one shows a one-line description of what it is for.
- Values live in `Profiles.kt` as explicit tables (no more "one multiplier for everything"), with two flavours:
  - **Player**: cleanup (denoise / deband / AA) runs on the real source pixels before FSR 1 upscales, so it removes real blocks.
  - **Screen overlay**: the capture already contains the stretched picture, so denoise is lower, Detail uses a wider radius, and AA is mostly off. Always Sharpen mode (the capture stays full size).
- **Strength** = how much help the picture needs. **GPU budget** = how much work per frame (like DLSS):
  - Performance: upscale + sharpen only. Detail / denoise / deband / Edge Smooth off, FXAA stays Fast; in the player the hardware bilinear upscale replaces FSR 1. Cheapest.
  - Balanced: the tables as designed.
  - Quality: FXAA Fast becomes FXAA Quality, and the player uses FSR 1 from 1.02x enlargement instead of 1.15x. A modest step: the app has no heavier algorithm to switch on.
- Game: sharpen + FXAA only, no cleanup passes (cheapest, lowest latency, HUD text stays crisp). Light uses FXAA Fast.
- HD movie: almost transparent. No denoise (it would erase film grain), light deband only.
- Anime: strongest deband, clean flat areas, Edge Smooth on line art (player only).
- In the player FSR 1 is used only when the picture is enlarged more than 1.15x; at about 1:1 plain RCAS is used. Auto picks the strength from the enlargement (<1.2x light, <2.2x balanced, else strong).
- They are starting points derived from what each shader does, not measured optima: use FX + Zoom to judge and fine-tune. Touching any slider switches to custom.

## Build
Android Studio: open the folder, Build > Build APK(s).
GitHub Actions: put ClearOverlay.zip and .github/workflows/build.yml in a repo (workflow unzips it).

## Troubleshooting
- Image repeats like a tunnel / goes black: the overlay could not be hidden from its own capture.
- Touches do not reach the app below: pass-through failed on your ROM.
- A toast with a shader/GL message: send it. Logs: `adb logcat -s CRSC`

## Files
- Shaders.kt: FSR1 / SGSR1 / RCAS (GLSL ES 3.0). GlPipeline.kt: the passes.
- Enhance.kt: Smart fix. AiSr.kt: offline AI tiles (LiteRT). GlPipeline.snapshot(): offscreen render for Save.
- OverlayService.kt: capture + overlay. Bubble.kt: floating bubble + panel. Win.kt: hidden-API tricks.
