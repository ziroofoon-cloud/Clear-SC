# +CRSC 3.5.0

Tiny Android app. Captures the screen, sharpens / upscales every frame on the GPU (FSR 1, SGSR 1,
or plain bilinear) and shows it in a touch-transparent full-screen overlay. Android 12+ (minSdk 31).
UI is in English or Persian: pick System / English / فارسی on the main screen (res/values + res/values-fa).

## Use
1. Start -> allow "Display over other apps" -> allow screen capture.
2. A floating bubble appears. Tap = effect on/off. Hold = settings panel. Drag = move.
3. Modes: Sharpen (RCAS, full resolution) / FSR 1 / SGSR 1 / Fast (hardware bilinear, cheapest,
   best for very weak GPUs). "Boost" adds a second sharpening pass.
4. Render resolution: pick 1080p / 1440p / 4K to render at that height-class and upscale back to
   the panel's real resolution, or "Custom" for the raw percentage slider. A preset above the panel's own
   resolution (e.g. 1440p on a 1080p phone) is allowed: the frame is captured bigger, sharpened, then
   shrunk back to the panel with a 4-tap filter (supersampling). Custom slider goes 33-200%. In Sharpen mode only values above 100% apply (it never renders below full resolution).
5. Vivid colors: optional saturation + contrast lift applied after upscaling (off by default),
   similar in spirit to a video player's "enhance" filter.
6. Bubble size: slider to resize the floating bubble, applied live.
7. Auto-hide (on by default): after ~2.5s idle, the bubble dims and slides ~37% of its own size
   past the screen edge it is snapped to. The idle delay is adjustable (1-30 s) in the panel. Push the bubble past a side edge and release to put it to sleep instantly. Any touch instantly brings it back; that first touch
   only wakes it, it does not also toggle the effect.

## Two ways to use the effects
1. **Whole screen** (bubble): captures the screen and processes it, so it works over any app / video. A full-screen layer, so it can never be as sharp as the real pixels.
2. **Inside the player** ("Video & photo player", or "Open with" on any video / photo / link): the file is decoded here and the effects are applied ONCE directly to the video frames - no screen capture, better quality, a 360p file is upscaled from its real pixels.
While the player is in front the screen effect is paused automatically (switch in the player's settings), so the picture is never processed twice; it is restored when you leave the player.

## Video & photo player
Pipeline: denoise / deband / anti-aliasing -> FSR 1 / SGSR 1 / Fast upscale -> sharpen -> Vivid.
- Engine: Media3 ExoPlayer. Local files, direct links (http/https), HLS (.m3u8), DASH (.mpd); mp4/mkv/webm...
- Top bar: **FX** = effects on/off (compare with the original picture), **rotation** (auto by video / landscape / portrait / follow phone), settings, menu.
- **Zoom**: pinch with two fingers (up to 12x) or tap the zoom button (1x / 2x / 4x / 8x). Zoomed in, one finger pans. The crop is taken from the real source pixels and goes through the whole pipeline, so you can switch FX on/off and compare the result at pixel level.
- Settings panel: effects on/off, "tap = play/pause" on/off (off = a tap only shows/hides the controls), pause screen effect while the player is open, plus all the picture sliders. While a slider is held the panel becomes almost transparent so the picture can be judged; it also closes itself after ~7 s idle (switch: "Fade the panel while adjusting"). In landscape it is a narrow column on the right.
- Subtitles: embedded tracks (CC button) or an external .srt/.vtt/.ass file (menu > Add subtitle file; non-UTF-8 files such as Windows-1256 Persian are converted automatically). Size adjustable in the menu.
- Audio track picker, speed 0.5x-2x, resume position, fit/fill picture.
- Gestures: single tap = play/pause (switchable), double tap left/right = -/+10 s, double tap centre = play/pause, horizontal drag = seek, vertical drag on the left = brightness, on the right = volume, long press = 2x speed while held.
- Photos are capped at 4096 px on the long side.
- Black picture + sound only (fixed in 3.2.0): the picture view used to be created only after the decoder reported a size, which it does not do before it has a surface. The view is now created from the track format, with a 1.5 s fallback.

## Photo tools (3.5.0)
Open a photo in the player; the bottom bar shows three buttons:
- **Enhance**: *Smart fix* (instant, no model: white balance + levels + shadow lift, measured from the photo's own histogram; does nothing if the photo is already balanced) or *AI upscale x4* (offline Real-ESRGAN General x4v3 through LiteRT / TensorFlow Lite on the CPU). The ~5 MB model is bundled in the APK: the Gradle task downloadAiModel fetches it while building (needs internet only on the build machine). To bundle your own file put it at app/src/main/assets/models/sr.tflite. If the build had no internet the app falls back to a one-time download / "Pick file". The photo is cut into overlapping 128 px tiles; progress is shown, Back cancels. Input is limited to 1024 px on the long side so the result stays within 4096 px. Expect tens of seconds for a small photo and a few minutes for a 1024 px one on a mid-range phone.
- **Save**: renders the photo through the whole effect pipeline offscreen at full size (or 2x) and writes JPEG / PNG to Pictures/ClearOverlay (MediaStore, no storage permission). What you see (including the FX on/off state) is what is saved.
- **Original**: back to the decoded file.
- The rotation button now has 5 states: auto, landscape, portrait, follow phone, **locked** (keeps the current orientation). The icon shows the state.

## Updating over an old install
Every build is signed with the same fixed key (app/crsc.keystore, debug and release) and versionCode is the build time in minutes, so a new build installs over the old one as an update. A build signed with a different key (every build before 3.5.0) cannot be updated: uninstall it once, then install 3.5.0; from then on updates work. Keep app/crsc.keystore in your repo/zip - a different key breaks updates again.

## Quick profiles
Content type x strength (Light / Balanced / Strong, plus Auto in the player) x GPU budget (Performance / Balanced / Quality). Six types: **Low-res video**, **Stream / Moonlight**, **Game**, **Low-quality photo**, **HD movie**, **Anime / cartoon**. Selecting one shows a one-line description of what it is for.
- Values live in `Profiles.kt` as explicit tables (no more "one multiplier for everything"), with two flavours:
  - **Player**: cleanup (denoise / deband / AA) runs on the real source pixels before FSR 1 upscales, so it removes real blocks.
  - **Screen overlay**: the capture already contains the stretched picture, so denoise is lower, Detail uses a wider radius, and AA is mostly off. Always Sharpen mode (the capture stays full size).
- **Strength** = how much help the picture needs. **GPU budget** = how much work per frame (like DLSS):
  - Performance: upscale + sharpen only. Detail / denoise / deband / Edge Smooth off, FXAA stays Fast; in the player the hardware bilinear upscale replaces FSR 1. Cheapest.
  - Balanced: the tables as designed.
  - Quality: FXAA Fast becomes FXAA Quality, and the player uses FSR 1 from 1.02x enlargement instead of 1.15x. A modest step: the app has no heavier algorithm to switch on.
- Game: sharpen + FXAA only, no cleanup passes (cheapest, lowest latency, HUD text stays crisp). Light uses FXAA Fast.
- HD movie: almost transparent. No denoise (it would erase film grain), light deband only.
- Anime: strongest deband, clean flat areas, Edge Smooth on line art (player only).
- In the player FSR 1 is used only when the picture is enlarged more than 1.15x; at about 1:1 plain RCAS is used. Auto picks the strength from the enlargement (<1.2x light, <2.2x balanced, else strong).
- They are starting points derived from what each shader does, not measured optima: use FX + Zoom to judge and fine-tune. Touching any slider switches to custom.

## Build
Android Studio: open the folder, Build > Build APK(s).
GitHub Actions: put ClearOverlay.zip and .github/workflows/build.yml in a repo (workflow unzips it).

## Troubleshooting
- Image repeats like a tunnel / goes black: the overlay could not be hidden from its own capture.
- Touches do not reach the app below: pass-through failed on your ROM.
- A toast with a shader/GL message: send it. Logs: `adb logcat -s CRSC`

## Files
- Shaders.kt: FSR1 / SGSR1 / RCAS (GLSL ES 3.0). GlPipeline.kt: the passes.
- Enhance.kt: Smart fix. AiSr.kt: offline AI tiles (LiteRT). GlPipeline.snapshot(): offscreen render for Save.
- OverlayService.kt: capture + overlay. Bubble.kt: floating bubble + panel. Win.kt: hidden-API tricks.
