# +CRSC 3.99.45

Tiny Android app. Captures the screen, sharpens / upscales every frame on the GPU (FSR 1, SGSR 1,
or plain bilinear) and shows it in a touch-transparent full-screen overlay. Android 12+ (minSdk 31).
UI is in English or Persian: pick System / English / فارسی on the main screen (res/values + res/values-fa).

## 3.99.46 - Aura: the same picture for less work
- **Aura (NIS Lite, Standard and Soft)** now skips the work that cannot change its result, and is otherwise the same shader with the same numbers: (1) the edge direction and the two extra cubics along the edge are worked out only where an edge exists (where the edge weight is 0 the result is the plain cubic anyway); (2) the Gaussian reference, the push and the cleaning only where the gate or the Soft cleaning is above 0 (flat and noisy areas are left alone by the shader already); (3) the cubic of the pixel's own cell is a plain polynomial (the general weights give the same numbers there); (4) the Gaussian weights need 4 `exp` instead of 8 (`exp(-k(u+1)^2) = a c / b`, `exp(-k(u-1)^2) = a c b`, `exp(-k(u-2)^2) = a c^4 b^2`); (5) the 4 columns and 4 rows of the window are clamped once instead of 16 coordinate pairs. The colour sample stays outside every branch (it needs derivatives).
- **Measured with the app's own shaders (software OpenGL ES 3.2, 8 cases x 16 settings: x1.5 / x2 / x3 / x4, Standard and Soft, 4 photos, a flat and a noisy flat picture, horizontal / vertical lines, diagonal stripes): the largest difference from the old shader is 1/255 on a handful of pixels (differing pixels round to 0.00 %), i.e. rounding.** Nothing about the look changes.
- **Honest size of the gain:** on the test machine's CPU driver the draw takes 99 % (busy picture) down to 84 % (calm picture, blurred sky) of the old time. Where the picture is calm (sky, walls, blurred backgrounds, dark areas) more work is skipped; on busy pictures hardly any. A phone GPU skips a branch only when a whole group of neighbouring pixels takes it, so expect a similar picture there, not more. The reason it is not more: 16 texture reads per pixel are about 42 % of the time (profiled stage by stage: reads 42 ms, edge tensor +3, cubic and edge cleaning +24, range and gate +15, Gaussian and push +13 of about 100 ms); the arithmetic that is left cannot be dropped without changing the picture.
- **The bigger step (not done here, it needs OpenGL ES 3.1 and a fall-back):** one small pass that writes the luma of the source picture as two 8-bit parts, then `textureGather` for the window: 8 reads instead of 16 and no luma maths per read. Not exact to the last bit (16-bit luma instead of float, about 0.05/255), and it needs a new render target, a new program and the old shader as a fall-back on a phone without ES 3.1. Say "continue" if you want it.
- Not compiled or run on a phone here (no Kotlin compiler; the shader was compiled and run offscreen).

## 3.99.45 - CRSC Edge: lighter, the same picture
No formula, threshold, weight or level of CRSC Edge was touched (all six levels, Exact mode on or off, the flat-area shortcuts: the result is the same as in 3.99.44). What changed is how the passes read and write their pictures:
- **The GPU is told not to load the old picture of a target before a pass that redraws all of it** (`GlPipeline.discardOld` = `glInvalidateFramebuffer` after `bindOut`, for the 6 targets of one CRSC Edge frame: enlargement, shrunk copy, back-projection, edge smoothing, detail boost, edge steepening). On a tile-based GPU (nearly every phone) a pass otherwise starts by reading the previous contents of the target from memory; a full-screen pass does not need them. This is where most of the saving should be (memory traffic of up to 6 full-size pictures per frame), but it is a GPU effect: **it cannot be seen on the test driver here**.
- **Edge smoothing and edge steepening (`EDGE_REFINE`, `EDGE_SHOCK`) read their 3x3 neighbours as plain texels** (`texelFetch` / `texelFetchOffset`, with a clamped version only for the picture border) instead of filtered samples at computed positions: the pixel and its 8 neighbours lie exactly on texel centres, so the values are the same, with less address arithmetic and no filtering unit. The two passes get a new uniform `uSize` (set in `crscEdge`).
- **Back-projection (`CRSC_BP`)**: the centre of its 3x3 range of the low-resolution picture was read twice (once for the error, once inside the loop); now once (11 reads per pixel instead of 12). The 8 others are written out by hand (no loop).
- **FSR 1 enlargement (`EASU`)**: the 12 source pixels are fetched by integer position around the pixel (what the four emulated gathers picked, without the position arithmetic and without the clamp for pixels inside the picture). EASU is also the enlargement of the FSR 1 mode, which gets the same result and the same saving.
- **Checked here:** old and new shaders compiled in a software OpenGL ES 3.2 driver and rendered over **300 cases** (picture sizes 4x3 up to 128x72 so the border path is used a lot, 5 kinds of picture incl. noise / checkerboard / stripes / gradient with random flatness in alpha, shortcut limit 0 and 0.08, back-projection at 1x / 2x / 3x, EASU at 0.6x / 1x / 1.5x / 2x / 3x): **identical in every value, all four passes (largest difference 0)**. Speed on that CPU driver: edge smoothing about 35 % less time, edge steepening about 40 % less, back-projection and EASU unchanged (a CPU is not a phone GPU; the numbers move by 10 - 20 % from run to run).
- **Not measured on a phone, Kotlin not compiled here.** If a build error shows up, send the log. If the picture of CRSC Edge looks different on your phone in any way, tell me: the first thing to try is to remove the `discardOld(...)` calls in `crscEdge` (6 lines).

## 3.99.44 - "Make settings lighter" now measures (same picture, lighter settings, even if the settings change)
- The button of 3.99.43 only removed what was identical. It is now a real search (`SmartOpt.kt`, in the **video / photo player**; other screens keep the simple version): it takes **one real frame** of the open photo or of the video at the current spot (local files, at most 1080 on the short side), renders it with your settings through the app's own GL pipeline (`MangaFx.processWith`, off screen, so the live picture is not touched) as the reference, then tries lighter variations and keeps one when its picture is close to the reference and it is really faster on this phone:
  - **a lighter upscaler** (NIS original / NIS / NIS Lite -> NIS fast -> NIS mid / SGSR -> FSR 1 -> bilinear + sharpen), each with the same sharpness and with +0.1 (a lighter one often needs a little more); must be at least 7 % faster and **at least 36 dB similar** (PSNR on brightness) to the reference;
  - **leaving an effect out** (Denoise, Deband, Detail, Clarity, anti-ringing, Boost, anti-aliasing, middle size step) when the picture stays **at least 40 dB** close;
  - **CRSC Edge one level lower** (as a mode step).
  Up to 4 rounds, every step compared with the ORIGINAL reference (small losses cannot add up). It shows the speed gain, the similarity and the list, and **applies only when you tap Apply**. The time includes a fixed part (picture upload / read-back), so the real saving of the pure effect work is larger than the percent shown.
- `MangaFx` got `crscNow` (the CRSC level for one call). `Controls.buildControls` got `optFrame`.
- Honest limits: frame generation and the temporal clean-up need several frames and are not part of the test; the numbers (36 / 40 dB, 7 %) are chosen, not tuned; a search can take up to a minute on a weak phone. Not compiled or tested on a device.

## 3.99.43 - "Make settings lighter (same picture)"
- New button in the picture controls (under Auto-lighten): goes through the chosen settings and removes only what gives the same picture: **NIS (original) -> NIS (fast)** (README 3.88.0: the same picture, largest difference 1/255, less work), **Denoise / Deband / Detail / Clarity / Anti-ringing set almost to zero** (a whole pass for nothing visible; limits 0.06 / 0.06 / 0.04 / 0.04 / 0.05) and **CRSC exact mode** (only another way to compute flat areas, used with the Lanczos / CRSC upscaler below level 5). It lists what it changed or says that nothing can be lightened; Auto is switched off when something changed. `Optimize.kt`.
- Honest limit: a setting that really changes the picture (a heavier upscaler, frame generation, temporal clean-up...) is NOT swapped, because no lighter setting gives exactly the same picture; for those, "Auto-lighten when lagging" lowers them only while the phone lags.
- Not compiled or tested on a device.

## 3.99.42 - Looks: Gaming
- New look **Gaming** (last in the list, so the saved numbers of the other looks do not change): contrast +0.14, saturation +0.16, vibrance +0.26, shadows +0.16 (nothing hides in the dark), highlights -0.06, vivid colours 0.10, clarity 0.30, brightness +0.02, no grain. Strength can be lowered like for the other looks. Not compiled or tested on a device.

## 3.99.41 - File manager: Android/data through another file app
- The system refuses to give **Android/data** and **Android/obb** to any app on many phones (Redmi Note 9 Pro: the button in the system picker cannot be used). The dialog now has a third button, **Through another app (MT Manager...)**: a file app that already has access (MT Manager shows the folder as its own storage in the system picker) can hand it over: open the menu in the picker, choose that app, open Android/data, "Use this folder". It is added like a cloud place (the same path as "Add cloud") and is browsed, copied and so on there.
- Not compiled or tested on a device, and not known to work with MT Manager: it depends on that app offering its folders to the system picker (its "document provider"). If it is not in the picker's menu, tell me; the only other way is Shizuku support.

## 3.99.40 - auto find on the network, photo direction is remembered
- **Auto find (Network screen).** When the screen opens, the phone's network is searched in the background for SMB / FTP servers; servers not saved yet are offered in a list (nothing shows if none is found). Long-press the search button, or use the extra button in the found-list, to turn it on / off (on by default).
- **Photo direction.** The landscape / portrait choice made for photos is now saved and kept next time (and between photos). Videos still follow their own shape each time; Lock and Free are unchanged.
- Not compiled and not run on a phone.

## 3.99.39 - Auto leaves Smart Fix off, rename files (music too), delete that works for every file
- **Auto never turns Smart Fix on** (it sets it off); it stays a manual choice.
- **Rename** for songs (long-press a song > Rename; the title shown in the list changes too) and for library items (select ONE file, pencil button on the bar). Works for media-store files (Android may ask permission once), files of added folders and picked documents.
- **Delete did nothing for files outside the phone's media store** (songs / videos from an added folder or picked with the file picker: "move to trash" only showed a note). Now the dialog says they are deleted for good, does it (file path, document or content uri), tells how many failed, and refreshes the list.
- Not compiled and not run on a phone.

## 3.99.38 - real percentage in the video editor, cover in the music notification
- **Video edit (cut / join / mute / speed / add sound) showed 0% until done.** That path copies the streams without re-encoding and never reported progress; it now reports the position inside each piece (with Add sound, the sound preparation is the first half). Other editors (photo, audio, GIF, re-encode export) already reported.
- **Music notification shows the song's cover** (large icon, and album art on the lock screen / media controls). It loads in the background and the notification refreshes when the cover is ready.
- Not compiled and not run on a phone.

## 3.99.37 - Artemis quick setup cards, FX settings backup, more archive types
- **Artemis quick setup** is now a list of cards: bold name, accent line with the real numbers (e.g. "1080p - 60 fps - 30 Mbps"), a "use when" hint, and three dot meters (Picture / Reaction / Network). The one in use is marked and outlined, the one suited to the phone is starred. Presets were made clearly different (Sharpest, Everyday, Fast reaction, Weak/mobile/battery, 720p+upscaler, Smooth 120, 4K); "Save battery" merged into "Weak".
- **Settings backup (FX)** card on the main screen: Save to file (system file picker, e.g. Download - survives uninstall), Load file, Share (as text). One readable JSON: all picture settings of every section, saved profiles, sound FX, stream FX. Bubble, language, theme and library are not included. Loading validates the file, keeps your existing profiles (same-named ones are replaced) and applies at once.
- File manager can extract 7z, tar, tar.gz, rar (RAR5 gives a clear message) as well as zip.
- Not compiled and not run on a phone.

## 3.99.36 - button colours, swipe songs, Artemis touchpad click
- **Button colours turning black / white.** The colour palette (`Ui`) is global and was overwritten by whichever screen or service initialised it last (a service or overlay built while another screen was open). It now follows the screen that is on top (activity lifecycle callback; the player, manga and GIF screens stay dark) and an init from a non-activity context is ignored while a screen is showing.
- **Swipe the music bar to change song.** Swipe left on the mini bar or on the cover of the full-screen player = next song, right = previous (the bar follows the finger and springs back).
- **Artemis virtual keyboard, the three Touch buttons (TP(R) / TP / TP(L)).** A cancelled touch, a quick flick of the cursor, and the touch that already pressed the held button all also sent a mouse click (the stray left click), and a release was sent without a press. Now a click is sent only for a real short tap that stayed in place and ended with the finger lifting; the held button (TP(R) / TP(L)) is released only if it was pressed.
- Not compiled and not run on a phone.

## 3.99.35 - music bar menu, manual direction, profile sub-options, load meter
- **Music bar / full-screen player: favorite and playlists.** The share icon of the bar is now a **more** menu (add to / remove from favorites, add to a playlist or a new one, share). The full-screen player has a **star** (favorite, filled when the song is a favorite) next to the more button. (`MusicQuick`, MusicLists.kt.)
- **Choose the direction by hand.** Player tools -> **Choose the direction...**: automatic / follow the phone / portrait / landscape (either end) / portrait fixed / landscape fixed / portrait upside down / landscape the other way. The "fixed" ones are saved like the Lock key; "portrait / landscape (either end)" is for the open file only, as the arrow key is.
- **Profiles and the sub-options of the upscaler (e.g. CRSC Edge quality).** The values were saved and loaded, but the rows under the mode chips (CRSC Edge quality + exact, NIS fast level, Standard / Mid / Soft variants, Crispness + its shader row) were built once and never repainted, so after loading a profile (or Auto / Reset) they still showed the old choice. They are now built again from the settings in `syncAll` (new `Rebuildable`), and the Standard / Soft / Mid variant memory is read from the mode.
- **Load of these settings** (the meter): a photo in the player was counted as a video (frame generation and temporal clean-up added to its load); NIS crispness was only counted for CRSC Edge although it runs after every upscaler; Smart Edge anti-aliasing had the weight of the lightest AA; cutting black bars was not counted. All four corrected.
- Not compiled and not run on a phone.

## 3.99.34 - Crash at start fixed
- **The app closed at once when it was opened (or when a section such as Video / Photo was entered).** Cause: the preference key `"bright"` was used for two different things in the screen section: the side of the screen the floating bubble sits on (a Boolean, from long ago) and the new brightness setting (a Float; `pk()` leaves the key unchanged in the screen section). A save wrote the Float over the Boolean, and the next start died in `getBoolean("bright")` / `getFloat("bright")` with a `ClassCastException` in `Cfg.load`; the video and photo sections copy the screen settings, so entering them did the same. An upgrade from an older version, which has the Boolean stored under that key, crashes the same way.
- **Fix:** the bubble side has its own key (`bubble_right`); `Cfg.fixBrightKeys` runs before anything is read and repairs old data (a Boolean found under `bright` / `sec_..._bright` is moved to `bubble_right` or dropped; the brightness is read only as a Float); the copy of settings into a section skips a wrong-typed brightness. No data of the user has to be deleted: installing over the old version is enough.
- **Checked in the same pass:** every preference key of the app (145) for a second value type: `bright` was the only one. All 249 formatted strings (`getString(id, args)`) against their English and Persian text (stray `%`, missing arguments, Int / Float): no problem. Every class in the manifest exists; foreground-service types have their permissions.
- Not compiled or run on a phone here (no Kotlin compiler).

## 3.99.33 - Build fix (second try)
- 3.99.32 wrote the type of `rotVerify` out, and the compiler then said `Variable 'rotVerify' must be initialized` (line 2996): a `Runnable` cannot use itself inside its own initialiser in Kotlin at all. Now the work is the function `verifyRotation()` and `private val rotVerify = Runnable { verifyRotation() }` only calls it; the function posts `rotVerify` again as before. Same behaviour, same timings (120 ms, 900 ms, at most 2 kicks).
- The repacked zips of 3.99.32 (bzip2 / deflate 9) were not the cause of that error: the build log shows the project was unpacked fine.
- Not compiled here (no Kotlin compiler).

## 3.99.32 - Build fix
- **The only compile error of the 3.99.31 build log:** `PlayerActivity.kt` line 2994, "Type checking has run into a recursive problem". `private val rotVerify = Runnable { ... ui.postDelayed(rotVerify, 900) ... }` uses itself inside its own initialiser, and Kotlin cannot infer the type of such a value. It is now `private val rotVerify: Runnable = Runnable { ... }` (same code, the type written out).
- The rest of the build went through (the streaming client module, resources, native libraries). I searched every other Kotlin file for a value that is used inside its own untyped initialiser: this was the only one.
- Not compiled here (no Kotlin compiler); the change is one declared type.

## 3.99.31 - Temporal clean-up: Strong is clearly stronger than Light
- Light and Strong did differ in the code, but only a little (blend weight 0.8 / 0.9, tolerance 0.18 / 0.24; the 3.96.5 bench measured +1.6 dB / +1.9 dB), so on a normal video hardly any difference can be seen. **Strong is now wider**: blend weight 0.93 (about 14 frames of memory instead of 10), tolerance 0.30, smoothing of still flat areas 0.5, back-off in motion 0.15, luma tolerance 0.10. **Light is unchanged.** The same shader is used by the player, Watch now and the file export.
- Not measured: these numbers are chosen, not tuned on the bench. If Strong shows a trail behind moving things, tell me and I will pull it back (the old values are in the comment in `GlPipeline.temporalStage`).
- Not compiled or tested on a device.

## 3.99.30 - lighter background work (nothing visible changes)
- Player: while the control bar is hidden the 200 ms tick no longer rewrites the time texts and the seek bar (nobody sees them; they are refreshed at once when the bar comes back). The tick still runs for the A-B repeat, Auto and the stall checks.
- Music full screen: refreshes 4 times a second only while lyrics are shown, 2.5 times a second otherwise (was 4 for everything in 3.99.22).
- The heavy picture settings are handled by **Auto-lighten** (3.98.0, off by default; switch in the picture controls): it lowers frame generation, temporal clean-up, Denoise, the upscaler... step by step only while the phone lags and brings them back afterwards, without touching the saved settings.
- Not compiled or tested on a device. Nothing else was changed on purpose: without measurements on the phone, other "speed-ups" could break something.

## 3.99.29 - second review
- **Fixed: after a subtitle-sync step the subtitles stayed switched off** (the reloaded video forgot the choice; the last added subtitle is selected again now).
- Checked again by reading: lyrics screen (variables, view switching), A-B repeat, key handling in manga, duplicate finder (cancel, symbolic links, non-local returns), space view, text on photos (coordinates, eraser), SubRip / WebVTT / ASS time shifting. Nothing else found. Not compiled or tested on a device.

## 3.99.28 - review of 3.99.21 - 3.99.27
- **Fixed: the subtitle-sync dialog showed no buttons** (a dialog with a message does not show its list): the hint is in the title now.
- Read through again, no change needed: A-B repeat, lyrics, manga keys, duplicate finder, space view, photo text, subtitle time shifting. Not compiled or tested on a device.

## 3.99.27 - Player: subtitle sync
- More menu -> **Subtitle sync** (shown when a subtitle file was added by hand): -1 / -0.5 / -0.1 / +0.1 / +0.5 / +1 s steps (up to 10 minutes) and a reset. The added subtitle files are rewritten with every time moved (SubRip, WebVTT, SSA / ASS; TTML is left as it is) in the cache and the video is prepared again at the same spot. The delay is for this video only. Subtitles inside the video file (embedded tracks) cannot be moved this way. New file `SubShift.kt`.
- Not compiled or tested on a device.

## 3.99.26 - Photo edit: text on the picture
- Pen tab: a fourth kind, **Text**. Tap where the words should go, type them (up to 4 lines), OK. The colour and the size (1-4) of the pen are used; a thin outline in the opposite shade keeps the words readable on any picture. Texts are undone / redone / cleared together with the pen strokes, are saved in the picture and are cut by the eraser like the strokes. A text cannot be moved afterwards (undo and put it again).
- Not compiled or tested on a device.

## 3.99.25 - File manager: where did the space go
- **More menu -> Where did the space go?**: measures every item of the open folder (a folder counts everything inside; any storage type that can be listed), shows them biggest first with a share bar, size and percentage; tapping a folder opens it, tapping a file selects it. Measuring can be cancelled.
- Not compiled or tested on a device. Next: Edit section.

## 3.99.24 - File manager: duplicate finder, SHA-256 in properties
- **More menu -> Find duplicate files** (phone storage, this folder and below, hidden files only when shown): same size, then the first / last 64 KB, then the whole file (SHA-256), so only truly identical files are listed (files under 4 KB and symbolic links are skipped). Groups are sorted by the space that could be freed; pick a group and tick the copies to remove (all but the first are ticked; at least one copy always stays); deleting asks first and is permanent (not the trash). New file `FmDupes.kt`.
- **Properties** of one file on the phone also shows its SHA-256 (computed in the background, to compare a download with the original).
- Not compiled or tested on a device. Space analysis (folder sizes) not done yet.

## 3.99.23 - Manga: page keys
- The reader turns pages with the **volume keys** (volume down = next, up = back; the volume bar no longer shows), Page Up / Page Down, Space and the left / right arrows of a keyboard (arrows follow the reading direction). In the long strip the same keys scroll by 85 % of the screen. Not while the picture-settings panel is open.
- Not compiled or tested on a device. Next: file manager (properties with checksum, duplicates, space analysis).

## 3.99.22 - Music: synchronised lyrics (.lrc)
- The full-screen "now playing" shows the lyrics of the song when a **.lrc file with the same name** lies next to it (or in a `Lyrics` folder beside it): the line being sung is big and in the accent colour, one line before and after in grey; the dancing bars give their place to the lyrics. Several time stamps per line, `[offset:ms]` and word stamps `<mm:ss.xx>` are understood; a file without time stamps is ignored. The song's file path comes from MediaStore (all-files access is already granted). New file `Lyrics.kt`. The screen refreshes every 250 ms (was 400).
- Not compiled or tested on a device. Next: manga, file manager.

## 3.99.21 - Player: repeat a section (A-B)
- Tools menu of the video / music player: **Repeat a section (A-B)**. Tap once at the start (A), once at the end (B): the section then repeats until the third tap switches it off (the menu line shows the times). It switches itself off when another file opens; not for Watch now pieces. The check runs on the 200 ms tick, so the jump back can be up to 0.2 s late.
- Not compiled or tested on a device. Next stages planned: music (lyrics), manga, file manager (properties, duplicates, space analysis), edit.

## 3.99.20 - Auto sets Smart fix, clarity and deinterlace too
- **Smart fix:** Auto switches it on for photos, films and clips (measured white balance / levels / shadow lift) and off for game streams, manga, animation and the screen layer.
- **Clarity:** a touch of local contrast (photo 20, HD film 12, other clips 8) when the GPU budget is Balanced or Quality; none on animation, dark or busy pictures.
- **Deinterlace:** switched on (odd lines) when the file looks interlaced: MPEG-2 video, or a TV container (.ts / .mpg / .vob) with 480 / 576 / 1080 lines at about 25-30 fps. It only touches lines where combing shows, so a wrong guess costs only a little GPU time.
- Together with what Auto already set (profile, strength, GPU budget, upscaler, anti-aliasing, size choices, CRSC options, black-bar cut, anti-ringing, temporal clean-up, live picture tuning, AI model for photos) this means Auto now leaves no picture option untouched except the colour moods (Looks, brightness, warmth, grain, vivid), which are taste, not correction.
- The live part of Auto (dark / animation / busy detection) also re-decides these when the kind of picture changes.
- Not compiled or tested on a device.

## 3.99.19 - Artemis: two upstream fixes
- Compared the embedded client (Artemis v20.2.6, still the newest stable release; the 3.0 line is experimental and rewrites the video / input code, so it was NOT merged) with the official `moonlight-noir` branch and took the two small bug fixes that apply cleanly:
  - **Picture-in-picture while the stream is on an external display** no longer tries to enter PiP (it crashed when the display was removed).
  - **Game menu from the controller's Play / Start hold** now works even when "mouse emulation" is off (the hold used to do nothing then).
- The quick setup list (3.99.9) already picks the setup from Wi-Fi speed and screen refresh rate; nothing to add there.
- Not compiled or tested on a device.

## 3.99.18 - review of 3.99.16 / 3.99.17
- **Fixed:** the "Load of these settings" details dialog crashed when the panel was the floating panel of the screen layer (no activity: the dialog had no window type). It now uses the overlay window type there.
- **Fixed:** the "Measured now" line kept showing an old number after the picture stopped (e.g. a closed video); it is shown only when the number is less than 3 seconds old.
- **Fixed:** a Look stayed marked after a profile / Auto / Reset changed the colours; the mark is now kept only while the colour settings still equal the look.
- Checked again: Java classes compile, strings en / fa equal, Kotlin parses. Not compiled as an app and not run on a phone.

## 3.99.17 - Looks (colour moods)
- New row **Looks** in the picture settings panel (before Vivid colours), with a strength slider: Cinematic, Artistic, Vivid and cheerful, Horror, Warm, Cool, Vintage, Black and white, Noir, Dreamy, Night boost, Anime / cartoon, Eye comfort (and None). A look sets only the colour sliders (brightness, contrast, saturation, vibrance, warmth, tint, shadows, highlights, vivid colours, film grain, clarity); upscaler and sharpening stay as they are. The strength scales every value, the sliders below follow and can still be changed by hand. It applies to the section in use (video, photo, manga, GIF, screen layer). The values are taste choices, not measured; tell me which look needs more or less. Not compiled or run on a phone.

## 3.99.16 - load meter, cloud apps, file manager space tools, sound output
- **Load of the picture settings** (new bar at the top of the settings panel, everywhere the panel is used): an ESTIMATE of how heavy the settings are (1.0x = FSR 1 at 1080p; Light / Medium / Heavy / Very heavy, with colour), from the upscaler, Boost, Detail, Clarity, Anti-ringing, Deinterlace, colour / tone, grain, Denoise, Deband, Anti-aliasing, Temporal and Frame generation, scaled by the size they work at (output size, source size, capture scale). Tap it for the biggest parts. Under it the **measured frame time** of the live picture is shown when something is being drawn. It refreshes by itself every 0.7 s. The weights are typical, not measured on every phone: use the bar to compare two settings on the same phone.
- **Cloud spaces:** new first entry in "Add a cloud account": **Google Drive, OneDrive, Dropbox... (through their apps)**. Google, Microsoft and Dropbox do not give an app a key to their servers without a registration, but their own apps offer their files to other apps. The system folder picker (menu, choose the cloud, "Use this folder") adds that cloud as a place: browse, open, copy to / from (also to WebDAV / NAS / the phone), new folder, rename, delete. `SafFs` got an "opaque id" mode for this (the ids of these providers are not paths: names are looked up folder by folder and the ids seen are remembered). The place can be renamed and removed like the other accounts.
- **File manager - free up space:** the home screen shows how full the phone is with a "Free up space" row (opens Free up space: videos, photos, music, comics). In a folder, More has **Biggest files here** (the 60 biggest files below the folder, any storage; tap one to jump to it selected, then delete / move it) and **Free up space**.
- **Sound output** (music player: new speaker button in the top bar; video player: tools menu): Auto (the phone decides) or the phone speaker / earpiece, wired headphones, USB audio, a named Bluetooth device, hearing aid. Saved; given to the player as its preferred device, re-given when a device connects or leaves (the earbuds come back).
- Checked (scripts): string keys en / fa equal, every `R.string` exists, Java classes compile, Kotlin parses. Not compiled as an app and not run on a phone. SAF clouds: whether a cloud lets you pick its root as a folder depends on its app version; if it refuses, pick a folder inside it.

## 3.99.15 - profiles: rename, every FX setting saved; three new picture settings
- **Rename a saved profile:** long-press a profile -> **Rename** (`UserProfiles.rename`; empty names and names of another profile are refused, the "Before quick profile" slot cannot be renamed).
- **Profiles save every FX setting.** Added to the snapshot: Smart fix, Auto crop (black bars), Smooth live, Input / Middle / Output size, frame generation (on, factor, quality), Temporal clean-up, the layer dim, and the three new settings below. Profiles saved before keep the current value of anything they do not have.
- **New picture settings** (in the colour part of the panel, next to Warmth / Saturation / Film grain; saved per section like the others, in profiles, reset by "Reset", used by the batch photo job): **Tint** (green <-> magenta), **Vibrance** (saturation that changes already strong colours less) and **Brightness**. One extra uniform `uTone2` in `COLOR_ENHANCE`; checked in the software GL harness (all zero = the picture unchanged; the six directions move the colours the right way).
- Not in this version: the three new settings are not part of the "Save as a new file" look (`Look`), only of the live player / photo / manga / batch picture.
- Not compiled and not run on a phone.

## 3.99.14 - six reported problems
- **Black buttons on the first screen.** The colours (`Ui.*`) are shared by all screens, and the video / photo / manga screens switch them to the dark set. When the first screen came back from one of them (or a rebuild of a row ran while the dark set was active) its buttons kept the wrong colours until touched. Now `MainActivity.onResume` compares the colours it was built with and recreates itself when they differ.
- **Saturation 5 saved as 4.** Slider positions were made with `.toInt()` of a float (`(0.05f + 1f) * 100f` = 104.99999 -> 104). All of them in the picture panel (Controls.kt: sharpness, detail, denoise, deband, AA strength, vivid, contrast, shadows / highlights / saturation / warmth / grain / clarity / anti-ringing, dim, and the audio panel) now round (`roundToInt`).
- **Middle / Input did nothing with "Sharpen only".** That mode skipped the Input and Middle steps. They now run when one of them is chosen, and the picture is brought back to the screen size with a bicubic filter before the sharpening.
- **AI upscale started by itself.** The automatic AI upscale of small photos is now **off by default** (new setting key `autoai2`, so an old saved "on" no longer counts); the switch "AI-upscale small photos automatically" in the Auto settings turns it on.
- **Manga page turning.** The old page slid out (empty screen), then the program waited for the new page to be decoded, then it slid in: that was the black gap. Now the old page stays until the new one is decoded, the new one appears at once with a short slide-in; two pages ahead are prepared (was one).
- **Direction / turning (video and photo).** (1) 3.98.7 / 3.98.9: the picture size is checked again after turning, and "which way is the screen" uses the whole display. (2) New: 0.9 s after a direction request the screen is checked; when a landscape-only or portrait-only mode is active and the phone is still the other way (some phones ignore a request made while turning), the request is dropped for a moment and made again, twice at most. Free / Lock are not touched by this. Could not be tested on a phone.
- Not compiled and not run on a phone.

## 3.99.13 - Photo viewer: the automatic AI upscale no longer comes back after a cancel
- **Fixed: the AI upscale of a small photo started again and again.** While Auto is on, a small photo is AI-upscaled by itself as soon as it opens (`autoAiSmall`, on by default). A cancel (Back) stopped that run, but nothing remembered it, so the next time the same photo opened (or you came back to it, or the view was rebuilt) the AI started again, and there was no switch anywhere to stop it. Now: a photo whose automatic run you cancelled is remembered (`AiSkip`, the last 300 photos, kept between runs) and is left alone; after **two** cancelled automatic runs in a row the automatic start is switched off with a message; a finished automatic run starts the count again; leaving the photo meanwhile (next / previous) does not count as a cancel. A **tap on the progress box** now cancels too (the text says "tap or Back = cancel"). New switch **AI-upscale small photos automatically** in the Auto settings of the photo viewer (turning it on forgets the skipped photos). The manual "AI" button is unchanged and always works.
- Not compiled or run on a phone here: please open a small photo with Auto on, cancel, leave and open it again (it should not start), and check the new switch.

## 3.99.12 - Manga reader: screen direction
- New row **Screen direction** in the reader's panel: Auto (follows the phone) / Portrait / Landscape / Lock (stays as it is now). The choice is saved and used the next time a comic opens. Not compiled or run on a phone.

## 3.99.11 - Video sleep timer
- New **Sleep timer** in the player's tools menu (videos): Off / 15 / 30 / 45 / 60 / 90 minutes; the video pauses when the time is up, and the menu line shows the minutes left. (The music player already had one; the same texts are used.) Not compiled or run on a phone.

## 3.99.10 - Music player: refresh button
- New refresh button in the top bar of the music screen: new or changed songs in Music, Download, Documents, Podcasts, Audiobooks, Recordings and the other top-level folders are handed to the phone's media scanner, then the list is read again (also after 8 s if the scanner does not answer for every file). Not compiled or run on a phone.

## 3.99.9 - Free up space: Music and Comics tabs, Artemis quick setup, icon fixes, review
- **Free up space now has Music and Comics tabs** next to Videos and Photos: the music of the phone (2 MB and bigger) and the comic files (.cbz / .cb7 from 1 MB, .zip / .7z from 5 MB, found through the phone's file index) are listed, tick some, pick Balanced / Small / Tiny, see the guessed result size, then shrink (music as AAC 96 / 64 / 40 kbps, comics as WebP pages in a new .cbz, as before). "Pick files by hand" still works for files that are not listed.
- **File manager button on the main screen:** the folder icon sat above the text; it is now a picture view centred next to the two text lines. The same hanging-icon fault is fixed in the rows of the file manager and of the network screen (`Icons.glyphRow`).
- **Artemis quick setup:** the list now shows the phone's Wi-Fi speed and screen refresh rate, marks the setup that suits them (★; mobile data and slow Wi-Fi get the light ones, fast Wi-Fi + 90 Hz or more the smooth one) and marks the one in use (✓). Three new setups: **Smooth 120** (1080p / 120 / 40 Mbps), **4K picture** (4K / 60 / 60 Mbps), **Save battery** (720p / 30 / 8 Mbps).
- **Fixed:** in the hidden-folder access (`SafFs`) a file written into Android/data or Android/obb was created with the type "application/octet-stream", which some storage providers answer by adding ".bin" to the name (a.mp4 -> a.mp4.bin). The real type of the name is used now.
- Checked (scripts): all 40 shaders compile (shaders unchanged), the plain-Java file-manager classes compile with javac, Kotlin syntax parses, EN / FA string keys equal, every `R.string` used exists. Not compiled as an app and not run on a phone.

## 3.99.8 - Auto-lighten: level changes only between frames
- The player's dropped-frame report and the "new video" reset came from the UI thread and changed the Auto-lighten level while the GL thread could be in the middle of a frame (a frame built from two levels). Both are now requests that the GL thread takes before the next frame (`govBump`, `govReset`). Turning the switch off now also drops the level at once.
- Static check of this version: string resources en / fa equal (1210, no duplicates, no format mismatches, no missing names), Cfg load / save keys match. Not compiled or run on a phone.

## 3.99.7 - Settings no longer jump back when another screen opens
- Edit, Edit hub, Photo edit, Export, Audio edit and Free up space used to reload the saved settings every time they were opened. Anything that was only in memory at that moment (a choice made by Auto, a Quick profile that was just applied, a slider still being moved) was thrown away, so settings seemed to "change by themselves". They now load the saved values only the first time after the app starts (`Cfg.ensureLoaded`).
- Not compiled or tested on a device.

## 3.99.6 - Numbers and times always in Latin digits
- Times (1:05:30), sizes (1.2 GB / 35.4 MB) and frame rates were written with the phone's language in some screens (Audio, Edit, Export, Storage, Network, Manga, Player lists). In Persian they came out in Persian digits next to Latin units, which the right-to-left layout can show in a jumbled order ("wrong time display"). All of them now use the same fixed format as the video player. The big player of the music screen also shows hours now (it showed 75:00 for 1 h 15 min).
- Not compiled or tested on a device.

## 3.99.5
- Free up space: the explanation line now says that music and comics are done through "Pick files by hand".

## 3.99.4 - Free up space: 7z comics too
- Comic shrinking now also takes **.7z / .cb7** (copied to the cache, read with the 7z library, written as a .cbz with WebP pages; the cache copy is removed). .cbr / .rar are still not supported.
- Not compiled or tested on a device.

## 3.99.3 - Free up space also shrinks music
- **Free up space → Pick files by hand → Music from the app's library / Music files from the phone's files:** a track is written again as AAC (.m4a) at 96 / 64 / 40 kbps (Balanced / Small / Tiny; half of that for mono). A file that is already at or below that rate is skipped ("already small"). The new file is in Music / ClearOverlay / Shrunk; the original is not touched. Tags and cover pictures are not copied.
- Not compiled or tested on a device.

## 3.99.2 - Free up space also shrinks comics
- **Free up space → Pick files by hand → Comic files (CBZ / ZIP):** every page of a comic is written again as lossy WebP (82 / 72 / 62 quality for Balanced / Small / Tiny, pages never larger than 3000 / 2200 / 1600 px on the long side; a page that would not get smaller is kept as it was; other files inside are copied). The new `_small.cbz` is in Download / ClearOverlay / Shrunk; the original is not touched (delete it yourself when the new one reads well). Only .cbz / .zip (not .cbr / .rar / .7z).
- The Picture settings batch 2 asked for earlier (clarity, anti-ringing, deinterlace, auto crop of black bars) is already part of 3.98.x, so nothing was added for it here.
- Not compiled or tested on a device.

## 3.99.1 - Artemis: quick setup for streaming
- New button **Quick setup for streaming** in the streaming card: Best picture (1080p / 60 / 30 Mbps), Balanced (1080p / 60 / 20 Mbps), Fast reaction (720p / 60 / 12 Mbps, ultra low latency), Weak Wi-Fi (720p / 30 / 5 Mbps) and **720p + this app's upscaler** (the PC sends a small clean picture, +CRSC sharpens it on the phone; direct mode is switched on). They write the client's own settings (size, fps, bit rate, codec auto, frame pacing, low latency; a hand-typed size is cleared), so everything can still be changed in the client's settings.
- The embedded Artemis client already has the features of the other forks (virtual display, custom refresh rate, HDR, on-screen keyboard / controller profiles, clipboard sync, performance overlay); no code of other forks was merged.
- Not compiled or tested on a device.

## 3.99.0 - Free up space fixes, Library folders by path (hidden folders)
- **Free up space, pick by hand:** the button now asks *Video from the app's library* / *Photo from the app's library* / *From the phone's files*.
- **Free up space, videos that gave nothing:** a video now gets a second try (H.264 if the H.265 encoder failed, "Tiny" if the first result was not smaller), a stalled codec is stopped after 30 s instead of waiting for ever, and every error names the step it happened in (encoder, decoder, converting, sound, saving) so the summary shows the real reason.
- **Library, add folder:** a new in-app folder chooser (reads the folders directly, needs "All files access" like the File Manager) lists **hidden folders** (names with a dot) and can choose a folder that only holds hidden files. The phone's own picker is still offered. Folders added this way (and by the phone's picker) now also list hidden files and sub-folders inside them (cache / trash / thumbnail folders and `.nomedia` are still skipped).
- Not compiled or tested on a device.

## 3.98.12 - File Manager: hidden files, protected folders, a better button, bug fixes
- **The button.** It is now right under **Library** on the main screen, a card of its own (folder icon, bold **File Manager**, a line "Phone, hidden files, network and cloud", an arrow) instead of a small chip further down. The screen title is "File Manager" / "مدیریت فایل" too.
- **Hidden files.**
  - An **eye button** at the top of the file manager (also in the home list) switches the files and folders whose name starts with a dot (`.nomedia`, `.thumbnails`, ...) on and off. The choice is **kept** (it used to be a menu item that was off again every time). Hidden entries are drawn a little fainter. The ⋮ menu entry is still there.
  - A new home section **Hidden and protected places**: *Android/data* and *Android/obb*, *Android/media*, *Files of this app (private)* (the app's own data folder, `/data/data/...`) and *Device root (/)*.
  - **Android/data and Android/obb** are closed to every app on Android 11 and newer, even with "All files access". New `SafFs.kt` opens them through the access the user gives **once** with the system folder picker (tap "USE THIS FOLDER"); it is remembered (persisted URI permission) and then they browse, copy, rename, delete, create folders and open files like any other place. If the plain way works on a phone (older Android, some ROMs) that is used first. A picked wrong folder is refused with a message. **Android 13 and newer refuse these two folders in the picker for every app** (the same wall every file manager meets; MT Manager gets past it with Shizuku, ADB or root, which this app does not have): there the dialog says so and the folders stay closed.
- **Bugs fixed in the file manager** (the storage classes are plain Java and were compiled and run here: 13 checks, all pass):
  - *A link back to a parent folder made search, size counting, copy and zip go round and round* (a symbolic link to a folder looked like a normal folder; with the new "/" and data folders this gets more likely). Found with a test: the old code gave 41 duplicate search hits and counted 205 bytes for an 11-byte folder (copying would have made 40 nested copies). `FmItem` now knows `link`; search, size counting, copy and zip do not walk into a linked folder (a linked file is copied as its content).
  - *Selected items that are not on the screen stayed selected*: select a hidden file, switch hidden off, then Delete / Cut / Copy still acted on it. Now only what is shown can stay selected (after a reload, a hidden toggle, a search). A search hit that is hidden turns hidden files on so it can be selected.
  - *Renaming `a.txt` to `A.txt` was refused* on storages that ignore letter case (SD card, FAT / exFAT, the internal storage on many phones) because "the name exists"; only a really different file is a clash now.
  - *"All files access"*: after allowing it in the system settings you came back to the home list and had to tap the folder again; the folder you tapped now opens by itself.
  - A folder that cannot be read says "no access, or it is not a folder" instead of only "cannot read".
  - Pictures opened from cloud storage are copied to the app's cache; copies older than a day are now deleted (they were never cleaned).
  - The date format of every row was created again for every row while scrolling; it is created once.
- **Checked here:** the plain-Java classes (`FmItem`, `LocalFs`, `FmCopy`, `FmSearch`, `ZipTools`) compiled and tested with a script (symbolic-link loop in search / size / copy / zip / delete, rename by case, clash, unreadable folder, "/" as a storage); brackets of the changed Kotlin files balance; every `R.string` exists in both languages (1189 each, no duplicates, no loose apostrophes). **Not compiled as an app and not run on a phone**: `SafFs.kt` (the Android document provider side), the picker flow in `FilesActivity.kt` and the new main-screen button are untested; if the build shows an error send the log. Things to try: the new button; the eye (hide / show `.nomedia`); Android/data on an Android 11 / 12 phone (grant once, then browse and open a file), on Android 13+ (should explain, not crash); "/" and the app's private folder; select a hidden file, hide hidden files, the bar should disappear.
- Also looked at, no change: the 3.98.11 Smart fix analysis (`SmartFix.measure`, its use in the photo path and the live pass): the grid sample, the bar rules, the white-balance weights and the gamma branches are consistent; its value ranges (gain 0.85 - 1.2, span at least 0.2, gamma 0.65 - 1.2) keep it bounded.

## 3.98.11 - Smart fix improved
- Smart fix (white balance + levels + shadow lift; photos, GIF, video, live screen) now uses one shared analysis (`SmartFix.measure`); the photo path (`Enhance.auto`) uses it too, so photo and video agree.
- **Black bars are ignored** (letterbox / pillarbox rows and columns that are nearly black): they used to make a normal picture look "too dark" and lifted it too much.
- **White balance no longer fights colourful pictures:** near-gray pixels count most, and the more colourful the picture the weaker the balance (a green field or blue sky is not a cast; before it was pushed to the 1.2 / 0.85 limits and turned magenta / orange). The balance keeps the brightness (only colour moves).
- **Brightness target uses mean and median** (a small bright window no longer hides a dark scene).
- **Video:** the correction used to be updated in steps (every half second, 20 % of the way); it now follows the measurement a little every frame (smooth, no stepping) and follows faster after a scene cut.
- Checked: synthetic scenes (neutral grey, warm cast, green field, blue sky, bars) in a script - neutral stays 1.0, a real warm cast is still corrected, a green field / sky is corrected about half as strongly as before, bars do not change the result. Not compiled as an app and not run on a phone: please compare Smart fix on / off on a few photos and videos.

## 3.98.10 - review of 3.98.9
- Checked (scripts, no phone): all 40 shader variants compile and link on a software OpenGL ES 3.2 driver (shaders and GlPipeline are identical to 3.98.3, whose pixel tests still apply); the plain-Java file-manager classes (`FmFs`, `LocalFs`, `WebDavFs`, `S3Fs`, `HttpRaw`, `FmCopy`, `ZipTools`, `FmSearch`) compile with javac; Kotlin syntax parses (the only errors are Android types the checker does not have); strings: EN / FA keys and `%`-arguments match, no loose apostrophes or bad `\u` escapes; manifest classes exist.
- **Fixed:** "Pick files by hand" in Free up space counted a single picked file twice in its message (the file came both as `data` and in `clipData`). Picked addresses are now de-duplicated.
- The 3.96.3 - 3.96.7 changes were already merged in 3.98.1 and the file manager arrived in 3.98.4, so nothing from 3.96.3 is missing.
- Not compiled as an app and not run on a phone.

## 3.98.9 - the known problems of 3.98.8
- **Hidden folder + next / previous:** a file opened from the "show hidden" view keeps the whole folder for next / previous (hidden files are only skipped when the open file is not a hidden one).
- **Export time estimate:** "no upscaling" (RAW) and "sharpen only" now have their own weight (0.6 / 0.7) instead of counting as FSR.
- **Direction keys:** "which way is the screen now" (arrow key, Lock) used the size of the window; in split screen or a floating window that is wrong. It now uses the whole display. This can make the arrow key / Lock pick the wrong direction less often; the other turning problems could not be found without a phone.
- Not compiled and not run on a phone.

## 3.98.8 - review
- Checked (by script, nothing compiled): every `R.string` used exists in both languages, EN / FA names and `%1$d`-style arguments match, no duplicate names, every manifest activity has a class and every activity class is in the manifest, brackets balance.
- **Fixed:** a file export with H.265 chosen on a phone without a usable H.265 encoder falls back to H.264; the size (made for H.265, possibly 4K / 6K) is now fitted again for H.264 so the fallback cannot fail on a size the H.264 encoder does not take.
- Known and not changed: with a hidden folder, opening one of its files from the Library's "show hidden" view gives no next / previous file; the export time estimate ignores some upscalers.
- Not compiled and not run on a phone.

## 3.98.7 - Player: picture size after turning the phone (safety net)
- Reported: after turning the phone the picture is sometimes too small or too big, sometimes the turn does not happen. The cause could not be reproduced (nothing was run on a phone); the code path was read and one weak point found: the picture view was only rebuilt by the stage's layout listener, which can see a half-way size while the system turns the window, or no event at all (180 degree turn, split screen, slow phone).
- New `ensureFit()`: after every turn (`onConfigurationChanged`), resume and direction request (`applyRotation`) the size of the picture view is compared with the stage 5 times (0 / 0.15 / 0.4 / 0.9 / 1.8 s) and rebuilt when it does not match.
- If a problem stays, please note: which mode (default / the arrow key / Lock / Free), video or photo, the phone's auto-rotate setting, and what exactly happens - that is what is needed to find the rest.
- Not compiled and not run on a phone.

## 3.98.6 - Free up space showed no files at all
- **Bug fixed:** the screen asked for READ_MEDIA_VIDEO and READ_MEDIA_IMAGES on every Android version and wanted both. On Android 12 and older these permissions do not exist, so the screen never got "access" and stayed empty. It now uses the Library's own check (`Media.permissions()` / `Media.granted()`: READ_EXTERNAL_STORAGE on Android 12 and older).
- The lists are no longer sorted by the media query (some phones refuse that sort and return nothing); they are sorted in the app.
- Not compiled and not run on a phone.

## 3.98.5 - Free up space (file shrinker): pick files by hand
- The shrinker only listed the biggest files of the phone and had no way to choose a file. New button **Pick files by hand...** opens the phone's file picker (several files at once, videos and JPEG photos, any size). Picked files are added to the list, ticked, and shrunk like the others. Files picked from the phone's Videos / Images lists keep their media-index address, so "Delete the originals" still works; files from other places (e.g. a cloud folder) are shrunk but their originals are kept.
- Not compiled and not run on a phone.

## 3.98.4
- **New: a file manager ("Files" on the main screen).** One screen for the phone's own files, the network servers you already saved (SMB / FTP) and cloud accounts, all browsed the same way.
  - **Phone**: internal storage, SD card / USB (every mounted volume) and the usual folders (Download, DCIM, Pictures, Movies, Music, Documents). Needs the "All files access" permission, asked once with an explanation (new `MANAGE_EXTERNAL_STORAGE` in the manifest).
  - **Network**: the servers of the network screen (SMB shares, FTP), now with writing: copy to / from the phone, new folder, rename, delete. Videos, photos, music and comics still stream straight from the server.
  - **Cloud**: *WebDAV* accounts (Nextcloud / ownCloud, Box, pCloud, Koofr, Yandex Disk, GMX, WEB.DE, Synology / QNAP NAS and any other WebDAV server) and *S3-compatible* accounts (Amazon S3, Backblaze B2, Wasabi, Cloudflare R2, MinIO), with presets in "Add a cloud account"; the connection is tested before saving. The phone's HttpURLConnection refuses the WebDAV methods (PROPFIND, MKCOL, MOVE), so there is a small HTTP/1.1 client of its own (`HttpRaw`: TLS with host-name check, chunked answers, redirects, basic authentication); a certificate nobody vouches for (home NAS) is accepted only when you tick it. S3 uses AWS Signature V4 (path-style addresses); folders are key prefixes, renaming copies on the server and deletes the old keys. Google Drive, OneDrive and Dropbox need an app registration with each company (a key that belongs to the app), so they are not included.
  - **Working with files**: long-press to select several, then Copy / Cut / Delete / Rename, and under "More": Share, Select all, Properties, Compress to zip, Extract zip (zip and cbz, phone files). Paste works between any two storages (phone to cloud, cloud to NAS...) with a progress dialog, cancel, and "keep both / replace / skip" when names clash. A cancelled or failed copy never leaves a half file behind. Search (the menu at the top right) looks for a name in the folder and everything below it, on any storage. Sort by name / date / size, show hidden files. Tapping a file opens it in the app's own player, photo viewer, GIF viewer, music player or comic reader (with the other files of the folder as the playlist); other types go to "open with". Cloud files are downloaded to the cache first.
  - **Tests**: the storage side is plain Java (`FmFs`, `LocalFs`, `WebDavFs`, `S3Fs`, `HttpRaw`, `FmCopy`, `ZipTools`, `FmSearch`) and was run offline, on the exact files in this project, against mock servers (49 checks): WebDAV (list, 5 MB upload and download byte for byte, chunked answers, names with spaces / # / % / Persian letters, keep both / skip / replace, rename, move, folder trees both ways, cancel leaves nothing behind, a folder cannot go into itself, wrong password); S3 (the three published AWS Signature V4 examples come out right, a mock that checks every signature itself, pages of 3 results, rename and folder move by server-side copy, cancelled upload, wrong secret key); zip (round trip, Persian names, "../" entries cannot leave the target folder, cancel deletes the half archive, the archive is never packed into itself) and search.
  - **Not compiled or run on a phone here** (no Android build tools): the Kotlin parts (`FilesActivity.kt`, `FmProviders.kt` with the SMB / FTP writing, `FmProvider.kt`) need a real build and a try. The SMB write calls (write, mkdir, rm / rmdir, rename) go through reflection so a different smbj version fails with a message instead of breaking the build. `FmProvider.kt` hands phone files to the players and to other apps as content:// addresses (read only, only with a grant; the platform ContentProvider, no extra library).

## 3.98.3 - build fix (strings)
- **Build error fixed:** `export_target_big_hint` (English) had an apostrophe that was not escaped ("the phone's encoder"); the resource compiler refuses it. It is `\u2019` now, like the other texts. No other change. A check of every string of `values` and `values-fa` for bad `\u` escapes and loose apostrophes finds nothing else. (The two "Multiple substitutions" lines in the build log, `export_size_hint` and Moonlight's `layer_alpha_hint`, are warnings that were there before; they do not stop the build.)
- Not compiled as an app here (the Kotlin code has never been through a real build in these chats; if the next build shows a Kotlin error, send the log).

## 3.98.2 - 4K / 6K export, "Free up space" moved, Hide everywhere (applied on 3.98.1)
- Save as a new file: new sizes **4K** (2160) and **6K** (3240). The size is fitted to what the phone's encoder takes (`ExportInfo.fitOut`); if it cannot do it, the picture is made a little smaller with the same shape, never squeezed. H.265 reaches the biggest sizes. 4K / 6K are very heavy.
- The main-screen "Free up space" entry is gone; the same function is a button in the Save as a new file screen (many big videos / photos at once, Balanced / Small / Tiny, optional delete of the originals).
- Hide: what you hide in the Library is also left out of the music player's list and of next / previous file in the player (the open file stays).
- Not compiled and not run on a phone.

## 3.98.1 - merge of 3.96.7 (Temporal rebuilt, Watch now / player fixes, NIS fix) with 3.98.0 (3.97.0 Auto everywhere + Auto-lighten)
- Both lines came from 3.96.2. The 3.96.3 - 3.96.7 changes (below) were put on top of 3.98.0; the 3.97.0 Auto work (manga, GIF, stream panel, `Auto.applyExtras`, `Profiles.nameRes`) and Auto-lighten are kept. Quick profiles keep the 3.96.3 FXAA Fast values. Not compiled or run on a phone.

## 3.96.7 - NIS (original): wrong pixels at exact sample positions
- **Bug fixed in "NIS (original)".** The 64-phase coefficient tables have rows 0..63, but the phase index was `int(fr * 64.0)` (plain filter) and `int(pf * 64.0)` (the two diagonal filters), which is 64 when the fractional position rounds up to exactly 1.0, so the shader read past the end of the table (undefined: it gave dark / wrong pixels such as (7, 0, 0) where the source pixel is (21, 13, 7)). It happens on pixels that sit exactly on a source pixel (e.g. whole-number positions at x3), most visibly in the first columns of a picture. The index is now limited to 63 (`min(..., 63)`) in all three places; nothing else in the program changed. NIS fast, NIS mid and Aura have no table and were not affected.
  - Checked with this version's shaders on a software OpenGL ES 3.2 driver: 14 pictures x 5 scales (1, 1.5, 2, 3, 4) x 3 sharpness values = 210 cases. Before the fix 30 cases had pixels more than 8 / 255 away from NIS fast (wrong pixels); after it 0 cases, largest difference 2 / 255. All 40 shader variants compile and link.
- **Offline study, nothing shipped from it** (the app's own shaders run on a software GL driver; 12 animation / anime / flat-art pictures and 3 synthetic lace / mesh pictures, source = the real picture shrunk x2 or x3 and compressed with H.264 crf 26, compared with the real picture at the display size):
  - Compression costs the most: the same Aura upscale from the clean low-res picture gives 30.65 dB / SSIM 0.906, from the H.264 one 29.11 dB / 0.865. The app Denoise recovers almost nothing of it (+0.07 dB at 15 %, and it lowers edge sharpness from 0.94 to 0.86); sigma, bilateral, non-local-means and luma-guided chroma filters tried offline recovered at most 0.15 dB against the clean low-res picture (the encoder removed detail; it is not additive noise).
  - A RAISR-style learned filter bank (144 least-squares 7x7 filters by edge angle / strength / coherence): +0.3 to +0.8 dB over Catmull on clean sources, +0.1 to +0.4 dB on H.264 ones. One back-projection round after Aura: +0.08 dB. Every combination of Aura's push and flat-area clean-up is within 0.3 dB.
  - Rendering at 1.5x or 4K and shrinking to 1080p: NIS fast +0.2 to +0.4 dB, Aura -0.1 to -0.5 dB, at 2.2x and 4x the pixels.
  - A setting with AA Edge Smooth 100 %, NIS fast, Sharpness 100 %, Crispness Max, Detail 100 % at 4K gave edge sharpness 1.55 of the real picture (1.0 = same) and 25.7 dB / SSIM 0.804, against 27.8 dB / 0.847 for Aura, Sharpness 50, Crispness Soft, Detail 30 % at 1080p; on a 4-pixel lace pattern it invents an irregular grid that is not in the picture. Edge Smooth 100 % keeps only 0.82 to 0.90 (SSIM) of fine lace / mesh patterns; a variant that smooths only straight edges kept 0.98 to 0.99 of the lace but lost the jaggy removal (30.5 -> 28.2 dB on aliased shapes), so it was not shipped.
- Kotlin was not touched in this version (one shader constant and the version number).

## 3.96.6 - Player: leaving Watch now / Smooth live, preparing behind the viewer, rotation, first picture
(first batch of the list; the export screen items - 4K / 6K, Free up space inside "Save as a new file", Hide everywhere - follow)
- **Leaving no longer reopens the video.** The export screen opened the player by itself once the first pieces were ready, but only remembered this when it had done it itself; a player opened with the "Watch" button was opened a second time after leaving it. `watchParts` now always marks it.
- **Back in Watch now / Smooth live asks four things** (list): *leave the video and keep preparing in the background* (nothing is cancelled; "Watch" on the export screen returns to the spot that was watched), *save what is ready, then leave*, *stop and delete*, *stay*. Only "stop and delete" cancels the work. Before, every way out (also Back when no piece was ready, or the library key) cancelled the job.
- **"Keep this much behind me" now makes that part.** After a jump the work starts at the spot itself (the picture appears at once); when it is as far ahead as the "ahead" setting allows (instead of idling) it goes back and makes the missing part of the stretch [spot - behind, spot), then continues; it hops over pieces that exist. It never makes more than "ahead" in front, keeps the "behind" part, deletes the rest (as before) and does this while the video is paused too. (`missingBehind`, `backfillReq` in `VideoExport`.)
- **Free rotation (video): the picture no longer shrinks and grows.** `onConfigurationChanged` rebuilt the picture view with the stage size of the old direction, and the stage's layout listener rebuilt it again; now only the layout listener does it, with the final size.
- **Photos:** by default a photo now follows its own shape (landscape / portrait) like a video, so **Free rotation** (follow the phone in every direction) does something. **Rotation lock** freezes the exact direction (landscape / reverse landscape / portrait / reverse portrait, `rot_lockdir_*`), also after a restart (before it froze "whatever the screen had" when the player was opened, so a saved lock could stay in the wrong direction).
- **No black screen at the start of a video:** a still picture of the start spot (`MediaMetadataRetriever`, local files only) is shown until the first frame is drawn (removed after 250 ms of the first frame or 6 s at most; not for Watch now / Smooth live pieces).
- Not compiled as an app and not run on a phone.

## 3.96.5 - Temporal clean-up rebuilt (Light / Strong)
Why: it only gained about +0.8 dB PSNR on noisy / compressed test video (and the old Strong could drag a fade), so it was hardly worth the GPU time.
- **Motion search (`TEMPORAL_MOTION`, own shader; frame generation still uses `FG_MOTION`)**: log search 8 -> 4 -> 2 -> 1 -> 0.5 px, so the motion is **half-pixel accurate**; 45 matches of 36 samples per 16 x 16 block (the old one made 106 matches of 16 samples with whole-pixel steps).
- **`TEMPORAL`**: the old picture is sampled with a **Catmull-Rom** filter (bilinear blurred it a little more on every frame of the recursion); it is **clipped to the 3 x 3 neighbourhood of the new frame** (uClip x spread, at least uSig) instead of min / max + 0.02; the blend is also gated by the difference of the **3 x 3 averages** of old and new (uTolL), so a fade, a flash or a cut is not mistaken for noise and drops the old picture at once.
- **Levels:** Light 80 % / tolerance 0.18 / motion back-off 0.35 / small spatial smoothing; Strong 90 % / 0.24 / 0.2 / more spatial smoothing in still flat areas. Both were tuned (coordinate descent) on the offline bench.
- **Measured (software OpenGL ES, synthetic video: 10 scenes x 2 degradations = 20 cases: still, slow and fast pan, a moving object, a cut, hand shake, zoom, rotation, a fast object, a fade; noise + JPEG per frame; PSNR / SSIM against the clean frame, mean over frames 4-12):** old Light +0.87 dB (SSIM +0.033), old Strong +0.81 dB (+0.028); **new Light +1.61 dB (+0.054), new Strong +1.90 dB (+0.068)**. The worst single case: new +0.4 dB or better, old +0.2 / +0.3. Sharpness against the clean frame stays 0.97 - 1.02. The bench is synthetic (a real encoder's artefacts are different), and the GPU cost was not measured here (the new search does fewer samples than the old one, the shader reads 9 more history samples).
- Not compiled as an app and not run on a phone. Please compare Off / Light / Strong on a noisy or low-bitrate video with still parts, and on a pan; tell me about any smear.

## 3.96.4 - review of "Save as a new file" and Watch now
- **Fixed: the measured Auto look and the measured black bars were thrown away at the start of a job.** `VideoExport.run` measured them (`look.txt`, `bars.txt` in the job folder) and then, for a job with no finished pieces, cleaned the whole job folder, which deleted both files again. A job that was paused or cut short measured everything again when it was continued (and 3.95.0 / 3.92.0 say the opposite). Both are written again after the clean-up, so a continued job uses the same look and the same crop. Nothing changes for a job that runs in one go.
- Read through, no change needed: `VideoExport` (pieces, resume, range, stream gate / jumps, frame cap, Auto fps), `ExportService` (state, notifications, clean-up of a streaming job), `ExportInfo` (estimate and `streamSpeed` use the same factors; mode bits 8..26 do not overlap), `LookAuto`, `Look.encode / decode` (the new AA mode 4 survives the Smooth live copy), the export screen (start, advice, resume, finished card) and the player side of Watch now (`syncStream`).
- Known and left alone: the total length uses the default 33 ms frame time for the last picture (a 60 fps video is 17 ms off; it is the same on every run, so resume still matches); a new job started in the same instant the previous one ends could lose its notification (not reachable by hand).
- Not compiled as an app and not run on a phone.

## 3.96.3 - Quick profiles re-checked with the newer settings
- Tested on the same synthetic scenes as 3.89.30 (11 picture kinds x 3 strengths, software OpenGL ES 3.2, SSIM / PSNR / sharpness against the original): **Clarity** (+/-15 %), **Anti-ringing** (50 / 100 %, also with +0.08 sharpness) and the new AA **Smart Edge** (50 / 80 %) next to FXAA Fast / Quality / Edge Smooth.
- **Clarity and Anti-ringing stay 0 in the Quick profiles.** Positive Clarity lowered SSIM everywhere (-0.002 to -0.01) and over-sharpened games; Anti-ringing changed SSIM by +-0.002 on video / photo / game (the profile sharpness is too low to ring) and clearly hurt text and manga (-0.03 .. -0.08). They are for the user's own taste, not a default. Deinterlace stays off (the test scenes are not interlaced).
- **Game rows:** FXAA Quality (even after 3.89.31) scored below FXAA Fast at the old strengths (Light 0.35 same, Balanced 0.685 vs 0.689, Strong 0.618 vs 0.624 SSIM). Now FXAA Fast 0.35 / 0.40 / 0.45 in the player and overlay tables (was Fast 0.35, Quality 0.50 / 0.65). The Quality budget still upgrades Fast to Quality.
- Every other row is unchanged: AA choices differ by less than +-0.003 SSIM there, which is inside the noise of a synthetic test, and Smart Edge keeps sharpness better than FXAA / Edge Smooth but gains no SSIM on these scenes.
- Not compiled as an app and not run on a phone.

## 3.98.0 - Auto-lighten: live effects that do not lag with heavy settings (on top of 3.97.0)
- New switch **Auto-lighten when lagging (video player)** (Picture controls, under Auto crop; per section, off by default; not the same as the "Smooth live" export mode). The player measures the frame time (and listens to dropped-frame reports); above the video's frame budget the pipeline lightens itself step by step and returns after a long calm stretch (with back-off). Saved settings are never changed.
- Levels (`GovFx`, `GlPipeline.govUpdate`): 1 frame generation, temporal, Boost off; 2 Denoise, Deband, anti-aliasing, NIS crispness off, CRSC one level lower; 3 upscaler one step lighter; 4 FSR 1; 5 Clarity / anti-ringing off and output at most 1080 p.
- Video player only. Not compiled or run on a phone.

## 3.97.0
- **Auto now works in every section.** In the manga reader, in the GIF viewer and in the Smooth live (stream) panel the Auto switch used to do nothing (there was no pick function behind it: it only said "waiting"). Now: *Manga* gets the manga profile with the Quality budget, its strength from how much the pages are enlarged on your screen, applied before the first page is processed. *GIF* gets the video profile (clean-up of dither and banding), Quality budget for small GIFs and Balanced for big ones, re-picked for every GIF. *Smooth live* picks the stream profile from the stream size.
- **Auto covers the newer options too** (a quick profile only sets sharpness, detail, clean-up and the upscaler; the rest was left as it was): the input / middle / output size choices go back to automatic, CRSC Edge exact mode and the extra NIS crispness pass go off, black bars are cut by themselves on films and clips (not on game streams or GIFs, and nothing happens when there are none), and anti-ringing is switched on when the sharpening is strong (sharpness 55 % and above, NIS original / NIS, CRSC Edge Crisp or Ultra). Deinterlace and Smart fix are left to you (a live frame cannot tell a combed picture safely); the live tuning of shadows, highlights, contrast, saturation, sharpness and clean-up from 3.96.2 is unchanged. The screen layer's Auto steps also reset these options, so a leftover manual choice cannot linger there.
- **Fix**: the Auto line in the player named only 6 of the 11 content types ("Auto" was shown for Text, Manga, Repair, Dark and Busy). All 11 names are used now (`Profiles.nameRes`).
- Checked statically (string resources, resource names, Kotlin property use); not compiled or run on a phone here.

## 3.96.2 - Player: a quiet note for Auto, and live auto-tuning
- **The Auto note is small now.** "Auto: Video - Quality" and "Auto: dark picture -> NIS soft" were shown in the big box in the middle of the picture (20 pt, covering it every time the picture kind changed). They are a small note (11 pt, dim) in the lower left corner for about 2.5 s (`showAutoChip`; it sits above the bottom bar when the bar is shown). The centre box stays for seeking, volume and the like.
- **Live auto-tuning** (player panel, under the effects switch; videos only; off by default; saved as `autolive`). While the video plays the app looks at a tiny copy of the frame about once a second (`Auto.stats`: mean brightness, brightness range, share of burnt-out pixels, colourfulness, edge amount), smooths the numbers and adds a small change **on top of your own settings** (they are never overwritten: the change lives in `Cfg.tShadows ...` and is added in `LiveFx`; it is not saved and is zero when the switch is off, the media closes or the player ends):
  - dark scene -> shadows up (at most +0.35), burnt-out -> highlights down (at most -0.30), flat -> contrast up (about +0.27), grey -> saturation up (+0.20), soft -> sharpness +0.10, busy -> sharpness -0.10, dark or busy -> denoise +0.15.
  - It follows the picture continuously (each target is eased in, 25 % per second), unlike Auto which picks the upscaler when the kind of picture changes. Not used in Watch now / Smooth live pictures (they are already processed) and not for photos.
- The numbers above are first guesses, not measured on real films. Please try a dark film, a bright cartoon and a grey old clip with the switch on and off, and tell me where it is too much or too little.
- Not compiled as an app and not run on a phone.

## 3.96.1 - Smooth live: frame rate, Auto and manual
Smooth live still has to decode, draw the effects and encode every frame, so a phone that only just keeps up with the effects live may be a little slower than the video here. New **Frame rate in Smooth live** (shown when Smooth live is chosen; own setting `live_fps`, the export screen's fps cap does not apply to it):
- **Auto (default):** all frames; if the measured speed stays under 0.95x of the video (after 6 s, checked every 8 s), every second frame is left out (60 -> 30 fps), and if that is not enough, 24 fps; the speed is measured again after each step. It never goes back up by itself during the job. A video of 30 fps or less is never reduced.
- **All frames:** nothing is left out; a slower phone waits first to build a head start (the "Preparing" line).
- **30 / 24 fps:** always that rate (a video with a lower rate keeps its own).
- The time estimate and the speed learned from runs follow the choice (`ExportInfo.fpsCapFor`).
- Not compiled as an app and not run on a phone. Please try a 60 fps video with heavy player settings: Auto should start within a few seconds and then play without stops; compare with All frames.

## 3.96.0 - "Smooth live": the same picture as playing directly, made ahead so it does not lag
New third choice in "Save as a new file" -> output: **File / Watch now / Smooth live**.
- **Same picture as direct apply.** It copies the video player's own settings when it starts (`liveOpts()` in `ExportActivity`: upscaler and its CRSC level, sharpening, detail, detail size, denoise, deband, anti-aliasing, boost, vivid, contrast, shadows, highlights, saturation, warmth, grain, clarity, anti-ringing, deinterlace, Smart fix, auto crop of black bars, the player's temporal clean-up). They travel inside the `Look` text (new fields `live`, `lSharp` ... `lVivid`; the old jobs decode as before) and `VideoExport.fxFor` uses them instead of what a quality tier would pick. So nothing is chosen twice and the picture is the one the player would draw.
- **Lighter and faster than Watch now at a big size.** The picture is made at the size of the screen (its short side, 720..1440), which is also what direct playing shows, not at a 4K target; H.264; the same pieces / head start / no rest between frames / richer bit rate as Watch now (3.92.x - 3.95.x), and the player only shows the pieces (plain copy). Nothing is saved to the gallery.
- **What it cannot do:** it cannot make a picture faster than the phone's GPU can draw those settings. If the settings are so heavy that the phone makes less than 1x of the video, it still waits to build a head start (the "Preparing" line) and tells why; the cure is lighter player settings. It will play without the lag of direct playing because the work runs ahead, not because it is free.
- The other choices of the export screen (size, quality, upscaler, look) are not used in this choice; the range (part of the video) is. The "will it be smooth" question before starting is not asked (it is for sizes you pick).
- Not compiled as an app and not run on a phone. Please try: set the player's video settings heavy, play the video directly (it lags), then Smooth live (should not), and compare the picture. Tell me what looks different from the direct picture.

## 3.95.2 - review of the merged 3.95.1 (3.92.6 + the other line)
- **Fixed: the "will it be smooth?" warning of Watch now did not know the upscaler or the frame rate cap.** The other line made the learned phone speed be divided by the upscaler weight (`modeCost`: NIS mid 1.4, NIS original 2.6, CRSC Edge ...) and added the 30 / 24 fps cap, but `ExportInfo.streamSpeed` (my warning before a heavy size) still used neither: with a heavy upscaler it promised a speed that the phone cannot reach, and with a cap it was too careful. It uses the same factors as `estimateSec` now.
- Nothing else changed. Checked in the merge: the compile error of the log (`Shrink.kt` smart cast of `pfd`) is already fixed in 3.95.1; all brackets balance (tokenizer check, every .kt file); strings en / fa equal (1077, no duplicates, XML valid, every `R.string` used exists); the new functions and constants it calls exist (`modeCost`, `LookAuto.analyze`, `Look.auto`, `setPlayIcon`, `cleanBehind`, `Cfg.MODE_*`).
- Not compiled as an app and not run on a phone.

## 3.95.1 - Save as a new file, step 2: "Fully automatic" modernised, smaller Watch now space limits
- **Fully automatic** now uses the **Auto picture look** (3.95.0), chooses the **upscaler by the kind of picture** (anime / cartoon chip -> CRSC Edge level 2; everything else -> NIS fast mid; plain FSR 1 when that would take more than about 4 hours) and still picks the quality tier (the strongest that fits 6 hours), the encoder (H.265 when the phone has it), Smart fix and the light temporal clean-up; black bars are cut by the Auto look. The estimate on the screen says what it uses (`export_full_summary_fmt`).
- **The time estimate knows the upscaler now** (`ExportInfo.modeCost`: FSR 1.0, NIS 1.2, NIS mid 1.4, NIS fast 1.8, NIS original 2.6, CRSC Edge 1.8 + 0.35 x level; these are guesses, not measured). The speed the app learns from a run is divided by the same factor, so the numbers stay consistent.
- **Watch now space limit: 50 MB and 100 MB added** (and 300 MB, 600 MB default, 1 GB, 2 GB, no limit). With a limit of 150 MB or less the work may stop at 15 s ahead (was 50 s), and the player's head start is 12 s at most; with a 4K picture this is a thin head start, so a small limit suits smaller sizes best.
- Not compiled as an app and not run on a phone (brackets balance; strings en / fa equal, 1077).
- Still to do: a "smooth live" option, lighter and faster than Watch now.

## 3.95.0 - Save as a new file, step 1: "Auto" picture look
- New switch **Auto** at the top of the Picture look section (video file / Watch now). When on, the sliders are hidden and not used. When the work starts (`VideoExport`, before the size is chosen) `LookAuto.analyze` looks at 7 frames spread over the video (middle part only, so bars and subtitles do not count) and picks mild settings: mean brightness < 0.30 -> Shadows up to +55; many clipped highlights -> Highlights down to -40; a narrow brightness range -> Contrast up to +35; low colour -> Saturation up to +30 (very colourful: -10); soft picture -> Clarity +12 / +25 with Anti-ringing 30; torn lines in an SD source (<= 600 px high) -> Deinterlace; black bars are always cut (when there are none, nothing changes). The answer is written to `look.txt` in the job folder, so a continued job gets the same look; the job id contains the Auto flag.
- `Look` has a new field `auto` (11th number of the text). Old jobs load as before.
- Not compiled as an app and not run on a phone (brackets balance; strings en / fa equal, 1076). The rules were not tried on real videos: please try Auto on a dark film, on a normal film and on an old SD clip, and say what looks wrong.
- Still to do (next steps): "Fully automatic" modernised (it will use Auto look, a better upscaler choice by content and a summary of what it chose); a "smooth live" option that is lighter and faster than Watch now.

## 3.94.0 - "Watch now", step 5: Stop while preparing, disk space, FX on request
(on top of 3.92.6; the 3.93.0 Watch now / export code of the other line was not merged, 3.92.1 - 3.92.6 already do those parts)
- **Stop while it is preparing.** While the circle turned, pause / play did nothing useful (the player was re-paused every tick and then started by itself). Now, during the wait, the play / pause button means "do not start by itself" / "start when ready": it keeps preparing, and when ready the picture is shown paused at the spot. Leaving with Back worked before and still does.
- **Watched pieces are deleted, and the disk use is limited.** Found: pieces behind the viewer were only deleted inside the "wait while far ahead" step; once the work had made the whole video (`atEnd`) or was not waiting, nothing was ever deleted. Now `cleanBehind()` runs in every round and at the end too. The default "keep behind" is 10 s (was 30 s). New setting **Most space the pieces may use** (300 MB / 600 MB default / 1 GB / 2 GB / No limit): when the pieces on disk are over it the work waits (never nearer than about 50 s ahead, so the head start still works). The "keep watched pieces" choice in the player menu is for that viewing only (before it was written to the settings and stayed on).
- **FX in Watch now, off by default.** The FX button / switch now works for a stream: it puts the player's live effects (sharpening, Detail, colour, frame generation, temporal) on top of the finished pieces. Off by default (the pieces already carry the work of the export; on a heavy size it adds lag); the choice is remembered. Auto stays out of streams.
- **Frame rate cap** (All frames / 30 fps / 24 fps) in the export screen: a 60 fps video is worked on at 30 fps = about twice as fast (every second frame left out, same quality per frame); also for Watch now. The time estimate follows it.
- Not compiled as an app and not run on a phone (brackets balance; strings en / fa equal, 1074). Please try: Watch now, press pause while the circle turns, then wait (it should show a paused picture); a longer video with the space limit at 300 MB and look at the storage; the FX button in Watch now.

## 3.92.6 - "Watch now (stream)", step 4: review leftovers
- **No resting between frames when streaming.** The "Balanced / Gentle" load setting made the work sleep after every frame; for "Watch now" that only made a phone that is slower than the video even slower (the work already idles by itself whenever it is far enough ahead).
- **The head-start wait never asks for more than can exist.** It is capped by the "keep ahead" setting (80 %), 24 s when the phone is nearly full, 48 s on Auto. Before, a 40 s wait with "keep 30 s ahead" could only end by the 45 s time-out.
- **One-time hint** when the measured speed stays under 0.8x of the video: says why it waits now and then and that a smaller size is smooth.
- Everything from 3.92.3 - 3.92.5 is in this build. Not compiled as an app and not run on a phone (brackets balance with a tokenizer-based check; strings en / fa equal, 1063).

## 3.92.5 - "Watch now (stream)", step 3: the stops, the restart-from-piece-start, a warning for heavy sizes
Reported on a Redmi Note 9 Pro at 4K: choppy, long stops, the picture stayed stopped although the next piece was ready until pause / play, and play started the piece over.
- **Why it stood still:** when the player ran out of finished pieces it asked for "the spot where the last piece ended" and looked for a piece that starts exactly there. The next piece starts a few ms away, so it was never found; worse, the work took the request as a jump, threw its place away and started decoding again (a long stop). Now: a 0.4 s tolerance on both sides; the player does not ask the work for anything when the work is already near that spot (it asks only after 4 s without a piece).
- **Restart from the start of the piece:** pressing play on a player that had run out of pieces called `play()` on an ended player, which starts the current item over. For a stream that is not at the end of the video, play now goes on from the spot instead.
- **Watchdog:** if the player should be playing but is not (not waiting for the work, not dragging) for about 2 s, it is put back at the very same spot by itself, no pause / play needed.
- **Warning before a heavy size:** "Watch now" cannot be smooth when the phone makes the picture slower than the video plays (4K on a middle phone is far below 1x). When the start is pressed, the guess of the speed is shown; if it is below about 1x the app offers the biggest smaller size that should be smooth (or "Keep my size"). The guess uses the speed measured on this phone; **it is now learned while watching** (before, only finished file exports taught it), so it gets accurate after the first watch. Before the first measurement it uses a default and may be too careful.
- Not compiled as an app and not run on a phone. Please try 4K and 1080p Watch now, a jump on the bar, and letting it run out of pieces and continue by itself.

## 3.92.4 - "Watch now (stream)", step 2: head start, richer picture, honest progress
- **Head start instead of stutter.** When the player reaches the end of what is ready (or you jump), it now waits until enough is ready ahead before playing: about the first piece on a phone that is as fast as the video, and `10 s / speed` (6..40 s) on a slower one, at most 45 s. The screen says "Preparing... x of y s ready". Before, a slower phone played one second, stopped, played one second.
- **Richer bit rate for the pieces** (x1.5, VBR, at most 40 Mbit/s): they are temporary, so the extra size costs only a little disk, and less of the upscaled detail is lost in the encoder.
- **Low free space:** under 400 MB free the work runs at most 30 s ahead.
- **Export screen for "Watch now"** no longer shows a percentage of the whole video (it meant nothing there): it shows how much is ready ahead of you (bar = against the "keep ahead" setting), whether the phone is faster or slower than the video, and the pieces / size on the phone now.
- Not compiled as an app and not run on a phone. Please try: a slow setting (the "Preparing" line, then smooth play), jumps on the bar, a fast setting (should still start at once), the export screen while watching.

## 3.92.3 - "Watch now (stream)", step 1: no double processing, honest speed, no leftovers
- **The player no longer runs its own effects on top of the streamed pieces.** The pieces were already upscaled and sharpened by the export, but the player's live pipeline (FX switch, Auto, frame generation, temporal clean-up, auto crop) ran on them again: everything was done twice (GPU load = lag, and the picture got over-sharpened). Now the pieces (and the finished file, when a file export ends while it is watched) are only shown: plain copy, cheap. New flag `plainView` in `PlayerActivity`; the FX button / switch shows off there, and pressing it explains why (`stream_fx_note`) without changing your saved FX choice. Auto no longer changes your saved settings while streaming.
- **Speed measurement fixed (streaming).** The time the work waits for the viewer was counted as slow work, and a jump forward counted as a huge speed. That made "Auto ahead", the start wait and the estimate wrong. The wait is now taken out and a jump starts a fresh measurement.
- **Leftover pieces are removed at once.** If the app was killed or the phone restarted while watching, the temporary pieces stayed on the phone for a week. Streaming folders now carry a marker (`stream.tmp`) and are deleted at the next export start and in the periodic cleanup (`VideoExport.cleanStreamLeftovers`).
- Not compiled as an app and not run on a phone (brackets balance in the changed files; strings en / fa equal, 1053). Please try: Watch now on a heavy setting (the picture should be smooth and the FX button off), jump around the timeline, kill the app while watching and check Storage afterwards.

## 3.92.2
The leftovers of 3.92.1 ("not included") are done where they make sense:
- **Contrast** is in the Picture look section of the video / GIF export too (it was never part of file exports). It is part of `Look` (`Fx.kt`) -> `fxFor(contrast = ...)`.
- **Cut the black bars (video export only, a switch under Picture look).** New `BarScan.kt`: before the size is chosen, nine frames spread over the video (or over the chosen part) are read with `MediaMetadataRetriever.getScaledFrameAtTime` at 192 x 108 and measured with the same rules as the player's live detector (a row / column is a bar when at most one pixel is lit; an all-black frame says nothing; a bar under 2.5 % is no bar; one row / column of margin; the smallest bar found in any frame is used, so a dark scene cannot make the crop bigger). With fewer than 4 usable frames nothing is cut. The result (left, bottom, right, top) is written to `bars.txt` in the job folder, so **a continued job uses exactly the same crop**. `VideoExport` then makes the output the shape of the picture inside the bars (short side = the chosen size, even numbers, 64..4096) and sets `GlPipeline.barL / barB / barR / barT`, the crop the player already uses (applied when the source is copied, so the picture is cropped on the GPU, not stretched). A video without bars is unchanged. When the export is started from the Library's Save the switch starts at the player's Auto crop setting, otherwise it starts off. The GIF export does not have this switch.
- **Batch (photos / manga, "live settings" quality):** the copied live settings now include the new ones (Shadows, Highlights, Saturation, Warmth, Film grain, Clarity, Anti-ringing, Deinterlace), as the photo viewer / reader shows them.
- Still not done: the time estimate on the export screen does not know about the extra passes (and not about the smaller size with cut bars): it is an estimate; I did not want to put in a number that was not measured. Output wider than 4096 px (e.g. 2.35:1 at 2160) is clamped like before, which would then change the shape slightly.
- Checked here: the bar rules were run on synthetic frames in a Python copy (2.35:1 letterbox -> bars 12 % top and bottom -> 1920x1080 source gives 2530x1080, aspect 2.343; no bars -> 0; all-black frame skipped; thin 2 px line ignored); brackets balance in the changed files; strings en / fa equal (1052). **Not compiled as an app and not run on a phone.** Please try a letterboxed film with the switch on (the file should have no black bars and the right shape), the same film with it off, a video without bars with it on (no change), and pause / continue a cut-bars export.

## 3.92.1
- **The new picture settings now go into the files that are saved as new files.** "Upscale a video to a new file" and the GIF upscale used only Sharpness / Vivid colours / Smart fix from the panel; **Shadows, Highlights, Saturation, Warmth, Film grain (3.91.0) and Clarity, Anti-ringing, Deinterlace (3.92.0)** were left out (3.92.0 said so). Now:
  - The export screen has a new section **Picture look** (video: under Smart fix in the custom settings; GIF: under Smart fix) with the same seven sliders and the Deinterlace choice as the player. They start at the player's current values when the export is started from the Library's **Save** (the screen takes over the live settings, as it already did for sharpness / colour), otherwise they start at 0 / off.
  - Code: new class `Look` (`Fx.kt`) holds the eight values and writes them as one short text ("" when everything is off). It travels in `ExportOpts.look` -> intent extra `look` -> `ExportJob.look` -> `VideoExport.fxFor(..., look)` -> `FxSet` (which now has the eight values), the same `FxSet` the live pipeline reads, so the file gets exactly the passes the player shows (colour pass with tone + grain, Detail pass with Clarity / Anti-ringing, Deinterlace before Denoise). It is also saved with an unfinished job (so Continue keeps it) and is part of the job id (another look = a new job, not a wrong resume). GIF: `GifOpts.look` -> `fxFor`.
  - Old unfinished jobs and old settings load as before (no `look` = all off).
- **Not included:** Auto crop of black bars (it changes the player view, not the picture) and the existing Contrast slider (it was never part of the file export; say so if you want it). Batch photo processing (`BatchService`) has its own settings and is unchanged. The time estimate on the export screen does not add anything for the extra passes (Clarity / Deinterlace cost a little).
- The sound side ("Save as a new file" in Edit audio) already carries **Speech mode** since 3.89.29 (`AudioCfg.snapshot()`), no change needed there.
- Checked here: brackets balance in the changed files (same counts as before), strings en / fa equal (1050), every `R.string` exists. **Not compiled as an app and not run on a phone.** Please try: Library -> Save on a video after setting e.g. Shadows +30, Grain 20 and Clarity +40 in the player (the new file should look like the player), then the export screen from the menu with the sliders set by hand; and pause / continue an export.

## 3.92.0
More picture settings, from the second suggestion list (Shadows / Highlights / Saturation / Warmth / Film grain were already in 3.91.0):
- **Clarity (local contrast)**: slider -100..+100 in the picture settings. Positive = more large-scale contrast (mid-tones most, so shadows and highlights do not clip); negative = a soft look. It is in the same pass as Detail (one pass, only when on).
- **Anti-ringing**: slider 0..100 %. On a hard step edge a pixel may not leave the two levels found 1.5 px away on both sides along the gradient, so halos from strong sharpening vanish; thin lines and soft ramps are untouched. Same pass as Detail / Clarity.
- **Deinterlace**: Off / rebuild odd lines / rebuild even lines. Only where the lines are torn (a line differs from both neighbours in the same direction) it is rebuilt from the lines above and below along the edge; still areas keep all detail. If one choice looks worse, use the other. Runs first in the clean-up chain (before Denoise).
- **Cut black bars automatically (video player)**: the whole frame is looked at about every 12 frames (192 x 108 copy); a bar must be pure black over the whole row / column; a change is applied only when 6 measurements in a row agree, and the player view then takes the shape of the picture inside the bars (the picture is cropped on the GPU, not stretched). Turning the switch off, or a new video size, puts the whole frame back. Screenshots keep the whole frame.
- Saved with the normal settings and in user profiles (clarity, antiring, deint); reset buttons and Quick profiles set them to 0 / off. Auto crop is a normal setting (key autocrop).
- Checked here: the changed shaders compile and run on a software OpenGL ES 3.2 driver (anti-ringing removes a synthetic halo, deinterlace rebuilds a combed block, clarity changes the local contrast); brackets balance in the changed Kotlin files; strings en / fa equal (1048). **Not compiled as an app and not run on a phone.** Please check Auto crop on a letterboxed film (the view should change shape once, a few seconds after start).
- Not done: these new settings are not used by the video file export (same as Shadows / Grain in 3.91.0).

## 3.91.0
- New picture settings (screen, player and photo viewer), all in the same settings panel under Contrast: **Shadows** (lift / deepen dark areas), **Highlights** (boost / pull back bright areas), **Saturation** (independent of Vivid colors), **Warmth** (cooler / less blue light ... warmer) and **Film grain**.
- They are saved with the normal settings and inside saved user profiles; the reset buttons and Quick profiles set them back to 0. They cost one extra multiply in the existing colour pass (no extra render pass).
- Not compiled / tested on a device in this build; the shader itself was checked offline.

## 3.90.0
- **New: "Free up space (shrink videos and photos)"** on the main screen (`Shrink.kt`, `ShrinkActivity.kt`). For a phone that is full, without a computer or the cloud: the biggest videos (8 MB and up) and JPEG photos (1.2 MB and up) are listed with their size and a guess of the size afterwards; tick some, pick Balanced / Small / Tiny, and they are written again, smaller, into Movies / Pictures -> ClearOverlay -> Shrunk. The originals are not touched; afterwards a box offers "Delete the originals" (phone's own trash / allow box, only for files that really got smaller) or "Keep both".
  - **Video:** decoded and encoded again as H.265 (HEVC; H.264 if the phone has no HEVC encoder) at 55 / 40 / 28 % of the old bit rate (never below 0.03 bits per pixel), same picture size, frame times and turn; the sound is copied as it is (a sound the MP4 file cannot hold is left out). HDR videos and H.265 files that are already thin are skipped. A result that is not at least 8 % smaller is deleted again.
  - **Photo (JPEG):** written again at quality 88 / 80 / 70 (Tiny also at most 3000 px). The turn is applied to the pixels; GPS / camera EXIF is not copied, the date taken is.
  - Runs while the screen stays on (progress window with Cancel); do not leave the app during a long video.
- Checked here: the new files parse with the Kotlin compiler (only "unresolved Android class" errors, because the Android SDK is not available here); strings en / fa added in pairs. **Not compiled as an app and not run on a phone.** Please try: one short video (Balanced), one photo, then "Delete the originals".
- The other items of the earlier list (rotation, NIS original in photos, Bluetooth earbuds, Boost, 6K, playlists with many songs, Auto) were already done in 3.89.32 - 3.89.34.

## 3.89.34
- **Auto (video / photo player) is better and tells you what it did.**
  - **Explanation line:** under the Auto switch the panel now shows, live, what Auto chose: profile and GPU budget, source size -> shown size (and the enlargement), the upscaler, the kind of picture it sees (dark / animation / soft / detailed), and a note when frame drops lowered the budget or when it switched the temporal clean-up on. It updates whenever Auto changes something (before, only a short toast said it).
  - **It gives the budget back:** when frames were dropped Auto lowered the GPU budget for the rest of the video, so one bad scene made the whole film worse. Now, after a calm minute without drops, it raises the budget one step again. If the raise is followed by dropped frames within 40 s, it stays lowered for that video (no flip-flopping).
  - **Heavily compressed video gets the light temporal clean-up** (the previous frame, moved along the motion, is blended in) when the file has fewer than 0.07 bits per pixel, the GPU budget is Balanced or Quality and the video is not above about 1080p60. Auto switches it off again for the next video that does not need it (it never touches a value you set yourself higher). The bit rate must be known, so streams without one are left alone.
- Not compiled as an app here (parse check only, strings en / fa equal, 1005 each). Please check: open a video with Auto on and read the line under the switch; a long video on a weak phone (budget should come back after a minute without drops).

## 3.89.33
- **Playlists: pick many songs at once.** Inside a playlist the chip row has a new chip "＋ Songs" (and a new playlist opens the same picker right after you name it): every song of the phone with a search field, tap to tick several (a count shows how many), "All / none" ticks everything shown (the search result when you typed one), OK adds the new ones in library order and takes out the ones you un-ticked. Long-press a song still works for one song. (`AudioActivity.pickSongsDialog`, `MusicLists.addAll / removeAll`.)
- **6K output size.** The Output resolution row (live settings, player and photos) has a new "6K" chip (short side 3240, e.g. 5760x3240). The size limits for saving a photo / video frame at the chosen output size went from 16.8 to 19.5 megapixels so a 16:9 picture at 6K can be saved. It is heavy for the GPU and memory; video file export stays at the encoder's 4096 px limit (the export now keeps the shape when it has to cut: before, a long side cut at 4096 squeezed the picture; the export takes at most 4K from this setting).
- **Screen direction in the player: the landscape / portrait key is no longer remembered.** It was saved for good, so after pressing it once every later video (also a portrait one) kept that direction, and only pressing the key again fixed it. Now each new file follows its own shape again; "Lock" and "Free" are still saved. The direction is also requested again every time the player comes back to the front. **If it still sticks, please tell me which screen (video / photo / reader / library), what you pressed and which direction it stayed in.**
- Already in 3.89.32 and checked here: NIS fast Light has no run-time array index (4 constant calls); Bluetooth earbuds pause the video (media session); Boost; NIS original in the photo viewer.
- Not compiled as an app here: all Kotlin files parse (Kotlin 1.9.24, no syntax error), strings en / fa equal (1001 each), every `R.string` used exists.

## 3.89.32
- **NIS original in the photo viewer no longer hangs / closes the viewer.** The shader kept its 6x6 window and its working values in arrays that are indexed at run time; phone GPUs put such arrays in slow scratch memory, so a many-megapixel photo took so long that the GPU watchdog killed the context. The shader is rewritten without those arrays (every window pixel is its own variable, the diagonal taps are picked with selects) and skips the edge detector wherever a window is flat (exactly the same result there). Checked offline against the old shader on 4 natural images x 3 scales x 3 sharpness values (11.4 million pixels): identical except 1 pixel that differs by 1/255. The band drawing for big pictures now adapts: it starts with small bands for NIS original and halves a band that took over 0.25 s (doubles one under 40 ms), so no single GPU submission can run long.
- **Video pauses when Bluetooth earbuds are taken out of the ears** (or a headset / car / watch button is pressed). Taking earbuds out does not disconnect them, so the old "device removed" and "becoming noisy" checks never fired; the earbuds instead send a media pause key, and the video player had no media session to receive it (the key went to the music app). The player now owns a media session while a video is open (play / pause / stop / seek, with a proper playback state).
- **Boost (extra sharpening pass) works at every sharpness setting.** Measured offline (FSR, natural images): the old extra pass repeated the same strength, so at a low slider it changed almost nothing (sharpness 0.642 -> 0.650 at 15%: it looked broken) and at a high one it doubled an already strong pass (100%: halo 62, SSIM 0.76 -> 0.32). The extra pass is now strong where the normal pass is weak and gentle where it is strong: it adds about +0.06 to +0.11 sharpness at every slider position with small halos.
- Not compiled or run on a phone here. Please check: a big photo with NIS original; a video with Bluetooth earbuds (take one out); Boost on / off at a low and a high sharpness.

## 3.89.31
- Anti-aliasing: **FXAA Quality no longer blurs.** Its edge threshold and sub-pixel blend were too aggressive
  (at 100% it lost ~0.23 SSIM on aliased test scenes, now ~0.015). Same shader, safer constants.
- New AA mode **Smart Edge**: edge-directed, smooths only hard 1-pixel stair-steps, along the edge, and skips
  soft detail / texture. Sharpness kept at ~94-97% (Edge Smooth / FXAA lose more), clean photos nearly untouched.
- Measured with the software GL harness on synthetic game/text/anime (aliased) and photo/soft (clean) sets; not run on a phone.

## 3.89.30
- **Quick profiles measured and retuned, two new profiles: Dark and Busy.** The app's own shaders (denoise, deband, anti-aliasing, FSR 1 EASU, RCAS, Detail) were run in a software OpenGL ES driver in the order of the player pipeline, on test pictures made from real photos (astronaut, cat, coffee, rocket; grass / gravel / hubble / retina for Busy) and from synthetic art (flat-colour "anime" made by mean-shift + ink lines, halftone "manga", text pages, a game-like scene sampled without anti-aliasing). Each scenario has three degradation levels (Light / Balanced / Strong: downscale x2 + blur + noise + JPEG quality 60..15, banding, point sampling for games, heavy blur for Repair); each profile was searched (coordinate search over Sharpness, Detail, Detail radius, Denoise, Deband, AA type and strength) against the clean original, with SSIM + PSNR and a sharpness ratio, and checked on different crops (held out).
- **Result (held out, mean of all 33 cases, SSIM / PSNR / sharpness ratio):** old table 0.7444 / 24.94 dB / 0.81; new table **0.7568 / 25.06 dB / 0.83**; no processing 0.7376 / 24.99 dB / 0.77. Biggest gains: Text +0.04 SSIM, Manga +0.04, Anime +0.008, Game +0.003..+0.04, Busy +0.006..+0.012; Video / Stream / Photo / Movie / Repair +0.001..+0.005. Dark equals the old Video row (no measurable gain, kept as its own profile because noise in the shadows is the main problem there).
- **What changed in the tables:** the old tables denoised and debanded too much (the test showed lower SSIM than no processing at all for Photo, Stream, Busy): Denoise / Detail / Deband are lower for Video, Stream, Photo, Movie; Edge-Smooth AA is off for Photo, Anime, Movie (it softened); Anime keeps its Denoise (flat colours love it) but loses the AA; Text gets a moderate Denoise (it removes JPEG ringing around the letters; was almost none) and a tighter Detail radius; Manga gets a stronger Detail (0.75 - 0.90) and +0.10 Sharpness (line art gains most from sharpening: sharpness ratio 0.57 -> 0.66); Game: lower Sharpness (0.35 / 0.48 / 0.58, sharpening aliased edges makes them worse) and almost no cleanup, FXAA stays. Values are the optimum moved 60 % of the way from the old values (the test pictures are synthetic), the strength ladder never goes down, and Game / Manga / Text / Dark / Busy were set by hand from the measurements (see `tune` notes below). The screen-overlay table is not measured: it was moved by the same change as the player table (scaled: Denoise x0.45, Detail radius x0.6).
- **Auto (player) now also picks the profile from the picture:** a dark scene -> Dark, animation -> Anime, busy -> Busy (before only animation). **Auto's upscaler per kind** from the same test (all NIS modes and FSR 1 were within 0.003 SSIM of each other on most kinds, so these are small differences): animation -> NIS soft (Aura, the old choice, was the worst NIS mode on animation; soft equals FSR 1), busy -> NIS soft with the Quality budget (NIS original was the worst on busy pictures). Dark / soft stay NIS soft.
- **Limits, honestly:** SSIM / PSNR on synthetic degradations are not a viewer's opinion (they favour a little less processing than people like, hence the 60 % step and the hand-set kinds); CRSC Edge (the multi-pass upscaler used for stills / Quality budget) was not part of the test; real video has motion, grain and compression that were not simulated; the overlay table is derived. Judge by eye with FX on / off and Zoom, and tell me which profile looks worse. Not compiled as an app here; brackets balance in the changed files; strings en / fa equal.

## 3.89.29
- **Sound: new "Speech mode (make talking clear)"** in the sound panel (music screen and the video player's sound dialog): a switch + a "Speech clarity" slider (the switch sets 70 %). It is a layer on top of the presets and sliders, saved as `AudioCfg.speech`, and it is also used by the sound export / Edit (it is part of `AudioParams`). What it does (all in `AudioFxCore`, no new library): the dialogue lift at 2.8 kHz (at least 80 % of the amount, up to about +5.6 dB), the muddy low-mids at 320 Hz down (up to -5 dB), the consonants at 6 kHz up (up to +4.5 dB), the side signal of a stereo sound turned down to 30 % (music, room and panned effects about 10 dB quieter, the centred voice stays), at least 75 % of the levelling (loud and quiet words closer), the rumble filter and the hiss gate (threshold up to about -36 dBFS). Mono sound gets everything except the side reduction. Checked: the filter response of the three bands at 70 % (-3.4 dB at 320 Hz, +4.7 dB at 2.8 kHz, +4.0 dB at 6 kHz); not listened to here, so judge by ear and use the slider.
- **Quick profiles show what they really set**: under the description of the chosen profile a second line lists the upscaler and the Sharpness / Detail / Denoise / Deband / anti-aliasing values now in force (read back from the live settings, so it is right for every strength, GPU budget and Auto).
- Not changed (known): tapping a quick profile or Reset does not touch NIS crispness / NIS fast level. Not compiled as an app here; brackets balance, strings en / fa equal (no missing, no duplicate, same format arguments).

## 3.89.28
- **Check of 3.89.8 - 3.89.27 (upscaling), two small fixes.** (1) `GlPipeline.snapshotNow` always drew one more full frame into the window after a snapshot, also for the offscreen users (manga pages, GIF frames, batch) that never show the window; with the 2x2 surface they use, that was a whole extra supersample + sharpen pass thrown away after every page / frame. It is skipped when `manualOnly` is set. (2) The per-section settings list (`Cfg.SECTION_KEYS`) lacked `crscnisfast` and `nisfastlevel`, so a first-time video / photo / manga / GIF section started with Standard crispness and NIS fast level Exact instead of the screen's values; both are copied now.
- Checked, no error found: all 34 fragment shaders compile and link in a software OpenGL ES 3.2 driver (the two textureGather ones with the ES 3.1 vertex shader); `NIS_FAST_G` (gather) against `NIS_FAST` at all three levels, fed with the app's own `NIS_LUMA` output: **identical in every pixel** on 3 pictures x 2 sizes; strings en / fa equal, no duplicates; every `R.string` used exists (`cancel`, `copy`, `ok` are `android.R.string`).
- Known, not changed: a crispness / NIS fast level set in the live settings also applies to a video export started afterwards (the pipeline reads `Cfg` directly, not the export's own settings), and the export time estimate ignores the upscaler. Not compiled as an app here.

## 3.89.27
- **Comic files show their first page in the library (Manga tab).** A .cbz / .zip / .cbr / .rar / .cb7 / .7z / .pdf found in a folder you added (and a comic in the history that was opened as a file) used to show only the book icon; it now shows its cover, like a thumbnail: the first page (in the same natural order the reader uses), cut to a square that starts near the top where a cover's title is. New file `BookCovers.kt`: built in the background the first time (two at a time, so the list stays smooth), then kept as a small JPEG in the cache and in memory, so the next time it is instant. The file is read in place when the phone allows it (zip / pdf: no copy); only when it cannot be opened that way is it copied to the cache (files over 400 MB are skipped). A file with no readable first page (a compressed RAR5, an encrypted file) keeps the book icon. Image folders already had their cover and are unchanged.
- **Photo / video zoom now fills the whole screen.** A wide picture (a film frame, a 2.39:1 screenshot) is fitted as a strip in the middle of the screen, and zooming only enlarged the picture inside that strip (black above and below stayed unused). Now the picture view grows with the zoom, up to the whole screen: at 2.5x the strip is 2.5x taller, and from about 4.6x on (for a 2.39:1 picture on a 20:9 phone) the picture fills the screen from top to bottom, like a normal photo viewer. Pinch still zooms around your fingers, one finger pans, double-tap = 2.5x / back to fit, and the 1x / 2x / 4x / 8x button works the same. The zoom is still taken from the real source pixels and goes through the whole pipeline (the pipeline got a crop window with its own width and height fractions, `zoomWX` / `zoomWY`); at 1x nothing changes. Fill-mode videos, whose picture is already bigger than the screen, behave as before.
- When the view changes size the picture is drawn again twice (the second time 80 ms later) so that no stretched frame stays on screen.
- Not compiled or run here (no Android build tools): please build and check (1) the Manga tab of the library and (2) zooming a wide photo, and a rotation while zoomed.

## 3.89.26
- **Build fix**: the English text `res_chain_hint` stopped the resource step ("Invalid unicode escape sequence" at that string). It had an apostrophe that aapt2 reads as a broken escape; it now uses the typographic apostrophe, so there is nothing to misread. No other change.

## 3.89.25
- **Check of 3.89.23 / 3.89.24; two fixes.** (1) The library scan (3.89.23) listed every .rar / .7z file of the phone as a comic; it lists only .cbz / .cbr / .cb7 / .zip / .pdf again. (2) Comics on a network server (.cbr / .cb7 / .rar / .7z) were refused with a message before they reached the reader; the reader recognises the type itself, so they open like a .cbz. Braces / parentheses of the changed files checked. Not compiled, not tested on a phone.

## 3.89.24
- **Photo / video zoom goes where you pinch.** The pinch used to zoom around the middle of the picture, so the part you wanted slid out of view and you had to pan back; now the point under your fingers stays under them. **Photos: double-tap zooms in 2.5x at the finger, double-tap again goes back to the whole picture** (videos keep double-tap = seek / play). Not compiled, not tested on a phone.

## 3.89.23
- **Manga:** a 3200 px page was decoded at half size (1600 px) because of the sample-size loop; pages are now decoded at 3000 px or more on the long side (still within the 8 MP limit). Pages get mipmaps (a big page shown small is no longer jagged). When a page is fixed / upscaled while you are zoomed in, the zoom and position stay (they used to jump back to "fit").
- **Manga: .7z / .cb7 archives open** (commons-compress 1.26.1 + xz 1.9; the pictures are unpacked once into the cache like RAR). Password-protected or damaged archives show an error; a .7z with a huge LZMA dictionary may run out of memory on a weak phone. Library scan lists .cb7 / .7z / .rar books too.
- **Quick profiles:** the nine profiles are a grid of cards (3 per row) and Strength / GPU budget are equal-width rows, all visible without scrolling.
- **Zoom button back on the player's top bar** (1× / 2× / 4× / 8×) next to FX; it had been hidden behind the tools menu.
- **Artemis:** every visible "Moonlight" is now "Artemis" (en + fa). The logo is the one inside the embedded client; it could not be compared with the real Artemis logo here (no network access to GitHub).
- **Music:** Favorites and playlists. A row above the song list: All / ♥ Favorites / your playlists / ＋. Long-press a song: add or remove favorite, add to a playlist (or make a new one), remove from this playlist. Long-press a playlist chip to delete it. Stored as uris.
- **Headphones out = the video pauses:** already in 3.89.x (ExoPlayer's "becoming noisy" + an audio-device callback); no change.
- **Input resolution choice removed** (the file's own size is detected; Middle does the same job). Saved Input values are ignored. Hints rewritten.
- Not compiled and not tested on a phone.

## 3.89.22
- **Check of 3.89.15 - 3.89.21:** mode lists, chip counts, saved-mode ranges (0..10), Crispness range (0..4) and brace balance checked; no error found. One cleanup: the old NIS mid shader is no longer compiled at start (it was unused since 3.89.20: wasted start-up time). Not compiled, not tested on a phone.

## 3.89.21
- **NIS mid is sharper: push 0.75 (was 0.55) times NIS fast.** Measured (4 photos, 2x, slider 50%): edge sharpness bilinear 0.134, Aura Standard 0.184, NIS mid 0.55x 0.191, **NIS mid 0.75x 0.206**, NIS original 0.224; halos 0.083 / 0.117 / **0.235** / 0.453. So Aura < NIS mid < NIS original in sharpness. Not compiled, not tested on a phone.

## 3.89.20
- **NIS mid is now NIS fast "Medium" with about half the push** (uSharp x 0.55), not the separate 4x4 / 4-tap shader. Measured against NIS original on 4 photos (2x): the old NIS mid matched NIS original at half the slider value only at 44 dB (a different, simpler filter); NIS fast Medium with the lower push matches NIS original at that lower value at 65 dB, i.e. the same picture, only less sharp. Cost: Medium reads 17 taps in flat areas and 37 elsewhere (the old mid always 16), so mid is not lighter than Medium itself. `NIS_MID` shaders stay in the file, unused. Not compiled, not tested on a phone.

## 3.89.19
- **NIS fast is back to Standard / Mid** (a small row under the chip; Exact / Medium / Light stays under Standard), as in 3.89.16. The four-level row of 3.89.17 is gone. Crispness keeps its four levels (3.89.18).
- Not compiled and not tested on a phone.

## 3.89.18
- **Crispness has four levels (Soft / Medium / Strong / Max) plus Off.** The push is 0.45 / 0.9 / 1.35 / 1.8 times the slider value on plain upscalers (Max = the old level 3, about NIS original's sharpness) and 0.15 / 0.3 / 0.45 / 0.6 on Aura / NIS / NIS fast / NIS mid. Saved levels keep their number, so an old "Strong" (3) is now Strong (a bit lighter than before: 1.35 instead of 1.8). Same shader, same cost.
- Not compiled and not tested on a phone.

## 3.89.17
- **NIS fast now has four levels in one row: Exact / Medium / Light / Mid.** The separate Standard / Mid row is gone (Mid is the fourth level; mode values unchanged). The Crispness change of 3.89.16 only changed uniform values, the same shader runs, so it costs the same.
- Not compiled and not tested on a phone.

## 3.89.16
- **Crispness levels calibrated against NIS (original)** (software OpenGL ES 3.2 driver, 4 photos, 2x upscale, slider 50%). Before: on a plain upscaler level 3 reached only 89% of NIS original's edge sharpness, and on NIS mid level 1 was already about NIS original while levels 2 / 3 sharpened 1.15 / 1.3 times more, with 2.4 / 3 times the halos (the "picture gets worse" effect). Now: on FSR 1, SGSR 1, Fast, CRSC Edge, Sharpen the three levels push 0.6 / 1.2 / 1.8 times the slider value (level 3 is about NIS original's sharpness); on Aura / NIS / NIS fast / NIS mid they push 0.2 / 0.4 / 0.6 times (NIS mid + level 3 is about NIS original). Only the push values changed.
- **NIS mid left as it is.** Measured: it equals NIS original at about half the slider value (44 dB against NIS original at 25%), so it is "NIS original, lighter, less sharp"; the earlier note of "about 10% less sharp" was wrong (about half the push).
- Not compiled and not tested on a phone.

## 3.89.15
- **NIS Lite renamed to "Aura"**, and the upscaler list is shorter: "Aura soft" is no longer its own chip but the **Soft** choice in a small row under Aura (Standard / Soft); "NIS mid" is the **Mid** choice under NIS fast (Standard / Mid). The stored mode numbers did not change (6, 8, 9, 10), so saved settings, presets and Auto keep working. Saved file names: Aura / AuraSoft / NISFastMid.
- "NIS crispness" is now just **Crispness**.
- Not compiled and not tested on a phone (UI code in `Controls.kt` and strings only).

## 3.89.14
- **NIS fast Light (and Medium's detector call is unchanged): no run-time index into the private array.** Light picked its edge-detector support pixel with run-time arguments (`edgeAt(fr.y >= 0.5 ? 1 : 0, ...)`), which makes the shader index the array `P` with a run-time value; some GPUs put such an array in slow memory (same problem as fixed in 3.89.7), which can make Light slower than Exact. It is now four calls with constant arguments inside `if / else`, in both `NIS_FAST` and `NIS_FAST_G`. Same maths. Checked: 180 cases (Medium and Light, normal and gather shader, sizes 1x1 to 160x90, 6 picture kinds, 3 scales) **identical in every pixel to 3.89.13** (largest difference 0). Not timed on a phone.

## 3.89.13
- **Check of the 3.89.12 file** (the chat that made it ended without notes): the file is complete. Everything 3.89.12 describes is in the code (`NIS_LUMA`, `NIS_FAST_G`, `NIS_MID_G`, `gatherUsable`, `ensureLuma`, `lumaPass`, `nisGatherProg`, teardown in `release()`), version and README matched, nothing was cut off.
- **Safety net for the gather path (the only code change):** the first frame drawn with a gather shader is checked once with `glGetError`. If the driver reports an error (luma pass or draw), the gather path is switched off for that GL context and the frame is drawn again with the normal 3.89.11 shaders. Before, a driver that links the shader but misbehaves would have shown a wrong picture with no fallback. `gatherState = -1` still turns the whole path off by hand.
- **New offline test of the gather shaders, on edge cases the 3.89.12 test did not cover:** 1673 cases: sizes from 1x1, 2x2, 1x7, 7x1, 3x5 up to 333x5 and 160x90 (the border path is used almost everywhere), 7 kinds of picture (noise, checkerboard, stripes, gradient, diagonal edges, almost-flat noise, circle), scales 0.75 to 4, sharpness 0 / 0.5 / 0.7 / 1, NIS fast Exact / Medium / Light and NIS mid, each against the normal shader: **identical in every pixel (largest difference 0)**.
- Also checked: all 37 shader variants in `Shaders.kt` compile and link (software OpenGL ES 3.2); all Kotlin files parse with the Kotlin 1.9.24 compiler (no syntax error; every reference between the app's own files resolves); strings en / fa: 969 each, no missing, no duplicate, equal format arguments; mode value 10 and the export bit layout (mode 0-7, size 9-10, frame generation 8 / 11-14, AI 15-17 / 20, temporal 18-19, CRSC 21-23, Smart fix 26) do not overlap; saved settings, profiles and profile import accept modes 0..10 and keep the NIS sub-settings.
- **Still not done here (no Android SDK / Maven access):** a real build and a test on a phone. The gather path should be a clear saving of texture fetches on a GPU; the real gain depends on the phone.

## 3.89.12
- **NIS fast (Exact / Medium / Light) and NIS mid: a quarter of the texture fetches, the same picture.** On devices with OpenGL ES 3.1+ (all ES 3.2 phones) the luma of the source is computed **once per frame** into an R32F texture (`Shaders.NIS_LUMA`, one pass at the source size, same formula as `getY`), and the two shaders read it with `textureGather` (4 pixels per fetch): NIS fast 9 fetches instead of 36 (Medium / Light: 4 for the flat test, 13 otherwise), NIS mid 4 instead of 16, and no luma arithmetic per tap. New shaders `NIS_FAST_G` and `NIS_MID_G` (`#version 310 es`); the formulas, thresholds, weights and the sharpening factor are untouched.
- **Safe fallback:** the gather path is used only when the context is ES 3.1+, a float render target exists (core in 3.2, `GL_EXT_color_buffer_float` before), the R32F target is complete and both shaders link. Any failure switches it off for that GL context and the normal shaders of 3.89.11 are used, as before. Nothing to set.
- Checked by compiling everything in a software OpenGL ES 3.2 driver and rendering 540 cases (5 picture sizes from 5x3 to 160x90, 6 kinds of picture incl. noise, checkerboard, stripes, gradients, 6 scales 0.75 to 4, 3 sharpness values; the tiny pictures use the border a lot) for NIS fast at all three levels and NIS mid, against the 3.89.11 shaders: **identical in every pixel (0 differing values of about 1.3 million)**. On the CPU test driver (which is not fetch-bound like a phone GPU, and where the luma pass and an upload are included) the gather versions took 77 %, 89 %, 69 % and 83 % of the time of the normal ones (NIS fast Exact / Medium / Light, NIS mid).
- **Not tested on a phone, Kotlin not compiled here** (new code: `gatherUsable`, `ensureLuma`, `lumaPass`, `nisGatherProg` in `GlPipeline.kt`, and the program teardown). The extra memory is one R32F texture of the source size (about 8 MB for 1080p). If a build error shows up, or the picture looks different on your phone, the first thing to try is `gatherState = -1` in `gatherUsable()`, which turns the whole path off.

## 3.89.11
- **NIS fast (all three levels) and NIS mid: a little less work, the same picture.** Two changes inside `Shaders.NIS_FAST` / `Shaders.NIS_MID`, no change of any formula, threshold or weight:
  1. The edge detector now decides "does anything fire?" before it does the division for the edge weights, and returns zero at once when nothing does (before, it computed the division first and returned the same zero afterwards). This helps every pixel that is not flat but has no real edge (texture, noise, gradients).
  2. The two phase weight sets of the plain filter (6 / 4 taps) are computed once and reused by the 0 and 90 degree filters (before, each of those filters computed the same polynomials again).
- Checked by compiling old and new shaders in a software OpenGL ES 3.2 driver and rendering 432 cases (4 picture sizes, 6 kinds of picture incl. noise, checkerboard, stripes and smooth gradients, 6 scales, 3 sharpness values) for NIS fast Exact / Medium / Light and NIS mid: **identical in every pixel (largest difference 0)** for all four.
- Speed: on the CPU test driver 0 - 7 % less time (NIS fast Exact 0 %, Medium 6 %, Light 5 %, NIS mid 7 %). That driver is not a phone GPU, so the real saving is for you to feel. Bigger savings need a change of the picture (fewer taps, as in Medium / Light) or a luma pre-pass with its own texture that could not be tested here.

## 3.89.10
- **NIS mid: less work per pixel, the same picture.** One change inside `Shaders.NIS_MID`, no change of any formula, filter, threshold or the sharpening factor: pixels whose 4x4 neighbourhood lies inside the picture read their 16 taps with constant offsets (`texelFetchOffset`), so there is no per-tap clamp / address arithmetic (the clamped reads are kept for the border pixels). Same method as NIS fast in 3.89.7.
- Checked by compiling the old and the new shader in a software OpenGL ES 3.2 driver and rendering 288 cases (4 picture sizes from 9x7 to 160x90, 4 kinds of picture incl. checkerboard and noise, 6 scales 0.75 to 4, 3 sharpness values; small pictures so the border path is used a lot): **identical in every pixel (largest difference 0)**.
- Speed was not measured on a phone (the test driver runs on a CPU). The saving is real work removed; how much it is depends on the GPU.

## 3.89.9
- **NIS mid added to the 3.89.8 line** (it existed only in 3.67.0, which was built on the old 3.66.0 base). Same shader as 3.67.0 (`Shaders.NIS_MID`), mode value 10, chip "NIS mid" next to NIS fast, upscaler chip in video / GIF export, saved files say `NISMid`. NIS fast with its Exact / Medium / Light levels is unchanged.
- **Fix:** profile import clamped `mode` to 0..8, which silently turned NIS fast (9) into NIS Lite soft (8); it is 0..10 now (same for the saved setting in `Cfg`).
- **Fix: saved profiles (UserProfiles) now keep the upscaler sub-settings**: CRSC Edge level, CRSC exact mode, NIS crispness (strength and Crisp Fast) and the NIS fast quality level were not stored, so loading a profile kept whatever was set before. Old profiles load as before (missing keys keep the current value).
- **Fix: a refused shader no longer breaks the pipeline.** NIS mid and NIS fast (Exact) were built unprotected when the GL pipeline starts; if a phone's driver rejected one of them, the whole viewer would fail to start. Now each falls back to NIS (original), which uses the same uniforms.
- Checked here: every shader in `Shaders.kt` (NIS fast at all three levels, NIS mid, NIS crispness shaders) compiles and links in a software OpenGL ES 3.2 driver; string keys used by the code exist in en and fa; mode value 10 fits the export bit layout (low 8 bits). Against NIS (original) on synthetic pictures: NIS fast Exact differs by at most 1/255; Medium by up to 7/255 on hard edges (1/255 on noise / gradients); Light and NIS mid differ much more on pure noise (PSNR about 23 - 35 dB), as designed. Not compiled as an app here and not timed on a phone.

## 3.89.8
- **NIS fast now has three quality levels, like CRSC Edge: Exact / Medium / Light** (a chip row "NIS fast quality" under the mode chips, shown only while NIS fast is selected; saved as `Cfg.nisFastLevel`; Exact is the default, so nothing changes unless you pick another one).
  - **Exact**: the shader of 3.89.7, as before.
  - **Medium**: where the 4x4 middle of the 6x6 neighbourhood is flat (no edge is possible there) only those 16 taps are read, the weights made to add up to 1 again, instead of 36. Measured against NIS (original) on 6 real pictures, 3 sizes: mean difference 0.038 / 255 (Exact 0.030), PSNR 61.7 dB (Exact 63.7).
  - **Light**: Medium plus one edge-detector call (nearest support) instead of four mixed ones. Mean difference 1.25 / 255, about 21 % of pixels differ by more than one level, PSNR 38.4 dB: nearly the same picture, a little different on edges.
  - How much work is saved depends on the picture: in the test pictures 2 - 63 % of the pixels were flat (Medium reads 17 instead of 37 taps for them). On a GPU, neighbouring pixels run together, so the real saving is smaller than that count. Not timed on a phone.
- **Honest note about "distance from NIS (original)": it is not zero.** Exact differs by at most 1 / 255 on 11 of the 12 test renders (about 2.6 % of pixels differ by one level, the polynomial fit of the filter tables). On one render (picture 'coffee', x3) 229 pixels in the very first column of the picture differ a lot: there the original gives a dark (7, 0, 0) although the source pixel is (20, 12, 6) and its neighbours are similar, while NIS fast gives (20, 12, 7). So in that case the original is the odd one; it was not looked into further.
- Checked: all three shaders compile and link in a software OpenGL ES 3.2 driver, strings en / fa equal and without duplicates. Kotlin (Cfg, GlPipeline, Controls) not compiled here.

## 3.89.7
- **NIS fast: less work per pixel, the same picture.** Two changes inside `Shaders.NIS_FAST`, no change of any formula: (1) pixels whose 6x6 neighbourhood lies inside the picture read their 36 taps with constant offsets (`texelFetchOffset`), so there is no per-tap clamp / address arithmetic (the clamped loop is kept for the border pixels); (2) the two diagonal branches no longer index a local array with a run-time value (that forces slow private memory on some GPUs); it is a plain select now.
- Checked here by compiling both shaders in a software OpenGL ES 3.2 driver and rendering 135 cases (4 pictures x 5 scales, 0.75 to 3 x 3 sharpness values, small pictures so the border path is used a lot): the new output is **identical to the old NIS fast in every pixel (largest difference 0)**; both stay within 1/255 of NIS (original), as before.
- Speed was **not** measured on a phone (the test driver runs on a CPU, where the two run the same). The saving is real work removed, but how much it is on your GPU is for you to feel; if it is not enough, the only bigger saving needs a fixed-point luma pre-pass (one more pass and texture), which I did not add without a way to test it.
- Not compiled as an app here (Kotlin unchanged apart from the version number).

## 3.89.6
- **NIS crispness: the second choice is now called "Crisp Fast" and is really lighter than Standard.** (3.89.0 had it as "NIS fast", the general NIS fast upscaler shader run at scale 1: that was heavier than Standard, because Standard's `NIS_SHARP1` is made only for scale 1.) New shader `NIS_CRISP_FAST`, the same picture as Standard:
  - the 8 neighbours are read once with 3 + 3 coordinate clamps instead of a clamp per read, and the values already read are reused by the direction filters (Standard reads 4 of them again);
  - the strength / limit constants are worked out once on the CPU and passed as one uniform (`uCfg`) instead of about 20 operations per pixel;
  - only the filter maths in `poly()` runs in half precision (mediump); the edge detection, the weights and the pixel colour stay full precision. Running everything in half precision was tried first and rejected: edge decisions flipped on borderline pixels (up to 19/255 on a few pixels). A built-in `dot()` for the luma was rejected too (it rounds differently, same flips): the same formula as Standard is used.
  - Checked offline with the app's own shaders on a software GL driver (synthetic edges + noise, and the logo, sharpness 30 / 70 / 100 %): in full precision the new shader equals Standard (largest difference 1/255 on 1 pixel of about 130 000); with half precision emulated inside `poly()` the largest difference is 1/255 (2/255 on 2 pixels at 100 %), PSNR against Standard 61-73 dB.
  - If the phone's driver refuses the new shader, Standard is used instead. The saved setting keeps its key (`crscnisfast`), so it carries over. Texts: row names "Standard" / "Crisp Fast", hint updated.
- **Not measured on the phone** (no phone here): how much faster it is depends on the GPU. Standard stays as it was, so the two can be compared.

## 3.89.4
- **Status bar pulled in over a full-screen screen**: when you swipe down from the top edge to see the clock and battery, the top bar of the video player, the manga reader and the GIF viewer now slides down out from under it (a short smooth move) and slides back when it leaves. The system gives the app no "bar is showing" signal for this (the window's insets say nothing changes), so the swipe itself is detected (a touch starting in the top 30 dp that moves down or is taken over by the system) together with the old system-UI-visibility callback; the bar stays down for about 3.8 s, the time the system keeps the status bar.

## 3.89.2
- **Build fix** (Actions log): `MangaActivity.kt` line 290 called `dp(32)` without a context (`The integer literal does not conform to the expected type Context`); it is `dp(this, 32)`. It was already broken in 3.86.0 / 3.87.0 (the manga top bar). No other change.

## 3.89.1
- The first choice of the new NIS crispness row is called **Standard** (it was "NIS (light)", easy to mix up with the NIS Lite upscaler). No other change.

## 3.89.0
- **NIS crispness now has two shaders**: under the level chips (Off / Light / Medium / Original) a second row appears while it is on: **Standard** = the sharpener of 3.87.0 (default, unchanged) and **NIS fast** = the NIS fast shader run at scale 1 on the finished picture (same strength mapping per level). Saved per section (`crscnisfast`), used by the player, screen layer, photos and export alike. The row is hidden when crispness is Off, so the panel stays short. Which one is lighter on a phone was not measured; try both.
- Not compiled or run on a phone here.

## 3.88.0
Brings the work of the 3.66.0 line (the NIS chat) into 3.87.0, plus bug fixes:
- **New upscaler "NIS fast"** (mode value 9; player / screen-layer mode chips, video-export upscaler chips, saved files say `NISFast`): the original NIS algorithm computed with less work, the same picture as "NIS (original)" (largest difference 1/255 in the tests of 3.66.0). The shader is copied unchanged from 3.66.0 (`Shaders.NIS_FAST`); it is wired in everywhere "NIS (original)" is: `Cfg`, `GlPipeline` (program, draw, post / boost passes, programs freed on release), `Controls`, `ExportActivity`, `OverlayService`, `PlayerActivity` (Auto message), `Stamp`, `MangaFx` (a photo result is kept within 8 megapixels for it too). It does not use the light "NIS crispness" shader of 3.87.0; that stays a separate switch.
- **Bug: adding a picture to a video of a portrait phone clip** (`StillInsert`): the decoder was allowed to turn the picture by the file's rotation while the encoder frame kept the stored size and the file's rotation was written again, so portrait videos (rotation 90 / 270) came out squeezed and turned twice. The decoder is now told not to rotate (`KEY_ROTATION` = 0); the rotation is written once, as before.
- **Edit video: a progress window** with percentage and a Cancel button for every save (picture insert, added sound, GIF, converted sound), instead of a one-second "Saving..." toast and no sign of life; cancelling no longer shows an error.
- **Edit video: errors now say why** (the error text is added to "Could not save the video"), so a failure on one phone can be reported exactly.
- **Edit video: Mute + Add sound (mix)** no longer mixes the original sound back in: with "Mute" the added sound replaces it.
- **Main screen: "Copy / move AI model files to a folder..."** (it was only in the player and manga menus).
- Not compiled or run on a phone here; brackets balance in the changed files; strings (en / fa) checked: no missing, no duplicate, equal format arguments.

## 3.87.0
- **Merge of two lines of work** (no new feature of its own): the other chats' 3.86.0 (bars at the edge, icons, manga bar, FX state, NIS crispness on every upscaler, quick video volume ...) plus these changes made on top of 3.83.0:
  - **NIS crispness is light**: the NIS (original) sharpener for the case where the picture already has its final size (all filter phases are 0) was rewritten: no coefficient tables, no 6x6 array, only the pixels of the detected edge direction are read, flat pixels cost 9 reads. Same formulas as NIS original at scale 1 (checked by hand, not run). All three levels (Soft / Medium / Strong) use it; if the driver refuses the shader, the older paths (NIS Lite / original) are used.
  - **CRSC Edge lighter, same picture**: flat-pixel early-outs of the edge smoothing, detail boost and edge steepening passes (the back-projection pass writes how flat each pixel's surroundings are into alpha). Measured by the author of that change on 90 cases: 63-101 dB PSNR against the full computation.
  - **CRSC Edge Max and Exact mode**: the quality chips end with *Max* (3 back-projection rounds, works live); the switch *Exact mode* turns the shortcuts off for every level (the picture exactly as before the lighter update); Max always works exact.
  - Build fix from that line: `row.isBaselineAligned = false` in MainActivity.
- Not compiled or run on a phone here; brackets balance in the changed files.

## 3.86.0
- **Top bars move down while the phone's status bar is pulled in** (clock, battery ... in landscape full-screen): `Edge.insets` only used `getInsets()`, which does not contain a bar that is shown for a moment by a swipe (it is drawn over the app), so the bar of the player / manga / GIF viewer ended up under the clock. It now also uses the real size of a bar while it is visible, and returns to the edge when the bar goes away.
- **Stretched / squeezed icons fixed everywhere** (gear, pencil ...): `LineIcon` scaled x and y separately, so any button with a non-square icon area deformed the icon. It uses one scale now and centres the icon.
- **Manga top bar**: the buttons shrink on a narrow screen so the title always keeps at least 100 dp and the last button (close) is no longer pushed off the screen; all six buttons are the same rounded chip; the page / scroll mode and the reading direction are drawn line icons (new `PAGE`, `STRIP`, `ARROW_L`, `ARROW_R`) instead of the text glyphs. The bar re-fits when the screen turns.
- **FX lit but not working, player**: the saved FX switch is loaded per kind (video / photo) by `Cfg.bind`, but the pipeline's bypass flag was only set when the button was pressed, so after opening the other kind FX looked ON while the pipeline was bypassed; the next press switched it off and only the second one on. `syncFx()` now puts the pipeline, the button and the panel switch back in step on resume, when the kind changes and on every press.
- **FX lit but not working, manga**: the off-screen renderer stayed off for ever after one failure and the first page (which also compiles the shaders) was given only 3 s. A failure is retried after 6 s, the first page gets 12 s, later ones 5 s, a stuck renderer is rebuilt, a failed page is retried once, and if it still fails a message says so (once) instead of silently showing the plain page.
- Not compiled or run on a phone here; brackets balance in the changed files; icon ids unique.

## 3.85.0
- **Quick volume of the video's own sound**: a speaker button in the top bar of the player (videos only) opens a small panel under it with a slider (0-100 %), a mute button and the percentage. It sets only the video's volume (`player.volume`), not the phone's volume and not the music's, so you can listen to music and watch a video together (turn the video down or mute it, keep the music on). The value is the same one the *Video sound* dialog uses and it is saved; the panel closes by itself after 3.5 seconds or when the controls hide. New icons `Icons.VOLUME` / `VOLUME_OFF`.
- **The video pauses when headphones / Bluetooth are taken off or switch off**, like the music. ExoPlayer's own handling of that was already on, but some phones (MIUI among them) do not send the broadcast for every kind of headset, so the removal of the audio device itself (wired, Bluetooth, USB, BLE, hearing aid) is watched too (`AudioDeviceCallback`, registered with the player and removed in `onDestroy`). Pictures are not affected.
- Not compiled or run on a phone here; brackets balance in the changed files; icon ids checked to be unique (the first id I picked collided with an existing icon and was moved).

## 3.84.0
- **NIS crispness now works on every upscaler**, not only CRSC Edge: FSR 1, SGSR 1, Fast, Sharpen and the NIS upscalers (and on the chosen-output-size path). It has its own box in the upscaler panel (visible for every mode except Original / RAW) with the same four choices: Off / Light / Medium / Original (heavy). The sharpener is one shared function now (`GlPipeline.nisCrisp`), CRSC Edge uses exactly the same code as before, so its picture is unchanged.
- How it is placed: upscaler -> NIS crispness (at scale 1) -> a lighter final RCAS (x0.6, as CRSC Edge already did). For SGSR 1 and the NIS upscalers, which normally draw straight to the screen, the crispness is the last pass and draws to the screen itself, so they cost one extra pass and no extra RCAS.
- Offline check with the app's shaders, x3, 70 % sharpness, compressed source: on FSR 1 level Light even raised PSNR / SSIM a little (26.68 / 0.748 against 26.54 / 0.738) with sharper edges; Medium is sharper at the same fidelity; Original (heavy) adds visible halos (overshoot 0.40 against 0.23). On Fast every level trades some fidelity for sharpness. On the NIS upscalers themselves it sharpens twice, so keep it low there.
- Export reads the same setting, so a file saved with a different upscaler now also gets the crispness that is switched on in the player.
- Bug hunt: strings (955 in English and Persian, no missing / duplicate / mismatched format arguments), manifest, cursors and media objects were scanned, nothing found; no change needed there.
- Not compiled or run on a phone here; brackets balance in the changed files. Making NIS crispness lighter is the next step.

## 3.83.2
- **Bars at the edge**: the top and bottom bars of the video player and the manga reader (and the GIF viewer) now sit at the very edge of the screen in full-screen mode. Only while the phone's own status bar is pulled in for a moment (clock, battery ...) do they move down / sideways, so they never overlap it; they go back when it leaves. (Before, the room of the hidden status bar was always kept free.)
- **Mini music player**: the share and close icons have square boxes again, no longer squashed flat.
- **Video**: pulling out the headphones (wired or Bluetooth) pauses the video, like the music player already did.
- **Music notification**: a media session gives the notification a seek bar you can drag (and the lock-screen / Bluetooth buttons work with seeking, next and previous).
- **Manga top bar**: about 1.3x bigger in every size setting; the page-mode and reading-direction buttons now use the same square chip as the icon buttons, and FX / gear / cloud / close line up.

## 3.83.1
- **Build fix**: `MainActivity.kt` line 387 used `row.baselineAligned`, which Kotlin does not know for a LinearLayout (the Java getter is `isBaselineAligned`). It is now `row.isBaselineAligned = false`, so the Kotlin compile step goes through. No other change.

## 3.78.0
- **Manga top bar size is now a setting that stays**: manga panel (the gear) -> Panel -> *Top bar size (FX, gear, cloud ...)*: Small / **Medium** / Large (icons 32 / 40 / 48 dp, text and FX grow with them). It applies at once and is remembered, so no later change can make it jump back. The default is Medium (a little bigger than before; before it was 32 dp).
- **Streaming card (the Moonlight section)**: the title now has the logo of the built-in streaming client (a ring with eight spokes, drawn in the app's accent colour). Note: that client is the Artemis fork and its own logo is this ring; the moon logo of the original Moonlight is not part of the project and could not be downloaded here. If you want that exact picture, send the PNG and I will put it in.
- Not compiled or run on a phone here.

## 3.77.0
Edit, round 4: **add a picture to a video** (shown for a few seconds).
- **Edit video -> Add a picture**: pick a photo (Library or files), choose **at the start / at the end / both** and how long (2 / **3** / 5 / 8 s). The picture is fitted inside the frame with black bars.
- This one **re-encodes** the video (new `StillInsert.kt`: decoder -> OpenGL -> H.264 encoder -> MP4), so it takes longer and loses a little quality, unlike the plain cut. The sound is kept (copied as it is and shifted when a picture comes first; silent while a picture is shown). The turn (rotate) setting and the cut part (from - to) apply. Works for one kept part, speed 1x, no joined clip and no added sound (the screen says so).
- Not compiled or run on a phone here. This is the riskiest piece so far (it talks to the decoder, GL and the encoder at once): if the saved video is empty, green or fails, send the error text.

## 3.76.0
Edit, round 3: **make a GIF**.
- **Edit video -> Output -> GIF**: an animated GIF of the part you cut (from - to), saved in Pictures/ClearOverlay. Choose the size (240 / **320** / 480 / 640 px on the long side) and the speed of frames (8 / **10** / 12 / 15 / 20 per second); the recommended choices have a star. The turn (rotate) and speed choices of the screen apply too. Up to 300 frames, no sound.
- New `GifWriter.kt`: the app's own GIF encoder (per-frame 256-colour palette by median cut, light Floyd-Steinberg dithering, LZW). The LZW part was checked against a real GIF decoder (Pillow) in tests, including the table reset of long frames; the Kotlin itself was not compiled here.
- Not compiled or run on a phone here.

## 3.75.0
Edit, round 2: **add sound**.
- **Edit music -> Add sound**: pick a song / voice / any sound (from the music Library or the phone's files), set its volume (-12 .. +6 dB); it is mixed with the song from its start and repeats when it is shorter. It is read and mixed piece by piece (new `PcmSource`), so a long file does not fill the memory. Works together with cut, fades, volume, speed, the enhancer and every output format.
- **Edit video -> Add sound**: pick a sound, then **Mix with the original** or **Replace the original**, and its volume. The sound is prepared as AAC, cut to the length of the picture and written next to the (still not re-encoded) video, so the result is an MP4. Limits (said in the screen too): one kept part only (not together with "remove the part", a joined clip or splitting); if the video has no sound, or its speed is changed, the added sound replaces the original.
- Not compiled or run on a phone here.

## 3.74.0
Edit, round 1:
- **Edit music: speed** (0.25x, 0.5x, 0.75x, 1x, 1.25x, 1.5x, 2x, 3x, 4x). It is a real change of the sound (the file is decoded, resampled and encoded again), and like a tape the pitch changes with the speed. Fades and the length follow the new speed.
- **Edit video: speed 0.25x** added (0.25 / 0.5 / 1 / 2 / 4 / 8; 1x is the default). The video keeps being cut without re-encoding, so a sped-up video has no sound. When the output is **audio only**, speed now works for real (before, only the time stamps were changed, which does nothing to sound).
- **Video only**: the sound choice in Edit video reads "Keep the sound" / "Video only (no sound)".
- **Add a clip at the end** can now be chosen from the **Library** as well as from the phone's files.
- Not compiled or run on a phone here.

## 3.73.0
**Network (the Net browser) for music and GIF:**
- The Network tile now shows in the **Music** and **GIF** tabs of the Library too (it was only in Videos / Photos / Manga).
- **Music from the network**: tap a song (mp3, m4a, aac, flac, wav, ogg, opus, wma ...) in a server folder: it is streamed into the music player and the other songs of that folder become the queue (Next / Previous work, the notification and the mini player work, the sound enhancer and speed apply). Nothing is saved on the phone. Songs from the network show the music-note instead of album art.
- GIF from the network already opened (downloaded to the cache, then the GIF viewer); it is now reachable from the GIF tab.
- Not compiled or run on a phone here; not tested against a real server.

## 3.72.0
**Smarter Auto (player and photos), live, and it now chooses between all the upscalers (NIS Lite, NIS Lite soft, NIS original, CRSC Edge, FSR 1):**
- While Auto is on, about once a second (once for a photo) the app looks at a tiny copy of the frame and decides what kind of picture it is: **dark**, **animation** (flat colours, clean lines), **soft** (low contrast, few edges), **detailed / busy**, or **normal**. It uses plain rules on brightness, contrast, edge amount and how few colours cover the picture; it is a heuristic, not machine learning.
- What it picks: dark or soft -> NIS Lite soft (the normal push would amplify noise); animation -> the Anime profile + NIS Lite (clean edges); a detailed photo with the Quality budget -> NIS (original); anything else -> the usual choice (CRSC Edge / FSR 1). When the picture is shown about 1:1 it stays on plain sharpening, and with the Performance budget on the cheap Fast scaler, as before.
- Flicker protection: for video a new kind must be seen three times in a row and at least 5 s after the last switch; photos switch at once. A short message tells what was picked ("Auto: dark picture -> NIS Lite soft").
- The thresholds are rough and only tested by reasoning, not on real clips. If it picks badly for some video, tell me what the video was and what it picked and I will tune the numbers.
- Not compiled or run on a phone here.

## 3.71.0
- **Accent colour in Appearance** (main screen, Appearance card): eight round colour choices (default cyan / violet, blue, green, orange, pink, red, purple, gold). It changes the buttons, sliders, highlights and the gradient of every screen, in dark and light mode (the light mode uses a darker shade of the same colour so text stays readable). The app restarts its screen when you pick one.
- Not compiled or run on a phone here.

## 3.70.0
Music, round 4:
- **Full-screen album picture**: tap the cover in the music screen's player card and a full-screen "now playing" opens: big cover (it gently shrinks when paused), title, artist, seek bar, shuffle / previous / play / next / repeat, share, close. Works in portrait and landscape.
- **"Playing" animation**: dancing bars in the app's accent colour that rest when the music is paused. They show in the music list (on the current song), in the player card, in the full-screen view (wide strip) and in the mini player at the bottom. It is a decoration, not a real spectrum (reading the real sound would need the microphone permission).
- Not compiled or run on a phone here; brackets checked only by reading.

## 3.69.0
- **Temporal clean-up: Strong was worse than no filter in a pan, and Light and Strong looked alike. Fixed, with numbers.** Offline test with the app's own shaders (noisy, JPEG-compressed video, PSNR against the clean source frame): in a panning scene the old Strong was **1.2-1.4 dB worse than no filter** (ghosting: its tolerance of 0.20 and 94 % weight trusted a motion search that only knows whole pixels), the old Light was about +0.7 dB. Now Strong is about **+0.5 dB better than no filter in a pan** and the cleanest in still scenes (about +0.25 dB over Light, +0.9 / +1.3 dB over the input), Light is practically unchanged (within 0.1 dB).
- How: the blend weight falls where the block match is poor (new use of the match error that was computed but never used), the tolerance is no longer huge (Strong 0.08, Light 0.07), the history is clamped tighter to the new frame (0.02), and Strong backs off to about 20 % where things move (`uMot`), while still flat areas are averaged and smoothed.
- Honest limits: on clean video both levels look almost the same (nothing to remove); the difference shows on noisy / compressed video with still parts. The gain is small in dB; it is mostly less shimmer and grain. The motion search is whole-pixel only, a sub-pixel search would be the next real improvement.
- The explanation text under the Temporal switch (English and Persian) was updated to match.
- Not compiled or run on a phone here; the shader was compiled and run offscreen and equals the tested one; brackets balance.

## 3.68.0
- **Music no longer stops when you open a photo in the Library.** The player screen paused the music every time it opened, also for pictures. Now only a video pauses it, and only when the new switch is off.
- **New in the video's sound dialog (the sound button in the player)**: a *Video volume* slider (0-100%, the enhancer's boost below still raises it), a *Mute the video's sound* switch, and *Keep the music playing during videos*. So you can listen to music while you adjust the upscaling of a muted video. The choices are saved (`AudioCfg.vidVolume / vidMute / keepMusic`) and applied when a video is opened.
- English and Persian strings added for all of it.
- Not compiled or run on a phone here; brackets balance in the changed files.

## 3.67.0
- **NIS (original) on a photo no longer closes the viewer.** A big photo (many megapixels) was drawn by the heavy NIS shader in ONE draw call, which took so long that the GPU watchdog killed the context. Targets above about 3 megapixels are now drawn in bands of about 1 megapixel with a `glFinish` between them (`GlPipeline.drawTiled`, used by the NIS shaders; live sizes stay a single draw), the photo result of NIS (original) is kept within 8 megapixels, and a failed snapshot returns the plain picture instead of throwing. Not reproduced on a phone here: this is the most likely cause (a GPU time-out), so if it still closes, tell me which photo size.
- **Music speed**: 0.25x and 0.5x added at the slow end, 3x and 4x at the fast end (0.25 / 0.5 / 0.75 / 0.9 / 1 / 1.1 / 1.25 / 1.5 / 2 / 3 / 4).
- **Follow phone / theme and every other chip row**: all chips of a row are as tall as the tallest one (the long label wrapped to two lines and made its chip taller than the others).
- **Share in the music bar**: a Share icon in the mini player (it sits above the close icon in one column so the title keeps its space). New `Icons.SHARE`.
- Checked, no change needed: the automatic sound mode (`AudioFx` auto) is wired into the music player's audio sink and adapts to dull / speech / mono sound.
- Not compiled or run on a phone here; brackets balance in the changed files.

## 3.66.0
- **Several layouts for the on-screen keyboard and the on-screen game controller.** Before, the keyboard had five fixed slots that were all named "Profile 1" in the list (so only one layout ever seemed to exist), the ready-made layouts (Full / Gaming / Numpad) overwrote the layout in use, and the game controller had a single layout. Now both have **named layout profiles**: create, switch, rename, duplicate (copy) and delete as many as you like. Your old layouts are kept as the first profiles (nothing is lost; the old slots 2-5 that had data appear as extra profiles).
- Where: **in the game menu** ("Keyboard layouts..." / "Controller layouts..."), on the keyboard's **Layouts** button in configuration mode (its text shows the layout in use; the ready-made layouts are still there), **long press on the controller's gear** button, and in the **streaming settings** (one entry for the keyboard and one for the controller; it shows the layout in use). Switching inside a game rebuilds the keys at once; edits made in configuration mode are saved into the layout that was in use before you switch.
- "Reset layout" in the settings now resets only the layout in use.
- Streaming client: it already is the Artemis fork (ClassicOldSong/moonlight-android v20.2.6, formerly "Moonlight Noir"); there is nothing to swap. A newer v20.3.0 exists only as an experimental pre-release, so it was not merged.
- Not compiled or run here (the Java was syntax-checked only): build it in GitHub Actions and test both layout lists.

## 3.65.2
- **Player controls**: the bottom bar is now compact and **flush with the bottom edge** (and the sides; only a camera hole or a system bar moves it), with just the top corners round. Every button has the same height (the icon buttons - previous / play / next / audio - used to be taller than the text ones), and the seek slider is slim. The top bar sits closer to the top edge.
- **Music player card**: smaller cover, one-line title, slim seek bar (it was stretched 1.7x), smaller buttons and tighter spacing.

## 3.65.1
Brings the NIS Lite work of 3.51.1 onto this version (3.65.0 already had the 3.51.0 part: Input / Middle up to 1440p and 4K, "NIS (original)", "NIS Lite soft", `tools/shader_test`):
- **NIS Lite retuned on 11 real 360p -> 1080p pairs (x3, whole frames)**: mean PSNR / SSIM / sharpness (1.0 = the real picture) / halo: Catmull 31.71 / 0.892 / 0.75 / 0.11; NIS Lite before 30.49 / 0.881 / 1.06 / 0.61; **NIS Lite now 31.06 / 0.888 / 0.99 / 0.45**; original NIS 29.63 / 0.869 / 1.12 / 0.78. Gaussian sigma x0.9, gate from 0.01, guard 0.25, along-edge smoothing x0.7, detail strength x1.0. Equal or better on the earlier sets too (SSIM +0.001 to +0.004).
- **Bug fixed: speckle at exact enlargement factors (x3, x5 ...)**: the local contrast used for the gate / guard / overshoot came from the 2x2 source cell and jumped at the borders of source pixels; at exact x3 one output pixel in three sits on such a border (up to ~20/255 of difference on edges). It is now a per-pixel plus-shaped range, interpolated, so it is continuous (jump p99 15 -> about 4.5 / 255), with the same results on the real sets.
- **NIS Lite soft**: push 60% of normal (was 40%) and it now calms flat, low-contrast areas (new uniform `uClean` 0.7, soft mode only; edges untouched). On a very degraded source (480x270 with dither, x4): PSNR / SSIM normal 22.38 / 0.418, soft 23.17 / 0.519 (bilinear 23.22 / 0.538, original NIS 22.32 / 0.422). Soft is the better choice for anime (x3 SSIM: Catmull 0.885, normal 0.857, soft 0.890) and for dark, soft or noisy pictures; it is less sharp (about 0.78 at x3).
- By content at x3 (SSIM, Catmull / NIS Lite / soft / original NIS): game and render 0.892 / 0.895 / 0.887 / 0.876; animation 0.841 / 0.850 / 0.841 / 0.838; text 0.964 / 0.975 / 0.971 / 0.974.
- `tools/shader_test/glrun.py`: `float_out=True` (float render target, for NaN / range tests).
- GLSL compiled and run offscreen (software OpenGL ES 3.2): both NIS shaders compile and link, output matches the numpy model within 8-bit rounding. The Kotlin changes are two uniform lines in `GlPipeline.nis()`; not compiled or run on a phone here.

## 3.65.0
Icons, round 3:
- **Library**: the favourite star on the tiles is a filled yellow line-icon star, and the tick of a selected tile is a drawn check icon (both were text glyphs ★ and ✓, which look different on every phone).
- **AI snap bar** (cloud x4 / cloud Aa): the cloud in front of the two cloud buttons is the app's cloud icon, not an emoji; the status text no longer starts with one.
- New icons in `Icons.kt`: check, filled star; new helpers `Icons.leading()` (icon in front of a text) and `Icons.clear()`.
- Left as text on purpose: the cloud mark in the manga progress line (that line is also used for other messages, an icon there could stay on by mistake) and the tick marks inside choice dialogs.
- Not compiled or run here; brackets balance in the changed files.

## 3.64.0
Icons, round 2 (the last emoji / glyph buttons are gone):
- **Player bottom bar**: play / pause, previous, next and the audio-track button are the app's own line icons now (they used the text glyphs ▶ ❚❚ ⏮ ⏭ ♪, which look different on every phone).
- **Net browser**: file-type icons (folder, video, picture, book, other file, SMB server, FTP / web server) are themed line icons in the app colour instead of emoji. The Library tile for the Net browser got the globe icon too.
- New line icons in `Icons.kt`: camera, film, picture, file, server, globe; plus `Icons.glyph()` that turns any text button into an icon button.
- The "save stream" menu entry no longer starts with an emoji.
- Not compiled or run here (no compiler); brackets balance in the changed files.

## 3.63.0
- Landscape: the top and bottom bars of the player, GIF viewer and manga reader no longer move away from the screen edge because of the camera hole; they only keep clear of it when the hole is really in their own band.
- Manga: smaller top icons (gear, cloud, close), FX is a clear on / off pill with a gap from the gear (settings and switch are separate), the book name may use two lines.
- Library: sliding between sections no longer scrolls the list up / down at the same time, and a clumsy second finger right after a slide can no longer change the tile size (pinch is stricter). A slower but long slide also changes the section.

## 3.60.0
Temporal Upscaling (clean-up with the previous frames) is stronger and the two levels now differ clearly:
- **Light**: 60 % of the earlier frame is blended in where it agrees (tolerance 0.08) - gentle, almost no risk.
- **Strong**: 94 % (tolerance 0.20), and the tolerance grows with local texture, so noise in busy areas is averaged out too. In still, flat areas (no edge or detail) the remaining grain is also smoothed spatially. Real edges are not touched. Expect a visible difference on noisy or compressed video; fast motion can leave faint trails.
- Works for the player, GIF, stream and video export. It is subtle on clean, already sharp video - that is expected. Not tested on a device (no compiler here): if Strong looks too smooth, tell me and I will lower it.

## 3.59.0
Theme-consistent icons and model files:
- **Icons that match the app**: Library (search, trash, selection bar: favourite / delete / close), settings panels (lock, close), the player's top bar (edit tools, gear, menu), Trash and Net (close, search) now use the app's own line icons instead of mixed emoji. Emoji prefixes were removed from several menus and buttons (model menu, photo bar, AI snapshot bar, editor hub).
- **Copy / move model files**: in the model menu (player and manga) a new "Copy / move a model file…" entry saves a model to any folder you choose (internal storage, SD card, cloud drive). "Copy" keeps it in the app; "Move" removes it from the app after the copy worked. The built-in model can only be copied.
- Still emoji (on purpose, for now): file-type icons inside the Net browser and the small play/pause glyph of the video bar.

## 3.58.0
Manga and Library, second round:
- **Manga top bar**: the buttons (FX, gear, cloud, page mode, direction, close) are smaller again (38 dp), so the name of the book next to them keeps room.
- **The gear no longer switches FX on**: it only opens the settings panel. The FX switch (in the panel and the FX button) does that.
- **Manga settings panel in landscape**: it sits at the right edge, as tall as the screen allows (40 / 52 / 66 % of the width for the three sizes), and keeps clear of the status bar, navigation bar and camera cut-out; in portrait it is lifted above the navigation bar. (The panel used to be a wide, short box floating in the middle.)
- **Library, swiping between sections** (Videos / Photos / Manga / GIF / Music): a second swipe during the slide, or a list still flinging, could leave the list shifted, half faded or scrolled to a strange place. A swipe is now ignored while one is running, a running fling is stopped first, and after every slide the list is put back to normal.
- Not compiled or run here.

## 3.57.0
Music, first round (the list of changes asked for is done step by step):
- **Tapping a song in the Library now queues all the other songs**: Next / Previous work and the next song plays when one ends. Before, only the tapped file was played, so there was no next or previous.
- **"No songs found" fixed**: the song scan asked the phone for a sorted result with a "COLLATE" sort order, which some phones refuse; the whole query then failed and the list stayed empty. The list is now sorted in the app, and when the detailed query finds nothing the same plain query as the Library is used. Songs without a title use the file name.
- **Album art** in the song list, the player card and the bar at the bottom (the picture of the album or the one stored in the file; a music-note placeholder when there is none).
- **New player screen**: icon buttons instead of words (shuffle / previous / big play-pause / next / repeat: all, one, off), elapsed and total time under the progress bar, cover next to the title, long titles are cut with "..." and never run under the cover. The player respects the status bar, navigation bar and camera cut-out, and in landscape the list is on the left and the player on the right. Search opens with the magnifier. Long-press a song: Play next, Add to the end of the queue, Edit, Share, Delete.
- **Bigger "now playing" bar** with album art and 46 dp round buttons (previous / play-pause / next / stop); also in the player.
- New themed line icons (search, play, pause, next, previous, shuffle, repeat, music note, bin, back arrow, dots, pencil) in `Icons.kt`; they use the app colours.
- Not compiled or run here.

## 3.56.1
- **Build fix**: `MusicPlayer.setSpeed()` clashed with the setter of the property `speed` (same JVM name, "Platform declaration clash") and stopped the build. The function is now `changeSpeed()`. This was the only error in the build log; the type-checking step passed for all files.

## 3.56.0
- **Library search**: a magnifier icon at the top opens a search box. Inside a folder or category it filters what is shown by name; at the top level of Videos / Photos / GIFs / Music it searches all files of that section (Manga: filters the folders and books by name). Closing the box shows everything again.
- **Edit photo: hold to compare**: hold a finger on the picture (any tab except Draw) to see the original, let go to see the edit again. **Leaving with unsaved edits asks first** ("Leave without saving?"); no question when nothing was changed or the photo was just saved.
- Not compiled or run here.

## 3.55.0
- **Manga reader: bigger top bar buttons** (FX, settings gear, cloud, page mode, direction, close) about twice as big; the title next to them gets shorter.
- **Draw: eraser and redo** (Edit photo): a third brush "Eraser" removes pen strokes only (never the photo itself) and works on the saved full-size picture too; new Redo button next to Undo.
- **Save with the live quality for manga and photos**: "Enhance to files" has a new quality chip **Live**. It copies the settings you see in the Manga reader (or the photo viewer): upscaler, CRSC level, sharpness, detail, denoise, colour, input and output size, and runs them on every page / picture (manga: one new .cbz). The settings are copied when the job starts, so changing them afterwards (or the screen layer) cannot disturb a running job. Videos, GIFs and songs already had this (3.53.0).
- **Delete in the viewer**: the player's Tools menu has "Delete..." (move to the trash / delete for good) for the open video, GIF or photo; the viewer closes afterwards.
- **"Now playing" bar** also on the Edit screen (it was on the main screen and the Library).
- **Bug fixes**
  - A sleep timer left over from an earlier song could pause the next song a long time later (the timer was only cleared by the bar's stop button, not by the notification's stop or the idle stop). Stopping the player now always clears it.
  - Trash screen: "Delete forever" with nothing chosen means everything; it now asks once ("ALL n items") so one tap cannot empty the trash.
- Checked by script: all text resources used in the code exist, no duplicates, English and Persian have the same names and the same %-arguments, brackets balance in the changed files. Not compiled or run here.

## 3.54.0
- Trash for every section: the Library selection bar has a bin button (Videos, Photos, GIFs, Music), books (manga) have "Delete…" on long-press, songs have it in their long-press menu. Two choices: Move to trash (the phone's own trash, ~30 days, restorable) or Delete forever. Android shows its own allow box. The bin icon at the top of the Library opens the Trash screen: restore, or delete for good (nothing chosen = all).
- Music: a "now playing" bar at the bottom of the Library and the main screen (previous / play-pause / next / stop, progress, tap to open the player). New in the music player: song search, sleep timer, playing speed, long-press menu per song (play next, edit sound, share, delete).

## 3.53.0
- Library: the selection bar now has a Save button on the Videos, GIFs and Music tabs (Photos keeps Enhance). Video / GIF (one file): saved with the live settings of that section (upscaler, CRSC level, sharpness, colour, temporal, frame generation) and the export starts by itself. Music: the sound settings of the music player are baked into new files, one after the other, in the background.

## 3.52.1
- Video / audio editor: a wrong cut range now says "The end must be after the start" instead of the misleading "type the start and end".

## 3.52.0
- Temporal Light / Strong now really differ: the motion vectors stored "no motion" as 0.08 px of shift (8-bit rounding), so the history picture was blurred a little every frame and the Strong level could not do its job. "No motion" is now exactly zero. Offline test on noisy video: static scene, Strong +7 dB over the source (was +1.5), Light +3.
- Frame generation, Light and Very light: they only followed motion up to about 4 px, so with real motion the result was no better than a plain blend (looked like "nothing happens"). They now use a log search (36 matches per block, reach about 30 px, 1 px precision): in the test the Very light / Light result went from 21.7 dB (= plain blend) to 32 dB, the same as Normal, and it costs less than the old search.
- The same exact-zero fix also makes the frame generation picture sharper in still areas.

## 3.51.0
- **Input and Middle now go up to 1440p and 4K** (like Output). A value bigger than the file (or than the picture at that step) does nothing; it can only bring the picture down. Nothing else changed in how the chain works.
- **New choice "NIS Lite soft"** (screen layer / player mode chips, video export upscaler chips; saved files say `NISLiteSoft`): NIS Lite with the push at 40% of normal (`uGain` = 0.4). For dark and soft pictures, where the normal push amplifies noise and softness more than it helps. Mode value 8; the mode is stored in the low 8 bits of the export mode word, so nothing collides (`Stamp.modeName` now reads all 8 bits, it used to read 3).
  - Measured with the real shaders (see below), x2, the 6 real LR / HR pairs from the user, 4 crops each. Dark series frame: PSNR / SSIM normal Lite 39.9 / 0.983, **soft 42.5 / 0.988**, plain Catmull 42.6 / 0.988 (that frame's own reference is soft, so any push costs fidelity). Mean of the 6 pairs: normal 27.67 dB / 0.916 / sharpness 0.98, soft 28.16 dB / 0.913 / 0.88, original NIS 26.13 dB / 0.900 / 1.08, Catmull 27.85 dB / 0.901 / 0.82. On the real 360p test frames (x2 and x3) the same 40% push gave +0.5 dB and +0.013 SSIM. Soft is not "better" in general: it is less sharp (0.88 against 0.98); use it when normal looks noisy or harsh.
  - Tried and dropped: making the push depend on the brightness of the picture (a dark-based gain): +0.3 dB on the dark frame only, and it cannot tell a soft source with a sharp original (the 360p case) from a soft source with a soft original, so it stays a choice.
- **NIS Lite fifth-round retune from the Upscale branch** (real LR / HR pairs: anime, dark series, Deathloop native and FSR, two phone UIs, and two flat-art images): Gaussian sigma x0.8, noise gate up to 0.08, overshoot 0.35, detail strength x1.5. Same cost. About +0.003 SSIM, +0.2 dB, about 15% less halo on those pairs. Mean of the 6 pairs (real shaders): SSIM Lite 0.916 against 0.900 for the original NIS, on every one of the 6 images Lite is ahead in SSIM and PSNR.
- **The shaders were compiled and run for real this time**: both NIS shaders compile and link on a software OpenGL ES 3.2 driver (Mesa llvmpipe), and the NIS Lite output matches the numpy model it was tuned with to within 8-bit rounding (mean difference 0.1 to 0.35 of 255, largest 1.9). The same test run on the original NIS shader gives the numbers the earlier numpy port gave (mean SSIM 0.8995 against 0.900), so that port was right too. The test script is in `tools/shader_test/glrun.py` (needs `EGL_PLATFORM=surfaceless`, Mesa, Python 3 with numpy). A rough speed proxy on that CPU driver (960x540 to 1920x1080): NIS Lite about 35% of the time of the original NIS. A CPU driver says little about a phone GPU; it was not measured on a phone.
- Not compiled or run on a phone here: the Kotlin changes (mode lists, strings, chips) were reviewed by reading only; the GLSL was compiled and run offscreen as described.

## 3.50.0
- **CRSC Edge now works with a chosen output size.** In the player / photo output-size chain CRSC Edge had no branch and silently fell back to plain bilinear + RCAS, i.e. it was identical to Fast, and its quality levels did nothing there. It now runs the real CRSC Edge pipeline (shared function `crscEdge`, same code for both paths).
- **Sharpen is no longer the same as Fast when it enlarges** (chosen output size): Fast stays plain bilinear, Sharpen uses a sharp bicubic (Catmull-Rom, anti-ringing clamp) + RCAS. Offline x3: Sharpen PSNR 26.61 vs Fast 26.39, edge sharpness 0.77 vs 0.71.
- **CRSC Edge levels are evenly stepped now.** Before: Light, Balanced and Strong were almost the same picture (difference 0.7-1.6 of 255), Crisp was far stronger with halos (overshoot 1.16, as high as the original NIS) and Ultra was milder than Crisp. Now every level is one step sharper: edge sharpness 0.71 / 0.76 / 0.81 / 0.87 / 0.91 of the original (Maximum, file only: 0.93), halo overshoot 0.17 / 0.25 / 0.37 / 0.56 / 0.75 (FSR 1: 0.23); on sources that are already sharpened and compressed the top levels halo more (Ultra about 1.8, original NIS 2.1), so use Balanced or Strong there. Each step is about 1 of 255 in mean pixel difference; Maximum is only slightly different from Ultra. Ultra no longer needs 3 back-projection rounds (they gave nothing measurable), so it is no longer heavy: all live levels cost one round.
- **Bug fixed:** the strength of the last RCAS pass left over from a CRSC Edge frame could stay in use in the chosen-size path after switching to another mode. It is reset at the start of every frame.
- Cleaned the README (the 3.49.1 notes were there twice, the title showed 3.47.0).
- Not compiled or run on a phone here. The shaders were compiled and run offscreen with a software OpenGL ES 3.2 driver, and the level tables were measured with the same shaders.

## 3.49.2
- NIS Lite brought to the final state of the separate Upscale branch: third round (edge steepening removed, exactly horizontal / vertical edges are not smoothed along their length) and fourth round (re-tuned on real content). Only the `NIS` shader in `Shaders.kt` changed; every other file is as in 3.49.1.
- Not compiled or run on a phone here; the merged shader was compiled and rendered offscreen with a software OpenGL ES 3.2 driver.

## 3.49.1
- Input resolution below the file's size no longer looks rough: the picture is copied at full size and shrunk with a proper filter (halving steps + 4 taps) instead of one single-tap read. Same filter for the new Middle step and for manga / photo pages.

## 3.49.0
- Resolution chain now has a MIDDLE step: input -> middle -> output. After clean-up the picture is shrunk to the chosen Middle size (clean anti-aliasing), then the chosen upscaler (CRSC Edge etc.) builds it up to the output size. Example: soft 1080p file -> Middle 480p -> Output 1080p. Ignored when Middle is not smaller than the work size. The settings panel info line shows the extra step.

## 3.48.0
- Library: new "Music" tab (audio files), like the other sections.
- Edit photo and Edit audio: pick "From the app's library" or "From the phone's files", like Edit video.
- Edit photo: new "Draw" tab (pen / marker, 7 colours, 4 thicknesses, undo, clear); strokes are saved into the picture at full size.
- Player Tools menu: "Edit" item that opens the right editor for the open file (video / photo / audio).

## 3.47.0
- **Edit photo** (new): turn left / right, mirror, flip, crop (free, 1:1, 4:3, 3:2, 16:9, 3:4, 2:3, 9:16 with zoom and position sliders), auto fix (the app's own Smart fix), brightness, contrast, colour strength, warmth, eight ready-made looks (vivid, black and white, sepia, warm, cool, fade, dramatic), sharpen, saved size (full / 75 / 50 / 25 %) and JPG or PNG. Saved as a NEW picture in Pictures/ClearOverlay, the original is not changed; a Share link appears after saving. It also appears in the system "Edit with" list of other apps.
  - Preview: a small copy (long side 1280 px). Colour changes are a colour-matrix filter on the preview (instant); turn / crop / auto fix / sharpen are rebuilt on a background thread. Saving decodes the photo again (long side at most 3200 px; retried at half size if memory runs out) and runs the same steps, so the file matches the preview. The photo is turned upright by its EXIF tag first.
  - The sharpening row logic was checked against a reference 3x3 unsharp mask (identical output). The rest was only reviewed by reading; not compiled or run here.
- **One "Edit" button** on the main screen (replaces "Edit video" and "Edit audio"): it opens a screen that lists the video, audio and photo editors. Fewer buttons on the main screen. The editors themselves are unchanged.

## 3.46.0
- **NIS Lite**: the NIS upscaler (player, overlay, export, PC stream) was rewritten to be lighter, cleaner and more natural. The old shader is kept in `Shaders.kt` as `NIS_ORIG` (not compiled into a program).
  - Cost per pixel: 16 texel fetches + 1 bilinear tap, no big tables (old: 36 fetches, 4 edge tests, two 384-float tables indexed at run time).
  - Idea: NIS-style edge direction + limited adaptive sharpening, FSR 1-style cleaning along edges (the picture is smoothed *along* an edge, not across it, so stair-steps go but the edge stays sharp), CRSC-style fidelity (the result never goes past the local min / max, big details are soft-limited, flat / noisy areas are not sharpened).
  - Offline test (numpy model of the shader vs a literal port of the old shader; x2; photo and line-art; box, nearest (aliased) and JPEG q45 sources; sharpness slider 50%): old NIS sharpness 1.15-1.31 (x original), halo 0.9-1.8; NIS Lite sharpness 0.99-1.11, halo 0.17-0.5 on photos. PSNR on photos: old 27.7 / 23.8 / 25.4 dB, Lite 30.0 / 25.9 / 26.6 dB (Catmull 29.6 / 26.5 / 26.7). Line art: Lite SSIM 0.894 / 0.857 / 0.738 against old 0.904 / 0.812 / 0.774 (box / aliased / JPEG).
  - The sharpness slider now maps inside the shader (0 = soft, 100% = strong, still limited).
- **Crisper pass (second round)**: closer to the original NIS look. Added edge steepening across the edge (2 more cubic evaluations, pulls the value toward the nearer side of the edge, limited), a second fine-detail unsharp mask and a stronger main one. Cost is still ALU only (same 16 fetches + 1 tap). Model numbers at slider 50% (mean of photo / photo / line art, box / aliased / JPEG sources): sharpness 1.10 (first Lite 0.99, old NIS about 1.15-1.3), halo 1.9 (first Lite 1.1), PSNR 24.8 dB (first Lite 25.7). At slider 80% sharpness 1.20. Lower the slider to go back toward the softer, cleaner first version.
- **NIS (original)** is back as its own choice (screen layer / player mode chips, video export upscaler chips): the old heavy shader, to compare with NIS Lite on the phone. NIS Lite is labelled "NISLite" and the original "NIS" in saved file names.
- **Tuned on real pictures** (the 360p -> 1080p test frames of the user: 3 room and 3 game crops, the 360p frame rebuilt by averaging 3x3 blocks, compared to the real 1080p frame). x3 enlargement, slider 50%: gradient (sharpness) against the real 1080p frame: bilinear 0.65, Catmull 0.68, first NIS Lite 0.72, previous crisp NIS Lite 0.77, **original NIS 0.82, new NIS Lite 0.81**; PSNR 30.1 / 30.4 / 30.7 / 30.5 / 30.2 / **30.4** dB, SSIM 0.860 (original NIS 0.858). So the new NIS Lite is about as sharp as the original at x3 and a little more faithful. At x3 the previous version was too soft; the enlargement factor (new uniform `uFactor`) now widens the soft reference and sets the push: sigma = 0.4 + 0.2 f, detail strength = 1.1 + 0.2 f (x 1.6), edge steepening 0.65 - 0.15 f (same as before at x2).
- The 360p source in the test is a very compressed stream: NIS Lite and FSR 1 outputs differ by only 2.2 / 255 on that frame and both show the same painted / posterised look. That look comes mostly from the source and from the clean-up stages (denoise / deblock), not from the upscaler.
- **NIS Lite, third round (lighter and better than the original NIS in the tests)**:
  - Removed the edge-steepening stage (2 of the 5 cubic evaluations). In every test it gave no measurable gain. Estimated ALU work per pixel about 20% lower (counted by hand, not measured on a phone); fetches unchanged (16 + 1).
  - Edges that are exactly horizontal or vertical (text, UI, HUD) are no longer smoothed along their length: they cannot have stair-steps, and the smoothing only softened thin strokes.
  - Tests (same cases for every method; x2 and x3; photo, YouTube-like x264, dark movie with grain, animation, aliased game render, aliased game stream, text/UI), mean over all: SSIM new Lite 0.811, previous Lite 0.809, original NIS 0.800; PSNR 25.0 / 24.9 / 24.1 dB; halo 1.3 / 1.4 / 2.0. New Lite is ahead of the original NIS in every case except text/UI at x3 (SSIM 0.500 against 0.531). The original NIS is sharper (sharpness 1.17 against 1.04 of the real picture), so on a picture that needs more bite the slider of Lite has to go up.
  - Real 360p -> 1080p test frames (x3): new Lite PSNR 30.53 dB, SSIM 0.861, sharpness 0.82; original NIS 30.24 dB, 0.858, 0.82.
- **Fourth round (tuned on real content)**: test set made from the user's two real 1080p frames (room / chat text / faces / plush; Rust HUD / names / character / grass), shrunk x2 and x3 and compressed with x264 (crf 28), 12 crops each. New Lite beat the original NIS on all 24 crop / scale pairs (SSIM x2 0.898 against 0.883, x3 0.825 against 0.813). Plain Catmull has a higher SSIM than both (0.907 / 0.844) but much lower sharpness (0.85 / 0.75 against 0.97 / 0.94 of Lite; 1.0 = the real picture), so the tuning target was "sharpness near the real picture, then the highest SSIM". Coordinate search over 13 parameters found no real gain beyond: detail strength x1.15 and the second (fine) unsharp mask removed (one Gaussian less per pixel). Real set, mean of x2 and x3: SSIM 0.859, sharpness 0.97. Cost: 3 cubic evaluations + 1 Gaussian + 16 fetches + 1 tap; estimated about 30% less ALU than the first crisp version and about 10% less than the third round (counted by hand).
- Not compiled or run here: the shader was only modelled in numpy. The speed gain is from counting work, not measured on a phone.

## 3.45.0
- **Edit video, better** (still no re-encoding): two sliders (From / To) with the video frame at each end, so the cut points are picked by eye (the text fields still work and stay in sync); **Cut it out** (remove the part between From and To, join the rest) next to the old Keep; **Join another clip** at the end (clips must have the same codec and size, otherwise a clear message). The remux code now writes a list of segments on one continuous timeline.
- Not compiled or run here. Next: photo editor.

## 3.44.0
- **Edit audio** (main screen, under Edit video): pick a song or the sound track of a video, cut a part (from - to), fade in / out (0-8 s, smooth curve), volume (-6 .. +10 dB), optionally run your sound enhancer settings (equaliser, presets), save as a new .m4a in Music/ClearOverlay. The original is not changed. The export code (`AudioExport.run`) got an `Edit` parameter: sample-accurate start / end inside the decoded blocks, the enhancer filters run on the whole block so they stay in step.
- Not compiled or run here. Next: better video editor, photo editor.

## 3.43.0
- **Sound enhancer, more tools**: a 5-band **equaliser** (60 Hz shelf, 250 Hz, 1 kHz, 4 kHz, 12 kHz shelf; -12..+12 dB each; quick shapes Flat / Bass+ / Vocal / Treble+ / V) and a **Dialogue boost** slider (presence lift around 2.8 kHz, up to +7 dB). The presets (Music / Video / Podcast / ASMR) now set these too. Everything works in the music player, the video player, the PC stream and the file export (enhanced copy), and is saved.
- The filter formulas (RBJ biquads) were checked numerically: e.g. +12 dB shelf = 12.1 dB at 20 Hz, 6.0 dB at the corner; peak bands hit exactly their gain at the centre.
- Not compiled or run here; the sound itself is not judged. Next: audio editor.

## 3.42.0
- **Tools button in the video / photo player**: zoom, screenshot, rotate, rotation lock, free rotation and "Edit video" (cut, mute, speed) are now one ✎ button next to FX; the top bar stays clear of the picture. The button turns accent-coloured while zoomed.
- **Text level** (Main screen > Appearance): Full / Light (every explanation cut to its first sentence) / Minimal (explanations hidden, only labels and controls). Works in every screen that builds its text through the shared helper; texts set later in code are not affected.
- Not compiled or run here.

## 3.41.0
- **Repair profile** (Video / Photo / Manga ... quick-profile row, new last chip): for big pictures of poor quality ("fake HD": soft, blocky, noisy). Strong clean-up of blocks, noise and banding at the source size, a wide Detail radius for the softness, light sharpening, CRSC Edge as the upscaler. For really low-resolution files also lower the "source resolution" chip.
- **Save as a new file (video)**: the CRSC Edge level chips only appear when CRSC Edge is the chosen upscaler.
- **Manga reader**: the top bar is much smaller (about 40 %: tighter padding, smaller icons, direction / mode buttons are symbols only), the file name is shown, and the second line shows the page number plus the file format and size.
- Frame generation "Very light" is real: it halves the motion search width, uses a 2 px search range instead of 4 and skips the final 1-px refinement (cheaper, but misses fast motion).
- Not compiled or run here.

## 3.40.1
- **The levels now really differ.** Measured first: in 3.40.0 Balanced vs Strong differed by about 0.1 of 255 (invisible) because the detail step is clamped to the local range, so a bigger amount changed nothing. Now (mean difference to Light on the test pictures, video / photo / text / anime): Balanced 0.7 / 0.7 / 2.0 / 1.7, **Strong about 1.4 / 1.5 / 3.9 / 3.4** (stronger detail boost, wider overshoot, stronger edge step), **Crisp about 3.6 / 3.8 / 6.3 / 7.6** (also wider radius). Light and Balanced are the faithful ones; Strong costs a little fidelity (-0.3 to -0.4 dB), Crisp a lot (-2.5 dB) and is purely a punchy look. Ultra / Maximum stay the faithful heavy ones.
- **Temporal**: Light now 0.5 blend with a strict match window; Strong 0.93 with a wider window. Test (noisy simulated video, static / slow / faster pan): Light +1.0 / +1.0 / +0.8 dB, Strong +3.6 / +2.3 / +2.3 dB, against +2.8 / +1.8 / +1.6 dB for the old Light and +3.2 / +2.1 / +1.8 for the old Strong (those two were hardly different). Strong can leave faint ghost trails on fast moving thin objects.
- Test pictures are synthetic; judge on the phone with FX on / off and Zoom. Not compiled or run here.

## 3.40.0
- **Two heavier CRSC Edge levels.** *Ultra (heavy)* for live use (player, stream): 3 back-projection rounds (gain 1.3) + edge smoothing + detail boost + edge step. *Maximum (file only)*: 6 rounds, only offered in Save as a new file (video export chips; the manga / photo batch "CRSC" quality uses it automatically). In the live panels level 5 is never used (it falls back to Ultra).
- Text and Manga profiles now pick Ultra.
- **Honest numbers** (offline test, x2, 5 content sets, 2 pictures each, PSNR / SSIM): more rounds hardly help. Ultra: text SSIM 0.8474 vs 0.8453 (Strong), manga 0.4131 vs 0.4100, anime +0.06 dB; photo and video: no difference. 6 rounds / interleaved / second final round: at most +0.02 dB more than Ultra. Supersampling (working at 2x and shrinking) was clearly worse (-0.4 to -1 dB). The method is saturated: heavier is not better by these metrics.
- **Strong vs Crisp**: Strong is the more faithful one (measured). Crisp (stronger detail boost + double edge step) scored lowest of all CRSC levels (-0.2 dB vs Balanced) and only *looks* crisper; use it when you want a punchy look. Ultra is the strongest faithful choice.
- Job mode bits: CRSC level now uses 3 bits (21-23).
- Not compiled or run here.

## 3.39.0
- **Best upscaler for each kind of content.** The quick profiles (Video, Stream, Game, Photo, Movie, Anime, Text, Manga) now choose the upscaler and the CRSC Edge level too, not only sharpening / clean-up. Offline test (x2, 6 test sets: photo, x264 video, game-like, anime-like, text screenshots, manga-like screentone; PSNR / SSIM against the original, FSR 1 / SGSR 1 / NIS / bilinear / CRSC levels compared):
  - photo +0.10 dB vs FSR 1 (CRSC balanced best), compressed video +0.08 dB, anime +0.24 dB (SSIM 0.812 vs 0.802), text SSIM 0.845 vs 0.829 (strong), manga SSIM 0.409 vs 0.397 (strong). NIS and SGSR 1 were last everywhere, so they stay optional.
  - Game / stream: on the aliased game-like set plain bilinear scored best and CRSC light second (better than FSR 1); that test is only a rough proxy, so Game and Stream use CRSC *light* (one round, cheapest).
  - Levels: Photo / Video / Movie / Anime balanced, Text / Manga strong, Game / Stream light.
- Photo / Text / Manga profiles always use CRSC Edge when the picture is enlarged; Video / Stream / Game / Anime use it with the Quality budget, otherwise FSR 1. Performance budget stays "Fast".
- Auto (video): sources up to about 1080p30 get the Quality budget (CRSC Edge); 70-150 MP/s Balanced (FSR 1); above 150 MP/s Performance.
- Sections Photo, Video and Manga start with CRSC Edge (once, existing choice is replaced one time); the PC stream section is re-seeded with the Stream profile at the Quality budget.
- The overlay (screen capture) still uses sharpening only: the capture is already at full size.
- Test caveats: synthetic proxies (cartoonised and screentone pictures, x264 of still images), SwiftShader, not a phone. Not compiled or run here.

## 3.38.2
- Merge of 3.38.1 (direct streaming, build fix) with the CRSC Edge of 3.38.0. Offline WebGL test, x2, 4 natural pictures, sharpness 50%: on clean pictures the old CRSC Edge (2 back-projection rounds + edge step) scored 31.13 dB / SSIM 0.9195 vs 31.09 / 0.9144 for the 3.38.0 one; on compressed sources (JPEG q60 / q35, like video and streams) 3.38.0 wins: 28.23 / 27.40 dB vs 27.98 / 27.16 (FSR 1: 28.12 / 27.31). 3.38.0 also needs only one back-projection round, so it is lighter. Since video and streams are always compressed, the 3.38.0 CRSC Edge (GlPipeline.kt, Shaders.kt) is used. A hybrid of both was tested and was worse than either.
- Not compiled or run here.

## 3.38.1
- **Build fix**: the English `moon_hint` text made the resource step fail ("Invalid unicode escape sequence", string/moon_hint). It now uses plain typographic quotes and an apostrophe character instead of backslash escapes, so aapt2 has nothing to trip on.

## 3.38.0
- **PC game streaming goes straight into the +CRSC engine (direct mode, on by default).** The embedded Artemis / Moonlight client no longer has to be captured from the screen: its video decoder now draws into the `GlPipeline` input surface and the pipeline draws the processed picture into the stream window. So the stream gets FSR 1, SGSR 1, NIS, CRSC, sharpening, detail / clean-up, temporal clean-up and **frame generation**, all with no screen-capture permission, no floating layer and no capture delay.
- **Sound:** every decoded audio packet goes through the sound enhancer (clarity / bass / width / loudness / voice, the same as the music and video player) before it reaches the AudioTrack. Stereo only: 5.1 / 7.1 streams are left untouched.
- **In-game menu:** a new entry "Picture & sound (+CRSC)" opens the picture panel (same as the video player), temporal and frame-generation choices and the sound panel, live while playing. The stream has its own picture settings section ("PC streaming"), so the player / screen layer settings are not changed.
- Main screen: a switch "Process the stream inside the app (direct)". Off = the old way (screen layer + bubble). In direct mode the first button just opens the client.
- Safe fallbacks: HDR streams, the switch being off, or the GL engine failing to start all use the original direct rendering. A warning shows if the old screen layer is running at the same time (the picture would be processed twice).
- How it is built: `moonlight/.../ClearHook.java` (small bridge, the module does not depend on the app), `Game.java` (decoder target + release), `GameMenu.java` (menu entry), `AndroidAudioRenderer.java` (audio hook) and `app/.../StreamFx.kt` (the engine side).
- Frame generation adds about one frame of delay (it needs the next frame); it is off by default. Not compiled or run here.

## 3.37.1
- Main screen, PC game streaming card: the first button is now one step: it applies the streaming picture settings, starts the screen layer (the floating bubble = the toolbox: tap on / off, hold for settings) and then opens the streaming client. The second button opens the client alone. The hint text explains the flow.

## 3.37.0 (3.33.0 changes merged into 3.36.0)
- **Manga / CBZ**: a full RAR5 decompressor (`Rar5Unpacker.java`: LZ + Huffman + E8 / E8E9 / ARM / delta filters, solid archives, CRC check). A .cbz / .cbr that is really a compressed RAR5 now opens with all its pages (before, only the few pages stored without compression showed). Tested offline on the libarchive / rarfile sample archives (compressed, solid, multi-file: CRC OK). If a few pages cannot be unpacked a message names how many. Zip entries without a picture extension are always sniffed by their first bytes.
- **NIS** (NVIDIA Image Scaling, MIT licence) as its own upscaler (player, overlay, export): directional polyphase scaler with its own adaptive sharpening. On clean test pictures it scores below FSR 1 in PSNR (it sharpens on purpose), so it is an option, not the default.
- **CRSC Edge quality**: Light (1 round, no edge step) / Balanced (the 3.36.0 setting: 2 rounds + light edge step) / Strong (3 rounds) / Crisp (2 rounds + double edge step). Chip row under the upscaler list; export has its own row (bits 21-22 of the job mode).
- Upscaler review of the merged line (offline WebGL test, 4 natural pictures, x2): FSR 1 31.04 dB; plain back-projection 31.17; noise-aware back-projection (3.36.0) 31.22 and, on JPEG-compressed sources, 28.01 vs 27.85 for the plain one, so the 3.36.0 shaders were kept.
- Not compiled or run here.

## 3.34.0 (merge of three lines)
Built from the bug-fix line (3.33.0) with the other two lines merged in, each part kept only where a PC test showed it is better:
- **Bug fixes** of 3.32.0 (streaming upscale, chip sizes ...): as in the bug-fix line.
- **Sound** (from the sound line): sound enhancer (clarity / bass / width / loudness / voice; Music, Video, Podcast, ASMR), music & sound player with background playback, enhanced .m4a copy, enhancer for the video player's sound, Moonlight card on the main screen.
- **CRSC Edge**: FSR 1 EASU + two rounds of back-projection (as in 3.32.1) + a light shock filter across the edges (new). Test (x2, real pictures, Lanczos standing in for EASU): back-projection 29.52 dB / SSIM 0.898, with the shock step 29.57 / 0.900 and crisper edges. A third back-projection round is dropped (almost no gain, costly).
- **Back-projection is noise-aware**: very small errors (mostly video-compression noise) are no longer pushed back, real edges still are. Test on JPEG-compressed sources: 26.34 -> 26.43 dB, SSIM 0.7625 -> 0.7671; clean sources unchanged (-0.01 dB).
- **Temporal** (3.32.1 version kept, not the rewrite of the sound line): on simulated noisy video it beat the output-size rewrite in every case (the rewrite broke down on sub-pixel pans because the block motion is whole-pixel). One change: the agreement window is narrower (0.12 -> 0.08) and Strong uses 0.85 instead of 0.9, which tested better on slow pans (mean gain over no temporal +0.27 -> +0.37 dB; a perfectly clean slow pan still loses about 0.5 dB, that is the price).
- **Frame generation**: the 3.32.1 interpolation (neighbouring blocks count only when they move alike, more tolerant match test) kept: better in 4 of 5 simulated scenes (+0.4 to +0.9 dB), slightly worse in one (-0.3 dB).
- Not compiled or run here.

## Use
1. Start -> allow "Display over other apps" -> allow screen capture.
2. A floating bubble appears. Tap = effect on/off. Hold = settings panel. Drag = move.
3. Modes: Sharpen (RCAS, full resolution) / FSR 1 / SGSR 1 / Fast (hardware bilinear, cheapest,
   best for very weak GPUs). "Boost" adds a second sharpening pass.
4. Render resolution: pick 1080p / 1440p / 4K to render at that height-class and upscale back to
   the panel's real resolution, or "Custom" for the raw percentage slider. A preset above the panel's own
   resolution (e.g. 1440p on a 1080p phone) is allowed: the frame is captured bigger, sharpened, then
   shrunk back to the panel with a 4-tap filter (supersampling). Custom slider goes 33-200%. In Sharpen mode only values above 100% apply (it never renders below full resolution).
5. Vivid colors: optional saturation + contrast lift applied after upscaling (off by default),
   similar in spirit to a video player's "enhance" filter.
6. Layer opacity (screen overlay panel): how much of the processed layer shows over the real screen (100% = fully processed, lower = blended with the original, a softer effect; changes apply live and are part of saved profiles).
7. Bubble size: slider to resize the floating bubble, applied live.
7. Auto-hide (on by default): after ~2.5s idle, the bubble dims and slides ~37% of its own size
   past the screen edge it is snapped to. The idle delay is adjustable (1-30 s) in the panel. Push the bubble past a side edge and release to put it to sleep instantly. Any touch instantly brings it back; that first touch
   only wakes it, it does not also toggle the effect.

## Library: your own folders and categories (3.8.0)
The Library (main screen > "Library: videos, photos, manga") lists every video and photo on the phone, grouped by folder, without picking files one by one.
- **Add a folder by hand** (＋📁 at the top, or the "Add a folder…" tile): for a folder the phone's media index does not list. Pick it once; sub-folders are included, and the access is remembered. Hand-added folders are marked 📌 and work in Videos, Photos and Manga. Long-press one to remove it from the library (nothing is deleted from the phone). 🔄 scans hand-added folders again.
- **Categories**: "⭐ Favorites" plus any you make (Videos and Photos tabs). Long-press an item to select (tap more to add to the selection), then **★** (toggle favorite), **Add to…** (pick or create a category), **All**, **✕**. Inside a category the selection bar also has **Remove**. Long-press a folder to add everything in it to a category; long-press a category to rename or delete it. Favorites show a ★ on their thumbnail.
- Opening a category plays it as a playlist, like a folder.

## 3.10.9
- **Player, portrait**: the picture view is now sized from the area that is really on screen (it used the previous orientation's size for a moment after a rotation, so the video looked zoomed in) and is rebuilt whenever that area changes. The old saved "Fill" setting is reset to Fit.
- **Picture size** (video): Fit, Fill (crop edges), Stretch to the screen, 16:9, 4:3, 21:9. In the settings panel (Playback section) and in the menu. Photos are always fitted.

## 3.10.8
- Build fixes: FTP binary-mode constant clashed with the app's own `Net.FTP` name; the share-listing library no longer drags in a second BouncyCastle.

## 3.10.7
- **Network > add / edit a SMB server**: *List the shared folders* asks the server for its shares (after the address and login are filled in) and fills the share name when you pick one. Hidden shares ($) are left out. If the server refuses or the helper library does not fit, a message says so and you can still type the name.

## 3.10.6
- **Photos from a link or a network server** are read once and decoded from memory (before, each photo opened 3 separate connections: size, picture, rotation), and web links now time out after 15 / 30 s instead of hanging.

## 3.10.4
- **Manga reader, same tools as the photo viewer**: the cloud button now opens *Enhance this page*: Smart fix, offline AI upscale (with the model list: choose / one-tap download / add from file or link / remove), Online photo x4, Online clearer writing x2, Back to the original page, Save page, Online settings. An enhanced page stays enhanced while you scroll or turn pages, until you choose *Original*. Progress shows in the top bar; tap the cloud button again to cancel.
- **Network manga**: a .cbz / .pdf on an SMB / FTP server is downloaded once into the cache with a progress counter in the top bar (opening it again, or continuing from History, is instant), instead of being copied again on every open.
- **Network scan** (🔍 in Network): found devices show their network name when the router knows it, the form is pre-filled with that name, and servers you already saved are marked ✓.
- Online error HTTP 402 = the Replicate account has no credit (the service is paid; not an app bug). The message now says so in English and Persian.
- Note: the README sections below 3.9.5 describe earlier stages; Network (SMB / FTP, scan, last folder per server), History, Panel size on every panel, low-data online mode and the Manga quick profile are all in the app already.

## 3.22.0
- **Screen direction is separate for photos and videos** in the player (the two keys remember their own state; before, one setting served both). The panel (size, lock, ...) and the effect settings were already separate per photo / video.
- **Screenshot for video**: the camera button in the player's top bar saves the current frame with the effects on (at the chosen output size, or the video's own size) to Pictures/ClearOverlay.
- **Logo**: the four squares around the + keep their sizes, their centres now sit on two horizontal and two vertical lines at the same distance from the plus (app icon, launcher icon and bubble).
- **CBZ in the manga reader**: pages are found again by their entry objects (names that are not valid UTF-8 could not be found again), and an archive that cannot be opened as a random-access zip is now read from the start into the cache instead of failing. RAR5 and 7z are still not supported.

## 3.21.1
- **Upscale a video, tidier**: option rows swipe sideways instead of squeezing (also in Enhance to files and the Library tabs); options are grouped under headings; the *Fully automatic / Custom* switch picks everything by itself (quality, upscaler, encoder, size, speed); frame generation shows *30 fps -> 60 fps*; the *CRSC* entry is gone from Quality (it stays as an Upscaler choice); "(2x frames)" removed from the player switch.
- **Times**: the estimate now says *Processing time (how long the phone works)* and is not skewed by AI / frame-generation runs any more (they no longer teach the speed estimate); *time left* uses the recent speed instead of the average since the start.
- CRSC Lanczos is listed before Fast and Raw in the mode row.

## 3.21.0
- **Offline AI model for video** (Upscale a video > *AI model*): Off / Light / Medium / Heavy. Every frame goes through a small TFLite super-resolution model on the CPU (Light = XLSR / QuickSRNet Small, Medium = QuickSRNet Medium / Large, Heavy = SESR-M5 / Real-ESRGAN General), then the normal FSR / Lanczos / sharpening steps. The frame is shrunk first (360 / 288 / 216 px high), so it is for short, low-resolution clips; expect seconds per frame. *Half the frames* makes it twice as fast; *Test the speed* measures the phone and improves the time estimate; the model is downloaded from the same screen.
- **Stream**: pieces are now 8 seconds long (before: a minute), so the player starts after the first piece, and when the phone is slower than the video it waits for a bigger head start. New settings: *keep this much ready ahead of me* (Auto / 30 s .. 10 min) and *keep this much behind me* (Auto / 10 s .. 2 min); watched pieces are deleted. Seeking works inside the finished pieces; a brief pause between pieces is possible.
- Not compiled or run here.

## 3.20.2
- **Upscale a video**: the Quality list has a sixth choice, *CRSC (own)*: the Best settings with the CRSC Lanczos upscaler.

## 3.20.1
- **Enhance to files** (photos / manga): a fourth quality, *CRSC Lanczos* (own method: Lanczos-3 with anti-ringing + the strong Photo / Manga clean-up).

## 3.20.0
- **CRSC Lanczos**: own upscaler (Lanczos-3, 6x6 taps, anti-ringing clamp, then RCAS). Available as a mode in the overlay / player panel and as an Upscaler choice for video export. No halos; a bit softer than FSR 1 / SGSR 1 and heavier on the GPU.

## 3.19.1
- **Frame generation quality**: Light / Normal / High (High uses smaller 8 px blocks and a 1 px refining search; about twice the work of Normal), in both the export and the player.

## 3.19.0
- **Frame generation modes**: 2x / 3x / 4x frames per source frame, and a *Light* motion search (about a quarter of the work) in both the file export and the live player switch. The LSFG Lossless.dll is not supported (it needs a native Vulkan port; see the chat notes).

## 3.18.1
- **File size option** (Upscale a video): Normal / Small (about 55% of the bit rate) / Smallest (about 32%). Best with H.265. The phone re-encodes with its hardware encoder, which is less efficient than YouTube's VP9/AV1, so the result can still be bigger than the downloaded file.

## 3.18.0
- **Quality options are always visible** (Upscale a video): Quality = Auto / Fast / Balanced / Best / **Maximum** (Best plus a second sharpening pass and the highest bit rate: slowest, heaviest, biggest file), Upscaler = Auto / FSR 1 / SGSR 1, Encoder = Auto / H.264 / H.265, with the sharpness and vivid sliders below. Auto picks for the video and the phone and shows what it picked. (Before, they were hidden behind a *Manual* switch.)
- **Frame generation (own method, not the LSFG app)**: *Upscale a video > Frame generation > 2x frames* builds an extra in-between frame for every frame (30 -> 60 fps) with GPU block matching + warped blending, inside the video file. The player has the same as a live switch (panel > Effect > *Frame generation*): one frame between every two, with a very small delay. Weak spots: very fast motion, scene cuts, small text. Estimate and size account for it (about 1.7x time).
- **Online AI for video (Replicate, paid)**: a button under Start: the video (or the chosen range, cut without re-encoding) is uploaded (limit about 95 MB), a cloud model (default `lucataco/real-esrgan-video`, changeable in the Online settings) upscales it and the result is saved to Movies/ClearOverlay. Resolution choices HD / FHD / 4k (exact values depend on the model). Runs in a background service with a notification. Needs your own token and credit (HTTP 402 = no credit).
- Offline AI/ML models (Real-ESRGAN etc.) for video are not offered: on this phone they take seconds per frame (days per film). They stay for photos and manga.
- Not compiled or run here: build it in GitHub Actions and test.

## 3.17.0
- **Streaming upscale** (Upscale a video > *What to do with the result* > *Watch now (stream)*): instead of making a file, the app upscales only a few minutes **ahead of the spot you are watching**, plays the finished pieces in the player (it opens by itself when the first piece is ready), **deletes the pieces you have already watched** (about one minute behind you is kept) and waits when it is 3 minutes ahead, so it needs very little free space and the phone rests while you pause. Turn on the *part* option and set *From* to start at, for example, minute 14; the window then slides forward as you watch (14-17, 15-18, ...). Nothing is saved as a file, and closing the player stops the work and deletes the pieces. Seeking works inside the finished pieces (about a minute each); the same Auto / Manual quality, pace and encoder settings apply.

## 3.16.1
- **Enhance to files now runs in the background**: it is a foreground service with a progress notification (with a Cancel button), so it goes on with the screen off or the app closed; the screen no longer has to stay on. Tap the notification to come back to the progress and the hold-to-compare preview.
- **Enhance a whole .cbz / .zip / .pdf**: Library > Manga > long-press a book tile (files in your hand-added folders) > *Enhance every page to a new .cbz…*. A PDF is drawn page by page (about 2000 px on the long side) and every page is enhanced; the result is one new .cbz in Download/ClearOverlay. The file is copied to the cache while it works and removed afterwards, so keep some free space for it. RAR / 7z are not handled here.

## 3.16.0
- **Enhance to files (photos and manga)**: Library > Photos > long-press a picture, select more, tap **Enhance**; or long-press a Photos / Manga folder > *Enhance this folder to files…*. Choose **Standard / High / Maximum (offline AI model, then a light polish)**, the size (same, ×1.5, ×2, ×3) and JPEG / PNG; manga can be written as **one new .cbz** (Download/ClearOverlay) or as separate pictures; photos go to Pictures/ClearOverlay/Enhanced. While it runs the last result is shown, and **holding the picture shows the original** to compare. Maximum needs an AI model (downloaded in the photo viewer); without one it runs as High.
- **Library**: the number of tiles per row (pinch) is now remembered separately for Videos, Photos, GIF and Manga (before, a pinch in one section changed all of them, which could leave videos at two per row).

## 3.13.0
- **Upscale a video, new screen**: it reads the file (size, fps, codec, length) and shows the result size, a rough time and the load on the phone (light / medium / heavy). *Auto* picks the cleanup strength and the encoder for this video and this phone; *Manual* adds upscaler (FSR 1 / SGSR 1), quality, encoder, **sharpness** (auto or 0-100%) and **vivid colours**. Sizes: 480p, 720p, 1080p, 1440p.
- **Load on the phone**: Max speed / Balanced / Gentle (rests between frames: slower, cooler).
- **Encoders are really tested** on the phone (a tiny encoder of each type is started): H.264, H.265, AV1, VP9 are shown with hw / sw / not working. H.264 and H.265 can be used for the result.
- The time estimate learns: after an export the real speed of the phone is saved and used next time.

## 3.12.8
- Build fix: a broken text line in Online.kt (3.12.1) stopped the compile.

## 3.12.7
- **Manga tab**: .pdf / .cbz / .cbr / .zip files inside your hand-added folders are now listed (after the folders) and open straight in the reader; before, they could only be opened with *Open PDF / CBZ / ZIP…*.

## 3.12.6
- **Video upscale: choose the upscaler** (FSR 1 or SGSR 1), like in the player. This is the third way to use the effects: *baked into a new file* (besides the screen layer and the live player).

## 3.12.5
- **Video upscale: encoder choice** (*H.264* / *H.265*): H.265 gives a file about 30% smaller at the same look; falls back to H.264 by itself if the phone has no H.265 encoder. The upscaling itself already runs in OpenGL (the same FSR 1 / denoise / sharpen shaders as the player).

## 3.12.4
- **Panels by purpose**: bubble size and bubble auto-hide / delay (they only exist for the screen layer) are no longer listed in the video, photo, manga and GIF settings panels; they stay on the main screen and in the bubble's own panel.

## 3.12.3
- **Video upscale from a network server (SMB / FTP)**: the file is copied to the phone first (the upscaler needs a seekable file), processed, and the copy is deleted afterwards. Make sure the phone has free space for it.

## 3.12.2
- **Video upscale can be resumed**: the finished one-minute pieces are listed on disk. If the app is killed, the phone restarts or the job fails, start the same file with the same size / quality again and it continues after the last finished piece (the progress bar starts there, the finished part is watchable at once). *Cancel* still throws the work away; leftovers older than a week are removed by themselves.

## 3.12.1
- **Manga**: RAR comics now open: .cbr, and RAR files that were only renamed to .cbz (a very common reason a "cbz" would not open). Pictures are unpacked once into the cache. RAR5 (new format) and 7z are still not supported; the message says so.
- **Online enhance**: small pictures go inside the request (one step fewer that can fail), models that do not know "scale" are retried with the image only, official models (no version) are started through their own endpoint, network errors are named, and a hardware bitmap no longer breaks the resize. HTTP 402 still means the Replicate account has no credit.

## 3.12.0
- **Upscale a video to a new file** (Main screen > *Upscale a video to a new file*, or the player's ⋮ menu): the video is decoded, run through the same GPU effects as the player (denoise / deband / FSR 1 / sharpen, from the *Low-res video* or *Anime* quick-profile tables) and re-encoded with the hardware H.264 encoder to **720p or 1080p**, saved in Movies/ClearOverlay. Three tiers: *Fast* (upscale + sharpen), *Balanced* (+ cleanup), *Best quality* (strongest cleanup, finer sharpening, higher bit rate). Frame rate stays the same (60 fps stays 60 fps); sound is copied untouched. It runs in a foreground service with a progress notification, so the screen can be off; the screen shows progress, speed (seconds of video per second of work) and the time left.
- The result is written in pieces of about a minute. **Watch the finished part** plays the finished pieces while the rest is still being made; at the end they are joined into one file.
- Not yet: resuming after the app was killed, videos on a network server (copy to the phone first), neural (AI) upscaling of video (about 2-3 frames per second on a mid-range phone, hours for a normal video).
- Under the hood the GL pipeline can now take its settings from a fixed set (`Fx.kt`), so an export is not affected by sliders moved meanwhile.

## 3.11.6
- **Separate settings per section**: the screen layer (overlay over other apps), video, photo, manga and GIF each keep their own picture settings (mode FSR / SGSR, render and input / output resolution, sharpen, denoise, contrast, anti-aliasing, quick profile, panel size, FX switches ...). Something chosen in the manga reader no longer changes photos or videos, and so on. The first time a section is used it starts as a copy of the screen layer's current settings, so nothing is lost; after that they are independent. The settings panel title shows which section it belongs to ("... · Manga"). Shared by all: the bubble, language, theme, "pause the overlay while playing".
- Saved user profiles are shared: a profile saved in one section can be applied in another.
- The photo / video split follows the file that is open in the player.

## 3.11.5
- **Manga page slider**: a bar at the bottom with the current page and the total; drag it (or tap the track) to jump far in one go. In right-to-left page mode the slider is mirrored, so page 1 is on the right. It shows and hides with the top bar.
- **Keep the FX button on screen** also in the manga reader (switch in the reader's settings panel): when the bars hide, only the FX button stays, top right.
- **.cbz / .zip**: pictures in any sub-folder of the archive are read (sorted by full path, chapter folders included; Windows-style `\` paths and Thumbs.db handled). The archive is copied to the cache once and reused when you open the same file again. If nothing readable is found, the message now says how many files the archive has and shows a few names, so the cause is visible. RAR / 7z archives renamed to .cbz are still not supported (a real RAR needs an extra library).

## 3.11.4
- **Logo (app icon, header, bubble)**: back to the classic layout, one pixel in each of the four corners around the "+" (big top-left, medium top-right and bottom-left, small bottom-right), the "+" keeps its size, the pixels are a bit bigger than the old ones and all sit inside the safe circle so nothing is cut off. The extra glow behind the plus in the launcher icon was removed.

## 3.11.3
- **App icon (launcher)**: it still had the old pixel squares at the very corners, which a round / squircle launcher mask cut off. Redrawn to match the in-app logo: the "+" and the shrinking pixels all sit inside the adaptive icon's safe circle, with a soft glow behind the plus. The themed (monochrome) icon uses the same shapes.

## 3.11.2
- Fixed a compile error in the settings panel (scope of the render-scale hint) introduced with 3.11.0.

## 3.11.1
- The resolution chain (input / output) now also works for **manga pages** (the page is brought to the input size, rendered at the output short side, capped at 6000 px / 20 MP), for **GIFs** (live), and **saving a photo** has a new entry *Save at the output resolution (JPEG)*.

## 3.11.0
- **Resolution chain (player / photo)**: Settings panel > *Resolution: input → output*. **Input** = what the file really is (Auto, 240p ... 1080p; lower than the file brings it down first, good for soft "fake HD" files). **Output** = the size it is rendered at (Auto = screen, 480p ... 4K). Bigger than the screen = supersampling; smaller than the file = **Downscale** (a clean anti-aliasing); smaller source than output = upscale with the chosen mode (FSR 1 / SGSR 1 / Fast). A live line shows the real chain: *file → work → output → screen*. (Before, the player ignored the render-resolution slider, and FSR 1 / SGSR 1 only differed when the file was smaller than the screen.)
- **Contrast** slider (-50 .. +50) next to Vivid colours; saved in your own profiles.
- **Logo**: smaller and redrawn; the pixel squares sit inside the safe circle so the round bubble no longer cuts them.

## 3.9.5
- **History**: videos and manga left half way are listed in Library > Videos / Manga > *History* (newest first, with the saved spot); tap = continue exactly there, long-press = remove (long-press the History tile = clear all). Finished items drop out by themselves.
- **Manga**: PDF now opens (the file picker no longer filters by type; the file type is detected from the file itself), .cbz with non-UTF-8 names opens, RAR / 7z comics (.cbr / .cb7) say clearly that they are not supported.
- **Panel size** (small / medium / large) is in the manga settings panel too (shared chips).
- **Photo panel**: video-only rows (tap = play/pause, auto-next) are hidden while a photo is open.
- **Quick profile "Manga"**.
- **Online enhance**: smaller upload (x4 photos 1024 px, writing 1280 px), data-URI fallback when the file store refuses, version lookup that survives models without "latest version", automatic retry on rate limit (429), a *Test connection* button in Online settings, and errors are shown in full in a copyable dialog.

## 3.9.0 (stage 1)
- **Themes**: Main screen > Appearance: *Follow phone / Dark / Light* and *Modern / Classic* (flat, square-ish, solid accent). The video, photo, manga and GIF screens stay dark (they sit on black).
- **Player**: FX on/off label is a small tag near the top; settings panel size Small / Medium / Large; speed 0.25x-4x with a slider and presets; orientation key = only Landscape <-> Portrait, with a separate lock key (freezes the current direction) and a separate free key (follows the phone in every direction); a start-up watchdog fixes videos that begin black or with a spinner that never ends (re-attaches the picture, nudges the decoder, reloads at the same spot); big videos (e.g. 4K on a 1080p screen) are processed at most 1.5x the screen size, which makes FX much lighter.
- **Quick profiles**: new *Text* profile (readable thin strokes).
- **Library**: cells are always the same square size, so the folder grid can no longer shrink after switching sections.

## 3.9.1
- **FX in the manga reader**: top bar has an FX button (on/off) and a settings button. The full effects panel (profiles, upscaler, sharpen, denoise, Vivid ...) opens at the bottom; pages are processed off screen with the same GL pipeline as photos and shown in both scroll and horizontal modes. Pages are rebuilt a moment after a slider stops.
- **Online enhance (photos in the player)**: Enhance > *Online enhance*: *Photo x4* or *Clearer writing x2*. Uses Replicate (replicate.com): you add your own API token and (optionally) the model names under *Online settings*. The newest version of the model is looked up at run time; default model `nightmareai/real-esrgan`. Pictures are shrunk to 1600 px before upload to keep the price low. Back cancels. Not tested without internet in the build environment: if it fails, the error text shown tells what went wrong (wrong token, no credit, wrong model name).
- **3.9.2 – online enhance elsewhere**: manga reader top bar `☁` (current page: *Photo x4* / *Clearer writing x2* / settings; tap `☁` again while it works to cancel); screen layer: the still-frame tool (long-press the bubble > AI snapshot) has `☁ x4` and `☁ Aa` buttons for the whole frame. Same token and models as the player. GIF and video are not included (a GIF is dozens of frames, video would be far more costly).

## 3.9.3
- **GIF viewer**: `FX` button + settings (gear): every GIF frame goes through the same local effects pipeline as photos (denoise, upscale, sharpen, Vivid ...). Free and offline, so it is the cheap alternative to cloud upscaling for GIFs (and for video the player's FX does the same). Off by default.
- **Hidden items PIN** (optional): long-press the eye icon in the library to set / change / remove a PIN (4+ digits); with a PIN set, the eye asks for it before showing hidden items. It is a privacy lock inside the app, not encryption: the files themselves stay where they are.
- **Manga**: top-bar icons (gear, cloud, close) match the library's line icons; the cloud menu can also save the current page (with FX or online result) to Pictures/ClearOverlay.

## Two ways to use the effects
1. **Whole screen** (bubble): captures the screen and processes it, so it works over any app / video. A full-screen layer, so it can never be as sharp as the real pixels.
2. **Inside the player** ("Video & photo player", or "Open with" on any video / photo / link): the file is decoded here and the effects are applied ONCE directly to the video frames - no screen capture, better quality, a 360p file is upscaled from its real pixels.
While the player is in front the screen effect is paused automatically (switch in the player's settings), so the picture is never processed twice; it is restored when you leave the player.

## Video & photo player
Pipeline: denoise / deband / anti-aliasing -> FSR 1 / SGSR 1 / Fast upscale -> sharpen -> Vivid.
- Engine: Media3 ExoPlayer. Local files, direct links (http/https), HLS (.m3u8), DASH (.mpd); mp4/mkv/webm...
- Top bar: **FX** = effects on/off (compare with the original picture), **rotation** (auto by video / landscape / portrait / follow phone), settings, menu.
- **Zoom**: pinch with two fingers (up to 12x) or tap the zoom button (1x / 2x / 4x / 8x). Zoomed in, one finger pans. The crop is taken from the real source pixels and goes through the whole pipeline, so you can switch FX on/off and compare the result at pixel level.
- Settings panel: effects on/off, "tap = play/pause" on/off (off = a tap only shows/hides the controls), pause screen effect while the player is open, plus all the picture sliders. While a slider is held the panel becomes almost transparent so the picture can be judged; it also closes itself after ~7 s idle (switch: "Fade the panel while adjusting"). In landscape it is a narrow column on the right.
- Subtitles: embedded tracks (CC button) or an external .srt/.vtt/.ass file (menu > Add subtitle file; non-UTF-8 files such as Windows-1256 Persian are converted automatically). Size adjustable in the menu.
- Audio track picker, speed 0.5x-2x, resume position, fit/fill picture.
- Gestures: single tap = play/pause (switchable), double tap left/right = -/+10 s, double tap centre = play/pause, horizontal drag = seek, vertical drag on the left = brightness, on the right = volume, long press = 2x speed while held.
- Photos are capped at 4096 px on the long side.
- Black picture + sound only (fixed in 3.2.0): the picture view used to be created only after the decoder reported a size, which it does not do before it has a surface. The view is now created from the track format, with a 1.5 s fallback.

## Photo tools (3.5.0)
Open a photo in the player; the bottom bar shows three buttons:
- **Enhance**: *Smart fix* (instant, no model: white balance + levels + shadow lift, measured from the photo's own histogram; does nothing if the photo is already balanced) or *AI upscale x4* (offline Real-ESRGAN General x4v3 through LiteRT / TensorFlow Lite on the CPU). Several models can be kept: the built-in one plus any .tflite you add by hand (Enhance > "AI models" > add from file or from a direct link; choose the active one there, remove added ones). No model is bundled in the APK or the zip any more: open Enhance > "AI models" > "Recommended models" and tap one to download it (Real-ESRGAN General x4v3, XLSR, QuickSRNet, SESR-M5). To bundle your own anyway, put it at app/src/main/assets/models/sr.tflite. The photo is cut into overlapping 128 px tiles; progress is shown, Back cancels. Input is limited to 1024 px on the long side so the result stays within 4096 px. Expect tens of seconds for a small photo and a few minutes for a 1024 px one on a mid-range phone.
- **Save**: renders the photo through the whole effect pipeline offscreen at full size (or 2x) and writes JPEG / PNG to Pictures/ClearOverlay (MediaStore, no storage permission). What you see (including the FX on/off state) is what is saved.
- **Original**: back to the decoded file.
- The rotation button now has 5 states: auto, landscape, portrait, follow phone, **locked** (keeps the current orientation). The icon shows the state.

## Updating over an old install
Every build is signed with the same fixed key (app/crsc.keystore, debug and release) and versionCode is the build time in minutes, so a new build installs over the old one as an update. A build signed with a different key (every build before 3.5.0) cannot be updated: uninstall it once, then install 3.5.0; from then on updates work. Keep app/crsc.keystore in your repo/zip - a different key breaks updates again.

## My profiles (3.6.0)
The first row of the settings panel (main screen, bubble panel and player panel all share it). Tune the sliders by hand, tap **＋ Save**, give it a name: every picture setting (mode, sharpness, detail, denoise, deband, anti-aliasing, render scale, vivid, boost) is stored. Tap a saved profile to get exactly those values back; long-press it to update it with the current settings or delete it.
- Quick profiles never touch saved ones. The profile you loaded stays highlighted until you change anything by hand.
- Safety net: when a quick profile is about to replace hand-made settings, the app copies them into **↩ Before quick profile** first, so one tap brings them back.
- Bubble settings (size, auto-hide) are not part of a profile.

## More AI models (3.6.0)
Enhance > "AI models" > **Recommended models**: one tap downloads, unpacks (Qualcomm ships .zip files) and selects a model. All run offline on the CPU, tile by tile; the upscale factor (x2 / x3 / x4) is read from the model itself.
| Model | Size | Notes |
|---|---|---|
| Real-ESRGAN General x4v3 | ~5 MB | best detail, slowest |
| XLSR | ~115 KB | fastest, softest |
| QuickSRNet Small / Medium / Large | 0.1 - 0.4 MB | light; Medium is a good first pick for photos |
| SESR-M5 | ~1.3 MB | better quality, slower than QuickSRNet |
Only **float** .tflite models work (not the w8a8 ones). Direct links (zip or plain .tflite) can also be pasted under "Add model from link", or a downloaded file picked with "Add model from file".
AI is photo-only: running a neural network on every video frame is far beyond a mid-range phone (about 2-3 frames per second at best), so video keeps using the GPU shaders (FSR 1 / SGSR 1 / denoise / deband).

## 3.7.0: library, playlist, panel lock, Auto
- **Library** (main screen, first button; also ⋮ > Library in the player): your videos, photos and manga straight from the phone's media index, no file manager. Tabs Videos / Photos / Manga, folders, thumbnails, duration badges. First run asks for photo/video access (READ_MEDIA_* / READ_EXTERNAL_STORAGE on Android 12). "📂" = the old picker / link entry.
- **Playlist**: opening an item from the library (or "Open with" on a media-store file) builds a playlist of the SAME type in that folder: photos swipe left / right (not when zoomed), videos use ⏮ ⏭ and can auto-play the next one ("Play the next video automatically"). Videos and photos are never mixed.
- **Manga**: any image folder (Manga tab) or a .cbz / .zip opens in the reader: Scroll (webtoon) or Pages (pinch zoom, swipe or tap edges, right-to-left switch). The last page is remembered. The reader has no effects pipeline.
- **Player panel**: 🔒 / 🔓 next to its title: unlocked, drag the panel by the title to move it away from the picture. New settings: panel opacity while adjusting (100% = never dims), "close the panel by itself when idle" on/off.
- **Auto** (top of every settings panel): picks quick profile, strength, GPU budget, anti-aliasing, mode and AI model by itself. Player video: content type from resolution / frame rate / stream, strength from the enlargement, budget from the pixel rate and lowered when frames drop. Photo: strength from size, Quality budget, AI model by size (small = best model; a very small photo is AI-upscaled automatically). Screen overlay: light all-round profile, then a ladder Fast 80% > Performance > Balanced > Quality moved by the measured time per frame. Touch any control and Auto switches off. These are rules of thumb, not measured on a device.

## AI still frame (3.6.0)
Live AI on every screen frame is too heavy for a mid-range phone, but one frame is fine. With the screen effect ON, open the bubble panel and tap **✨ AI frame**:
1. The current screen is grabbed exactly as it is (no effects), the live effect pauses and the picture freezes.
2. **Drag over an area** to enhance just that part (best: the model sees real pixels, and it is much faster), or tap **Whole screen** (the frame is shrunk first so the result stays under ~16 MP). Tap the model name at the top to switch between installed models.
3. The result opens zoomable (pinch, drag, double-tap = fit). **Save** writes a PNG to Pictures/ClearOverlay. **Back** returns to the frozen frame to try another area or model; **Close** resumes the live effect.
Needs at least one downloaded AI model. Files: AiSnap.kt (viewer), GlPipeline.rawFrame(), OverlayService.startAiSnap().

## Quick profiles
Content type x strength (Light / Balanced / Strong, plus Auto in the player) x GPU budget (Performance / Balanced / Quality). Six types: **Low-res video**, **Stream / Moonlight**, **Game**, **Low-quality photo**, **HD movie**, **Anime / cartoon**. Selecting one shows a one-line description of what it is for.
- Values live in `Profiles.kt` as explicit tables (no more "one multiplier for everything"), with two flavours:
  - **Player**: cleanup (denoise / deband / AA) runs on the real source pixels before FSR 1 upscales, so it removes real blocks.
  - **Screen overlay**: the capture already contains the stretched picture, so denoise is lower, Detail uses a wider radius, and AA is mostly off. Always Sharpen mode (the capture stays full size).
- **Strength** = how much help the picture needs. **GPU budget** = how much work per frame (like DLSS):
  - Performance: upscale + sharpen only. Detail / denoise / deband / Edge Smooth off, FXAA stays Fast; in the player the hardware bilinear upscale replaces FSR 1. Cheapest.
  - Balanced: the tables as designed.
  - Quality: FXAA Fast becomes FXAA Quality, and the player uses FSR 1 from 1.02x enlargement instead of 1.15x. A modest step: the app has no heavier algorithm to switch on.
- Game: sharpen + FXAA only, no cleanup passes (cheapest, lowest latency, HUD text stays crisp). Light uses FXAA Fast.
- HD movie: almost transparent. No denoise (it would erase film grain), light deband only.
- Anime: strongest deband, clean flat areas, Edge Smooth on line art (player only).
- In the player FSR 1 is used only when the picture is enlarged more than 1.15x; at about 1:1 plain RCAS is used. Auto picks the strength from the enlargement (<1.2x light, <2.2x balanced, else strong).
- They are starting points derived from what each shader does, not measured optima: use FX + Zoom to judge and fine-tune. Touching any slider switches to custom.

## Build
Android Studio: open the folder, Build > Build APK(s).
GitHub Actions: put ClearOverlay.zip and .github/workflows/build.yml in a repo (workflow unzips it).

## Troubleshooting
- Image repeats like a tunnel / goes black: the overlay could not be hidden from its own capture.
- Touches do not reach the app below: pass-through failed on your ROM.
- A toast with a shader/GL message: send it. Logs: `adb logcat -s CRSC`

## Files
- Shaders.kt: FSR1 / SGSR1 / RCAS (GLSL ES 3.0). GlPipeline.kt: the passes.
- Enhance.kt: Smart fix. AiSr.kt: offline AI tiles (LiteRT). GlPipeline.snapshot(): offscreen render for Save.
- OverlayService.kt: capture + overlay. Bubble.kt: floating bubble + panel. Win.kt: hidden-API tricks.

## 3.23.0
- New "Edit video" screen (main screen): cut a part (from – to), mute the sound, turn the picture. No re-encoding; saved to Movies/ClearOverlay.
- CRSC upscaler: Lanczos + edge refine pass ("CRSC Edge").
- Temporal denoise option (previous frames) for video export and the player; included in the full-auto mode.
- Better frame-generation interpolation; CRSC listed before Raw/Fast.
- Not compiled or tested in this environment.

## 3.24.0
- "Watch now" (stream) is now like a video site: the player shows the whole timeline; only the part around the spot you watch is prepared (the "ahead" setting). Drag the bar to any minute: that spot is prepared and plays after a short wait; pieces far from the viewer (behind or ahead) are deleted.
- Stream worker: jump requests, no double work on pieces that already exist, history reset after a jump (no blending across a cut), fixed a counter bug that could hide new pieces after old ones were deleted.
- Not compiled or tested in this environment.

## 3.25.0
- New logo look: pure white pixel squares with soft shadows, 3D "+" (depth, shadow, light edge) in the app header, bubble and launcher icon.
- Share: player (top bar), library (selection bar) and the finished upscale result open the system share sheet.
- Manga archives: pictures in sub-folders named cover / variant / extra / bonus go after the real pages; the failure message now shows the error type.
- Not compiled or tested in this environment.

## 3.26.0
- Player top bar: buttons shrink on narrow (portrait) screens so ⚙ and ⋮ stay visible; Share moved into the ⋮ menu.
- FG / Temporal / quality / multiplier rows in the player panel are now scrolling chips like the rest of the app (the chosen one is highlighted).
- Orientation: photos and videos are fully separate (the old shared setting is no longer used). Panel size is re-applied when the media kind changes.
- CRSC upscaler rebuilt: edge-directed Lanczos (structure tensor, 6x6 taps stretched along edges) + edge smoothing + edge steepening + RCAS. Fast stays the plain bilinear + RCAS mode.
- Manga archives with several book folders: choose which book to read (or all pages); cover/extra folders go last.
- Frame generation: motion search runs on a copy at most 960 px wide (much less GPU work at 1440p/4K).
- Logo: glossy tile, deeper gradient.
- Not compiled or tested in this environment.

## 3.26.1
- Player panel: the panel size row is now at the top; Temporal and Frame generation have their own sections with the same label style as the rest.

## 3.26.2
- Temporal clean-up was skipped in Raw mode and when a fixed output size was chosen; it now runs before every output path. Stronger blend (light 50 %, strong 78 %) so the difference is visible.

## 3.27.0
- CRSC: smoothing only on clear edges (texture stays crisp), stronger edge steepening, sharper across-edge kernel, two RCAS passes (three with Boost).
- Frame generation: light mode used 8-px steps and missed small motions (it behaved like frame doubling); all levels now search with 4-px steps and finish with a 1-px refinement.

## 3.28.0
- CRSC: new scale-aware finishing sharpen (unsharp mask whose radius follows the enlargement factor; acts on mid-contrast detail, spares flat areas and strong edges, clamped to the local range) before RCAS. Strength follows the Sharpness slider. RCAS is back to one pass (two with Boost).

## 3.28.1
- Logo: colours swapped — the "+" is now white (3D, soft violet depth) and the pixel squares carry the cyan → violet gradient.

## 3.28.2
- Manga: a page that cannot be read the normal way is now read by scanning the archive from the start (odd directories / name encodings); decode errors are shown (once) instead of leaving a blank page; a failed opening shows a dialog with the error and a Copy button.

## 3.28.3
- Manga archives: files without a known picture extension are recognised by their first bytes (JPEG / PNG / GIF / WebP / BMP / AVIF / HEIC), in both the normal and the streaming reader. An empty RAR now reports "no pictures" instead of a blank "No pages found".

## 3.28.4
- Manga: the "no pictures" message lists up to 10 file paths from inside the archive, so the real structure can be seen.

## 3.29.0
- Offline AI for video: the levels now get faster as they get lighter (Light used a bigger input picture than Medium, which made it slower). Input heights: Very light 144, Light 240, Medium 288, Heavy 216 px.
- New "Very light" level and an "Auto" choice: Auto picks the best level that should finish in about 20 minutes (using the saved speed test, the chosen time range and the frame count) and halves the frames if needed.

## 3.29.1
- Export progress: the video length ("x of y", percentage, time left) now comes from the last picture of the video track instead of the stored duration, which is wrong in some files (cut / re-muxed by messengers).

## 3.30.0
- CRSC Edge rebuilt on EASU + edge steepening + scale-aware sharpen (lighter, cleaner).
- Temporal rewritten with neighbourhood clamping (less ghosting, better quality).
- FG: new "very light" quality level.
- Manga: RAR5 (stored) archives named .cbz/.cbr now open; clearer message for compressed RAR5.
- Light theme: bubble settings text now readable.
- "Keep this much" chips only shown for Watch-now streaming.
- Library: pinch zoom on folders no longer crashes / overlaps tiles.

## 3.31.0
- Edit video: new output modes (video / audio only .m4a / single frame JPG), speed change (0.5×–8×, no sound), split into parts every N minutes.
- Launcher icon redesigned: clean gradient ring with a rounded white plus.

## 3.31.1
- In-app logo (LogoView) now matches the launcher icon.

## 3.31.2
- Temporal: only low frequencies averaged over time, moving areas untouched (no softening / odd motion).
- CRSC Edge: removed edge steepening (looked artificial/layered), gentler smoothing and sharpening.

## 3.32.0
- CRSC rebuilt: EASU + iterative back-projection (shrink, compare with the source, add the difference back, range-limited). Measured offline in a WebGL harness: +0.6 dB PSNR and crisper lines vs FSR 1; no artificial edge steepening.
- Temporal: per-pixel recursive filter with motion-compensated history clamped to the neighbourhood and an exponential similarity weight (offline test: +3.5..+5.9 dB on noisy clips, static and panning).
