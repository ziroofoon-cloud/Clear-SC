# Clear Overlay

Tiny Android app (~100-200 KB, no libraries). Captures the screen, sharpens (and optionally
upscales) every frame on the GPU, and shows it in a touch-transparent full-screen overlay.
Requires Android 12+ (minSdk 31).

## Build
- Android Studio: open this folder -> Build > Build APK(s).

## Use
1. Start -> allow "Display over other apps" -> allow screen capture.
2. Open your game/app. Adjust Sharpness live from the notification/app.
3. Render scale 100% = sharpen only. Lower = capture smaller, then upscale back.

## If something looks wrong
- Image repeats like a tunnel / goes black: the overlay could not be hidden from
  its own capture on your ROM (a toast appears when that happens).
- Touches do not reach the app below: pass-through failed on your ROM.
- Logs: `adb logcat -s ClearOverlay ClearGl`

## Files that matter
- GlPipeline.kt: shaders (upscale + sharpen), EGL.
- OverlayService.kt: capture, overlay window, capture-exclusion, touch pass-through.
