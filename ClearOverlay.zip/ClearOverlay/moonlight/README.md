# moonlight (embedded game-streaming client)

This module is the Artemis / Moonlight Android client (ClassicOldSong/moonlight-android, tag v20.2.6, GPL-3.0), packed as a
library so it runs inside this app (opened from the main screen: "PC game streaming").

The large third-party native sources are NOT in the zip; the GitHub Actions workflow downloads them before building:
`src/main/jni/moonlight-core/moonlight-common-c` (git submodule), `libopus` and `openssl` (prebuilt static libraries).
To build on your own computer, run the same `git clone --recurse-submodules --branch v20.2.6` step by hand and copy those
three folders into `src/main/jni/moonlight-core/`.
