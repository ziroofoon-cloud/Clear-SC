plugins {
    id("com.android.library")
}

android {
    namespace = "com.limelight"
    compileSdk = 35
    // the build machine's NDK (passed by the workflow); without it Gradle uses its default one
    (findProperty("ndkVersion") as String?)?.let { ndkVersion = it }

    defaultConfig {
        // the host app needs 31 anyway
        minSdk = 31
        consumerProguardFiles("consumer-rules.pro")

        // the code reads these from BuildConfig; in a library they are not generated, so they are set by hand
        buildConfigField("boolean", "ROOT_BUILD", "false")
        buildConfigField("String", "APPLICATION_ID", "\"app.clearoverlay\"")
        buildConfigField("String", "VERSION_NAME", "\"20.2.6-clear\"")

        // strings the original build generated per flavour / build type
        resValue("string", "app_label", "Streaming")
        resValue("string", "app_label_root", "Streaming (Root)")
        resValue("string", "app_label_game", "Streaming (Game)")
        resValue("string", "obtainium_app_url", "https://github.com/ClassicOldSong/moonlight-android/releases")

        ndk { abiFilters += listOf("arm64-v8a") }
        externalNativeBuild {
            ndkBuild {
                arguments("PRODUCT_FLAVOR=nonRoot")
                abiFilters += listOf("arm64-v8a")
            }
        }
    }

    buildFeatures {
        buildConfig = true
        resValues = true
    }

    externalNativeBuild {
        ndkBuild { path = file("src/main/jni/Android.mk") }
    }

    compileOptions {
        encoding = "UTF-8"
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    lint { disable += "MissingTranslation" }
}

dependencies {
    implementation("org.bouncycastle:bcprov-jdk18on:1.81")
    implementation("org.bouncycastle:bcpkix-jdk18on:1.81")
    implementation("org.jcodec:jcodec:0.2.5")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jmdns:jmdns:3.6.1")
    implementation("com.github.cgutman:ShieldControllerExtensions:1.0.1")
    implementation("com.google.code.gson:gson:2.13.1")
    implementation("androidx.annotation:annotation:1.9.1")
    implementation("androidx.cardview:cardview:1.0.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("androidx.preference:preference:1.2.1")
    implementation("androidx.recyclerview:recyclerview:1.4.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.github.ByteHamster:SearchPreference:v2.5.1")
}
