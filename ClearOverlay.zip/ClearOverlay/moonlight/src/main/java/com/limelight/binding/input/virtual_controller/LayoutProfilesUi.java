package com.limelight.binding.input.virtual_controller;

import android.app.AlertDialog;
import android.content.Context;
import android.text.InputType;
import android.widget.EditText;
import android.widget.Toast;

import com.limelight.R;

import java.util.List;
import java.util.function.Consumer;

/** The dialogs that switch, create, rename, duplicate and delete layout profiles (keyboard and controller). */
public final class LayoutProfilesUi {
    private LayoutProfilesUi() {}

    /**
     * Shows the profile list: tap a profile to use it. [beforeOpen] runs first (saves edits that are not saved yet),
     * [onChanged] runs after the active profile or its content changed (reload the layout there).
     */
    public static void show(final Context ctx, final String kind, final Runnable beforeOpen, final Runnable onChanged) {
        if (beforeOpen != null) beforeOpen.run();
        final List<LayoutProfiles.Profile> ps = LayoutProfiles.list(ctx, kind);
        final String act = LayoutProfiles.activeId(ctx, kind);
        CharSequence[] names = new CharSequence[ps.size()];
        int checked = 0;
        for (int i = 0; i < ps.size(); i++) {
            names[i] = ps.get(i).name;
            if (ps.get(i).id.equals(act)) checked = i;
        }
        new AlertDialog.Builder(ctx)
                .setTitle(title(ctx, kind))
                .setSingleChoiceItems(names, checked, (d, which) -> {
                    d.dismiss();
                    LayoutProfiles.setActive(ctx, kind, ps.get(which).id);
                    changed(onChanged);
                })
                .setPositiveButton(R.string.layout_profile_new, (d, w) -> askNew(ctx, kind, onChanged))
                .setNeutralButton(R.string.layout_profile_manage, (d, w) -> manage(ctx, kind, onChanged))
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private static String title(Context ctx, String kind) {
        return ctx.getString(LayoutProfiles.KIND_KEYBOARD.equals(kind)
                ? R.string.layout_profiles_keyboard_title : R.string.layout_profiles_controller_title);
    }

    private static void changed(Runnable onChanged) {
        if (onChanged != null) onChanged.run();
    }

    private static EditText nameBox(Context ctx, String initial) {
        EditText et = new EditText(ctx);
        et.setSingleLine(true);
        et.setInputType(InputType.TYPE_CLASS_TEXT);
        et.setHint(R.string.layout_profile_name_hint);
        et.setText(initial);
        et.setSelection(et.getText().length());
        return et;
    }

    private static void askNew(final Context ctx, final String kind, final Runnable onChanged) {
        final List<LayoutProfiles.Profile> ps = LayoutProfiles.list(ctx, kind);
        final EditText et = nameBox(ctx, "Layout " + (ps.size() + 1));
        final String current = LayoutProfiles.activeId(ctx, kind);
        new AlertDialog.Builder(ctx)
                .setTitle(R.string.layout_profile_new_title)
                .setView(et)
                .setPositiveButton(R.string.layout_profile_create_empty, (d, w) -> {
                    LayoutProfiles.create(ctx, kind, et.getText().toString(), null);
                    changed(onChanged);
                })
                .setNeutralButton(R.string.layout_profile_create_copy, (d, w) -> {
                    LayoutProfiles.create(ctx, kind, et.getText().toString(), current);
                    changed(onChanged);
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private static void manage(final Context ctx, final String kind, final Runnable onChanged) {
        final List<LayoutProfiles.Profile> ps = LayoutProfiles.list(ctx, kind);
        CharSequence[] names = new CharSequence[ps.size()];
        for (int i = 0; i < ps.size(); i++) names[i] = ps.get(i).name;
        new AlertDialog.Builder(ctx)
                .setTitle(R.string.layout_profile_manage)
                .setItems(names, (d, which) -> actions(ctx, kind, ps.get(which), onChanged))
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private static void actions(final Context ctx, final String kind, final LayoutProfiles.Profile p, final Runnable onChanged) {
        CharSequence[] items = {
                ctx.getString(R.string.layout_profile_rename),
                ctx.getString(R.string.layout_profile_duplicate),
                ctx.getString(R.string.layout_profile_delete)
        };
        new AlertDialog.Builder(ctx)
                .setTitle(p.name)
                .setItems(items, (d, which) -> {
                    if (which == 0) {
                        final EditText et = nameBox(ctx, p.name);
                        new AlertDialog.Builder(ctx)
                                .setTitle(R.string.layout_profile_rename)
                                .setView(et)
                                .setPositiveButton(android.R.string.ok, (d2, w2) -> {
                                    LayoutProfiles.rename(ctx, kind, p.id, et.getText().toString());
                                    changed(onChanged);
                                })
                                .setNegativeButton(android.R.string.cancel, null)
                                .show();
                    } else if (which == 1) {
                        LayoutProfiles.create(ctx, kind, p.name + " 2", p.id);
                        changed(onChanged);
                    } else {
                        if (LayoutProfiles.list(ctx, kind).size() <= 1) {
                            Toast.makeText(ctx, R.string.layout_profile_last, Toast.LENGTH_SHORT).show();
                            return;
                        }
                        new AlertDialog.Builder(ctx)
                                .setMessage(ctx.getString(R.string.layout_profile_delete_confirm, p.name))
                                .setPositiveButton(android.R.string.ok, (d2, w2) -> {
                                    LayoutProfiles.delete(ctx, kind, p.id);
                                    changed(onChanged);
                                })
                                .setNegativeButton(android.R.string.cancel, null)
                                .show();
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }
}
