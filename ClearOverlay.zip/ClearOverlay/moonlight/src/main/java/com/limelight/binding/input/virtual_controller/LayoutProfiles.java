package com.limelight.binding.input.virtual_controller;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.preference.PreferenceManager;

import com.limelight.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Named layout profiles for the on-screen keyboard and the on-screen game controller.
 *
 * Every profile keeps the positions / sizes / visibility of the elements in its own SharedPreferences file (the id of
 * the profile is the name of that file), so the old single layouts ("OSC_Keyboard", "OSC") simply become the first
 * profile and nothing the user saved is lost. The active profile is stored where the old code already looked for it
 * ("keyboard_axi_list" for the keyboard), so every loader / saver only has to ask [activeDataName].
 */
public final class LayoutProfiles {
    public static final String KIND_KEYBOARD = "keyboard";
    public static final String KIND_CONTROLLER = "controller";

    private static final String STORE = "layout_profiles";
    private static final int MAX_NAME = 40;

    public static final class Profile {
        public final String id;
        public final String name;

        Profile(String id, String name) {
            this.id = id;
            this.name = name;
        }
    }

    private LayoutProfiles() {}

    private static boolean isKeyboard(String kind) {
        return KIND_KEYBOARD.equals(kind);
    }

    private static String activeKey(String kind) {
        return isKeyboard(kind) ? "keyboard_axi_list" : "osc_active_profile";
    }

    private static String firstId(String kind) {
        return isKeyboard(kind) ? "OSC_Keyboard" : "OSC";
    }

    private static SharedPreferences defaults(Context c) {
        return PreferenceManager.getDefaultSharedPreferences(c);
    }

    /** The id of the active profile (= name of the SharedPreferences file with its element data). */
    public static String activeId(Context c, String kind) {
        String id = defaults(c).getString(activeKey(kind), firstId(kind));
        return (id == null || id.isEmpty()) ? firstId(kind) : id;
    }

    /** Name of the SharedPreferences file the loaders / savers must use. */
    public static String activeDataName(Context c, String kind) {
        return activeId(c, kind);
    }

    public static String activeName(Context c, String kind) {
        String id = activeId(c, kind);
        for (Profile p : list(c, kind)) {
            if (p.id.equals(id)) return p.name;
        }
        return id;
    }

    public static List<Profile> list(Context c, String kind) {
        List<Profile> out = read(c, kind);
        boolean changed = false;
        if (out == null) {
            out = seed(c, kind);
            changed = true;
        }
        String act = activeId(c, kind);
        if (!contains(out, act)) {
            out.add(new Profile(act, defaultName(c, kind, act)));
            changed = true;
        }
        if (changed) write(c, kind, out);
        return out;
    }

    public static void setActive(Context c, String kind, String id) {
        defaults(c).edit().putString(activeKey(kind), id).apply();
    }

    /** Creates a profile (empty = the default layout, or a copy of [copyFromId]) and makes it the active one. */
    public static String create(Context c, String kind, String name, String copyFromId) {
        List<Profile> ps = list(c, kind);
        String id = (isKeyboard(kind) ? "OSC_Keyboard_" : "OSC_") + Long.toString(System.currentTimeMillis(), 36);
        SharedPreferences.Editor e = c.getSharedPreferences(id, Context.MODE_PRIVATE).edit();
        e.clear();
        if (copyFromId != null) {
            Map<String, ?> all = c.getSharedPreferences(copyFromId, Context.MODE_PRIVATE).getAll();
            for (Map.Entry<String, ?> en : all.entrySet()) {
                if (en.getValue() instanceof String) e.putString(en.getKey(), (String) en.getValue());
            }
        }
        e.apply();
        ps.add(new Profile(id, cleanName(name, ps.size() + 1)));
        write(c, kind, ps);
        setActive(c, kind, id);
        return id;
    }

    public static void rename(Context c, String kind, String id, String name) {
        List<Profile> ps = list(c, kind);
        List<Profile> out = new ArrayList<>();
        for (Profile p : ps) {
            out.add(p.id.equals(id) ? new Profile(id, cleanName(name, out.size() + 1)) : p);
        }
        write(c, kind, out);
    }

    /** Deletes a profile and its saved positions; the last remaining profile cannot be deleted. */
    public static boolean delete(Context c, String kind, String id) {
        List<Profile> ps = list(c, kind);
        if (ps.size() <= 1) return false;
        List<Profile> out = new ArrayList<>();
        for (Profile p : ps) {
            if (!p.id.equals(id)) out.add(p);
        }
        c.getSharedPreferences(id, Context.MODE_PRIVATE).edit().clear().apply();
        write(c, kind, out);
        if (activeId(c, kind).equals(id)) setActive(c, kind, out.get(0).id);
        return true;
    }

    // ---------------------------------------------------------------- storage
    private static boolean contains(List<Profile> ps, String id) {
        for (Profile p : ps) {
            if (p.id.equals(id)) return true;
        }
        return false;
    }

    private static String cleanName(String name, int number) {
        String n = name == null ? "" : name.trim();
        if (n.isEmpty()) n = "Layout " + number;
        return n.length() > MAX_NAME ? n.substring(0, MAX_NAME) : n;
    }

    private static String defaultName(Context c, String kind, String id) {
        if (isKeyboard(kind)) {
            int[] res = {R.string.keyboard_layout_set_1, R.string.keyboard_layout_set_2, R.string.keyboard_layout_set_3,
                    R.string.keyboard_layout_set_4, R.string.keyboard_layout_set_5};
            if ("OSC_Keyboard".equals(id)) return c.getString(res[0]);
            for (int i = 2; i <= 5; i++) {
                if (("OSC_Keyboard_" + i).equals(id)) return c.getString(res[i - 1]);
            }
            return id;
        }
        return "OSC".equals(id) ? c.getString(R.string.layout_profile_controller_default) : id;
    }

    private static List<Profile> seed(Context c, String kind) {
        List<Profile> out = new ArrayList<>();
        out.add(new Profile(firstId(kind), defaultName(c, kind, firstId(kind))));
        if (isKeyboard(kind)) {
            // the old fixed slots 2..5 count as profiles when the user had saved something in them
            for (int i = 2; i <= 5; i++) {
                String id = "OSC_Keyboard_" + i;
                if (!c.getSharedPreferences(id, Context.MODE_PRIVATE).getAll().isEmpty()) {
                    out.add(new Profile(id, defaultName(c, kind, id)));
                }
            }
        }
        return out;
    }

    private static List<Profile> read(Context c, String kind) {
        String json = c.getSharedPreferences(STORE, Context.MODE_PRIVATE).getString("list_" + kind, null);
        if (json == null) return null;
        try {
            JSONArray a = new JSONArray(json);
            List<Profile> out = new ArrayList<>();
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                String id = o.getString("id");
                if (!contains(out, id)) out.add(new Profile(id, o.optString("name", id)));
            }
            return out.isEmpty() ? null : out;
        } catch (Exception e) {
            return null;
        }
    }

    private static void write(Context c, String kind, List<Profile> ps) {
        try {
            JSONArray a = new JSONArray();
            for (Profile p : ps) {
                JSONObject o = new JSONObject();
                o.put("id", p.id);
                o.put("name", p.name);
                a.put(o);
            }
            c.getSharedPreferences(STORE, Context.MODE_PRIVATE).edit().putString("list_" + kind, a.toString()).apply();
        } catch (Exception ignored) {
        }
    }
}
