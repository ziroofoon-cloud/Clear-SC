package com.limelight.binding.input.virtual_controller.keyboard;

import android.graphics.Rect;
import android.view.KeyEvent;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Ready-made layouts for the on-screen keyboard (a real keyboard arrangement, a gaming layout and a numpad).
 * Every key has the same element id the loader uses ("key_<android key code>", "m_<mouse button>"), so a layout only
 * moves / shows existing elements, or creates the missing ones, and the saved profile keeps working.
 */
public final class KeyboardLayoutPresets {
    public static final int FULL = 0;
    public static final int GAMING = 1;
    public static final int NUMPAD = 2;

    /** One key of a layout: what it is and where it goes (pixels). */
    public static final class Slot {
        public final String elementId;
        public final int code;
        public final int type; // 0 keyboard key, 1 mouse button
        public final String name;
        public final Rect rect;

        Slot(String elementId, int code, int type, String name, Rect rect) {
            this.elementId = elementId;
            this.code = code;
            this.type = type;
            this.name = name;
            this.rect = rect;
        }
    }

    public static String idOf(int type, int code) {
        return type == 0 ? "key_" + code : "m_" + code;
    }

    private static final class Grid {
        final List<Slot> slots = new ArrayList<>();
        final int ox;
        final int oy;
        final float cw;
        final float ch;
        final int gap;

        Grid(int ox, int oy, float cw, float ch) {
            this.ox = ox;
            this.oy = oy;
            this.cw = cw;
            this.ch = ch;
            this.gap = Math.max(3, (int) (Math.min(cw, ch) * 0.06f));
        }

        void put(int type, int code, String name, float col, float row, float w, float h) {
            int l = ox + Math.round(col * cw) + gap / 2;
            int t = oy + Math.round(row * ch) + gap / 2;
            int r = ox + Math.round((col + w) * cw) - gap / 2;
            int b = oy + Math.round((row + h) * ch) - gap / 2;
            slots.add(new Slot(idOf(type, code), code, type, name, new Rect(l, t, r, b)));
        }

        void key(int code, String name, float col, float row, float w, float h) {
            put(0, code, name, col, row, w, h);
        }

        void key(int code, String name, float col, float row) {
            put(0, code, name, col, row, 1f, 1f);
        }
    }

    public static List<Slot> build(int preset, int screenW, int screenH) {
        switch (preset) {
            case GAMING:
                return gaming(screenW, screenH);
            case NUMPAD:
                return numpad(screenW, screenH);
            default:
                return full(screenW, screenH);
        }
    }

    /** The same slots as a map from element id, in layout order. */
    public static Map<String, Slot> byId(List<Slot> slots) {
        Map<String, Slot> m = new LinkedHashMap<>();
        for (Slot s : slots) {
            m.put(s.elementId, s);
        }
        return m;
    }

    /** Vertical position of the top of the full keyboard (the custom shortcut row is placed above it). */
    public static int fullTop(int screenW, int screenH) {
        List<Slot> l = full(screenW, screenH);
        int top = screenH;
        for (Slot s : l) {
            top = Math.min(top, s.rect.top);
        }
        return top;
    }

    // ---------------------------------------------------------------------------------------------

    /** A normal keyboard: 15 columns, 6 rows, at the bottom of the screen. */
    public static List<Slot> full(int sw, int sh) {
        int margin = Math.max(8, (int) (sw * 0.015f));
        float cw = (sw - 2f * margin) / 15f;
        float ch = Math.min(cw * 0.8f, sh * 0.095f);
        Grid g = new Grid(margin, Math.round(sh - margin - 6f * ch), cw, ch);

        // row 0: Esc, F1..F12, Del
        g.key(KeyEvent.KEYCODE_ESCAPE, "Esc", 0, 0);
        for (int i = 0; i < 12; i++) {
            g.key(KeyEvent.KEYCODE_F1 + i, "F" + (i + 1), 1 + i, 0);
        }
        g.key(KeyEvent.KEYCODE_FORWARD_DEL, "Del", 13, 0);

        // row 1: ` 1..0 - = Backspace
        g.key(KeyEvent.KEYCODE_GRAVE, "`", 0, 1);
        for (int i = 0; i < 9; i++) {
            g.key(KeyEvent.KEYCODE_1 + i, String.valueOf(i + 1), 1 + i, 1);
        }
        g.key(KeyEvent.KEYCODE_0, "0", 10, 1);
        g.key(KeyEvent.KEYCODE_MINUS, "-", 11, 1);
        g.key(KeyEvent.KEYCODE_EQUALS, "=", 12, 1);
        g.key(KeyEvent.KEYCODE_DEL, "\u232B", 13, 1, 2, 1);

        // row 2: Tab Q..P [ ] \
        g.key(KeyEvent.KEYCODE_TAB, "Tab", 0, 2, 1.5f, 1);
        int[] r2 = {KeyEvent.KEYCODE_Q, KeyEvent.KEYCODE_W, KeyEvent.KEYCODE_E, KeyEvent.KEYCODE_R, KeyEvent.KEYCODE_T,
                KeyEvent.KEYCODE_Y, KeyEvent.KEYCODE_U, KeyEvent.KEYCODE_I, KeyEvent.KEYCODE_O, KeyEvent.KEYCODE_P};
        String q = "QWERTYUIOP";
        for (int i = 0; i < r2.length; i++) {
            g.key(r2[i], String.valueOf(q.charAt(i)), 1.5f + i, 2);
        }
        g.key(KeyEvent.KEYCODE_LEFT_BRACKET, "[", 11.5f, 2);
        g.key(KeyEvent.KEYCODE_RIGHT_BRACKET, "]", 12.5f, 2);
        g.key(KeyEvent.KEYCODE_BACKSLASH, "\\", 13.5f, 2, 1.5f, 1);

        // row 3: Caps A..L ; ' Enter
        g.key(KeyEvent.KEYCODE_CAPS_LOCK, "Caps", 0, 3, 1.75f, 1);
        int[] r3 = {KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_D, KeyEvent.KEYCODE_F, KeyEvent.KEYCODE_G,
                KeyEvent.KEYCODE_H, KeyEvent.KEYCODE_J, KeyEvent.KEYCODE_K, KeyEvent.KEYCODE_L};
        String a = "ASDFGHJKL";
        for (int i = 0; i < r3.length; i++) {
            g.key(r3[i], String.valueOf(a.charAt(i)), 1.75f + i, 3);
        }
        g.key(KeyEvent.KEYCODE_SEMICOLON, ";", 10.75f, 3);
        g.key(KeyEvent.KEYCODE_APOSTROPHE, "'", 11.75f, 3);
        g.key(KeyEvent.KEYCODE_ENTER, "Enter", 12.75f, 3, 2.25f, 1);

        // row 4: Shift Z..M , . / Shift Up
        g.key(KeyEvent.KEYCODE_SHIFT_LEFT, "Shift", 0, 4, 2.25f, 1);
        int[] r4 = {KeyEvent.KEYCODE_Z, KeyEvent.KEYCODE_X, KeyEvent.KEYCODE_C, KeyEvent.KEYCODE_V, KeyEvent.KEYCODE_B,
                KeyEvent.KEYCODE_N, KeyEvent.KEYCODE_M};
        String z = "ZXCVBNM";
        for (int i = 0; i < r4.length; i++) {
            g.key(r4[i], String.valueOf(z.charAt(i)), 2.25f + i, 4);
        }
        g.key(KeyEvent.KEYCODE_COMMA, ",", 9.25f, 4);
        g.key(KeyEvent.KEYCODE_PERIOD, ".", 10.25f, 4);
        g.key(KeyEvent.KEYCODE_SLASH, "/", 11.25f, 4);
        g.key(KeyEvent.KEYCODE_SHIFT_RIGHT, "Shift", 12.25f, 4, 1.75f, 1);
        g.key(KeyEvent.KEYCODE_DPAD_UP, "\u2191", 14, 4);

        // row 5: Ctrl Win Alt Space Alt Menu arrows
        g.key(KeyEvent.KEYCODE_CTRL_LEFT, "Ctrl", 0, 5, 1.25f, 1);
        g.key(KeyEvent.KEYCODE_META_LEFT, "Win", 1.25f, 5, 1.25f, 1);
        g.key(KeyEvent.KEYCODE_ALT_LEFT, "Alt", 2.5f, 5, 1.25f, 1);
        g.key(KeyEvent.KEYCODE_SPACE, "Space", 3.75f, 5, 6.25f, 1);
        g.key(KeyEvent.KEYCODE_ALT_RIGHT, "Alt", 10, 5);
        g.key(KeyEvent.KEYCODE_MENU, "Menu", 11, 5);
        g.key(KeyEvent.KEYCODE_DPAD_LEFT, "\u2190", 12, 5);
        g.key(KeyEvent.KEYCODE_DPAD_DOWN, "\u2193", 13, 5);
        g.key(KeyEvent.KEYCODE_DPAD_RIGHT, "\u2192", 14, 5);
        return g.slots;
    }

    /** WASD on the left, mouse buttons and Space on the right, a few number keys along the top. */
    public static List<Slot> gaming(int sw, int sh) {
        int m = Math.max(8, (int) (sw * 0.015f));
        float k = Math.min(sh * 0.14f, sw * 0.075f);

        Grid left = new Grid(m, Math.round(sh - m - 3f * k), k, k);
        int[] r0 = {KeyEvent.KEYCODE_Q, KeyEvent.KEYCODE_W, KeyEvent.KEYCODE_E, KeyEvent.KEYCODE_R, KeyEvent.KEYCODE_T};
        String s0 = "QWERT";
        for (int i = 0; i < r0.length; i++) {
            left.key(r0[i], String.valueOf(s0.charAt(i)), i, 0);
        }
        int[] r1 = {KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_D, KeyEvent.KEYCODE_F, KeyEvent.KEYCODE_G};
        String s1 = "ASDFG";
        for (int i = 0; i < r1.length; i++) {
            left.key(r1[i], String.valueOf(s1.charAt(i)), i, 1);
        }
        left.key(KeyEvent.KEYCODE_SHIFT_LEFT, "Shift", 0, 2, 1.5f, 1);
        left.key(KeyEvent.KEYCODE_CTRL_LEFT, "Ctrl", 1.5f, 2, 1.5f, 1);
        left.key(KeyEvent.KEYCODE_ALT_LEFT, "Alt", 3, 2, 1.5f, 1);

        Grid right = new Grid(Math.round(sw - m - 4f * k), Math.round(sh - m - 3f * k), k, k);
        int[] rr = {KeyEvent.KEYCODE_Z, KeyEvent.KEYCODE_X, KeyEvent.KEYCODE_C, KeyEvent.KEYCODE_V};
        String sr = "ZXCV";
        for (int i = 0; i < rr.length; i++) {
            right.key(rr[i], String.valueOf(sr.charAt(i)), i, 0);
        }
        right.put(1, 1, "ML", 0, 1, 2, 1);
        right.put(1, 3, "MR", 2, 1, 2, 1);
        right.key(KeyEvent.KEYCODE_SPACE, "Space", 0, 2, 4, 1);

        Grid top = new Grid(m, Math.round(Math.max(sh * 0.13f, 20f)), k * 0.8f, k * 0.8f);
        top.key(KeyEvent.KEYCODE_ESCAPE, "Esc", 0, 0);
        top.key(KeyEvent.KEYCODE_TAB, "Tab", 1, 0);
        for (int i = 0; i < 6; i++) {
            top.key(KeyEvent.KEYCODE_1 + i, String.valueOf(i + 1), 2 + i, 0);
        }

        List<Slot> all = new ArrayList<>(left.slots);
        all.addAll(right.slots);
        all.addAll(top.slots);
        return all;
    }

    /** A numpad on the right, the navigation keys and arrows to its left. */
    public static List<Slot> numpad(int sw, int sh) {
        int m = Math.max(8, (int) (sw * 0.015f));
        float k = Math.min(sh * 0.14f, sw * 0.075f);

        Grid pad = new Grid(Math.round(sw - m - 4f * k), Math.round(sh - m - 5f * k), k, k);
        pad.key(KeyEvent.KEYCODE_NUM_LOCK, "Num", 0, 0);
        pad.key(KeyEvent.KEYCODE_NUMPAD_DIVIDE, "/", 1, 0);
        pad.key(KeyEvent.KEYCODE_NUMPAD_MULTIPLY, "*", 2, 0);
        pad.key(KeyEvent.KEYCODE_NUMPAD_SUBTRACT, "-", 3, 0);
        for (int n = 1; n <= 9; n++) {
            int row = 3 - (n - 1) / 3; // 7 8 9 on row 1, 4 5 6 on row 2, 1 2 3 on row 3
            int col = (n - 1) % 3;
            pad.key(KeyEvent.KEYCODE_NUMPAD_0 + n, String.valueOf(n), col, row);
        }
        pad.key(KeyEvent.KEYCODE_NUMPAD_ADD, "+", 3, 1, 1, 2);
        pad.key(KeyEvent.KEYCODE_ENTER, "Enter", 3, 3, 1, 2);
        pad.key(KeyEvent.KEYCODE_NUMPAD_0, "0", 0, 4, 2, 1);
        pad.key(KeyEvent.KEYCODE_NUMPAD_DOT, ".", 2, 4);

        Grid nav = new Grid(Math.round(sw - m - 4f * k - 3.4f * k), Math.round(sh - m - 5f * k), k, k);
        nav.key(KeyEvent.KEYCODE_INSERT, "Ins", 0, 0);
        nav.key(KeyEvent.KEYCODE_MOVE_HOME, "Home", 1, 0);
        nav.key(KeyEvent.KEYCODE_PAGE_UP, "PgUp", 2, 0);
        nav.key(KeyEvent.KEYCODE_FORWARD_DEL, "Del", 0, 1);
        nav.key(KeyEvent.KEYCODE_MOVE_END, "End", 1, 1);
        nav.key(KeyEvent.KEYCODE_PAGE_DOWN, "PgDn", 2, 1);
        nav.key(KeyEvent.KEYCODE_DPAD_UP, "\u2191", 1, 3);
        nav.key(KeyEvent.KEYCODE_DPAD_LEFT, "\u2190", 0, 4);
        nav.key(KeyEvent.KEYCODE_DPAD_DOWN, "\u2193", 1, 4);
        nav.key(KeyEvent.KEYCODE_DPAD_RIGHT, "\u2192", 2, 4);

        List<Slot> all = new ArrayList<>(pad.slots);
        all.addAll(nav.slots);
        return all;
    }
}
