package com.limelight;

import android.app.Activity;
import android.content.Context;
import android.view.Surface;

import java.util.function.Consumer;

/**
 * Bridge between the streaming client (this module) and the host app's picture / sound engine.
 * The module cannot see the app, so the app registers itself here ({@code app.clearoverlay.StreamFx}); when nothing
 * is registered (or the feature is off) the client behaves exactly like the original Artemis / Moonlight.
 */
public final class ClearHook {
    private ClearHook() {}

    /** Picture: the decoder draws into the engine, the engine draws the processed picture into the window. */
    public interface Video {
        /** True when the user wants the stream processed inside the app. */
        boolean enabled(Context c);

        /**
         * Builds the engine. [out] = the window surface (the stream view); [streamW] x [streamH] = the video size.
         * [onInput] is called (any thread) with the surface the decoder must render into, or with null when the engine
         * could not start (the client then renders straight to the window as before).
         */
        void start(Context c, Surface out, int streamW, int streamH, Consumer<Surface> onInput);

        /** Stops the engine; call before the window surface goes away. Safe to call twice. */
        void release();

        /** The picture + sound settings dialog (opened from the in-game menu). */
        void showSettings(Activity a);

        String menuLabel(Context c);
    }

    /** Sound: gets the decoded PCM (interleaved 16-bit) of every audio packet and may change it in place. */
    public interface Audio {
        void configure(int sampleRate, int channels);
        void process(short[] pcm);
    }

    public static volatile Video video;
    public static volatile Audio audio;
    private static boolean tried;

    /** Looks the host app's engine up (by name, so this module still builds without it) and registers it once. */
    public static synchronized void ensureInstalled(Context c) {
        if (video != null || tried) return;
        tried = true;
        try {
            Class<?> k = Class.forName("app.clearoverlay.StreamFx");
            k.getMethod("install", Context.class).invoke(null, c.getApplicationContext());
        } catch (Throwable t) {
            LimeLog.warning("+CRSC stream engine not available: " + t);
        }
    }
}
