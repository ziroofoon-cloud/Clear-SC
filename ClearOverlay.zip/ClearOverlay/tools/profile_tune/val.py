import sys,json,numpy as np
sys.argv=[sys.argv[0]]
sys.path.insert(0,'tune'); import pipe, scen, metrics, base, opt
F=json.load(open('tune/final.json')); types=base.types+['dark','busy']
tot=dict(old=[],new=[],none=[])
for t in types:
    for l in range(3):
        ti=base.types.index(t) if t in base.types else (1 if t=='dark' else 3)
        old=base.TAB[ti*3+l]; new=F[f'{t}:{l}']
        scen.SEEDOFF=100
        o=base.ev(old,t,l); n=base.ev(new,t,l); z=base.ev(None,t,l)
        for k,m in (('old',o),('new',n),('none',z)): tot[k].append(m)
        print('%-7s L%d  ssim old %.4f new %.4f none %.4f | psnr %.2f %.2f %.2f | sharp %.2f %.2f %.2f %s'%(t,l,o['ssim'],n['ssim'],z['ssim'],o['psnr'],n['psnr'],z['psnr'],o['sharp'],n['sharp'],z['sharp'],'' if n['ssim']>=o['ssim']-0.001 else '  <-- worse than old'),flush=True)
for k,v in tot.items(): print(k,'mean ssim %.4f psnr %.2f sharp %.2f'%tuple(np.mean([[m[x] for x in ('ssim','psnr','sharp')] for m in v],axis=0)))
