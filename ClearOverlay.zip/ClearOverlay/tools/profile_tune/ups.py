import sys,json,time,numpy as np
args=sys.argv[1:]; sys.argv=[sys.argv[0]]
sys.path.insert(0,'tune'); import pipe, scen, metrics, base, opt
UPS=['fsr','nis','nis_soft','nis_mid','nis_fast','nis_orig']
def ev_up(P,scn,lvl,up,off=0,n=4):
    scen.SEEDOFF=off; pairs=scen.make(scn,lvl,n); res=[]
    for d,gt in pairs:
        ow,oh=(d.shape[1],d.shape[0]) if scn=='repair' else (gt.shape[1],gt.shape[0])
        if scn=='repair' and up!='fsr': pass
        res.append(metrics.score(pipe.player(d,P,ow,oh,up),gt))
    return {k:float(np.mean([r[k] for r in res])) for k in res[0]}
if __name__=='__main__':
    out={}
    for item in args:
        scn,lvl=item.split(':'); lvl=int(lvl); res={}
        P0=json.load(open('tune/final.json'))[item] if True else None
        for up in UPS:
            best=None
            for sh in [0.0,0.15,0.3,0.45,0.6,0.75,0.9]:
                P=dict(P0); P['sharp']=sh; m=ev_up(P,scn,lvl,up); j=opt.J(m)
                if best is None or j>best[0]: best=(j,sh,m)
            res[up]=dict(sharpslider=best[1],**best[2],J=best[0])
            m=best[2]; print(item,'%-9s sharp %.2f ssim %.4f psnr %.2f sh %.2f J %.4f'%(up,best[1],m['ssim'],m['psnr'],m['sharp'],best[0]),flush=True)
        out[item]=res; json.dump(out,open('tune/ups_%s.json'%args[0].replace(':','_'),'w'))
