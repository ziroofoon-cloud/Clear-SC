import numpy as np, cv2
from skimage import data
from PIL import Image, ImageDraw, ImageFont
rng=np.random.default_rng(7)
SEEDOFF=0
def rgb(a):
    a=np.asarray(a)
    if a.ndim==2: a=np.stack([a]*3,-1)
    if a.shape[2]==4: a=a[...,:3]
    return a.astype(np.uint8)
def fit(a,W=640):
    a=rgb(a); h,w=a.shape[:2]; k=W/w
    return cv2.resize(a,(W,int(round(h*k))),interpolation=cv2.INTER_CUBIC if k>1 else cv2.INTER_AREA)
def crops(a,n,cw=384,ch=216,seed=0):
    r=np.random.default_rng(seed); a=fit(a) if a.shape[1]<cw+8 or a.shape[0]<ch+8 else a
    if a.shape[0]<ch+4: a=cv2.resize(a,(int(a.shape[1]*(ch+4)/a.shape[0])+1,ch+4))
    out=[]
    for _ in range(n):
        y=r.integers(0,a.shape[0]-ch+1); x=r.integers(0,a.shape[1]-cw+1); out.append(a[y:y+ch,x:x+cw].copy())
    return out
def jpeg(a,q):
    ok,b=cv2.imencode('.jpg',cv2.cvtColor(a,cv2.COLOR_RGB2BGR),[cv2.IMWRITE_JPEG_QUALITY,int(q)]); return cv2.cvtColor(cv2.imdecode(b,1),cv2.COLOR_BGR2RGB)
def noise(a,s,seed=0):
    r=np.random.default_rng(seed); return np.clip(a.astype(np.float32)+r.normal(0,s,a.shape),0,255).astype(np.uint8)
def down(a,f=2): return cv2.resize(a,(a.shape[1]//f,a.shape[0]//f),interpolation=cv2.INTER_AREA)
def blur(a,s): return cv2.GaussianBlur(a,(0,0),s) if s>0 else a
def posterize(a,bits): sh=8-bits; return ((a>>sh)<<sh).astype(np.uint8)
def photos():
    L=[]
    for n in ('astronaut','chelsea','coffee','rocket'): L.append(rgb(getattr(data,n)()))
    return L
def anime_gt(a):
    a=fit(a,480); m=cv2.pyrMeanShiftFiltering(a,12,28); m=cv2.pyrMeanShiftFiltering(m,12,28)
    g=cv2.cvtColor(a,cv2.COLOR_RGB2GRAY); e=cv2.adaptiveThreshold(cv2.medianBlur(g,5),255,cv2.ADAPTIVE_THRESH_MEAN_C,cv2.THRESH_BINARY,9,7)
    m=(m.astype(np.float32)*(0.25+0.75*(e[...,None]/255.))).astype(np.uint8)
    return m
def manga_gt(a):
    a=fit(a,480); g=cv2.cvtColor(a,cv2.COLOR_RGB2GRAY).astype(np.float32)
    h,w=g.shape; yy,xx=np.mgrid[0:h,0:w]; scr=(np.sin(xx*0.9+yy*0.9)*np.sin(xx*0.9-yy*0.9))*0.5+0.5
    t=np.where(g/255.<scr*0.9+0.05,0,255).astype(np.uint8)
    e=cv2.adaptiveThreshold(cv2.GaussianBlur(g.astype(np.uint8),(0,0),1.2),255,cv2.ADAPTIVE_THRESH_MEAN_C,cv2.THRESH_BINARY,11,6)
    out=np.minimum(np.where(g>200,255,t),e); return rgb(out)
def text_gt(seed):
    r=np.random.default_rng(seed); W,H=480,270
    inv=seed%2==1; bg=(20,22,28) if inv else (250,250,246); fg=(235,235,235) if inv else (15,15,15)
    im=Image.new('RGB',(W,H),bg); d=ImageDraw.Draw(im)
    words="the quick brown fox jumps over a lazy dog 0123456789 ClearOverlay NIS Upscaling subtitle UI text".split()
    y=4
    for sz in (13,15,18,22,14,16,12,20):
        f=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',sz); x=6
        line=' '.join(r.choice(words,9)); d.text((x,y),line,font=f,fill=fg); y+=sz+10
        if y>H-24: break
    d.rectangle([6,H-34,W-6,H-10],outline=fg,width=1); d.line([6,H-22,W-6,H-22],fill=fg,width=1)
    return np.asarray(im)
def game_gt(seed):
    r=np.random.default_rng(seed); W,H=768,432; S=2
    im=Image.new('RGB',(W*S,H*S)); d=ImageDraw.Draw(im)
    for y in range(0,H*S,8): d.line([0,y,W*S,y],fill=(30+y*60//(H*S),50,90+y*80//(H*S)),width=8)
    for _ in range(40):
        c=tuple(int(v) for v in r.integers(30,255,3)); pts=[(int(r.integers(0,W*S)),int(r.integers(0,H*S))) for _ in range(3)]; d.polygon(pts,fill=c)
    f=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',46)
    d.text((60,40),"HP 100  AMMO 24",font=f,fill=(255,255,255))
    for i in range(12): d.line([(0,int(r.integers(0,H*S))),(W*S,int(r.integers(0,H*S)))],fill=(255,255,255),width=3)
    g=np.asarray(im); return cv2.resize(g,(480,270),interpolation=cv2.INTER_AREA)  # clean (anti-aliased) target
def dark(a,k=0.3,gm=1.25): return np.clip(255*((a/255.)**gm)*k,0,255).astype(np.uint8)
LEVELS=3
_C={}
def make(scn,lvl,n=4):
    k=(scn,lvl,n,SEEDOFF)
    if k not in _C: _C[k]=_make(scn,lvl,n)
    return _C[k]
def _make(scn,lvl,n=4):
    """returns list of (input uint8, gt uint8) ; ratio ow/iw = 2 unless stated"""
    P=photos(); out=[]
    if scn in ('video','photo','stream','dark','busy','movie'):
        base=P+([rgb(data.grass()),rgb(data.gravel()),rgb(data.hubble_deep_field()),rgb(data.retina())] if scn=='busy' else [])
        if scn=='busy': base=base[4:]+base[:2]
        cs=[]
        for i,a in enumerate(base[:n]): cs.append(crops(a,1,seed=i+SEEDOFF)[0])
        for i,gt in enumerate(cs):
            if scn=='dark': gt=dark(gt,[0.34,0.28,0.2][lvl]); 
            if scn=='movie': gt=noise(gt,2.5,i)
            d=down(gt)
            if scn=='video': d=jpeg(noise(blur(d,[0.4,0.6,0.8][lvl]),[1.5,2.5,4][lvl],i),[60,42,28][lvl])
            elif scn=='stream': d=jpeg(blur(d,[0.3,0.4,0.5][lvl]),[65,50,38][lvl]); d=posterize(d,[8,7,6][lvl])
            elif scn=='photo': d=jpeg(noise(d,[1,1.5,2.5][lvl],i),[50,35,20][lvl])
            elif scn=='dark': d=jpeg(noise(d,[3,5,8][lvl],i),[60,45,30][lvl])
            elif scn=='busy': d=jpeg(noise(d,1.5,i),[65,48,32][lvl])
            elif scn=='movie': d=jpeg(blur(d,[0,0.3,0.5][lvl]),[97,85,70][lvl]) if lvl else d
            out.append((d,gt))
    elif scn=='anime':
        for i,a in enumerate(P[:n]):
            gt=anime_gt(a)[:216,:384]; gt=crops(gt,1,seed=i)[0] if gt.shape[0]<216 else gt
            d=down(gt); d=posterize(jpeg(d,[60,45,30][lvl]),[8,7,6][lvl]); out.append((d,gt))
    elif scn=='manga':
        for i,a in enumerate(P[:n]):
            gt=manga_gt(a)[:216,:384]; d=jpeg(noise(down(gt),[2,3,5][lvl],i),[65,50,35][lvl]); out.append((d,gt))
    elif scn=='text':
        for i in range(n):
            gt=text_gt(i+SEEDOFF)[:216,:384]; d=jpeg(down(gt),[78,62,45][lvl]); out.append((d,gt))
    elif scn=='game':
        for i in range(n):
            gt=game_gt(i+SEEDOFF)[:216,:384]; d=gt[::2,::2].copy()   # point sampled = aliased
            if lvl: d=jpeg(d,[100,80,60][lvl]); 
            out.append((d,gt))
    elif scn=='repair':
        for i,a in enumerate(P[:n]):
            gt=crops(a,1,seed=i+SEEDOFF)[0]; d=jpeg(noise(blur(gt,[1.0,1.6,2.2][lvl]),[1.5,2.5,3.5][lvl],i),[40,25,15][lvl]); out.append((d,gt))
    return out
SCN=['video','stream','game','photo','movie','anime','text','manga','repair','dark','busy']
