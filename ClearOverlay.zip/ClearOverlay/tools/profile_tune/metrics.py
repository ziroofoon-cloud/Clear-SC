import numpy as np, cv2
from skimage.metrics import structural_similarity as ssim, peak_signal_noise_ratio as psnr
def grad(a):
    g=cv2.cvtColor(a,cv2.COLOR_RGB2GRAY).astype(np.float32); return np.hypot(cv2.Sobel(g,cv2.CV_32F,1,0),cv2.Sobel(g,cv2.CV_32F,0,1)).mean()
def score(out,gt):
    h=min(out.shape[0],gt.shape[0]); w=min(out.shape[1],gt.shape[1]); o=out[:h,:w]; g=gt[:h,:w]
    return dict(ssim=ssim(o,g,channel_axis=2,data_range=255,win_size=7),psnr=psnr(g,o,data_range=255),sharp=grad(o)/(grad(g)+1e-6))
