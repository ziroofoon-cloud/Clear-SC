import sys,os,json,time,copy,numpy as np
args=sys.argv[1:]; sys.argv=[sys.argv[0]]
sys.path.insert(0,'tune'); import pipe, scen, metrics, base
GRID=dict(sharp=[round(x*0.05,2) for x in range(0,21)], detail=[round(x*0.05,2) for x in range(0,19)], dsize=[.2,.3,.4,.5,.6],
          denoise=[round(x*0.05,2) for x in range(0,13)], deband=[round(x*0.05,2) for x in range(0,13)], aa=[0,1,2,3], aastr=[.2,.35,.5,.7])
def J(m): return m['ssim']+0.003*m['psnr']+0.06*min(m['sharp'],1.0)-1.5*max(0,m['sharp']-1.04)
def evalp(P,scn,lvl,off): 
    scen.SEEDOFF=off; return base.ev(P,scn,lvl,4)
def opt(scn,lvl,start,fixed=()):
    cur=dict(start); best=J(evalp(cur,scn,lvl,0)); hist=0
    for sweep in range(3):
        improved=False
        for k in ['sharp','detail','denoise','deband','aa','aastr','dsize']:
            if k in fixed: continue
            if k=='aastr' and cur['aa']==0: continue
            for v in GRID[k]:
                if v==cur[k]: continue
                t=dict(cur); t[k]=v; j=J(evalp(t,scn,lvl,0))
                if j>best+1e-5: best=j; cur=t; improved=True
        if not improved: break
    return cur,best
if __name__=='__main__':
    out={}
    for item in args:
        scn,lvl=item.split(':'); lvl=int(lvl); t=time.time()
        ti=base.types.index(scn) if scn in base.types else (1 if scn=='dark' else 3)
        start=dict(base.TAB[ti*3+lvl]); fixed=(('deband',) if scn in('text','manga') else ())+(('sharp',) if os.environ.get('FIXSHARP') else ())
        b,jb=opt(scn,lvl,start,fixed)
        m0=evalp(start,scn,lvl,0); m1=evalp(b,scn,lvl,0)
        v0=evalp(start,scn,lvl,50); v1=evalp(b,scn,lvl,50); vn=evalp(None,scn,lvl,50)
        out[item]=dict(best=b,start=start,train_old=m0,train_new=m1,val_old=v0,val_new=v1,val_none=vn)
        print(item,round(time.time()-t),'s best',b,'\n   val old ssim %.4f psnr %.2f sh %.2f | val new ssim %.4f psnr %.2f sh %.2f | val none ssim %.4f psnr %.2f sh %.2f'%(v0['ssim'],v0['psnr'],v0['sharp'],v1['ssim'],v1['psnr'],v1['sharp'],vn['ssim'],vn['psnr'],vn['sharp']),flush=True)
        json.dump(out,open('tune/out%s_%s.json'%(os.environ.get('TAG',''),args[0].replace(':','_')),'w'))
