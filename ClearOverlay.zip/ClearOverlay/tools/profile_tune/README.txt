Quick-profile tuning (README 3.89.30). Run from the project root with a software OpenGL ES driver (Mesa llvmpipe):
  EGL_PLATFORM=surfaceless python3 tools/profile_tune/val.py     (compares old / new tables on held-out crops)
pipe.py runs the app's own shaders (Shaders.kt) in the order of GlPipeline.render; scen.py makes the test pictures; opt.py is the search.
The scripts expect the scratch layout they were written in (paths at the top of each file); treat them as notes, not a build step.
