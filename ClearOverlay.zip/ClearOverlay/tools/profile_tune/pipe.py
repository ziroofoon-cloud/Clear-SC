"""Runs the app's own fragment shaders (Shaders.kt) in a software OpenGL ES driver, in the order of GlPipeline.render for the player."""
import sys, os, re, ctypes as C, numpy as np
os.environ['EGL_PLATFORM']='surfaceless'; os.environ.setdefault('LIBGL_ALWAYS_SOFTWARE','1')
sys.path.insert(0,'n80/ClearOverlay/tools/shader_test')
import glrun
from glrun import gl
glrun.init()
KT=sys.argv[1] if len(sys.argv)>1 and sys.argv[1].endswith('.kt') else 'n90/ClearOverlay/app/src/main/java/app/clearoverlay/Shaders.kt'
S=open(KT).read()
def sh(n):
    k=f'const val {n} = """'; i=S.index(k)+len(k); return S[i:S.index('"""',i)]
VERT=sh('VERT'); PROG={}
def prog(n):
    if n not in PROG: PROG[n]=glrun.compile_prog(VERT,sh(n))
    return PROG[n]
gl.glUniform1f.argtypes=[C.c_int,C.c_float]; gl.glUniform2f.argtypes=[C.c_int,C.c_float,C.c_float]
gl.glUniform4f.argtypes=[C.c_int,C.c_float,C.c_float,C.c_float,C.c_float]; gl.glUniform2i.argtypes=[C.c_int,C.c_int,C.c_int]
gl.glGetUniformLocation.argtypes=[C.c_uint,C.c_char_p]
def run(name, img, ow, oh, **u):
    """img: HxWx3 uint8. u: name -> float | (a,b) floats | (a,b,c,d) floats | ('i',a,b). Returns oh x ow x 3 uint8 (RGBA8 target, like the app)."""
    p=prog(name); H,W,_=img.shape
    rgba=np.full((H,W,4),255,np.uint8); rgba[...,:3]=img
    tex=C.c_uint(); gl.glGenTextures(1,C.byref(tex)); gl.glBindTexture(0x0DE1,tex)
    gl.glTexImage2D(0x0DE1,0,0x1908,W,H,0,0x1908,0x1401,rgba.ctypes.data_as(C.c_void_p))
    for pn,v in ((0x2800,0x2601),(0x2801,0x2601),(0x2802,0x812F),(0x2803,0x812F)): gl.glTexParameteri(0x0DE1,pn,v)
    ot=C.c_uint(); gl.glGenTextures(1,C.byref(ot)); gl.glBindTexture(0x0DE1,ot)
    gl.glTexImage2D(0x0DE1,0,0x1908,ow,oh,0,0x1908,0x1401,None)
    fb=C.c_uint(); gl.glGenFramebuffers(1,C.byref(fb)); gl.glBindFramebuffer(0x8D40,fb)
    gl.glFramebufferTexture2D(0x8D40,0x8CE0,0x0DE1,ot,0)
    gl.glViewport(0,0,ow,oh); gl.glUseProgram(p)
    gl.glActiveTexture(0x84C0); gl.glBindTexture(0x0DE1,tex)
    L=lambda n: gl.glGetUniformLocation(p,n.encode())
    gl.glUniform1i(L('uSrc'),0)
    if L('uSrcSize')>=0: gl.glUniform2i(L('uSrcSize'),W,H)
    if L('uInv')>=0: gl.glUniform2f(L('uInv'),1.0/W,1.0/H)
    for k,v in u.items():
        loc=L(k)
        if loc<0: continue
        if isinstance(v,tuple):
            if v[0]=='i': gl.glUniform2i(loc,v[1],v[2])
            elif len(v)==2: gl.glUniform2f(loc,*v)
            elif len(v)==4: gl.glUniform4f(loc,*v)
        else: gl.glUniform1f(loc,float(v))
    gl.glDrawArrays(4,0,3); gl.glPixelStorei(0x0D05,1)
    out=np.zeros((oh,ow,4),np.uint8); gl.glReadPixels(0,0,ow,oh,0x1908,0x1401,out.ctypes.data_as(C.c_void_p))
    gl.glDeleteTextures(1,C.byref(tex)); gl.glDeleteTextures(1,C.byref(ot)); gl.glDeleteFramebuffers(1,C.byref(fb))
    return out[...,:3].copy()
def easu(img,ow,oh):
    H,W,_=img.shape; iw,ih,ox,oy=float(W),float(H),float(ow),float(oh)
    return run('EASU',img,ow,oh,uCon0=(iw/ox,ih/oy,0.5*iw/ox-0.5,0.5*ih/oy-0.5),uCon1=(1/iw,1/ih,1/iw,-1/ih),uCon2=(-1/iw,2/ih,1/iw,2/ih),uCon3=(0.0,4/ih,0.0,0.0))
AA={1:'FXAA_FAST',2:'FXAA_QUALITY',3:'EDGE_SMOOTH'}
def player(src,P,ow,oh,up='fsr'):
    """P: dict sharp, detail, dsize, denoise, deband, aa, aastr. Same order as GlPipeline: denoise, deband, AA, upscale, RCAS, detail."""
    x=src
    if P['denoise']>0: x=run('DENOISE',x,x.shape[1],x.shape[0],uAmt=P['denoise'])
    if P['deband']>0: x=run('DEBAND',x,x.shape[1],x.shape[0],uAmt=P['deband'],uRange=24.0)
    if P['aa']: x=run(AA[P['aa']],x,x.shape[1],x.shape[0],uAmt=P['aastr'])
    sw=x.shape[1]
    if up.startswith('nis'):
        if up in ('nis_orig','nis_fast','nis_mid'):
            nm={'nis_orig':'NIS_ORIG','nis_fast':'NIS_FAST','nis_mid':'NIS_FAST'}[up]
            k=0.75 if up=='nis_mid' else 1.0
            x=run(nm,x,ow,oh,uScale=(sw/ow,x.shape[0]/oh),uSharp=min(1.0,max(0.0,(0.15+0.7*P['sharp'])*k)))
        else:
            x=run('NIS',x,ow,oh,uFactor=ow/sw,uGain=0.6 if up=='nis_soft' else 1.0,uClean=0.7 if up=='nis_soft' else 0.0,uSharp=min(1.0,max(0.0,P['sharp'])))
    else:
        if x.shape[1]!=ow or x.shape[0]!=oh:
            x=easu(x,ow,oh) if up=='fsr' else run('BILINEAR',x,ow,oh)
        else:
            x=run('BILINEAR',x,ow,oh)  # sharp-only path: same size copy
        x=run('RCAS',x,ow,oh,uSharpness=P['sharp']*1.2)
    if P['detail']>0: x=run('DETAIL',x,ow,oh,uAmt=P['detail'],uRadius=1.0+3.0*P['dsize'])
    return x
if __name__=='__main__':
    im=(np.random.default_rng(0).random((36,64,3))*255).astype(np.uint8)
    o=player(im,dict(sharp=.4,detail=.3,dsize=.4,denoise=.2,deband=.2,aa=3,aastr=.3),128,72); print(o.shape,o.mean())
