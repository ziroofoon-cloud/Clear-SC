import sys,re,json,numpy as np,time
sys.argv=[sys.argv[0]]
sys.path.insert(0,'tune'); import pipe, scen, metrics
src=open('n90/ClearOverlay/app/src/main/java/app/clearoverlay/Profiles.kt').read()
pl=src[src.index('private val PLAYER'):src.index('private val OVERLAY')]
AAm={'Cfg.AA_OFF':0,'Cfg.AA_FXAA_FAST':1,'Cfg.AA_FXAA_QUALITY':2,'Cfg.AA_EDGE':3}
rows=re.findall(r'P\(([^)]*)\)',pl)
TAB=[]
for r in rows:
    p=[x.strip() for x in r.split(',')]
    v=[float(x.rstrip('f')) for x in p[:5]]; aa=AAm[p[5]] if len(p)>5 else 0; ast=float(p[6].rstrip('f')) if len(p)>6 else 0.5
    TAB.append(dict(sharp=v[0],detail=v[1],dsize=v[2],denoise=v[3],deband=v[4],aa=aa,aastr=ast))
types=['video','stream','game','photo','movie','anime','text','manga','repair']
assert len(TAB)==27,len(TAB)
NONE=dict(sharp=0.0,detail=0,dsize=.4,denoise=0,deband=0,aa=0,aastr=.5)
def ev(P,scn,lvl,n=4,rcas=True):
    pairs=scen.make(scn,lvl,n); res=[]
    for d,gt in pairs:
        ow,oh=gt.shape[1],gt.shape[0]
        if scn=='repair': ow,oh=d.shape[1],d.shape[0]
        out=pipe.player(d,P,ow,oh) if P is not None else pipe.easu(d,ow,oh)
        res.append(metrics.score(out,gt if scn!='repair' else gt))
    return {k:float(np.mean([r[k] for r in res])) for k in res[0]}
if __name__=='__main__':
    t=time.time(); out={}
    for ti,scn in enumerate(types+['dark','busy']):
        for lvl in range(3):
            cur=TAB[ti*3+lvl] if ti<9 else TAB[(1 if scn=='dark' else 3)*3+lvl]   # dark/busy: shown with the Video / Photo row for reference
            b=ev(None,scn,lvl); c=ev(cur,scn,lvl)
            print(f"{scn:7s} L{lvl} noproc ssim {b['ssim']:.4f} psnr {b['psnr']:.2f} sh {b['sharp']:.2f} | table ssim {c['ssim']:.4f} psnr {c['psnr']:.2f} sh {c['sharp']:.2f}",flush=True)
    print('time',round(time.time()-t))
