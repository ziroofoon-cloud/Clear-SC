import json,re,sys
sys.argv=[sys.argv[0]]
fs=json.load(open('tune/best_fs.json'))
types=['video','stream','game','photo','movie','anime','text','manga','repair','dark','busy']
def r2(x): return round(x*20)/20 if False else round(x,2)
def shrink(old,opt,k=0.6): return old+k*(opt-old)
FINAL={}
for ti,t in enumerate(types):
    for l in range(3):
        v=fs[f'{t}:{l}']; o=v['start']; b=v['best']
        P={}
        for key in ('detail','dsize','denoise','deband'):
            P[key]=shrink(o[key],b[key]) if t in types[:9] else b[key]
        P['sharp']=o['sharp'] if t in types[:9] else None
        P['aa']=b['aa'] if t not in('game',) else o['aa']
        P['aastr']=b['aastr'] if P['aa'] else 0.5
        FINAL[(t,l)]=P
# ---- decisions by hand where the synthetic test is misleading / the evidence is one-sided (see README 3.89.30)
for l in range(3):
    FINAL[('game',l)].update(sharp=[0.35,0.48,0.58][l],denoise=[0.06,0.08,0.10][l],deband=[0.05,0.08,0.10][l],detail=[0.05,0.08,0.12][l],dsize=0.30)
    FINAL[('manga',l)].update(sharp=[0.55,0.68,0.80][l],detail=[0.75,0.85,0.90][l],dsize=0.45,denoise=[0.25,0.30,0.35][l],deband=0.0)
    FINAL[('text',l)].update(deband=0.0,dsize=0.25,denoise=[0.22,0.28,0.34][l],detail=[0.50,0.55,0.62][l])
    FINAL[('dark',l)].update(sharp=[0.30,0.38,0.46][l],detail=[0.20,0.25,0.40][l],dsize=0.55,denoise=[0.10,0.15,0.22][l],deband=[0.25,0.35,0.45][l],aa=0,aastr=0.5)
    FINAL[('busy',l)].update(sharp=[0.30,0.38,0.46][l],detail=[0.12,0.15,0.18][l],dsize=0.50,denoise=[0.05,0.08,0.12][l],deband=[0.15,0.25,0.40][l],aa=0,aastr=0.5)
    FINAL[('movie',l)].update(aa=0)
# keep the strength ladder sane: denoise / deband never go down from Light to Strong
for t in types:
    for key in ('denoise','deband'):
        for l in (1,2): FINAL[(t,l)][key]=max(FINAL[(t,l)][key],FINAL[(t,l-1)][key])
for k,P in FINAL.items():
    for key in ('sharp','detail','dsize','denoise','deband','aastr'):
        if P[key] is not None: P[key]=round(P[key]/0.01)*0.01; P[key]=round(P[key],2)
json.dump({f'{t}:{l}':P for (t,l),P in FINAL.items()},open('tune/final.json','w'),indent=1)
for t in types:
    print(t,[ (P['sharp'],P['detail'],P['dsize'],P['denoise'],P['deband'],P['aa'],P['aastr']) for P in (FINAL[(t,l)] for l in range(3))])
