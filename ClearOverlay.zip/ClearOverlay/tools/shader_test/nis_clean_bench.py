"""NIS fast / NIS mid / FSR 1 / SGSR 1 on the app's real shaders (software OpenGL ES 3.2):  EGL_PLATFORM=surfaceless python3 tools/shader_test/nis_clean_bench.py
Four sources (a photo, text-like lines, a noisy JPEG photo, a compressed photo), each shrunk to half size and enlarged 2x again; every result is compared
with the original: PSNR, SSIM, edge strength (mean gradient and the 98th percentile of it), halos (share of pixels past the local range of a plain
enlargement by more than 10/255) and noise in the flat areas of the original (std of the high-pass there; the original itself has the value 'GT')."""
import sys, os, io
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from chain import *
from skimage.metrics import structural_similarity as ssim
from scipy.ndimage import maximum_filter, minimum_filter, uniform_filter, gaussian_filter

photo = Image.open(os.path.join(matplotlib.get_data_path(), 'sample_data', 'grace_hopper.jpg')).convert('RGB')
def lines_img():
    a = np.full((600, 512, 3), 235, np.uint8); rng = np.random.RandomState(3)
    for y in range(30, 570, 22):
        x = 20
        while x < 480:
            w = int(rng.randint(6, 40)); a[y:y + 6, x:x + w] = 30; x += w + int(rng.randint(6, 16))
    a[::37, :] = 90
    return Image.fromarray(a)
def jpeg_noisy(img, q=35, noise=3.0, seed=1):
    b = io.BytesIO(); img.save(b, 'JPEG', quality=q)
    d = np.array(Image.open(io.BytesIO(b.getvalue())).convert('RGB')).astype(float) + np.random.RandomState(seed).normal(0, noise, (img.size[1], img.size[0], 3))
    return Image.fromarray(np.clip(d, 0, 255).astype(np.uint8))
GT = photo.resize((512, 600), Image.LANCZOS)
SETS = [('photo', GT, GT.resize((256, 300), Image.LANCZOS)),
        ('text lines', lines_img(), lines_img().resize((256, 300), Image.LANCZOS)),
        ('noisy jpeg photo (q35 noise3)', GT, jpeg_noisy(GT.resize((256, 300), Image.LANCZOS))),
        ('compressed photo (q30 noise1)', GT, jpeg_noisy(GT.resize((256, 300), Image.LANCZOS), 30, 1.0, 2))]

def lum(a): a = a.astype(float); return .299 * a[..., 0] + .587 * a[..., 1] + .114 * a[..., 2]
def gradm(a): gy, gx = np.gradient(lum(a)); return np.hypot(gx, gy)
def halo(o, ref): l, r = lum(o), lum(ref); return ((l > maximum_filter(r, 5) + 10) | (l < minimum_filter(r, 5) - 10)).mean() * 100
def flat_mask(G):
    l = lum(G); m = uniform_filter(l, 7); v = uniform_filter(l * l, 7) - m * m
    return v < 4.0
def detail_metrics(o, G):
    """How much of the TRUE fine detail comes back (gain of the original's high-pass found in the result; 1.0 = all of it) and how much of the result's high-pass is NOT the original's (artifacts: noise, halos, wavy lines; RMS of 0..255 values)."""
    lo, lg = lum(o), lum(G); ho = lo - gaussian_filter(lo, 1.5); hg = lg - gaussian_filter(lg, 1.5)
    gain = float((ho * hg).sum() / (hg * hg).sum()); art = float(np.sqrt(((ho - gain * hg) ** 2).mean()))
    return gain, art
def flat_noise(o, mask):
    l = lum(o); hp = l - gaussian_filter(l, 1.5); return float(hp[mask].std())

VS = VERT
def nisfast_src(level, refine=False, extra=''):
    t = grab('NIS_FAST').replace('#define NF_LEVEL 0', '#define NF_LEVEL %d' % level + ('\n#define NF_REFINE' if refine else '') + extra)
    return t
_cache = {}
def prog(key, src):
    if key not in _cache: _cache[key] = compile_prog(VS, src)
    return _cache[key]
def run_nis(base, w, h, bw, bh, p, sharp):
    d = Rt(w, h); run(p, d, [base], i2={'uSrcSize': (bw, bh)}, f1={'uSharp': sharp}, f2={'uScale': (bw / w, bh / h)}); return d.read()[..., :3]
def run_fsr(base, w, h, bw, bh, sharp):
    t1 = Rt(w, h); iw, ih, ox, oy = float(bw), float(bh), float(w), float(h)
    run(progs['EASU'], t1, [base], f1={'uSharpness': 0}, i2={'uSrcSize': (bw, bh)},
        f4={'uCon0': (iw / ox, ih / oy, .5 * iw / ox - .5, .5 * ih / oy - .5), 'uCon1': (1 / iw, 1 / ih, 1 / iw, -1 / ih), 'uCon2': (-1 / iw, 2 / ih, 1 / iw, 2 / ih), 'uCon3': (0, 4 / ih, 0, 0)})
    out = Rt(w, h); run(prog('RCAS', grab('RCAS')), out, [t1], i2={'uSrcSize': (w, h)}, f1={'uSharpness': sharp * 1.2, 'uProtect': 0.0}); return out.read()[..., :3]
def run_sgsr(base, w, h, bw, bh, sharp):
    d = Rt(w, h); run(prog('SGSR1', grab('SGSR1')), d, [base], i2={'uSrcSize': (bw, bh)}, f4={'uViewportInfo': (1 / bw, 1 / bh, bw, bh)}, f1={'uEdgeSharpness': 1 + 3 * sharp}); return d.read()[..., :3]

def variants(sharp, extra):
    """name -> function(base, w, h, bw, bh) -> uint8 picture"""
    V = {}
    s_fast = min(1.0, .15 + .7 * sharp)
    V['FSR 1 (EASU + RCAS)'] = lambda b, w, h, bw, bh: run_fsr(b, w, h, bw, bh, sharp)
    V['SGSR 1'] = lambda b, w, h, bw, bh: run_sgsr(b, w, h, bw, bh, sharp)
    for lv in (0, 1, 2):
        p = prog('fast%d' % lv, nisfast_src(lv)); V['NIS fast standard L%d' % lv] = (lambda p: lambda b, w, h, bw, bh: run_nis(b, w, h, bw, bh, p, s_fast))(p)
    for lv in (0, 1, 2):
        p = prog('fast%d' % lv, nisfast_src(lv)); V['NIS mid L%d' % lv] = (lambda p: lambda b, w, h, bw, bh: run_nis(b, w, h, bw, bh, p, min(1.0, s_fast * .75)))(p)
    pc = prog('clean0', nisfast_src(0, True)); V['NIS fast CLEAN L0'] = (lambda pc: lambda b, w, h, bw, bh: run_nis(b, w, h, bw, bh, pc, s_fast))(pc)
    for name, (src, mul) in extra.items():
        p = prog(name, src); V[name] = (lambda p, mul: lambda b, w, h, bw, bh: run_nis(b, w, h, bw, bh, p, min(1.0, s_fast * mul)))(p, mul)
    return V

def evaluate(sharp=0.6, extra={}, sets=SETS, quiet=False):
    res = {}
    V = variants(sharp, extra)
    for sname, gt, small in sets:
        G = np.array(gt); s = np.array(small); bh, bw, _ = s.shape; h, w, _ = G.shape
        rgba = np.full((bh, bw, 4), 255, np.uint8); rgba[..., :3] = s; base = Rt(bw, bh, rgba)
        bil = np.array(small.resize((w, h), Image.BILINEAR)); mask = flat_mask(G)
        gg = gradm(G)
        rows = [('bilinear', bil)] + [(n, f(base, w, h, bw, bh)) for n, f in V.items()]
        if not quiet: print(f' {sname}  (GT: edge {gg.mean():.2f} g98 {np.percentile(gg, 98):.1f} flat-noise {flat_noise(G, mask):.2f})')
        for n, o in rows:
            g = gradm(o)
            dg, da = detail_metrics(o, G); r = dict(dgain=dg, art=da, psnr=psnr(G, o), ssim=ssim(G, o, channel_axis=2, data_range=255), edge=g.mean(), g98=float(np.percentile(g, 98)), halo=halo(o, bil), noise=flat_noise(o, mask))
            res[(sname, n)] = r
            if not quiet: print(f'   {n:24s} PSNR {r["psnr"]:5.2f} SSIM {r["ssim"]:.4f} edge {r["edge"]:5.2f} g98 {r["g98"]:5.1f} halo {r["halo"]:5.2f}% noise {r["noise"]:.2f} detail {r["dgain"]:.3f} artifacts {r["art"]:.2f}')
    return res
if __name__ == '__main__':
    evaluate()
