"""Checks AI 3x 'similar frames' with the real shaders in software OpenGL ES 3.2 (Mesa).
1) Ai3Shaders.REF (read from the .kt) compiles and gives the same picture as a numpy model.
2) frame 1, then frame 2 = frame 1 + codec-like noise + one really changed block: the result made with skip-unchanged on R' must be IDENTICAL (maxdiff 0) to a fresh full run on R'
   (the invariant), and its difference to a fresh full run on the real frame 2 is printed (the price of the tolerance).
Run: EGL_PLATFORM=surfaceless python3 tools/shader_test/ai3_sim_check.py   (needs numpy, scikit-image, opencv)"""
import sys,os,ctypes as C,numpy as np
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
import ai3_skip_check as K
from ai3_skip_check import gl,glrun,tex,run,S,T
kt=open(T+'app/src/main/java/app/clearoverlay/Ai3Shaders.kt').read()
REF=kt[kt.index('const val REF = """')+len('const val REF = """'):]; REF=REF[:REF.index('"""')]
rp=glrun.compile_prog(K.VERT,REF); print('REF compiled OK')
def ref_gl(s8,r8,tol):
    H,W=s8.shape[:2]; a=np.full((H,W,4),255,np.uint8); a[...,:3]=s8; b=a.copy(); b[...,:3]=r8
    ts=tex(W,H,0x1908,0x1401,0x1908,a.ctypes.data_as(C.c_void_p)); tr=tex(W,H,0x1908,0x1401,0x1908,b.ctypes.data_as(C.c_void_p)); to=tex(W,H,0x1908,0x1401,0x1908)
    fb=C.c_uint(); gl.glGenFramebuffers(1,C.byref(fb)); gl.glBindFramebuffer(0x8D40,fb); gl.glFramebufferTexture2D(0x8D40,0x8CE0,0x0DE1,to,0); gl.glDrawBuffers(1,(C.c_uint*1)(0x8CE0)); gl.glViewport(0,0,W,H)
    gl.glUseProgram(rp); gl.glActiveTexture(0x84C0); gl.glBindTexture(0x0DE1,ts); gl.glActiveTexture(0x84C1); gl.glBindTexture(0x0DE1,tr)
    gl.glUniform1i(gl.glGetUniformLocation(rp,b'uIn'),0); gl.glUniform1i(gl.glGetUniformLocation(rp,b'uPrev'),1); gl.glUniform1f(gl.glGetUniformLocation(rp,b'uTol'),(tol+0.25)/255)
    gl.glDrawArrays(4,0,3); out=np.zeros((H,W,4),np.uint8); gl.glReadPixels(0,0,W,H,0x1908,0x1401,out.ctypes.data_as(C.c_void_p)); return out[...,:3]
def ref_np(s8,r8,tol):
    close=(np.abs(s8.astype(int)-r8.astype(int)).max(-1)<=tol)[...,None]; return np.where(close,r8,s8)
rng=np.random.default_rng(3)
for name,f1 in S.imgs():
    if name not in ('rocket','synth'): continue
    f1_8=(f1*255+0.5).astype(np.uint8)
    for noise in (1,2):
        f2=f1_8.astype(int)+rng.integers(-noise,noise+1,f1_8.shape); f2[20:44,30:70]=np.clip(f2[20:44,30:70]*0.7+50,0,255)   # noise + a really changed block
        f2=np.clip(f2,0,255).astype(np.uint8)
        for tol in (1,2,4):
            Rp=ref_np(f2,f1_8,tol); g=ref_gl(f2,f1_8,tol); assert (g==Rp).all(),'REF shader != numpy model'
            d_in=np.abs(Rp.astype(int)-f2.astype(int)).max()
            for t in (0,1,3,6):
                st={}; run(t,f1_8/255.,True,thr=None,state=st)
                b=run(t,Rp/255.,True,thr=None,state=st)       # skip-unchanged with R' (what GlPipeline does)
                full=run(t,Rp/255.,False)                      # fresh full network on R'
                real=run(t,f2/255.,False)                      # fresh full network on the real frame
                same=(Rp==f1_8).all(-1).mean()*100
                print(f'{name:7s} noise +-{noise} tol {tol} level {t}: input differs from real by <= {d_in}; {same:4.1f}% of source pixels kept; skip-vs-full-on-R\' maxdiff {np.abs(b-full).max()} (must be 0); result vs real frame maxdiff {np.abs(b-real).max()}/255',flush=True)
