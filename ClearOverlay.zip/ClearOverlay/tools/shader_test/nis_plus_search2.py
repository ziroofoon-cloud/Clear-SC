"""Second search: a monotonic-edge gate (a real edge is one clear step in the six taps, noise is not) on top of NIS fast clean."""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from nis_plus_search import *
def make2(R=2.25, T=76.0, cfw=2.6, G=1.0, glo=0.2, ge0=0.02, ge1=0.09, tol=-1.0, mono=None, level=0):
    t = make(R, T, cfw, G, glo, ge0, ge1, tol, level)
    if mono:
        m0, m1, fl = mono
        anchor = 'yu *= %.4f * mix(%.4f, 1.0, smoothstep(%.4f, %.4f, rg));' % (G, glo, ge0, ge1)
        assert anchor in t
        t = t.replace(anchor, anchor + '\n    { float dc = abs(x3 - x2); float sm = abs(x1 - x0) + abs(x2 - x1) + dc + abs(x4 - x3) + abs(x5 - x4) + 1e-4; yu *= mix(%.3f, 1.0, smoothstep(%.3f, %.3f, dc / sm)); }' % (fl, m0, m1))
    return t
if __name__ == '__main__':
    grid = []
    for mono in ((0.30, 0.60, 0.3), (0.40, 0.70, 0.3), (0.40, 0.70, 0.5), (0.25, 0.50, 0.4)):
        for G in (1.2, 1.5, 1.8):
            grid.append(dict(G=G, mono=mono))
    grid.append(dict(G=1.0))
    extra = {'Q%02d' % i: (make2(**g), 1.0) for i, g in enumerate(grid)}
    res = evaluate(0.6, extra, quiet=True)
    names = ['NIS fast standard L0', 'NIS fast CLEAN L0'] + list(extra)
    S = summarize(res, names); ref = S['NIS fast standard L0']
    for n in names:
        s = S[n]; tag = json.dumps(grid[int(n[1:])]) if n in extra else ''
        print(f'{n:22s} PSNR {s["psnr"]:5.2f} SSIM {s["ssim"]:.4f} halo {s["halo"]:5.2f} DETAIL {s["dgain"]/ref["dgain"]:.3f} ART {s["art"]/ref["art"]:.3f} ratio {(s["art"]/ref["art"])/(s["dgain"]/ref["dgain"]):.3f} {tag}')
