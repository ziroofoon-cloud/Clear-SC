"""Python mirror of Lite8.wrap (SrShaders.kt): feature maps stored as RGBA8, companded: e = 0.5 + 0.5 * sign(v) * sqrt(|v| / R)."""
import re
R=3.0
def wrap(src,dec,enc):
    fn="\nconst float L8R = %s;\nvec4 l8d(vec4 e){ vec4 s = e * 2.0 - 1.0; return sign(s) * s * s * L8R; }\nvec4 l8e(vec4 v){ return sign(v) * sqrt(min(abs(v) / L8R, 1.0)) * 0.5 + 0.5; }\n"%repr(float(R))
    s=src
    if dec: s=re.sub(r'texelFetch\((uT\d+),\s*([^,]+?),\s*0\)',r'l8d(texelFetch(\1, \2, 0))',s)
    if enc: s=re.sub(r'(?m)^(\s*o\d+ = )(.*);\s*$',lambda m:m.group(1)+'l8e('+m.group(2)+');',s)
    i=s.index('void main()')
    return s[:i]+fn+s[i:]
