"""(Lite 8 + skip-flat variant of sr_same_check.py: the skip programs with 8-bit maps against the skip programs with 16-bit maps.) Checks AI 2x 'skip unchanged areas' with the real shaders in software OpenGL ES 3.2 (Mesa): the 8-channel network (PASS1..3 + PASS4) with the flat-map patch (mirror of
SrShaders.flatPatch) and the final pass PASS4_SAME. Frame 1 is drawn in full, frame 2 (a block changed) is drawn with the result of frame 1 kept in the unchanged places; the
result must be exactly the full network's result for frame 2 (maxdiff 0), also for a repeated frame. Also checks the plain flat-skip patch compiles.
Run: EGL_PLATFORM=surfaceless python3 tools/shader_test/sr_same_check.py  (needs numpy)"""
import sys,re,os,ctypes as C,numpy as np
os.environ['EGL_PLATFORM']='surfaceless'
HERE=os.path.dirname(os.path.abspath(__file__)); T=os.path.join(HERE,'..','..')+os.sep
sys.path.insert(0,HERE)
import glrun; from glrun import gl
import lite8_wrap as W8
print(glrun.init())
VERT=glrun.shaders_from()[0]
J=T+'app/src/main/java/app/clearoverlay/'
def const(kt,name):
    s=open(J+kt).read(); i=s.index('const val '+name+' = """')+len('const val '+name+' = """'); return s[i:s.index('"""',i)]
P=[const('SrShaders.kt','PASS1'),const('SrShaders.kt','PASS2'),const('SrShaders.kt','PASS3')]
P4=const('SrShaders.kt','PASS4'); FLAT=const('Ai3Shaders.kt','FLAT')
def patch(pass_,src):
    if pass_<2: return src
    s=src.replace('precision highp sampler2D;','precision highp sampler2D;\nuniform sampler2D uFlat;',1)
    outs=len(re.findall(r'layout\(location=\d+\) out',s)); z=' '.join(f'o{i} = vec4(0.0);' for i in range(outs)); m='ivec2 p = ivec2(gl_FragCoord.xy);'
    return s.replace(m,m+f'\n  if (texelFetch(uFlat, p, 0)[{3-pass_}] > 0.5) {{ {z} return; }}',1)
last="outColor = vec4(clamp(bl + uGain * res, 0.0, 1.0), 1.0);"; assert last in P4
P4S=P4.replace('precision highp sampler2D;','precision highp sampler2D;\nuniform sampler2D uFlat;',1).replace(last,"float fv = texelFetch(uFlat, q, 0).r;\n  outColor = vec4(clamp(bl + (fv > 0.5 ? 0.0 : uGain) * res, 0.0, 1.0), 1.0);",1)
P4D=P4S.replace("float fv = texelFetch(uFlat, q, 0).r;","float fv = texelFetch(uFlat, q, 0).r;\n  if (fv > 0.9) discard;",1)
gl.glGetUniformLocation.argtypes=[C.c_uint,C.c_char_p]; gl.glUniform1i.argtypes=[C.c_int,C.c_int]; gl.glUniform1f.argtypes=[C.c_int,C.c_float]
def tex(w,h,fmt,typ,intf,data=None):
    t=C.c_uint(); gl.glGenTextures(1,C.byref(t)); gl.glBindTexture(0x0DE1,t); gl.glTexImage2D(0x0DE1,0,intf,w,h,0,fmt,typ,data)
    for pn,v in ((0x2800,0x2600),(0x2801,0x2600),(0x2802,0x812F),(0x2803,0x812F)): gl.glTexParameteri(0x0DE1,pn,v)
    return t.value
def mrt(n,w,h,lite=False):
    ts=[tex(w,h,0x1908,0x1401,0x8058) if lite else tex(w,h,0x1908,0x140B,0x881A) for _ in range(n)]; fb=C.c_uint(); gl.glGenFramebuffers(1,C.byref(fb)); gl.glBindFramebuffer(0x8D40,fb)
    for i,t in enumerate(ts): gl.glFramebufferTexture2D(0x8D40,0x8CE0+i,0x0DE1,t,0)
    gl.glDrawBuffers(n,(C.c_uint*n)(*[0x8CE0+i for i in range(n)])); assert gl.glCheckFramebufferStatus(0x8D40)==0x8CD5
    return ts,fb.value
CP={}
def progs(skip,same,lite=False):
    k=(skip,same,lite)
    if k not in CP:
        S3=[patch(i+1,P[i]) if skip else P[i] for i in range(3)]; F=(P4D if same else P4S) if skip else P4
        if lite: S3=[W8.wrap(S3[i],i>0,True) for i in range(3)]; F=W8.wrap(F,True,False)
        CP[k]=[glrun.compile_prog(VERT,x) for x in S3+[F]]
    return CP[k]
def run(img,skip,same=False,gain=1.0,state=None,lite=False,thr=-1.0):
    H,W=img.shape[:2]; ps=progs(skip,same,lite)
    rgba=np.full((H,W,4),255,np.uint8); rgba[...,:3]=(img*255+0.5).astype(np.uint8)
    src=tex(W,H,0x1908,0x1401,0x1908,rgba.ctypes.data_as(C.c_void_p))
    A=mrt(2,W,H,lite); B=mrt(2,W,H,lite); Cm=mrt(3,W,H,lite); flat=None
    if skip:
        flat=tex(W,H,0x1908,0x1401,0x1908); fb=C.c_uint(); gl.glGenFramebuffers(1,C.byref(fb)); gl.glBindFramebuffer(0x8D40,fb); gl.glFramebufferTexture2D(0x8D40,0x8CE0,0x0DE1,flat,0)
        gl.glDrawBuffers(1,(C.c_uint*1)(0x8CE0)); gl.glViewport(0,0,W,H)
        fp=glrun.compile_prog(VERT,FLAT); gl.glUseProgram(fp)
        use_prev=state is not None and state.get('valid',False)
        gl.glActiveTexture(0x84C0); gl.glBindTexture(0x0DE1,src); gl.glUniform1i(gl.glGetUniformLocation(fp,b'uIn'),0)
        gl.glActiveTexture(0x84C1); gl.glBindTexture(0x0DE1,state['prev'] if use_prev else src); gl.glUniform1i(gl.glGetUniformLocation(fp,b'uPrev'),1)
        gl.glUniform1i(gl.glGetUniformLocation(fp,b'uSame'),1 if use_prev else 0); gl.glUniform1i(gl.glGetUniformLocation(fp,b'uR'),3); gl.glUniform1i(gl.glGetUniformLocation(fp,b'uE'),1)
        gl.glUniform1f(gl.glGetUniformLocation(fp,b'uThr'),thr); gl.glDrawArrays(4,0,3)
    def bind(pr,ts):
        for u,ti in enumerate(ts): gl.glActiveTexture(0x84C0+u); gl.glBindTexture(0x0DE1,ti); gl.glUniform1i(gl.glGetUniformLocation(pr,f'uT{u}'.encode()),u)
        return len(ts)
    for k,(ob,ins) in enumerate(((A,[src]),(B,A[0]),(Cm,B[0]))):
        pr=ps[k]; gl.glBindFramebuffer(0x8D40,ob[1]); gl.glViewport(0,0,W,H); gl.glUseProgram(pr); u=bind(pr,ins)
        if skip and k>=1: gl.glActiveTexture(0x84C0+u); gl.glBindTexture(0x0DE1,flat); gl.glUniform1i(gl.glGetUniformLocation(pr,b'uFlat'),u)
        gl.glDrawArrays(4,0,3)
    ot=state['ot'] if (state is not None and state.get('ot')) else tex(2*W,2*H,0x1908,0x1401,0x1908)
    if state is not None: state['ot']=ot
    fb=C.c_uint(); gl.glGenFramebuffers(1,C.byref(fb)); gl.glBindFramebuffer(0x8D40,fb); gl.glFramebufferTexture2D(0x8D40,0x8CE0,0x0DE1,ot,0); gl.glDrawBuffers(1,(C.c_uint*1)(0x8CE0))
    gl.glViewport(0,0,2*W,2*H); pf=ps[3]; gl.glUseProgram(pf); bind(pf,Cm[0]); gl.glActiveTexture(0x84C3); gl.glBindTexture(0x0DE1,src); gl.glUniform1i(gl.glGetUniformLocation(pf,b'uIn'),3)
    if skip: gl.glActiveTexture(0x84C4); gl.glBindTexture(0x0DE1,flat); gl.glUniform1i(gl.glGetUniformLocation(pf,b'uFlat'),4)
    gl.glUniform1f(gl.glGetUniformLocation(pf,b'uGain'),gain); gl.glDrawArrays(4,0,3)
    out=np.zeros((2*H,2*W,4),np.uint8); gl.glReadPixels(0,0,2*W,2*H,0x1908,0x1401,out.ctypes.data_as(C.c_void_p))
    if state is not None: state['prev']=tex(W,H,0x1908,0x1401,0x1908,rgba.ctypes.data_as(C.c_void_p)); state['valid']=True
    return out[...,:3].astype(int)
rng=np.random.default_rng(3)
s=np.full((96,128,3),235,np.uint8); s[10:50,10:60]=(50,100,200); s[70:,:]=13; s[55:90,80:120]=(230,75,75)
base=(s.astype(np.float32)/255.); noisy=np.clip(base+rng.normal(0,2/255,base.shape),0,1).astype(np.float32)
for name,f1 in (('synth',base),('synth+noise2',noisy)):
    for gain in (1.0,):
        a=run(f1,True,False,gain,None,False,(3+.25)/255); b=run(f1,True,False,gain,None,True,(3+.25)/255)
        print(f'flat-skip {name:13s}: 8-bit vs 16-bit max {np.abs(a-b).max()} mean {np.abs(a-b).mean():.3f}',flush=True)
        f2=f1.copy(); f2[20:44,30:70]=np.clip(f2[20:44,30:70]*0.7+0.2,0,1)
        for lite in (False,True):
            st={}; run(f1,True,True,gain,st,lite); b=run(f2,True,True,gain,st,lite); ref=run(f2,False,False,gain,None,lite)
            print(f'same-skip lite={lite} {name:13s}: frame 2 maxdiff to the full network {np.abs(b-ref).max()}',flush=True)
