"""Aura Sharp against Aura Sharper (old: push 3.9, limit 0.22; new: push 9.0, limit 0.28) on the app's real NIS shader (software OpenGL ES 3.2).
Run:  EGL_PLATFORM=surfaceless python3 tools/shader_test/aura_sharper_check.py
Prints, at x1.5 / x2 / x3: on a thin white line (1 source pixel) the peak and the dark rim beside it (255 = past the line's own 235), and on the 4 sources of
nis_clean_bench (photo, text lines, noisy jpeg, compressed photo, each shrunk and enlarged again): PSNR, SSIM, edge strength (98th percentile), halos, noise, recovered detail, artifacts."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ['EGL_PLATFORM'] = 'surfaceless'
from chain import *
from nis_clean_bench import SETS, flat_mask, flat_noise, psnr, ssim, lum, gradm, detail_metrics, halo
P = compile_prog(VERT, grab('NIS'))
def aura(img, scale, gain, clean, tight, sharp=0.6):
    bh, bw, _ = img.shape; w, h = int(round(bw * scale)), int(round(bh * scale))
    rgba = np.full((bh, bw, 4), 255, np.uint8); rgba[..., :3] = img
    base = Rt(bw, bh, rgba); d = Rt(w, h)
    run(P, d, [base], i2={'uSrcSize': (bw, bh)}, f1={'uFactor': w / bw, 'uSharp': sharp, 'uGain': gain, 'uClean': clean, 'uTight': tight})
    return d.read()[..., :3]
def thin_line(scale, **kw):
    a = np.full((120, 200, 3), 60, np.uint8); a[:, 40] = 235
    L = lum(aura(a, scale, **kw)); r = int(60 * scale); c0 = int(40 * scale)
    prof = L[r, c0 - int(6 * scale):c0 + int(8 * scale)]
    return prof.max(), max(0.0, 60 - prof.min())
def sources(scale, **kw):
    acc = {k: [] for k in ('psnr', 'ssim', 'g98', 'halo', 'noise', 'detail', 'art')}
    for _, GT, _s in SETS:
        sm = GT.resize((int(round(GT.size[0] / scale)), int(round(GT.size[1] / scale))), Image.LANCZOS)
        out = aura(np.array(sm), scale, **kw); H, W, _ = out.shape
        G = np.array(GT.resize((W, H), Image.LANCZOS)); bil = np.array(sm.resize((W, H), Image.BILINEAR))
        dg, da = detail_metrics(out, G)
        for k, v in dict(psnr=psnr(G, out), ssim=ssim(G, out, channel_axis=2, data_range=255), g98=float(np.percentile(gradm(out), 98)), halo=halo(out, bil), noise=flat_noise(out, flat_mask(G)), detail=dg, art=da).items(): acc[k].append(v)
    return {k: float(np.mean(v)) for k, v in acc.items()}
CFG = [('Sharp (push 2.6, limit 0.15)', dict(gain=2.6, clean=0.2, tight=0.15)),
       ('Sharper 3.99.296 (3.9, 0.22)', dict(gain=3.9, clean=0.32, tight=0.22)),
       ('Sharper 3.99.300 (9.0, 0.28)', dict(gain=9.0, clean=0.2, tight=0.28))]
for sc in (1.5, 2.0, 3.0):
    print('--- scale', sc)
    for n, kw in CFG:
        pk, un = thin_line(sc, **kw); a = sources(sc, **kw)
        print(f"{n:30s} thin line peak {pk:3.0f} dark rim {un:3.0f} | PSNR {a['psnr']:5.2f} SSIM {a['ssim']:.4f} g98 {a['g98']:5.1f} halo {a['halo']:5.2f}% noise {a['noise']:.2f} detail {a['detail']:.3f} artifacts {a['art']:.2f}")
