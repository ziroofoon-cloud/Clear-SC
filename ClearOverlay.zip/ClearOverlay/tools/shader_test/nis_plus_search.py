"""Search for a 'NIS fast clean+' setting: as sharp as NIS fast standard (edge strength and g98) but cleaner (fewer halos, less noise, better PSNR / SSIM).
Run:  EGL_PLATFORM=surfaceless python3 tools/shader_test/nis_plus_search.py"""
import sys, os, itertools, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from nis_clean_bench import *
BASE = grab('NIS_FAST')
def make(R=2.5, T=88.0, cfw=2.6, G=0.85, glo=0.2, ge0=0.02, ge1=0.09, tol=-1.0, level=0):
    t = BASE.replace('#define NF_LEVEL 0', '#define NF_LEVEL %d\n#define NF_REFINE' % level)
    t = t.replace('float kDetectRatio = 2.5 * 1127.0 / 1024.0, kDetectThres = 88.0 / 1024.0;', 'float kDetectRatio = %.4f * 1127.0 / 1024.0, kDetectThres = %.4f / 1024.0;' % (R, T))
    cfl = 'float cf = 1.0;' if cfw <= 0 else 'float cf = smoothstep(kDetectThres, kDetectThres * %.3f, max(c1 ? m1 : 0.0, c2 ? m2 : 0.0));' % cfw
    old = 'float cf = smoothstep(kDetectThres, kDetectThres * 2.6, max(c1 ? m1 : 0.0, c2 ? m2 : 0.0));'
    assert old in t; t = t.replace(old, cfl)
    old = 'yu *= 0.85 * mix(0.2, 1.0, smoothstep(0.02, 0.09, rg));'
    assert old in t
    new = 'yu *= %.4f * mix(%.4f, 1.0, smoothstep(%.4f, %.4f, rg));' % (G, glo, ge0, ge1)
    if tol >= 0:
        new += '\n    { float cl = min(min(x1, x2), min(x3, x4)), ch = max(max(x1, x2), max(x3, x4)); float tt = %.4f * (ch - cl); yu = clamp(y + yu, cl - tt, ch + tt) - y; }' % tol
    t = t.replace(old, new)
    return t
def summarize(res, names):
    out = {}
    for n in names:
        rows = [res[(s, n)] for s, _, _ in SETS]
        out[n] = {k: float(np.mean([r[k] for r in rows])) for k in ('psnr', 'ssim', 'edge', 'g98', 'halo', 'noise', 'dgain', 'art')}
    return out
if __name__ == '__main__':
    cands = {}
    grid = []
    for (R, T, cfw) in ((2.0, 64.0, 0), (2.0, 64.0, 2.6), (2.5, 88.0, 2.6), (2.25, 76.0, 2.6), (2.5, 88.0, 1.6), (2.25, 76.0, 1.6)):
        for G in (1.0, 1.2, 1.4):
            for tol in (-1, 0.05, 0.15):
                grid.append(dict(R=R, T=T, cfw=cfw, G=G, glo=0.2, ge0=0.02, ge1=0.09, tol=tol))
    for ge in ((0.02, 0.09, 0.2), (0.015, 0.05, 0.3)):
        for G in (1.0, 1.3):
            grid.append(dict(R=2.25, T=76.0, cfw=1.6, G=G, glo=ge[2], ge0=ge[0], ge1=ge[1], tol=0.1))
    extra = {}
    for i, g in enumerate(grid):
        extra['P%02d' % i] = (make(**g), 1.0)
    res = evaluate(0.6, extra, quiet=True)
    names = ['bilinear', 'FSR 1 (EASU + RCAS)', 'SGSR 1', 'NIS fast standard L0', 'NIS fast CLEAN L0', 'NIS mid L0'] + list(extra)
    S = summarize(res, names)
    ref = S['NIS fast standard L0']
    print('mean over the 4 sources; ratios to NIS fast standard: edge, g98')
    for n in names:
        s = S[n]; tag = ''
        if n in extra: tag = ' ' + json.dumps({k: v for k, v in grid[int(n[1:])].items() if k not in ('glo', 'ge0', 'ge1') or True})
        print(f'{n:22s} PSNR {s["psnr"]:5.2f} SSIM {s["ssim"]:.4f} edge {s["edge"]:5.2f}({s["edge"]/ref["edge"]:.3f}) g98 {s["g98"]:5.1f}({s["g98"]/ref["g98"]:.3f}) halo {s["halo"]:5.2f} noise {s["noise"]:.2f} DETAIL {s["dgain"]:.3f}({s["dgain"]/ref["dgain"]:.3f}) ART {s["art"]:.2f}({s["art"]/ref["art"]:.3f}){tag}')
