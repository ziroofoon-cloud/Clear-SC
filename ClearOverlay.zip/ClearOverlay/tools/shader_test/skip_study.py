"""How much of the CRSC Edge work the flat-area shortcuts skip, and what a larger shortcut factor (km) does to the picture.
Software OpenGL ES 3.2 (run with EGL_PLATFORM=surfaceless).  For each picture / enlargement / level it renders the chain with km = 1 (as the
app does at Light), 2, 3, 4 (Lightest) and prints the PSNR against km = 1, the largest pixel error, the share of pixels that skip a pass and the
share of 8x8 tiles that skip a pass COMPLETELY (a GPU only saves work when a whole group of neighbouring pixels skips)."""
import sys, os
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import numpy as np
import chain
from chain import Rt, run, progs, CR, BOOST, OVER, RAD, SHOCK, psnr
from PIL import Image

def tiles_skipped(mask, t=8):
    h, w = mask.shape
    h8, w8 = h // t * t, w // t * t
    m = mask[:h8, :w8].reshape(h8 // t, t, w8 // t, t)
    return m.all(axis=(1, 3)).mean()

def frame(img, scale, lv, km, sk=0.5):
    bh, bw, _ = img.shape; w, h = int(bw * scale), int(bh * scale)
    rgba = np.full((bh, bw, 4), 255, np.uint8); rgba[..., :3] = img
    base = Rt(bw, bh, rgba); t1 = Rt(w, h); t2 = Rt(w, h); d = Rt(bw, bh)
    iw, ih, ox, oy = float(bw), float(bh), float(w), float(h)
    run(progs['EASU'], t1, [base], f1={'uSharpness': 0}, i2={'uSrcSize': (bw, bh)},
        f4={'uCon0': (iw/ox, ih/oy, .5*iw/ox-.5, .5*ih/oy-.5), 'uCon1': (1/iw, 1/ih, 1/iw, -1/ih), 'uCon2': (-1/iw, 2/ih, 1/iw, 2/ih), 'uCon3': (0, 4/ih, 0, 0)})
    cur, other = t1, t2
    exact = (lv == 5)
    for _ in range(CR[lv]):
        run(progs['CRSC_DOWN'], d, [cur], f2={'uInv': (1/bw, 1/bh)})
        run(progs['CRSC_BP_L'], other, [cur, base, d], f2={'uInv': (1/bw, 1/bh)}, f1={'uG': 1.3 if lv == 5 else .9})
        cur, other = other, cur
    ratio = min(max(w/bw, 1), 4)
    stats = {}
    a0 = cur.read()[..., 3] / 255.0
    stats['refine'] = (a0 < 0.08 * km)
    run(progs['EDGE_REFINE'], other, [cur], f2={'uInv': (1/w, 1/h)}, i2={'uSize': (w, h)}, f1={'uR': min(max(.67*ratio, 1), 2.5), 'uSkipR': 0 if exact else .08*km}); cur, other = other, cur
    if lv > 0:
        a1 = cur.read()[..., 3] / 255.0
        stats['sharp'] = (a1 < 0.0625 * km)
        run(progs['CRSC_SHARP'], other, [cur], f2={'uInv': (1/w, 1/h)}, f1={'uR': min(max(.5*ratio*RAD[lv], 1), 2), 'uAmt': BOOST[lv]*(.3+sk), 'uOver': OVER[lv], 'uSkip': 0 if exact else .0625*km}); cur, other = other, cur
        a2 = cur.read()[..., 3] / 255.0
        stats['shock'] = (a2 < 0.1 * km)
        run(progs['EDGE_SHOCK'], other, [cur], f2={'uInv': (1/w, 1/h)}, i2={'uSize': (w, h)}, f1={'uR': ratio, 'uSkip': 0 if exact else .1*km, 'uAmt': (.1+.2*sk)*SHOCK[lv]}); cur, other = other, cur
    return cur.read()[..., :3], stats

def pictures():
    from skimage import data
    out = {}
    import matplotlib, os as _os
    gh = np.array(Image.open(_os.path.join(matplotlib.get_data_path(), 'sample_data', 'grace_hopper.jpg')).convert('RGB'))
    out['grace 640x360 x2'] = (np.array(Image.fromarray(gh).resize((640, 360), Image.LANCZOS)), 2.0)
    out['astronaut 256x256 x3'] = (np.array(Image.fromarray(data.astronaut()).resize((256, 256), Image.LANCZOS)), 3.0)
    out['coffee 320x240 x2'] = (np.array(Image.fromarray(data.coffee()).resize((320, 240), Image.LANCZOS)), 2.0)
    out['cat 300x200 x3'] = (np.array(Image.fromarray(data.chelsea()).resize((300, 200), Image.LANCZOS)), 3.0)
    vf = '/mnt/user-data/uploads/1000243811.png'
    if os.path.exists(vf): out['video frame 640x360 x2'] = (np.array(Image.open(vf).convert('RGB')), 2.0)
    return out

if __name__ == '__main__':
    for name, (im, sc) in pictures().items():
        print('==', name)
        for lv in (1, 2, 3, 4):
            ref, st1 = frame(im, sc, lv, 1)
            row = []
            for km in (1, 2, 3, 4):
                o, st = frame(im, sc, lv, km)
                dd = np.abs(o.astype(int) - ref.astype(int))
                px = np.mean([m.mean() for m in st.values()]); tl = np.mean([tiles_skipped(m) for m in st.values()])
                row.append(f'km{km}: {psnr(o, ref):5.1f}dB max{dd.max():2d} skip px {px*100:4.1f}% tiles {tl*100:4.1f}%')
            print(f' lv{lv}  ' + ' | '.join(row))
