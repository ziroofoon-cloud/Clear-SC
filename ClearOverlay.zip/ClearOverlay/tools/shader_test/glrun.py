"""Offscreen test for the NIS shaders: compiles them with a software OpenGL ES 3 driver and renders a picture.
Run:  EGL_PLATFORM=surfaceless python3 tools/shader_test/glrun.py   (prints the driver and whether both shaders compile and link)
Other scripts can import render() / compile_prog() / shaders_from() to compare the output with a numpy model."""
import ctypes as C, numpy as np, re, os, sys
os.environ.setdefault('LIBGL_ALWAYS_SOFTWARE','1')
egl=C.CDLL('libEGL.so.1'); gl=C.CDLL('libGLESv2.so.2')
egl.eglGetDisplay.restype=C.c_void_p; egl.eglGetDisplay.argtypes=[C.c_void_p]
egl.eglInitialize.argtypes=[C.c_void_p,C.POINTER(C.c_int),C.POINTER(C.c_int)]
egl.eglChooseConfig.argtypes=[C.c_void_p,C.POINTER(C.c_int),C.POINTER(C.c_void_p),C.c_int,C.POINTER(C.c_int)]
egl.eglCreatePbufferSurface.restype=C.c_void_p; egl.eglCreatePbufferSurface.argtypes=[C.c_void_p,C.c_void_p,C.POINTER(C.c_int)]
egl.eglCreateContext.restype=C.c_void_p; egl.eglCreateContext.argtypes=[C.c_void_p,C.c_void_p,C.c_void_p,C.POINTER(C.c_int)]
egl.eglMakeCurrent.argtypes=[C.c_void_p]*4
def init():
    d=egl.eglGetDisplay(None); mj=C.c_int(); mn=C.c_int(); assert egl.eglInitialize(d,C.byref(mj),C.byref(mn)),'egl init'
    egl.eglBindAPI(0x30A0)
    at=(C.c_int*9)(0x3033,1,0x3040,0x40,0x3024,8,0x3038,0,0)  # SURFACE_TYPE pbuffer, RENDERABLE ES3, RED 8 ... (NONE)
    at=(C.c_int*7)(0x3033,1,0x3040,0x40,0x3038,0,0)
    cfg=C.c_void_p(); n=C.c_int(); egl.eglChooseConfig(d,at,C.byref(cfg),1,C.byref(n)); assert n.value>0,'no config'
    sf=egl.eglCreatePbufferSurface(d,cfg,(C.c_int*5)(0x3057,16,0x3056,16,0x3038))
    cx=egl.eglCreateContext(d,cfg,None,(C.c_int*3)(0x3098,3,0x3038)); assert cx,'no ctx'
    assert egl.eglMakeCurrent(d,sf,sf,cx),'make current'
    gl.glGetString.restype=C.c_char_p
    return gl.glGetString(0x1F01).decode()+' | '+gl.glGetString(0x1F02).decode()
def compile_prog(vs,fs):
    def sh(t,src):
        s=gl.glCreateShader(t); b=src.encode(); p=C.c_char_p(b); ln=C.c_int(len(b))
        gl.glShaderSource(s,1,C.byref(p),C.byref(ln)); gl.glCompileShader(s)
        ok=C.c_int(); gl.glGetShaderiv(s,0x8B81,C.byref(ok))
        if not ok.value:
            buf=C.create_string_buffer(4096); gl.glGetShaderInfoLog(s,4096,None,buf); raise RuntimeError('compile: '+buf.value.decode())
        return s
    p=gl.glCreateProgram(); gl.glAttachShader(p,sh(0x8B31,vs)); gl.glAttachShader(p,sh(0x8B30,fs)); gl.glLinkProgram(p)
    ok=C.c_int(); gl.glGetProgramiv(p,0x8B82,C.byref(ok))
    if not ok.value:
        buf=C.create_string_buffer(4096); gl.glGetProgramInfoLog(p,4096,None,buf); raise RuntimeError('link: '+buf.value.decode())
    return p
def render(prog,img,outW,outH,ints={},floats={},vec2={},float_out=False):
    """img: HxWx3 float 0..1 ; returns outHxoutWx3 uint8 (rendered with GL_LINEAR + clamp texture)"""
    H,W,_=img.shape
    rgba=np.ones((H,W,4),np.uint8)*255; rgba[...,:3]=(img*255+0.5).astype(np.uint8)
    tex=C.c_uint(); gl.glGenTextures(1,C.byref(tex)); gl.glBindTexture(0x0DE1,tex)
    gl.glTexImage2D(0x0DE1,0,0x1908,W,H,0,0x1908,0x1401,rgba.ctypes.data_as(C.c_void_p))
    for pn,v in ((0x2800,0x2601),(0x2801,0x2601),(0x2802,0x812F),(0x2803,0x812F)): gl.glTexParameteri(0x0DE1,pn,v)
    ot=C.c_uint(); gl.glGenTextures(1,C.byref(ot)); gl.glBindTexture(0x0DE1,ot)
    if float_out: gl.glTexImage2D(0x0DE1,0,0x8814,outW,outH,0,0x1908,0x1406,None)
    else: gl.glTexImage2D(0x0DE1,0,0x1908,outW,outH,0,0x1908,0x1401,None)
    fb=C.c_uint(); gl.glGenFramebuffers(1,C.byref(fb)); gl.glBindFramebuffer(0x8D40,fb)
    gl.glFramebufferTexture2D(0x8D40,0x8CE0,0x0DE1,ot,0)
    gl.glViewport(0,0,outW,outH); gl.glUseProgram(prog)
    gl.glActiveTexture(0x84C0); gl.glBindTexture(0x0DE1,tex)
    gl.glGetUniformLocation.argtypes=[C.c_uint,C.c_char_p]
    gl.glUniform1i(gl.glGetUniformLocation(prog,b'uSrc'),0)
    gl.glUniform2i(gl.glGetUniformLocation(prog,b'uSrcSize'),W,H)
    for k,v in floats.items(): gl.glUniform1f.argtypes=[C.c_int,C.c_float]; gl.glUniform1f(gl.glGetUniformLocation(prog,k.encode()),v)
    for k,(a,b) in vec2.items(): gl.glUniform2f.argtypes=[C.c_int,C.c_float,C.c_float]; gl.glUniform2f(gl.glGetUniformLocation(prog,k.encode()),a,b)
    gl.glDrawArrays(4,0,3)
    gl.glPixelStorei(0x0D05,1)
    if float_out:
        out=np.zeros((outH,outW,4),np.float32); gl.glReadPixels(0,0,outW,outH,0x1908,0x1406,out.ctypes.data_as(C.c_void_p)); return out[...,:3]
    out=np.zeros((outH,outW,4),np.uint8)
    gl.glReadPixels(0,0,outW,outH,0x1908,0x1401,out.ctypes.data_as(C.c_void_p))
    return out[::-1,:,:3] if False else out[...,:3]
def shaders_from(kt=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','..','app','src','main','java','app','clearoverlay','Shaders.kt')):
    s=open(kt).read()
    def grab(name):
        i=s.index(f'const val {name} = """')+len(f'const val {name} = """'); j=s.index('"""',i); return s[i:j]
    return grab('VERT'),grab('NIS'),grab('NIS_ORIG')
if __name__=='__main__':
    print(init()); v,n,o=shaders_from(); print('VERT:\n',v[:400]); p=compile_prog(v,n); print('NIS Lite compiled & linked OK'); p2=compile_prog(v,o); print('NIS original compiled & linked OK')
