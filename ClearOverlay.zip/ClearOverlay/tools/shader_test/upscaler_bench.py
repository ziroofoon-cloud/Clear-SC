"""Upscaler table (software OpenGL ES 3.2, run with EGL_PLATFORM=surfaceless):  python3 tools/shader_test/upscaler_bench.py
Runs the real Aura (NIS Lite: Standard / Soft / Sharp), NIS original and a plain bilinear enlargement on three kinds of source
(a photo, text-like lines, a noisy JPEG-like photo) and prints, against the larger original: PSNR, SSIM, edge strength (mean gradient;
the original has 'GT') and halo % (share of pixels that leave the local range of the plain enlargement by more than 10/255).
The point is to choose defaults with numbers, not to guess. Shader texts are read from Shaders.kt (the app's own)."""
import sys, os, io
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from chain import *
from skimage.metrics import structural_similarity as ssim
from scipy.ndimage import maximum_filter, minimum_filter
photo = Image.open(os.path.join(matplotlib.get_data_path(), 'sample_data', 'grace_hopper.jpg')).convert('RGB')
def lines_img():
    a = np.full((600, 512, 3), 235, np.uint8)
    rng = np.random.RandomState(3)
    for y in range(30, 570, 22):
        x = 20
        while x < 480:
            w = int(rng.randint(6, 40)); a[y:y + 6, x:x + w] = 30; x += w + int(rng.randint(6, 16))
    a[::37, :] = 90
    return Image.fromarray(a)
def jpeg_noisy(img, q=35, noise=3.0):
    b = io.BytesIO(); img.save(b, 'JPEG', quality=q)
    d = np.array(Image.open(io.BytesIO(b.getvalue())).convert('RGB')).astype(float) + np.random.RandomState(1).normal(0, noise, (img.size[1], img.size[0], 3))
    return Image.fromarray(np.clip(d, 0, 255).astype(np.uint8))
SETS = []
GT = photo.resize((512, 600), Image.LANCZOS); SETS.append(('photo', GT, GT.resize((256, 300), Image.LANCZOS)))
L = lines_img(); SETS.append(('text lines', L, L.resize((256, 300), Image.LANCZOS)))
SETS.append(('noisy jpeg photo', GT, jpeg_noisy(GT.resize((256, 300), Image.LANCZOS))))
nis, orig = compile_prog(VERT, grab('NIS')), compile_prog(VERT, grab('NIS_ORIG'))
def lum(a): a = a.astype(float); return .299 * a[..., 0] + .587 * a[..., 1] + .114 * a[..., 2]
def grad(a): gy, gx = np.gradient(lum(a)); return np.hypot(gx, gy).mean()
def halo(o, ref): l, r = lum(o), lum(ref); return ((l > maximum_filter(r, 5) + 10) | (l < minimum_filter(r, 5) - 10)).mean() * 100
VAR = {'Aura standard': (1.0, 0.0, 0.0), 'Aura soft': (0.6, 0.7, 0.0), 'Aura sharp': (2.6, 0.2, 0.15)}
tight_src = grab('NIS')
progs = {}
def aura(src_rt, w, h, bw, bh, name, sharp):
    g, c, t = VAR[name]
    d = Rt(w, h)
    p = nis
    L_ = lambda n: gl.glGetUniformLocation(p, n.encode())
    run(p, d, [src_rt], i2={'uSrcSize': (bw, bh)}, f1={'uFactor': w / bw, 'uGain': g, 'uClean': c, 'uSharp': sharp, 'uTight': t})
    return d.read()[..., :3]
for sharp in (0.6,):
    print(f'sharpness slider {sharp}')
    for name, gt, small in SETS:
        G = np.array(gt); s = np.array(small); bh, bw, _ = s.shape; h, w, _ = G.shape
        rgba = np.full((bh, bw, 4), 255, np.uint8); rgba[..., :3] = s; base = Rt(bw, bh, rgba)
        bil = np.array(small.resize((w, h), Image.BILINEAR))
        rows = [('bilinear', bil)]
        d = Rt(w, h); run(orig, d, [base], i2={'uSrcSize': (bw, bh)}, f1={'uSharp': min(1, .15 + .7 * sharp)}, f2={'uScale': (bw / w, bh / h)}); rows.append(('NIS original', d.read()[..., :3]))
        for v in VAR: rows.append((v, aura(base, w, h, bw, bh, v, sharp)))
        print(f' {name}  (GT edge strength {grad(G):.2f})')
        for n, o in rows:
            print(f'   {n:14s} PSNR {psnr(G, o):5.2f}  SSIM {ssim(G, o, channel_axis=2, data_range=255):.4f}  edges {grad(o):5.2f}  halo {halo(o, bil):5.2f}%')
