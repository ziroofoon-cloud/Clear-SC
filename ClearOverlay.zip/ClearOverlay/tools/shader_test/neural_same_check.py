"""Checks the 'Neural' upscaler's strength (uGain) and its lightening options (skip flat / unchanged areas / similar frames) with the REAL shaders in software OpenGL ES 3.2 (Mesa):
 - the patched hidden / head / compose shaders (a mirror of NeuralNet.flatPatch / composeText) compile for all three models;
 - strength 1.0 = the unpatched network, strength 0 = the plain bilinear picture (the network's number is multiplied);
 - a second frame (one block changed, noise on the rest) drawn with the result of the first KEPT in the unchanged places is bit-identical (maxdiff 0) to the full network on the same input;
 - 'similar frames' (reference picture R' from Ai3Shaders.REF): the kept result is bit-identical to the full network on R', and R' is nowhere further than the tolerance from the real frame.
Run: EGL_PLATFORM=surfaceless python3 tools/shader_test/neural_same_check.py   (needs numpy, scikit-image, opencv)"""
import sys,os,re,ctypes as C,numpy as np
os.environ['EGL_PLATFORM']='surfaceless'
HERE=os.path.dirname(os.path.abspath(__file__)); T=os.path.join(HERE,'..','..')+os.sep; sys.path.insert(0,HERE)
import glrun; from glrun import gl
print(glrun.init()); VERT=glrun.shaders_from()[0]
J=T+'app/src/main/java/app/clearoverlay/'
def const(kt,name):
    s=open(J+kt).read(); i=s.index('const val '+name+' = """')+len('const val '+name+' = """'); return s[i:s.index('"""',i)]
FLAT=const('Ai3Shaders.kt','FLAT'); REF=const('Ai3Shaders.kt','REF')
gl.glClearColor.argtypes=[C.c_float]*4; gl.glGetUniformLocation.argtypes=[C.c_uint,C.c_char_p]; gl.glUniform1i.argtypes=[C.c_int,C.c_int]; gl.glUniform1f.argtypes=[C.c_int,C.c_float]
def tex(w,h,fmt,typ,intf,data=None):
    t=C.c_uint(); gl.glGenTextures(1,C.byref(t)); gl.glBindTexture(0x0DE1,t); gl.glTexImage2D(0x0DE1,0,intf,w,h,0,fmt,typ,data)
    for pn,v in ((0x2800,0x2601),(0x2801,0x2601),(0x2802,0x812F),(0x2803,0x812F)): gl.glTexParameteri(0x0DE1,pn,v)
    return t.value
def fbo_of(ts):
    fb=C.c_uint(); gl.glGenFramebuffers(1,C.byref(fb)); gl.glBindFramebuffer(0x8D40,fb)
    for i,t in enumerate(ts): gl.glFramebufferTexture2D(0x8D40,0x8CE0+i,0x0DE1,t,0)
    gl.glDrawBuffers(len(ts),(C.c_uint*len(ts))(*[0x8CE0+i for i in range(len(ts))])); assert gl.glCheckFramebufferStatus(0x8D40)==0x8CD5; return fb.value
def parse(path):
    ch=ly=0; srcs={}; cur=None
    for ln in open(path).read().split('\n')[1:]:
        if ln.startswith('@'):
            n=ln[1:].strip(); cur=None if n=='end' else srcs.setdefault(n,[]) 
            if n!='end': cur=srcs[n]
        elif cur is not None: cur.append(ln)
        elif ln.startswith('channels '): ch=int(ln[9:])
        elif ln.startswith('layers '): ly=int(ln[7:])
    return ch,ly,{k:'\n'.join(v)+'\n' for k,v in srcs.items()}
def compose_text(src,same):
    up='uniform sampler2D uHead;'; use='vec3(r)'; o='ivec2 o = ivec2(gl_FragCoord.xy);'
    assert up in src and use in src and o in src
    s=src.replace(up,up+'\nuniform float uGain;',1).replace(use,'vec3(r * uGain)',1)
    if same: s=s.replace('uniform float uGain;','uniform float uGain;\nuniform sampler2D uFlat;',1).replace(o,o+'\n    if (texelFetch(uFlat, o >> 1, 0).r > 0.9) discard;',1)
    return s
def flat_patch(layers,pass_,src):
    main='void main() {'; m='ivec2 p = ivec2(gl_FragCoord.xy);'; assert main in src and m in src
    outs=len(re.findall(r'layout\(location=\d+\) out',src)); z=' '.join(f'o{i} = vec4(0.0);' for i in range(outs))
    return src.replace(main,'uniform sampler2D uFlat;\n'+main,1).replace(m,m+f'\n    if (texelFetch(uFlat, p, 0)[{layers-pass_}] > 0.5) {{ {z} return; }}',1)
class Model:
    def __init__(s,name):
        s.ch,s.ly,s.src=parse(T+f'app/src/main/assets/neural/{name}.nsr'); s.n=s.ch//4; assert s.ly==4
        names=['l1']+[f'hid{i}' for i in range(1,s.ly-1)]+['head']
        s.plain=[glrun.compile_prog(VERT,s.src[k]) for k in names]+[glrun.compile_prog(VERT,compose_text(s.src['compose'],False))]
        s.skip=[glrun.compile_prog(VERT,flat_patch(s.ly,i+1,s.src[names[i]])) for i in range(1,s.ly)]+[glrun.compile_prog(VERT,compose_text(s.src['compose'],True))]
        s.refp=glrun.compile_prog(VERT,REF); s.flatp=glrun.compile_prog(VERT,FLAT)
def rgba_tex(img):
    H,W=img.shape[:2]; a=np.full((H,W,4),255,np.uint8); a[...,:3]=img; return tex(W,H,0x1908,0x1401,0x1908,a.ctypes.data_as(C.c_void_p))
def net(m,src_tex,W,H,gain,flat=None,state=None,skipprog=False):
    """draw the network on src_tex; skipprog: use the patched programs with the flat map `flat`. Returns the head texture."""
    A=[tex(W,H,0x1908,0x140B,0x881A) for _ in range(m.n)]; B=[tex(W,H,0x1908,0x140B,0x881A) for _ in range(m.n)]; Hd=tex(W,H,0x1908,0x140B,0x881A)
    fa,fb_,fh=fbo_of(A),fbo_of(B),fbo_of([Hd]); gl.glViewport(0,0,W,H)
    pl=m.plain
    gl.glBindFramebuffer(0x8D40,fa); gl.glUseProgram(pl[0]); gl.glActiveTexture(0x84C0); gl.glBindTexture(0x0DE1,src_tex); gl.glUniform1i(gl.glGetUniformLocation(pl[0],b'uSrc'),0); gl.glDrawArrays(4,0,3)
    cur,nxt,fcur,fnxt=A,B,fa,fb_
    for i in range(1,m.ly):
        last=i==m.ly-1; p=(m.skip[i-1] if skipprog else pl[i])
        gl.glBindFramebuffer(0x8D40,fh if last else fnxt); gl.glUseProgram(p)
        for j in range(m.n): gl.glActiveTexture(0x84C0+j); gl.glBindTexture(0x0DE1,cur[j]); gl.glUniform1i(gl.glGetUniformLocation(p,f'uF{j}'.encode()),j)
        if skipprog: gl.glActiveTexture(0x84C0+m.n); gl.glBindTexture(0x0DE1,flat); gl.glUniform1i(gl.glGetUniformLocation(p,b'uFlat'),m.n)
        gl.glDrawArrays(4,0,3)
        if not last: cur,nxt,fcur,fnxt=nxt,cur,fnxt,fcur
    return Hd
def compose(m,src_tex,head,W,H,gain,out_tex,out_fbo,flat=None,same=False):
    gl.glBindFramebuffer(0x8D40,out_fbo); gl.glViewport(0,0,2*W,2*H); p=m.skip[-1] if same else m.plain[-1]; gl.glUseProgram(p)
    gl.glActiveTexture(0x84C0); gl.glBindTexture(0x0DE1,src_tex); gl.glUniform1i(gl.glGetUniformLocation(p,b'uBase'),0)
    gl.glActiveTexture(0x84C1); gl.glBindTexture(0x0DE1,head); gl.glUniform1i(gl.glGetUniformLocation(p,b'uHead'),1); gl.glUniform1f(gl.glGetUniformLocation(p,b'uGain'),gain)
    if same: gl.glActiveTexture(0x84C2); gl.glBindTexture(0x0DE1,flat); gl.glUniform1i(gl.glGetUniformLocation(p,b'uFlat'),2)
    gl.glDrawArrays(4,0,3)
def readback(out_fbo,W,H):
    gl.glBindFramebuffer(0x8D40,out_fbo); o=np.zeros((2*H,2*W,4),np.uint8); gl.glReadPixels(0,0,2*W,2*H,0x1908,0x1401,o.ctypes.data_as(C.c_void_p)); return o[...,:3].astype(int)
def new_out(W,H):
    t=tex(2*W,2*H,0x1908,0x1401,0x1908); f=fbo_of([t]); gl.glViewport(0,0,2*W,2*H); gl.glClearColor(0.5,0.0,0.5,1.0); gl.glClear(0x4000); return t,f
def flatmap(m,inp,prev,use_prev,W,H,thr):
    ft=tex(W,H,0x1908,0x1401,0x1908); ff=fbo_of([ft]); gl.glViewport(0,0,W,H); gl.glUseProgram(m.flatp)
    gl.glActiveTexture(0x84C0); gl.glBindTexture(0x0DE1,inp); gl.glUniform1i(gl.glGetUniformLocation(m.flatp,b'uIn'),0)
    gl.glActiveTexture(0x84C1); gl.glBindTexture(0x0DE1,prev if use_prev else inp); gl.glUniform1i(gl.glGetUniformLocation(m.flatp,b'uPrev'),1)
    gl.glUniform1i(gl.glGetUniformLocation(m.flatp,b'uSame'),1 if use_prev else 0); gl.glUniform1i(gl.glGetUniformLocation(m.flatp,b'uR'),4); gl.glUniform1i(gl.glGetUniformLocation(m.flatp,b'uE'),2)
    gl.glUniform1f(gl.glGetUniformLocation(m.flatp,b'uThr'),thr); gl.glDrawArrays(4,0,3); return ft
def full(m,img,gain):
    H,W=img.shape[:2]; s=rgba_tex(img); h=net(m,s,W,H,gain); t,f=new_out(W,H); compose(m,s,h,W,H,gain,t,f); return readback(f,W,H)
import cv2, skimage.data as d
def load(n):
    im=getattr(d,n)()
    if im.ndim==2: im=np.stack([im]*3,-1)
    return cv2.resize(im[...,:3],(128,96),interpolation=cv2.INTER_AREA)
rng=np.random.default_rng(5); bad=0
for name in ('lite','medium','plus'):
    m=Model(name); print(f'--- {name}: all shaders compiled')
    img=load('astronaut'); H,W=img.shape[:2]
    # strength: 0 = plain bilinear, 1 = the network; 0.5 lies between
    g1=full(m,img,1.0); g0=full(m,img,0.0); gh=full(m,img,0.5)
    print(f'  gain 0 vs 1: mean |diff| {np.abs(g1-g0).mean():.2f} of 255; gain 0.5 is the middle: mean |gh-(g0+g1)/2| {np.abs(gh-(g0+g1)/2).mean():.3f}')
    # skip unchanged (exact): frame 2 = frame 1 + a changed block
    f1=img.copy(); f2=img.copy(); f2[20:44,30:70]=np.clip(f2[20:44,30:70].astype(int)*0.6+60,0,255).astype(np.uint8)
    s1=rgba_tex(f1); h1=net(m,s1,W,H,1.0); out,of=new_out(W,H); compose(m,s1,h1,W,H,1.0,out,of)       # frame 1 in full
    s2=rgba_tex(f2); flat=flatmap(m,s2,s1,True,W,H,-1.0); h2=net(m,s2,W,H,1.0,flat=flat,skipprog=True); compose(m,s2,h2,W,H,1.0,out,of,flat=flat,same=True)   # frame 2, unchanged places kept
    kept=readback(of,W,H); ref=full(m,f2,1.0); dd=np.abs(kept-ref).max(); bad+=dd!=0
    print(f'  skip unchanged: frame 2 with the result of frame 1 kept vs the full network: maxdiff {dd} (must be 0)')
    # repeated frame: nothing is redrawn, the picture stays exactly the same
    flat=flatmap(m,s1,s1,True,W,H,-1.0); h=net(m,s1,W,H,1.0,flat=flat,skipprog=True); compose(m,s1,h,W,H,1.0,out,of,flat=flat,same=True)
    # (the target is now frame 2's picture; a repeated frame 2 must leave it as it is)
    flat=flatmap(m,s2,s2,True,W,H,-1.0); h=net(m,s2,W,H,1.0,flat=flat,skipprog=True); compose(m,s2,h,W,H,1.0,out,of,flat=flat,same=True)
    # similar frames: noise +-1, a block really changed; R' = REF(frame, reference)
    noisy=np.clip(f1.astype(int)+rng.integers(-1,2,f1.shape),0,255).astype(np.uint8); noisy[20:44,30:70]=f2[20:44,30:70]
    tol=2; close=(np.abs(noisy.astype(int)-f1.astype(int)).max(-1)<=tol)[...,None]; Rp=np.where(close,f1,noisy).astype(np.uint8)
    sR=rgba_tex(Rp)
    # the REF shader itself
    rt=tex(W,H,0x1908,0x1401,0x1908); rf=fbo_of([rt]); gl.glViewport(0,0,W,H); gl.glUseProgram(m.refp); sN=rgba_tex(noisy)
    gl.glActiveTexture(0x84C0); gl.glBindTexture(0x0DE1,sN); gl.glUniform1i(gl.glGetUniformLocation(m.refp,b'uIn'),0)
    gl.glActiveTexture(0x84C1); gl.glBindTexture(0x0DE1,s1); gl.glUniform1i(gl.glGetUniformLocation(m.refp,b'uPrev'),1); gl.glUniform1f(gl.glGetUniformLocation(m.refp,b'uTol'),(tol+0.25)/255); gl.glDrawArrays(4,0,3)
    o=np.zeros((H,W,4),np.uint8); gl.glReadPixels(0,0,W,H,0x1908,0x1401,o.ctypes.data_as(C.c_void_p)); assert (o[...,:3]==Rp).all(),'REF shader != numpy model'
    out,of=new_out(W,H); compose(m,s1,h1,W,H,1.0,out,of)
    flat=flatmap(m,sR,s1,True,W,H,-1.0); hR=net(m,sR,W,H,1.0,flat=flat,skipprog=True); compose(m,sR,hR,W,H,1.0,out,of,flat=flat,same=True)
    kept=readback(of,W,H); refR=full(m,Rp,1.0); dd=np.abs(kept-refR).max(); bad+=dd!=0
    real=full(m,noisy,1.0); skipped=(1-np.mean((np.abs(kept-g1)>0).any(-1)))*100
    print(f'  similar frames (+-1 noise, tolerance {tol}): kept result vs full network on Rp: maxdiff {dd} (must be 0); vs the real frame: maxdiff {np.abs(kept-real).max()}/255; input of Rp differs from the real frame by <= {np.abs(Rp.astype(int)-noisy.astype(int)).max()}')
    # skip flat (Normal = 3 of 255): compiles and differs from the full network only a little
    flat=flatmap(m,s2,s1,False,W,H,(3+0.25)/255); hF=net(m,s2,W,H,1.0,flat=flat,skipprog=True); out,of=new_out(W,H); compose(m,s2,hF,W,H,1.0,out,of,flat=flat,same=True)
    sk=readback(of,W,H); print(f'  skip flat (Normal): vs the full network: maxdiff {np.abs(sk-ref).max()}/255, mean {np.abs(sk-ref).mean():.3f}')
print('ALL EXACT' if bad==0 else f'{bad} EXACTNESS CHECK(S) FAILED')
