from chain import *
img=np.array(Image.open(os.path.join(matplotlib.get_data_path(),'sample_data','grace_hopper.jpg')).convert('RGB'))
pn={n:compile_prog(VERT,grab(n)) for n in ('NIS','NIS_L')}
for name,arr in (('video 640x360',np.array(Image.fromarray(img).resize((640,360),Image.LANCZOS))),('photo 256x300',np.array(Image.fromarray(img).resize((256,300),Image.LANCZOS)))):
    for sc in (1.5,2.0,3.0):
        for soft in (0,1):
            bh,bw,_=arr.shape; w,h=int(bw*sc),int(bh*sc)
            rgba=np.full((bh,bw,4),255,np.uint8); rgba[...,:3]=arr
            base=Rt(bw,bh,rgba); outs=[]
            for n in ('NIS','NIS_L'):
                d=Rt(w,h)
                run(pn[n],d,[base],i2={'uSrcSize':(bw,bh)},f1={'uFactor':w/bw,'uGain':0.6 if soft else 1,'uClean':0.7 if soft else 0,'uSharp':0.6})
                outs.append(d.read()[...,:3])
            df=np.abs(outs[0].astype(int)-outs[1].astype(int))
            print(f'{name} x{sc} {"soft" if soft else "std "}: PSNR {psnr(outs[0],outs[1]):5.1f} max {df.max()}')
