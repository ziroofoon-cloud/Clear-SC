"""CRSC Edge levels (the app's real shaders, via chain.frame): does a lower level lose real detail, or only the extra steps? Original / Light / Lightest per level, 4 test sources.
Run: EGL_PLATFORM=surfaceless python3 tools/shader_test/crsc_levels.py"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from nis_clean_bench import *
import chain
rows = {}
for sname, gt, small in SETS:
    G = np.array(gt); s = np.array(small); mask = flat_mask(G); bil = np.array(small.resize((G.shape[1], G.shape[0]), Image.BILINEAR))
    for lv in range(6):
        for mode in ('orig', 'lightest'):
            o = chain.frame(s, 2.0, lv, mode, 0.6)
            dg, da = detail_metrics(o, G)
            rows.setdefault((lv, mode), []).append(dict(psnr=psnr(G, o), ssim=ssim(G, o, channel_axis=2, data_range=255), halo=halo(o, bil), noise=flat_noise(o, mask), dg=dg, art=da, edge=gradm(o).mean()))
print('mean of 4 sources (2x, slider 0.6)')
for k, rs in rows.items():
    m = {x: np.mean([r[x] for r in rs]) for x in rs[0]}
    print(f'level {k[0]} {k[1]:8s} PSNR {m["psnr"]:5.2f} SSIM {m["ssim"]:.4f} halo {m["halo"]:5.2f} noise {m["noise"]:.2f} edge {m["edge"]:5.2f} DETAIL {m["dg"]:.3f} ART {m["art"]:.2f}')
