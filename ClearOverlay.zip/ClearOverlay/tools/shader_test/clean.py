from chain import *
import io
from skimage.metrics import structural_similarity as ssim
img=Image.open(os.path.join(matplotlib.get_data_path(),'sample_data','grace_hopper.jpg')).convert('RGB')
GT=img.resize((512,600),Image.LANCZOS)            # ground truth (what a good source would have been at the big size)
small=GT.resize((256,300),Image.LANCZOS)
def degrade(q,noise,seed=1):
    b=io.BytesIO(); small.save(b,'JPEG',quality=q); d=np.array(Image.open(io.BytesIO(b.getvalue())).convert('RGB')).astype(float)
    r=np.random.RandomState(seed); d+=r.normal(0,noise,d.shape); return np.clip(d,0,255).astype(np.uint8)
G=np.array(GT)
def prog(name,txt=None):
    return compile_prog(VERT,txt if txt is not None else grab(name))
P={n:prog(n) for n in ('DENOISE','PRESHARP','RCAS')}
def pass1(p,src,f1={},f2=None,w=None,h=None,i2={}):
    d=Rt(w or src.w,h or src.h); run(p,d,[src],f1=f1,f2=f2 or {'uInv':(1/src.w,1/src.h)},i2=i2); return d
def pipeline(arr,L,den=None,pre=None,sharp=0.5,clean=True):
    bh,bw,_=arr.shape; rgba=np.full((bh,bw,4),255,np.uint8); rgba[...,:3]=arr
    cur=Rt(bw,bh,rgba)
    dn=P['DENOISE'] if den is None else den; ps=P['PRESHARP'] if pre is None else pre
    if clean:
        cur=pass1(dn,cur,f1={'uAmt':max(0.0,0.08+0.25*L)})
        cur=pass1(ps,cur,f1={'uAmt':max(sharp*0.6,0.15+0.8*L)})
    w,h=bw*2,bh*2; up=Rt(w,h)
    run(P_EASU,up,[cur],i2={'uSrcSize':(bw,bh)},f4={'uCon0':(bw/w,bh/h,.5*bw/w-.5,.5*bh/h-.5),'uCon1':(1/bw,1/bh,1/bw,-1/bh),'uCon2':(-1/bw,2/bh,1/bw,2/bh),'uCon3':(0,4/bh,0,0)})
    out=Rt(w,h); run(P['RCAS'],out,[up],i2={'uSrcSize':(w,h)},f1={'uSharpness':sharp*1.2*0.6})
    return out.read()[...,:3]
P_EASU=progs['EASU']
def score(o):
    return psnr(G,o), ssim(G,o,channel_axis=2,data_range=255)
if __name__=='__main__':
    for name,(q,n) in {'light compression q60 noise0':(60,0),'compressed q30 noise2':(30,2),'noisy q80 noise6':(80,6),'clean q95 noise0':(95,0)}.items():
        arr=degrade(q,n); print('==',name)
        print(' no clean-up     PSNR %.2f SSIM %.4f'%score(pipeline(arr,0,clean=False)))
        for L in (0.2,0.4,0.6,0.8):
            print(' clean L=%.1f     PSNR %.2f SSIM %.4f'%((L,)+score(pipeline(arr,L))))
