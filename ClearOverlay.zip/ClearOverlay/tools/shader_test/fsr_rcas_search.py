"""FSR 1 with a stronger RCAS and 'Protect' (the app's own settings, same cost) against FSR 1 default, SGSR 1 and NIS mid: detail brought back vs artifacts.
Run: EGL_PLATFORM=surfaceless python3 tools/shader_test/fsr_rcas_search.py"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from nis_clean_bench import *
def run_fsr2(base, w, h, bw, bh, sharp, prot):
    t1 = Rt(w, h); iw, ih, ox, oy = float(bw), float(bh), float(w), float(h)
    run(progs['EASU'], t1, [base], f1={'uSharpness': 0}, i2={'uSrcSize': (bw, bh)},
        f4={'uCon0': (iw / ox, ih / oy, .5 * iw / ox - .5, .5 * ih / oy - .5), 'uCon1': (1 / iw, 1 / ih, 1 / iw, -1 / ih), 'uCon2': (-1 / iw, 2 / ih, 1 / iw, 2 / ih), 'uCon3': (0, 4 / ih, 0, 0)})
    out = Rt(w, h); run(prog('RCAS', grab('RCAS')), out, [t1], i2={'uSrcSize': (w, h)}, f1={'uSharpness': sharp, 'uProtect': prot}); return out.read()[..., :3]
rows = {}
for sname, gt, small in SETS:
    G = np.array(gt); s = np.array(small); bh, bw, _ = s.shape; h, w, _ = G.shape
    rgba = np.full((bh, bw, 4), 255, np.uint8); rgba[..., :3] = s; base = Rt(bw, bh, rgba)
    mask = flat_mask(G); bil = np.array(small.resize((w, h), Image.BILINEAR))
    cases = {'FSR default (slider .6 -> 0.72)': lambda: run_fsr2(base, w, h, bw, bh, 0.72, 0.0), 'SGSR 1 (slider .6)': lambda: run_sgsr(base, w, h, bw, bh, 0.6),
             'NIS fast standard': lambda: run_nis(base, w, h, bw, bh, prog('fast0', nisfast_src(0)), 0.57), 'NIS fast CLEAN': lambda: run_nis(base, w, h, bw, bh, prog('clean0', nisfast_src(0, True)), 0.57),
             'NIS mid L2': lambda: run_nis(base, w, h, bw, bh, prog('fast2', nisfast_src(2)), 0.57 * .75)}
    for sh in (1.0, 1.2, 1.5):
        for pr in (0.0, 0.5, 1.0):
            cases['FSR rcas %.1f protect %.1f' % (sh, pr)] = (lambda sh, pr: lambda: run_fsr2(base, w, h, bw, bh, sh, pr))(sh, pr)
    for n, f in cases.items():
        o = f(); dg, da = detail_metrics(o, G)
        rows.setdefault(n, []).append(dict(psnr=psnr(G, o), ssim=ssim(G, o, channel_axis=2, data_range=255), halo=halo(o, bil), noise=flat_noise(o, mask), dg=dg, art=da))
ref = {k: np.mean([r[k] for r in rows['FSR default (slider .6 -> 0.72)']]) for k in ('dg', 'art')}
print('mean of 4 sources; DETAIL and ART are ratios to FSR default; ratio = ART/DETAIL (lower = fewer artifacts per bit of real detail)')
for n, rs in rows.items():
    m = {k: np.mean([r[k] for r in rs]) for k in rs[0]}
    print(f'{n:32s} PSNR {m["psnr"]:5.2f} SSIM {m["ssim"]:.4f} halo {m["halo"]:5.2f} noise {m["noise"]:.2f} DETAIL {m["dg"]/ref["dg"]:.3f} ART {m["art"]/ref["art"]:.3f} ratio {(m["art"]/ref["art"])/(m["dg"]/ref["dg"]):.3f}')
