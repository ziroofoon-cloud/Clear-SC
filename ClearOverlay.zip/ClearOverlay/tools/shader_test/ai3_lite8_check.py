"""Checks the "Lite 8" storage (feature maps as RGBA8, companded) for AI 3x / Nova 3x with the real shaders in software OpenGL ES 3.2 (Mesa). The tables (file names, buffer sizes, pass plan,
final inputs) are read from Ai3Shaders.kt. Prints the difference of the final picture to the normal RGBA16F run (of 255).
Run: EGL_PLATFORM=surfaceless python3 tools/shader_test/ai3_lite8_check.py <picture.png> [R] [tiers,comma]  (needs numpy, PIL)"""
import sys,re,os,ctypes as C,numpy as np
os.environ['EGL_PLATFORM']='surfaceless'
HERE=os.path.dirname(os.path.abspath(__file__)); T=os.path.join(HERE,'..','..')+os.sep
sys.path.insert(0,HERE)
import glrun; from glrun import gl
from PIL import Image
import lite8_wrap as W8
print(glrun.init())
VERT=glrun.shaders_from()[0]
kt=open(T+'app/src/main/java/app/clearoverlay/Ai3Shaders.kt').read()
FILE=re.findall(r'"([^"]+)"',re.search(r'private val FILE = arrayOf\((.*?)\)\n',kt).group(1))
SIZES=[[int(x) for x in m.split(',')] for m in re.findall(r'intArrayOf\(([\d, ]+)\)',re.search(r'val SIZES = arrayOf\((.*?)\)\n',kt).group(1))]
def plan(t):
    body=re.search(r'fun plan\(t: Int\): Array<IntArray> = when \(t\) \{(.*?)\n    \}',kt,re.S).group(1)
    for line in body.strip().split('\n'):
        a,b=line.split('->',1); a=a.strip()
        rows=[[int(x) for x in r.split(',')] for r in re.findall(r'intArrayOf\(([-\d, ]+)\)',b)]
        if a=='else' or t in [int(x) for x in re.findall(r'\d+',a) if True] and '..' not in a or any(('..' in p and int(p.split('..')[0])<=t<=int(p.split('..')[1])) for p in re.findall(r'\d+\.\.\d+',a)):
            return rows
def finalInputs(t): return [2] if (t in (0,7,11,13,15,17) or 18<=t<=30) else ([1] if t in (8,9,10,12,14,16) else [2,3])
A=T+'app/src/main/assets/ai3/'
gl.glGetUniformLocation.argtypes=[C.c_uint,C.c_char_p]; gl.glUniform1i.argtypes=[C.c_int,C.c_int]; gl.glUniform1f.argtypes=[C.c_int,C.c_float]
def tex(w,h,fmt,typ,intf,data=None):
    t=C.c_uint(); gl.glGenTextures(1,C.byref(t)); gl.glBindTexture(0x0DE1,t); gl.glTexImage2D(0x0DE1,0,intf,w,h,0,fmt,typ,data)
    for pn,v in ((0x2800,0x2600),(0x2801,0x2600),(0x2802,0x812F),(0x2803,0x812F)): gl.glTexParameteri(0x0DE1,pn,v)
    return t.value
def mrt(n,w,h,lite):
    ts=[tex(w,h,0x1908,0x1401,0x8058) if lite else tex(w,h,0x1908,0x140B,0x881A) for _ in range(n)]
    fb=C.c_uint(); gl.glGenFramebuffers(1,C.byref(fb)); gl.glBindFramebuffer(0x8D40,fb)
    for i,t in enumerate(ts): gl.glFramebufferTexture2D(0x8D40,0x8CE0+i,0x0DE1,t,0)
    gl.glDrawBuffers(n,(C.c_uint*n)(*[0x8CE0+i for i in range(n)])); assert gl.glCheckFramebufferStatus(0x8D40)==0x8CD5
    return ts,fb.value
cache={}
def progs(t,lite):
    k=(t,lite)
    if k not in cache:
        L=len(plan(t)); n=L+1; l=[]
        for p in range(1,n+1):
            s=open(f'{A}{FILE[t]}_p{p}.frag').read()
            if lite: s=W8.wrap(s,p>1,p<n)
            l.append(glrun.compile_prog(VERT,s))
        cache[k]=l
    return cache[k]
def run(t,img,lite,gain=1.0):
    H,Wd=img.shape[:2]; ps=progs(t,lite)
    rgba=np.full((H,Wd,4),255,np.uint8); rgba[...,:3]=img
    src=tex(Wd,H,0x1908,0x1401,0x1908,rgba.ctypes.data_as(C.c_void_p))
    bufs=[mrt(n,Wd,H,lite) if n else None for n in SIZES[t]]
    def bind(pr,tl):
        for u,ti in enumerate(tl): gl.glActiveTexture(0x84C0+u); gl.glBindTexture(0x0DE1,ti); gl.glUniform1i(gl.glGetUniformLocation(pr,f'uT{u}'.encode()),u)
        return len(tl)
    for k,pl in enumerate(plan(t)):
        pr=ps[k]; ob=bufs[pl[0]]; gl.glBindFramebuffer(0x8D40,ob[1]); gl.glViewport(0,0,Wd,H); gl.glUseProgram(pr)
        ins=[]
        for i in pl[1:]: ins+=[src] if i<0 else bufs[i][0]
        bind(pr,ins); gl.glDrawArrays(4,0,3)
    pf=ps[-1]; ot=tex(3*Wd,3*H,0x1908,0x1401,0x1908)
    fb=C.c_uint(); gl.glGenFramebuffers(1,C.byref(fb)); gl.glBindFramebuffer(0x8D40,fb); gl.glFramebufferTexture2D(0x8D40,0x8CE0,0x0DE1,ot,0); gl.glDrawBuffers(1,(C.c_uint*1)(0x8CE0))
    gl.glViewport(0,0,3*Wd,3*H); gl.glUseProgram(pf)
    ins=[]
    for i in finalInputs(t): ins+=bufs[i][0]
    u=bind(pf,ins); gl.glActiveTexture(0x84C0+u); gl.glBindTexture(0x0DE1,src); gl.glUniform1i(gl.glGetUniformLocation(pf,b'uIn'),u)
    gl.glUniform1f(gl.glGetUniformLocation(pf,b'uGain'),gain); gl.glDrawArrays(4,0,3)
    out=np.zeros((3*H,3*Wd,4),np.uint8); gl.glReadPixels(0,0,3*Wd,3*H,0x1908,0x1401,out.ctypes.data_as(C.c_void_p))
    return out[...,:3].astype(int)
if __name__=='__main__':
    im=Image.open(sys.argv[1]).convert('RGB'); im=im.crop((0,0,min(im.width,128),min(im.height,96))); img=np.array(im)
    if len(sys.argv)>2: W8.R=float(sys.argv[2])
    ts=[int(x) for x in sys.argv[3].split(',')] if len(sys.argv)>3 else list(range(len(FILE)))
    for t in ts:
        try:
            a=run(t,img,False); b=run(t,img,True); d=np.abs(a-b)
            print(f'R={W8.R:g} tier {t:2d} {FILE[t]:16s} max {d.max():3d}  mean {d.mean():.3f}  >2: {100*(d>2).mean():.2f}%  >4: {100*(d>4).mean():.3f}%',flush=True)
        except Exception as e: print('tier',t,FILE[t],'FAILED',repr(e)[:150],flush=True)
