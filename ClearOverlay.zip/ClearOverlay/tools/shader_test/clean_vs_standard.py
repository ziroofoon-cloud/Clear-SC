"""Is 'NIS fast (clean)' with a higher Sharpness slider as sharp as 'NIS fast' standard, and cleaner? (same cost: the slider is a uniform)
Run: EGL_PLATFORM=surfaceless python3 tools/shader_test/clean_vs_standard.py"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from nis_clean_bench import *
P_STD = prog('fast0', nisfast_src(0)); P_CLN = prog('clean0', nisfast_src(0, True))
rows = {}
def slider_to_u(sl): return min(1.0, .15 + .7 * sl)
for sname, gt, small in SETS:
    G = np.array(gt); s = np.array(small); bh, bw, _ = s.shape; h, w, _ = G.shape
    rgba = np.full((bh, bw, 4), 255, np.uint8); rgba[..., :3] = s; base = Rt(bw, bh, rgba)
    mask = flat_mask(G); bil = np.array(small.resize((w, h), Image.BILINEAR))
    cases = {}
    for sl in (0.5, 0.6): cases['standard  slider %.2f' % sl] = (lambda sl: lambda: run_nis(base, w, h, bw, bh, P_STD, slider_to_u(sl)))(sl)
    for sl in (0.5, 0.6, 0.7, 0.8, 0.9, 1.0): cases['CLEAN     slider %.2f' % sl] = (lambda sl: lambda: run_nis(base, w, h, bw, bh, P_CLN, slider_to_u(sl)))(sl)
    for n, f in cases.items():
        o = f(); dg, da = detail_metrics(o, G)
        rows.setdefault(n, []).append(dict(psnr=psnr(G, o), ssim=ssim(G, o, channel_axis=2, data_range=255), halo=halo(o, bil), noise=flat_noise(o, mask), dg=dg, art=da, edge=gradm(o).mean()))
ref = {k: np.mean([r[k] for r in rows['standard  slider 0.60']]) for k in ('dg', 'art', 'halo', 'edge')}
print('mean of 4 sources; DETAIL / ART / EDGE = ratio to NIS fast standard at slider 0.60')
for n, rs in rows.items():
    m = {k: np.mean([r[k] for r in rs]) for k in rs[0]}
    print(f'{n:24s} PSNR {m["psnr"]:5.2f} SSIM {m["ssim"]:.4f} halo {m["halo"]:5.2f} noise {m["noise"]:.2f} EDGE {m["edge"]/ref["edge"]:.3f} DETAIL {m["dg"]/ref["dg"]:.3f} ART {m["art"]/ref["art"]:.3f}')
