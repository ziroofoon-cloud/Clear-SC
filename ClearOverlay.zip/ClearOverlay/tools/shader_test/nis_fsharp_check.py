"""NIS fast: Standard vs Clean + Sharp (NF_CRISP) vs Sharp (NF_SHARP, 3.99.308), rendered with the REAL shader text of Shaders.kt on Mesa llvmpipe.
Run:  EGL_PLATFORM=surfaceless python3 tools/shader_test/nis_clean_check.py
Prints, per test picture (clean / compressed / noisy source, 2x up), against the full-size ground truth:
  edge   = mean gradient on the edges of the truth, output / truth   (1.00 = as sharp as the truth; higher = sharper)
  detail = fine-detail energy (picture minus its blur) in textured places, output / truth
  flat   = same fine energy in flat places: the noise that was made (lower = cleaner)
  PSNR / SSIM against the truth.
"""
import io, os, sys
import numpy as np
from PIL import Image
import matplotlib
from scipy import ndimage as ndi
from skimage.metrics import structural_similarity as ssim
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import glrun as G

print(G.init())
KT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'app', 'src', 'main', 'java', 'app', 'clearoverlay', 'Shaders.kt')
src = open(KT, encoding='utf-8').read()
def grab(name):
    i = src.index(f'const val {name} = """') + len(f'const val {name} = """'); j = src.index('"""', i); return src[i:j]
VERT = grab('VERT'); FAST = grab('NIS_FAST'); FASTG = grab('NIS_FAST_G')
def variant(txt, lv, mode):
    d = '#define NF_LEVEL %d' % lv + {'std': '', 'clean': '\n#define NF_REFINE', 'crisp': '\n#define NF_CRISP', 'fsharp': '\n#define NF_SHARP'}[mode]
    return txt.replace('#define NF_LEVEL 0', d)
# the gather versions must at least compile / link too (they need ES 3.1: llvmpipe has 3.2)
V310 = VERT.replace('#version 300 es', '#version 310 es')
for mode in ('std', 'clean', 'crisp', 'fsharp'):
    for lv in (0, 1, 2):
        G.compile_prog(VERT, variant(FAST, lv, mode)); G.compile_prog(V310, variant(FASTG, lv, mode))
print('all 12 plain + 12 gather programs compile and link')

img = Image.open(os.path.join(matplotlib.get_data_path(), 'sample_data', 'grace_hopper.jpg')).convert('RGB')
GT = img.resize((512, 600), Image.LANCZOS); small = GT.resize((256, 300), Image.LANCZOS)
GTa = np.array(GT).astype(np.float32)
def lum(a): return 0.2126 * a[..., 0] + 0.7152 * a[..., 1] + 0.0722 * a[..., 2]
def degrade(q, noise, seed=1):
    b = io.BytesIO(); small.save(b, 'JPEG', quality=q); d = np.array(Image.open(io.BytesIO(b.getvalue())).convert('RGB')).astype(float)
    d += np.random.RandomState(seed).normal(0, noise, d.shape); return np.clip(d, 0, 255).astype(np.uint8)
gy = lum(GTa)
gx_, gy_ = ndi.sobel(gy, 1), ndi.sobel(gy, 0); gmag = np.hypot(gx_, gy_) / 8
edge = ndi.binary_dilation(gmag > 12, iterations=1)
loc = np.sqrt(np.maximum(ndi.uniform_filter(gy ** 2, 5) - ndi.uniform_filter(gy, 5) ** 2, 0))
flat = (ndi.maximum_filter(gmag, 7) < 2.5)
tex = (~edge) & (loc > 3) & (gmag > 2.5) & (gmag <= 12)
print('mask sizes: edge %d  texture %d  flat %d' % (edge.sum(), tex.sum(), flat.sum()))
def hp(a): l = lum(a.astype(np.float32)); return l - ndi.gaussian_filter(l, 1.2)
def metrics(o):
    o = o.astype(np.float32)
    ge = np.hypot(ndi.sobel(lum(o), 1), ndi.sobel(lum(o), 0)) / 8
    h, ht = hp(o), hp(GTa)
    mse = ((o - GTa) ** 2).mean()
    return dict(edge=ge[edge].mean() / gmag[edge].mean(),
                detail=np.sqrt((h[tex] ** 2).mean()) / np.sqrt((ht[tex] ** 2).mean()),
                flat=np.sqrt((h[flat] ** 2).mean()),
                psnr=10 * np.log10(255 ** 2 / mse), ssim=ssim(GTa.astype(np.uint8), o.astype(np.uint8), channel_axis=2, data_range=255))
def up(arr, prog, sharp):
    return G.render(prog, arr.astype(np.float32) / 255, 512, 600, floats={'uSharp': sharp}, vec2={'uScale': (0.5, 0.5)})

CASES = {'clean source (q95, no noise)': (95, 0), 'compressed (q40, noise 1.5)': (40, 1.5), 'noisy low quality (q30, noise 4)': (30, 4)}
MODES = [('NIS fast Standard', 'std'), ('NIS fast Clean + Sharp', 'crisp'), ('NIS fast Sharp (new)', 'fsharp')]
progs = {(m, lv): G.compile_prog(VERT, variant(FAST, lv, m)) for _, m in MODES for lv in (0, 1, 2)}
res = {}
for sharp in (0.5, 0.71):
    print('\n######## uSharp = %.2f (slider 0.5 / 0.8) ########' % sharp)
    for cname, (q, n) in CASES.items():
        arr = degrade(q, n); print('\n== %s' % cname)
        print('%-24s %6s %7s %7s %7s %7s' % ('', 'edge', 'detail', 'flat', 'PSNR', 'SSIM'))
        for label, m in MODES:
            r = metrics(up(arr, progs[(m, 0)], sharp)); res[(sharp, cname, m)] = r
            print('%-24s %6.3f %7.3f %7.3f %7.2f %7.4f' % (label, r['edge'], r['detail'], r['flat'], r['psnr'], r['ssim']))
# the lighter levels: the new variant against Standard at the same level
print('\n######## levels 1 / 2 (uSharp 0.5, compressed source) ########')
arr = degrade(40, 1.5)
for lv in (1, 2):
    for label, m in MODES:
        r = metrics(up(arr, progs[(m, lv)], 0.5)); print('level %d %-24s edge %.3f detail %.3f flat %.3f PSNR %.2f SSIM %.4f' % (lv, label, r['edge'], r['detail'], r['flat'], r['psnr'], r['ssim']))
# save a crop for looking at
arr = degrade(30, 4); outs = [up(arr, progs[(m, 0)], 0.5) for _, m in MODES]
crop = lambda a: a[40:240, 120:320]
Image.fromarray(np.concatenate([crop(np.array(GT))] + [crop(o) for o in outs], 1)).resize((1600, 400), Image.NEAREST).save('/home/claude/nis_fsharp_compare.png')
print('saved /home/claude/nis_fsharp_compare.png  (truth | Standard | Clean | Clean + Sharp)')

# thin bright line + a bar on grey: the rim (dark undershoot beside the line) and the peak (overshoot) of each variant
print('\n######## thin line / bar test (source 8-bit grey 100, line 200 / bar 200; uSharp 0.5) ########')
t = np.full((300, 256, 3), 100, np.uint8); t[:, 60] = 200; t[:, 120:126] = 200; t[100:, 180:200] = 40
for label, m in MODES:
    o = up(t, progs[(m, 0)], 0.5)[:, :, 0].astype(float); row = o[50]
    print('%-24s line peak %5.1f  rim min beside line %5.1f  bar peak %5.1f  bar rim min %5.1f' % (label, row[116:140].max() if False else o[50, 2*60-3:2*60+4].max(), o[50, 2*60-6:2*60-2].min(), o[50, 2*120-3:2*126+3].max(), o[50, 2*120-8:2*120-3].min()))
