"""Checks the "Lite 8" storage of the AI 2x feature maps (RGBA8 instead of RGBA16F, companded) with the real shaders in software OpenGL ES 3.2 (Mesa).
The wrapper below mirrors Lite8.wrap in SrShaders.kt. Prints, per network, the difference of the final picture to the normal RGBA16F run (of 255).
Run: EGL_PLATFORM=surfaceless python3 tools/shader_test/lite8_check.py <picture.png> [R]  (needs numpy, PIL)"""
import sys,re,os,ctypes as C,numpy as np
os.environ['EGL_PLATFORM']='surfaceless'
HERE=os.path.dirname(os.path.abspath(__file__)); T=os.path.join(HERE,'..','..')+os.sep
sys.path.insert(0,HERE)
import glrun; from glrun import gl
from PIL import Image
print(glrun.init())
VERT=glrun.shaders_from()[0]
J=T+'app/src/main/java/app/clearoverlay/'
def const(kt,name):
    s=open(J+kt).read(); i=s.index('const val '+name+' = """')+len('const val '+name+' = """'); return s[i:s.index('"""',i)]
RNG=float(sys.argv[2]) if len(sys.argv)>2 else 8.0
def wrap(src,dec,enc,R=RNG):
    """mirror of Lite8.wrap"""
    fn=("\nconst float L8R = %s;\nvec4 l8d(vec4 e){ vec4 s = e * 2.0 - 1.0; return sign(s) * s * s * L8R; }\nvec4 l8e(vec4 v){ return sign(v) * sqrt(min(abs(v) / L8R, 1.0)) * 0.5 + 0.5; }\n"%repr(R))
    s=src
    if dec: s=re.sub(r'texelFetch\((uT\d+),\s*([^,]+?),\s*0\)',r'l8d(texelFetch(\1, \2, 0))',s)
    if enc: s=re.sub(r'(?m)^(\s*o\d+ = )(.*);\s*$',lambda m:m.group(1)+'l8e('+m.group(2)+');',s)
    i=s.index('void main()')
    return s[:i]+fn+s[i:]
gl.glGetUniformLocation.argtypes=[C.c_uint,C.c_char_p]; gl.glUniform1i.argtypes=[C.c_int,C.c_int]; gl.glUniform1f.argtypes=[C.c_int,C.c_float]
def tex(w,h,fmt,typ,intf,data=None):
    t=C.c_uint(); gl.glGenTextures(1,C.byref(t)); gl.glBindTexture(0x0DE1,t); gl.glTexImage2D(0x0DE1,0,intf,w,h,0,fmt,typ,data)
    for pn,v in ((0x2800,0x2600),(0x2801,0x2600),(0x2802,0x812F),(0x2803,0x812F)): gl.glTexParameteri(0x0DE1,pn,v)
    return t.value
def mrt(n,w,h,lite):
    ts=[tex(w,h,0x1908,0x1401,0x8058) if lite else tex(w,h,0x1908,0x140B,0x881A) for _ in range(n)]
    fb=C.c_uint(); gl.glGenFramebuffers(1,C.byref(fb)); gl.glBindFramebuffer(0x8D40,fb)
    for i,t in enumerate(ts): gl.glFramebufferTexture2D(0x8D40,0x8CE0+i,0x0DE1,t,0)
    gl.glDrawBuffers(n,(C.c_uint*n)(*[0x8CE0+i for i in range(n)])); assert gl.glCheckFramebufferStatus(0x8D40)==0x8CD5
    return ts,fb.value
def run(img,P,P4,ng,lite,gain=1.0):
    H,W=img.shape[:2]
    if lite: P=[wrap(P[0],False,True),wrap(P[1],True,True),wrap(P[2],True,True)]; P4=wrap(P4,True,False)
    ps=[glrun.compile_prog(VERT,s) for s in P+[P4]]
    rgba=np.full((H,W,4),255,np.uint8); rgba[...,:3]=img
    src=tex(W,H,0x1908,0x1401,0x1908,rgba.ctypes.data_as(C.c_void_p))
    A=mrt(ng,W,H,lite); B=mrt(ng,W,H,lite); Cm=mrt(3,W,H,lite)
    def bind(pr,ts):
        for u,ti in enumerate(ts): gl.glActiveTexture(0x84C0+u); gl.glBindTexture(0x0DE1,ti); gl.glUniform1i(gl.glGetUniformLocation(pr,f'uT{u}'.encode()),u)
        return len(ts)
    for k,(ob,ins) in enumerate(((A,[src]),(B,A[0]),(Cm,B[0]))):
        pr=ps[k]; gl.glBindFramebuffer(0x8D40,ob[1]); gl.glViewport(0,0,W,H); gl.glUseProgram(pr); bind(pr,ins); gl.glDrawArrays(4,0,3)
    ot=tex(2*W,2*H,0x1908,0x1401,0x1908)
    fb=C.c_uint(); gl.glGenFramebuffers(1,C.byref(fb)); gl.glBindFramebuffer(0x8D40,fb); gl.glFramebufferTexture2D(0x8D40,0x8CE0,0x0DE1,ot,0); gl.glDrawBuffers(1,(C.c_uint*1)(0x8CE0))
    gl.glViewport(0,0,2*W,2*H); pf=ps[3]; gl.glUseProgram(pf); bind(pf,Cm[0]); gl.glActiveTexture(0x84C3); gl.glBindTexture(0x0DE1,src); gl.glUniform1i(gl.glGetUniformLocation(pf,b'uIn'),3)
    gl.glUniform1f(gl.glGetUniformLocation(pf,b'uGain'),gain); gl.glDrawArrays(4,0,3)
    out=np.zeros((2*H,2*W,4),np.uint8); gl.glReadPixels(0,0,2*W,2*H,0x1908,0x1401,out.ctypes.data_as(C.c_void_p))
    return out[...,:3].astype(int)
im=Image.open(sys.argv[1]).convert('RGB'); im=im.crop((0,0,min(im.width,192),min(im.height,128))); img=np.array(im)
P4=const('SrShaders.kt','PASS4')
nets=[('Standard 8ch',[const('SrShaders.kt',f'PASS{i}') for i in (1,2,3)],2),('Wide 12ch',[const('SrShaders.kt',f'PASS{i}_12') for i in (1,2,3)],3)]
A=J.replace('java/app/clearoverlay/','assets/sr/')
for nm,f,ng in (('c8',None,2),('c12',None,3),('n16',None,4),('a4',None,1)):
    nets.append((nm,[open(A+f'{nm}_p{i}.frag').read() for i in (1,2,3)],ng))
for name,P,ng in nets:
    for gain in (1.0,2.0):
        a=run(img,P,P4,ng,False,gain); b=run(img,P,P4,ng,True,gain); d=np.abs(a-b)
        print(f'R={RNG:g} {name:13s} gain {gain}: max {d.max()}  mean {d.mean():.3f}  >2: {100*(d>2).mean():.2f}%  >4: {100*(d>4).mean():.3f}%',flush=True)
