"""Checks the noise map shader of "Aura sharp: strength follows the noise" (Shaders.NOISE_MAP) with Mesa: a synthetic picture (flat areas, edges, a gradient) with Gaussian noise of 0 .. 10
(of 255) per colour channel; the estimate is what the app does (the cells with at least 16 flat places, weighted by the flat places). Prints the true luma noise and the estimate.
Run: EGL_PLATFORM=surfaceless python3 tools/shader_test/aura_auto_check.py  (needs numpy, opencv)"""
import os,sys,numpy as np
os.environ['EGL_PLATFORM']='surfaceless'
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
import glrun
print(glrun.init())
V=glrun.shaders_from()[0]
kt=open(os.path.join(HERE,'..','..','app','src','main','java','app','clearoverlay','Shaders.kt')).read()
i=kt.index('const val NOISE_MAP = """')+len('const val NOISE_MAP = """'); FS=kt[i:kt.index('"""',i)]
P=glrun.compile_prog(V,FS)
def synth(W=640,H=360):
    y,x=np.mgrid[0:H,0:W]; im=np.zeros((H,W,3),np.float32)
    im[...]=0.55; im[:, :W//3]=(0.2,0.3,0.6); im[H//2:, W//3:2*W//3]=(0.85,0.8,0.7)
    im+= (0.15*np.sin(x/90.0))[...,None]*np.array([1,.8,.6],np.float32)           # smooth gradient
    for k in range(10): im[20+k*30:30+k*30, 400:600]=0.1+0.08*k                      # strong edges (bars)
    return np.clip(im,0,1)
rng=np.random.default_rng(5)
CW,CH=48,27
print('true luma sigma (of 255) -> estimate  | share of cells counted')
for sg in (0,1,2,3,4,6,8,10):
    base=synth(); im=np.clip(base+rng.normal(0,sg/255.,base.shape),0,1).astype(np.float32)
    q=(np.round(im*255)/255).astype(np.float32)   # the picture as 8-bit
    true=(q-base)@np.array([0.299,0.587,0.114],np.float32); true=float(true.std()*255)
    out=glrun.render(P,im,CW,CH,vec2={'uCells':(CW,CH)})
    r=out[...,0].astype(np.float32)/255.*16.; g=out[...,1].astype(np.float32)/255.
    use=g*64>=16
    est=float((r*g)[use].sum()/g[use].sum()) if use.any() else float('nan')
    print(f'{true:6.2f} -> {est:6.2f}    {100*use.mean():5.1f}% of cells')
