"""NIS fast (clean) at its lightest level against FSR 1 and SGSR 1 (the cost numbers of the app's load meter: FSR 1.0, SGSR 1.2, NIS fast levels 1.7 / 1.4 / 1.15, NIS mid 1.45 / 1.2 / 0.95).
Run: EGL_PLATFORM=surfaceless python3 tools/shader_test/light_vs_fsr.py"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from nis_clean_bench import *
from fsr_rcas_search import run_fsr2
PC2 = prog('clean2', nisfast_src(2, True)); PS2 = prog('fast2', nisfast_src(2)); PC1 = prog('clean1', nisfast_src(1, True))
def u(sl): return min(1.0, .15 + .7 * sl)
rows = {}
for sname, gt, small in SETS:
    G = np.array(gt); s = np.array(small); bh, bw, _ = s.shape; h, w, _ = G.shape
    rgba = np.full((bh, bw, 4), 255, np.uint8); rgba[..., :3] = s; base = Rt(bw, bh, rgba)
    mask = flat_mask(G); bil = np.array(small.resize((w, h), Image.BILINEAR))
    cases = {'FSR 1 (cost 1.0)': lambda: run_fsr2(base, w, h, bw, bh, 0.72, 0.0),
             'SGSR 1 (cost 1.2)': lambda: run_sgsr(base, w, h, bw, bh, 0.6),
             'NIS fast L2 standard (1.15)': lambda: run_nis(base, w, h, bw, bh, PS2, u(0.6)),
             'NIS fast L2 CLEAN s.60 (1.15)': lambda: run_nis(base, w, h, bw, bh, PC2, u(0.6)),
             'NIS fast L2 CLEAN s.90 (1.15)': lambda: run_nis(base, w, h, bw, bh, PC2, u(0.9)),
             'NIS fast L1 CLEAN s.90 (1.4)': lambda: run_nis(base, w, h, bw, bh, PC1, u(0.9))}
    for n, f in cases.items():
        o = f(); dg, da = detail_metrics(o, G)
        rows.setdefault(n, []).append(dict(psnr=psnr(G, o), ssim=ssim(G, o, channel_axis=2, data_range=255), halo=halo(o, bil), noise=flat_noise(o, mask), dg=dg, art=da, edge=gradm(o).mean()))
ref = {k: np.mean([r[k] for r in rows['FSR 1 (cost 1.0)']]) for k in ('dg', 'art', 'edge')}
print('mean of 4 sources; EDGE / DETAIL / ART = ratio to FSR 1')
for n, rs in rows.items():
    m = {k: np.mean([r[k] for r in rs]) for k in rs[0]}
    print(f'{n:32s} PSNR {m["psnr"]:5.2f} SSIM {m["ssim"]:.4f} halo {m["halo"]:5.2f} noise {m["noise"]:.2f} EDGE {m["edge"]/ref["edge"]:.3f} DETAIL {m["dg"]/ref["dg"]:.3f} ART {m["art"]/ref["art"]:.3f}')
print('per source SSIM / halo:')
for i, (sname, _, _) in enumerate(SETS):
    print(' ', sname, ' | '.join(f'{n.split(" (")[0][:22]} {rows[n][i]["ssim"]:.3f}/{rows[n][i]["halo"]:.1f}' for n in rows))
