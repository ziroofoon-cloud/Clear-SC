import sys, os, re, itertools
# usage: EGL_PLATFORM=surfaceless python3 gather_compare.py app/src/main/java/app/clearoverlay/Shaders.kt  (normal vs textureGather NIS fast / mid, must print max diff 0)
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, ctypes as C
os.environ['EGL_PLATFORM']='surfaceless'
import glrun
from glrun import gl
print(glrun.init())
KT=sys.argv[1]
s=open(KT).read()
def grab(name):
    k=f'const val {name} = """'; i=s.index(k)+len(k); j=s.index('"""',i); return s[i:j]
VERT=grab('VERT'); V310=VERT.replace('#version 300 es','#version 310 es')
LUMA=grab('NIS_LUMA'); FAST=grab('NIS_FAST'); FASTG=grab('NIS_FAST_G'); MID=grab('NIS_MID'); MIDG=grab('NIS_MID_G')
gl.glGetUniformLocation.argtypes=[C.c_uint,C.c_char_p]
gl.glUniform1f.argtypes=[C.c_int,C.c_float]; gl.glUniform2f.argtypes=[C.c_int,C.c_float,C.c_float]
gl.glGetString.restype=C.c_char_p
print(gl.glGetString(0x1F02))
def mkimg(kind,W,H,rng):
    if kind=='noise': return rng.random((H,W,3))
    if kind=='check': 
        y,x=np.mgrid[0:H,0:W]; return np.repeat((((x//2+y//2)%2)*0.9+0.05)[...,None],3,2)
    if kind=='stripes':
        y,x=np.mgrid[0:H,0:W]; return np.repeat((((x//3)%2)*0.8+0.1)[...,None],3,2)
    if kind=='grad':
        y,x=np.mgrid[0:H,0:W]; g=(x/max(W-1,1)*0.7+y/max(H-1,1)*0.3); return np.stack([g,g*0.8,1-g],2)
    if kind=='edges':
        y,x=np.mgrid[0:H,0:W]; d=((x*0.7+y*1.3)%17<8)*0.8+0.1; return np.stack([d,d*0.9,d*0.5],2)
    if kind=='flatnoise': return np.clip(0.5+rng.random((H,W,3))*0.015,0,1)
    if kind=='circle':
        y,x=np.mgrid[0:H,0:W]; d=(((x-W/2)**2+(y-H/2)**2)<(min(W,H)/3)**2)*0.8+0.1; return np.stack([d,d,d*0.7],2)
PC={}
def prog(key,vs,fs):
    if key not in PC: PC[key]=glrun.compile_prog(vs,fs)
    return PC[key]
def run(img,ow,oh,fastlv,sharp):
    H,W,_=img.shape
    rgba=np.ones((H,W,4),np.uint8)*255; rgba[...,:3]=(img*255+0.5).astype(np.uint8)
    tex=C.c_uint(); gl.glGenTextures(1,C.byref(tex)); gl.glBindTexture(0x0DE1,tex)
    gl.glTexImage2D(0x0DE1,0,0x1908,W,H,0,0x1908,0x1401,rgba.ctypes.data_as(C.c_void_p))
    for pn,v in ((0x2800,0x2601),(0x2801,0x2601),(0x2802,0x812F),(0x2803,0x812F)): gl.glTexParameteri(0x0DE1,pn,v)
    # luma
    lt=C.c_uint(); gl.glGenTextures(1,C.byref(lt)); gl.glBindTexture(0x0DE1,lt)
    gl.glTexImage2D(0x0DE1,0,0x822E,W,H,0,0x1903,0x1406,None)
    for pn,v in ((0x2800,0x2600),(0x2801,0x2600),(0x2802,0x812F),(0x2803,0x812F)): gl.glTexParameteri(0x0DE1,pn,v)
    lf=C.c_uint(); gl.glGenFramebuffers(1,C.byref(lf)); gl.glBindFramebuffer(0x8D40,lf)
    gl.glFramebufferTexture2D(0x8D40,0x8CE0,0x0DE1,lt,0)
    assert gl.glCheckFramebufferStatus(0x8D40)==0x8CD5,'luma fbo incomplete'
    pl=prog('luma',VERT,LUMA)
    gl.glViewport(0,0,W,H); gl.glUseProgram(pl); gl.glActiveTexture(0x84C0); gl.glBindTexture(0x0DE1,tex)
    gl.glUniform1i(gl.glGetUniformLocation(pl,b'uSrc'),0); gl.glDrawArrays(4,0,3)
    res={}
    for name,vs,fs in (('fast',VERT,FAST.replace('#define NF_LEVEL 0','#define NF_LEVEL %d'%fastlv)),('fastG',V310,FASTG.replace('#define NF_LEVEL 0','#define NF_LEVEL %d'%fastlv)),('mid',VERT,MID),('midG',V310,MIDG)):
        p=prog((name,fastlv),vs,fs)
        ot=C.c_uint(); gl.glGenTextures(1,C.byref(ot)); gl.glBindTexture(0x0DE1,ot)
        gl.glTexImage2D(0x0DE1,0,0x1908,ow,oh,0,0x1908,0x1401,None)
        fb=C.c_uint(); gl.glGenFramebuffers(1,C.byref(fb)); gl.glBindFramebuffer(0x8D40,fb)
        gl.glFramebufferTexture2D(0x8D40,0x8CE0,0x0DE1,ot,0)
        gl.glViewport(0,0,ow,oh); gl.glUseProgram(p)
        gl.glActiveTexture(0x84C0); gl.glBindTexture(0x0DE1,tex)
        gl.glActiveTexture(0x84C1); gl.glBindTexture(0x0DE1,lt)
        gl.glUniform1i(gl.glGetUniformLocation(p,b'uSrc'),0)
        loc=gl.glGetUniformLocation(p,b'uLuma')
        if loc>=0: gl.glUniform1i(loc,1)
        gl.glUniform2i(gl.glGetUniformLocation(p,b'uSrcSize'),W,H)
        gl.glUniform2f(gl.glGetUniformLocation(p,b'uScale'),W/ow,H/oh)
        gl.glUniform1f(gl.glGetUniformLocation(p,b'uSharp'),sharp)
        gl.glDrawArrays(4,0,3); gl.glPixelStorei(0x0D05,1)
        out=np.zeros((oh,ow,4),np.uint8); gl.glReadPixels(0,0,ow,oh,0x1908,0x1401,out.ctypes.data_as(C.c_void_p))
        res[name]=out[...,:3].astype(int)
        gl.glActiveTexture(0x84C0)
        gl.glDeleteFramebuffers(1,C.byref(fb)); gl.glDeleteTextures(1,C.byref(ot))
    gl.glDeleteFramebuffers(1,C.byref(lf)); gl.glDeleteTextures(1,C.byref(lt)); gl.glDeleteTextures(1,C.byref(tex))
    return res
rng=np.random.default_rng(5)
sizes=[(1,1),(2,2),(1,7),(7,1),(3,5),(5,3),(9,7),(37,23),(64,48),(160,90),(333,5)]
kinds=['noise','check','stripes','grad','edges','flatnoise','circle']
tot=0;bad=0;maxd=0
for (W,H) in sizes:
  for kind in kinds:
    img=mkimg(kind,W,H,rng)
    for sc in (0.75,1.0,1.5,2.0,3.3,4.0):
      ow=max(1,int(round(W*sc)));oh=max(1,int(round(H*sc)))
      if ow*oh>200000: continue
      for lv in (0,1,2):
        for sh in (0.0,0.5,1.0) if (lv==0 and sc in (1.5,3.3)) else (0.7,):
          r=run(img,ow,oh,lv,sh)
          d1=np.abs(r['fast']-r['fastG']); d2=np.abs(r['mid']-r['midG']) if lv==0 else np.zeros(1)
          tot+=1; m=max(d1.max(),d2.max()); maxd=max(maxd,m)
          if m>0:
              bad+=1; print('DIFF',W,H,kind,sc,lv,sh,'fast',d1.max(),(d1>0).sum(),'mid',d2.max())
print('cases',tot,'with differences',bad,'max diff',maxd)
