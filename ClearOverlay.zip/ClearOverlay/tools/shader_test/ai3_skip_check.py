"""Checks AI 3x 'skip flat areas' and 'skip unchanged areas' with the real shaders in software OpenGL ES 3.2 (Mesa): the patched shaders (mirror of Ai3Shaders.flatPatch + Ai3Shaders.FLAT read from the .kt)
compile for all 7 levels. Part 1 prints how the flat-skip output differs from the normal one. Part 2 (frame 1, then frame 2 with a changed block, then frame 2 again) must print maxdiff 0 for 'skip unchanged areas'.
Run: EGL_PLATFORM=surfaceless python3 tools/shader_test/ai3_skip_check.py  (needs numpy, scikit-image, opencv)"""
import sys,re,os,ctypes as C,numpy as np
os.environ['EGL_PLATFORM']='surfaceless'
HERE=os.path.dirname(os.path.abspath(__file__)); T=os.path.join(HERE,'..','..')+os.sep
sys.path.insert(0,HERE); sys.path.insert(0,os.path.join(HERE,'..'))
import glrun; from glrun import gl
import fp16_check_ai3 as F
class S:
    F=F
    @staticmethod
    def imgs():
        import skimage.data as d,cv2
        L=[]
        for n in ('rocket','page'):
            im=getattr(d,n)()
            if im.ndim==2: im=np.stack([im]*3,-1)
            L.append((n,cv2.resize(im,(int(im.shape[1]/3),int(im.shape[0]/3)),interpolation=cv2.INTER_AREA)[:96,:128].astype(np.float32)/255.))
        s=np.full((96,128,3),235,np.uint8); cv2.rectangle(s,(10,10),(60,50),(50,100,200),-1); cv2.circle(s,(95,55),25,(230,75,75),-1); s[70:,:]=13
        s=s.astype(np.float32)/255.; L.append(('synth',s))
        rng=np.random.default_rng(1); L.append(('synth+noise1',np.clip(s+rng.normal(0,1/255,s.shape),0,1).astype(np.float32)))
        return L
print(glrun.init())
VERT=glrun.shaders_from()[0]
kt=open(T+'app/src/main/java/app/clearoverlay/Ai3Shaders.kt').read()
FLAT=kt[kt.index('const val FLAT = """')+len('const val FLAT = """'):]; FLAT=FLAT[:FLAT.index('"""')]
FILE=S.F.FILE; SIZES=S.F.SIZES; plan=S.F.plan
A=T+'app/src/main/assets/ai3/'
def passes(t): return len(plan(t))+1
def patch(t,k,src):   # mirror of Ai3Shaders.flatPatch
    if k<2: return src
    L=len(plan(t)); s=src.replace('precision highp sampler2D;','precision highp sampler2D;\nuniform sampler2D uFlat;',1)
    if k<passes(t):
        m='ivec2 p = ivec2(gl_FragCoord.xy);'; outs=len(re.findall(r'layout\(location=\d+\) out',s))
        z=' '.join(f'o{i} = vec4(0.0);' for i in range(outs))
        return s.replace(m,m+f'\n  if (texelFetch(uFlat, p, 0)[{L-k}] > 0.5) {{ {z} return; }}',1)
    m='switch (k) {'; assert m in s
    return s.replace(m,'float fv = texelFetch(uFlat, q, 0).r;\n  if (fv > 0.9) discard;\n  if (fv < 0.5) '+m,1)
gl.glGetUniformLocation.argtypes=[C.c_uint,C.c_char_p]
gl.glUniform1i.argtypes=[C.c_int,C.c_int]; gl.glUniform1f.argtypes=[C.c_int,C.c_float]
def tex(w,h,fmt,typ,intf,data=None):
    t=C.c_uint(); gl.glGenTextures(1,C.byref(t)); gl.glBindTexture(0x0DE1,t)
    gl.glTexImage2D(0x0DE1,0,intf,w,h,0,fmt,typ,data)
    for pn,v in ((0x2800,0x2600),(0x2801,0x2600),(0x2802,0x812F),(0x2803,0x812F)): gl.glTexParameteri(0x0DE1,pn,v)
    return t.value
def mrt(n,w,h):
    ts=[tex(w,h,0x1908,0x140B,0x881A) for _ in range(n)]
    fb=C.c_uint(); gl.glGenFramebuffers(1,C.byref(fb)); gl.glBindFramebuffer(0x8D40,fb)
    for i,t in enumerate(ts): gl.glFramebufferTexture2D(0x8D40,0x8CE0+i,0x0DE1,t,0)
    gl.glDrawBuffers(n,(C.c_uint*n)(*[0x8CE0+i for i in range(n)]))
    assert gl.glCheckFramebufferStatus(0x8D40)==0x8CD5
    return ts,fb.value
cache={}
def progs(t,skip):
    k=(t,skip)
    if k not in cache:
        cache[k]=[glrun.compile_prog(VERT,(patch(t,p,open(f'{A}{FILE[t]}_p{p}.frag').read()) if skip else open(f'{A}{FILE[t]}_p{p}.frag').read())) for p in range(1,passes(t)+1)]
    return cache[k]
def run(t,img,skip,thr=3.0,gain=1.0,state=None):
    H,W=img.shape[:2]; ps=progs(t,skip)
    rgba=np.full((H,W,4),255,np.uint8); rgba[...,:3]=(img*255+0.5).astype(np.uint8)
    src=tex(W,H,0x1908,0x1401,0x1908,rgba.ctypes.data_as(C.c_void_p))
    bufs=[mrt(n,W,H) if n else None for n in SIZES[t]]
    L=len(plan(t)); flat=None
    if skip:
        flat=tex(W,H,0x1908,0x1401,0x1908); fb=C.c_uint(); gl.glGenFramebuffers(1,C.byref(fb)); gl.glBindFramebuffer(0x8D40,fb); gl.glFramebufferTexture2D(0x8D40,0x8CE0,0x0DE1,flat,0)
        gl.glDrawBuffers(1,(C.c_uint*1)(0x8CE0)); gl.glViewport(0,0,W,H)
        fp=glrun.compile_prog(VERT,FLAT); gl.glUseProgram(fp); gl.glActiveTexture(0x84C0); gl.glBindTexture(0x0DE1,src)
        use_prev = state is not None and state.get('valid',False)
        gl.glActiveTexture(0x84C1); gl.glBindTexture(0x0DE1,state['prev'] if use_prev else src); gl.glUniform1i(gl.glGetUniformLocation(fp,b'uPrev'),1); gl.glUniform1i(gl.glGetUniformLocation(fp,b'uSame'),1 if use_prev else 0)
        gl.glActiveTexture(0x84C0)
        gl.glUniform1i(gl.glGetUniformLocation(fp,b'uIn'),0); gl.glUniform1i(gl.glGetUniformLocation(fp,b'uR'),L); gl.glUniform1i(gl.glGetUniformLocation(fp,b'uE'),max(L-2,0)); gl.glUniform1f(gl.glGetUniformLocation(fp,b'uThr'),(thr+0.25)/255 if thr is not None else -1.0)
        gl.glDrawArrays(4,0,3)
    def bind(pr,unit_list):
        u=0
        for ti in unit_list:
            gl.glActiveTexture(0x84C0+u); gl.glBindTexture(0x0DE1,ti); gl.glUniform1i(gl.glGetUniformLocation(pr,f'uT{u}'.encode()),u); u+=1
        return u
    for k,pl in enumerate(plan(t)):
        pr=ps[k]; ob=bufs[pl[0]]; pin=pl[1]; gl.glBindFramebuffer(0x8D40,ob[1]); gl.glViewport(0,0,W,H); gl.glUseProgram(pr)
        ins=[]
        for i in pin: ins+= [src] if i<0 else bufs[i][0]
        u=bind(pr,ins)
        if skip and k>=1: gl.glActiveTexture(0x84C0+u); gl.glBindTexture(0x0DE1,flat); gl.glUniform1i(gl.glGetUniformLocation(pr,b'uFlat'),u)
        gl.glDrawArrays(4,0,3)
    pf=ps[-1]; ot=state['ot'] if (state is not None and state.get('ot')) else tex(3*W,3*H,0x1908,0x1401,0x1908)
    if state is not None: state['ot']=ot
    fb=C.c_uint(); gl.glGenFramebuffers(1,C.byref(fb)); gl.glBindFramebuffer(0x8D40,fb); gl.glFramebufferTexture2D(0x8D40,0x8CE0,0x0DE1,ot,0); gl.glDrawBuffers(1,(C.c_uint*1)(0x8CE0))
    gl.glViewport(0,0,3*W,3*H); gl.glUseProgram(pf)
    ins=[]
    for i in ((2,) if t==0 else (2,3)): ins+=bufs[i][0]
    u=bind(pf,ins); gl.glActiveTexture(0x84C0+u); gl.glBindTexture(0x0DE1,src); gl.glUniform1i(gl.glGetUniformLocation(pf,b'uIn'),u)
    if skip: gl.glActiveTexture(0x84C0+u+1); gl.glBindTexture(0x0DE1,flat); gl.glUniform1i(gl.glGetUniformLocation(pf,b'uFlat'),u+1)
    gl.glUniform1f(gl.glGetUniformLocation(pf,b'uGain'),gain); gl.glDrawArrays(4,0,3)
    out=np.zeros((3*H,3*W,4),np.uint8); gl.glReadPixels(0,0,3*W,3*H,0x1908,0x1401,out.ctypes.data_as(C.c_void_p))
    if state is not None:
        state['prev']=tex(W,H,0x1908,0x1401,0x1908,rgba.ctypes.data_as(C.c_void_p)); state['valid']=True
    fl=None
    if skip:
        gl.glBindFramebuffer(0x8D40,0); 
    return out[...,:3].astype(int)
def part2():
    for t in range(7):
        for name,f1 in S.imgs():
            f2=f1.copy(); f2[20:44,30:70]=np.clip(f2[20:44,30:70]*0.7+0.2,0,1); f1=f1.copy(); f1[60:80,5:30]=np.roll(f1[60:80,5:30],3,axis=1)
            for gain in (1.0,2.4):
                st={}; run(t,f1,True,thr=None,gain=gain,state=st); b=run(t,f2,True,thr=None,gain=gain,state=st); c=run(t,f2,True,thr=None,gain=gain,state=st); ref=run(t,f2,False,gain=gain)
                print(f'skip unchanged: level {t} {name:13s} gain {gain}: frame 2 maxdiff {np.abs(b-ref).max()}, repeated frame maxdiff {np.abs(c-ref).max()}',flush=True)
if __name__=='__main__':
    ims=dict(S.imgs())
    for t in range(7):
        for name in ('rocket','synth','synth+noise1','page'):
            im=ims[name]; a=run(t,im,False); 
            for thr in (1.5,3.0,6.0):
                b=run(t,im,True,thr); d=np.abs(a-b)
                print(f'tier {t} {name:13s} thr {thr}: maxdiff {d.max():2d}  pixels differing {100*(d.max(-1)>0).mean():5.2f}%  (>1: {100*(d.max(-1)>1).mean():5.2f}%)',flush=True)
        if t==2: pass
    part2()
