"""Offline tests (software OpenGL ES 3.2, run with EGL_PLATFORM=surfaceless): chain.py = CRSC Edge Original / Light / Lightest on a real picture (PSNR), aura.py = Aura NIS vs NIS_L, clean.py = Clean upscale vs ground truth (PSNR / SSIM). Needs numpy, pillow, matplotlib, scikit-image."""
import sys, os, re, ctypes as C, numpy as np
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
os.environ['EGL_PLATFORM']='surfaceless'
import glrun
from glrun import gl, compile_prog
from PIL import Image
import matplotlib
print(glrun.init())
KT=os.path.join(HERE,'..','..','app','src','main','java','app','clearoverlay','Shaders.kt')
S=open(KT).read()
def grab(n):
    k=f'const val {n} = """'; i=S.index(k)+len(k); return S[i:S.index('"""',i)]
VERT=grab('VERT')
progs={n:compile_prog(VERT,grab(n)) for n in ['EASU','EDGE_REFINE','CRSC_SHARP','CRSC_DOWN','CRSC_BP','CRSC_BP_L','EDGE_SHOCK']}
gl.glGetUniformLocation.argtypes=[C.c_uint,C.c_char_p]
gl.glUniform1f.argtypes=[C.c_int,C.c_float]; gl.glUniform2f.argtypes=[C.c_int,C.c_float,C.c_float]
gl.glUniform4f.argtypes=[C.c_int,C.c_float,C.c_float,C.c_float,C.c_float]
gl.glUniform1i.argtypes=[C.c_int,C.c_int]; gl.glUniform2i.argtypes=[C.c_int,C.c_int,C.c_int]
class Rt:
    def __init__(s,w,h,data=None):
        s.w,s.h=w,h; s.tex=C.c_uint(); gl.glGenTextures(1,C.byref(s.tex)); gl.glBindTexture(0x0DE1,s.tex)
        gl.glTexImage2D(0x0DE1,0,0x1908,w,h,0,0x1908,0x1401,None if data is None else data.ctypes.data_as(C.c_void_p))
        for pn,v in ((0x2800,0x2601),(0x2801,0x2601),(0x2802,0x812F),(0x2803,0x812F)): gl.glTexParameteri(0x0DE1,pn,v)
        s.fb=C.c_uint(); gl.glGenFramebuffers(1,C.byref(s.fb)); gl.glBindFramebuffer(0x8D40,s.fb); gl.glFramebufferTexture2D(0x8D40,0x8CE0,0x0DE1,s.tex,0)
    def read(s):
        gl.glBindFramebuffer(0x8D40,s.fb); o=np.zeros((s.h,s.w,4),np.uint8); gl.glPixelStorei(0x0D05,1)
        gl.glReadPixels(0,0,s.w,s.h,0x1908,0x1401,o.ctypes.data_as(C.c_void_p)); return o
def run(p,dst,texs,ints={},f1={},f2={},f4={},i2={}):
    gl.glBindFramebuffer(0x8D40,dst.fb); gl.glViewport(0,0,dst.w,dst.h); gl.glUseProgram(p)
    for u,t in enumerate(texs):
        gl.glActiveTexture(0x84C0+u); gl.glBindTexture(0x0DE1,t.tex)
    L=lambda n: gl.glGetUniformLocation(p,n.encode())
    for n,u in zip(['uSrc','uLow','uD'],range(3)):
        if L(n)>=0: gl.glUniform1i(L(n),u)
    for n,v in f1.items():
        if L(n)>=0: gl.glUniform1f(L(n),v)
    for n,v in f2.items():
        if L(n)>=0: gl.glUniform2f(L(n),*v)
    for n,v in f4.items():
        if L(n)>=0: gl.glUniform4f(L(n),*v)
    for n,v in i2.items():
        if L(n)>=0: gl.glUniform2i(L(n),*v)
    gl.glDrawArrays(4,0,3)
CR=[1,1,1,1,1,3]; BOOST=[0,2,3,4,5,5]; OVER=[0,.03,.04,.05,.06,.06]; RAD=[1,1,1.15,1.25,1.33,1.33]; SHOCK=[0,1.4,1.8,2.2,2.6,2.6]
def frame(img,scale,lv,mode,sk=0.5):
    """mode: 'orig' (BP original), 'light' (BP_L), 'lightest' (BP_L, skip x4, max 2 rounds)"""
    bh,bw,_=img.shape; w,h=int(bw*scale),int(bh*scale)
    rgba=np.full((bh,bw,4),255,np.uint8); rgba[...,:3]=img
    base=Rt(bw,bh,rgba); t1=Rt(w,h); t2=Rt(w,h); d=Rt(bw,bh)
    iw,ih,ox,oy=float(bw),float(bh),float(w),float(h)
    run(progs['EASU'],t1,[base],f1={'uSharpness':0},i2={'uSrcSize':(bw,bh)},
        f4={'uCon0':(iw/ox,ih/oy,.5*iw/ox-.5,.5*ih/oy-.5),'uCon1':(1/iw,1/ih,1/iw,-1/ih),'uCon2':(-1/iw,2/ih,1/iw,2/ih),'uCon3':(0,4/ih,0,0)})
    cur=t1; other=t2
    exact=(lv==5); lite=(mode=='lightest'); km=4 if lite else 1
    rounds=CR[lv]; 
    if lite and rounds>2: rounds=2
    bp=progs['CRSC_BP'] if mode=='orig' else progs['CRSC_BP_L']
    for _ in range(rounds):
        run(progs['CRSC_DOWN'],d,[cur],f2={'uInv':(1/bw,1/bh)})
        run(bp,other,[cur,base,d],f2={'uInv':(1/bw,1/bh)},f1={'uG':1.3 if lv==5 else .9})
        cur,other=other,cur
    ratio=min(max(w/bw,1),4)
    run(progs['EDGE_REFINE'],other,[cur],f2={'uInv':(1/w,1/h)},i2={'uSize':(w,h)},f1={'uR':min(max(.67*ratio,1),2.5),'uSkipR':0 if exact else .08*km}); cur,other=other,cur
    if lv>0:
        run(progs['CRSC_SHARP'],other,[cur],f2={'uInv':(1/w,1/h)},f1={'uR':min(max(.5*ratio*RAD[lv],1),2),'uAmt':BOOST[lv]*(.3+sk),'uOver':OVER[lv],'uSkip':0 if exact else .0625*km}); cur,other=other,cur
        run(progs['EDGE_SHOCK'],other,[cur],f2={'uInv':(1/w,1/h)},i2={'uSize':(w,h)},f1={'uR':ratio,'uSkip':0 if exact else .1*km,'uAmt':(.1+.2*sk)*SHOCK[lv]}); cur,other=other,cur
    return cur.read()[...,:3]
def psnr(a,b):
    m=((a.astype(float)-b.astype(float))**2).mean(); return 99.0 if m==0 else 10*np.log10(255**2/m)
if __name__=='__main__':
    import glob
    img=np.array(Image.open(os.path.join(matplotlib.get_data_path(),'sample_data','grace_hopper.jpg')).convert('RGB'))
    # video-like frame: 640x360 crop/resize
    im=Image.fromarray(img).resize((640,360),Image.LANCZOS); v=np.array(im)
    for name,arr,sc in (('video640x360 x2',v,2.0),('photo 256x300 x3',np.array(Image.fromarray(img).resize((256,300),Image.LANCZOS)),3.0)):
        print('==',name)
        for lv in range(6):
            o=frame(arr,sc,lv,'orig'); l=frame(arr,sc,lv,'light'); t=frame(arr,sc,lv,'lightest')
            d1=np.abs(o.astype(int)-l.astype(int)); d2=np.abs(l.astype(int)-t.astype(int)); d3=np.abs(o.astype(int)-t.astype(int))
            print(f'lv{lv}: Orig-vs-Light PSNR {psnr(o,l):5.1f} max {d1.max():3d} | Light-vs-Lightest PSNR {psnr(l,t):5.1f} max {d2.max():3d} px>8: {(d2.max(axis=2)>8).mean()*100:.3f}% | Orig-vs-Lightest PSNR {psnr(o,t):5.1f} max {d3.max()}')
        if lv==5:
            Image.fromarray(np.hstack([o,t])).save('/tmp/claude-0/n/exp2/lv5_%s.png'%name.split()[0])
