"""CRSC Edge Light / Lightest use the "constant offsets" passes (EDGE_REFINE_C, EDGE_SHOCK_C, CRSC_BP_C). This checks that they give exactly the picture of the
older text (EDGE_REFINE, EDGE_SHOCK, CRSC_BP_L) on real pictures at every level, and times the passes in the software renderer (a CPU: only a rough picture).
Run:  EGL_PLATFORM=surfaceless python3 tools/shader_test/exact_check.py"""
import sys, os, time
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); os.environ['EGL_PLATFORM'] = 'surfaceless'
import numpy as np
import chain
from chain import progs, grab, VERT, psnr, gl
from glrun import compile_prog
from PIL import Image
import skip_study
old = dict(progs)
new = dict(progs)
for k, v in {'EDGE_REFINE': 'EDGE_REFINE_C', 'EDGE_SHOCK': 'EDGE_SHOCK_C', 'CRSC_BP_L': 'CRSC_BP_C'}.items():
    new[k] = compile_prog(VERT, grab(v))
worst = 99.0
for name, (im, sc) in skip_study.pictures().items():
    for lv in range(0, 6):
        progs.update(old); a = chain.frame(im, sc, lv, 'light')
        progs.update(new); b = chain.frame(im, sc, lv, 'light')
        d = int(np.abs(a.astype(int) - b.astype(int)).max())
        worst = min(worst, psnr(a, b))
        print(f'{name:26s} lv{lv}: {psnr(a, b):5.1f} dB  largest difference {d}')
print('worst PSNR', worst)
