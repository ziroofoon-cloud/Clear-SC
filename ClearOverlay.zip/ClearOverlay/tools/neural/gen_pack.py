# bin (weights from train.py) -> .nsr pack: the GLSL ES 3.0 shaders of the tiny net, weights inlined as constants.
# usage: python3 gen_pack.py model.bin out.nsr
import numpy as np, struct, sys
def read_bin(path):
    d=open(path,'rb').read(); assert d[:4]==b'NSR1'
    scale,nl,_=struct.unpack('<iii',d[4:16]); o=16; layers=[]
    for _ in range(nl):
        cin,cout=struct.unpack('<ii',d[o:o+8]); o+=8
        w=np.frombuffer(d,'<f4',cin*9*cout,o).reshape(cin*9,cout).copy(); o+=cin*9*cout*4
        b=np.frombuffer(d,'<f4',cout,o).copy(); o+=cout*4
        layers.append((cin,cout,w,b))
    return scale,layers
def F(x): return '%.6e'%float(x)
# tap t = dy*3+dx of the training code is (row offset dy-1, column offset dx-1) in a picture whose rows go DOWN;
# the render targets of the app are y-UP, so the GL offset of tap t is (dx-1, 1-dy)
OFF=[(dx-1,1-dy) for dy in range(3) for dx in range(3)]
HEAD='#version 300 es\nprecision mediump float;\n'
def outs(n): return ''.join('layout(location=%d) out vec4 o%d;\n'%(k,k) for k in range(n))
def vec4(a): return 'vec4(%s)'%','.join(F(x) for x in a)
def l1_src(w,b):
    cout=w.shape[1]; N=cout//4; s=HEAD+'uniform sampler2D uSrc;\n'+outs(N)
    s+='const vec4 W[%d] = vec4[%d](\n'%(N*9,N*9)+',\n'.join(vec4(w[t,4*k:4*k+4]) for k in range(N) for t in range(9))+');\n'
    s+='const vec4 B[%d] = vec4[%d](%s);\n'%(N,N,','.join(vec4(b[4*k:4*k+4]) for k in range(N)))
    s+='float Y(ivec2 p, ivec2 sz) { return dot(texelFetch(uSrc, clamp(p, ivec2(0), sz - 1), 0).rgb, vec3(0.299, 0.587, 0.114)); }\nvoid main() {\n    ivec2 p = ivec2(gl_FragCoord.xy);\n    ivec2 sz = textureSize(uSrc, 0);\n'
    for t,(ox,oy) in enumerate(OFF): s+='    float y%d = Y(p + ivec2(%d, %d), sz);\n'%(t,ox,oy)
    for k in range(N):
        s+='    o%d = max(B[%d]'%(k,k)+''.join(' + W[%d] * y%d'%(k*9+t,t) for t in range(9))+', 0.0);\n'
    return s+'}\n'
def hid_src(w,b,relu):
    cin,cout=w.shape[0]//9,w.shape[1]; Ni=cin//4; No=cout//4
    s=HEAD+''.join('uniform sampler2D uF%d;\n'%j for j in range(Ni))+outs(No)
    mats=[]
    for k in range(No):
        for t in range(9):
            for j in range(Ni):
                cols=[w[(4*j+bb)*9+t,4*k:4*k+4] for bb in range(4)]  # column bb = the 4 outputs of input channel 4j+bb
                mats.append('mat4('+','.join(F(x) for c in cols for x in c)+')')
    s+='const mat4 W[%d] = mat4[%d](\n'%(len(mats),len(mats))+',\n'.join(mats)+');\n'
    s+='const vec4 B[%d] = vec4[%d](%s);\n'%(No,No,','.join(vec4(b[4*k:4*k+4]) for k in range(No)))
    s+='void main() {\n    ivec2 p = ivec2(gl_FragCoord.xy);\n    ivec2 sz = textureSize(uF0, 0);\n'
    for k in range(No): s+='    vec4 a%d = B[%d];\n'%(k,k)
    for t,(ox,oy) in enumerate(OFF):
        s+='    ivec2 q%d = clamp(p + ivec2(%d, %d), ivec2(0), sz - 1);\n'%(t,ox,oy)
        for j in range(Ni): s+='    vec4 v%d_%d = texelFetch(uF%d, q%d, 0);\n'%(t,j,j,t)
        for k in range(No):
            for j in range(Ni): s+='    a%d += W[%d] * v%d_%d;\n'%(k,(k*9+t)*Ni+j,t,j)
    for k in range(No): s+='    o%d = %s;\n'%(k,'max(a%d, 0.0)'%k if relu else 'a%d'%k)
    return s+'}\n'
COMPOSE='''#version 300 es
precision highp float;
uniform sampler2D uBase;
uniform sampler2D uHead;
in highp vec2 vUv;
out vec4 outColor;
void main() {
    ivec2 o = ivec2(gl_FragCoord.xy);
    // depth to space: the picture's rows go down in the training data, the targets here go up
    int idx = ((1 - (o.y & 1)) << 1) + (o.x & 1);
    float r = texelFetch(uHead, o >> 1, 0)[idx];
    vec3 b = texture(uBase, vUv).rgb;
    outColor = vec4(clamp(b + vec3(r), 0.0, 1.0), 1.0);
}
'''
def build(path_in,path_out):
    scale,layers=read_bin(path_in); assert scale==2 and layers[0][0]==1 and layers[-1][1]==4
    C=layers[0][1]; assert C%4==0
    parts=[('l1',l1_src(layers[0][2],layers[0][3]))]
    for i,(ci,co,w,b) in enumerate(layers[1:-1],1): parts.append(('hid%d'%i,hid_src(w,b,True)))
    ci,co,w,b=layers[-1]; parts.append(('head',hid_src(w,b,False))); parts.append(('compose',COMPOSE))
    with open(path_out,'w') as f:
        f.write('NSR2\nscale 2\nchannels %d\nlayers %d\n'%(C,len(layers)))
        for n,s in parts: f.write('@%s\n%s'%(n,s))
        f.write('@end\n')
    return C,len(layers)
if __name__=='__main__': print(build(sys.argv[1],sys.argv[2]))
