# Tiny luma super-resolution net (x2) for the +CRSC live "Neural" upscaler.
# conv3x3(1->C) relu, conv3x3(C->C) relu x (L-2), conv3x3(C->4) -> depth-to-space -> residual added to the bilinear enlargement.
# Edge padding everywhere (the shader clamps coordinates the same way).
import numpy as np, cv2, time, sys, struct
from skimage import data
C=int(sys.argv[1]); L=int(sys.argv[2]); STEPS=int(sys.argv[3]); OUT=sys.argv[4]; SEED=int(sys.argv[5]) if len(sys.argv)>5 else 0
rs=np.random.RandomState(SEED)
def luma(im):
    im=np.asarray(im)
    if im.ndim==2: return im.astype(np.float32)/255
    return (0.299*im[...,0]+0.587*im[...,1]+0.114*im[...,2]).astype(np.float32)/255
def load(names):
    out=[]
    for n in names:
        try: y=luma(getattr(data,n)())
        except Exception: continue
        if min(y.shape)>=128: out.append(y)
    return out
hold=load(['astronaut','camera'])
train=load(['coffee','chelsea','rocket','motorcycle_left','eagle','retina','coins','moon','grass','gravel','brick'])
print('train',len(train),'hold',len(hold),flush=True)
def degrade(lr):
    if rs.rand()<0.4:
        q=int(rs.randint(55,96)); ok,b=cv2.imencode('.jpg',(np.clip(lr,0,1)*255).astype(np.uint8),[cv2.IMWRITE_JPEG_QUALITY,q]); lr=cv2.imdecode(b,0).astype(np.float32)/255
    if rs.rand()<0.3: lr=np.clip(lr+rs.randn(*lr.shape).astype(np.float32)*rs.uniform(0.002,0.012),0,1)
    return lr
def patches(B,P=24):
    X=np.empty((B,P,P,1),np.float32); T=np.empty((B,2*P,2*P),np.float32)
    for i in range(B):
        y=train[rs.randint(len(train))]; h,w=y.shape
        yy=rs.randint(0,(h-2*P)//2)*2; xx=rs.randint(0,(w-2*P)//2)*2
        c=y[yy:yy+2*P,xx:xx+2*P]
        if rs.rand()<.5: c=c[:,::-1]
        if rs.rand()<.5: c=c[::-1]
        c=np.ascontiguousarray(c)
        m=[cv2.INTER_AREA,cv2.INTER_LINEAR,cv2.INTER_CUBIC][rs.randint(3)] if rs.rand()<.5 else cv2.INTER_AREA
        lr=cv2.resize(c,(P,P),interpolation=m)
        lr=degrade(lr)
        bil=cv2.resize(lr,(2*P,2*P),interpolation=cv2.INTER_LINEAR)
        X[i,:,:,0]=lr; T[i]=c-bil
    return X,T
shapes=[(1,C)]+[(C,C)]*(L-2)+[(C,4)]
Wt=[];Bt=[]
for ci,co in shapes:
    Wt.append((rs.randn(ci*9,co)*np.sqrt(2/(ci*9))).astype(np.float32)); Bt.append(np.zeros(co,np.float32))
Wt[-1]*=0.1
print('params',sum(w.size+b.size for w,b in zip(Wt,Bt)),flush=True)
def im2col(x):
    B,H,W,Ci=x.shape; p=np.pad(x,((0,0),(1,1),(1,1),(0,0)),mode='edge')
    cols=np.stack([p[:,dy:dy+H,dx:dx+W,:] for dy in range(3) for dx in range(3)],-1)
    return cols.reshape(B*H*W,Ci*9)
def fwd(x):
    acts=[x];cols=[]
    for i,(w,b) in enumerate(zip(Wt,Bt)):
        c=im2col(acts[-1]); cols.append(c)
        B,H,W,_=acts[-1].shape
        y=(c@w+b).reshape(B,H,W,-1)
        if i<len(Wt)-1: y=np.maximum(y,0)
        acts.append(y)
    return acts,cols
def d2s(y):
    B,H,W,_=y.shape
    return y.reshape(B,H,W,2,2).transpose(0,1,3,2,4).reshape(B,2*H,2*W)
def d2s_back(g):
    B,H2,W2=g.shape;H=H2//2;W=W2//2
    return g.reshape(B,H,2,W,2).transpose(0,1,3,2,4).reshape(B,H,W,4)
def col2im(dc,shape):
    B,H,W,Ci=shape
    dc=dc.reshape(B,H,W,Ci,9); dp=np.zeros((B,H+2,W+2,Ci),np.float32); k=0
    for dy in range(3):
        for dx in range(3):
            dp[:,dy:dy+H,dx:dx+W,:]+=dc[...,k]; k+=1
    # edge padding: what fell on the padding belongs to the border pixel it copies
    dp[:,1,:,:]+=dp[:,0,:,:]; dp[:,H,:,:]+=dp[:,H+1,:,:]
    dp[:,:,1,:]+=dp[:,:,0,:]; dp[:,:,W,:]+=dp[:,:,W+1,:]
    return dp[:,1:-1,1:-1,:]
m=[np.zeros_like(w) for w in Wt]+[np.zeros_like(b) for b in Bt]; v=[np.zeros_like(w) for w in Wt]+[np.zeros_like(b) for b in Bt]
def adam(params,grads,t,lr):
    for i,(p,g) in enumerate(zip(params,grads)):
        m[i]=.9*m[i]+.1*g; v[i]=.999*v[i]+.001*g*g
        p-=lr*(m[i]/(1-.9**t))/(np.sqrt(v[i]/(1-.999**t))+1e-8)
def predict(lr):
    acts,_=fwd(lr[None,:,:,None]); return d2s(acts[-1])[0]
def evaluate():
    r={'bil':[],'cub':[],'net':[],'bil_jpg':[],'net_jpg':[]}
    for y in hold:
        h,w=y.shape; h-=h%2; w-=w%2; y=y[:h,:w]
        lr=cv2.resize(y,(w//2,h//2),interpolation=cv2.INTER_AREA)
        for tag,l in (('',lr),('_jpg',cv2.imdecode(cv2.imencode('.jpg',(lr*255).astype(np.uint8),[cv2.IMWRITE_JPEG_QUALITY,75])[1],0).astype(np.float32)/255)):
            bil=cv2.resize(l,(w,h),interpolation=cv2.INTER_LINEAR)
            ps=lambda a:10*np.log10(1/np.mean((np.clip(a,0,1)-y)**2))
            r['bil'+tag].append(ps(bil)); r['net'+tag].append(ps(bil+predict(l)))
            if tag=='': r['cub'].append(ps(cv2.resize(l,(w,h),interpolation=cv2.INTER_CUBIC)))
    return {k:round(float(np.mean(x)),2) for k,x in r.items() if x}
def save(path):
    with open(path,'wb') as f:
        f.write(b'NSR1'); f.write(struct.pack('<iii',2,len(Wt),0))
        for w,b in zip(Wt,Bt):
            f.write(struct.pack('<ii',w.shape[0]//9,w.shape[1])); f.write(w.astype('<f4').tobytes()); f.write(b.astype('<f4').tobytes())
t0=time.time()
for t in range(1,STEPS+1):
    X,T=patches(32)
    acts,cols=fwd(X); pred=d2s(acts[-1]); diff=pred-T; loss=np.mean(diff**2)
    g=d2s_back(2*diff/diff.size); gw=[None]*len(Wt); gb=[None]*len(Bt)
    for i in reversed(range(len(Wt))):
        if i<len(Wt)-1: g=g*(acts[i+1]>0)
        gf=g.reshape(-1,g.shape[-1]); gw[i]=cols[i].T@gf; gb[i]=gf.sum(0)
        if i>0: g=col2im(gf@Wt[i].T,acts[i].shape)
    adam(Wt+Bt,gw+gb,t,2e-3*(0.5*(1+np.cos(np.pi*t/STEPS))*0.95+0.05))
    if t%1000==0 or t==STEPS: print(t,'loss',round(float(loss),7),evaluate(),'%.0fs'%(time.time()-t0),flush=True)
    if t%2000==0: save(OUT)
save(OUT); print('saved',OUT,flush=True)
