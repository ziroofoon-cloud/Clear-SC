# GL (software OpenGL ES 3.2) vs numpy: the shaders of a .nsr pack must give the same picture as the numpy net.
# usage: python3 test_pack.py model.bin model.nsr   (needs numpy, opencv, scikit-image)
import sys, os, ctypes as C, numpy as np, cv2, struct
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,os.path.join(HERE,'..','shader_test')); os.environ['EGL_PLATFORM']='surfaceless'
import glrun
from glrun import gl, compile_prog
from skimage import data
print(glrun.init())
S=open(os.path.join(HERE,'..','..','app','src','main','java','app','clearoverlay','Shaders.kt'),encoding='utf-8').read()
k='const val VERT = """'; i=S.index(k)+len(k); VERT=S[i:S.index('"""',i)]
sys.path.insert(0,HERE); from gen_pack import read_bin
def parse(path):
    t=open(path).read().split('\n'); secs={}; cur=None
    for ln in t:
        if ln.startswith('@'):
            cur=ln[1:]; secs[cur]=[]
        elif cur: secs[cur].append(ln)
    return {k:'\n'.join(v)+'\n' for k,v in secs.items() if k!='end'}
gl.glGetUniformLocation.argtypes=[C.c_uint,C.c_char_p]; gl.glUniform1i.argtypes=[C.c_int,C.c_int]
def tex(w,h,fmt=0x881A,typ=0x140B,data=None,linear=False):
    t=C.c_uint(); gl.glGenTextures(1,C.byref(t)); gl.glBindTexture(0x0DE1,t)
    gl.glTexImage2D(0x0DE1,0,fmt,w,h,0,0x1908,typ,None if data is None else data.ctypes.data_as(C.c_void_p))
    for pn,v in ((0x2800,0x2601 if linear else 0x2600),(0x2801,0x2601 if linear else 0x2600),(0x2802,0x812F),(0x2803,0x812F)): gl.glTexParameteri(0x0DE1,pn,v)
    return t
def draw(prog,targets,w,h,inputs):
    fb=C.c_uint(); gl.glGenFramebuffers(1,C.byref(fb)); gl.glBindFramebuffer(0x8D40,fb)
    for i,t in enumerate(targets): gl.glFramebufferTexture2D(0x8D40,0x8CE0+i,0x0DE1,t,0)
    bufs=(C.c_uint*len(targets))(*[0x8CE0+i for i in range(len(targets))]); gl.glDrawBuffers(len(targets),bufs)
    assert gl.glCheckFramebufferStatus(0x8D40)==0x8CD5,'fbo incomplete'
    gl.glViewport(0,0,w,h); gl.glUseProgram(prog)
    for u,(name,t) in enumerate(inputs):
        gl.glActiveTexture(0x84C0+u); gl.glBindTexture(0x0DE1,t); gl.glUniform1i(gl.glGetUniformLocation(prog,name.encode()),u)
    gl.glDrawArrays(4,0,3)
def run(pack_path,bin_path,img):
    secs=parse(pack_path); H,W,_=img.shape
    scale,layers=read_bin(bin_path); C_=layers[0][1]; N=C_//4; L=len(layers)
    rgba=np.full((H,W,4),255,np.uint8); rgba[...,:3]=img[::-1]           # y-up target: the top row of the picture is the LAST row
    base=tex(W,H,0x1908,0x1401,np.ascontiguousarray(rgba),linear=True)
    A=[tex(W,H) for _ in range(N)]; B=[tex(W,H) for _ in range(N)]; head=tex(W,H)
    draw(compile_prog(VERT,secs['l1']),A,W,H,[('uSrc',base)])
    cur,nxt=A,B
    for i in range(1,L-1):
        draw(compile_prog(VERT,secs['hid%d'%i]),nxt,W,H,[('uF%d'%j,cur[j]) for j in range(N)]); cur,nxt=nxt,cur
    draw(compile_prog(VERT,secs['head']),[head],W,H,[('uF%d'%j,cur[j]) for j in range(N)])
    out=tex(2*W,2*H,0x1908,0x1401)
    draw(compile_prog(VERT,secs['compose']),[out],2*W,2*H,[('uBase',base),('uHead',head)])
    o=np.zeros((2*H,2*W,4),np.uint8); gl.glPixelStorei(0x0D05,1); gl.glReadPixels(0,0,2*W,2*H,0x1908,0x1401,o.ctypes.data_as(C.c_void_p))
    return o[::-1,:,:3]
def ref(bin_path,img):
    scale,layers=read_bin(bin_path)
    y=(0.299*img[...,0]+0.587*img[...,1]+0.114*img[...,2]).astype(np.float32)/255
    x=y[None,:,:,None]
    for i,(ci,co,w,b) in enumerate(layers):
        B,H,W,Ci=x.shape; p=np.pad(x,((0,0),(1,1),(1,1),(0,0)),mode='edge')
        cols=np.stack([p[:,dy:dy+H,dx:dx+W,:] for dy in range(3) for dx in range(3)],-1).reshape(B*H*W,Ci*9)
        x=(cols@w+b).reshape(B,H,W,-1)
        if i<len(layers)-1: x=np.maximum(x,0)
    Bn,H,W,_=x.shape; res=x.reshape(Bn,H,W,2,2).transpose(0,1,3,2,4).reshape(Bn,2*H,2*W)[0]
    f=img.astype(np.float32)/255; bil=cv2.resize(f,(2*W,2*H),interpolation=cv2.INTER_LINEAR)
    return np.clip(bil+res[...,None],0,1)
if __name__=='__main__':
    binp,pack=sys.argv[1],sys.argv[2]
    im=np.asarray(data.astronaut())[80:80+120,150:150+160]   # 160x120 crop
    g=run(pack,binp,im).astype(np.float32)/255; r=ref(binp,im)
    d=np.abs(g-r); print('GL vs numpy: max abs diff %.5f  mean %.6f  (1/255 = %.5f)'%(d.max(),d.mean(),1/255))
    # and the plain bilinear for comparison: the net must change the picture
    f=im.astype(np.float32)/255; bil=cv2.resize(f,(2*im.shape[1],2*im.shape[0]),interpolation=cv2.INTER_LINEAR)
    print('net vs bilinear mean diff %.5f'%np.abs(r-bil).mean())
