"""Offline check of half-precision (mediump) maths for the AI 3x networks: runs every level on two small test pictures once with 32-bit maths and once with 16-bit maths
(every product and sum rounded to 16 bits, the weights as 16-bit constants, the stored textures 16-bit in both) and prints how much the residual channels change.
Needs numpy, scikit-image and opencv-python. Last result (3.99.242): the largest change is 0.20 of 255 (Light), 0.05 (Quality). The phone's compiler is not covered."""
import re,sys,numpy as np
import os
A=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','app','src','main','assets','ai3')+os.sep
FILE=["aio0x3","aio1x3","aio4x3","aio1bx3","aio2bx3","aio2x3","aio3x3"]
NAMES=["Light","Balanced","Quality","Balanced+","High","Plus","Ultra"]
SIZES=[(1,1,7,0),(2,2,7,7),(8,8,7,7),(3,3,7,7),(5,5,7,7),(4,4,7,7),(6,6,7,7)]
def plan(t):
    if t==0: return [(0,[-1]),(1,[0]),(2,[1])]
    if t in (1,3,4,5,6): return [(0,[-1]),(1,[0]),(2,[1]),(3,[1])]
    return [(0,[-1]),(1,[0]),(0,[1]),(2,[0]),(3,[0])]
num=re.compile(r'-?\d+\.?\d*(?:e[-+]?\d+)?')
def parse(src):
    ntex=len(re.findall(r'uniform sampler2D uT\d+',src)); nout=len(re.findall(r'layout\(location=\d+\) out',src))
    bias={}; ops=[]; epi={}
    shift=(0,0); smap={}
    for l in src.split('\n'):
        m=re.match(r'\s*vec4 a(\d+) = vec4\((.*)\);',l)
        if m: bias[int(m.group(1))]=np.array(num.findall(m.group(2)),dtype=np.float64); continue
        m=re.search(r'ivec2 q = clamp\(p \+ ivec2\((-?\d+),(-?\d+)\)',l)
        if m: shift=(int(m.group(1)),int(m.group(2))); smap={}; continue
        m=re.match(r'\s*vec([34]) s(\d+) = texelFetch\(uT(\d+), q, 0\)\.(rgba|rgb);',l)
        if m: smap[int(m.group(2))]=(int(m.group(3)),int(m.group(1))); continue
        m=re.match(r'\s*a(\d+) \+= (mat\w+)\((.*)\) \* s(\d+);',l)
        if m:
            k=int(m.group(1)); vals=np.array(num.findall(m.group(3).replace('vec4','')),dtype=np.float64)
            tex,n=smap[int(m.group(4))]; cols=vals.reshape(n,4).T  # 4 x n (columns are the vec4s)
            ops.append((k,shift,tex,n,cols)); continue
        m=re.match(r'\s*o(\d+) = max\(a(\d+), 0\.0\) \+ vec4\((.*)\) \* min\(a\d+, 0\.0\);',l)
        if m: epi[int(m.group(1))]=np.array(num.findall(m.group(3)),dtype=np.float64); continue
        m=re.match(r'\s*o(\d+) = a(\d+);',l)
        if m: epi[int(m.group(1))]=None
    return ntex,nout,bias,ops,epi
def shifted(x,dx,dy):
    H,W=x.shape[:2]; xp=np.pad(x,((1,1),(1,1),(0,0)),mode='edge'); return xp[1+dy:1+dy+H,1+dx:1+dx+W]
def run(src,texs,half):
    ntex,nout,bias,ops,epi=parse(src)
    dt=np.float16 if half else np.float32
    acc={k:np.broadcast_to(bias[k].astype(dt),texs[0].shape[:2]+(4,)).copy() for k in bias}
    cache={}
    for k,(dx,dy),tex,n,cols in ops:
        key=(tex,dx,dy)
        if key not in cache: cache[key]=shifted(texs[tex],dx,dy)[...,:n].astype(dt)
        s=cache[key]; c=cols.astype(dt)  # weights are fp16 constants in mediump
        if half:
            r=np.zeros(acc[k].shape,dtype=np.float16)
            for i in range(n): r=(r+(s[...,i:i+1]*c[:,i][None,None,:]).astype(np.float16)).astype(np.float16)
            acc[k]=(acc[k]+r).astype(np.float16)
        else:
            acc[k]=acc[k]+np.einsum('hwn,mn->hwm',s,c).astype(np.float32)
    out=[]
    for o in range(nout):
        a=acc[o].astype(np.float32)
        sl=epi.get(o)
        if sl is not None: a=np.maximum(a,0)+sl.astype(np.float32)*np.minimum(a,0)
        out.append(a.astype(np.float16).astype(np.float32))  # stored in an RGBA16F texture either way
    return out
def pipeline(t,img,half):
    pl=plan(t); bufs={}; res={}
    for p,(ob,ins) in enumerate(pl,1):
        src=open(f'{A}{FILE[t]}_p{p}.frag',encoding='utf-8').read()
        texs=[]
        for i in ins: texs+= [np.concatenate([img,np.ones(img.shape[:2]+(1,),np.float32)],-1)] if i==-1 else bufs[i]
        out=run(src,texs,half)
        if ob in (0,1) or True: bufs[ob]=out if not (ob in (2,3)) else out
        if ob in (2,3): res[ob]=out
    return res
if __name__=='__main__':
    import skimage.data as d,cv2
    imgs=[]
    for im in (d.astronaut(),d.chelsea()):
        im=cv2.resize(im,(int(im.shape[1]/3),int(im.shape[0]/3)),interpolation=cv2.INTER_AREA)[:80,:96].astype(np.float32)/255.
        imgs.append(im)
    for t in range(7):
        rows=[]
        for img in imgs:
            a=pipeline(t,img,False); b=pipeline(t,img,True)
            errs=[]; mags=[]
            for ob in (2,3):
                if ob in a:
                    for x,y in zip(a[ob],b[ob]): errs.append(np.abs(x-y)[2:-2,2:-2]*255); mags.append(np.abs(x)[2:-2,2:-2]*255)
            e=np.concatenate([x.ravel() for x in errs]); m=np.concatenate([x.ravel() for x in mags])
            rows.append((e.max(),e.mean(),m.mean()))
        r=np.mean(rows,0)
        print(f'{NAMES[t]:10s} residual-channel error (of 255): max {max(x[0] for x in rows):.2f}  mean {r[1]:.4f}  | typical residual size {r[2]:.2f}',flush=True)
