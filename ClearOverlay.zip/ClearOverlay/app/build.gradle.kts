plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.clearoverlay"
    compileSdk = 34

    defaultConfig {
        applicationId = "app.clearoverlay"
        minSdk = 31
        targetSdk = 34
        versionCode = 30200
        versionName = "3.2.0"
    }

    buildTypes {
        // Shrink even the debug build so the APK stays tiny (no Kotlin stdlib bloat).
        // Debug is not shrunk any more: the Media3 player loads its HLS/DASH modules by reflection.
        getByName("debug") {
            isMinifyEnabled = false
        }
        getByName("release") {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    // Player engine: local files, direct links, HLS and DASH streaming, mkv/mp4/webm, subtitles, audio tracks.
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.4.1")
    implementation("androidx.media3:media3-exoplayer-dash:1.4.1")
}
