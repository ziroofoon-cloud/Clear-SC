plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.clearoverlay"
    compileSdk = 34

    defaultConfig {
        applicationId = "app.clearoverlay"
        minSdk = 31
        targetSdk = 34
        // versionCode grows with every build (minutes since 1970), so a new build always installs over the old one as an update.
        versionCode = (System.currentTimeMillis() / 60000L).toInt()
        versionName = "3.12.7"
        // Redmi Note 9 Pro is arm64: keeping only that ABI keeps the AI runtime small.
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    // One fixed signing key for debug AND release. Before, every build machine made its own random debug key,
    // so Android refused to install a new build over the old one ("app not installed") until it was uninstalled.
    signingConfigs {
        create("crsc") {
            storeFile = file("crsc.keystore")
            storePassword = "crscapp"
            keyAlias = "crsc"
            keyPassword = "crscapp"
        }
    }

    buildTypes {
        // Shrink even the debug build so the APK stays tiny (no Kotlin stdlib bloat).
        // Debug is not shrunk any more: the Media3 player loads its HLS/DASH modules by reflection.
        getByName("debug") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("crsc")
        }
        getByName("release") {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("crsc")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    // smbj / BouncyCastle ship duplicate metadata files; keep one copy so the APK builds.
    packaging {
        resources {
            excludes += setOf(
                "META-INF/versions/**", "META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*",
                "META-INF/AL2.0", "META-INF/LGPL2.1", "META-INF/INDEX.LIST"
            )
        }
    }
}

dependencies {
    // Player engine: local files, direct links, HLS and DASH streaming, mkv/mp4/webm, subtitles, audio tracks.
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.4.1")
    implementation("androidx.media3:media3-exoplayer-dash:1.4.1")
    // Offline on-device AI (LiteRT = TensorFlow Lite): runs a super-resolution model on the CPU, no internet needed.
    implementation("com.google.ai.edge.litert:litert:1.0.1")
    // Network sources: SMB (Windows / NAS shared folders) and FTP.
    implementation("com.hierynomus:smbj:0.13.0")
    implementation("commons-net:commons-net:3.11.1")
    implementation("com.github.junrar:junrar:7.5.5")
    // Lists the shares of an SMB server (srvsvc RPC); used through reflection, so a mismatch only disables "List shares".
    implementation("com.rapid7.client:dcerpc:0.12.0") {
        // it brings an old BouncyCastle (jdk15on) that clashes with the one smbj uses (jdk18on)
        exclude(group = "org.bouncycastle")
    }
}
