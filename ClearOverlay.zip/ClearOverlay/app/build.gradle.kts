import java.net.URL

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.clearoverlay"
    compileSdk = 34

    defaultConfig {
        applicationId = "app.clearoverlay"
        minSdk = 31
        targetSdk = 34
        // versionCode grows with every build (minutes since 1970), so a new build always installs over the old one as an update.
        versionCode = (System.currentTimeMillis() / 60000L).toInt()
        versionName = "3.6.0"
        // Redmi Note 9 Pro is arm64: keeping only that ABI keeps the AI runtime small.
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    // One fixed signing key for debug AND release. Before, every build machine made its own random debug key,
    // so Android refused to install a new build over the old one ("app not installed") until it was uninstalled.
    signingConfigs {
        create("crsc") {
            storeFile = file("crsc.keystore")
            storePassword = "crscapp"
            keyAlias = "crsc"
            keyPassword = "crscapp"
        }
    }

    buildTypes {
        // Shrink even the debug build so the APK stays tiny (no Kotlin stdlib bloat).
        // Debug is not shrunk any more: the Media3 player loads its HLS/DASH modules by reflection.
        getByName("debug") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("crsc")
        }
        getByName("release") {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("crsc")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

// Bundles the offline AI model (Real-ESRGAN General x4v3, ~5 MB, BSD-3) into the APK so nobody has to download it.
// To skip the download put your own file at app/src/main/assets/models/sr.tflite (it is then used instead).
// If the download fails (no internet while building) the build still succeeds and the app offers a one-time download.
val aiModelDir = layout.buildDirectory.dir("generated/aiModel")
val downloadAiModel by tasks.registering {
    val outFile = aiModelDir.get().file("models/sr.tflite").asFile
    val own = file("src/main/assets/models/sr.tflite")
    outputs.file(outFile)
    doLast {
        if (own.exists() || (outFile.exists() && outFile.length() > 100_000L)) return@doLast
        try {
            outFile.parentFile.mkdirs()
            val url = "https://huggingface.co/qualcomm/Real-ESRGAN-General-x4v3/resolve/1cadd892450d350bfd18e20e490931020063c2be/Real-ESRGAN-General-x4v3.tflite?download=true"
            URL(url).openStream().use { ins -> outFile.outputStream().use { ins.copyTo(it) } }
            if (outFile.length() < 100_000L) outFile.delete()
        } catch (e: Exception) {
            outFile.delete()
            logger.warn("AI model download failed (" + e.message + "): the app will offer a one-time download instead.")
        }
    }
}
android.sourceSets.getByName("main").assets.srcDir(aiModelDir)
tasks.matching { it.name.startsWith("merge") && it.name.endsWith("Assets") }.configureEach { dependsOn(downloadAiModel) }

dependencies {
    // Player engine: local files, direct links, HLS and DASH streaming, mkv/mp4/webm, subtitles, audio tracks.
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.4.1")
    implementation("androidx.media3:media3-exoplayer-dash:1.4.1")
    // Offline on-device AI (LiteRT = TensorFlow Lite): runs a super-resolution model on the CPU, no internet needed.
    implementation("com.google.ai.edge.litert:litert:1.0.1")
}
