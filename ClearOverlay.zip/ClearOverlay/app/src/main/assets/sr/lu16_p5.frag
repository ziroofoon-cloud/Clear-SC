#version 300 es
precision highp float;
precision highp int;
precision highp sampler2D;
uniform sampler2D uT0;   // conv4 output (4 ch = 2x2 sub-pixels) @ WxH, NEAREST
uniform sampler2D uIn;   // original RGBA8 input @ WxH
uniform float uGain;     // 1.0 = as trained, >1 sharper, 0 = plain bilinear (set with glUniform1f)
layout(location=0) out vec4 outColor;
void main(){
  ivec2 p = ivec2(gl_FragCoord.xy); ivec2 q = p >> 1; int k = (p.y & 1) * 2 + (p.x & 1);   // depth_to_space: ch = dy*2 + dx
  float res = texelFetch(uT0, q, 0)[k];
  ivec2 hi = textureSize(uIn, 0) - 1; ivec2 o = ivec2(((p.x & 1) << 1) - 1, ((p.y & 1) << 1) - 1);
  ivec2 qx = clamp(q + ivec2(o.x, 0), ivec2(0), hi), qy = clamp(q + ivec2(0, o.y), ivec2(0), hi), qd = clamp(q + o, ivec2(0), hi);
  vec3 bl = 0.5625 * texelFetch(uIn, q, 0).rgb + 0.1875 * (texelFetch(uIn, qx, 0).rgb + texelFetch(uIn, qy, 0).rgb) + 0.0625 * texelFetch(uIn, qd, 0).rgb;
  outColor = vec4(clamp(bl + uGain * res, 0.0, 1.0), 1.0);
}
