#version 300 es
precision highp float;
precision highp int;
precision highp sampler2D;

uniform sampler2D uT0;
uniform sampler2D uT1;
uniform sampler2D uT2;
uniform sampler2D uT3;
uniform sampler2D uT4;
uniform sampler2D uT5;
uniform sampler2D uT6;
uniform sampler2D uT7;
uniform sampler2D uT8;
uniform sampler2D uT9;
uniform sampler2D uT10;
uniform sampler2D uT11;
uniform sampler2D uT12;
uniform sampler2D uT13;
uniform sampler2D uIn;   // original RGBA8 input (texelFetch)
uniform float uGain;     // sharpness: 1.0 = as trained, 0 = soft/clean, 1.6 = sharper (MUST be set with glUniform1f)
layout(location=0) out vec4 outColor;
void main(){
  ivec2 p = ivec2(gl_FragCoord.xy); ivec2 q = p / 3; ivec2 m = p - q * 3; int k = m.y * 3 + m.x;   // depth_to_space: ch = c*9 + dy*3 + dx
  vec3 rA = vec3(0.0); vec3 rB = vec3(0.0);
  switch (k) {
    case 0: rA = vec3(texelFetch(uT0, q, 0)[0], texelFetch(uT2, q, 0)[1], texelFetch(uT4, q, 0)[2]); rB = vec3(texelFetch(uT6, q, 0)[3], texelFetch(uT9, q, 0)[0], texelFetch(uT11, q, 0)[1]); break;
    case 1: rA = vec3(texelFetch(uT0, q, 0)[1], texelFetch(uT2, q, 0)[2], texelFetch(uT4, q, 0)[3]); rB = vec3(texelFetch(uT7, q, 0)[0], texelFetch(uT9, q, 0)[1], texelFetch(uT11, q, 0)[2]); break;
    case 2: rA = vec3(texelFetch(uT0, q, 0)[2], texelFetch(uT2, q, 0)[3], texelFetch(uT5, q, 0)[0]); rB = vec3(texelFetch(uT7, q, 0)[1], texelFetch(uT9, q, 0)[2], texelFetch(uT11, q, 0)[3]); break;
    case 3: rA = vec3(texelFetch(uT0, q, 0)[3], texelFetch(uT3, q, 0)[0], texelFetch(uT5, q, 0)[1]); rB = vec3(texelFetch(uT7, q, 0)[2], texelFetch(uT9, q, 0)[3], texelFetch(uT12, q, 0)[0]); break;
    case 4: rA = vec3(texelFetch(uT1, q, 0)[0], texelFetch(uT3, q, 0)[1], texelFetch(uT5, q, 0)[2]); rB = vec3(texelFetch(uT7, q, 0)[3], texelFetch(uT10, q, 0)[0], texelFetch(uT12, q, 0)[1]); break;
    case 5: rA = vec3(texelFetch(uT1, q, 0)[1], texelFetch(uT3, q, 0)[2], texelFetch(uT5, q, 0)[3]); rB = vec3(texelFetch(uT8, q, 0)[0], texelFetch(uT10, q, 0)[1], texelFetch(uT12, q, 0)[2]); break;
    case 6: rA = vec3(texelFetch(uT1, q, 0)[2], texelFetch(uT3, q, 0)[3], texelFetch(uT6, q, 0)[0]); rB = vec3(texelFetch(uT8, q, 0)[1], texelFetch(uT10, q, 0)[2], texelFetch(uT12, q, 0)[3]); break;
    case 7: rA = vec3(texelFetch(uT1, q, 0)[3], texelFetch(uT4, q, 0)[0], texelFetch(uT6, q, 0)[1]); rB = vec3(texelFetch(uT8, q, 0)[2], texelFetch(uT10, q, 0)[3], texelFetch(uT13, q, 0)[0]); break;
    case 8: rA = vec3(texelFetch(uT2, q, 0)[0], texelFetch(uT4, q, 0)[1], texelFetch(uT6, q, 0)[2]); rB = vec3(texelFetch(uT8, q, 0)[3], texelFetch(uT11, q, 0)[0], texelFetch(uT13, q, 0)[1]); break;
  }
  vec3 res = rA + uGain * rB;
  ivec2 hi = textureSize(uIn, 0) - 1;
  vec2 off = (vec2(m) + 0.5) / 3.0 - 0.5; ivec2 dir = ivec2(sign(off)); vec2 a = abs(off);   // sample point inside the input pixel grid
  ivec2 qx = clamp(q + ivec2(dir.x, 0), ivec2(0), hi), qy = clamp(q + ivec2(0, dir.y), ivec2(0), hi), qd = clamp(q + dir, ivec2(0), hi);
  vec3 bl = (1.0 - a.x) * (1.0 - a.y) * texelFetch(uIn, q, 0).rgb + a.x * (1.0 - a.y) * texelFetch(uIn, qx, 0).rgb
          + (1.0 - a.x) * a.y * texelFetch(uIn, qy, 0).rgb + a.x * a.y * texelFetch(uIn, qd, 0).rgb;
  outColor = vec4(clamp(bl + res, 0.0, 1.0), 1.0);
}
