#version 300 es
precision highp float;
precision highp int;
precision highp sampler2D;

uniform sampler2D uT0;
layout(location=0) out vec4 o0;
// conv1: 3->4 3x3 (outputs 0..3), clamp-to-edge, PReLU
void main(){
  ivec2 p = ivec2(gl_FragCoord.xy);
  ivec2 hi = textureSize(uT0, 0) - 1;
  vec4 a0 = vec4(0.035068,-0.002226,-0.013771,0.002885);
  { ivec2 q = clamp(p + ivec2(-1,-1), ivec2(0), hi);
    vec3 s0 = texelFetch(uT0, q, 0).rgb;
    a0 += mat3x4(vec4(0.094056,-0.114906,0.239277,0.0527),vec4(0.080053,-0.139895,-0.301389,0.238483),vec4(-0.212809,0.025987,-0.220676,0.09058)) * s0;
  }
  { ivec2 q = clamp(p + ivec2(0,-1), ivec2(0), hi);
    vec3 s0 = texelFetch(uT0, q, 0).rgb;
    a0 += mat3x4(vec4(0.223616,0.058146,-0.291704,-0.443861),vec4(0.007736,-0.448549,0.05432,0.069807),vec4(-0.069999,0.009685,0.204735,-0.177256)) * s0;
  }
  { ivec2 q = clamp(p + ivec2(1,-1), ivec2(0), hi);
    vec3 s0 = texelFetch(uT0, q, 0).rgb;
    a0 += mat3x4(vec4(0.089934,0.059148,0.248886,-0.325282),vec4(0.148796,0.045578,-0.127033,-0.025809),vec4(0.002216,-0.137795,0.068979,0.234728)) * s0;
  }
  { ivec2 q = clamp(p + ivec2(-1,0), ivec2(0), hi);
    vec3 s0 = texelFetch(uT0, q, 0).rgb;
    a0 += mat3x4(vec4(-0.354674,0.576403,-0.005461,0.240537),vec4(-0.200437,0.02967,0.064097,-0.07045),vec4(-0.07501,0.161598,0.243828,-0.034182)) * s0;
  }
  { ivec2 q = clamp(p + ivec2(0,0), ivec2(0), hi);
    vec3 s0 = texelFetch(uT0, q, 0).rgb;
    a0 += mat3x4(vec4(0.246407,-0.302654,-0.339866,0.185009),vec4(-0.044338,-0.334043,0.206715,0.287337),vec4(0.3522,0.242545,-0.093956,0.18212)) * s0;
  }
  { ivec2 q = clamp(p + ivec2(1,0), ivec2(0), hi);
    vec3 s0 = texelFetch(uT0, q, 0).rgb;
    a0 += mat3x4(vec4(0.121488,-0.102771,-0.085433,-0.174252),vec4(-0.131216,-0.185951,-0.448743,-0.612605),vec4(0.273996,0.087324,-0.4033,0.331727)) * s0;
  }
  { ivec2 q = clamp(p + ivec2(-1,1), ivec2(0), hi);
    vec3 s0 = texelFetch(uT0, q, 0).rgb;
    a0 += mat3x4(vec4(-0.14614,0.555972,0.014725,-0.000285),vec4(0.162985,-0.019608,0.069236,-0.037737),vec4(-0.737885,-0.222694,-0.029941,0.10422)) * s0;
  }
  { ivec2 q = clamp(p + ivec2(0,1), ivec2(0), hi);
    vec3 s0 = texelFetch(uT0, q, 0).rgb;
    a0 += mat3x4(vec4(0.15816,0.17601,0.074244,0.12127),vec4(0.010811,-0.257129,0.333307,0.008981),vec4(-0.514124,0.199131,-0.121339,-0.238341)) * s0;
  }
  { ivec2 q = clamp(p + ivec2(1,1), ivec2(0), hi);
    vec3 s0 = texelFetch(uT0, q, 0).rgb;
    a0 += mat3x4(vec4(0.099224,0.180463,-0.267318,0.127484),vec4(-0.079597,-0.026746,-0.080977,-0.387931),vec4(-0.047567,-0.136475,0.211016,-0.412145)) * s0;
  }
  o0 = max(a0, 0.0) + vec4(0.202626,0.189579,0.075735,0.125248) * min(a0, 0.0);
}
