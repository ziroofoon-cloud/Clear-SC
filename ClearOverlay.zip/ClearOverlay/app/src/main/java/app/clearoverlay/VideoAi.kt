package app.clearoverlay

import android.content.Context
import android.graphics.Bitmap
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

/**
 * Offline AI upscaling for short videos: every frame goes through a small super-resolution model (TFLite, on the CPU),
 * then through the normal pipeline (FSR / Lanczos, sharpening, ...). It is slow: seconds per frame, so it is meant for
 * short clips; the "half frame rate" option makes only every second frame.
 *
 * Settings live in bits of the job "mode": bits 15-16 = level (0 off, 1 light, 2 medium, 3 heavy), bit 17 = half frame rate.
 */
object VideoAi {
    /** Levels: 0 off, 1 light, 2 medium, 3 heavy, 4 very light. (The level has 3 bits: bits 15-16 and bit 20.) */
    fun level(mode: Int) = ((mode shr 15) and 3) or (((mode shr 20) and 1) shl 2)
    fun half(mode: Int) = (mode and (1 shl 17)) != 0
    fun bits(level: Int, half: Boolean): Int {
        val l = level.coerceIn(0, 4)
        return if (l <= 0) 0 else ((l and 3) shl 15) or ((l shr 2) shl 20) or (if (half) 1 shl 17 else 0)
    }

    /** The order of the choices in the screen (Auto is the last one and is not a level of its own). */
    val UI_LEVELS = intArrayOf(0, 4, 1, 2, 3)

    /** Models tried in this order for each level (ids of [AiSr.CATALOG]). */
    private val PREF = arrayOf(
        emptyList(),
        listOf("XLSR", "QuickSRNet_Small"),
        listOf("QuickSRNet_Medium", "QuickSRNet_Large"),
        listOf("SESR_M5", "Real_ESRGAN_x4v3"),
        listOf("XLSR", "QuickSRNet_Small") // very light: the same small model on a much smaller picture
    )

    /** Short side of the picture that goes into the model: bigger frames are shrunk first (time grows with the pixels). */
    private val CAP = intArrayOf(0, 240, 288, 216, 144)

    /** Guess of milliseconds per 128 px tile before the speed test has been run. */
    private val DEF_MS = floatArrayOf(0f, 80f, 220f, 600f, 70f)

    fun catalogFor(level: Int): List<AiSr.Cat> = PREF[level.coerceIn(0, 4)].mapNotNull { id -> AiSr.CATALOG.firstOrNull { it.id == id } }

    /** The installed model for this level, or null. */
    fun modelFor(ctx: Context, level: Int): String? =
        catalogFor(level).firstOrNull { AiSr.isInstalled(ctx, it) }?.id

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("crsc", Context.MODE_PRIVATE)

    fun savedMs(ctx: Context, id: String): Float = prefs(ctx).getFloat("ai_ms_$id", 0f)
    fun saveMs(ctx: Context, id: String, ms: Float) = prefs(ctx).edit().putFloat("ai_ms_$id", ms).apply()

    fun msPerTile(ctx: Context, level: Int): Float {
        val id = modelFor(ctx, level)
        val s = if (id != null) savedMs(ctx, id) else 0f
        return if (s > 0f) s else DEF_MS[level.coerceIn(0, 4)]
    }

    /** The size of the frame that goes into the model. */
    fun inputSize(w: Int, h: Int, level: Int): Pair<Int, Int> {
        val cap = CAP[level.coerceIn(0, 4)]
        val short = min(w, h)
        if (cap <= 0 || short <= cap) return Pair(w, h)
        val k = cap.toFloat() / short
        return Pair(max(2, (w * k).toInt()), max(2, (h * k).toInt()))
    }

    /** Seconds the model needs for one frame of a w x h video (a rough guess; the speed test makes it better). */
    fun secPerFrame(ctx: Context, w: Int, h: Int, level: Int): Float {
        val (iw, ih) = inputSize(w, h, level)
        val tiles = ceil(iw / 112f) * ceil(ih / 112f)
        return tiles * msPerTile(ctx, level) / 1000f
    }

    fun shrink(src: Bitmap, level: Int): Bitmap {
        val (iw, ih) = inputSize(src.width, src.height, level)
        return if (iw == src.width && ih == src.height) src else Bitmap.createScaledBitmap(src, iw, ih, true)
    }
}

/** "Auto" for the offline AI: the best level whose work fits a time budget; falls back to half the frames, then to the lightest level. */
object VideoAiAuto {
    private const val BUDGET_SEC = 20 * 60f

    /** Returns (level, half rate) for a video of [frames] frames at [w] x [h]. */
    fun pick(ctx: Context, w: Int, h: Int, frames: Double): Pair<Int, Boolean> {
        val order = intArrayOf(3, 2, 1, 4)
        for (half in booleanArrayOf(false, true)) {
            for (l in order) {
                val t = frames * (if (half) 0.5 else 1.0) * VideoAi.secPerFrame(ctx, w, h, l)
                if (t <= BUDGET_SEC) return Pair(l, half)
            }
        }
        return Pair(4, true)
    }
}
