package app.clearoverlay

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import java.io.BufferedOutputStream
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.max
import kotlin.math.sqrt

/**
 * "Enhance to files" for photos and manga pages: pick the quality (Standard / High / Maximum with the offline AI model)
 * and the size, start, and get new pictures (Pictures/ClearOverlay/Enhanced) or, for manga, one new .cbz
 * (Download/ClearOverlay). While it runs the last result is shown and holding the picture shows the original, to compare.
 * Keep the screen on while it works (it stays on by itself).
 */
class BatchActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private var uris: List<Uri> = emptyList()
    private var name = "pictures"
    private var manga = false
    private var srcUri: Uri? = null

    private var quality = 1
    private var scaleIdx = 2
    private var png = false
    private var asCbz = true

    private lateinit var setup: LinearLayout
    private lateinit var card: LinearLayout
    private lateinit var statusTv: TextView
    private lateinit var bar: ProgressBar
    private lateinit var detailTv: TextView
    private lateinit var preview: ImageView
    private lateinit var hintTv: TextView
    private lateinit var cancelBtn: TextView
    private var before: Bitmap? = null
    private var after: Bitmap? = null

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Cfg.bind(this, "screen")
        Ui.init(this)
        setTheme(Ui.theme())
        super.onCreate(savedInstanceState)
        Ui.styleBars(window)
        uris = intent.getStringArrayListExtra(X_URIS)?.map { Uri.parse(it) } ?: emptyList()
        name = intent.getStringExtra(X_NAME) ?: "pictures"
        manga = intent.getBooleanExtra(X_MANGA, false)
        srcUri = intent.getStringExtra(X_SRC)?.let { Uri.parse(it) }
        val resume = uris.isEmpty() && srcUri == null && (BatchState.running || BatchState.finished)
        if (uris.isEmpty() && srcUri == null && !resume) {
            finish()
            return
        }
        if (resume) {
            // opened from the notification: show the running (or last) batch
            val j = BatchState.job
            name = j?.name ?: name
            manga = j?.manga ?: manga
        }

        val pad = dp(this, 16)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, dp(this@BatchActivity, 14), pad, pad)
        }
        col.addView(Ui.text(this, getString(R.string.batch_title), 22f, Ui.TEXT, true))
        col.addView(
            Ui.text(this, if (srcUri != null) getString(R.string.batch_file_fmt, name) else getString(R.string.batch_count_fmt, uris.size, name), 13f, Ui.MUTED),
            lp(4)
        )

        setup = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        setup.addView(Ui.text(this, getString(R.string.batch_quality), 13f, Ui.TEXT, true), lp(16))
        val hasAi = AiSr.hasModel(this)
        setup.addView(
            chips(listOf(getString(R.string.batch_q_standard), getString(R.string.batch_q_high), getString(R.string.batch_q_max), getString(R.string.batch_q_crsc)), quality) { i -> quality = i; showHint() },
            lp(6)
        )
        hintTv = Ui.text(this, "", 12f, Ui.MUTED)
        setup.addView(hintTv, lp(6))
        setup.addView(Ui.text(this, getString(R.string.batch_size), 13f, Ui.TEXT, true), lp(16))
        setup.addView(chips(listOf(getString(R.string.batch_same), "×1.5", "×2", "×3"), scaleIdx) { i -> scaleIdx = i }, lp(6))
        setup.addView(Ui.text(this, getString(R.string.batch_format), 13f, Ui.TEXT, true), lp(16))
        setup.addView(chips(listOf("JPEG", "PNG"), 0) { i -> png = i == 1 }, lp(6))
        if (manga) {
            setup.addView(Ui.text(this, getString(R.string.batch_output), 13f, Ui.TEXT, true), lp(16))
            setup.addView(chips(listOf(getString(R.string.batch_out_cbz), getString(R.string.batch_out_images)), 0) { i -> asCbz = i == 0 }, lp(6))
        }
        setup.addView(Ui.text(this, getString(R.string.batch_note), 12f, Ui.MUTED), lp(14))
        setup.addView(
            Ui.text(this, getString(R.string.batch_start), 16f, Ui.BG, true).apply {
                gravity = Gravity.CENTER
                background = Ui.gradient(dp(this@BatchActivity, 14).toFloat())
                setPadding(dp(this@BatchActivity, 20), dp(this@BatchActivity, 13), dp(this@BatchActivity, 20), dp(this@BatchActivity, 13))
                setOnClickListener { start(hasAi) }
            },
            lp(18)
        )
        col.addView(setup)
        showHint()

        card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.round(Ui.CARD, dp(this@BatchActivity, 16).toFloat(), Ui.STROKE, dp(this@BatchActivity, 1))
            setPadding(pad, pad, pad, pad)
            visibility = View.GONE
        }
        statusTv = Ui.text(this, "", 15f, Ui.TEXT, true)
        card.addView(statusTv)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            progressTintList = android.content.res.ColorStateList.valueOf(Ui.ACCENT)
        }
        card.addView(bar, lp(10))
        detailTv = Ui.text(this, "", 12.5f, Ui.MUTED)
        card.addView(detailTv, lp(8))
        preview = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(android.graphics.Color.BLACK)
            visibility = View.GONE
            // hold = the original, release = the result
            setOnTouchListener { _, ev ->
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> before?.let { setImageBitmap(it) }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> after?.let { setImageBitmap(it) }
                }
                true
            }
        }
        card.addView(preview, lp(12))
        card.addView(Ui.text(this, getString(R.string.batch_compare_hint), 11.5f, Ui.MUTED), lp(4))
        cancelBtn = Ui.text(this, getString(android.R.string.cancel), 14f, Ui.TEXT, true).apply {
            gravity = Gravity.CENTER
            background = Ui.round(Ui.CHIP, dp(this@BatchActivity, 12).toFloat())
            setPadding(dp(this@BatchActivity, 12), dp(this@BatchActivity, 11), dp(this@BatchActivity, 12), dp(this@BatchActivity, 11))
            setOnClickListener { if (BatchState.running || BatchState.pending) BatchService.cancel(this@BatchActivity) else finish() }
        }
        card.addView(cancelBtn, lp(12))
        col.addView(card, lp(18))

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            addView(col)
        })
        if (resume || BatchState.running) showRun()
    }

    private fun showHint() {
        hintTv.text = getString(
            when (quality) {
                0 -> R.string.batch_q_standard_desc
                1 -> R.string.batch_q_high_desc
                3 -> R.string.batch_q_crsc_desc
                else -> if (AiSr.hasModel(this)) R.string.batch_q_max_desc else R.string.batch_q_max_nomodel
            }
        )
    }

    private fun lp(top: Int) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@BatchActivity, top) }

    private fun chips(labels: List<String>, selected: Int, onPick: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val all = ArrayList<TextView>()
        fun paint(sel: Int) {
            val r = dp(this, 12).toFloat()
            all.forEachIndexed { i, c ->
                c.background = if (i == sel) Ui.gradient(r) else Ui.round(Ui.CHIP, r)
                c.setTextColor(if (i == sel) Ui.BG else Ui.MUTED)
            }
        }
        labels.forEachIndexed { i, l ->
            val c = TextView(this).apply {
                text = l
                textSize = 14f
                gravity = Gravity.CENTER
                maxLines = 1
                setPadding(dp(this@BatchActivity, 8), dp(this@BatchActivity, 10), dp(this@BatchActivity, 8), dp(this@BatchActivity, 10))
                setOnClickListener {
                    paint(i)
                    onPick(i)
                }
            }
            all.add(c)
            row.addView(c, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i > 0) marginStart = dp(this@BatchActivity, 6) })
        }
        paint(selected)
        return row
    }

    // ---- the work runs in BatchService; this screen only starts it and shows its progress -------------

    private fun start(hasAi: Boolean) {
        if (BatchState.running || BatchState.pending) return
        BatchService.start(
            this,
            BatchJob(
                uris = uris,
                src = srcUri,
                name = name,
                manga = manga,
                quality = quality,
                scaleIdx = scaleIdx,
                png = png,
                asCbz = asCbz
            )
        )
        showRun()
    }

    private fun showRun() {
        setup.visibility = View.GONE
        card.visibility = View.VISIBLE
        ui.removeCallbacks(ticker)
        ui.post(ticker)
    }

    private var shownVersion = -1
    private val ticker = object : Runnable {
        override fun run() {
            if (isDestroyed) return
            val total = BatchState.total
            val n = BatchState.done + BatchState.failed
            if (BatchState.version != shownVersion) {
                shownVersion = BatchState.version
                before = BatchState.before
                after = BatchState.after
                after?.let {
                    preview.setImageBitmap(it)
                    preview.visibility = View.VISIBLE
                }
            }
            val el = SystemClock.elapsedRealtime() - BatchState.startedAt
            if (BatchState.running || BatchState.pending) {
                bar.progress = if (total > 0) (n * 1000L / total).toInt() else 0
                statusTv.text = if (total > 0) getString(R.string.batch_progress_fmt, n, total) else getString(R.string.manga_preparing)
                val left = if (n > 0 && total > 0) el * (total - n) / n else -1L
                detailTv.text = getString(R.string.batch_elapsed_fmt, ExportClock.fmt(el)) + "   ·   " + getString(R.string.batch_eta_fmt, ExportClock.fmt(left))
                cancelBtn.text = getString(android.R.string.cancel)
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                ui.postDelayed(this, 500)
            } else if (BatchState.finished) {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                bar.progress = if (total > 0) (n * 1000L / total).toInt() else 1000
                statusTv.text = BatchState.message ?: ""
                cancelBtn.text = getString(R.string.batch_close)
            }
        }
    }

    override fun onDestroy() {
        // the work goes on in the service; only the screen is closed
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    companion object {
        const val X_URIS = "uris"
        const val X_NAME = "name"
        const val X_MANGA = "manga"
        const val X_SRC = "src"
    }
}

/** "12:05" / "1:02:30"; "-" when not known yet. */
object ExportClock {
    fun fmt(ms: Long): String {
        if (ms < 0) return "-"
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, sec) else String.format(java.util.Locale.US, "%d:%02d", m, sec)
    }
}
