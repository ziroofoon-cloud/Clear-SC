package app.clearoverlay

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

/** In-app language override: "" = follow the system, "en" = English, "fa" = Persian. */
object Lang {
    const val SYSTEM = ""
    const val EN = "en"
    const val FA = "fa"

    /** Reads the saved choice straight from prefs, so it works before [Cfg.load] and on every call. */
    fun saved(c: Context): String =
        c.getSharedPreferences("crsc", Context.MODE_PRIVATE).getString("lang", SYSTEM) ?: SYSTEM

    /** Returns [base] with the chosen language (and matching RTL/LTR direction) applied. */
    fun wrap(base: Context): Context {
        val tag = saved(base)
        if (tag.isEmpty()) return base
        val loc = Locale.forLanguageTag(tag)
        val conf = Configuration(base.resources.configuration)
        conf.setLocale(loc)
        conf.setLayoutDirection(loc)
        return base.createConfigurationContext(conf)
    }
}
