package app.clearoverlay

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import java.util.Locale

/** The one switch "Show live FPS" (stored apart from the picture profiles: it is the same for video, photo and screen). */
object FpsPref {
    private const val FILE = "crsc_ui"
    private const val KEY = "show_fps"
    fun on(ctx: Context): Boolean = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean(KEY, false)
    fun set(ctx: Context, v: Boolean) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean(KEY, v).apply()
    }
}

/** Frames per second over the last second, from a running total of shown pictures (call [sample] about twice a second). */
class FpsMeter {
    private val times = ArrayDeque<Long>()
    private val totals = ArrayDeque<Long>()

    @Volatile
    var fps = 0f
        private set

    fun reset() {
        times.clear()
        totals.clear()
        fps = 0f
    }

    fun sample(total: Long) {
        val t = SystemClock.elapsedRealtime()
        if (totals.isNotEmpty() && total < totals.last()) reset() // a new picture chain started counting from zero
        times.addLast(t)
        totals.addLast(total)
        while (times.size > 2 && t - times.first() > 1100L) {
            times.removeFirst()
            totals.removeFirst()
        }
        val dt = t - times.first()
        fps = if (times.size >= 2 && dt > 0) (total - totals.first()) * 1000f / dt else 0f
    }

    fun text(): String = String.format(Locale.US, "%.1f FPS", fps)
}

/**
 * The small "FPS" label drawn over every app by the screen overlay (a window that lets touches through and is kept out of the
 * capture, like the overlay itself). It follows [FpsPref] by itself: switch it on or off and it appears or goes within half a second.
 */
class ScreenFpsHud(private val ctx: Context, private val wm: WindowManager, private val frames: () -> Long) {
    private val h = Handler(Looper.getMainLooper())
    private val meter = FpsMeter()
    private var tv: TextView? = null

    private val tick = object : Runnable {
        override fun run() {
            update()
            h.postDelayed(this, 500)
        }
    }

    fun start() {
        h.removeCallbacks(tick)
        h.post(tick)
    }

    fun stop() {
        h.removeCallbacks(tick)
        remove()
    }

    private fun update() {
        if (!FpsPref.on(ctx)) {
            remove()
            meter.reset() // the old samples must not be averaged into the number when it is switched on again
            return
        }
        meter.sample(frames())
        val v = tv ?: add() ?: return
        v.text = meter.text()
    }

    private fun add(): TextView? {
        val v = TextView(ctx).apply {
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(dp(ctx, 8), dp(ctx, 3), dp(ctx, 8), dp(ctx, 3))
            background = Ui.round(Color.parseColor("#99000000"), dp(ctx, 8).toFloat())
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(ctx, 8)
            y = dp(ctx, 40)
        }
        Win.excludeFromCapture(lp) // otherwise the label would be captured, sharpened and drawn twice
        return try {
            wm.addView(v, lp)
            Win.passTouchesThrough(v)
            v.post { Win.skipScreenshot(v) }
            tv = v
            v
        } catch (e: Exception) {
            null
        }
    }

    private fun remove() {
        val v = tv ?: return
        tv = null
        runCatching { wm.removeView(v) }
    }
}
