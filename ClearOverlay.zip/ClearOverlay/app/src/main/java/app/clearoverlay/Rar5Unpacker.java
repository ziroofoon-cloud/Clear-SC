package app.clearoverlay;

import java.io.IOException;
import java.util.ArrayList;

/**
 * RAR5 decompressor (LZ + Huffman + the E8 / E8E9 / ARM / delta filters), written from the public RAR5 format
 * description and the unRAR decompression algorithm (decompression only). One instance per archive: for a solid
 * archive the dictionary and the Huffman state carry over from file to file.
 */
public final class Rar5Unpacker {
    private static final int NC = 306, DCB = 64, LDC = 16, RC = 44, BC = 20;
    private static final int HUFF_TABLE_SIZE = NC + DCB + RC + LDC;
    private static final int MAX_FILTER_BLOCK = 0x400000;
    private static final long MAX_WINDOW = 192L << 20;

    private static final class Table {
        final int[] decodeLen = new int[16];
        final int[] decodePos = new int[16];
        int[] decodeNum = new int[1];
        int maxNum = 1;
    }

    private static final class Filter {
        long start;
        int length;
        int type;
        int channels;
    }

    private byte[] win;
    private int mask;
    private int wp;
    private final long[] oldDist = new long[4];
    private int lastLength;
    private final Table bd = new Table(), ld = new Table(), dd = new Table(), ldd = new Table(), rd = new Table();
    private boolean tablesRead;
    private boolean started;

    // input
    private byte[] in;
    private int inLen;
    private long bitPos;
    // block
    private long blockEndBit;
    private boolean lastBlock;
    private boolean tablePresent;
    // output of the current file
    private byte[] out;
    private int filePos;
    private int unpSize;

    private int peek16() {
        int i = (int) (bitPos >> 3);
        int v = (b(i) << 16) | (b(i + 1) << 8) | b(i + 2);
        return (v >> (8 - (int) (bitPos & 7))) & 0xFFFF;
    }

    private int b(int i) {
        return i < inLen ? in[i] & 0xFF : 0;
    }

    private long bits(int n) { // n <= 32
        long r = 0;
        int left = n;
        while (left > 0) {
            int i = (int) (bitPos >> 3);
            int off = (int) (bitPos & 7);
            int take = Math.min(8 - off, left);
            int v = (b(i) >> (8 - off - take)) & ((1 << take) - 1);
            r = (r << take) | v;
            bitPos += take;
            left -= take;
        }
        return r;
    }

    private static void makeTable(int[] len, int off, int size, Table t) {
        t.maxNum = size;
        t.decodeNum = new int[size];
        int[] count = new int[16];
        for (int i = 0; i < size; i++) count[len[off + i] & 0xF]++;
        count[0] = 0;
        t.decodePos[0] = 0;
        t.decodeLen[0] = 0;
        long upper = 0;
        for (int i = 1; i < 16; i++) {
            upper += count[i];
            t.decodeLen[i] = (int) (upper << (16 - i));
            upper *= 2;
            t.decodePos[i] = t.decodePos[i - 1] + count[i - 1];
        }
        int[] cp = t.decodePos.clone();
        for (int i = 0; i < size; i++) {
            int cl = len[off + i] & 0xF;
            if (cl != 0) {
                int p = cp[cl]++;
                if (p < size) t.decodeNum[p] = i;
            }
        }
    }

    private int decode(Table t) {
        int field = peek16() & 0xFFFE;
        int bitsN = 15;
        for (int i = 1; i < 15; i++) {
            if (field < t.decodeLen[i]) {
                bitsN = i;
                break;
            }
        }
        bitPos += bitsN;
        int dist = (field - t.decodeLen[bitsN - 1]) >> (16 - bitsN);
        int pos = t.decodePos[bitsN] + dist;
        if (pos < 0 || pos >= t.maxNum) pos = 0;
        return t.decodeNum[pos];
    }

    private boolean readBlockHeader() {
        bitPos = (bitPos + 7) & ~7L;
        int flags = (int) bits(8);
        int byteCount = ((flags >> 3) & 3) + 1;
        if (byteCount == 4) return false;
        int blockBitSize = (flags & 7) + 1;
        int saved = (int) bits(8);
        int size = 0;
        int sum = 0x5a ^ flags;
        for (int i = 0; i < byteCount; i++) {
            int v = (int) bits(8);
            size |= v << (8 * i);
            sum ^= v;
        }
        if ((sum & 0xFF) != saved) return false;
        long start = bitPos >> 3;
        blockEndBit = (start + size - 1) * 8 + blockBitSize;
        lastBlock = (flags & 0x40) != 0;
        tablePresent = (flags & 0x80) != 0;
        return true;
    }

    private boolean readTables() {
        if (!tablePresent) return true;
        int[] bl = new int[BC];
        for (int i = 0; i < BC; i++) {
            int len = (int) bits(4);
            if (len == 15) {
                int zc = (int) bits(4);
                if (zc == 0) {
                    bl[i] = 15;
                } else {
                    zc += 2;
                    while (zc-- > 0 && i < BC) bl[i++] = 0;
                    i--;
                }
            } else {
                bl[i] = len;
            }
        }
        makeTable(bl, 0, BC, bd);
        int[] tb = new int[HUFF_TABLE_SIZE];
        int i = 0;
        while (i < HUFF_TABLE_SIZE) {
            if ((bitPos >> 3) > inLen + 8) return false;
            int n = decode(bd);
            if (n < 16) {
                tb[i++] = n;
            } else if (n < 18) {
                int cnt;
                if (n == 16) cnt = (int) bits(3) + 3;
                else cnt = (int) bits(7) + 11;
                if (i == 0) return false;
                while (cnt-- > 0 && i < HUFF_TABLE_SIZE) {
                    tb[i] = tb[i - 1];
                    i++;
                }
            } else {
                int cnt;
                if (n == 18) cnt = (int) bits(3) + 3;
                else cnt = (int) bits(7) + 11;
                while (cnt-- > 0 && i < HUFF_TABLE_SIZE) tb[i++] = 0;
            }
        }
        tablesRead = true;
        makeTable(tb, 0, NC, ld);
        makeTable(tb, NC, DCB, dd);
        makeTable(tb, NC + DCB, LDC, ldd);
        makeTable(tb, NC + DCB + LDC, RC, rd);
        return true;
    }

    private int slotToLength(int slot) {
        int lbits;
        int length = 2;
        if (slot < 8) {
            lbits = 0;
            length += slot;
        } else {
            lbits = slot / 4 - 1;
            length += (4 | (slot & 3)) << lbits;
        }
        if (lbits > 0) length += (int) bits(lbits);
        return length;
    }

    private void copy(int length, long dist) {
        if (dist <= 0 || dist > mask + 1L) {
            for (int i = 0; i < length; i++) put((byte) 0);
            return;
        }
        int src = (wp - (int) dist) & mask;
        for (int i = 0; i < length; i++) {
            byte v = win[src];
            src = (src + 1) & mask;
            put(v);
        }
    }

    private void put(byte v) {
        win[wp] = v;
        wp = (wp + 1) & mask;
        if (filePos < unpSize) out[filePos++] = v;
    }

    private long filterData() {
        int count = (int) bits(2) + 1;
        long data = 0;
        for (int i = 0; i < count; i++) data |= bits(8) << (8 * i);
        return data;
    }

    /**
     * Unpacks one file.
     *
     * @param packed   the packed bytes
     * @param size     the unpacked size
     * @param solid    the "solid" flag of the file (true: continue the dictionary of the previous file)
     * @param dictSize the dictionary size of the file
     * @return the unpacked bytes
     */
    public byte[] unpack(byte[] packed, int packedLen, long size, boolean solid, long dictSize) throws IOException {
        if (size < 0 || size > Integer.MAX_VALUE - 16) throw new IOException("file too large");
        in = packed;
        inLen = packedLen;
        bitPos = 0;
        unpSize = (int) size;
        out = new byte[unpSize];
        filePos = 0;
        if (!solid || !started || win == null) {
            long want = Math.min(dictSize, Math.max(size, 1L << 16));
            long w = 1L << 16;
            while (w < want) w <<= 1;
            if (solid) { // later files of a solid archive may need the whole dictionary
                w = 1L << 16;
                while (w < dictSize) w <<= 1;
            }
            if (w > MAX_WINDOW) throw new IOException("dictionary too large");
            if (win == null || win.length < w || !solid) {
                win = new byte[(int) w];
                mask = (int) w - 1;
            }
            if (!solid || !started) {
                wp = 0;
                java.util.Arrays.fill(oldDist, -1L);
                lastLength = 0;
                tablesRead = false;
            }
        }
        started = true;
        ArrayList<Filter> filters = new ArrayList<>();
        if (unpSize == 0) return out;
        if (!readBlockHeader() || !readTables() || !tablesRead) throw new IOException("bad data");
        while (true) {
            if (bitPos >= blockEndBit) {
                boolean done = false;
                while (bitPos >= blockEndBit) {
                    if (lastBlock) {
                        done = true;
                        break;
                    }
                    if (!readBlockHeader() || !readTables()) throw new IOException("bad block");
                }
                if (done) break;
            }
            if (filePos >= unpSize) break;
            if ((bitPos >> 3) > inLen + 8L) throw new IOException("truncated data");
            int slot = decode(ld);
            if (slot < 256) {
                put((byte) slot);
                continue;
            }
            if (slot >= 262) {
                int length = slotToLength(slot - 262);
                long dist = 1;
                int dbits;
                int ds = decode(dd);
                if (ds < 4) {
                    dbits = 0;
                    dist += ds;
                } else {
                    dbits = ds / 2 - 1;
                    dist += (long) (2 | (ds & 1)) << dbits;
                }
                if (dbits > 0) {
                    if (dbits >= 4) {
                        if (dbits > 4) {
                            dist += bits(dbits - 4) << 4;
                        }
                        dist += decode(ldd);
                    } else {
                        dist += bits(dbits);
                    }
                }
                if (dist > 0x100) {
                    length++;
                    if (dist > 0x2000) {
                        length++;
                        if (dist > 0x40000) length++;
                    }
                }
                oldDist[3] = oldDist[2];
                oldDist[2] = oldDist[1];
                oldDist[1] = oldDist[0];
                oldDist[0] = dist;
                lastLength = length;
                copy(length, dist);
                continue;
            }
            if (slot == 256) {
                Filter f = new Filter();
                f.start = filterData();
                long len = filterData();
                if (len > MAX_FILTER_BLOCK) len = 0;
                f.length = (int) len;
                f.type = (int) bits(3);
                if (f.type == 0) f.channels = (int) bits(5) + 1;
                f.start += filePos;
                filters.add(f);
                continue;
            }
            if (slot == 257) {
                if (lastLength != 0) copy(lastLength, oldDist[0]);
                continue;
            }
            int distNum = slot - 258;
            long dist = oldDist[distNum];
            for (int i = distNum; i > 0; i--) oldDist[i] = oldDist[i - 1];
            oldDist[0] = dist;
            int ls = decode(rd);
            int length = slotToLength(ls);
            lastLength = length;
            copy(length, dist);
        }
        if (filePos < unpSize) throw new IOException("short data " + filePos + "/" + unpSize);
        for (Filter f : filters) applyFilter(f);
        return out;
    }

    private void applyFilter(Filter f) {
        if (f.length <= 0 || f.start < 0 || f.start + f.length > unpSize) return;
        int s = (int) f.start;
        int n = f.length;
        switch (f.type) {
            case 1:
            case 2: {
                int cmp2 = f.type == 2 ? 0xE9 : 0xE8;
                final int fileSize = 0x1000000;
                int cur = 0;
                int p = s;
                long fileOffset = f.start & 0xFFFFFFFFL;
                while (cur + 4 < n) {
                    int cb = out[p++] & 0xFF;
                    cur++;
                    if (cb == 0xE8 || cb == cmp2) {
                        long offset = (cur + fileOffset) % fileSize;
                        long addr = (out[p] & 0xFFL) | ((out[p + 1] & 0xFFL) << 8) | ((out[p + 2] & 0xFFL) << 16) | ((out[p + 3] & 0xFFL) << 24);
                        if ((addr & 0x80000000L) != 0) {
                            if (((addr + offset) & 0x80000000L) == 0) put4(p, addr + fileSize);
                        } else if (((addr - fileSize) & 0x80000000L) != 0) {
                            put4(p, addr - offset);
                        }
                        p += 4;
                        cur += 4;
                    }
                }
                break;
            }
            case 3: {
                long fileOffset = f.start & 0xFFFFFFFFL;
                for (int cur = 0; cur + 3 < n; cur += 4) {
                    int d = s + cur;
                    if ((out[d + 3] & 0xFF) == 0xEB) {
                        long offset = (out[d] & 0xFFL) + (out[d + 1] & 0xFFL) * 0x100 + (out[d + 2] & 0xFFL) * 0x10000;
                        offset -= (fileOffset + cur) / 4;
                        out[d] = (byte) offset;
                        out[d + 1] = (byte) (offset >> 8);
                        out[d + 2] = (byte) (offset >> 16);
                    }
                }
                break;
            }
            case 0: {
                byte[] dst = new byte[n];
                int srcPos = 0;
                for (int ch = 0; ch < f.channels; ch++) {
                    int prev = 0;
                    for (int dp = ch; dp < n; dp += f.channels) {
                        prev = (prev - out[s + srcPos++]) & 0xFF;
                        dst[dp] = (byte) prev;
                    }
                }
                System.arraycopy(dst, 0, out, s, n);
                break;
            }
            default:
        }
    }

    private void put4(int p, long v) {
        out[p] = (byte) v;
        out[p + 1] = (byte) (v >> 8);
        out[p + 2] = (byte) (v >> 16);
        out[p + 3] = (byte) (v >> 24);
    }
}
