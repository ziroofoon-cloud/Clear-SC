package app.clearoverlay;

import android.os.ParcelFileDescriptor;

import java.io.File;

/**
 * Runs inside Shizuku's process as the "shell" user (no Context here). That user may open the folders Android keeps closed to every
 * app: Android/data and Android/obb. Only plain java.io.File is used.
 */
public class ShellService extends IShellFs.Stub {
    public ShellService() { }

    @Override public void destroy() { System.exit(0); }

    @Override public String[] list(String dir) {
        File[] a = new File(dir).listFiles();
        if (a == null) return null;
        String[] r = new String[a.length];
        for (int i = 0; i < a.length; i++) {
            File f = a[i];
            boolean d = f.isDirectory();
            r[i] = (d ? "d" : "f") + "\t" + (d ? -1L : f.length()) + "\t" + f.lastModified() + "\t" + f.getName();
        }
        return r;
    }

    @Override public boolean exists(String path) { return new File(path).exists(); }

    @Override public boolean mkdirs(String path) {
        File f = new File(path);
        return f.isDirectory() || f.mkdirs();
    }

    @Override public boolean deleteTree(String path) { return deleteAll(new File(path)); }

    private static boolean deleteAll(File f) {
        if (!f.exists()) return true;
        if (f.isDirectory()) {
            File[] a = f.listFiles();
            if (a != null) for (File c : a) deleteAll(c);
        }
        return f.delete();
    }

    @Override public boolean rename(String from, String to) { return new File(from).renameTo(new File(to)); }

    @Override public ParcelFileDescriptor open(String path, String mode) {
        try {
            File f = new File(path);
            if ("r".equals(mode)) return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
            File p = f.getParentFile();
            if (p != null && !p.exists()) p.mkdirs();
            return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_WRITE_ONLY | ParcelFileDescriptor.MODE_CREATE | ParcelFileDescriptor.MODE_TRUNCATE);
        } catch (Exception e) {
            return null;
        }
    }

    @Override public long free(String path) { return new File(path).getUsableSpace(); }
}
