package app.clearoverlay

import android.graphics.Bitmap
import android.os.SystemClock
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min

/** A copy of the picture settings that can be changed, so the search can try variations without touching [Cfg]. */
class MutFx(b: FxView) : FxView {
    override var mode = b.mode
    override var boost = b.boost
    override var vivid = b.vivid
    override var contrast = b.contrast
    override var shadows = b.shadows
    override var highlights = b.highlights
    override var saturation = b.saturation
    override var warmth = b.warmth
    override var brightness = b.brightness
    override var vibrance = b.vibrance
    override var tint = b.tint
    override var grain = b.grain
    override var clarity = b.clarity
    override var antiRing = b.antiRing
    override var deint = b.deint
    override var detail = b.detail
    override var detailSize = b.detailSize
    override var denoise = b.denoise
    override var deband = b.deband
    override var aaMode = b.aaMode
    override var aaStrength = b.aaStrength
    override var sharp = b.sharp
    override var inRes = b.inRes
    override var outRes = b.outRes
    override var midRes = b.midRes
    override var smartFix = b.smartFix
    override var cleanUp = b.cleanUp
    override var cleanLevel = b.cleanLevel
    /** CRSC Edge level (used when the upscaler is CRSC Edge). */
    var crsc = Cfg.crscLevel

    fun copy(): MutFx = MutFx(this).also { it.crsc = crsc }
}

/**
 * "Make lighter, same picture", measured: one real frame goes through the app's own GL pipeline with the chosen settings (the reference), then with
 * lighter variations (a lighter upscaler with the same or a slightly higher sharpness, an effect left out, a lower CRSC level...). A variation is
 * kept when its picture is close to the reference (PSNR on brightness) and, for a lighter upscaler, when it is really faster on this phone. The search
 * goes step by step from the settings the user chose, but every step is compared with the ORIGINAL picture, so small losses cannot add up.
 * Frame generation and the temporal clean-up need several frames and are not part of this search.
 */
object SmartOpt {
    /** Closeness needed (dB): effects that are left out must be invisible, a swapped upscaler may differ a little more. */
    private const val T_EFFECT = 40f
    private const val T_MODE = 36f

    class Result(val moves: List<Int>, val msBefore: Long, val msAfter: Long, val psnr: Float, val fx: MutFx, val changed: Boolean)

    private fun cost(m: Int, crsc: Int): Float = when (m) {
        Cfg.MODE_RAW -> 0.25f
        Cfg.MODE_SHARP -> 0.5f
        Cfg.MODE_FAST -> 0.8f
        Cfg.MODE_FSR -> 1.0f
        Cfg.MODE_SGSR, Cfg.MODE_NIS_MID -> 1.2f
        Cfg.MODE_NIS_FAST, Cfg.MODE_NIS_FINE -> 1.4f
        Cfg.MODE_NIS, Cfg.MODE_NIS_SOFT -> 1.7f
        Cfg.MODE_NIS_ORIG -> 3.2f
        Cfg.MODE_CLEAR -> 1.4f
        Cfg.MODE_ART -> 2.6f
        Cfg.MODE_PIXEL -> 1.2f
        Cfg.MODE_LANCZOS -> 1.6f + 0.45f * crsc
        else -> 1.0f
    }

    private val LADDER = intArrayOf(
        Cfg.MODE_NIS_ORIG, Cfg.MODE_NIS, Cfg.MODE_NIS_SOFT, Cfg.MODE_NIS_FAST, Cfg.MODE_NIS_MID, Cfg.MODE_SGSR, Cfg.MODE_FSR, Cfg.MODE_FAST, Cfg.MODE_SHARP
    )

    private fun psnr(a: Bitmap, b: Bitmap): Float {
        if (a.width != b.width || a.height != b.height) return 0f
        val w = a.width
        val h = a.height
        val ra = IntArray(w)
        val rb = IntArray(w)
        var sum = 0.0
        var n = 0L
        var y = 0
        while (y < h) {
            a.getPixels(ra, 0, w, 0, y, w, 1)
            b.getPixels(rb, 0, w, 0, y, w, 1)
            var x = 0
            while (x < w) {
                val p = ra[x]
                val q = rb[x]
                val la = 0.299 * ((p shr 16) and 255) + 0.587 * ((p shr 8) and 255) + 0.114 * (p and 255)
                val lb = 0.299 * ((q shr 16) and 255) + 0.587 * ((q shr 8) and 255) + 0.114 * (q and 255)
                val d = la - lb
                sum += d * d
                n++
                x += 2
            }
            y += 2
        }
        if (n == 0L) return 99f
        val mse = sum / n
        return if (mse < 1e-6) 99f else (10.0 * log10(255.0 * 255.0 / mse)).toFloat().coerceAtMost(99f)
    }

    /** Mean brightness gradient (how much fine detail the picture holds), every 2nd pixel. */
    private fun grad(a: Bitmap): Double {
        val w = a.width
        val h = a.height
        if (w < 3 || h < 3) return 0.0
        val r0 = IntArray(w)
        val r1 = IntArray(w)
        var sum = 0.0
        var n = 0L
        var y = 0
        while (y < h - 1) {
            a.getPixels(r0, 0, w, 0, y, w, 1)
            a.getPixels(r1, 0, w, 0, y + 1, w, 1)
            var x = 0
            while (x < w - 1) {
                val l = luma(r0[x])
                sum += Math.abs(l - luma(r0[x + 1])) + Math.abs(l - luma(r1[x]))
                n++
                x += 2
            }
            y += 2
        }
        return if (n == 0L) 0.0 else sum / n
    }

    private fun luma(p: Int): Double = 0.299 * ((p shr 16) and 255) + 0.587 * ((p shr 8) and 255) + 0.114 * (p and 255)

    private class Shot(val bmp: Bitmap, val ms: Long)

    private fun render(fx: MangaFx, src: Bitmap, c: MutFx, ow: Int, oh: Int, timed: Boolean): Shot? {
        fx.crscNow = c.crsc
        var best = Long.MAX_VALUE
        var bmp: Bitmap? = null
        for (i in 0 until (if (timed) 2 else 1)) { // the first run also warms the shaders; two runs give a steadier time
            val t0 = SystemClock.elapsedRealtime()
            val r = fx.processWith(src, c, ow, oh) ?: return null
            val dt = SystemClock.elapsedRealtime() - t0
            if (dt < best) best = dt
            if (bmp != null) bmp.recycle()
            bmp = r
        }
        return Shot(bmp!!, best)
    }

    /** Runs on a worker thread. Null when the GPU part failed or the search was cancelled. */
    fun run(frame: Bitmap, screenShort: Int, cancel: () -> Boolean, progress: (String) -> Unit): Result? {
        val fx = MangaFx()
        try {
            val base = MutFx(LiveFx)
            // the size the picture is made at: the chosen output size, else the screen's short side (at most 1440), kept within ~2.5 megapixels
            val outShort = if (base.outRes > 0) base.outRes else min(screenShort, 1440)
            var k = (outShort.toFloat() / min(frame.width, frame.height)).coerceIn(0.5f, 4f)
            val area = frame.width.toDouble() * frame.height * k * k
            if (area > 2_500_000.0) k *= Math.sqrt(2_500_000.0 / area).toFloat()
            val ow = max(2, (frame.width * k).toInt())
            val oh = max(2, (frame.height * k).toInt())
            progress("0")
            // the first try can fail while the GPU context starts or the shaders compile: try again from a clean renderer
            var ref0: Shot? = null
            for (attempt in 0 until 3) {
                ref0 = runCatching { render(fx, frame, base, ow, oh, true) }.getOrNull()
                if (ref0 != null || cancel()) break
                fx.reset()
            }
            val ref = ref0 ?: return null
            val refGrad = grad(ref.bmp)
            if (cancel()) return null
            var cur = base
            var curMs = ref.ms
            var curPsnr = 99f
            val moves = ArrayList<Int>()

            class Cand(val c: MutFx, val label: Int, val isMode: Boolean)

            fun candidates(c: MutFx): List<Cand> {
                val l = ArrayList<Cand>()
                if (c.denoise > 0f) l.add(Cand(c.copy().also { it.denoise = 0f }, R.string.so_denoise, false))
                if (c.deband > 0f) l.add(Cand(c.copy().also { it.deband = 0f }, R.string.so_deband, false))
                if (c.detail > 0f) l.add(Cand(c.copy().also { it.detail = 0f }, R.string.so_detail, false))
                if (c.clarity != 0f) l.add(Cand(c.copy().also { it.clarity = 0f }, R.string.so_clarity, false))
                if (c.antiRing > 0f) l.add(Cand(c.copy().also { it.antiRing = 0f }, R.string.so_antiring, false))
                // half the strength first: often invisible, and keeps the look of the effect
                if (c.denoise > 0.15f) l.add(Cand(c.copy().also { it.denoise = c.denoise * 0.5f }, R.string.so_half_denoise, false))
                if (c.deband > 0.15f) l.add(Cand(c.copy().also { it.deband = c.deband * 0.5f }, R.string.so_half_deband, false))
                if (c.detail > 0.15f) l.add(Cand(c.copy().also { it.detail = c.detail * 0.5f }, R.string.so_half_detail, false))
                if (Math.abs(c.clarity) > 0.15f) l.add(Cand(c.copy().also { it.clarity = c.clarity * 0.5f }, R.string.so_half_clarity, false))
                if (c.boost) l.add(Cand(c.copy().also { it.boost = false }, R.string.so_boost, false))
                if (c.aaMode != Cfg.AA_OFF) l.add(Cand(c.copy().also { it.aaMode = Cfg.AA_OFF }, R.string.so_aa, false))
                if (c.midRes > 0) l.add(Cand(c.copy().also { it.midRes = 0 }, R.string.so_midres, false))
                if (c.mode == Cfg.MODE_LANCZOS && c.crsc > 0) l.add(Cand(c.copy().also { it.crsc = c.crsc - 1 }, R.string.so_crsc, true))
                val here = cost(c.mode, c.crsc)
                for (m in LADDER + Cfg.MODE_LANCZOS) {
                    if (m == c.mode) continue
                    if (m == Cfg.MODE_LANCZOS) continue // never swap towards the heavier CRSC
                    if (cost(m, 0) >= here * 0.93f) continue
                    for (extra in floatArrayOf(0f, 0.1f)) {
                        val n = c.copy()
                        n.mode = m
                        n.sharp = (c.sharp + extra).coerceIn(0f, 1f)
                        l.add(Cand(n, R.string.so_mode, true))
                    }
                }
                return l
            }

            var round = 0
            while (round < 6 && !cancel()) {
                round++
                progress(round.toString())
                var bestC: Cand? = null
                var bestShot: Shot? = null
                var bestP = 0f
                var bestScore = 0f
                for (cd in candidates(cur)) {
                    if (cancel()) return null
                    val sh = runCatching { render(fx, frame, cd.c, ow, oh, cd.isMode) }.getOrNull() ?: continue
                    val p = psnr(ref.bmp, sh.bmp)
                    val need = if (cd.isMode) T_MODE else T_EFFECT
                    // a swapped upscaler must really be faster; leaving an effect out never adds work
                    val faster = cd.isMode && sh.ms <= curMs * 0.93f
                    // the fine detail must stay: not clearly blurrier (and not clearly harsher) than the reference
                    val gr = if (refGrad > 0.5) grad(sh.bmp) / refGrad else 1.0
                    val ok = p >= need && gr >= 0.88 && gr <= 1.25 && (if (cd.isMode) faster else true)
                    // preference: the biggest saving (time), then the closest picture
                    val score = (if (cd.isMode) (curMs - sh.ms).toFloat() else 0.5f) + p * 0.01f - (if (cd.label == R.string.so_half_denoise || cd.label == R.string.so_half_deband || cd.label == R.string.so_half_detail || cd.label == R.string.so_half_clarity) 0.3f else 0f)
                    if (ok && (bestC == null || score > bestScore)) {
                        bestShot?.bmp?.recycle()
                        bestC = cd
                        bestShot = sh
                        bestP = p
                        bestScore = score
                    } else sh.bmp.recycle()
                }
                val bc = bestC ?: break
                val bs = bestShot!!
                cur = bc.c
                curPsnr = bestP
                // the speed of the new settings (an effect that was left out changes it a little too)
                val again = render(fx, frame, cur, ow, oh, true)
                if (again != null) {
                    curMs = again.ms
                    again.bmp.recycle()
                }
                moves.add(bc.label)
                bs.bmp.recycle()
            }
            ref.bmp.recycle()
            return Result(moves, ref.ms, curMs, curPsnr, cur, moves.isNotEmpty())
        } finally {
            fx.release()
        }
    }

    /** Puts the found settings into [Cfg] (the temporary offsets of the live settings are taken out again). */
    fun apply(r: Result) {
        val c = r.fx
        Cfg.mode = c.mode
        Cfg.sharp = (c.sharp - Cfg.tSharp).coerceIn(0f, 1f)
        Cfg.denoise = (c.denoise - Cfg.tDenoise).coerceIn(0f, 1f)
        Cfg.deband = c.deband
        Cfg.detail = c.detail
        Cfg.clarity = c.clarity
        Cfg.antiRing = c.antiRing
        Cfg.boost = c.boost
        Cfg.aaMode = c.aaMode
        Cfg.midRes = c.midRes
        if (c.mode == Cfg.MODE_LANCZOS) Cfg.crscLevel = c.crsc
    }
}
