package app.clearoverlay

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager

/**
 * The icon on the home screen. Android has no call that changes an app's icon, so the manifest has one launcher entry (an activity-alias of
 * [MainActivity]) for each look of [Cfg.logoStyle], each with its own icon, and exactly one of them is enabled at a time:
 * 0 IconAuto (follows dark / light mode by resource qualifiers), 1 IconClassic, 2 IconClassicLight, 3 IconSoftDark, 4 IconSoftLight.
 * The new one is enabled first and the others after it, so there is never a moment with no launcher entry. DONT_KILL_APP: the app is not closed;
 * the launcher shows the new icon when it notices the change (a few seconds, and a few launchers only after they are restarted).
 */
object AppIcon {
    private val ALIASES = arrayOf("IconAuto", "IconClassic", "IconClassicLight", "IconSoftDark", "IconSoftLight")

    fun apply(ctx: Context, style: Int) {
        val want = style.coerceIn(0, ALIASES.size - 1)
        val pm = ctx.packageManager
        try {
            pm.setComponentEnabledSetting(name(ctx, want), PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
            for (i in ALIASES.indices) {
                if (i == want) continue
                pm.setComponentEnabledSetting(name(ctx, i), PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
            }
        } catch (t: Throwable) {
            Diag.add("icon", "app icon not changed: " + (t.message ?: t.javaClass.simpleName))
        }
    }

    // the alias class names are in the app's namespace (app.clearoverlay), whatever the applicationId is
    private fun name(ctx: Context, i: Int) = ComponentName(ctx.packageName, "app.clearoverlay." + ALIASES[i])
}
