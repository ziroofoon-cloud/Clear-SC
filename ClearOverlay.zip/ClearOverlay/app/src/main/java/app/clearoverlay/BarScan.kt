package app.clearoverlay

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever

/**
 * Finds black bars (letterbox / pillarbox) of a video for the file export's "Cut black bars". The player does the same live on the GPU
 * ([GlPipeline] detectBars); a file needs the answer before its size is chosen, so a few frames spread over the video are looked at once.
 * The rules are the same as the player's: a row / column is a bar when it is black (at most one lit pixel), a frame that is all black says nothing,
 * a bar thinner than 2.5 % is no bar, one row / column of margin is kept, and the result is the smallest bar found in any frame (a dark scene
 * can only make a bar look bigger, never smaller), so a real picture edge is not cut.
 */
object BarScan {
    private const val W = 192
    private const val H = 108
    private const val SAMPLES = 9

    /**
     * Fractions of the picture to cut: left, bottom, right, top (0..0.45 each). All zero when there is nothing to cut or the frames cannot be read.
     * Blocking (a few seconds): call it from a worker thread. [setup] points the retriever at the video.
     */
    fun detect(startUs: Long, endUs: Long, setup: (MediaMetadataRetriever) -> Unit): FloatArray {
        val none = FloatArray(4)
        if (endUs <= startUs) return none
        val mr = MediaMetadataRetriever()
        try {
            setup(mr)
            val best = floatArrayOf(1f, 1f, 1f, 1f)
            var used = 0
            for (i in 0 until SAMPLES) {
                val t = startUs + (endUs - startUs) * (2 * i + 1) / (2L * SAMPLES)
                val raw = runCatching { mr.getScaledFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, W, H) }.getOrNull() ?: continue
                val bmp = if (raw.width != W || raw.height != H) Bitmap.createScaledBitmap(raw, W, H, false) else raw
                val r = measure(bmp)
                if (bmp !== raw) bmp.recycle()
                raw.recycle()
                if (r == null) continue
                used++
                for (k in 0 until 4) best[k] = minOf(best[k], r[k])
            }
            if (used < 4) return none
            for (k in 0 until 4) best[k] = best[k].coerceIn(0f, 0.45f)
            return best
        } catch (e: Throwable) {
            return none
        } finally {
            runCatching { mr.release() }
        }
    }

    /** Bars of one W x H frame (left, bottom, right, top as fractions), or null when the frame is all black. */
    private fun measure(bmp: Bitmap): FloatArray? {
        val px = IntArray(W * H)
        bmp.getPixels(px, 0, W, 0, 0, W, H)
        // rows of the bitmap run from the top; the player counts from the bottom, the result is the same picture edges
        val luma = IntArray(W * H)
        var any = false
        for (i in px.indices) {
            val c = px[i]
            val r = (c shr 16) and 0xFF
            val g = (c shr 8) and 0xFF
            val b = c and 0xFF
            val y = (r * 77 + g * 150 + b * 29) shr 8
            luma[i] = y
            if (y > 24) any = true
        }
        if (!any) return null
        val th = 14
        fun rowBlack(y: Int): Boolean {
            var n = 0
            for (x in 0 until W) if (luma[y * W + x] > th) n++
            return n <= 1
        }
        fun colBlack(x: Int): Boolean {
            var n = 0
            for (y in 0 until H) if (luma[y * W + x] > th) n++
            return n <= 1
        }
        var top = 0
        while (top < H * 2 / 5 && rowBlack(top)) top++
        var bot = 0
        while (bot < H * 2 / 5 && rowBlack(H - 1 - bot)) bot++
        var lef = 0
        while (lef < W * 2 / 5 && colBlack(lef)) lef++
        var rig = 0
        while (rig < W * 2 / 5 && colBlack(W - 1 - rig)) rig++
        fun fr(n: Int, tot: Int): Float = if (n < tot * 0.025f) 0f else ((n - 1).toFloat() / tot)
        return floatArrayOf(fr(lef, W), fr(bot, H), fr(rig, W), fr(top, H))
    }
}
