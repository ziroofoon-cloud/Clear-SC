package app.clearoverlay

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

/**
 * Home-screen widget (4x1): four quick buttons - the overlay (switches the effect when it is running, otherwise opens the app to start it:
 * the screen-capture permission needs a screen), the library, the music player and "Free up space".
 */
class QuickWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) mgr.updateAppWidget(id, build(ctx))
    }

    companion object {
        private fun open(ctx: Context, code: Int, cls: Class<*>): PendingIntent =
            PendingIntent.getActivity(ctx, code, Intent(ctx, cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        fun build(ctx: Context): RemoteViews {
            val v = RemoteViews(ctx.packageName, R.layout.widget_quick)
            val overlay: PendingIntent =
                if (OverlayService.running)
                    PendingIntent.getService(ctx, 1, Intent(ctx, OverlayService::class.java).setAction(OverlayService.ACT_TOGGLE),
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                else open(ctx, 1, MainActivity::class.java)
            v.setOnClickPendingIntent(R.id.w_overlay, overlay)
            v.setOnClickPendingIntent(R.id.w_library, open(ctx, 2, LibraryActivity::class.java))
            v.setOnClickPendingIntent(R.id.w_music, open(ctx, 3, AudioActivity::class.java))
            v.setOnClickPendingIntent(R.id.w_shrink, open(ctx, 4, ShrinkActivity::class.java))
            return v
        }

        /** Called when the overlay starts / stops so that the first button does the right thing. */
        fun refresh(ctx: Context) {
            runCatching {
                val m = AppWidgetManager.getInstance(ctx)
                val ids = m.getAppWidgetIds(ComponentName(ctx, QuickWidget::class.java))
                if (ids.isNotEmpty()) for (id in ids) m.updateAppWidget(id, build(ctx))
            }
        }
    }
}
