package app.clearoverlay

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets

/**
 * Screen-edge space for bars. A camera hole on the side (landscape) only pushes a bar away from that edge when the hole is
 * really in the bar's band of the screen; a bar in the corner stays at the edge (it used to be moved away for no reason).
 */
object Edge {
    /** Returns [left, top, right, bottom] for something that sits in the vertical band [bandTop, bandBottom] (pixels). */
    fun insets(act: Activity, ins: WindowInsets, bandTop: Int, bandBottom: Int): IntArray {
        // only bars that are on screen right now count: in full-screen mode a bar sits at the very edge, and only while the phone's
        // status bar is pulled in for a moment (clock, battery ...) does it move down / sideways so nothing overlaps
        val sys = ins.getInsets(WindowInsets.Type.systemBars())
        var l = sys.left
        var t = sys.top
        var r = sys.right
        var b = sys.bottom
        // a bar that is pulled in by a swipe in full-screen mode is drawn OVER the app and is not part of getInsets(): while
        // it is visible, use its real size, so the app's own bars move out from under the clock / battery and back afterwards
        if (ins.isVisible(WindowInsets.Type.statusBars())) {
            t = maxOf(t, ins.getInsetsIgnoringVisibility(WindowInsets.Type.statusBars()).top)
        }
        if (ins.isVisible(WindowInsets.Type.navigationBars())) {
            val n = ins.getInsetsIgnoringVisibility(WindowInsets.Type.navigationBars())
            l = maxOf(l, n.left); r = maxOf(r, n.right); b = maxOf(b, n.bottom)
        }
        val cut = ins.displayCutout
        if (cut != null) {
            t = maxOf(t, cut.safeInsetTop)
            b = maxOf(b, cut.safeInsetBottom)
            val w = act.windowManager.currentWindowMetrics.bounds.width()
            for (rc in cut.boundingRects) {
                if (rc.bottom <= bandTop || rc.top >= bandBottom) continue
                if (rc.left <= 1) l = maxOf(l, rc.right)
                else if (rc.right >= w - 1) r = maxOf(r, w - rc.left)
            }
        }
        return intArrayOf(l, t, r, b)
    }

    fun full(act: Activity, ins: WindowInsets): IntArray = insets(act, ins, 0, Int.MAX_VALUE)

    /**
     * Tells a full-screen screen when the phone's status bar (clock, battery ...) is pulled in over it by a swipe from the top,
     * so its own top bar can slide down out from under the clock and come back afterwards.
     *
     * The system hides this from the app: the window's insets say "no bar" for the whole time, so they cannot be used. Two
     * other signals are used instead: the (old) system-UI-visibility callback, trusted only after it has once reported the
     * bars as hidden, and the swipe itself: a touch that starts in the top ~30 dp and either moves down or is taken away
     * from the app (cancelled) by the system. The bar is taken as shown for about 3.8 s (the time the system keeps it) unless
     * the callback says it left sooner.
     *
     * Use: create it once, pass every touch to [onTouch] (Activity.dispatchTouchEvent), call [settle] when the window gets
     * focus again. [onChange] gets true / false and may animate; [barHeight] is the room to leave.
     */
    class TransientBars(private val act: Activity, private val view: View, private val onChange: (Boolean) -> Unit) {
        private val ui = Handler(Looper.getMainLooper())
        private var shown = false
        private var shownAt = 0L
        private var sawHidden = false
        private var fromEdge = false
        private var startY = 0f
        private var startT = 0L
        private val edgePx = dp(act, 30)
        private val pullPx = dp(act, 14)
        private val hide = Runnable { set(false) }

        init {
            @Suppress("DEPRECATION")
            act.window.decorView.setOnSystemUiVisibilityChangeListener { f ->
                if ((f and View.SYSTEM_UI_FLAG_FULLSCREEN) != 0) {
                    sawHidden = true
                    // "hidden" while the bar was only just shown is the start-up / gesture noise: wait until it has been out a while
                    if (shown && SystemClock.uptimeMillis() - shownAt > 1200) set(false)
                } else if (sawHidden) {
                    trigger()
                }
            }
        }

        /** The room the clock / battery row takes at the top, in pixels. */
        fun barHeight(): Int {
            val h = view.rootWindowInsets?.getInsetsIgnoringVisibility(WindowInsets.Type.statusBars())?.top ?: 0
            return if (h > 0) h else dp(act, 28)
        }

        private fun set(v: Boolean) {
            if (v == shown) return
            shown = v
            if (v) shownAt = SystemClock.uptimeMillis()
            onChange(v)
        }

        private fun trigger() {
            set(true)
            ui.removeCallbacks(hide)
            ui.postDelayed(hide, 3800)
        }

        fun onTouch(ev: MotionEvent) {
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    fromEdge = ev.rawY <= edgePx
                    startY = ev.rawY
                    startT = ev.eventTime
                }
                MotionEvent.ACTION_MOVE -> if (fromEdge && !shown && ev.rawY - startY > pullPx) trigger()
                MotionEvent.ACTION_CANCEL -> if (fromEdge && ev.eventTime - startT < 1500) trigger()
                MotionEvent.ACTION_UP -> fromEdge = false
            }
        }

        /** The window got focus back (for example after the full notification shade was pulled and closed). */
        fun settle() {
            if (shown && SystemClock.uptimeMillis() - shownAt > 1500) {
                ui.removeCallbacks(hide)
                set(false)
            }
        }

        fun release() {
            ui.removeCallbacks(hide)
        }
    }

    /**
     * Full-screen screens hide the system bars; swiping down from the top pulls the status bar (clock, battery) in for a
     * moment, drawn OVER the app. The window does not always dispatch new insets for that, so the system-bars change
     * itself is watched and the insets are asked for again: the screen's own bars then move down out from under the clock
     * and come back when it leaves.
     */
    @Suppress("DEPRECATION")
    fun watchBars(act: Activity, target: View) {
        act.window.decorView.setOnSystemUiVisibilityChangeListener {
            target.post { target.requestApplyInsets() }
            target.postDelayed({ target.requestApplyInsets() }, 250)
        }
    }
}
