package app.clearoverlay

import android.app.Activity
import android.view.WindowInsets

/**
 * Screen-edge space for bars. A camera hole on the side (landscape) only pushes a bar away from that edge when the hole is
 * really in the bar's band of the screen; a bar in the corner stays at the edge (it used to be moved away for no reason).
 */
object Edge {
    /** Returns [left, top, right, bottom] for something that sits in the vertical band [bandTop, bandBottom] (pixels). */
    fun insets(act: Activity, ins: WindowInsets, bandTop: Int, bandBottom: Int): IntArray {
        val sys = ins.getInsetsIgnoringVisibility(WindowInsets.Type.systemBars())
        var l = sys.left
        var t = sys.top
        var r = sys.right
        var b = sys.bottom
        val cut = ins.displayCutout
        if (cut != null) {
            t = maxOf(t, cut.safeInsetTop)
            b = maxOf(b, cut.safeInsetBottom)
            val w = act.windowManager.currentWindowMetrics.bounds.width()
            for (rc in cut.boundingRects) {
                if (rc.bottom <= bandTop || rc.top >= bandBottom) continue
                if (rc.left <= 1) l = maxOf(l, rc.right)
                else if (rc.right >= w - 1) r = maxOf(r, w - rc.left)
            }
        }
        return intArrayOf(l, t, r, b)
    }

    fun full(act: Activity, ins: WindowInsets): IntArray = insets(act, ins, 0, Int.MAX_VALUE)
}
