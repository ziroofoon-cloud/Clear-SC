package app.clearoverlay

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.provider.MediaStore
import android.view.Gravity
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.min

/**
 * "AI still frame": the live screen effect cannot run a neural network on every frame, but a single frame can.
 * The bubble panel's ✨ button grabs the current screen (no effects), pauses the live effect and opens this full-screen
 * viewer on the frozen picture. The user drags over the part to improve (best: the model then sees real pixels and
 * finishes quickly) or taps "Whole screen"; the offline AI model ([AiSr]) enhances it, and the result can be zoomed
 * and saved to Pictures/ClearOverlay. Closing resumes the live effect.
 */
class AiSnap(
    private val svc: OverlayService,
    private val wm: WindowManager,
    private val onClosed: () -> Unit
) {
    private val ctx: Context = Ui.themed(svc)
    private var root: FrameLayout? = null
    private lateinit var view: SnapView
    private lateinit var topTxt: TextView
    private lateinit var status: TextView
    private lateinit var bar: LinearLayout

    private var frame: Bitmap? = null
    private var result: Bitmap? = null
    private val cancel = AtomicBoolean(false)
    private var busy = false
    private var saving = false
    private var closed = false

    fun show(f: Bitmap) {
        frame = f
        val b = wm.maximumWindowMetrics.bounds
        val ins = wm.maximumWindowMetrics.windowInsets
            .getInsetsIgnoringVisibility(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())

        val lay = FrameLayout(ctx).apply {
            setBackgroundColor(Color.BLACK)
            setPadding(ins.left, ins.top, ins.right, ins.bottom)
        }
        view = SnapView(ctx).apply { onPick = { r -> runAi(r) } }
        lay.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val top = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#B30B1020"))
            setPadding(dp(ctx, 14), dp(ctx, 8), dp(ctx, 14), dp(ctx, 8))
        }
        topTxt = Ui.text(ctx, "", 13f, Ui.ACCENT, true)
        topTxt.setOnClickListener { if (!busy) cycleModel() }
        status = Ui.text(ctx, "", 12f, Ui.MUTED)
        top.addView(topTxt)
        top.addView(status)
        lay.addView(top, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))

        bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#B30B1020"))
            setPadding(dp(ctx, 10), dp(ctx, 8), dp(ctx, 10), dp(ctx, 8))
        }
        lay.addView(bar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))

        val lp = WindowManager.LayoutParams(
            b.width(), b.height(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        Win.excludeFromCapture(lp)
        root = lay
        wm.addView(lay, lp)
        showSelect()
    }

    private fun btn(label: String, color: Int, weight: Float = 1f, onClick: () -> Unit): TextView =
        Ui.text(ctx, label, 15f, color, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(ctx, 8), dp(ctx, 12), dp(ctx, 8), dp(ctx, 12))
            background = Ui.round(Ui.CHIP, dp(ctx, 12).toFloat(), color, dp(ctx, 1))
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight).apply {
                marginStart = dp(ctx, 4)
                marginEnd = dp(ctx, 4)
            }
        }

    private fun modelText() = ctx.getString(R.string.aisnap_model_fmt, AiSr.activeLabel(svc))

    private fun cycleModel() {
        val l = AiSr.list(svc)
        if (l.size < 2) {
            toast(ctx.getString(R.string.aisnap_one_model))
            return
        }
        val i = l.indexOfFirst { it.id == AiSr.activeId(svc) }
        AiSr.setActive(svc, l[(i + 1) % l.size].id)
        topTxt.text = modelText()
    }

    private fun showSelect() {
        val f = frame ?: return
        view.locked = false
        view.setBitmap(f, true)
        topTxt.visibility = View.VISIBLE
        topTxt.text = modelText()
        status.text = ctx.getString(R.string.aisnap_hint)
        bar.removeAllViews()
        bar.addView(btn("✨ " + ctx.getString(R.string.aisnap_whole), Ui.ACCENT2, 1.6f) { runAi(null) })
        bar.addView(btn("☁ x4", Ui.ACCENT) { runOnline(Online.PHOTO) })
        bar.addView(btn("☁ Aa", Ui.ACCENT) { runOnline(Online.TEXT) })
        bar.addView(btn("✕ " + ctx.getString(R.string.aisnap_close), Ui.MUTED) { close() })
    }

    /** Online (cloud) enhance of the whole frame: x4 for pictures, "Aa" for clearer writing. */
    private fun runOnline(kind: Int) {
        val f = frame ?: return
        if (busy) return
        if (!Online.hasKey(svc)) {
            toast(ctx.getString(R.string.online_need_key_overlay))
            return
        }
        busy = true
        cancel.set(false)
        showBusy(0)
        status.text = "☁ " + ctx.getString(R.string.online_working_fmt, "")
        Thread {
            var err: String? = null
            var out: Bitmap? = null
            try {
                out = Online.enhance(svc, f, kind, cancel) { st ->
                    svc.main.post { if (!closed && busy) status.text = "☁ " + ctx.getString(R.string.online_working_fmt, st) }
                }
            } catch (t: Throwable) {
                err = t.message ?: t.javaClass.simpleName
            }
            val e = err
            val o = out
            svc.main.post {
                if (closed) return@post
                busy = false
                when {
                    e != null -> {
                        toast(ctx.getString(R.string.online_error_fmt, e))
                        showSelect()
                    }
                    o == null -> {
                        toast(ctx.getString(R.string.ai_cancelled))
                        showSelect()
                    }
                    else -> {
                        result = o
                        showResult()
                    }
                }
            }
        }.start()
    }

    private fun showBusy(p: Int) {
        view.locked = true
        topTxt.visibility = View.GONE
        status.text = ctx.getString(R.string.aisnap_progress_fmt, p)
        if (bar.childCount != 1) {
            bar.removeAllViews()
            bar.addView(btn(ctx.getString(R.string.aisnap_cancel), Ui.DANGER) { cancel.set(true) })
        }
    }

    private fun showResult() {
        val r = result ?: return
        view.locked = false
        view.setBitmap(r, false)
        topTxt.visibility = View.GONE
        status.text = ctx.getString(R.string.aisnap_result_fmt, r.width, r.height)
        bar.removeAllViews()
        bar.addView(btn("💾 " + ctx.getString(R.string.aisnap_save), Ui.OK, 1.3f) { save() })
        bar.addView(btn("↩ " + ctx.getString(R.string.aisnap_back), Ui.ACCENT) { showSelect() })
        bar.addView(btn("✕ " + ctx.getString(R.string.aisnap_close), Ui.MUTED) { close() })
    }

    /** Enhances [region] (in frame pixels) or, with null, the whole frame. */
    private fun runAi(region: Rect?) {
        val f = frame ?: return
        if (busy) return
        if (!AiSr.hasModel(svc)) {
            toast(ctx.getString(R.string.aisnap_no_model))
            return
        }
        busy = true
        cancel.set(false)
        showBusy(0)
        Thread {
            var err: String? = null
            var out: Bitmap? = null
            try {
                val src = if (region != null) {
                    val l = region.left.coerceIn(0, f.width - 2)
                    val t = region.top.coerceIn(0, f.height - 2)
                    Bitmap.createBitmap(f, l, t, region.width().coerceIn(2, f.width - l), region.height().coerceIn(2, f.height - t))
                } else f
                out = AiSr.upscale(
                    svc, src,
                    { p -> svc.main.post { if (!closed && busy) showBusy(p) } },
                    cancel, 4096, 16_000_000L
                )
                if (src !== f) src.recycle()
            } catch (t: Throwable) {
                err = t.message ?: t.javaClass.simpleName
            }
            val e = err
            val o = out
            svc.main.post {
                if (closed) return@post
                busy = false
                when {
                    e != null -> {
                        toast(ctx.getString(R.string.ai_error_fmt, e))
                        showSelect()
                    }
                    o == null -> {
                        toast(ctx.getString(R.string.ai_cancelled))
                        showSelect()
                    }
                    else -> {
                        result = o
                        showResult()
                    }
                }
            }
        }.start()
    }

    private fun save() {
        val b = result ?: return
        if (saving) return
        saving = true
        toast(ctx.getString(R.string.img_wait))
        Thread {
            val ok = runCatching { writePng(b) }.getOrDefault(false)
            svc.main.post {
                saving = false
                toast(ctx.getString(if (ok) R.string.aisnap_saved else R.string.aisnap_save_fail))
            }
        }.start()
    }

    private fun writePng(b: Bitmap): Boolean {
        val name = "CRSC_AI_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".png"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ClearOverlay")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val resolver = svc.contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
        return try {
            val os = resolver.openOutputStream(uri)
            if (os == null) {
                resolver.delete(uri, null, null)
                false
            } else {
                os.use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                true
            }
        } catch (t: Throwable) {
            runCatching { resolver.delete(uri, null, null) }
            false
        }
    }

    private fun toast(s: String) = Toast.makeText(svc, s, Toast.LENGTH_SHORT).show()

    /** Removes the window without telling the service (used when the service itself is shutting down). */
    fun dispose() {
        if (closed) return
        closed = true
        cancel.set(true)
        root?.let { runCatching { wm.removeView(it) } }
        root = null
        frame = null
        result = null
    }

    fun close() {
        if (closed) return
        dispose()
        onClosed()
    }

    /**
     * Shows a bitmap fit to the screen. In select mode a drag draws a rectangle and reports it (bitmap pixels);
     * in view mode: pinch to zoom, drag to pan, double-tap = fit again.
     */
    private class SnapView(c: Context) : View(c) {
        var onPick: ((Rect) -> Unit)? = null
        var locked = false
        private var bmp: Bitmap? = null
        private var select = true
        private val m = Matrix()
        private val inv = Matrix()
        private var scale = 1f
        private var minScale = 1f
        private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        private val dim = Paint().apply { color = Color.parseColor("#99000000") }
        private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(c, 2).toFloat()
            color = Ui.ACCENT
        }
        private var sx = 0f
        private var sy = 0f
        private var ex = 0f
        private var ey = 0f
        private var dragging = false
        private var lastX = 0f
        private var lastY = 0f

        private val sgd = ScaleGestureDetector(c, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val target = (scale * d.scaleFactor).coerceIn(minScale, minScale * 16f)
                val f = target / scale
                m.postScale(f, f, d.focusX, d.focusY)
                scale = target
                invalidate()
                return true
            }
        })
        private val gd = GestureDetector(c, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (!select) {
                    fit()
                    invalidate()
                }
                return true
            }
        })

        fun setBitmap(b: Bitmap, selectMode: Boolean) {
            bmp = b
            select = selectMode
            dragging = false
            fit()
            invalidate()
        }

        private fun fit() {
            val b = bmp ?: return
            if (width == 0 || height == 0) return
            val s = min(width.toFloat() / b.width, height.toFloat() / b.height)
            minScale = s
            scale = s
            m.reset()
            m.postScale(s, s)
            m.postTranslate((width - b.width * s) / 2f, (height - b.height * s) / 2f)
        }

        override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
            fit()
        }

        override fun onDraw(canvas: Canvas) {
            val b = bmp ?: return
            canvas.drawBitmap(b, m, paint)
            if (select && dragging) {
                val r = RectF(min(sx, ex), min(sy, ey), max(sx, ex), max(sy, ey))
                canvas.save()
                canvas.clipOutRect(r)
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dim)
                canvas.restore()
                canvas.drawRect(r, stroke)
            }
        }

        override fun onTouchEvent(ev: MotionEvent): Boolean {
            if (locked || bmp == null) return true
            if (select) {
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = ev.x; sy = ev.y; ex = ev.x; ey = ev.y
                        dragging = true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        ex = ev.x; ey = ev.y
                        invalidate()
                    }
                    MotionEvent.ACTION_UP -> {
                        ex = ev.x; ey = ev.y
                        dragging = false
                        invalidate()
                        pick()
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        dragging = false
                        invalidate()
                    }
                }
                return true
            }
            sgd.onTouchEvent(ev)
            gd.onTouchEvent(ev)
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = ev.x; lastY = ev.y
                }
                MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_POINTER_UP -> {
                    val i = if (ev.actionMasked == MotionEvent.ACTION_POINTER_UP && ev.actionIndex == 0) 1 else 0
                    if (i < ev.pointerCount) {
                        lastX = ev.getX(i); lastY = ev.getY(i)
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    if (ev.pointerCount == 1 && !sgd.isInProgress) {
                        m.postTranslate(ev.x - lastX, ev.y - lastY)
                        invalidate()
                    }
                    lastX = ev.x; lastY = ev.y
                }
            }
            return true
        }

        private fun pick() {
            val b = bmp ?: return
            if (!m.invert(inv)) return
            val p = floatArrayOf(min(sx, ex), min(sy, ey), max(sx, ex), max(sy, ey))
            inv.mapPoints(p)
            val l = p[0].coerceIn(0f, b.width.toFloat()).toInt()
            val t = p[1].coerceIn(0f, b.height.toFloat()).toInt()
            val r = p[2].coerceIn(0f, b.width.toFloat()).toInt()
            val bt = p[3].coerceIn(0f, b.height.toFloat()).toInt()
            // ignore taps and tiny drags
            if (r - l < 24 || bt - t < 24) return
            onPick?.invoke(Rect(l, t, r, bt))
        }
    }
}
