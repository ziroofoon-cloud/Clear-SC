package app.clearoverlay;

import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

/**
 * One storage the file manager can browse: the phone's own storage, a network share, a cloud account. Paths are plain
 * "/a/b/c" strings that belong to the storage (for local storage they are the real file paths). Everything here blocks:
 * call it from a background thread.
 */
public interface FmFs extends Closeable {
    /** The first folder to show (for local storage the real path of the storage root). */
    String root();

    /** Folder part of [path], or null when [path] is the top of this storage. */
    String parent(String path);

    String join(String dir, String name);

    List<FmItem> list(String dir) throws IOException;

    InputStream open(String path) throws IOException;

    /**
     * Starts writing a file (replaces an existing one). [size] is the number of bytes that will be written, -1 if unknown.
     * Close the stream to finish the file; if the copy failed call [FmAbortable.abort] on it instead when it has one.
     */
    OutputStream create(String path, long size) throws IOException;

    void mkdir(String path) throws IOException;

    /** Deletes a file, or a folder with everything in it. */
    void delete(String path) throws IOException;

    /** Renames inside the same folder. */
    void rename(String path, String newName) throws IOException;

    /** Moves inside this storage without copying; false when that is not possible (the caller copies instead). */
    boolean moveWithin(String from, String to) throws IOException;

    boolean exists(String path) throws IOException;

    /** The real file for local storage, otherwise null. */
    File localFile(String path);

    /** Free space of the storage in bytes, -1 when unknown. */
    long freeSpace();
}
