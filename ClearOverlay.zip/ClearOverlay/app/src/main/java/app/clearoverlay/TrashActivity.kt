package app.clearoverlay

import android.app.Activity
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

/** The phone's trash for pictures, videos and music: restore, or delete for good. */
class TrashActivity : Activity() {
    private class Row(val uri: Uri, val name: String, val type: Int, val size: Long, val expires: Long)

    private var rows: List<Row> = emptyList()
    private val picked = HashSet<Int>()
    private lateinit var list: ListView
    private lateinit var empty: TextView
    private lateinit var info: TextView
    private val adapter = RowAdapter()

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Cfg.bind(this, "screen")
        Ui.init(this)
        setTheme(Ui.theme())
        super.onCreate(savedInstanceState)
        Ui.styleBars(window)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
            setPadding(dp(this@TrashActivity, 14), dp(this@TrashActivity, 14), dp(this@TrashActivity, 14), dp(this@TrashActivity, 10))
        }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(Ui.text(this, getString(R.string.trash_screen_title), 22f, Ui.TEXT, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(chip(getString(R.string.lib_select_all)) { pickAll() })
        top.addView(chip("✕") { finish() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(this@TrashActivity, 6) })
        root.addView(top)
        info = Ui.text(this, getString(R.string.trash_hint), 12f, Ui.MUTED)
        root.addView(info, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@TrashActivity, 6) })

        val frame = android.widget.FrameLayout(this)
        list = ListView(this).apply {
            divider = null
            adapter = this@TrashActivity.adapter
            setOnItemClickListener { _, _, pos, _ ->
                if (!picked.remove(pos)) picked.add(pos)
                this@TrashActivity.adapter.notifyDataSetChanged()
            }
        }
        frame.addView(list)
        empty = Ui.text(this, getString(R.string.trash_empty), 14f, Ui.MUTED).apply { gravity = Gravity.CENTER; visibility = View.GONE }
        frame.addView(empty, android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(frame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = dp(this@TrashActivity, 8) })

        val bar = LinearLayout(this)
        bar.addView(chip(getString(R.string.trash_restore)) { act(true) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(chip(getString(R.string.trash_forever)) { act(false) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(this@TrashActivity, 8) })
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@TrashActivity, 8) })
        setContentView(root)
        reload()
    }

    private fun chip(label: String, onClick: () -> Unit) = Ui.text(this, label, 14f, Ui.ACCENT, true).apply {
        gravity = Gravity.CENTER
        maxLines = 1
        background = Ui.round(Ui.CHIP, dp(this@TrashActivity, 10).toFloat())
        setPadding(dp(this@TrashActivity, 12), dp(this@TrashActivity, 10), dp(this@TrashActivity, 12), dp(this@TrashActivity, 10))
        setOnClickListener { onClick() }
    }

    private fun pickAll() {
        if (picked.size == rows.size) picked.clear() else for (i in rows.indices) picked.add(i)
        adapter.notifyDataSetChanged()
    }

    /** [restore]: bring the chosen files back; otherwise delete them for good. Nothing chosen = all of them. */
    private fun act(restore: Boolean) {
        if (rows.isEmpty()) return
        val sel = if (picked.isEmpty()) rows.map { it.uri } else picked.sorted().mapNotNull { rows.getOrNull(it)?.uri }
        val done = { picked.clear(); reload() }
        if (restore) {
            TrashOps.restore(this, sel, done)
        } else if (picked.isEmpty()) {
            // nothing chosen means "everything": ask once so one tap cannot empty the whole trash
            android.app.AlertDialog.Builder(this)
                .setMessage(getString(R.string.trash_all_forever_fmt, rows.size))
                .setPositiveButton(R.string.trash_forever) { _, _ -> TrashOps.deleteForever(this, sel, done) }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        } else {
            TrashOps.deleteForever(this, sel, done)
        }
    }

    private fun reload() {
        val app = applicationContext
        Thread {
            val out = ArrayList<Row>()
            runCatching {
                val files = MediaStore.Files.getContentUri("external")
                val q = android.os.Bundle().apply {
                    putInt(MediaStore.QUERY_ARG_MATCH_TRASHED, MediaStore.MATCH_ONLY)
                    putString(android.content.ContentResolver.QUERY_ARG_SQL_SELECTION, "media_type IN (1,2,3)")
                    putString(android.content.ContentResolver.QUERY_ARG_SQL_SORT_ORDER, "date_expires")
                }
                val proj = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, "media_type", MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DATE_EXPIRES)
                app.contentResolver.query(files, proj, q, null)?.use { c ->
                    while (c.moveToNext()) {
                        val type = c.getInt(2)
                        val base = when (type) {
                            1 -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                            2 -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                            else -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                        }
                        out.add(Row(ContentUris.withAppendedId(base, c.getLong(0)), c.getString(1) ?: "?", type, c.getLong(3), c.getLong(4)))
                    }
                }
            }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                rows = out
                picked.clear()
                adapter.notifyDataSetChanged()
                empty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
            }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        TrashOps.handleResult(req, res)
    }

    private inner class RowAdapter : BaseAdapter() {
        override fun getCount() = rows.size
        override fun getItem(position: Int) = rows[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val r = rows[position]
            val row = (convertView as? LinearLayout) ?: LinearLayout(this@TrashActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(this@TrashActivity, 12), dp(this@TrashActivity, 9), dp(this@TrashActivity, 12), dp(this@TrashActivity, 9))
                addView(Ui.text(this@TrashActivity, "", 15f, Ui.TEXT).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
                addView(Ui.text(this@TrashActivity, "", 12f, Ui.MUTED).apply { maxLines = 1 })
            }
            val sel = picked.contains(position)
            row.background = if (sel) Ui.round(Ui.CHIP, dp(this@TrashActivity, 10).toFloat(), Ui.ACCENT, dp(this@TrashActivity, 1)) else null
            val icon = when (r.type) { 1 -> "🖼"; 2 -> "♪"; else -> "🎬" }
            (row.getChildAt(0) as TextView).text = "$icon  ${r.name}"
            val days = if (r.expires > 0) ((r.expires * 1000L - System.currentTimeMillis()) / 86_400_000L).toInt().coerceAtLeast(0) else -1
            (row.getChildAt(1) as TextView).text = android.text.format.Formatter.formatShortFileSize(this@TrashActivity, r.size) + if (days >= 0) "  ·  " + getString(R.string.trash_days_fmt, days) else ""
            return row
        }
    }
}
