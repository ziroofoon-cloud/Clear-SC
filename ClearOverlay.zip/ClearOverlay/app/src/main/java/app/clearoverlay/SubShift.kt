package app.clearoverlay

import java.util.Locale

/** Moves every time of a subtitle text (SubRip, WebVTT, SSA / ASS; other kinds are returned as they are) by [delta] milliseconds. Never below 0. */
object SubShift {
    private val srt = Regex("(\\d{1,3}):(\\d{2}):(\\d{2})([,.])(\\d{1,3})\\s*-->\\s*(\\d{1,3}):(\\d{2}):(\\d{2})([,.])(\\d{1,3})")
    private val vtt = Regex("(?:(\\d{1,3}):)?(\\d{2}):(\\d{2})\\.(\\d{3})\\s*-->\\s*(?:(\\d{1,3}):)?(\\d{2}):(\\d{2})\\.(\\d{3})")
    private val assTime = Regex("^(\\d+):(\\d{2}):(\\d{2})\\.(\\d{2})$")

    private fun ms(h: Long, m: Long, s: Long, frac: String): Long {
        val f = (frac + "00").take(3).toLong()
        return ((h * 60 + m) * 60 + s) * 1000L + f
    }

    private fun fmt(t0: Long, comma: Boolean, hours: Boolean = true): String {
        val t = t0.coerceAtLeast(0L)
        val h = t / 3_600_000L
        val m = (t / 60_000L) % 60
        val s = (t / 1000L) % 60
        val f = t % 1000L
        val sep = if (comma) "," else "."
        return if (hours || h > 0) String.format(Locale.US, "%02d:%02d:%02d%s%03d", h, m, s, sep, f)
        else String.format(Locale.US, "%02d:%02d%s%03d", m, s, sep, f)
    }

    fun shift(text: String, name: String, delta: Long): String {
        if (delta == 0L) return text
        val n = name.lowercase(Locale.US)
        return when {
            n.endsWith(".ass") || n.endsWith(".ssa") -> shiftAss(text, delta)
            n.endsWith(".vtt") -> text.lines().joinToString("\n") { ln ->
                vtt.replace(ln) { m ->
                    val g = m.groupValues
                    val a = ms(g[1].ifEmpty { "0" }.toLong(), g[2].toLong(), g[3].toLong(), g[4]) + delta
                    val b = ms(g[5].ifEmpty { "0" }.toLong(), g[6].toLong(), g[7].toLong(), g[8]) + delta
                    fmt(a, false) + " --> " + fmt(b, false)
                }
            }
            n.endsWith(".ttml") || n.endsWith(".xml") || n.endsWith(".dfxp") -> text
            else -> text.lines().joinToString("\n") { ln ->
                srt.replace(ln) { m ->
                    val g = m.groupValues
                    val a = ms(g[1].toLong(), g[2].toLong(), g[3].toLong(), g[5]) + delta
                    val b = ms(g[6].toLong(), g[7].toLong(), g[8].toLong(), g[10]) + delta
                    fmt(a, true) + " --> " + fmt(b, true)
                }
            }
        }
    }

    private fun shiftAss(text: String, delta: Long): String {
        fun conv(t: String): String {
            val m = assTime.find(t.trim()) ?: return t
            val g = m.groupValues
            val v = ((g[1].toLong() * 60 + g[2].toLong()) * 60 + g[3].toLong()) * 1000L + g[4].toLong() * 10L + delta
            val c = v.coerceAtLeast(0L)
            return String.format(Locale.US, "%d:%02d:%02d.%02d", c / 3_600_000L, (c / 60_000L) % 60, (c / 1000L) % 60, (c % 1000L) / 10L)
        }
        return text.lines().joinToString("\n") { ln ->
            if (!ln.startsWith("Dialogue:") && !ln.startsWith("Comment:")) ln
            else {
                val head = ln.substringBefore(':') + ":"
                val p = ln.substring(head.length).split(',', limit = 10).toMutableList()
                if (p.size >= 3) {
                    p[1] = conv(p[1])
                    p[2] = conv(p[2])
                }
                head + p.joinToString(",")
            }
        }
    }
}
