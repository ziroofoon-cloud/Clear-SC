package app.clearoverlay

import android.content.Context
import android.net.Uri
import androidx.media3.common.C
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.TransferListener
import com.hierynomus.msdtyp.AccessMask
import com.hierynomus.msfscc.FileAttributes
import com.hierynomus.mssmb2.SMB2CreateDisposition
import com.hierynomus.mssmb2.SMB2ShareAccess
import com.hierynomus.smbj.SMBClient
import com.hierynomus.smbj.SmbConfig
import com.hierynomus.smbj.auth.AuthenticationContext
import com.hierynomus.smbj.auth.NtlmAuthenticator
import com.hierynomus.smbj.connection.Connection
import com.hierynomus.smbj.session.Session
import com.hierynomus.smbj.share.DiskShare
import org.apache.commons.net.ftp.FTP
import org.apache.commons.net.ftp.FTPClient
import org.apache.commons.net.ftp.FTPReply
import org.json.JSONArray
import org.json.JSONObject
import java.io.Closeable
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.util.EnumSet
import java.util.Locale
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * Network sources: shared folders on the local network (SMB / Windows share) and FTP servers.
 *
 *  - Servers are saved in the app's own preferences ([Net.servers]).
 *  - Files are addressed as  crnet://<serverId>/<path>  so the player, the photo viewer and the manga reader can
 *    stream them like any other uri (the video player reads them in small ranges, so seeking works and nothing
 *    is downloaded to the phone first).
 */
object Net {
    const val SCHEME = "crnet"
    const val SMB = "smb"
    const val FTP = "ftp"

    class Server(
        val id: String,
        val name: String,
        val proto: String,
        val host: String,
        val port: Int,
        val user: String,
        val pass: String,
        /** SMB: the share name (e.g. "Movies"). FTP: unused. */
        val share: String,
        /** Folder to start in ("/" = the root). */
        val path: String
    ) {
    }

    class Entry(val name: String, val isDir: Boolean, val size: Long)

    interface Client : Closeable {
        /** Entries of the folder [path] (no "." / ".."), unsorted. */
        fun list(path: String): List<Entry>

        /** Size of the file in bytes, or -1 when the server does not tell. */
        fun size(path: String): Long

        /** Reads the file from byte [offset]. Closing the stream does not close the client. */
        fun open(path: String, offset: Long): InputStream
    }

    // ---- saved servers --------------------------------------------------------------------------

    private const val PREF = "crsc_net"

    fun servers(ctx: Context): List<Server> {
        val s = ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("servers", null) ?: return emptyList()
        return runCatching {
            val a = JSONArray(s)
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Server(
                    o.getString("id"), o.optString("n"), o.optString("p", SMB), o.optString("h"), o.optInt("o", 0),
                    o.optString("u"), o.optString("w"), o.optString("s"), o.optString("d", "/")
                )
            }
        }.getOrDefault(emptyList())
    }

    fun server(ctx: Context, id: String): Server? = servers(ctx).firstOrNull { it.id == id }

    private fun saveAll(ctx: Context, l: List<Server>) {
        val a = JSONArray()
        for (s in l) {
            a.put(JSONObject().put("id", s.id).put("n", s.name).put("p", s.proto).put("h", s.host).put("o", s.port)
                .put("u", s.user).put("w", s.pass).put("s", s.share).put("d", s.path))
        }
        ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("servers", a.toString()).apply()
    }

    /** Adds the server, or replaces the one with the same id. */
    fun put(ctx: Context, s: Server) {
        val l = servers(ctx).toMutableList()
        val i = l.indexOfFirst { it.id == s.id }
        if (i >= 0) l[i] = s else l.add(s)
        saveAll(ctx, l)
    }

    fun remove(ctx: Context, id: String) = saveAll(ctx, servers(ctx).filter { it.id != id })

    fun newId(): String = java.lang.Long.toString(System.currentTimeMillis(), 36) + (Math.random() * 1296).toInt().toString(36)

    // ---- paths / uris ---------------------------------------------------------------------------

    /** Joins a folder and a name: "/a" + "b" -> "/a/b". */
    fun join(dir: String, name: String): String = (if (dir.endsWith("/")) dir else "$dir/") + name

    fun parent(path: String): String {
        val p = path.trimEnd('/')
        val i = p.lastIndexOf('/')
        return if (i <= 0) "/" else p.substring(0, i)
    }

    fun uriOf(s: Server, path: String): Uri = Uri.Builder().scheme(SCHEME).authority(s.id).path(if (path.startsWith("/")) path else "/$path").build()

    // ---- connecting -----------------------------------------------------------------------------

    /** Connects and logs in. Call from a background thread. Throws with a readable message when it fails. */
    fun connect(s: Server): Client = try {
        if (s.proto == SMB) SmbImpl(s) else FtpImpl(s)
    } catch (e: IOException) {
        throw e
    } catch (e: Exception) {
        throw IOException(e.message ?: e.javaClass.simpleName, e)
    }

    /** Stream of a crnet:// uri (own connection, closed together with the stream). Background thread only. */
    fun openStream(ctx: Context, u: Uri, offset: Long = 0L): InputStream {
        val s = server(ctx, u.host ?: "") ?: throw IOException("server not found")
        val c = connect(s)
        return try {
            val ins = c.open(u.path ?: "/", offset)
            object : InputStream() {
                override fun read(): Int = ins.read()
                override fun read(b: ByteArray, off: Int, len: Int): Int = ins.read(b, off, len)
                override fun available(): Int = ins.available()
                override fun close() {
                    runCatching { ins.close() }
                    runCatching { c.close() }
                }
            }
        } catch (e: Exception) {
            runCatching { c.close() }
            throw if (e is IOException) e else IOException(e.message ?: e.javaClass.simpleName, e)
        }
    }

    // ---- remembering the last folder of each server ----------------------------------------------

    fun lastPath(ctx: Context, id: String): String? =
        ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("last_$id", null)

    fun setLastPath(ctx: Context, id: String, path: String) =
        ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("last_$id", path).apply()

    // ---- finding servers on the local network ---------------------------------------------------

    class Found(val host: String, val smb: Boolean, val ftp: Boolean, val name: String = "")

    /** The device's network name (reverse DNS from the router), or "" when it has none or the lookup is slow. */
    private fun nameOf(host: String): String {
        val ex = Executors.newSingleThreadExecutor()
        return try {
            val f = ex.submit(java.util.concurrent.Callable { java.net.InetAddress.getByName(host).canonicalHostName })
            val n = f.get(1500, TimeUnit.MILLISECONDS)
            if (n == host) "" else n.substringBefore('.')
        } catch (e: Exception) {
            ""
        } finally {
            ex.shutdownNow()
        }
    }

    /** "192.168.1." style prefix of the Wi-Fi / hotspot / ethernet network the phone is on, or null. */
    private fun localPrefix(): String? = try {
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback && listOf("wlan", "eth", "swlan", "ap").any { n -> it.name.startsWith(n) } }
            .flatMap { it.interfaceAddresses.toList() }
            .map { it.address }
            .firstOrNull { it is Inet4Address && it.isSiteLocalAddress }
            ?.hostAddress?.substringBeforeLast('.')?.plus(".")
    } catch (e: Exception) {
        null
    }

    private fun portOpen(host: String, port: Int): Boolean = try {
        Socket().use { it.connect(InetSocketAddress(host, port), 400) }
        true
    } catch (e: Exception) {
        false
    }

    /**
     * Looks for SMB (port 445) and FTP (port 21) servers among the 254 addresses of the phone's own network.
     * Takes a few seconds. [progress] gets (checked, total). Background thread only.
     */
    fun scan(cancel: () -> Boolean, progress: (Int, Int) -> Unit): List<Found> {
        val base = localPrefix() ?: return emptyList()
        val pool = Executors.newFixedThreadPool(48)
        val found = java.util.Collections.synchronizedList(ArrayList<Found>())
        val done = AtomicInteger(0)
        val latch = CountDownLatch(254)
        for (i in 1..254) {
            pool.execute {
                try {
                    if (!cancel()) {
                        val h = base + i
                        val smb = portOpen(h, 445)
                        val ftp = portOpen(h, 21)
                        if (smb || ftp) found.add(Found(h, smb, ftp, nameOf(h)))
                    }
                } finally {
                    progress(done.incrementAndGet(), 254)
                    latch.countDown()
                }
            }
        }
        latch.await()
        pool.shutdownNow()
        return found.sortedBy { it.host.substringAfterLast('.').toIntOrNull() ?: 0 }
    }

    /**
     * Names of the shared folders of an SMB server (hidden / admin shares ending in $ left out). [s].share is ignored.
     * Uses the dcerpc library through reflection, so if it does not fit the smbj version this just throws and the user types the name.
     * Background thread only.
     */
    fun listShares(s: Server): List<String> {
        val client = SMBClient(
            SmbConfig.builder().withTimeout(15, TimeUnit.SECONDS).withSoTimeout(30, TimeUnit.SECONDS)
                .withAuthenticators(NtlmAuthenticator.Factory()).build()
        )
        try {
            val conn = client.connect(s.host, if (s.port > 0) s.port else 445)
            val auth = if (s.user.isEmpty()) AuthenticationContext.guest() else AuthenticationContext(s.user, s.pass.toCharArray(), "")
            val ses = conn.authenticate(auth)
            val tf = Class.forName("com.rapid7.client.dcerpc.transport.SMBTransportFactories")
            val factory = tf.getField("SRVSVC").get(null)
            val m = tf.methods.first { it.name == "getTransport" && it.parameterTypes.size == 1 && it.parameterTypes[0].isAssignableFrom(Session::class.java) }
            val transport = m.invoke(factory, ses)
            val svc = Class.forName("com.rapid7.client.dcerpc.mssrvs.ServerService")
            val inst = svc.constructors.first { it.parameterTypes.size == 1 }.newInstance(transport)
            val res = svc.getMethod("getShares0").invoke(inst) as List<*>
            return res.mapNotNull { it?.javaClass?.getMethod("getNetName")?.invoke(it) as? String }
                .filter { it.isNotEmpty() && !it.endsWith("$") }
                .sortedBy { it.lowercase(Locale.US) }
        } finally {
            runCatching { client.close() }
        }
    }

    // ---- file types -----------------------------------------------------------------------------

    private fun ext(n: String) = n.substringAfterLast('.', "").lowercase(Locale.US)

    fun isVideo(n: String) = ext(n) in setOf("mp4", "mkv", "webm", "avi", "mov", "m4v", "ts", "3gp", "flv", "wmv", "mpg", "mpeg", "m3u8")
    fun isGif(n: String) = ext(n) == "gif"
    fun isAudio(n: String) = ext(n) in setOf("mp3", "m4a", "aac", "flac", "wav", "ogg", "opus", "oga", "wma", "mka", "amr")
    fun isImage(n: String) = ext(n) in setOf("jpg", "jpeg", "png", "webp", "bmp", "heic", "avif")
    fun isManga(n: String) = ext(n) in setOf("cbz", "zip", "pdf", "cbr", "cb7", "rar", "7z")

    // ---- SMB ------------------------------------------------------------------------------------

    private class SmbImpl(s: Server) : Client {
        private val client = SMBClient(
            // NTLM only: the Kerberos classes smbj would otherwise try to load do not exist on Android
            SmbConfig.builder()
                .withTimeout(20, TimeUnit.SECONDS)
                .withSoTimeout(60, TimeUnit.SECONDS)
                .withAuthenticators(NtlmAuthenticator.Factory())
                .build()
        )
        private var conn: Connection? = null
        private var session: Session? = null
        private var share: DiskShare? = null

        init {
            try {
                if (s.share.isBlank()) throw IOException("share name is empty")
                val c = client.connect(s.host, if (s.port > 0) s.port else 445)
                conn = c
                val auth = if (s.user.isEmpty()) AuthenticationContext.guest() else AuthenticationContext(s.user, s.pass.toCharArray(), "")
                val ses = c.authenticate(auth)
                session = ses
                share = ses.connectShare(s.share) as DiskShare
            } catch (e: Exception) {
                close()
                throw if (e is IOException) e else IOException(e.message ?: e.javaClass.simpleName, e)
            }
        }

        private fun p(path: String) = path.trim('/').replace('/', '\\')

        override fun list(path: String): List<Entry> {
            val sh = share ?: throw IOException("not connected")
            return sh.list(p(path)).mapNotNull { f ->
                val n = f.fileName
                if (n == "." || n == "..") return@mapNotNull null
                val dir = (f.fileAttributes and FileAttributes.FILE_ATTRIBUTE_DIRECTORY.value) != 0L
                Entry(n, dir, f.endOfFile)
            }
        }

        override fun size(path: String): Long {
            val sh = share ?: throw IOException("not connected")
            return sh.getFileInformation(p(path)).standardInformation.endOfFile
        }

        override fun open(path: String, offset: Long): InputStream {
            val sh = share ?: throw IOException("not connected")
            val f = sh.openFile(
                p(path), EnumSet.of(AccessMask.GENERIC_READ), null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_OPEN, null
            )
            return object : InputStream() {
                private var pos = offset
                private var closed = false
                override fun read(): Int {
                    val b = ByteArray(1)
                    return if (read(b, 0, 1) <= 0) -1 else b[0].toInt() and 0xFF
                }

                override fun read(b: ByteArray, off: Int, len: Int): Int {
                    if (len == 0) return 0
                    val n = f.read(b, pos, off, len)
                    if (n <= 0) return -1
                    pos += n
                    return n
                }

                override fun close() {
                    if (closed) return
                    closed = true
                    runCatching { f.close() }
                }
            }
        }

        override fun close() {
            runCatching { share?.close() }
            runCatching { session?.close() }
            runCatching { conn?.close() }
            runCatching { client.close() }
            share = null; session = null; conn = null
        }
    }

    // ---- FTP ------------------------------------------------------------------------------------

    private class FtpImpl(s: Server) : Client {
        private val ftp = FTPClient()

        init {
            try {
                ftp.controlEncoding = "UTF-8"
                ftp.connectTimeout = 15000
                ftp.connect(s.host, if (s.port > 0) s.port else 21)
                ftp.soTimeout = 30000
                val user = s.user.ifEmpty { "anonymous" }
                val pass = if (s.user.isEmpty()) "anonymous@" else s.pass
                if (!ftp.login(user, pass)) throw IOException("FTP login failed: " + ftp.replyString.trim())
                ftp.enterLocalPassiveMode()
                ftp.setFileType(org.apache.commons.net.ftp.FTP.BINARY_FILE_TYPE) // plain FTP would mean Net.FTP (the "ftp" string) here
                ftp.setDataTimeout(30000)
            } catch (e: Exception) {
                close()
                throw if (e is IOException) e else IOException(e.message ?: e.javaClass.simpleName, e)
            }
        }

        override fun list(path: String): List<Entry> {
            val a = ftp.listFiles(if (path.isEmpty()) "/" else path) ?: return emptyList()
            return a.filter { it != null && it.name != "." && it.name != ".." }.map { Entry(it.name.substringAfterLast('/'), it.isDirectory, it.size) }
        }

        override fun size(path: String): Long {
            runCatching {
                if (FTPReply.isPositiveCompletion(ftp.sendCommand("SIZE", path))) {
                    val n = ftp.replyString.trim().split(' ').getOrNull(1)?.toLongOrNull()
                    if (n != null) return n
                }
            }
            return runCatching {
                ftp.listFiles(path)?.firstOrNull { !it.isDirectory }?.size ?: -1L
            }.getOrDefault(-1L)
        }

        override fun open(path: String, offset: Long): InputStream {
            ftp.restartOffset = offset
            val ins = ftp.retrieveFileStream(path) ?: throw IOException("FTP: " + ftp.replyString.trim())
            return object : InputStream() {
                override fun read(): Int = ins.read()
                override fun read(b: ByteArray, off: Int, len: Int): Int = ins.read(b, off, len)
                override fun close() {
                    // abort the transfer instead of reading the rest of a big file
                    runCatching { ftp.abort() }
                    runCatching { ins.close() }
                }
            }
        }

        override fun close() {
            runCatching { if (ftp.isConnected) ftp.logout() }
            runCatching { if (ftp.isConnected) ftp.disconnect() }
        }
    }

    // ---- download (images / manga / gif that need a real file) ---------------------------------

    fun cacheDir(ctx: Context): File = File(ctx.cacheDir, "net").also { it.mkdirs() }

    /** Removes downloaded files that are old or exceed the size cap (see [Storage.autoClean]). */
    fun cleanCache(ctx: Context) = Storage.autoClean(ctx)

    /**
     * Copies a network file to the cache and returns it. [onProgress] gets (bytes so far, total or -1); return false
     * from [keepGoing] to cancel. Background thread only.
     */
    fun download(ctx: Context, u: Uri, onProgress: (Long, Long) -> Unit, keepGoing: () -> Boolean): File {
        val s = server(ctx, u.host ?: "") ?: throw IOException("server not found")
        val name = (u.lastPathSegment ?: "file").replace(Regex("[^A-Za-z0-9._-]"), "_")
        val out = File(cacheDir(ctx), Integer.toHexString(u.toString().hashCode()) + "_" + name)
        val c = connect(s)
        try {
            val total = runCatching { c.size(u.path ?: "/") }.getOrDefault(-1L)
            if (out.exists() && total > 0 && out.length() == total) {
                out.setLastModified(System.currentTimeMillis())
                return out
            }
            val tmp = File(out.path + ".part")
            c.open(u.path ?: "/", 0).use { ins ->
                tmp.outputStream().use { o ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    while (true) {
                        if (!keepGoing()) throw IOException("cancelled")
                        val n = ins.read(buf)
                        if (n < 0) break
                        o.write(buf, 0, n)
                        done += n
                        onProgress(done, total)
                    }
                }
            }
            if (out.exists()) out.delete()
            if (!tmp.renameTo(out)) throw IOException("cannot save file")
            return out
        } finally {
            runCatching { c.close() }
        }
    }
}

// ---- video streaming ----------------------------------------------------------------------------

/** Reads crnet:// uris for ExoPlayer: opens the file at the wanted byte position, so seeking works without a download. */
@Suppress("UnsafeOptInUsageError")
class NetDataSource(private val ctx: Context) : BaseDataSource(true) {
    private var uri: Uri? = null
    private var client: Net.Client? = null
    private var stream: InputStream? = null
    private var remaining = 0L
    private var opened = false

    override fun open(dataSpec: DataSpec): Long {
        val u = dataSpec.uri
        uri = u
        transferInitializing(dataSpec)
        try {
            val s = Net.server(ctx, u.host ?: "") ?: throw IOException("server not found")
            val c = Net.connect(s)
            client = c
            val path = u.path ?: "/"
            val size = c.size(path)
            stream = c.open(path, dataSpec.position)
            remaining = when {
                dataSpec.length != C.LENGTH_UNSET.toLong() -> dataSpec.length
                size >= 0 -> (size - dataSpec.position).coerceAtLeast(0)
                else -> C.LENGTH_UNSET.toLong()
            }
        } catch (e: Exception) {
            close()
            throw if (e is IOException) e else IOException(e.message ?: e.javaClass.simpleName, e)
        }
        opened = true
        transferStarted(dataSpec)
        return remaining
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        if (remaining == 0L) return C.RESULT_END_OF_INPUT
        val unknown = remaining == C.LENGTH_UNSET.toLong()
        val want = if (unknown) length else minOf(length.toLong(), remaining).toInt()
        val n = stream?.read(buffer, offset, want) ?: return C.RESULT_END_OF_INPUT
        if (n < 0) return C.RESULT_END_OF_INPUT
        if (!unknown) remaining -= n
        bytesTransferred(n)
        return n
    }

    override fun getUri(): Uri? = uri

    override fun close() {
        runCatching { stream?.close() }
        runCatching { client?.close() }
        stream = null
        client = null
        uri = null
        if (opened) {
            opened = false
            transferEnded()
        }
    }
}

/** Normal sources (files, http, hls ...) as usual; crnet:// goes to [NetDataSource]. */
@Suppress("UnsafeOptInUsageError")
class RoutingDataSourceFactory(private val ctx: Context) : DataSource.Factory {
    private val def = DefaultDataSource.Factory(ctx)

    override fun createDataSource(): DataSource = Routing(ctx, def.createDataSource())

    private class Routing(private val ctx: Context, private val base: DataSource) : DataSource {
        private val listeners = ArrayList<TransferListener>()
        private var active: DataSource? = null

        override fun addTransferListener(transferListener: TransferListener) {
            listeners.add(transferListener)
            base.addTransferListener(transferListener)
        }

        override fun open(dataSpec: DataSpec): Long {
            val ds: DataSource = if (dataSpec.uri.scheme == Net.SCHEME) {
                NetDataSource(ctx).also { n -> listeners.forEach { n.addTransferListener(it) } }
            } else base
            active = ds
            return ds.open(dataSpec)
        }

        override fun read(buffer: ByteArray, offset: Int, length: Int): Int = active?.read(buffer, offset, length) ?: C.RESULT_END_OF_INPUT

        override fun getUri(): Uri? = active?.uri

        override fun getResponseHeaders(): Map<String, List<String>> = active?.responseHeaders ?: emptyMap()

        override fun close() {
            try {
                active?.close()
            } finally {
                active = null
            }
        }
    }
}
