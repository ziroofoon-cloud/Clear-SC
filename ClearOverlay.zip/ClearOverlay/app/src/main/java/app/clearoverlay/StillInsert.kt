package app.clearoverlay

import android.content.Context
import android.graphics.Bitmap
import android.graphics.SurfaceTexture
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLUtils
import android.os.Handler
import android.os.Looper
import android.view.Surface
import java.io.FileDescriptor
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Shows a picture for a few seconds at the start and / or the end of a video. The video is decoded, drawn with OpenGL (together
 * with the picture) and encoded again as H.264 into an MP4, so this one is NOT lossless, unlike the plain cut. The picture is
 * fitted inside the frame (black bars), the sound is copied as it is and shifted by the length of the first picture.
 */
class StillInsert(private val ctx: Context) {
    class Opts(
        val src: Uri,
        val image: Bitmap,
        val atStart: Boolean,
        val atEnd: Boolean,
        val stillSec: Float,
        val startUs: Long,
        val endUs: Long,          // <= 0: to the end
        val rotation: Int,        // total turn written into the file (degrees)
        val keepSound: Boolean
    )

    private val main = Handler(Looper.getMainLooper())

    fun run(out: FileDescriptor, o: Opts, cancel: AtomicBoolean, progress: (Float) -> Unit) {
        val vx = MediaExtractor()
        var ax: MediaExtractor? = null
        var dec: MediaCodec? = null
        var enc: MediaCodec? = null
        var mux: MediaMuxer? = null
        var dpy: EGLDisplay = EGL14.EGL_NO_DISPLAY
        var egl: EGLContext = EGL14.EGL_NO_CONTEXT
        var eglSurf: EGLSurface = EGL14.EGL_NO_SURFACE
        var st: SurfaceTexture? = null
        var decSurface: Surface? = null
        var encSurface: Surface? = null
        var started = false
        try {
            vx.setDataSource(ctx, o.src, null)
            var vTr = -1
            var aTr = -1
            for (i in 0 until vx.trackCount) {
                val m = vx.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
                if (m.startsWith("video/") && vTr < 0) vTr = i
                if (m.startsWith("audio/") && aTr < 0) aTr = i
            }
            if (vTr < 0) throw IllegalStateException("no video")
            val vf = vx.getTrackFormat(vTr)
            val w = (vf.getInteger(MediaFormat.KEY_WIDTH) and 1.inv()).coerceAtLeast(2)
            val h = (vf.getInteger(MediaFormat.KEY_HEIGHT) and 1.inv()).coerceAtLeast(2)
            val fps = runCatching { vf.getInteger(MediaFormat.KEY_FRAME_RATE) }.getOrNull()?.takeIf { it in 10..60 } ?: 30
            val bitrate = (w.toLong() * h * fps / 8).toInt().coerceIn(1_500_000, 40_000_000)
            var audioFmt: MediaFormat? = null
            if (o.keepSound && aTr >= 0) {
                val x = MediaExtractor()
                ax = x
                x.setDataSource(ctx, o.src, null)
                x.selectTrack(aTr)
                audioFmt = x.getTrackFormat(aTr)
            }

            // ---- encoder (H.264) with an input surface
            val ef = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
                setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }
            val e = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            enc = e
            e.configure(ef, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            encSurface = e.createInputSurface()
            e.start()

            // ---- EGL on the encoder's surface
            dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
            val ver = IntArray(2)
            EGL14.eglInitialize(dpy, ver, 0, ver, 1)
            val cfgAttr = intArrayOf(
                EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8,
                EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                0x3142, 1, // EGL_RECORDABLE_ANDROID
                EGL14.EGL_NONE
            )
            val cfgs = arrayOfNulls<EGLConfig>(1)
            val nCfg = IntArray(1)
            EGL14.eglChooseConfig(dpy, cfgAttr, 0, cfgs, 0, 1, nCfg, 0)
            if (nCfg[0] < 1) throw IllegalStateException("no EGL config")
            egl = EGL14.eglCreateContext(dpy, cfgs[0], EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
            eglSurf = EGL14.eglCreateWindowSurface(dpy, cfgs[0], encSurface, intArrayOf(EGL14.EGL_NONE), 0)
            if (!EGL14.eglMakeCurrent(dpy, eglSurf, eglSurf, egl)) throw IllegalStateException("EGL make current failed")
            GLES20.glViewport(0, 0, w, h)

            // ---- programs and textures
            val vs = "uniform mat4 uMvp;uniform mat4 uTex;attribute vec4 aPos;attribute vec4 aTc;varying vec2 vTc;" +
                "void main(){gl_Position=uMvp*aPos;vTc=(uTex*aTc).xy;}"
            val fsOes = "#extension GL_OES_EGL_image_external : require\nprecision mediump float;varying vec2 vTc;" +
                "uniform samplerExternalOES sTex;void main(){gl_FragColor=texture2D(sTex,vTc);}"
            val fs2d = "precision mediump float;varying vec2 vTc;uniform sampler2D sTex;void main(){gl_FragColor=texture2D(sTex,vTc);}"
            val pOes = program(vs, fsOes)
            val p2d = program(vs, fs2d)
            val texs = IntArray(2)
            GLES20.glGenTextures(2, texs, 0)
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texs[0])
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
            // the picture is turned the opposite way of the file's rotation, so it looks upright when the player turns the video
            val img = turn(o.image, (360 - o.rotation % 360) % 360)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texs[1])
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
            GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, img, 0)
            val imgAspect = img.width.toFloat() / img.height
            val frameAspect = w.toFloat() / h
            val fitX = minOf(1f, imgAspect / frameAspect)
            val fitY = minOf(1f, frameAspect / imgAspect)

            val quad = ByteBuffer.allocateDirect(16 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
                put(floatArrayOf(-1f, -1f, 0f, 0f, 1f, -1f, 1f, 0f, -1f, 1f, 0f, 1f, 1f, 1f, 1f, 1f))
                position(0)
            }
            val ident = FloatArray(16).also { android.opengl.Matrix.setIdentityM(it, 0) }
            fun draw(prog: Int, target: Int, tex: Int, mvp: FloatArray, tm: FloatArray) {
                GLES20.glUseProgram(prog)
                GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
                GLES20.glBindTexture(target, tex)
                GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, "sTex"), 0)
                GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(prog, "uMvp"), 1, false, mvp, 0)
                GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(prog, "uTex"), 1, false, tm, 0)
                val ap = GLES20.glGetAttribLocation(prog, "aPos")
                val at = GLES20.glGetAttribLocation(prog, "aTc")
                quad.position(0)
                GLES20.glEnableVertexAttribArray(ap)
                GLES20.glVertexAttribPointer(ap, 2, GLES20.GL_FLOAT, false, 16, quad)
                quad.position(2)
                GLES20.glEnableVertexAttribArray(at)
                GLES20.glVertexAttribPointer(at, 2, GLES20.GL_FLOAT, false, 16, quad)
                GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
                GLES20.glDisableVertexAttribArray(ap)
                GLES20.glDisableVertexAttribArray(at)
            }
            val stillMvp = FloatArray(16).also { android.opengl.Matrix.setIdentityM(it, 0); android.opengl.Matrix.scaleM(it, 0, fitX, fitY, 1f) }
            val flipY = floatArrayOf(1f, 0f, 0f, 0f, 0f, -1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 1f, 0f, 1f)

            // ---- muxer: the tracks are added when the encoder tells its format
            val muxer = MediaMuxer(out, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            mux = muxer
            var vTrack = -1
            var aTrack = -1
            val ei = MediaCodec.BufferInfo()
            fun drain(eos: Boolean) {
                var spins = 0
                while (true) {
                    val idx = e.dequeueOutputBuffer(ei, if (eos) 10_000L else 0L)
                    if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                        if (!eos) return
                        if (++spins > 400) return
                        continue
                    }
                    if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        vTrack = muxer.addTrack(e.outputFormat)
                        audioFmt?.let { aTrack = muxer.addTrack(it) }
                        runCatching { muxer.setOrientationHint(o.rotation % 360) }
                        muxer.start()
                        started = true
                        continue
                    }
                    if (idx >= 0) {
                        val b = e.getOutputBuffer(idx)
                        if ((ei.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) ei.size = 0
                        if (b != null && ei.size > 0 && started) {
                            b.position(ei.offset)
                            b.limit(ei.offset + ei.size)
                            muxer.writeSampleData(vTrack, b, ei)
                        }
                        e.releaseOutputBuffer(idx, false)
                        if ((ei.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                    }
                }
            }

            val stillUs = (o.stillSec * 1_000_000f).toLong()
            val frameUs = 1_000_000L / fps
            fun stillFrames(fromUs: Long) {
                val n = (stillUs / frameUs).toInt().coerceAtLeast(1)
                for (i in 0 until n) {
                    if (cancel.get()) throw IllegalStateException("cancelled")
                    GLES20.glClearColor(0f, 0f, 0f, 1f)
                    GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
                    draw(p2d, GLES20.GL_TEXTURE_2D, texs[1], stillMvp, flipY)
                    EGLExt.eglPresentationTimeANDROID(dpy, eglSurf, (fromUs + i * frameUs) * 1000L)
                    EGL14.eglSwapBuffers(dpy, eglSurf)
                    drain(false)
                }
            }

            var shift = 0L
            if (o.atStart) {
                stillFrames(0L)
                shift = stillUs
            }

            // ---- the video itself
            val lock = Object()
            var frameAvail = false
            val tex = SurfaceTexture(texs[0])
            st = tex
            tex.setOnFrameAvailableListener({ synchronized(lock) { frameAvail = true; lock.notifyAll() } }, main)
            val ds = Surface(tex)
            decSurface = ds
            val mime = vf.getString(MediaFormat.KEY_MIME) ?: throw IllegalStateException("no video")
            val d = MediaCodec.createDecoderByType(mime)
            dec = d
            // the decoder must NOT turn the picture itself: the frames are written as stored and the file's rotation is set at the end
            vf.setInteger(MediaFormat.KEY_ROTATION, 0)
            d.configure(vf, ds, null, 0)
            d.start()
            vx.selectTrack(vTr)
            if (o.startUs > 0) vx.seekTo(o.startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            val di = MediaCodec.BufferInfo()
            val tm = FloatArray(16)
            var inDone = false
            var outDone = false
            var lastTs = shift
            val spanUs = if (o.endUs > o.startUs) o.endUs - o.startUs else 0L
            while (!outDone) {
                if (cancel.get()) throw IllegalStateException("cancelled")
                if (!inDone) {
                    val i = d.dequeueInputBuffer(5000L)
                    if (i >= 0) {
                        val b = d.getInputBuffer(i)
                        val n = if (b != null) vx.readSampleData(b, 0) else -1
                        if (n < 0 || (o.endUs > 0 && vx.sampleTime > o.endUs)) {
                            d.queueInputBuffer(i, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            d.queueInputBuffer(i, 0, n, vx.sampleTime, 0)
                            vx.advance()
                        }
                    }
                }
                val oi = d.dequeueOutputBuffer(di, 5000L)
                if (oi >= 0) {
                    val pts = di.presentationTimeUs
                    val render = di.size > 0 && pts >= o.startUs && (o.endUs <= 0 || pts <= o.endUs)
                    if (render) synchronized(lock) { frameAvail = false }
                    d.releaseOutputBuffer(oi, render)
                    if (render) {
                        synchronized(lock) {
                            val t0 = System.currentTimeMillis()
                            while (!frameAvail) {
                                lock.wait(300)
                                if (System.currentTimeMillis() - t0 > 4000) throw IllegalStateException("decoder gave no frame")
                            }
                        }
                        tex.updateTexImage()
                        tex.getTransformMatrix(tm)
                        GLES20.glClearColor(0f, 0f, 0f, 1f)
                        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
                        draw(pOes, GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texs[0], ident, tm)
                        lastTs = pts - o.startUs + shift
                        EGLExt.eglPresentationTimeANDROID(dpy, eglSurf, lastTs * 1000L)
                        EGL14.eglSwapBuffers(dpy, eglSurf)
                        drain(false)
                        if (spanUs > 0) progress(((pts - o.startUs).toFloat() / spanUs).coerceIn(0f, 1f) * 0.9f)
                    }
                    if ((di.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true
                }
            }
            if (o.atEnd) stillFrames(lastTs + frameUs)
            e.signalEndOfInputStream()
            drain(true)

            // ---- the sound, copied as it is (shifted when a picture comes first)
            val x = ax
            if (x != null && started && aTrack >= 0) {
                if (o.startUs > 0) x.seekTo(o.startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
                val buf = ByteBuffer.allocate(1 shl 20)
                val ai = MediaCodec.BufferInfo()
                while (!cancel.get()) {
                    buf.clear()
                    val n = x.readSampleData(buf, 0)
                    if (n < 0) break
                    val t = x.sampleTime
                    if (o.endUs > 0 && t > o.endUs) break
                    if (t >= o.startUs) {
                        ai.set(0, n, t - o.startUs + shift, 0)
                        muxer.writeSampleData(aTrack, buf, ai)
                    }
                    x.advance()
                }
            }
            if (cancel.get()) throw IllegalStateException("cancelled")
            progress(1f)
        } finally {
            runCatching { dec?.stop() }; runCatching { dec?.release() }
            runCatching { enc?.stop() }; runCatching { enc?.release() }
            runCatching { if (started) mux?.stop() }; runCatching { mux?.release() }
            runCatching { st?.release() }
            runCatching { decSurface?.release() }
            runCatching { encSurface?.release() }
            if (dpy != EGL14.EGL_NO_DISPLAY) {
                runCatching { EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT) }
                if (eglSurf != EGL14.EGL_NO_SURFACE) runCatching { EGL14.eglDestroySurface(dpy, eglSurf) }
                if (egl != EGL14.EGL_NO_CONTEXT) runCatching { EGL14.eglDestroyContext(dpy, egl) }
                runCatching { EGL14.eglTerminate(dpy) }
            }
            runCatching { ax?.release() }
            runCatching { vx.release() }
        }
    }

    private fun turn(b: Bitmap, deg: Int): Bitmap {
        if (deg == 0) return b
        val m = android.graphics.Matrix().apply { postRotate(deg.toFloat()) }
        return Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
    }

    private fun program(vs: String, fs: String): Int {
        fun shader(type: Int, src: String): Int {
            val s = GLES20.glCreateShader(type)
            GLES20.glShaderSource(s, src)
            GLES20.glCompileShader(s)
            val ok = IntArray(1)
            GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
            if (ok[0] == 0) throw IllegalStateException("shader: " + GLES20.glGetShaderInfoLog(s))
            return s
        }
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, shader(GLES20.GL_VERTEX_SHADER, vs))
        GLES20.glAttachShader(p, shader(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(p)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw IllegalStateException("link: " + GLES20.glGetProgramInfoLog(p))
        return p
    }
}
