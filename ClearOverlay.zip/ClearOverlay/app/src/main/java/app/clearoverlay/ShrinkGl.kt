package app.clearoverlay

import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.os.Handler
import android.os.Looper
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

/**
 * The window a video encoder offers as its input ([android.media.MediaCodec.createInputSurface]) seen as an EGL surface.
 * Pictures are drawn into it with OpenGL and stamped with their own time, which is the way that works on every phone
 * (the old code let the decoder draw straight into the encoder's surface: no scaling of the picture, and the picture
 * could come out broken on phones whose encoder does not take another size). All calls must come from ONE thread.
 */
internal class ShrinkInput(private val surface: Surface) {
    private var dpy: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var ctx: EGLContext = EGL14.EGL_NO_CONTEXT
    private var srf: EGLSurface = EGL14.EGL_NO_SURFACE

    init {
        try {
            dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
            if (dpy === EGL14.EGL_NO_DISPLAY) throw IllegalStateException("no EGL display")
            val v = IntArray(2)
            if (!EGL14.eglInitialize(dpy, v, 0, v, 1)) throw IllegalStateException("EGL did not start")
            val cfg = pickConfig(true) ?: pickConfig(false) ?: throw IllegalStateException("no EGL configuration")
            ctx = EGL14.eglCreateContext(dpy, cfg, EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
            if (ctx === EGL14.EGL_NO_CONTEXT) throw IllegalStateException("no EGL context")
            srf = EGL14.eglCreateWindowSurface(dpy, cfg, surface, intArrayOf(EGL14.EGL_NONE), 0)
            if (srf === EGL14.EGL_NO_SURFACE) throw IllegalStateException("no EGL surface for the encoder")
        } catch (t: Throwable) {
            release()
            throw t
        }
    }

    private fun pickConfig(recordable: Boolean): EGLConfig? {
        val a = ArrayList<Int>()
        a.addAll(listOf(EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT))
        if (recordable) a.addAll(listOf(0x3142, 1)) // EGL_RECORDABLE_ANDROID
        a.add(EGL14.EGL_NONE)
        val cfgs = arrayOfNulls<EGLConfig>(1)
        val n = IntArray(1)
        val ok = EGL14.eglChooseConfig(dpy, a.toIntArray(), 0, cfgs, 0, 1, n, 0)
        return if (ok && n[0] > 0) cfgs[0] else null
    }

    fun makeCurrent() {
        if (!EGL14.eglMakeCurrent(dpy, srf, srf, ctx)) throw IllegalStateException("EGL makeCurrent failed")
    }

    fun setPresentationTime(ns: Long) {
        EGLExt.eglPresentationTimeANDROID(dpy, srf, ns)
    }

    fun swap(): Boolean = EGL14.eglSwapBuffers(dpy, srf)

    fun release() {
        if (dpy !== EGL14.EGL_NO_DISPLAY) {
            runCatching { EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT) }
            if (srf !== EGL14.EGL_NO_SURFACE) runCatching { EGL14.eglDestroySurface(dpy, srf) }
            if (ctx !== EGL14.EGL_NO_CONTEXT) runCatching { EGL14.eglDestroyContext(dpy, ctx) }
            runCatching { EGL14.eglReleaseThread() }
            runCatching { EGL14.eglTerminate(dpy) }
        }
        dpy = EGL14.EGL_NO_DISPLAY
        ctx = EGL14.EGL_NO_CONTEXT
        srf = EGL14.EGL_NO_SURFACE
        runCatching { surface.release() }
    }
}

/**
 * The window a video decoder draws into: a texture the GPU can read. [draw] puts the newest picture on the current EGL surface
 * (the encoder's), scaled to its size. The EGL context of [ShrinkInput] must be current on the calling thread when this is made.
 */
internal class ShrinkOutput {
    private val texId: Int
    private val st: SurfaceTexture
    val surface: Surface
    private val lock = Object()
    private var available = false
    private var prog = 0
    private val mtx = FloatArray(16)
    private val quad: FloatBuffer = ByteBuffer.allocateDirect(16 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
        put(floatArrayOf(-1f, -1f, 0f, 0f, 1f, -1f, 1f, 0f, -1f, 1f, 0f, 1f, 1f, 1f, 1f, 1f))
        position(0)
    }

    init {
        val t = IntArray(1)
        GLES20.glGenTextures(1, t, 0)
        texId = t[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        st = SurfaceTexture(texId)
        // the callback comes on the main thread (this worker thread has no message loop); the worker only waits for the flag
        st.setOnFrameAvailableListener({ synchronized(lock) { available = true; lock.notifyAll() } }, Handler(Looper.getMainLooper()))
        surface = Surface(st)
        prog = link(
            "uniform mat4 uM;\nattribute vec4 aP;\nattribute vec2 aT;\nvarying vec2 vT;\nvoid main(){ gl_Position = aP; vT = (uM * vec4(aT, 0.0, 1.0)).xy; }\n",
            "#extension GL_OES_EGL_image_external : require\nprecision mediump float;\nvarying vec2 vT;\nuniform samplerExternalOES sT;\nvoid main(){ gl_FragColor = texture2D(sT, vT); }\n"
        )
    }

    private fun shader(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) { val log = GLES20.glGetShaderInfoLog(s); GLES20.glDeleteShader(s); throw IllegalStateException("shader: $log") }
        return s
    }

    private fun link(vs: String, fs: String): Int {
        val v = shader(GLES20.GL_VERTEX_SHADER, vs)
        val f = shader(GLES20.GL_FRAGMENT_SHADER, fs)
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, v)
        GLES20.glAttachShader(p, f)
        GLES20.glLinkProgram(p)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        GLES20.glDeleteShader(v)
        GLES20.glDeleteShader(f)
        if (ok[0] == 0) { val log = GLES20.glGetProgramInfoLog(p); GLES20.glDeleteProgram(p); throw IllegalStateException("program: $log") }
        return p
    }

    /** Waits until the decoder has delivered the picture it was told to draw, and makes it the current texture. False when it does not come. */
    fun awaitNewImage(timeoutMs: Long): Boolean {
        val end = System.nanoTime() + timeoutMs * 1_000_000L
        synchronized(lock) {
            while (!available) {
                val left = (end - System.nanoTime()) / 1_000_000L
                if (left <= 0L) return false
                try { lock.wait(left) } catch (e: InterruptedException) { return false }
            }
            available = false
        }
        st.updateTexImage()
        return true
    }

    /** The newest picture, over the whole current surface of w x h pixels (a smaller size scales it). */
    fun draw(w: Int, h: Int) {
        st.getTransformMatrix(mtx)
        GLES20.glViewport(0, 0, w, h)
        GLES20.glDisable(GLES20.GL_BLEND)
        GLES20.glUseProgram(prog)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId)
        GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, "sT"), 0)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(prog, "uM"), 1, false, mtx, 0)
        val pl = GLES20.glGetAttribLocation(prog, "aP")
        val tl = GLES20.glGetAttribLocation(prog, "aT")
        quad.position(0)
        GLES20.glVertexAttribPointer(pl, 2, GLES20.GL_FLOAT, false, 16, quad)
        GLES20.glEnableVertexAttribArray(pl)
        quad.position(2)
        GLES20.glVertexAttribPointer(tl, 2, GLES20.GL_FLOAT, false, 16, quad)
        GLES20.glEnableVertexAttribArray(tl)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(pl)
        GLES20.glDisableVertexAttribArray(tl)
    }

    fun release() {
        runCatching { surface.release() }
        runCatching { st.setOnFrameAvailableListener(null) }
        runCatching { st.release() }
        runCatching { if (prog != 0) GLES20.glDeleteProgram(prog) }
        runCatching { GLES20.glDeleteTextures(1, intArrayOf(texId), 0) }
    }
}
