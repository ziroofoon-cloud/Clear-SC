package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.graphics.Bitmap
import android.util.LruCache
import android.util.Size
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * "Free up space": lists the biggest videos and photos of the phone; tick some, pick how small, and they are written again
 * smaller next to the originals (see [Shrink]). Afterwards the originals can be deleted (only the ones that really got smaller).
 */
class ShrinkActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private var videos: List<Shrink.Item> = emptyList()
    private var photos: List<Shrink.Item> = emptyList()
    private var music: List<Shrink.Item> = emptyList()
    private var comics: List<Shrink.Item> = emptyList()
    private var loaded = false
    private var tab = 0          // 0 = videos, 1 = photos, 2 = music, 3 = comics
    private var quality = -1     // -1 recommended (the level is chosen per file), 0 balanced, 1 small, 2 tiny
    private val picked = LinkedHashSet<Uri>()
    private lateinit var page: EditUi.Page
    private lateinit var listBox: LinearLayout
    private lateinit var info: TextView
    private lateinit var qualityHint: TextView
    private lateinit var action: TextView
    private var working = false
    private var sortMode = 0     // 0 biggest first, 1 oldest first, 2 newest first, 3 by name
    private val thumbs = object : LruCache<Uri, Bitmap>(60) {}
    private val thumbPool = Executors.newFixedThreadPool(2)
    private var renderGen = 0 // grows with every new list: thumbnails still waiting for an older list are dropped at once
    private var selAllBtn: TextView? = null

    override fun onDestroy() {
        thumbPool.shutdownNow()
        super.onDestroy()
    }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Cfg.ensureLoaded(this)
        Ui.init(this)
        setTheme(Ui.theme())
        super.onCreate(savedInstanceState)
        Ui.styleBars(window)
        page = EditUi.page(this, getString(R.string.shrink_title), getString(R.string.shrink_hint))
        val a = this
        val top = EditUi.card(a, null)
        top.addView(chipRow(a, listOf(getString(R.string.shrink_videos), getString(R.string.shrink_photos), getString(R.string.shrink_music), getString(R.string.shrink_comics)), 0) { tab = it; render() })
        top.addView(Ui.text(a, getString(R.string.shrink_quality), 12f, Ui.MUTED), EditUi.lp(a, 10))
        top.addView(
            chipRow(a, listOf(getString(R.string.shrink_q_rec), getString(R.string.shrink_q0), getString(R.string.shrink_q1), getString(R.string.shrink_q2)), 0) { quality = it - 1; paintQuality(); updateAction(); render() },
            EditUi.lp(a, 4)
        )
        qualityHint = Ui.text(a, "", 12f, Ui.ACCENT2)
        top.addView(qualityHint, EditUi.lp(a, 6))
        // any file of the phone (also small ones, or ones the list does not show): pick it by hand
        top.addView(
            Ui.text(a, getString(R.string.shrink_pick), 14f, Ui.ACCENT, true).apply {
                gravity = Gravity.CENTER
                background = Ui.round(Ui.CHIP, dp(a, 12).toFloat(), Ui.ACCENT, dp(a, 1))
                setOnClickListener { pickFiles() }
            },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(a, 42)).apply { topMargin = dp(a, 10) }
        )
        page.body.addView(top)
        info = Ui.text(a, "", 12f, Ui.MUTED)
        page.body.addView(info, EditUi.lp(a, 10))
        listBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        page.body.addView(listBox, EditUi.lp(a, 6))
        action = TextView(a).apply {
            gravity = Gravity.CENTER
            textSize = 15f
            setTextColor(Ui.BG)
            background = Ui.gradient(dp(a, 14).toFloat())
            setPadding(0, dp(a, 13), 0, dp(a, 13))
            setOnClickListener { start() }
        }
        page.bottom.addView(action)
        setContentView(page.root)
        paintQuality()
        if (hasAccess()) reload() else requestPermissions(perms(), REQ_PERM)
    }

    // the same permission check as the Library (Android 12 and older use READ_EXTERNAL_STORAGE; the READ_MEDIA_* ones do not exist there)
    private fun perms() = Media.permissions()
    private fun hasAccess() = Media.granted(this)

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (hasAccess()) reload() else info.text = getString(R.string.shrink_no_access)
    }

    private fun pickFiles() {
        AlertDialog.Builder(this)
            .setItems(arrayOf(getString(R.string.shrink_pick_lib_v), getString(R.string.shrink_pick_lib_p), getString(R.string.export_pick_files), getString(R.string.shrink_pick_comic), getString(R.string.shrink_pick_music_lib), getString(R.string.shrink_pick_music))) { _, w ->
                if (w == 5) pickMusic() else if (w == 4) {
                    @Suppress("DEPRECATION")
                    startActivityForResult(android.content.Intent(this, LibraryActivity::class.java).putExtra(LibraryArgs.PICK, true).putExtra(LibraryArgs.PICK_TAB, 4), REQ_MUSIC)
                } else if (w == 3) pickComics() else if (w == 2) pickFromFiles() else {
                    @Suppress("DEPRECATION")
                    startActivityForResult(
                        android.content.Intent(this, LibraryActivity::class.java).putExtra(LibraryArgs.PICK, true).putExtra(LibraryArgs.PICK_TAB, w),
                        REQ_PICK_LIB
                    )
                }
            }
            .show()
    }

    private fun pickComics() {
        val i = android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(android.content.Intent.CATEGORY_OPENABLE)
            .setType("*/*")
            .putExtra(android.content.Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-7z-compressed", "application/x-cb7", "application/x-cbz", "application/vnd.comicbook+zip", "application/octet-stream"))
            .putExtra(android.content.Intent.EXTRA_ALLOW_MULTIPLE, true)
        @Suppress("DEPRECATION")
        runCatching { startActivityForResult(i, REQ_COMIC) }
    }

    private fun pickMusic() {
        val i = android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(android.content.Intent.CATEGORY_OPENABLE)
            .setType("audio/*")
            .putExtra(android.content.Intent.EXTRA_ALLOW_MULTIPLE, true)
        @Suppress("DEPRECATION")
        runCatching { startActivityForResult(i, REQ_MUSIC) }
    }

    private fun startMusic(uris: List<Uri>) {
        val app = applicationContext
        Thread {
            val items = uris.distinct().mapNotNull { Shrink.audioItem(app, it) }
            ui.post {
                if (isDestroyed) return@post
                if (items.isEmpty()) { Toast.makeText(this, R.string.shrink_music_none, Toast.LENGTH_LONG).show(); return@post }
                runShrink(items)
            }
        }.start()
    }

    private fun startComics(uris: List<Uri>) {
        val app = applicationContext
        Thread {
            val items = uris.distinct().mapNotNull { Shrink.comicItem(app, it) }
            ui.post {
                if (isDestroyed) return@post
                if (items.isEmpty()) { Toast.makeText(this, R.string.shrink_comic_none, Toast.LENGTH_LONG).show(); return@post }
                runShrink(items)
            }
        }.start()
    }

    private fun pickFromFiles() {
        val i = android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(android.content.Intent.CATEGORY_OPENABLE)
            .setType("*/*")
            .putExtra(android.content.Intent.EXTRA_MIME_TYPES, arrayOf("video/*", "image/jpeg"))
            .putExtra(android.content.Intent.EXTRA_ALLOW_MULTIPLE, true)
        runCatching { startActivityForResult(i, REQ_PICK) }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: android.content.Intent?) {
        super.onActivityResult(req, res, data)
        TrashOps.handleResult(req, res)
        if (req == REQ_MUSIC && res == RESULT_OK && data != null) {
            val mu = ArrayList<Uri>()
            data.data?.let { mu.add(it) }
            data.clipData?.let { cd -> for (k in 0 until cd.itemCount) mu.add(cd.getItemAt(k).uri) }
            startMusic(mu)
            return
        }
        if (req == REQ_COMIC && res == RESULT_OK && data != null) {
            val cu = ArrayList<Uri>()
            data.data?.let { cu.add(it) }
            data.clipData?.let { cd -> for (k in 0 until cd.itemCount) cu.add(cd.getItemAt(k).uri) }
            startComics(cu)
            return
        }
        if ((req != REQ_PICK && req != REQ_PICK_LIB) || res != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        data.data?.let { uris.add(it) }
        data.clipData?.let { cd -> for (k in 0 until cd.itemCount) uris.add(cd.getItemAt(k).uri) }
        if (uris.isEmpty()) return
        val uniq = uris.distinct() // one picked file can come both as data and inside clipData
        val app = applicationContext
        info.text = getString(R.string.lib_loading)
        Thread {
            val items = uniq.mapNotNull { Shrink.itemFor(app, it) }
            ui.post {
                if (isDestroyed) return@post
                val skipped = uniq.size - items.size
                for (it in items) {
                    val list = if (it.video) videos else photos
                    if (list.none { x -> x.uri == it.uri }) {
                        if (it.video) videos = listOf(it) + videos else photos = listOf(it) + photos
                    }
                    picked.add(it.uri)
                }
                loaded = true
                Toast.makeText(this, getString(R.string.shrink_pick_added_fmt, items.count { it.video }, items.count { !it.video }), Toast.LENGTH_LONG).show()
                if (skipped > 0) Toast.makeText(this, getString(R.string.shrink_pick_skipped_fmt, skipped), Toast.LENGTH_LONG).show()
                render()
            }
        }.start()
    }

    private fun reload() {
        loaded = false
        info.text = getString(R.string.lib_loading)
        val app = applicationContext
        Thread {
            val v = Shrink.listVideos(app)
            val p = Shrink.listPhotos(app)
            val mu = Shrink.listMusic(app)
            val co = Shrink.listComics(app)
            ui.post {
                if (isDestroyed) return@post
                videos = v
                photos = p
                music = mu
                comics = co
                loaded = true
                picked.removeAll { u -> (v + p + mu + co).none { it.uri == u } }
                render()
            }
        }.start()
    }

    private fun sorted(l: List<Shrink.Item>): List<Shrink.Item> = when (sortMode) {
        1 -> l.sortedWith(compareBy({ if (it.dateTaken <= 0L) Long.MAX_VALUE else it.dateTaken }, { -it.size }))
        2 -> l.sortedByDescending { it.dateTaken }
        3 -> l.sortedBy { it.name.lowercase() }
        else -> l.sortedByDescending { it.size }
    }

    /** "  ·  Free on the phone: 12 GB of 128 GB" (empty when it cannot be read). */
    private fun freeLine(): String = runCatching {
        val st = android.os.StatFs(android.os.Environment.getExternalStorageDirectory().path)
        "\n" + getString(R.string.shrink_free_fmt, mb(st.availableBytes), mb(st.totalBytes))
    }.getOrDefault("")

    private fun current() = when (tab) { 0 -> videos; 1 -> photos; 2 -> music; else -> comics }

    private fun mb(b: Long): String = when {
        b >= 1L shl 30 -> String.format(java.util.Locale.US, "%.2f GB", b / 1073741824.0)
        else -> String.format(java.util.Locale.US, "%d MB", b / 1048576L)
    }

    private fun paintQuality() {
        if (quality < 0) { qualityHint.text = getString(R.string.shrink_qh_rec); return }
        qualityHint.text = getString(
            if (tab == 0) when (quality) { 0 -> R.string.shrink_qh_v0; 1 -> R.string.shrink_qh_v1; else -> R.string.shrink_qh_v2 }
            else if (tab == 2) when (quality) { 0 -> R.string.shrink_qh_a0; 1 -> R.string.shrink_qh_a1; else -> R.string.shrink_qh_a2 }
            else if (tab == 3) when (quality) { 0 -> R.string.shrink_qh_c0; 1 -> R.string.shrink_qh_c1; else -> R.string.shrink_qh_c2 }
            else when (quality) { 0 -> R.string.shrink_qh_p0; 1 -> R.string.shrink_qh_p1; else -> R.string.shrink_qh_p2 }
        )
    }

    private fun render() {
        paintQuality()
        renderGen++
        listBox.removeAllViews()
        if (!loaded) return
        val items = sorted(current())
        if (items.isEmpty()) {
            info.text = getString(R.string.shrink_nothing) + freeLine()
            updateAction()
            return
        }
        val total = items.sumOf { it.size }
        info.text = getString(R.string.shrink_found_fmt, items.size, mb(total)) + freeLine()
        // order of the list
        listBox.addView(chipRow(this, listOf(getString(R.string.shrink_sort_big), getString(R.string.shrink_sort_old), getString(R.string.shrink_sort_new), getString(R.string.shrink_sort_name)), sortMode) { sortMode = it; render() })
        // quick choices: what to tick
        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun quickBtn(label: String, pick: (List<Shrink.Item>) -> List<Shrink.Item>) {
            quick.addView(Ui.text(this, label, 13f, Ui.ACCENT, true).apply {
                setPadding(dp(this@ShrinkActivity, 10), dp(this@ShrinkActivity, 8), dp(this@ShrinkActivity, 10), dp(this@ShrinkActivity, 8))
                background = Ui.round(Ui.CHIP, dp(this@ShrinkActivity, 10).toFloat(), Ui.STROKE, dp(this@ShrinkActivity, 1))
                setOnClickListener {
                    val chosen = pick(items)
                    if (chosen.isEmpty()) Toast.makeText(this@ShrinkActivity, R.string.shrink_sel_none_found, Toast.LENGTH_SHORT).show()
                    else { picked.addAll(chosen.map { x -> x.uri }); render() }
                }
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(this@ShrinkActivity, 8) })
        }
        quickBtn(getString(R.string.shrink_sel_top)) { l -> l.sortedByDescending { x -> x.size }.take(10) }
        quickBtn(getString(R.string.shrink_sel_over)) { l -> l.filter { x -> x.size >= 500L shl 20 } }
        quickBtn(getString(R.string.shrink_sel_old)) { l ->
            val cut = System.currentTimeMillis() - 183L * 24 * 3600 * 1000
            l.filter { x -> x.dateTaken in 1..cut }
        }
        listBox.addView(android.widget.HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(quick) }, EditUi.lp(this, 8))
        // select all / none for this tab
        val selAll = Ui.text(this, getString(if (items.all { it.uri in picked }) R.string.shrink_none else R.string.shrink_all), 13f, Ui.ACCENT, true).apply {
            setPadding(dp(this@ShrinkActivity, 6), dp(this@ShrinkActivity, 6), dp(this@ShrinkActivity, 6), dp(this@ShrinkActivity, 6))
            setOnClickListener {
                if (items.all { it.uri in picked }) items.forEach { picked.remove(it.uri) } else items.forEach { picked.add(it.uri) }
                render()
            }
        }
        selAllBtn = selAll
        listBox.addView(selAll)
        for (it in items) listBox.addView(row(it, items), EditUi.lp(this, 6))
        updateAction()
    }

    private fun row(it: Shrink.Item, items: List<Shrink.Item>): View {
        val a = this
        val gen = renderGen
        val on = it.uri in picked
        val r = LinearLayout(a).apply {
            gravity = Gravity.CENTER_VERTICAL
            val p = dp(a, 12)
            setPadding(p, dp(a, 10), p, dp(a, 10))
            background = Ui.round(if (on) Ui.CHIP else Ui.CARD, dp(a, 14).toFloat(), if (on) Ui.ACCENT else Ui.STROKE, dp(a, 1))
        }
        val mark = TextView(a).apply {
            text = if (on) "✓" else ""
            gravity = Gravity.CENTER
            textSize = 15f
            setTextColor(Ui.BG)
            background = if (on) Ui.round(Ui.ACCENT, dp(a, 8).toFloat()) else Ui.round(Ui.CHIP, dp(a, 8).toFloat(), Ui.STROKE, dp(a, 1))
        }
        r.addView(mark, LinearLayout.LayoutParams(dp(a, 26), dp(a, 26)))
        if (it.uri.authority == android.provider.MediaStore.AUTHORITY) {
            val iv = ImageView(a).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                background = Ui.round(Ui.CHIP, dp(a, 8).toFloat())
                clipToOutline = true
                outlineProvider = object : android.view.ViewOutlineProvider() {
                    override fun getOutline(v: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(a, 8).toFloat()) }
                }
            }
            val uri = it.uri
            val cached = thumbs.get(uri)
            if (cached != null) iv.setImageBitmap(cached)
            else {
                iv.tag = uri
                runCatching {
                    thumbPool.execute {
                        if (gen != renderGen) return@execute // the list was built again meanwhile: this row is not on screen any more
                        val bm = runCatching { contentResolver.loadThumbnail(uri, Size(160, 160), null) }.getOrNull()
                        if (bm != null) {
                            thumbs.put(uri, bm)
                            ui.post { if (iv.tag == uri) iv.setImageBitmap(bm) }
                        }
                    }
                }
            }
            r.addView(iv, LinearLayout.LayoutParams(dp(a, 56), dp(a, 56)).apply { marginStart = dp(a, 10) })
        }
        val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        col.addView(Ui.text(a, it.name, 14f, Ui.TEXT).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
        val est = Shrink.estimate(it, quality)
        val dims = if (it.w > 0 && it.h > 0) it.w.toString() + "×" + it.h + "  ·  " else ""
        val dur = if (it.durMs > 0) fmtDur(it.durMs) + "  ·  " else ""
        col.addView(Ui.text(a, dims + dur + mb(it.size) + "  →  ≈ " + mb(est), 12f, Ui.MUTED).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
        r.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(a, 12) })
        // a tap changes only this row (the old code built the whole list again, and asked for every thumbnail again, on every tap)
        r.setOnClickListener { _ ->
            val nowOn = picked.add(it.uri)
            if (!nowOn) picked.remove(it.uri)
            mark.text = if (nowOn) "✓" else ""
            mark.background = if (nowOn) Ui.round(Ui.ACCENT, dp(a, 8).toFloat()) else Ui.round(Ui.CHIP, dp(a, 8).toFloat(), Ui.STROKE, dp(a, 1))
            r.background = Ui.round(if (nowOn) Ui.CHIP else Ui.CARD, dp(a, 14).toFloat(), if (nowOn) Ui.ACCENT else Ui.STROKE, dp(a, 1))
            selAllBtn?.text = getString(if (items.all { x -> x.uri in picked }) R.string.shrink_none else R.string.shrink_all)
            updateAction()
        }
        return r
    }

    private fun fmtDur(ms: Long): String {
        val s = (ms / 1000L).toInt()
        return if (s >= 3600) String.format(java.util.Locale.US, "%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60) else String.format(java.util.Locale.US, "%d:%02d", s / 60, s % 60)
    }

    private fun selected(): List<Shrink.Item> = (videos + photos + music + comics).filter { it.uri in picked }

    private fun updateAction() {
        val sel = selected()
        if (sel.isEmpty() || working) {
            page.bottom.visibility = View.GONE
            return
        }
        val saved = sel.sumOf { (it.size - Shrink.estimate(it, quality)).coerceAtLeast(0L) }
        action.text = getString(R.string.shrink_go_fmt, sel.size, mb(saved))
        page.bottom.visibility = View.VISIBLE
    }

    private fun start() = runShrink(selected())

    private fun runShrink(sel: List<Shrink.Item>) {
        if (sel.isEmpty() || working) return
        working = true
        updateAction()
        val cancel = AtomicBoolean(false)
        val prog = EditProgress(this, getString(R.string.shrink_working), cancel)
        val app = applicationContext
        val q = quality
        Thread {
            runCatching { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND) } // the picture / sound of anything playing must not stutter
            val results = ArrayList<Shrink.Result>()
            for ((i, item) in sel.withIndex()) {
                if (cancel.get()) break
                val r = Shrink.run(app, item, q, cancel) { f -> prog.set((i + f) / sel.size) }
                results.add(r)
            }
            ui.post {
                prog.close()
                working = false
                if (!isDestroyed) summary(results, sel.size)
            }
        }.start()
    }

    private fun summary(results: List<Shrink.Result>, asked: Int) {
        val ok = results.filter { it.out != null }
        val saved = ok.sumOf { it.item.size - it.outSize }
        val sb = StringBuilder()
        sb.append(getString(R.string.shrink_done_fmt, ok.size, asked, mb(saved.coerceAtLeast(0L))))
        if (ok.isNotEmpty()) {
            sb.append("\n\n")
            for (r in ok.take(6)) sb.append("• ").append(r.item.name.take(28)).append(" → ").append(mb(r.outSize)).append(if (r.note != null) " (" + getString(R.string.shrink_resized_fmt, r.note) + ")" else "").append('\n')
        }
        val bad = results.filter { it.out == null && it.error != "cancelled" }
        if (bad.isNotEmpty()) {
            sb.append("\n\n")
            for (b in bad.take(6)) {
                sb.append("• ").append(b.item.name.take(28)).append(": ").append(
                    when (b.error) {
                        "HDR" -> getString(R.string.shrink_why_hdr)
                        "no gain" -> getString(R.string.shrink_why_nogain) + (if (b.outSize > 0L) " (" + mb(b.item.size) + " → " + mb(b.outSize) + ")" else "")
                        "already small" -> getString(R.string.shrink_why_small)
                        else -> b.error ?: "?"
                    }
                ).append('\n')
            }
        }
        val dlg = AlertDialog.Builder(this).setTitle(if (ok.isEmpty() && bad.isNotEmpty()) R.string.shrink_failed_title else R.string.shrink_done_title).setMessage(sb.toString().trim())
        if (ok.isNotEmpty()) {
            dlg.setPositiveButton(R.string.shrink_delete_originals) { _, _ ->
                val del = ok.map { it.item.uri }.filter { u -> u.authority == android.provider.MediaStore.AUTHORITY }
                if (del.isEmpty()) { picked.clear(); reload() } else TrashOps.confirmDelete(this, del) { picked.clear(); reload() }
            }
            dlg.setNegativeButton(R.string.shrink_keep_both) { _, _ -> picked.clear(); reload() }
            val first = ok.first().out
            if (first != null) dlg.setNeutralButton(R.string.shrink_show) { _, _ ->
                runCatching {
                    val mime = contentResolver.getType(first) ?: "video/*"
                    startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW).setDataAndType(first, mime).addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION))
                }
                picked.clear(); reload()
            }
        } else {
            dlg.setPositiveButton(android.R.string.ok) { _, _ -> reload() }
            val text = sb.toString().trim()
            dlg.setNeutralButton(R.string.shrink_copy_error) { _, _ ->
                runCatching {
                    (getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("shrink", text))
                    Toast.makeText(this, R.string.shrink_copied, Toast.LENGTH_SHORT).show()
                }
            }
        }
        val shown = dlg.show()
        runCatching { shown.findViewById<android.widget.TextView>(android.R.id.message)?.setTextIsSelectable(true) } // the text can be selected and copied
        if (ok.isEmpty() && results.isEmpty()) Toast.makeText(this, R.string.ai_cancelled, Toast.LENGTH_SHORT).show()
    }

    private companion object {
        const val REQ_PERM = 41
        const val REQ_PICK = 42
        const val REQ_PICK_LIB = 43
        const val REQ_COMIC = 44
        const val REQ_MUSIC = 45
    }
}
