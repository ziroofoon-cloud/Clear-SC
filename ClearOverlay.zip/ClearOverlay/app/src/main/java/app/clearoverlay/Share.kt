package app.clearoverlay

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.MimeTypeMap
import android.widget.Toast
import java.util.Locale

/** The system "Share" sheet for videos / photos (content:// files) and for links. */
object Share {
    private fun mime(ctx: Context, u: Uri): String {
        val t = runCatching { ctx.contentResolver.getType(u) }.getOrNull()
        if (!t.isNullOrEmpty()) return t
        val ext = MimeTypeMap.getFileExtensionFromUrl(u.toString()).lowercase(Locale.US)
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
    }

    /** Shares [uris]; returns false when none of them can be shared (private app files, network shares). */
    fun share(ctx: Context, uris: List<Uri>): Boolean {
        val files = uris.filter { it.scheme == "content" }
        val links = uris.filter { it.scheme == "http" || it.scheme == "https" }
        val intent: Intent = when {
            files.size == 1 -> Intent(Intent.ACTION_SEND).setType(mime(ctx, files[0])).putExtra(Intent.EXTRA_STREAM, files[0])
            files.size > 1 -> {
                val types = files.map { mime(ctx, it).substringBefore('/') }.toSet()
                Intent(Intent.ACTION_SEND_MULTIPLE).setType(if (types.size == 1) types.first() + "/*" else "*/*")
                    .putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(files))
            }
            links.isNotEmpty() -> Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, links.joinToString("\n"))
            else -> {
                Toast.makeText(ctx, R.string.share_none, Toast.LENGTH_SHORT).show()
                return false
            }
        }
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        runCatching {
            ctx.startActivity(Intent.createChooser(intent, ctx.getString(R.string.share)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK.takeIf { ctx !is android.app.Activity } ?: 0))
        }.onFailure { Toast.makeText(ctx, R.string.share_none, Toast.LENGTH_SHORT).show() }
        return true
    }
}
