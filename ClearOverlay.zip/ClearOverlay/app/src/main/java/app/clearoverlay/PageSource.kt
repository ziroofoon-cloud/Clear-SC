package app.clearoverlay

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import java.io.File
import java.nio.ByteBuffer
import java.util.zip.ZipFile
import kotlin.math.max

/**
 * The pages of a comic file (.cbz / .zip) or a .pdf, one picture per page, for the batch "Enhance to files".
 * The file is copied to the cache once (it needs to be seekable) and removed again by [close].
 * RAR / 7z are not handled here.
 */
class PageSource private constructor(
    private val file: File,
    private val zip: ZipFile?,
    private val names: List<String>,
    private val pdf: PdfRenderer?,
    private val pfd: ParcelFileDescriptor?,
    val count: Int
) {
    private val lock = Any()

    /** Page [i] (0-based) as a bitmap whose long side is at most [maxSide]; null if it cannot be read. */
    fun load(i: Int, maxSide: Int = 4096): Bitmap? = runCatching {
        if (i !in 0 until count) return null
        if (pdf != null) loadPdf(i, maxSide) else loadZip(i, maxSide)
    }.getOrNull()

    private fun loadZip(i: Int, maxSide: Int): Bitmap? {
        val z = zip ?: return null
        val e = z.getEntry(names[i]) ?: return null
        val bytes = z.getInputStream(e).use { it.readBytes() }
        return ImageDecoder.decodeBitmap(ImageDecoder.createSource(ByteBuffer.wrap(bytes))) { dec, info, _ ->
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val m = max(info.size.width, info.size.height)
            if (m > maxSide) {
                val s = maxSide.toFloat() / m
                dec.setTargetSize(max(1, (info.size.width * s).toInt()), max(1, (info.size.height * s).toInt()))
            }
        }
    }

    private fun loadPdf(i: Int, maxSide: Int): Bitmap? = synchronized(lock) {
        val r = pdf ?: return null
        val page = r.openPage(i)
        try {
            // a page is measured in 1/72 inch: about 2000 px on the long side is plenty to read and to enhance
            val target = minOf(maxSide, 2000).toFloat()
            val k = target / max(page.width, page.height)
            val w = max(1, (page.width * k).toInt())
            val h = max(1, (page.height * k).toInt())
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            bmp
        } finally {
            page.close()
        }
    }

    fun close() {
        runCatching { pdf?.close() }
        runCatching { pfd?.close() }
        runCatching { zip?.close() }
        runCatching { file.delete() }
    }

    companion object {
        private val EXT = listOf(".jpg", ".jpeg", ".jfif", ".png", ".webp", ".bmp", ".gif", ".avif", ".heic", ".heif")

        /** Opens [uri]; throws with a readable message when it is not a .cbz / .zip / .pdf. */
        fun open(ctx: Context, uri: Uri): PageSource {
            val f = File(ctx.cacheDir, "batch_src_" + System.nanoTime() + ".bin")
            (ctx.contentResolver.openInputStream(uri) ?: error("cannot open the file")).use { ins ->
                f.outputStream().use { ins.copyTo(it) }
            }
            try {
                val head = ByteArray(5)
                f.inputStream().use { it.read(head) }
                val h = String(head, Charsets.ISO_8859_1)
                if (h.startsWith("%PDF")) {
                    val pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
                    val r = PdfRenderer(pfd)
                    return PageSource(f, null, emptyList(), r, pfd, r.pageCount)
                }
                if (h.startsWith("PK")) {
                    val z = try {
                        ZipFile(f)
                    } catch (t: Throwable) {
                        ZipFile(f, Charsets.ISO_8859_1)
                    }
                    val names = ArrayList<String>()
                    val en = z.entries()
                    while (en.hasMoreElements()) {
                        val e = en.nextElement()
                        if (e.isDirectory || e.name.contains("__MACOSX")) continue
                        val base = e.name.lowercase().substringAfterLast('/').substringAfterLast('\\')
                        if (base.startsWith(".")) continue
                        if (EXT.any { base.endsWith(it) }) names.add(e.name)
                    }
                    names.sortWith { a, b -> Media.natural(a.replace('\\', '/'), b.replace('\\', '/')) }
                    if (names.isEmpty()) error("no pictures in this archive")
                    return PageSource(f, z, names, null, null, names.size)
                }
                error("only .cbz, .zip and .pdf files can be enhanced this way")
            } catch (t: Throwable) {
                f.delete()
                throw t
            }
        }
    }
}
