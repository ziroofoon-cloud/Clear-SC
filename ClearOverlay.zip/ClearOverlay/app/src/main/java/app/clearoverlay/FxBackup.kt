package app.clearoverlay

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Backup of the picture / sound FX settings as ONE readable JSON file ("+CRSC settings"): it can be kept outside the app
 * (survives an uninstall), given to someone else, or sent to be tuned by hand and loaded back.
 *
 * Contents: every picture setting of every section (screen, video, photo, manga, gif, stream), the user's saved
 * profiles, the sound FX and the stream FX. The bubble, language, theme and library are NOT included.
 * Values are plain JSON; "types" lists the keys that are decimals ("f") or big integers ("l"), because JSON cannot tell 1.0 from 1.
 */
object FxBackup {
    const val REQ_SAVE = 41
    const val REQ_LOAD = 42
    private const val FORMAT = 1
    private val SEC = Regex("^sec_(video|photo|manga|gif|stream)_(.+)$")

    private fun prefs(c: Context, f: String) = c.getSharedPreferences(f, Context.MODE_PRIVATE)

    private fun isPicture(k: String): Boolean {
        if (k == "uprofiles" || k == "uprofiles_seq") return false // profiles are written separately
        if (k in Cfg.SECTION_KEYS) return true
        val m = SEC.matchEntire(k) ?: return false
        return m.groupValues[2] in Cfg.SECTION_KEYS || m.groupValues[2] == "seeded"
    }

    private fun dump(p: android.content.SharedPreferences, keep: (String) -> Boolean): Pair<JSONObject, JSONObject> {
        val v = JSONObject()
        val t = JSONObject()
        for (k in p.all.keys.sorted()) {
            if (!keep(k)) continue
            when (val x = p.all[k]) {
                is Boolean -> v.put(k, x)
                is Int -> v.put(k, x)
                is Long -> { v.put(k, x); t.put(k, "l") }
                is Float -> { v.put(k, x.toDouble()); t.put(k, "f") }
                is String -> v.put(k, x)
            }
        }
        return v to t
    }

    private fun group(p: android.content.SharedPreferences, keep: (String) -> Boolean): JSONObject {
        val (v, t) = dump(p, keep)
        return JSONObject().put("values", v).put("types", t)
    }

    fun build(c: Context): String {
        runCatching { Cfg.save(c) }
        val root = JSONObject()
        root.put("app", "+CRSC")
        root.put("format", FORMAT)
        root.put("appVersion", runCatching { c.packageManager.getPackageInfo(c.packageName, 0).versionName }.getOrNull() ?: "")
        root.put("saved", SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()))
        root.put("note", "Picture/sound FX settings of +CRSC. Section keys: no prefix = screen layer, sec_video_/sec_photo_/sec_manga_/sec_gif_/sec_stream_ = that section. Edit the numbers and load the file back in the app.")
        root.put("picture", group(prefs(c, "crsc")) { isPicture(it) })
        val prof = runCatching { JSONArray(prefs(c, "crsc").getString("uprofiles", "[]")) }.getOrDefault(JSONArray())
        root.put("profiles", prof)
        root.put("audio", group(prefs(c, "crsc_audio")) { true })
        root.put("stream", group(prefs(c, "crsc_stream")) { true })
        return root.toString(2)
    }

    private fun restore(p: android.content.SharedPreferences, g: JSONObject?, keep: (String) -> Boolean): Int {
        if (g == null) return 0
        val v = g.optJSONObject("values") ?: return 0
        val t = g.optJSONObject("types") ?: JSONObject()
        val e = p.edit()
        var n = 0
        val it = v.keys()
        while (it.hasNext()) {
            val k = it.next()
            if (!keep(k)) continue
            val x = v.opt(k)
            val old = p.all[k]
            when {
                x is Boolean -> e.putBoolean(k, x)
                x is String -> e.putString(k, x)
                x is Number -> {
                    val ty = t.optString(k, "")
                    val d = x.toDouble()
                    if (d.isNaN() || d.isInfinite()) continue
                    when {
                        ty == "f" || (ty.isEmpty() && old is Float) -> e.putFloat(k, d.toFloat())
                        ty == "l" || (ty.isEmpty() && old is Long) -> e.putLong(k, x.toLong())
                        else -> e.putInt(k, x.toInt())
                    }
                }
                else -> continue
            }
            n++
        }
        e.apply()
        return n
    }

    /** Loads a backup text. Returns the number of settings restored, or -1 when the text is not a +CRSC settings file. */
    fun restore(c: Context, text: String): Int {
        val root = runCatching { JSONObject(text) }.getOrNull() ?: return -1
        if (root.optString("app") != "+CRSC") return -1
        var n = restore(prefs(c, "crsc"), root.optJSONObject("picture")) { isPicture(it) }
        val incoming = root.optJSONArray("profiles")
        if (incoming != null && incoming.length() > 0) {
            val cur = runCatching { JSONArray(prefs(c, "crsc").getString("uprofiles", "[]")) }.getOrDefault(JSONArray())
            val out = JSONArray()
            val names = HashSet<String>()
            for (i in 0 until incoming.length()) incoming.optJSONObject(i)?.let {
                val nm = it.optString("name")
                if (nm.isNotEmpty() && names.add(nm.lowercase(Locale.US))) out.put(it)
            }
            for (i in 0 until cur.length()) cur.optJSONObject(i)?.let {
                if (names.add(it.optString("name").lowercase(Locale.US))) out.put(it)
            }
            prefs(c, "crsc").edit().putString("uprofiles", out.toString()).apply()
            n += incoming.length()
        }
        n += restore(prefs(c, "crsc_audio"), root.optJSONObject("audio")) { true }
        n += restore(prefs(c, "crsc_stream"), root.optJSONObject("stream")) { true }
        runCatching { Cfg.load(c) }
        runCatching { AudioFx.load(c) }
        runCatching { OverlayService.instance?.applyConfig() }
        return n
    }

    // ---- UI helpers (used by the main screen) ----
    fun fileName(): String = "CRSC-settings-" + SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date()) + ".json"

    fun pickSave(a: Activity) {
        a.startActivityForResult(
            Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json").putExtra(Intent.EXTRA_TITLE, fileName()),
            REQ_SAVE
        )
    }

    fun pickLoad(a: Activity) {
        a.startActivityForResult(
            Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"),
            REQ_LOAD
        )
    }

    fun share(a: Activity) {
        val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_SUBJECT, fileName()).putExtra(Intent.EXTRA_TEXT, build(a))
        a.startActivity(Intent.createChooser(i, a.getString(R.string.fxb_share)))
    }

    /** Handles the result of [pickSave] / [pickLoad]; true when [req] was ours. */
    fun handle(a: Activity, req: Int, res: Int, data: Intent?): Boolean {
        if (req != REQ_SAVE && req != REQ_LOAD) return false
        val u: Uri = data?.data ?: return true
        if (res != Activity.RESULT_OK) return true
        if (req == REQ_SAVE) {
            val ok = runCatching {
                a.contentResolver.openOutputStream(u, "wt")!!.use { it.write(build(a).toByteArray(Charsets.UTF_8)) }
            }.isSuccess
            Toast.makeText(a, a.getString(if (ok) R.string.fxb_saved else R.string.fxb_fail), Toast.LENGTH_LONG).show()
        } else {
            val text = runCatching { a.contentResolver.openInputStream(u)!!.use { String(it.readBytes(), Charsets.UTF_8) } }.getOrNull()
            val n = if (text == null) -1 else restore(a, text)
            Toast.makeText(a, if (n < 0) a.getString(R.string.fxb_bad) else a.getString(R.string.fxb_loaded_fmt, n), Toast.LENGTH_LONG).show()
        }
        return true
    }
}
