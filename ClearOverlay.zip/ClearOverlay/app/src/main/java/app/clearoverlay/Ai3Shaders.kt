package app.clearoverlay

/**
 * "AI 3x": the three-times networks of the training package `aio_results` (aio0x3 / aio1x3 / aio1bx3 / aio2x3 / aio2bx3 / aio3x3 / aio4x3). It is a part of its own, apart from "AI upscaler 2x":
 * an upscaler of the Upscaler row ([Cfg.MODE_AI3X]) with its own level ([Cfg.ai3Tier]) and sharpness ([Cfg.ai3Gain]). Shaders are in `assets/ai3/`
 * (all weights are constants, the text is long), generated from the trained weights; each network is a few convolution passes and one last pass that does
 * the depth-to-space (27 numbers -> a 3x3 block of RGB) and adds them to a bilinear 3x picture of the source (`uGain` = how much of the learned part).
 * Between the passes the numbers live in RGBA16F textures (up to 7 or 8 render targets at once). See GlPipeline.ai3Stage.
 */
object Ai3Shaders {
    const val TIERS = 23 // 0..6 the "AI 3x" levels; 7.. the "Nova 3x" levels (up to 17 are reserved, add a level = one more entry in each table below + its 4 / 5 shader files in assets/ai3/)
    const val NOVA_FIRST = 7
    /** Level 0..3 as saved in [Cfg.ai3Tier] (0..2 are the values older versions saved; 3 = the 12-channel, 4 = the 20-channel 5 = the 16-channel and 6 = the 24-channel one added later). */
    val NAMES = arrayOf("Light (4 ch)", "Balanced (8 ch)", "Quality (32 ch)", "Balanced+ (12 ch)", "High (20 ch)", "Plus (16 ch)", "Ultra (24 ch)", "Ultra Q (12 ch)", "Quality (28 ch)", "Balance (12>28 ch)", "Test 2L 4ch", "Test 3L 4ch", "Test 2L 8ch", "Test 3L 8ch", "Luma 2L 8ch", "Luma 3L 8ch", "Luma 2L 12ch", "Luma 3L 12ch", "Luma 4L 12ch", "Luma 3L 16ch", "Luma 5L 12ch", "Luma 4L 16ch", "Luma 6L 16ch")
    private val FILE = arrayOf("aio0x3", "aio1x3", "aio4x3", "aio1bx3", "aio2bx3", "aio2x3", "aio3x3", "aioM6x3", "aioM5x3", "aioM4x3", "ST3x_L2_C4_one", "ST3x_L3_C4_one", "ST3x_L2_C8_one", "ST3x_L3_C8_one", "ST3x_L2_C8_luma", "ST3x_L3_C8_luma", "ST3x_L2_C12_luma", "ST3x_L3_C12_luma", "ST3x_L4_C12_luma", "ST3x_L3_C16_luma", "ST3x_L5_C12_luma", "ST3x_L4_C16_luma", "ST3x_L6_C16_luma")

    /** The levels in the order of the chips (light to heavy), as saved values. */
    val ORDER = intArrayOf(0, 1, 3, 5, 4, 6, 2)
    /** The levels of the "Nova 3x" upscaler ([Cfg.MODE_NOVA3], saved in [Cfg.nvTier]) in the order of its chips (light to heavy). */
    val NOVA_ORDER = intArrayOf(14, 10, 11, 16, 15, 17, 9, 18, 19, 7, 8, 20, 21, 22)
    fun novaChipOfTier(t: Int): Int = NOVA_ORDER.indexOf(t).coerceAtLeast(0)
    fun novaTierOfChip(c: Int): Int = NOVA_ORDER.getOrElse(c) { NOVA_FIRST }
    fun chipOfTier(t: Int): Int = ORDER.indexOf(t).coerceAtLeast(0)
    fun tierOfChip(c: Int): Int = ORDER.getOrElse(c) { 1 }

    /** The next lighter level (the phone cannot run [t], or the picture is too big for it); -1 = none. */
    fun lower(t: Int): Int = when (t) { 14 -> -1; 10 -> 14; 11 -> 10; 16 -> 11; 15 -> 16; 12 -> 15; 17 -> 12; 13 -> 17; 9 -> 13; 18 -> 9; 19 -> 18; 7 -> 19; 8 -> 7; 20 -> 8; 21 -> 20; 22 -> 21; 2 -> 6; 6 -> 4; 4 -> 5; 5 -> 3; 3 -> 1; 1 -> 0; else -> -1 }

    /**
     * What [Cfg.ai3HybNet] (the light network of \"light + heavy\") can hold: 0 = the 3x Light (4 ch), 1..5 = an AI 2x level (fitted to 3x), 11..16 = a 3x network of level (value - 10),
     * chosen by the person (level 2, the 32-channel Quality one, is never a light network: it is the heaviest). Anything else is read as 0.
     */
    fun hybNetNorm(v: Int): Int = if (v in 0..5 || (v in 11..(10 + TIERS - 1) && v - 10 != 2)) v else 0
    /** The 3x level that [Cfg.ai3HybNet] = [v] asks for as the light network, or 0 (= Light 4 ch) when it asks for Light or for an AI 2x network. */
    fun hybLight3(v: Int): Int = if (v in 11..(10 + TIERS - 1) && v - 10 != 2) v - 10 else 0

    /** Number of RGBA16F textures of the four buffers A, B, C1, C2 (see [plan]) at the size of the source, for each level. */
    val SIZES = arrayOf(intArrayOf(1, 1, 7, 0), intArrayOf(2, 2, 7, 7), intArrayOf(8, 8, 7, 7), intArrayOf(3, 3, 7, 7), intArrayOf(5, 5, 7, 7), intArrayOf(4, 4, 7, 7), intArrayOf(6, 6, 7, 7), intArrayOf(3, 3, 7, 0), intArrayOf(4, 7, 0, 0), intArrayOf(3, 7, 0, 0), intArrayOf(1, 7, 0, 0), intArrayOf(1, 1, 7, 0), intArrayOf(2, 7, 0, 0), intArrayOf(2, 2, 7, 0), intArrayOf(2, 3, 0, 0), intArrayOf(2, 2, 3, 0), intArrayOf(3, 3, 0, 0), intArrayOf(3, 3, 3, 0), intArrayOf(3, 3, 3, 0), intArrayOf(4, 4, 3, 0), intArrayOf(3, 3, 3, 0), intArrayOf(4, 4, 3, 0), intArrayOf(4, 4, 3, 0))

    /** Textures held at the same time (x 8 bytes x pixels of the source = the memory). */
    fun textures(t: Int): Int = SIZES[t.coerceIn(0, TIERS - 1)].sum()

    /**
     * The passes before the last one: each is `[output buffer, input, input ...]`; buffers 0 = A, 1 = B, 2 = C1, 3 = C2, -1 = the source picture. The files are
     * `<name>_p1.frag` ... in this order, and the last file is the final pass (it reads [finalInputs] and the source).
     */
    fun plan(t: Int): Array<IntArray> = when (t) {
        0, 7, 11, 13, 15, 17, 19 -> arrayOf(intArrayOf(0, -1), intArrayOf(1, 0), intArrayOf(2, 1))
        18, 21 -> arrayOf(intArrayOf(0, -1), intArrayOf(1, 0), intArrayOf(0, 1), intArrayOf(2, 0))
        20 -> arrayOf(intArrayOf(0, -1), intArrayOf(1, 0), intArrayOf(0, 1), intArrayOf(1, 0), intArrayOf(2, 1))
        22 -> arrayOf(intArrayOf(0, -1), intArrayOf(1, 0), intArrayOf(0, 1), intArrayOf(1, 0), intArrayOf(0, 1), intArrayOf(2, 0))
        8, 9, 10, 12, 14, 16 -> arrayOf(intArrayOf(0, -1), intArrayOf(1, 0))
        1, 3, 4, 5, 6 -> arrayOf(intArrayOf(0, -1), intArrayOf(1, 0), intArrayOf(2, 1), intArrayOf(3, 1))
        else -> arrayOf(intArrayOf(0, -1), intArrayOf(1, 0), intArrayOf(0, 1), intArrayOf(2, 0), intArrayOf(3, 0))
    }
    fun finalInputs(t: Int): IntArray = if (t == 0 || t == 7 || t == 11 || t == 13 || t == 15 || t == 17 || t in 18..22) intArrayOf(2) else if (t == 8 || t == 9 || t == 10 || t == 12 || t == 14 || t == 16) intArrayOf(1) else intArrayOf(2, 3)

    /** Cost in the units of the load meter: estimated from the multiply-adds per source pixel (1260 / 4824 / 35400 / 7600 / 14000 / 10600 / 17700) like the 2x networks (0.36 per 1000); not measured. */
    fun cost(t: Int): Float = when (t) { 0 -> 0.5f; 1 -> 1.8f; 3 -> 2.7f; 4 -> 5.0f; 5 -> 3.8f; 6 -> 6.4f; 7 -> 1.7f; 8 -> 2.1f; 9 -> 1.5f; 10 -> 0.4f; 11 -> 0.45f; 12 -> 0.8f; 13 -> 1.0f; 14 -> 0.3f; 15 -> 0.5f; 16 -> 0.5f; 17 -> 1.0f; 18 -> 1.4f; 19 -> 1.5f; 20 -> 1.9f; 21 -> 2.3f; 22 -> 4.0f; else -> 12.7f }

    /** Shader text of pass [pass] (1-based; the last one is the final pass) of level [t], or null when it cannot be read. */
    fun asset(t: Int, pass: Int): String? {
        val c = NeuralNet.context() ?: return null
        return runCatching { c.assets.open("ai3/" + FILE[t.coerceIn(0, TIERS - 1)] + "_p" + pass + ".frag").use { String(it.readBytes(), Charsets.UTF_8) } }.getOrNull()
    }

    /** Number of passes of level [t] including the last one. */
    fun passes(t: Int): Int = plan(t).size + 1

    /** Half-precision (mediump) maths for level [t]. Checked offline for all seven levels with the worst rounding (every product and sum rounded to 16 bits): the largest change of a residual value is 0.2 of 255. A phone's compiler can still do worse (the 16-channel AI 2x network did on Adreno 618), which is why the switch is off by default. */
    fun halfOk(t: Int): Boolean = true

    /** The half-precision (mediump) version of a convolution pass: the two precision lines, and (the levels of the Nova family, checked offline by their trainer with this exact form: largest change 0.12 of 255) the running sums of the pass stay in full precision (`highp vec4 aN`). */
    fun half(t: Int, src: String): String {
        val h = SrShaders.half(src)
        return if (t >= NOVA_FIRST) Regex("(?m)^  vec4 (a\\d+) = ").replace(h) { "  highp vec4 " + it.groupValues[1] + " = " } else h
    }

    // ---- "skip flat areas" (experimental, Cfg.ai3Skip): the convolution passes from the 2nd on and the last pass do nothing where the source is flat ----
    /** Largest difference between the lightest and darkest value of a colour channel (of 255) that still counts as "flat", for the levels 1..3 of [Cfg.ai3Skip]: Safe, Normal, Strong. */
    val SKIP_THR = floatArrayOf(0f, 1.5f, 3f, 6f)

    /** "Light + heavy" (Cfg.ai3Hyb): a place counts as "light" when the largest local detail ([DETAIL]: second difference) in the neighbourhood the heavy network looks at is at most this (of 255), for the levels 1..3: Gentle, Normal, Strong. (Measured offline on 7 test pictures with the real networks: at 6 / 12 / 24 the mean difference to the full heavy result is 0.03 - 0.1 / 0.04 - 0.3 / 0.1 - 0.4 of 255 and the largest about 3 / 6 / 14; all-Light would be 2 - 4 on average and up to 60.) There the heavy network does not run and the pixel takes the result of the Light network (which runs on the whole picture and is drawn into the target first), not a plain enlargement. */
    val HYB_THR = floatArrayOf(0f, 6f, 12f, 24f)

    // ---- "similar frames" (experimental, Cfg.ai3Sim): the source of the last frame is kept as a reference picture R; where this frame is only a little different from R the network is given R, not this frame ----
    /** Largest difference of a colour channel (of 255) that still counts as "similar", for the levels 1..3 of [Cfg.ai3Sim]: Fine, Normal, Strong. */
    val SIM_TOL = floatArrayOf(0f, 1f, 2f, 4f)

    /**
     * Reference pass (one pass at the size of the source): `uIn` = this frame, `uPrev` = the reference picture R of the frame before. A pixel keeps its value from R when every colour channel is within
     * `uTol` of this frame, else it takes this frame's value. The network then runs on that picture (R') and not on this frame. Why this is exact (as far as the tolerance goes): R' differs from this frame by at most `uTol`
     * everywhere, so the result is the network's result for a picture that is not seen to be different; and where R' is the same as R the flat-map pass finds it "exactly the same" and the result of the frame before
     * is kept, so a result pixel is the network's result of R' at every pixel, always, with no mistake that adds up from frame to frame (R is only replaced where this frame is further away than `uTol`).
     */
    const val REF = """#version 300 es
precision highp float;
precision highp int;
precision highp sampler2D;
uniform sampler2D uIn;
uniform sampler2D uPrev;
uniform float uTol;
layout(location=0) out vec4 outColor;
void main(){
  ivec2 p = ivec2(gl_FragCoord.xy);
  vec4 s = texelFetch(uIn, p, 0);
  vec4 r = texelFetch(uPrev, p, 0);
  vec3 d = abs(s.rgb - r.rgb);
  outColor = (max(d.r, max(d.g, d.b)) <= uTol) ? r : s;
}
"""

    /** Number of 3x3 convolution layers of level [t] (= the picture a result pixel depends on reaches this many source pixels away). */
    fun layers(t: Int): Int = plan(t).size

    /**
     * Flat map pass (one pass at the size of the source, reads the source): channel e (0..3) = 0.6 when the source is flat (colour range <= `uThr`, `uThr` < 0 = not asked) and 1.0 when it is exactly the same as in the picture of the last frame (`uPrev`, `uSame` = 0: not asked; the same wins) in the whole window of radius
     * `uR + e` around the pixel, else 0. `uR` = [layers], `uE` = the largest e that is needed. A pixel that is not flat in the window of `uR` stops the loop at once.
     * Why this is exact: pass k (1-based) at a pixel is only read by passes k+1.. at pixels up to (layers - k) away, and the last pass only reads its own pixel. A result pixel is skipped
     * only when its whole window (radius [layers]) is flat; pass k at a pixel is skipped only when the window of radius layers + (layers - k) is flat, so no pixel that is computed ever reads
     * a value that was skipped. The only change of the picture: a flat pixel gets the plain 3x bilinear picture without the small learned part (at most about 2 of 255 for grey, 6 for very saturated colours).
     */
    const val FLAT = """#version 300 es
precision highp float;
precision highp int;
precision highp sampler2D;
uniform sampler2D uIn;
uniform sampler2D uPrev;
uniform int uR;
uniform int uE;
uniform int uSame;
uniform float uThr;
layout(location=0) out vec4 outColor;
void main(){
  ivec2 p = ivec2(gl_FragCoord.xy);
  ivec2 hi = textureSize(uIn, 0) - 1;
  vec3 c = texelFetch(uIn, p, 0).rgb;
  vec3 mn = c; vec3 mx = c;
  bool fl = uThr >= 0.0;
  bool sm = uSame != 0 && all(equal(c, texelFetch(uPrev, p, 0).rgb));
  vec4 f = vec4(0.0);
  for (int r = 1; r <= uR + uE; r++) {
    for (int dy = -r; dy <= r; dy++) {
      int st = (dy == -r || dy == r) ? 1 : 2 * r;
      for (int dx = -r; dx <= r; dx += st) {
        ivec2 q = clamp(p + ivec2(dx, dy), ivec2(0), hi);
        vec3 s = texelFetch(uIn, q, 0).rgb;
        mn = min(mn, s); mx = max(mx, s);
        if (sm && any(notEqual(s, texelFetch(uPrev, q, 0).rgb))) sm = false;
      }
    }
    vec3 d = mx - mn;
    if (fl && max(d.r, max(d.g, d.b)) > uThr) fl = false;
    if (!fl && !sm) break;
    if (r >= uR) f[r - uR] = sm ? 1.0 : 0.6;
  }
  outColor = f;
}
"""

    /**
     * "Light + heavy" detail pass (one pass at the size of the source): the local detail of each pixel = the largest second difference `|2c - left - right|` or `|2c - up - down|` of each colour (clamped to 1).
     * A flat area AND a smooth gradient give 0 (a gradient has no second difference), a step edge of height h gives h on the two pixels next to it, texture and noise give a value too. This is what tells the heavy
     * network from the Light one: both do the same with a smooth slope, they differ at edges and fine structure. (The old range test, max - min of the window, took every gradient for "detail".)
     */
    const val DETAIL = """#version 300 es
precision highp float;
precision highp int;
precision highp sampler2D;
uniform sampler2D uIn;
layout(location=0) out vec4 outColor;
void main(){
  ivec2 p = ivec2(gl_FragCoord.xy);
  ivec2 hi = textureSize(uIn, 0) - 1;
  vec3 c = texelFetch(uIn, p, 0).rgb;
  vec3 l = texelFetch(uIn, clamp(p + ivec2(-1, 0), ivec2(0), hi), 0).rgb;
  vec3 r = texelFetch(uIn, clamp(p + ivec2(1, 0), ivec2(0), hi), 0).rgb;
  vec3 u = texelFetch(uIn, clamp(p + ivec2(0, -1), ivec2(0), hi), 0).rgb;
  vec3 d = texelFetch(uIn, clamp(p + ivec2(0, 1), ivec2(0), hi), 0).rgb;
  vec3 dh = abs(2.0 * c - l - r);
  vec3 dv = abs(2.0 * c - u - d);
  outColor = vec4(min(max(dh, dv), vec3(1.0)), 1.0);
}
"""

    /** The flat-map pass for "light + heavy": [FLAT] run on the DETAIL picture with the minimum fixed at 0, so "range of the window" becomes "largest detail in the window" (the same loop, the same output channels). */
    val HFLAT: String = FLAT.replace("vec3 mn = c; vec3 mx = c;", "vec3 mn = vec3(0.0); vec3 mx = c;")

    /**
     * The text of pass [pass] (1-based, from 2 on; the last one is the final pass) of level [t] with the flat-area shortcut put in: a pass that is not the last one writes zeros and returns where
     * channel (layers - pass) of `uFlat` is 1; the final pass leaves the learned part out (plain bilinear) where channel 0 is 0.6, and does `discard` where it is 1.0 (the target keeps the result of the last frame, which is exactly what this frame would give). Pass 1 is returned as it is. Null when the text does not have the
     * places the change needs (then the normal shader is used).
     */
    fun flatPatch(t: Int, pass: Int, src: String, hybrid: Boolean = false): String? {
        if (pass < 2) return src
        val last = passes(t)
        val decl = "precision highp sampler2D;"
        if (!src.contains(decl)) return null
        var s = src.replaceFirst(decl, decl + "\nuniform sampler2D uFlat;")
        if (pass < last) {
            val marker = "ivec2 p = ivec2(gl_FragCoord.xy);"
            if (!s.contains(marker)) return null
            val outs = Regex("layout\\(location=\\d+\\) out").findAll(s).count()
            if (outs <= 0) return null
            val zero = (0 until outs).joinToString(" ") { "o$it = vec4(0.0);" }
            s = s.replaceFirst(marker, marker + "\n  if (texelFetch(uFlat, p, 0)[" + (layers(t) - pass) + "] > 0.5) { " + zero + " return; }")
        } else {
            val marker = "switch (k) {"
            if (!s.contains(marker)) return null
            // hybrid ("light + heavy"): the Light network has already drawn the whole target, so a light place (0.6) is left alone (discard) and the heavy result is drawn only on the rest.
            // (No extra texture is read: the final pass of the big levels already reads 16.)
            val cut = if (hybrid) "0.5" else "0.9"
            s = s.replaceFirst(marker, "float fv = texelFetch(uFlat, q, 0).r;\n  if (fv > " + cut + ") discard;\n  if (fv < 0.5) " + marker)
        }
        return s
    }
}
