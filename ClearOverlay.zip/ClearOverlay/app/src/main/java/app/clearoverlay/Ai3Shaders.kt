package app.clearoverlay

/**
 * "AI 3x": the three-times networks of the training package `aio_results` (aio0x3 / aio1x3 / aio4x3). It is a part of its own, apart from "AI upscaler 2x":
 * an upscaler of the Upscaler row ([Cfg.MODE_AI3X]) with its own level ([Cfg.ai3Tier]) and sharpness ([Cfg.ai3Gain]). Shaders are in `assets/ai3/`
 * (all weights are constants, the text is long), generated from the trained weights; each network is a few convolution passes and one last pass that does
 * the depth-to-space (27 numbers -> a 3x3 block of RGB) and adds them to a bilinear 3x picture of the source (`uGain` = how much of the learned part).
 * Between the passes the numbers live in RGBA16F textures (up to 7 or 8 render targets at once). See GlPipeline.ai3Stage.
 */
object Ai3Shaders {
    const val TIERS = 3
    val NAMES = arrayOf("Light (4 ch)", "Balanced (8 ch)", "Quality (32 ch)")
    private val FILE = arrayOf("aio0x3", "aio1x3", "aio4x3")

    /** Number of RGBA16F textures of the four buffers A, B, C1, C2 (see [plan]) at the size of the source, for each level. */
    val SIZES = arrayOf(intArrayOf(1, 1, 7, 0), intArrayOf(2, 2, 7, 7), intArrayOf(8, 8, 7, 7))

    /** Textures held at the same time (x 8 bytes x pixels of the source = the memory). */
    fun textures(t: Int): Int = SIZES[t.coerceIn(0, TIERS - 1)].sum()

    /**
     * The passes before the last one: each is `[output buffer, input, input ...]`; buffers 0 = A, 1 = B, 2 = C1, 3 = C2, -1 = the source picture. The files are
     * `<name>_p1.frag` ... in this order, and the last file is the final pass (it reads [finalInputs] and the source).
     */
    fun plan(t: Int): Array<IntArray> = when (t) {
        0 -> arrayOf(intArrayOf(0, -1), intArrayOf(1, 0), intArrayOf(2, 1))
        1 -> arrayOf(intArrayOf(0, -1), intArrayOf(1, 0), intArrayOf(2, 1), intArrayOf(3, 1))
        else -> arrayOf(intArrayOf(0, -1), intArrayOf(1, 0), intArrayOf(0, 1), intArrayOf(2, 0), intArrayOf(3, 0))
    }
    fun finalInputs(t: Int): IntArray = if (t == 0) intArrayOf(2) else intArrayOf(2, 3)

    /** Cost in the units of the load meter: estimated from the multiply-adds per source pixel (1260 / 4824 / 35400) like the 2x networks (0.36 per 1000); not measured. */
    fun cost(t: Int): Float = when (t) { 0 -> 0.5f; 1 -> 1.8f; else -> 12.7f }

    /** Shader text of pass [pass] (1-based; the last one is the final pass) of level [t], or null when it cannot be read. */
    fun asset(t: Int, pass: Int): String? {
        val c = NeuralNet.context() ?: return null
        return runCatching { c.assets.open("ai3/" + FILE[t.coerceIn(0, TIERS - 1)] + "_p" + pass + ".frag").use { String(it.readBytes(), Charsets.UTF_8) } }.getOrNull()
    }

    /** Number of passes of level [t] including the last one. */
    fun passes(t: Int): Int = plan(t).size + 1
}
