package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import java.util.concurrent.atomic.AtomicBoolean

/** A small "saving" window for the editors: percentage, a bar and a Cancel button (sets [cancel]). Safe to call from a worker thread. */
class EditProgress(private val act: Activity, title: String, private val cancel: AtomicBoolean) {
    private val text = TextView(act).apply { this.text = "0%"; textSize = 16f; setTextColor(Ui.TEXT) }
    private val bar = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000 }
    private var dlg: AlertDialog? = null
    private var last = -1

    init {
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(act, 22), dp(act, 14), dp(act, 22), dp(act, 4))
        }
        box.addView(text)
        box.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(act, 10) })
        act.runOnUiThread {
            if (!act.isDestroyed && !act.isFinishing) {
                dlg = AlertDialog.Builder(act).setTitle(title).setView(box).setCancelable(false)
                    .setNegativeButton(android.R.string.cancel) { _, _ -> cancel.set(true) }.create()
                dlg?.show()
                act.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }
    }

    fun set(p: Float) {
        val v = (p * 1000).toInt().coerceIn(0, 1000)
        if (v == last) return
        last = v
        act.runOnUiThread { text.text = (v / 10).toString() + "%"; bar.progress = v }
    }

    fun close() {
        act.runOnUiThread {
            act.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            runCatching { dlg?.dismiss() }
        }
    }
}
