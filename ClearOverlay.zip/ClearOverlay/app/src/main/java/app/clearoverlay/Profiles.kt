package app.clearoverlay

/**
 * Quick-profile tables: 6 content types x 3 strengths (Light / Balanced / Strong), in two flavours.
 *
 *  - PLAYER: values are applied to the real decoded pixels. Denoise / deband / AA run on the SOURCE
 *    resolution (before FSR 1 upscales), so even a small radius cleans real compression blocks.
 *  - OVERLAY: the screen capture already contains the picture AFTER the app stretched it. Blocks and noise are
 *    several pixels wide, so the small-radius denoise can no longer remove them (it would only soften), while the
 *    stretch blur is wide: denoise is therefore lower, Detail uses a larger radius, and AA is mostly off.
 *
 * Every table entry is a hand-tuned starting point derived from what each shader does (RCAS strength is
 * sharp x 1.2; Detail gain is amount x 3 with coring; Denoise sigma is 0.012 + 0.11 x amount; Deband threshold is
 * 0.004 + 0.03 x amount). They have not been measured on a device: judge with FX on/off + Zoom and fine-tune.
 */
object Profiles {
    const val VIDEO = 0   // low-res / soft video (e.g. 240p-480p files, YouTube at low quality)
    const val STREAM = 1  // game streaming (Moonlight, Steam Link, GeForce Now) or low-bitrate live streams
    const val GAME = 2    // game rendered on this device
    const val PHOTO = 3   // low-quality / small / heavily compressed photo
    const val MOVIE = 4   // clean HD film / series (720p and up): keep grain and texture, almost no processing
    const val ANIME = 5   // anime / cartoon: flat colours + line art
    const val TEXT = 6    // text / subtitles / UI / manga: thin strokes must stay readable
    const val COUNT = 7

    class P(
        val sharp: Float,
        val detail: Float,
        val detailSize: Float,
        val denoise: Float,
        val deband: Float,
        val aa: Int = Cfg.AA_OFF,
        val aaStr: Float = 0.5f
    )

    private val PLAYER: Array<Array<P>> = arrayOf(
        // VIDEO: clean blocks first (at source size), then undo the stretch blur
        arrayOf(
            P(0.30f, 0.25f, 0.45f, 0.20f, 0.15f),
            P(0.38f, 0.40f, 0.50f, 0.32f, 0.25f),
            P(0.46f, 0.55f, 0.60f, 0.44f, 0.35f)
        ),
        // STREAM (live / low-bitrate HLS): moderate cleanup, text and HUD stay crisp
        arrayOf(
            P(0.35f, 0.20f, 0.40f, 0.18f, 0.20f),
            P(0.42f, 0.30f, 0.40f, 0.26f, 0.30f),
            P(0.50f, 0.40f, 0.45f, 0.36f, 0.40f)
        ),
        // GAME (recorded gameplay): sharp + a little cleanup, FXAA only for jagged edges
        arrayOf(
            P(0.45f, 0.10f, 0.35f, 0.08f, 0.10f, Cfg.AA_FXAA_FAST, 0.35f),
            P(0.60f, 0.15f, 0.35f, 0.12f, 0.15f, Cfg.AA_FXAA_QUALITY, 0.45f),
            P(0.72f, 0.25f, 0.40f, 0.18f, 0.20f, Cfg.AA_FXAA_QUALITY, 0.65f)
        ),
        // PHOTO: JPEG blocks live at source size, so denoise there; edge-smooth only along edges
        arrayOf(
            P(0.35f, 0.35f, 0.40f, 0.28f, 0.12f, Cfg.AA_EDGE, 0.20f),
            P(0.45f, 0.45f, 0.45f, 0.38f, 0.20f, Cfg.AA_EDGE, 0.30f),
            P(0.55f, 0.60f, 0.50f, 0.50f, 0.30f, Cfg.AA_EDGE, 0.40f)
        ),
        // MOVIE (clean HD): nearly transparent. No denoise (it would erase film grain), light deband only
        arrayOf(
            P(0.20f, 0.00f, 0.30f, 0.00f, 0.10f),
            P(0.30f, 0.10f, 0.30f, 0.00f, 0.15f),
            P(0.40f, 0.18f, 0.35f, 0.08f, 0.22f)
        ),
        // ANIME: flat areas denoise very well, gradients band badly, lines need clean edges
        arrayOf(
            P(0.35f, 0.15f, 0.35f, 0.20f, 0.30f, Cfg.AA_EDGE, 0.30f),
            P(0.45f, 0.25f, 0.35f, 0.30f, 0.45f, Cfg.AA_EDGE, 0.40f),
            P(0.55f, 0.35f, 0.40f, 0.40f, 0.60f, Cfg.AA_EDGE, 0.50f)
        ),
        // TEXT: thin strokes need a tight, strong Detail radius; very little denoise (it would eat the strokes), no deband
        arrayOf(
            P(0.50f, 0.50f, 0.28f, 0.08f, 0.00f),
            P(0.62f, 0.68f, 0.30f, 0.12f, 0.00f),
            P(0.74f, 0.85f, 0.34f, 0.16f, 0.00f)
        )
    )

    private val OVERLAY: Array<Array<P>> = arrayOf(
        // VIDEO (already stretched by the app): wide Detail radius, only a little denoise
        arrayOf(
            P(0.40f, 0.35f, 0.65f, 0.10f, 0.20f),
            P(0.50f, 0.50f, 0.75f, 0.16f, 0.30f),
            P(0.58f, 0.65f, 0.85f, 0.22f, 0.40f)
        ),
        // STREAM (Moonlight etc., usually 1:1 or slightly stretched): light touch, cheap, low latency
        arrayOf(
            P(0.40f, 0.10f, 0.40f, 0.08f, 0.12f),
            P(0.50f, 0.20f, 0.40f, 0.14f, 0.20f),
            P(0.60f, 0.30f, 0.45f, 0.20f, 0.30f)
        ),
        // GAME (native pixels): sharpen + FXAA only; no cleanup passes (cheapest, least latency, HUD stays crisp)
        arrayOf(
            P(0.45f, 0.00f, 0.40f, 0.00f, 0.00f, Cfg.AA_FXAA_FAST, 0.35f),
            P(0.60f, 0.00f, 0.40f, 0.00f, 0.00f, Cfg.AA_FXAA_QUALITY, 0.45f),
            P(0.75f, 0.00f, 0.40f, 0.00f, 0.00f, Cfg.AA_FXAA_QUALITY, 0.65f)
        ),
        // PHOTO (shown in a gallery app): stretched, so Detail radius is large, denoise small, AA off
        arrayOf(
            P(0.40f, 0.30f, 0.65f, 0.12f, 0.10f),
            P(0.50f, 0.42f, 0.70f, 0.18f, 0.15f),
            P(0.60f, 0.55f, 0.80f, 0.25f, 0.20f)
        ),
        // MOVIE (Netflix / YouTube HD...): almost transparent
        arrayOf(
            P(0.22f, 0.00f, 0.45f, 0.00f, 0.10f),
            P(0.32f, 0.10f, 0.45f, 0.00f, 0.15f),
            P(0.42f, 0.18f, 0.50f, 0.00f, 0.20f)
        ),
        // ANIME (already stretched: edges are smooth, so AA off; banding is still the main enemy)
        arrayOf(
            P(0.38f, 0.15f, 0.55f, 0.12f, 0.30f),
            P(0.48f, 0.25f, 0.60f, 0.18f, 0.45f),
            P(0.58f, 0.35f, 0.65f, 0.25f, 0.60f)
        ),
        // TEXT (already stretched by the app): a little wider radius than in the player
        arrayOf(
            P(0.48f, 0.45f, 0.40f, 0.05f, 0.00f),
            P(0.60f, 0.62f, 0.42f, 0.08f, 0.00f),
            P(0.72f, 0.80f, 0.46f, 0.10f, 0.00f)
        )
    )

    fun get(type: Int, level: Int, inPlayer: Boolean): P =
        (if (inPlayer) PLAYER else OVERLAY)[type.coerceIn(0, COUNT - 1)][level.coerceIn(0, 2)]

    const val PERF = 0
    const val BALANCED = 1
    const val QUALITY = 2

    /**
     * GPU budget on top of a table entry (like DLSS Performance / Balanced / Quality; this is about cost, while
     * the strength Light / Balanced / Strong is about how much help the picture needs).
     *  - PERF: upscale + sharpen only. Detail, denoise, deband and Edge-Smooth are off, FXAA stays at its cheap
     *    "Fast" variant. Cheapest, for weak GPUs and for games where latency matters.
     *  - BALANCED: the table as designed.
     *  - QUALITY: the table, but FXAA Fast is upgraded to FXAA Quality (and see [upscaleMode]).
     */
    fun withBudget(v: P, budget: Int): P = when (budget) {
        PERF -> P(
            v.sharp, 0f, v.detailSize, 0f, 0f,
            if (v.aa == Cfg.AA_FXAA_FAST || v.aa == Cfg.AA_FXAA_QUALITY) Cfg.AA_FXAA_FAST else Cfg.AA_OFF,
            v.aaStr
        )
        QUALITY -> P(
            v.sharp, v.detail, v.detailSize, v.denoise, v.deband,
            if (v.aa == Cfg.AA_FXAA_FAST) Cfg.AA_FXAA_QUALITY else v.aa,
            v.aaStr
        )
        else -> v
    }

    /**
     * Upscaler to use. On the screen overlay always RCAS-only ("Sharpen"): the capture must stay at full size or
     * detail would be lost. In the player: FSR 1 (EASU) when the picture is really enlarged (>1.15x; >1.02x with
     * the Quality budget); at about 1:1 plain RCAS is cheaper and looks the same. With the Performance budget the
     * hardware bilinear upscale ("Fast") replaces EASU, which is the heaviest upscale pass.
     */
    fun upscaleMode(inPlayer: Boolean, ratio: Float, budget: Int): Int {
        if (!inPlayer) return Cfg.MODE_SHARP
        val minRatio = if (budget == QUALITY) 1.02f else 1.15f
        if (ratio <= minRatio) return Cfg.MODE_SHARP
        return if (budget == PERF) Cfg.MODE_FAST else Cfg.MODE_FSR
    }

    /**
     * Writes a profile choice straight into [Cfg] (what tapping a quick-profile chip does, minus the UI).
     * [level] 3 = auto strength from [ratio] (player only). Returns the strength actually used (0..2).
     */
    fun applyPick(type: Int, level: Int, budget: Int, inPlayer: Boolean, ratio: Float): Int {
        val lvl = if (inPlayer && level >= 3) autoLevel(ratio) else level.coerceIn(0, 2)
        val v = withBudget(get(type, lvl, inPlayer), budget)
        Cfg.profileType = type
        Cfg.profileLevel = level.coerceIn(0, 3)
        Cfg.profileBudget = budget.coerceIn(0, 2)
        Cfg.mode = upscaleMode(inPlayer, ratio, budget)
        Cfg.scalePct = 100
        Cfg.renderPreset = Cfg.PRESET_CUSTOM
        Cfg.boost = false
        Cfg.vivid = 0f
        Cfg.sharp = v.sharp
        Cfg.detail = v.detail
        Cfg.detailSize = v.detailSize
        Cfg.denoise = v.denoise
        Cfg.deband = v.deband
        Cfg.aaMode = v.aa
        Cfg.aaStrength = v.aaStr
        Cfg.userProfile = null
        return lvl
    }

    /** Strength chosen by "Auto" (player): the more the picture is enlarged, the more help it needs. */
    fun autoLevel(ratio: Float): Int = if (ratio < 1.2f) 0 else if (ratio < 2.2f) 1 else 2
}
