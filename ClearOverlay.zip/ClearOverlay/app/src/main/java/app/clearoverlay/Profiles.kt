package app.clearoverlay

/**
 * Quick-profile tables: 12 content types x 3 strengths (Light / Balanced / Strong), in two flavours.
 *
 *  - PLAYER: values are applied to the real decoded pixels. Denoise / deband / AA run on the SOURCE
 *    resolution (before FSR 1 upscales), so even a small radius cleans real compression blocks.
 *  - OVERLAY: the screen capture already contains the picture AFTER the app stretched it. Blocks and noise are
 *    several pixels wide, so the small-radius denoise can no longer remove them (it would only soften), while the
 *    stretch blur is wide: denoise is therefore lower, Detail uses a larger radius, and AA is mostly off.
 *
 * Every table entry is a hand-tuned starting point derived from what each shader does (RCAS strength is
 * sharp x 1.2; Detail gain is amount x 3 with coring; Denoise sigma is 0.012 + 0.11 x amount; Deband threshold is
 * 0.004 + 0.03 x amount). They have not been measured on a device: judge with FX on/off + Zoom and fine-tune.
 */
object Profiles {
    const val VIDEO = 0   // low-res / soft video (e.g. 240p-480p files, YouTube at low quality)
    const val STREAM = 1  // game streaming (Moonlight, Steam Link, GeForce Now) or low-bitrate live streams
    const val GAME = 2    // game rendered on this device
    const val PHOTO = 3   // low-quality / small / heavily compressed photo
    const val MOVIE = 4   // clean HD film / series (720p and up): keep grain and texture, almost no processing
    const val ANIME = 5   // anime / cartoon: flat colours + line art
    const val TEXT = 6    // text / subtitles / UI / manga: thin strokes must stay readable
    const val MANGA = 7   // manga / comic pages: black line art, screen tones, scan or JPEG noise
    const val REPAIR = 8  // big picture but poor quality (soft, blocky, noisy 'fake HD'): strong clean-up at the source size
    const val DARK = 9    // dark picture (night scene, dark film, low light): noise and blocks show most in the shadows, so cleaner, brightness untouched
    const val BUSY = 10   // busy picture (foliage, crowds, water, fine texture): detail must stay, so almost no denoise and a soft touch with the sharpening
    const val GAMEHQ = 11 // game, best picture: sharpen + FXAA Quality + texture detail + local contrast + light temporal steadying + a gentle colour touch
    const val COUNT = 12

    class P(
        val sharp: Float,
        val detail: Float,
        val detailSize: Float,
        val denoise: Float,
        val deband: Float,
        val aa: Int = Cfg.AA_OFF,
        val aaStr: Float = 0.5f
    )

    private val PLAYER: Array<Array<P>> = arrayOf(
        // VIDEO: clean blocks first (at source size), then undo the stretch blur
        arrayOf(
            P(0.30f, 0.19f, 0.36f, 0.11f, 0.09f),
            P(0.38f, 0.31f, 0.44f, 0.16f, 0.10f),
            P(0.46f, 0.37f, 0.60f, 0.24f, 0.14f)
        ),
        // STREAM (live / low-bitrate HLS): moderate cleanup, text and HUD stay crisp
        arrayOf(
            P(0.35f, 0.14f, 0.34f, 0.10f, 0.08f),
            P(0.42f, 0.21f, 0.28f, 0.13f, 0.12f),
            P(0.50f, 0.25f, 0.36f, 0.17f, 0.20f)
        ),
        // GAME (recorded gameplay): sharp + a little cleanup, FXAA Fast only for jagged edges (the Quality budget upgrades it to FXAA Quality; 3.96.3 test: Fast scored higher than Quality at the old strengths)
        arrayOf(
            P(0.38f, 0.05f, 0.30f, 0.05f, 0.04f, Cfg.AA_FXAA_FAST, 0.45f),
            P(0.50f, 0.08f, 0.30f, 0.06f, 0.06f, Cfg.AA_FXAA_FAST, 0.55f),
            P(0.60f, 0.11f, 0.30f, 0.08f, 0.08f, Cfg.AA_FXAA_FAST, 0.65f)
        ),
        // PHOTO: JPEG blocks live at source size, so denoise there; edge-smooth only along edges
        arrayOf(
            P(0.35f, 0.20f, 0.34f, 0.17f, 0.14f),
            P(0.45f, 0.21f, 0.54f, 0.24f, 0.14f),
            P(0.55f, 0.27f, 0.56f, 0.44f, 0.14f)
        ),
        // MOVIE (clean HD): nearly transparent. No denoise (it would erase film grain), light deband only
        arrayOf(
            P(0.20f, 0.12f, 0.24f, 0.00f, 0.04f),
            P(0.30f, 0.13f, 0.24f, 0.03f, 0.15f),
            P(0.40f, 0.19f, 0.35f, 0.06f, 0.15f)
        ),
        // ANIME: flat areas denoise very well, gradients band badly, lines need clean edges
        arrayOf(
            P(0.35f, 0.21f, 0.26f, 0.35f, 0.12f),
            P(0.45f, 0.22f, 0.32f, 0.45f, 0.18f),
            P(0.55f, 0.23f, 0.34f, 0.52f, 0.48f)
        ),
        // TEXT: thin strokes need a tight, strong Detail radius; a moderate denoise (it removes the JPEG ringing around the strokes, but more would eat them), no deband
        arrayOf(
            P(0.50f, 0.50f, 0.25f, 0.22f, 0.00f),
            P(0.62f, 0.55f, 0.25f, 0.28f, 0.00f),
            P(0.74f, 0.62f, 0.25f, 0.34f, 0.00f)
        ),
        // MANGA: crisp ink lines (tight Detail), clean JPEG / scan noise, smooth the staircase of upscaled lines;
        // no deband (it would blur screen tones / halftone patterns)
        arrayOf(
            P(0.55f, 0.75f, 0.45f, 0.25f, 0.00f),
            P(0.68f, 0.85f, 0.45f, 0.30f, 0.00f),
            P(0.80f, 0.90f, 0.45f, 0.35f, 0.00f)
        ),
        // REPAIR: heavy clean-up of blocks / noise / banding first, a wide Detail radius for the soft picture, light sharpening
        arrayOf(
            P(0.30f, 0.30f, 0.40f, 0.21f, 0.14f, Cfg.AA_EDGE, 0.30f),
            P(0.36f, 0.44f, 0.54f, 0.36f, 0.20f, Cfg.AA_EDGE, 0.40f),
            P(0.42f, 0.55f, 0.65f, 0.75f, 0.26f, Cfg.AA_EDGE, 0.50f)
        ),
        // DARK: night scenes / dark films: noise and blocks sit in the shadows (wider Detail radius so the noise is not sharpened, more deband for the dark gradients), no AA
        arrayOf(
            P(0.30f, 0.20f, 0.55f, 0.10f, 0.25f),
            P(0.38f, 0.25f, 0.55f, 0.15f, 0.35f),
            P(0.46f, 0.40f, 0.55f, 0.22f, 0.45f)
        ),
        // BUSY: foliage, crowds, water, fine texture: the picture is already full of detail, so almost no denoise and a small Detail amount (it would only amplify the texture)
        arrayOf(
            P(0.30f, 0.12f, 0.50f, 0.05f, 0.15f),
            P(0.38f, 0.15f, 0.50f, 0.08f, 0.25f),
            P(0.46f, 0.18f, 0.50f, 0.12f, 0.40f)
        ),
        // GAME HQ (recorded gameplay): only picture quality. Sharpen, FXAA Quality for jagged edges, a little Detail for texture,
        // a very light cleanup for the recording's compression; the colours are not touched
        arrayOf(
            P(0.38f, 0.12f, 0.34f, 0.03f, 0.04f, Cfg.AA_FXAA_QUALITY, 0.45f),
            P(0.48f, 0.17f, 0.36f, 0.04f, 0.05f, Cfg.AA_FXAA_QUALITY, 0.55f),
            P(0.58f, 0.22f, 0.38f, 0.05f, 0.06f, Cfg.AA_FXAA_QUALITY, 0.65f)
        )
    )

    private val OVERLAY: Array<Array<P>> = arrayOf(
        // VIDEO (already stretched by the app): wide Detail radius, only a little denoise
        arrayOf(
            P(0.40f, 0.29f, 0.60f, 0.06f, 0.14f),
            P(0.50f, 0.41f, 0.71f, 0.09f, 0.15f),
            P(0.58f, 0.47f, 0.85f, 0.13f, 0.19f)
        ),
        // STREAM (Moonlight etc., usually 1:1 or slightly stretched): light touch, cheap, low latency
        arrayOf(
            P(0.40f, 0.04f, 0.36f, 0.04f, 0.00f),
            P(0.50f, 0.11f, 0.33f, 0.08f, 0.02f),
            P(0.60f, 0.15f, 0.40f, 0.11f, 0.10f)
        ),
        // GAME (native pixels): sharpen + FXAA only; no cleanup passes (cheapest, least latency, HUD stays crisp)
        arrayOf(
            P(0.35f, 0.00f, 0.40f, 0.00f, 0.00f, Cfg.AA_FXAA_FAST, 0.35f),
            P(0.48f, 0.00f, 0.40f, 0.00f, 0.00f, Cfg.AA_FXAA_FAST, 0.40f),
            P(0.61f, 0.00f, 0.40f, 0.00f, 0.00f, Cfg.AA_FXAA_FAST, 0.45f)
        ),
        // PHOTO (shown in a gallery app): stretched, so Detail radius is large, denoise small, AA off
        arrayOf(
            P(0.40f, 0.15f, 0.61f, 0.07f, 0.12f),
            P(0.50f, 0.18f, 0.75f, 0.12f, 0.09f),
            P(0.60f, 0.22f, 0.84f, 0.22f, 0.04f)
        ),
        // MOVIE (Netflix / YouTube HD...): almost transparent
        arrayOf(
            P(0.22f, 0.12f, 0.41f, 0.00f, 0.04f),
            P(0.32f, 0.13f, 0.41f, 0.01f, 0.15f),
            P(0.42f, 0.19f, 0.50f, 0.00f, 0.13f)
        ),
        // ANIME (already stretched: edges are smooth, so AA off; banding is still the main enemy)
        arrayOf(
            P(0.38f, 0.21f, 0.50f, 0.19f, 0.12f),
            P(0.48f, 0.22f, 0.58f, 0.25f, 0.18f),
            P(0.58f, 0.23f, 0.61f, 0.30f, 0.48f)
        ),
        // TEXT (already stretched by the app): a little wider radius than in the player
        arrayOf(
            P(0.48f, 0.45f, 0.38f, 0.11f, 0.00f),
            P(0.60f, 0.49f, 0.39f, 0.15f, 0.00f),
            P(0.72f, 0.57f, 0.41f, 0.18f, 0.00f)
        ),
        // MANGA (shown by another app)
        arrayOf(
            P(0.55f, 0.72f, 0.51f, 0.13f, 0.00f),
            P(0.68f, 0.81f, 0.52f, 0.16f, 0.00f),
            P(0.80f, 0.84f, 0.53f, 0.18f, 0.00f)
        ),
        // REPAIR (already stretched by the app): less denoise, wider Detail
        arrayOf(
            P(0.35f, 0.35f, 0.61f, 0.14f, 0.09f),
            P(0.42f, 0.52f, 0.71f, 0.24f, 0.10f),
            P(0.50f, 0.62f, 0.80f, 0.45f, 0.11f)
        ),
        // DARK (already stretched by the app)
        arrayOf(
            P(0.33f, 0.20f, 0.75f, 0.05f, 0.25f),
            P(0.41f, 0.25f, 0.75f, 0.07f, 0.35f),
            P(0.49f, 0.40f, 0.75f, 0.10f, 0.45f)
        ),
        // BUSY (already stretched by the app)
        arrayOf(
            P(0.33f, 0.12f, 0.70f, 0.02f, 0.15f),
            P(0.41f, 0.15f, 0.70f, 0.04f, 0.25f),
            P(0.49f, 0.18f, 0.70f, 0.05f, 0.40f)
        ),
        // GAME HQ (a game on this device, native pixels): only picture quality. A game has no compression noise, so no denoise /
        // deband (the HUD and text stay crisp); sharpen + FXAA Quality + a small, fairly wide Detail for texture clarity. No colour touch.
        arrayOf(
            P(0.38f, 0.08f, 0.40f, 0.00f, 0.00f, Cfg.AA_FXAA_QUALITY, 0.45f),
            P(0.48f, 0.13f, 0.42f, 0.00f, 0.00f, Cfg.AA_FXAA_QUALITY, 0.55f),
            P(0.58f, 0.18f, 0.44f, 0.00f, 0.00f, Cfg.AA_FXAA_QUALITY, 0.65f)
        )
    )

    fun get(type: Int, level: Int, inPlayer: Boolean): P =
        (if (inPlayer) PLAYER else OVERLAY)[type.coerceIn(0, COUNT - 1)][level.coerceIn(0, 2)]

    /**
     * A table entry BETWEEN two strengths: [t] 0 = Light, 1 = Balanced, 2 = Strong; 1.4 is 40 % of the way from Balanced to Strong.
     * Used by Auto strength, so a picture that needs "a bit more than Balanced" gets exactly that instead of jumping a whole step.
     * (The anti-aliasing choice switches at the half way point; its strength blends.)
     */
    fun getBlend(type: Int, t: Float, inPlayer: Boolean): P {
        val x = t.coerceIn(0f, 2f)
        val lo = x.toInt().coerceAtMost(1)
        val f = x - lo
        val a = get(type, lo, inPlayer)
        if (f < 0.001f) return a
        val b = get(type, lo + 1, inPlayer)
        fun m(p: Float, q: Float) = p + (q - p) * f
        return P(m(a.sharp, b.sharp), m(a.detail, b.detail), m(a.detailSize, b.detailSize), m(a.denoise, b.denoise), m(a.deband, b.deband),
            if (f < 0.5f) a.aa else b.aa, m(a.aaStr, b.aaStr))
    }

    /**
     * Auto strength as a smooth number 0 (Light) .. 2 (Strong), from how much the picture is enlarged (the more, the more help it needs;
     * the anchors keep the old steps: under 1.2x about Light, 1.2 - 2.2x about Balanced, above that Strong) and, when the bit rate is
     * known, from how few bits each pixel got: [quality] = effective bits per pixel (see [Auto.forVideo], already corrected for HEVC / VP9 / AV1).
     * A video squeezed into few bits is blocky and needs more help; a rich one needs less. -1 = unknown: only the enlargement counts.
     */
    fun autoStrength(ratio: Float, quality: Float = -1f): Float {
        val r = ratio
        var t = when {
            r <= 1.0f -> 0f
            r < 1.2f -> 0.5f * (r - 1f) / 0.2f
            r < 1.7f -> 0.5f + 0.5f * (r - 1.2f) / 0.5f
            r < 2.2f -> 1f + 0.5f * (r - 1.7f) / 0.5f
            r < 3.2f -> 1.5f + 0.5f * (r - 2.2f) / 1f
            else -> 2f
        }
        if (quality > 0f) t += when {
            quality < 0.035f -> 0.6f
            quality < 0.06f -> 0.35f
            quality < 0.09f -> 0.15f
            quality > 0.20f -> -0.3f
            quality > 0.12f -> -0.15f
            else -> 0f
        }
        return t.coerceIn(0f, 2f)
    }

    /** The strength in force as a number 0..2: a chip (0 / 1 / 2) as it is, Auto (3, player only) from [autoStrength]. */
    fun resolveStrength(level: Int, inPlayer: Boolean, ratio: Float, quality: Float = -1f): Float =
        if (inPlayer && level >= 3) autoStrength(ratio, quality) else level.coerceIn(0, 2).toFloat()

    const val PERF = 0
    const val BALANCED = 1
    const val QUALITY = 2

    /**
     * GPU budget on top of a table entry (like DLSS Performance / Balanced / Quality; this is about cost, while
     * the strength Light / Balanced / Strong is about how much help the picture needs).
     *  - PERF: upscale + sharpen only. Detail, denoise, deband and Edge-Smooth are off, FXAA stays at its cheap
     *    "Fast" variant. Cheapest, for weak GPUs and for games where latency matters.
     *  - BALANCED: the table as designed.
     *  - QUALITY: the table, but FXAA Fast is upgraded to FXAA Quality (and see [upscaleMode]).
     */
    fun withBudget(v: P, budget: Int): P = when (budget) {
        PERF -> P(
            v.sharp, 0f, v.detailSize, 0f, 0f,
            if (v.aa == Cfg.AA_FXAA_FAST || v.aa == Cfg.AA_FXAA_QUALITY) Cfg.AA_FXAA_FAST else Cfg.AA_OFF,
            v.aaStr
        )
        QUALITY -> P(
            v.sharp, v.detail, v.detailSize, v.denoise, v.deband,
            if (v.aa == Cfg.AA_FXAA_FAST) Cfg.AA_FXAA_QUALITY else v.aa,
            v.aaStr
        )
        else -> v
    }

    /**
     * Upscaler to use. On the screen overlay always RCAS-only ("Sharpen"): the capture must stay at full size or
     * detail would be lost. In the player: FSR 1 (EASU) when the picture is really enlarged (>1.15x; >1.02x with
     * the Quality budget); at about 1:1 plain RCAS is cheaper and looks the same. With the Performance budget the
     * hardware bilinear upscale ("Fast") replaces EASU, which is the heaviest upscale pass.
     */
    fun upscaleMode(inPlayer: Boolean, ratio: Float, budget: Int, type: Int = -1): Int {
        if (!inPlayer) return Cfg.MODE_SHARP
        val minRatio = if (budget == QUALITY) 1.02f else 1.15f
        if (ratio <= minRatio) return Cfg.MODE_SHARP
        if (budget == PERF) return Cfg.MODE_FAST
        // Offline test (x2, test sets for each content type): CRSC Edge beat FSR 1 on photos, compressed video, anime,
        // text and manga. Single pictures (photo / text / manga) can always afford it; video and streams use it with the
        // Quality budget (the Auto choice for sources up to about 1080p30), otherwise FSR 1 stays the cheaper choice.
        val still = type == PHOTO || type == TEXT || type == MANGA || type == REPAIR
        return if (type >= 0 && (still || budget == QUALITY)) Cfg.MODE_LANCZOS else Cfg.MODE_FSR
    }

    /**
     * CRSC Edge level (0 light .. 3 crisp) per content type, from the offline tests (PSNR / SSIM against the original):
     * photo, video, movie, anime: balanced; text and manga: ultra (the sharpest live level, thin strokes gain most); game and stream: light
     * (cheapest, nearly as good as plain scaling on aliased game pictures, keeps latency low).
     */
    fun crscFor(type: Int): Int = when (type) {
        TEXT, MANGA -> 4
        STREAM, GAME -> 0
        else -> 1
    }

    /**
     * Writes a profile choice straight into [Cfg] (what tapping a quick-profile chip does, minus the UI).
     * [level] 3 = auto strength from [ratio] (player only). Returns the strength actually used (0..2).
     */
    fun applyPick(type: Int, level: Int, budget: Int, inPlayer: Boolean, ratio: Float, quality: Float = -1f): Int {
        val t = resolveStrength(level, inPlayer, ratio, quality)
        val lvl = Math.round(t).coerceIn(0, 2)
        Cfg.strengthNow = t
        val v = withBudget(getBlend(type, t, inPlayer), budget)
        Cfg.profileType = type
        Cfg.profileLevel = level.coerceIn(0, 3)
        Cfg.profileBudget = budget.coerceIn(0, 2)
        Cfg.mode = upscaleMode(inPlayer, ratio, budget, type)
        Cfg.crscLevel = crscFor(type)
        Cfg.scalePct = 100
        Cfg.renderPreset = Cfg.PRESET_CUSTOM
        Cfg.boost = false
        Cfg.vivid = 0f
        Cfg.shadows = 0f; Cfg.highlights = 0f; Cfg.saturation = 0f; Cfg.warmth = 0f; Cfg.grain = 0f
        Cfg.brightness = 0f; Cfg.vibrance = 0f; Cfg.tint = 0f
        Cfg.clarity = 0f; Cfg.antiRing = 0f; Cfg.deint = 0
        Cfg.sharp = v.sharp
        Cfg.detail = v.detail
        Cfg.detailSize = v.detailSize
        Cfg.denoise = v.denoise
        Cfg.deband = v.deband
        Cfg.aaMode = v.aa
        Cfg.aaStrength = v.aaStr
        applyLook(type, lvl)
        applyRelated(type, t, budget, inPlayer, ratio)
        Cfg.userProfile = null
        return lvl
    }

    /**
     * Strength and GPU budget also drive the settings of the sections they belong to (before this they only set the six picture values
     * and the upscaler, and the rest stayed whatever it was or was reset to zero). Called after the picture values by [applyPick] and by
     * the quick-profile chips. Does nothing while the global Auto is on (Auto.applyExtras decides these itself, with its own measurements).
     *
     *  - CRSC Edge: level from the content type, one step lower on a light touch for video-like pictures, one higher on Strong, and one
     *    higher for single pictures (photo / text / manga / repair) with the Quality budget, which also turns "exact mode" on for them
     *    (a single picture can afford the full computation). Performance caps it at 1. NIS crispness is reset.
     *  - Anti-ringing: only when the sharpening is strong (high sharpness, NIS, CRSC Edge Crisp / Ultra), 25 / 35 / 45 % by strength, off with Performance.
     *  - Clarity (player, film-like pictures: photo, HD movie, low-res video; Balanced and Quality budgets): a touch, growing with the strength.
     *  - Clean upscale (player, soft or blocky pictures: low-res video, repair, dark; only when the picture is enlarged, Balanced / Quality budgets):
     *    on from half way between Light and Balanced, 20 - 70 % growing with the strength (repair +15 %). Off for every other profile.
     *  - Temporal clean-up (player, same pictures): light, on a Strong touch with Balanced / Quality. Off for every other profile.
     *  - Performance turns Clean upscale and Temporal clean-up off (it means upscale + sharpen only).
     */
    fun applyRelated(type: Int, t: Float, budget: Int, inPlayer: Boolean, ratio: Float) {
        if (Cfg.autoMode) return
        val s = t.coerceIn(0f, 2f)
        val lvl = Math.round(s).coerceIn(0, 2)
        val still = type == PHOTO || type == TEXT || type == MANGA || type == REPAIR
        // CRSC Edge
        var c = crscFor(type)
        if (c in 1..3) {
            if (s < 0.5f && !still) c = 0
            if (s >= 1.5f) c += 1
            if (budget == QUALITY && still && s >= 0.5f) c += 1
            c = c.coerceIn(0, 3)
        }
        if (budget == PERF) c = c.coerceAtMost(1)
        val enlarged = inPlayer && ratio > 1.15f
        // Game LQ (720p -> 1080p / 1440p): an enlarged game picture is aliased, so the edge-directed upscaler gets a real level (1)
        if (type == GAME && enlarged && budget != PERF) c = if (s >= 1.5f) 2 else 1
        Cfg.crscLevel = c
        Cfg.crscExact = Cfg.mode == Cfg.MODE_LANCZOS && budget == QUALITY && still
        Cfg.crscNis = 0
        Cfg.crscNisFast = false
        // anti-ringing
        val strongSharp = Cfg.sharp >= 0.55f || Cfg.mode == Cfg.MODE_NIS_ORIG || Cfg.mode == Cfg.MODE_NIS ||
            (Cfg.mode == Cfg.MODE_LANCZOS && Cfg.crscLevel >= 3)
        Cfg.antiRing = if (!strongSharp || budget == PERF) 0f else 0.25f + 0.10f * lvl
        // games: an enlarged picture rings at hard edges (HUD, fences); HQ also keeps it on at every strength
        if (budget != PERF && ((type == GAME && enlarged) || type == GAMEHQ)) Cfg.antiRing = maxOf(Cfg.antiRing, 0.20f + 0.08f * lvl)
        // clarity
        Cfg.clarity = if (inPlayer && budget >= BALANCED && (type == PHOTO || type == MOVIE || type == VIDEO)) {
            val base = when (type) { PHOTO -> 0.20f; MOVIE -> 0.12f; else -> 0.08f }
            Math.round(base * (0.6f + 0.35f * s) * (if (budget == QUALITY) 1f else 0.75f) * 100f) / 100f
        } else 0f
        // Game HQ: local contrast (clarity) gives the "depth" of a modern reconstruction; light temporal accumulation steadies shimmering edges
        if (type == GAMEHQ && budget >= BALANCED) Cfg.clarity = Math.round((0.08f + 0.06f * s) * (if (budget == QUALITY) 1f else 0.8f) * 100f) / 100f
        // clean upscale + temporal clean-up (player)
        if (inPlayer) {
            val cleaning = budget >= BALANCED && (type == VIDEO || type == REPAIR || type == DARK)
            if (cleaning && ratio > 1.15f && s >= 0.5f) {
                Cfg.cleanUp = true
                Cfg.cleanLevel = (0.30f + 0.20f * (s - 1f) + (if (type == REPAIR) 0.15f else 0f)).coerceIn(0.2f, 0.7f)
            } else {
                Cfg.cleanUp = false
            }
            Cfg.playerTemporal = if ((cleaning && s >= 1.5f) || (type == GAMEHQ && budget >= BALANCED && s >= 0.5f && Cfg.section != "stream")) 1 else 0
        }
    }

    /**
     * The colour touch of the GAME profile: a little contrast, vibrance (colour that spares what is already strong, so the
     * HUD and skin tones do not turn garish) and shadow lift (dark corners stay readable). One row per strength; Light has
     * none, so it stays the cheapest and lowest-latency choice (no colour pass at all). Rows are contrast, vibrance, shadows.
     */
    private val GAME_LOOK = arrayOf(
        floatArrayOf(0f, 0f, 0f),
        floatArrayOf(0.05f, 0.10f, 0.06f),
        floatArrayOf(0.09f, 0.16f, 0.10f)
    )

    /** Game HQ: a gentler colour touch at every strength (contrast, vibrance, shadows): more depth, nothing garish. */
    private val GAMEHQ_LOOK = arrayOf(
        floatArrayOf(0.02f, 0.05f, 0.03f),
        floatArrayOf(0.04f, 0.08f, 0.06f),
        floatArrayOf(0.06f, 0.12f, 0.08f)
    )

    /** True when contrast / vibrance / shadows are exactly one of the game rows (so they came from a Game profile, not from the user). */
    private fun hasGameLook(): Boolean = (GAME_LOOK.drop(1) + GAMEHQ_LOOK).any {
        Math.abs(Cfg.contrast - it[0]) < 0.0005f && Math.abs(Cfg.vibrance - it[1]) < 0.0005f && Math.abs(Cfg.shadows - it[2]) < 0.0005f
    }

    /**
     * Sets (Game, Game HQ) or removes (any other profile, if the game touch is still what is in force) the colour touch. Called
     * after the picture values of a profile were written, by [applyPick] and by the quick-profile chips.
     */
    fun applyLook(type: Int, lvl: Int) {
        if (type == GAME || type == GAMEHQ) {
            val g = (if (type == GAME) GAME_LOOK else GAMEHQ_LOOK)[lvl.coerceIn(0, 2)]
            Cfg.contrast = g[0]
            Cfg.vibrance = g[1]
            Cfg.shadows = g[2]
        } else if (hasGameLook()) {
            Cfg.contrast = 0f
            Cfg.vibrance = 0f
            Cfg.shadows = 0f
        }
    }

    /** Strength chosen by "Auto" (player): the more the picture is enlarged, the more help it needs. */
    fun autoLevel(ratio: Float): Int = if (ratio < 1.2f) 0 else if (ratio < 2.2f) 1 else 2

    /** The label of a content type (all 11 of them). */
    fun nameRes(type: Int): Int = when (type) {
        VIDEO -> R.string.profile_video
        STREAM -> R.string.profile_stream
        GAME -> R.string.profile_game
        PHOTO -> R.string.profile_photo
        MOVIE -> R.string.profile_movie
        ANIME -> R.string.profile_anime
        TEXT -> R.string.profile_text
        MANGA -> R.string.profile_manga
        REPAIR -> R.string.profile_repair
        DARK -> R.string.profile_dark
        BUSY -> R.string.profile_busy
        GAMEHQ -> R.string.profile_gamehq
        else -> R.string.auto_word
    }
}
