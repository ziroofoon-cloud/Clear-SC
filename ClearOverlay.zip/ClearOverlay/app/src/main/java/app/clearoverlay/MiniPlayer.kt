package app.clearoverlay

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar

/**
 * The "now playing" bar at the bottom of the app screens, like other music apps: album art, title, artist, previous / play-pause / next
 * / stop and a thin progress line. Tap the cover or the title to open the player. Hidden when nothing is loaded.
 */
object MiniPlayer {
    /** Adds the bar at the end of [parent] (a vertical LinearLayout). */
    fun attach(act: Activity, parent: LinearLayout) {
        val ui = Handler(Looper.getMainLooper())
        val cs = dp(act, 52)
        val cover = Covers.CoverView(act, cs, 12)
        val title = Ui.text(act, "", 15f, Ui.TEXT, true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        val sub = Ui.text(act, "", 12f, Ui.MUTED).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        val prog = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            progressTintList = android.content.res.ColorStateList.valueOf(Ui.ACCENT)
        }
        fun icon(kind: Int, color: Int, onClick: () -> Unit): ImageView = ImageView(act).apply {
            setImageDrawable(LineIcon(kind, color))
            val p = dp(act, 11)
            setPadding(p, p, p, p)
            setOnClickListener { onClick() }
        }
        val eq = EqView(act, 3)
        val open = { act.startActivity(Intent(act, AudioActivity::class.java)) }
        val play = icon(Icons.PLAY, Ui.ACCENT) {
            val p = MusicPlayer.player
            if (p != null) { if (p.isPlaying) p.pause() else p.play() }
        }
        val texts = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            addView(LinearLayout(act).apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(eq, LinearLayout.LayoutParams(dp(act, 14), dp(act, 14)).apply { marginEnd = dp(act, 6) })
                addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            })
            addView(sub)
            setOnClickListener { open() }
        }
        cover.setOnClickListener { open() }
        val row = LinearLayout(act).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(act, 10), dp(act, 8), dp(act, 4), dp(act, 4))
            addView(cover, LinearLayout.LayoutParams(cs, cs))
            addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(act, 12); marginEnd = dp(act, 4) })
            val sz = dp(act, 46)
            addView(icon(Icons.PREV, Ui.TEXT) { MusicPlayer.player?.seekToPreviousMediaItem() }, LinearLayout.LayoutParams(sz, sz))
            addView(play, LinearLayout.LayoutParams(sz, sz))
            addView(icon(Icons.NEXT, Ui.TEXT) { MusicPlayer.player?.seekToNextMediaItem() }, LinearLayout.LayoutParams(sz, sz))
            // share and close share one column so the title keeps its room; each icon gets a SQUARE box (the line icons have no
            // size of their own and were squashed flat in a wide, low one)
            addView(LinearLayout(act).apply {
                orientation = LinearLayout.VERTICAL
                addView(icon(Icons.MORE, Ui.TEXT) { MusicPlayer.current()?.let { MusicQuick.show(act, it) } }.apply {
                    val q = dp(act, 5); setPadding(q, q, q, q)
                }, LinearLayout.LayoutParams(dp(act, 30), dp(act, 30)))
                addView(icon(Icons.CLOSE, Ui.MUTED) { MusicService.stopAll(act) }.apply {
                    val q = dp(act, 5); setPadding(q, q, q, q)
                }, LinearLayout.LayoutParams(dp(act, 30), dp(act, 30)))
            }, LinearLayout.LayoutParams(dp(act, 30), dp(act, 60)))
        }
        val card = SwipeCard(act).apply {
            onSwipe = { d -> if (d > 0) MusicPlayer.player?.seekToNextMediaItem() else MusicPlayer.player?.seekToPreviousMediaItem() }
            orientation = LinearLayout.VERTICAL
            background = Ui.round(Ui.CARD, dp(act, 18).toFloat(), Ui.STROKE, dp(act, 1))
            visibility = View.GONE
            addView(row)
            addView(prog, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(act, 3)).apply { setMargins(dp(act, 16), 0, dp(act, 16), dp(act, 8)) })
        }
        parent.addView(card, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(act, 10), dp(act, 4), dp(act, 10), dp(act, 8)) })

        var shown: Uri? = null
        var wasPlaying: Boolean? = null
        val tick = object : Runnable {
            override fun run() {
                val p = MusicPlayer.player
                val t = MusicPlayer.current()
                if (p == null || t == null) {
                    card.visibility = View.GONE
                } else {
                    card.visibility = View.VISIBLE
                    title.text = t.title
                    sub.text = t.artist
                    sub.visibility = if (t.artist.isEmpty()) View.GONE else View.VISIBLE
                    if (t.uri != shown) {
                        shown = t.uri
                        cover.bind(t.uri)
                    }
                    if (wasPlaying != p.isPlaying) {
                        wasPlaying = p.isPlaying
                        play.setImageDrawable(LineIcon(if (p.isPlaying) Icons.PAUSE else Icons.PLAY, Ui.ACCENT))
                        eq.run(p.isPlaying)
                    }
                    val d = p.duration
                    prog.progress = if (d > 0 && d != androidx.media3.common.C.TIME_UNSET) (p.currentPosition * 1000L / d).toInt().coerceIn(0, 1000) else 0
                }
                ui.postDelayed(this, 700)
            }
        }
        card.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) { ui.removeCallbacks(tick); ui.post(tick) }
            override fun onViewDetachedFromWindow(v: View) { ui.removeCallbacks(tick) }
        })
    }
}

/**
 * A vertical bar that turns a horizontal swipe into "next song" (finger moves left) or "previous song" (finger moves right): the bar
 * follows the finger a little and springs back. Taps on the buttons inside still work (the swipe is only taken once the finger has moved sideways).
 */
class SwipeCard(ctx: Context) : LinearLayout(ctx) {
    var onSwipe: ((Int) -> Unit)? = null
    private var x0 = 0f
    private var y0 = 0f
    private var swiping = false
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { x0 = e.rawX; y0 = e.rawY; swiping = false }
            MotionEvent.ACTION_MOVE -> if (!swiping && Math.abs(e.rawX - x0) > slop * 2 && Math.abs(e.rawX - x0) > Math.abs(e.rawY - y0) * 1.5f) {
                swiping = true
                parent?.requestDisallowInterceptTouchEvent(true)
            }
        }
        return swiping
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!swiping) return super.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_MOVE -> translationX = (e.rawX - x0) * 0.5f
            MotionEvent.ACTION_UP -> {
                val dx = e.rawX - x0
                swiping = false
                animate().translationX(0f).setDuration(160).start()
                if (Math.abs(dx) > dp(context, 70)) onSwipe?.invoke(if (dx < 0) 1 else -1)
            }
            MotionEvent.ACTION_CANCEL -> { swiping = false; animate().translationX(0f).setDuration(160).start() }
        }
        return true
    }
}

/** Swipe left / right on a plain view (the cover of the full-screen player): [onSwipe] gets +1 (next) or -1 (previous). */
fun View.swipeSongs(onSwipe: (Int) -> Unit) {
    var x0 = 0f
    var y0 = 0f
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { x0 = e.rawX; y0 = e.rawY; true }
            MotionEvent.ACTION_MOVE -> { v.translationX = (e.rawX - x0) * 0.4f; true }
            MotionEvent.ACTION_UP -> {
                val dx = e.rawX - x0
                val dy = e.rawY - y0
                v.animate().translationX(0f).setDuration(160).start()
                if (Math.abs(dx) > dp(v.context, 70) && Math.abs(dx) > Math.abs(dy) * 1.5f) onSwipe(if (dx < 0) 1 else -1)
                true
            }
            MotionEvent.ACTION_CANCEL -> { v.animate().translationX(0f).setDuration(160).start(); true }
            else -> false
        }
    }
}
