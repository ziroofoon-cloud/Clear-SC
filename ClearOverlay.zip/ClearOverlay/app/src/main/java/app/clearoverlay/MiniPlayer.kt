package app.clearoverlay

import android.app.Activity
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView

/** The small "now playing" bar at the bottom of the app screens, like other music apps. Hidden when nothing is loaded. */
object MiniPlayer {
    /** Adds the bar at the end of [parent] (a vertical LinearLayout). */
    fun attach(act: Activity, parent: LinearLayout) {
        val ui = Handler(Looper.getMainLooper())
        val title = Ui.text(act, "", 14f, Ui.TEXT, true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        val sub = Ui.text(act, "", 11f, Ui.MUTED).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        val prog = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000 }
        fun btn(label: String, onClick: () -> Unit) = Ui.text(act, label, 18f, Ui.ACCENT, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(act, 12), dp(act, 6), dp(act, 12), dp(act, 6))
            setOnClickListener { onClick() }
        }
        lateinit var play: TextView
        play = btn("▶") {
            val p = MusicPlayer.player
            if (p != null) { if (p.isPlaying) p.pause() else p.play() }
        }
        val texts = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            addView(title)
            addView(sub)
            setOnClickListener { act.startActivity(Intent(act, AudioActivity::class.java)) }
        }
        val row = LinearLayout(act).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(act, 14), dp(act, 6), dp(act, 6), dp(act, 4))
            addView(Ui.text(act, "♪", 20f, Ui.ACCENT, true).apply { setPadding(0, 0, dp(act, 10), 0) })
            addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(btn("◀◀") { MusicPlayer.player?.seekToPreviousMediaItem() })
            addView(play)
            addView(btn("▶▶") { MusicPlayer.player?.seekToNextMediaItem() })
            addView(btn("✕") { MusicService.stopAll(act) })
        }
        val card = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.round(Ui.CARD, dp(act, 14).toFloat(), Ui.STROKE, dp(act, 1))
            visibility = View.GONE
            addView(row)
            addView(prog, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(act, 3)).apply { setMargins(dp(act, 14), 0, dp(act, 14), dp(act, 6)) })
        }
        parent.addView(card, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(act, 10), dp(act, 4), dp(act, 10), dp(act, 8)) })

        val tick = object : Runnable {
            override fun run() {
                val p = MusicPlayer.player
                val t = MusicPlayer.current()
                if (p == null || t == null) {
                    card.visibility = View.GONE
                } else {
                    card.visibility = View.VISIBLE
                    title.text = t.title
                    sub.text = t.artist
                    sub.visibility = if (t.artist.isEmpty()) View.GONE else View.VISIBLE
                    play.text = if (p.isPlaying) "❚❚" else "▶"
                    val d = p.duration
                    prog.progress = if (d > 0 && d != androidx.media3.common.C.TIME_UNSET) (p.currentPosition * 1000L / d).toInt().coerceIn(0, 1000) else 0
                }
                ui.postDelayed(this, 700)
            }
        }
        card.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) { ui.removeCallbacks(tick); ui.post(tick) }
            override fun onViewDetachedFromWindow(v: View) { ui.removeCallbacks(tick) }
        })
    }
}
