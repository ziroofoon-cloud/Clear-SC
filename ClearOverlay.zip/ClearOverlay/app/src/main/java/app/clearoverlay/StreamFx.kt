package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.Surface
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import com.limelight.ClearHook
import java.util.concurrent.atomic.AtomicBoolean
import java.util.function.Consumer
import kotlin.math.roundToInt

/**
 * The embedded game-streaming client (Artemis / Moonlight) wired straight into the +CRSC engine.
 *
 * Picture: the client's video decoder draws into the [GlPipeline] input surface (instead of the window), the pipeline
 * runs FSR 1 / SGSR 1 / NIS / CRSC, sharpening, temporal clean-up and frame generation, and draws the result into the
 * stream window. No screen capture, no floating layer: one GPU pass less and no capture delay.
 * Sound: every decoded audio packet goes through [AudioFxCore] (the sound enhancer) before it reaches the AudioTrack.
 *
 * The client registers this object by name (see [ClearHook.ensureInstalled]); the module itself does not know the app.
 */
object StreamFx {
    private const val PREFS = "crsc_stream"
    private val ui = Handler(Looper.getMainLooper())

    @Volatile private var gl: GlPipeline? = null
    private var appCtx: Context? = null
    @Volatile private var srcLong = 1280

    // ---- settings of the stream (own file: the video player keeps its own frame generation / temporal choices) ----
    private fun sp(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** True = the stream is processed inside the app (default). False = the client renders to the window as the original. */
    fun directOn(c: Context) = sp(c).getBoolean("direct", true)
    fun setDirect(c: Context, on: Boolean) = sp(c).edit().putBoolean("direct", on).apply()

    private fun applyFlags(g: GlPipeline, c: Context) {
        val s = sp(c)
        g.bypass = !s.getBoolean("fx", true)
        g.frameGen = s.getBoolean("fg", false)
        g.frameGenN = s.getInt("fgn", 2).coerceIn(2, 4)
        g.fgQuality = s.getInt("fgq", 0).coerceIn(0, 3) // light by default: least delay, least heat
        g.temporal = s.getInt("tmp", 0).coerceIn(0, 2)
        g.maxProcRatio = 1.5f
    }

    @JvmStatic
    fun install(c: Context) {
        appCtx = c.applicationContext
        ClearHook.video = videoHook
        ClearHook.audio = audioHook
    }

    // ------------------------------------------------------------------------------------------ sound
    private val core = AudioFxCore()
    private var chans = 2
    private var fbuf = FloatArray(0)

    private val audioHook = object : ClearHook.Audio {
        override fun configure(sampleRate: Int, channels: Int) {
            appCtx?.let { AudioCfg.load(it) }
            chans = channels
            if (channels in 1..2) core.configure(sampleRate, channels)
        }

        override fun process(pcm: ShortArray) {
            // surround (5.1 / 7.1) is left untouched: the enhancer works on mono / stereo
            if (!AudioCfg.on || chans !in 1..2) return
            val n = pcm.size
            if (fbuf.size < n) fbuf = FloatArray(n)
            for (i in 0 until n) fbuf[i] = pcm[i] / 32768f
            core.process(fbuf, n / chans, AudioCfg.snapshot())
            for (i in 0 until n) pcm[i] = (fbuf[i] * 32767f).roundToInt().coerceIn(-32768, 32767).toShort()
        }
    }

    // ------------------------------------------------------------------------------------------ picture
    private val videoHook = object : ClearHook.Video {
        override fun enabled(c: Context) = directOn(c)

        override fun start(c: Context, out: Surface, streamW: Int, streamH: Int, onInput: Consumer<Surface?>) {
            val app = c.applicationContext
            appCtx = app
            srcLong = maxOf(streamW, streamH, 1)
            // the stream has its own picture settings section (first time: the "Stream" quick profile, FSR 1 when upscaling)
            Cfg.bind(app, "stream")
            val s = sp(app)
            if (!s.getBoolean("seeded", false)) {
                val dm = app.resources.displayMetrics
                val ratio = maxOf(dm.widthPixels, dm.heightPixels).toFloat() / maxOf(streamW, streamH, 1)
                Profiles.applyPick(Profiles.STREAM, 1, Profiles.BALANCED, true, ratio)
                Cfg.save(app)
                s.edit().putBoolean("seeded", true).apply()
            }
            if (OverlayService.running) {
                ui.post { Toast.makeText(app, Lang.wrap(app).getString(R.string.sfx_layer_warn), Toast.LENGTH_LONG).show() }
            }
            val g = GlPipeline(out)
            val delivered = AtomicBoolean(false)
            g.onError = { msg ->
                ui.post { Toast.makeText(app, "+CRSC: $msg".take(240), Toast.LENGTH_LONG).show() }
                if (delivered.compareAndSet(false, true)) {
                    // the engine could not start: give the window back and let the client render straight to it
                    ui.post {
                        g.release()
                        if (gl === g) gl = null
                        onInput.accept(null)
                    }
                }
            }
            applyFlags(g, app)
            gl = g
            g.start(streamW, streamH) { input ->
                if (delivered.compareAndSet(false, true)) onInput.accept(input)
            }
        }

        override fun release() {
            val g = gl ?: return
            gl = null
            g.release()
            appCtx?.let { Cfg.bind(it, "screen") }
        }

        override fun menuLabel(c: Context): String = Lang.wrap(c).getString(R.string.sfx_menu)

        override fun showSettings(a: Activity) {
            val g = gl ?: return
            showDialog(a, g)
        }
    }

    private fun showDialog(a: Activity, g: GlPipeline) {
        val app = a.applicationContext
        Ui.init(a)
        val ctx = Ui.themed(Lang.wrap(a))
        val s = sp(app)
        val pad = dp(ctx, 16)
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        fun gap(v: Int) = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(ctx, v) }
        fun head(res: Int) = Ui.text(ctx, ctx.getString(res), 14f, Ui.ACCENT, true)

        col.addView(Ui.text(ctx, ctx.getString(R.string.sfx_title), 17f, Ui.TEXT, true))
        if (OverlayService.running) col.addView(Ui.text(ctx, ctx.getString(R.string.sfx_layer_warn), 12f, Ui.DANGER), gap(6))

        // ---- picture: the same panel as the video player (profiles, upscaler list, sharpness, detail, clean-up ...)
        col.addView(head(R.string.sfx_picture), gap(14))
        col.addView(panelSwitch(ctx, ctx.getString(R.string.sfx_fx_switch), s.getBoolean("fx", true)) { on ->
            s.edit().putBoolean("fx", on).apply()
            g.bypass = !on
            g.redraw()
        }, gap(8))
        val dm = app.resources.displayMetrics
        val ratio = maxOf(dm.widthPixels, dm.heightPixels).toFloat() / srcLong
        col.addView(
            buildControls(a, inPlayer = true, sourceScale = { ratio }) { g.redraw() },
            gap(8)
        )

        // ---- temporal clean-up + frame generation (own choices for the stream)
        col.addView(head(R.string.panel_sec_temporal), gap(18))
        col.addView(Ui.text(ctx, ctx.getString(R.string.export_temporal), 12f, Ui.MUTED), gap(8))
        col.addView(
            chipRow(
                ctx,
                listOf(R.string.export_fg_off, R.string.export_temporal_light, R.string.export_temporal_strong).map { ctx.getString(it) },
                s.getInt("tmp", 0).coerceIn(0, 2)
            ) { q ->
                s.edit().putInt("tmp", q).apply()
                g.temporal = q
                g.redraw()
            },
            gap(4)
        )
        col.addView(head(R.string.panel_sec_fg), gap(18))
        col.addView(panelSwitch(ctx, ctx.getString(R.string.player_fg_switch), s.getBoolean("fg", false)) { on ->
            s.edit().putBoolean("fg", on).apply()
            g.frameGen = on
        }, gap(8))
        col.addView(Ui.text(ctx, ctx.getString(R.string.player_fg_quality), 12f, Ui.MUTED), gap(8))
        val qMap = intArrayOf(3, 0, 1, 2)
        col.addView(
            chipRow(
                ctx,
                listOf(R.string.export_fg_vlight, R.string.export_fg_light, R.string.export_fg_normal, R.string.export_fg_high).map { ctx.getString(it) },
                qMap.indexOf(s.getInt("fgq", 0).coerceIn(0, 3)).coerceAtLeast(0)
            ) { qi ->
                s.edit().putInt("fgq", qMap[qi]).apply()
                g.fgQuality = qMap[qi]
            },
            gap(4)
        )
        col.addView(Ui.text(ctx, ctx.getString(R.string.player_fg_mult), 12f, Ui.MUTED), gap(8))
        col.addView(
            chipRow(ctx, listOf("2x", "3x", "4x"), s.getInt("fgn", 2).coerceIn(2, 4) - 2) { i ->
                s.edit().putInt("fgn", i + 2).apply()
                g.frameGenN = i + 2
            },
            gap(4)
        )
        col.addView(Ui.text(ctx, ctx.getString(R.string.sfx_fg_note), 12f, Ui.MUTED), gap(4))

        // ---- sound: the same enhancer as the music / video player, applied to the stream's audio packets
        col.addView(head(R.string.sfx_sound), gap(18))
        col.addView(buildAudioPanel(ctx), gap(8))
        col.addView(Ui.text(ctx, ctx.getString(R.string.sfx_audio_hint), 12f, Ui.MUTED), gap(4))

        val sv = ScrollView(ctx).apply {
            setBackgroundColor(Ui.BG)
            addView(col)
        }
        val d = AlertDialog.Builder(a).setView(sv).setPositiveButton(android.R.string.ok, null).create()
        d.setOnDismissListener {
            Cfg.save(app)
            AudioCfg.save(app)
        }
        d.show()
        d.window?.setBackgroundDrawable(Ui.round(Ui.BG, dp(ctx, 16).toFloat()))
    }
}
