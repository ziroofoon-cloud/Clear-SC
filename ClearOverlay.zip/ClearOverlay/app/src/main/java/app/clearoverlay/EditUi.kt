package app.clearoverlay

import android.app.Activity
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * The shared look of the editors (video, audio, hub): a header with a back button, content grouped in rounded cards,
 * and a bar at the bottom that always shows the main action (Save), so it never has to be scrolled to.
 */
object EditUi {
    class Page(val root: LinearLayout, val body: LinearLayout, val bottom: LinearLayout, val title: TextView, val subtitle: TextView)

    private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    fun lp(a: Activity, top: Int = 0, w: Int = MATCH) = LinearLayout.LayoutParams(w, WRAP).apply { topMargin = dp(a, top) }

    /** Header (back, title, one-line explanation) + scrolling body + bottom bar (empty and hidden until something is added). */
    fun page(a: Activity, title: String, subtitle: String): Page {
        val root = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
        }
        root.setOnApplyWindowInsetsListener { v, ins ->
            val i = ins.getInsetsIgnoringVisibility(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            v.setPadding(i.left, i.top, i.right, i.bottom)
            ins
        }
        val head = LinearLayout(a).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(a, 8), dp(a, 8), dp(a, 16), dp(a, 8))
        }
        head.addView(Icons.button(a, Icons.CHEV_LEFT, Ui.TEXT, 44) { a.finish() })
        val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        val t = Ui.text(a, title, 20f, Ui.TEXT, true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        val s = Ui.text(a, subtitle, 12f, Ui.MUTED).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END }
        col.addView(t)
        col.addView(s, lp(a, 1, WRAP))
        head.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(a, 4) })
        root.addView(head)

        val body = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(a, 14), dp(a, 4), dp(a, 14), dp(a, 20))
        }
        val sc = ScrollView(a).apply {
            isVerticalScrollBarEnabled = false
            clipToPadding = false
            addView(body, ViewGroup.LayoutParams(MATCH, WRAP))
        }
        root.addView(sc, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val bottom = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.CARD)
            setPadding(dp(a, 14), dp(a, 10), dp(a, 14), dp(a, 10))
            visibility = View.GONE
        }
        root.addView(bottom, LinearLayout.LayoutParams(MATCH, WRAP))
        return Page(root, body, bottom, t, s)
    }

    /** A rounded card with an optional title and one-line hint; add the content with [add]. */
    fun card(a: Activity, title: String?, hint: String? = null): LinearLayout {
        val c = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.round(Ui.CARD, dp(a, 18).toFloat(), Ui.STROKE, dp(a, 1))
            val p = dp(a, 14)
            setPadding(p, dp(a, 13), p, dp(a, 14))
        }
        if (title != null) c.addView(Ui.text(a, title, 14f, Ui.ACCENT, true))
        if (hint != null) c.addView(Ui.text(a, hint, 12f, Ui.MUTED), lp(a, 3))
        return c
    }

    fun add(parent: LinearLayout, v: View, a: Activity, top: Int = 10) = parent.addView(v, lp(a, top))

    /** A small label above a group of chips inside a card. */
    fun label(a: Activity, text: String) = Ui.text(a, text, 13f, Ui.TEXT, true)

    fun note(a: Activity, text: String) = Ui.text(a, text, 12f, Ui.MUTED)

    fun divider(a: Activity): View = View(a).apply { setBackgroundColor(Ui.STROKE) }
        .also { it.layoutParams = LinearLayout.LayoutParams(MATCH, dp(a, 1)).apply { topMargin = dp(a, 14); bottomMargin = dp(a, 2) } }

    /** Wide button: [primary] = filled with the app gradient, otherwise a soft outlined chip. */
    fun action(a: Activity, label: String, primary: Boolean, icon: Int = -1, onClick: () -> Unit): View {
        val r = dp(a, 14).toFloat()
        val row = LinearLayout(a).apply {
            gravity = Gravity.CENTER
            orientation = LinearLayout.HORIZONTAL
            background = if (primary) Ui.gradient(r) else Ui.round(Ui.CHIP, r, Ui.STROKE, dp(a, 1))
            setPadding(dp(a, 14), dp(a, 13), dp(a, 14), dp(a, 13))
            isClickable = true
            setOnClickListener { onClick() }
        }
        val col = if (primary) Ui.BG else Ui.ACCENT
        if (icon >= 0) row.addView(ImageView(a).apply { setImageDrawable(LineIcon(icon, col)) }, LinearLayout.LayoutParams(dp(a, 20), dp(a, 20)).apply { marginEnd = dp(a, 8) })
        row.addView(Ui.text(a, label, 15f, col, true).apply { gravity = Gravity.CENTER; maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END })
        return row
    }

    /** What is chosen now (a file) with a "change" / "remove" pair; [onRemove] null = no remove button. */
    fun picked(a: Activity, iconKind: Int, title: String, sub: String, onChange: () -> Unit, onRemove: (() -> Unit)? = null): View {
        val row = LinearLayout(a).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = Ui.round(Ui.CHIP, dp(a, 14).toFloat())
            setPadding(dp(a, 10), dp(a, 10), dp(a, 6), dp(a, 10))
            isClickable = true
            setOnClickListener { onChange() }
        }
        row.addView(ImageView(a).apply {
            setImageDrawable(LineIcon(iconKind, Ui.ACCENT))
            background = Ui.round(Ui.BG, dp(a, 12).toFloat())
            val p = dp(a, 9)
            setPadding(p, p, p, p)
        }, LinearLayout.LayoutParams(dp(a, 42), dp(a, 42)))
        val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        col.addView(Ui.text(a, title, 14f, Ui.TEXT, true).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END })
        if (sub.isNotEmpty()) col.addView(Ui.text(a, sub, 12f, Ui.MUTED).apply { maxLines = 1 }, lp(a, 1, WRAP))
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(a, 12); marginEnd = dp(a, 6) })
        if (onRemove != null) row.addView(Icons.button(a, Icons.CLOSE, Ui.MUTED, 38) { onRemove() })
        return row
    }

    /** One-choice chips; the chosen one is filled with the gradient. Wide rows swipe sideways. */
    fun chips(a: Activity, labels: List<String>, selected: Int, onPick: (Int) -> Unit): View {
        val row = LinearLayout(a)
        val views = ArrayList<TextView>()
        val r = dp(a, 11).toFloat()
        fun paint(sel: Int) {
            views.forEachIndexed { i, c ->
                if (i == sel) {
                    c.background = Ui.gradient(r)
                    c.setTextColor(Ui.BG)
                } else {
                    c.background = Ui.round(Ui.CHIP, r)
                    c.setTextColor(Ui.MUTED)
                }
            }
        }
        labels.forEachIndexed { i, l ->
            val c = TextView(a).apply {
                text = l
                textSize = 13.5f
                gravity = Gravity.CENTER
                maxLines = 1
                minWidth = dp(a, 56)
                setPadding(dp(a, 13), dp(a, 10), dp(a, 13), dp(a, 10))
                setOnClickListener { paint(i); onPick(i) }
            }
            views.add(c)
            row.addView(c, LinearLayout.LayoutParams(WRAP, WRAP, 1f).apply { if (i > 0) marginStart = dp(a, 6) })
        }
        paint(selected)
        return ChipScroller(a, row)
    }

    /** A time field (m:ss or seconds) with the card's soft look. */
    fun timeField(a: Activity, hint: String, value: String, onText: (String) -> Unit): EditText = EditText(a).apply {
        setSingleLine()
        this.hint = hint
        setText(value)
        gravity = Gravity.CENTER
        textSize = 15f
        inputType = android.text.InputType.TYPE_CLASS_DATETIME or android.text.InputType.TYPE_DATETIME_VARIATION_TIME
        setTextColor(Ui.TEXT)
        setHintTextColor(Ui.MUTED)
        background = Ui.round(Ui.CHIP, dp(a, 12).toFloat())
        setPadding(dp(a, 12), dp(a, 11), dp(a, 12), dp(a, 11))
        addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, n: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) { onText(s?.toString() ?: "") }
        })
    }

    /** Empty state shown before a file is picked. */
    fun empty(a: Activity, iconKind: Int, text: String, button: String, onClick: () -> Unit): View {
        val c = card(a, null)
        c.gravity = Gravity.CENTER_HORIZONTAL
        c.addView(ImageView(a).apply {
            setImageDrawable(LineIcon(iconKind, Ui.ACCENT))
            background = Ui.round(Ui.CHIP, dp(a, 22).toFloat())
            val p = dp(a, 16)
            setPadding(p, p, p, p)
        }, LinearLayout.LayoutParams(dp(a, 68), dp(a, 68)).apply { topMargin = dp(a, 14) })
        c.addView(Ui.text(a, text, 13f, Ui.MUTED).apply { gravity = Gravity.CENTER }, lp(a, 12))
        c.addView(action(a, button, true, Icons.OPEN, onClick), lp(a, 16))
        return c
    }

}
