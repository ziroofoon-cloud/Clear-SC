package app.clearoverlay

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

/**
 * "Edit photo": turn / flip / crop, light (brightness, contrast, auto fix), colour (saturation, warmth), ready-made looks
 * and sharpening, then save a NEW picture in Pictures/ClearOverlay. The original is never changed.
 *
 * How it works: the preview is a small copy of the photo. Colour changes are a [ColorMatrixColorFilter] on the ImageView, so
 * they show at once; turning / cropping / auto fix / sharpening rebuild the small copy on a background thread. Saving decodes
 * the photo again (long side at most [SAVE_CAP] px so a big photo cannot run the phone out of memory) and runs the SAME steps,
 * so what is saved is what the preview showed.
 */
class PhotoEditActivity : Activity() {

    /** Everything the user can change. Immutable: every change makes a new copy, so a background job always sees a steady snapshot. */
    private data class St(
        val rotQ: Int = 0, val flipH: Boolean = false, val flipV: Boolean = false,
        val aspect: Int = 0, val zoom: Int = 100, val px: Int = 50, val py: Int = 50,
        val bright: Int = 0, val contrast: Int = 0, val sat: Int = 0, val warm: Int = 0,
        val sharp: Int = 0, val filter: Int = 0, val auto: Boolean = false,
        val sizeIdx: Int = 0, val fmt: Int = 0
    )

    private var st = St()
    private var uri: Uri? = null
    private var baseName = "photo"
    private var prev: Bitmap? = null          // small working copy (long side <= PREVIEW_CAP), turned upright by its EXIF tag
    private var tab = 0
    private var savedUri: Uri? = null
    private var busy = false

    @Volatile private var gen = 0
    private val exec = Executors.newSingleThreadExecutor()

    private lateinit var img: ImageView
    private lateinit var empty: TextView
    private lateinit var tabsHolder: LinearLayout
    private lateinit var panel: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var bottom: LinearLayout
    private lateinit var shareBtn: TextView

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Cfg.load(this)
        Ui.init(this)
        setTheme(Ui.theme())
        super.onCreate(savedInstanceState)
        Ui.styleBars(window)
        buildScreen()
        intent?.data?.let { load(it) }
    }

    override fun onDestroy() {
        gen++
        exec.shutdownNow()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ screen

    private fun gap(v: Int) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@PhotoEditActivity, v) }

    private fun button(label: String, primary: Boolean, onClick: () -> Unit) = Ui.text(this, label, 15f, if (primary) Ui.BG else Ui.ACCENT, true).apply {
        gravity = Gravity.CENTER
        maxLines = 1
        setPadding(dp(this@PhotoEditActivity, 12), dp(this@PhotoEditActivity, 12), dp(this@PhotoEditActivity, 12), dp(this@PhotoEditActivity, 12))
        background = if (primary) Ui.gradient(dp(this@PhotoEditActivity, 14).toFloat()) else Ui.round(Ui.CHIP, dp(this@PhotoEditActivity, 14).toFloat())
        setOnClickListener { onClick() }
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
            setPadding(dp(this@PhotoEditActivity, 14), dp(this@PhotoEditActivity, 18), dp(this@PhotoEditActivity, 14), dp(this@PhotoEditActivity, 12))
        }
        // title + pick
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(Ui.text(this, getString(R.string.pedit_title), 20f, Ui.TEXT, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(button(getString(R.string.pedit_pick), false) { pick() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(top)

        // preview
        val frame = android.widget.FrameLayout(this).apply { background = Ui.round(Ui.CARD, dp(this@PhotoEditActivity, 16).toFloat(), Ui.STROKE, dp(this@PhotoEditActivity, 1)) }
        img = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(this@PhotoEditActivity, 6), dp(this@PhotoEditActivity, 6), dp(this@PhotoEditActivity, 6), dp(this@PhotoEditActivity, 6))
        }
        frame.addView(img, android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        empty = Ui.text(this, getString(R.string.pedit_hint), 13f, Ui.MUTED).apply {
            gravity = Gravity.CENTER
            setPadding(dp(this@PhotoEditActivity, 24), 0, dp(this@PhotoEditActivity, 24), 0)
        }
        frame.addView(empty, android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(frame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.1f).apply { topMargin = dp(this@PhotoEditActivity, 10) })

        shareBtn = Ui.text(this, getString(R.string.share), 13f, Ui.ACCENT, true).apply {
            gravity = Gravity.CENTER
            visibility = View.GONE
            setPadding(0, dp(this@PhotoEditActivity, 8), 0, dp(this@PhotoEditActivity, 2))
            setOnClickListener { savedUri?.let { Share.share(this@PhotoEditActivity, listOf(it)) } }
        }
        root.addView(shareBtn)

        // tabs
        tabsHolder = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(tabsHolder, gap(8))

        // the panel of the chosen tab
        panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(this@PhotoEditActivity, 8)) }
        scroll = ScrollView(this).apply { addView(panel, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)) }
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = dp(this@PhotoEditActivity, 4) })

        // bottom bar: reset + save
        bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bottom.addView(button(getString(R.string.pedit_reset), false) { resetAll() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bottom.addView(button(getString(R.string.pedit_save), true) { save() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 2f).apply { marginStart = dp(this@PhotoEditActivity, 8) })
        root.addView(bottom, gap(8))

        setContentView(root)
        refreshAll()
    }

    /** Shows / hides the parts that need a photo and rebuilds the tab row and the panel. */
    private fun refreshAll() {
        val has = prev != null
        empty.visibility = if (has) View.GONE else View.VISIBLE
        tabsHolder.visibility = if (has) View.VISIBLE else View.GONE
        scroll.visibility = if (has) View.VISIBLE else View.GONE
        bottom.visibility = if (has) View.VISIBLE else View.GONE
        if (!has) {
            img.setImageDrawable(null)
            return
        }
        tabsHolder.removeAllViews()
        val names = listOf(R.string.pedit_tab_crop, R.string.pedit_tab_light, R.string.pedit_tab_color, R.string.pedit_tab_filters, R.string.pedit_tab_detail, R.string.pedit_tab_save)
        tabsHolder.addView(chips(names.map { getString(it) }, tab) { tab = it; buildPanel() })
        buildPanel()
    }

    private fun chips(labels: List<String>, selected: Int, onPick: (Int) -> Unit): View {
        val row = LinearLayout(this)
        val views = ArrayList<TextView>()
        fun paint(sel: Int) {
            val r = dp(this, 10).toFloat()
            views.forEachIndexed { i, c ->
                if (i == sel) {
                    c.background = Ui.gradient(r)
                    c.setTextColor(Ui.BG)
                } else {
                    c.background = Ui.round(Ui.CHIP, r)
                    c.setTextColor(Ui.MUTED)
                }
            }
        }
        labels.forEachIndexed { i, l ->
            val c = TextView(this).apply {
                text = l
                textSize = 14f
                gravity = Gravity.CENTER
                maxLines = 1
                minWidth = dp(this@PhotoEditActivity, 56)
                setPadding(dp(this@PhotoEditActivity, 12), dp(this@PhotoEditActivity, 9), dp(this@PhotoEditActivity, 12), dp(this@PhotoEditActivity, 9))
                setOnClickListener { paint(i); onPick(i) }
            }
            views.add(c)
            row.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i > 0) marginStart = dp(this@PhotoEditActivity, 6) })
        }
        paint(selected)
        return ChipScroller(this, row)
    }

    private fun slider(label: Int, min: Int, max: Int, value: Int, onChange: (Int) -> Unit) {
        val t = Ui.text(this, "", 13f, Ui.TEXT)
        fun setT(v: Int) { t.text = getString(label) + "   " + v }
        setT(value)
        val sb = SeekBar(this).apply {
            this.max = max - min
            progress = value - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    val v = p + min
                    setT(v)
                    onChange(v)
                }

                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        panel.addView(t, gap(10))
        panel.addView(sb, gap(0))
    }

    private fun label(res: Int) = panel.addView(Ui.text(this, getString(res), 13f, Ui.ACCENT, true), gap(14))

    private fun buildPanel() {
        panel.removeAllViews()
        when (tab) {
            0 -> { // turn, flip, crop
                val row = LinearLayout(this)
                row.addView(button("↶  " + getString(R.string.pedit_rot_l), false) { st = st.copy(rotQ = (st.rotQ + 3) % 4); requestPreview() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                row.addView(button("↷  " + getString(R.string.pedit_rot_r), false) { st = st.copy(rotQ = (st.rotQ + 1) % 4); requestPreview() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(this@PhotoEditActivity, 8) })
                panel.addView(row, gap(6))
                val row2 = LinearLayout(this)
                row2.addView(button("⇆  " + getString(R.string.pedit_flip_h), false) { st = st.copy(flipH = !st.flipH); requestPreview() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                row2.addView(button("⇅  " + getString(R.string.pedit_flip_v), false) { st = st.copy(flipV = !st.flipV); requestPreview() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(this@PhotoEditActivity, 8) })
                panel.addView(row2, gap(8))
                label(R.string.pedit_aspect)
                panel.addView(chips(ASPECT_LABELS.mapIndexed { i, s -> if (i == 0) getString(R.string.pedit_asp_orig) else s }, st.aspect) { st = st.copy(aspect = it); requestPreview() }, gap(6))
                slider(R.string.pedit_zoom, 100, 400, st.zoom) { st = st.copy(zoom = it); requestPreview() }
                slider(R.string.pedit_pos_x, 0, 100, st.px) { st = st.copy(px = it); requestPreview() }
                slider(R.string.pedit_pos_y, 0, 100, st.py) { st = st.copy(py = it); requestPreview() }
            }
            1 -> { // light
                panel.addView(chips(listOf(getString(R.string.pedit_auto_off), getString(R.string.pedit_auto_on)), if (st.auto) 1 else 0) { st = st.copy(auto = it == 1); requestPreview() }, gap(6))
                panel.addView(Ui.text(this, getString(R.string.pedit_auto_hint), 12f, Ui.MUTED), gap(4))
                slider(R.string.pedit_brightness, -100, 100, st.bright) { st = st.copy(bright = it); applyColorFilter() }
                slider(R.string.pedit_contrast, -100, 100, st.contrast) { st = st.copy(contrast = it); applyColorFilter() }
            }
            2 -> { // colour
                slider(R.string.pedit_saturation, -100, 100, st.sat) { st = st.copy(sat = it); applyColorFilter() }
                slider(R.string.pedit_warmth, -100, 100, st.warm) { st = st.copy(warm = it); applyColorFilter() }
            }
            3 -> { // ready-made looks
                panel.addView(chips(FILTER_RES.map { getString(it) }, st.filter) { st = st.copy(filter = it); applyColorFilter() }, gap(6))
                panel.addView(Ui.text(this, getString(R.string.pedit_filter_hint), 12f, Ui.MUTED), gap(6))
            }
            4 -> { // detail
                slider(R.string.pedit_sharpen, 0, 100, st.sharp) { st = st.copy(sharp = it); requestPreview() }
                panel.addView(Ui.text(this, getString(R.string.pedit_sharpen_hint), 12f, Ui.MUTED), gap(6))
            }
            else -> { // save options
                label(R.string.pedit_size)
                panel.addView(chips(listOf(getString(R.string.pedit_size_orig), "75%", "50%", "25%"), st.sizeIdx) { st = st.copy(sizeIdx = it) }, gap(6))
                label(R.string.pedit_format)
                panel.addView(chips(listOf("JPG", "PNG"), st.fmt) { st = st.copy(fmt = it) }, gap(6))
                panel.addView(Ui.text(this, getString(R.string.pedit_save_hint), 12f, Ui.MUTED), gap(10))
            }
        }
    }

    // ------------------------------------------------------------------ loading

    private fun pick() {
        @Suppress("DEPRECATION")
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"), REQ_PICK)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val u = data?.data
        if (res != RESULT_OK || u == null || req != REQ_PICK) return
        runCatching { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        load(u)
    }

    private fun load(u: Uri) {
        uri = u
        baseName = runCatching {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
        }.getOrNull()?.substringBeforeLast('.')?.ifBlank { null } ?: "photo"
        empty.text = getString(R.string.img_wait)
        Thread {
            val b = runCatching { decode(u, PREVIEW_CAP) }.getOrNull()
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                if (b == null) {
                    empty.text = getString(R.string.pedit_hint)
                    Toast.makeText(this, R.string.pedit_open_fail, Toast.LENGTH_LONG).show()
                    return@runOnUiThread
                }
                prev = b
                st = St()
                tab = 0
                savedUri = null
                shareBtn.visibility = View.GONE
                refreshAll()
                requestPreview()
            }
        }.start()
    }

    /** Decodes [u] with its long side at most [cap] px and turns it upright by its EXIF tag. */
    private fun decode(u: Uri, cap: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        val bw = bounds.outWidth
        val bh = bounds.outHeight
        if (bw <= 0 || bh <= 0) return null
        var sample = 1
        while (maxOf(bw, bh) / (sample * 2) >= cap) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
        var b = contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
        if (maxOf(b.width, b.height) > cap) {
            val k = cap.toFloat() / maxOf(b.width, b.height)
            val s = Bitmap.createScaledBitmap(b, maxOf(1, (b.width * k).toInt()), maxOf(1, (b.height * k).toInt()), true)
            if (s !== b) b.recycle()
            b = s
        }
        val orient = runCatching {
            contentResolver.openInputStream(u)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) }
        }.getOrNull() ?: ExifInterface.ORIENTATION_NORMAL
        val m = Matrix()
        when (orient) {
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(-90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(-90f)
            else -> return b
        }
        val r = Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
        if (r !== b) b.recycle()
        return r
    }

    // ------------------------------------------------------------------ preview

    /** Rebuilds the small picture (turn / crop / auto fix / sharpen) on a background thread; the newest request wins. */
    private fun requestPreview() {
        val p = prev ?: return
        val snap = st
        val g = ++gen
        exec.execute {
            if (g != gen) return@execute
            val out = runCatching { render(p, snap, false, 1f) }.getOrNull() ?: return@execute
            runOnUiThread {
                if (g == gen && !isDestroyed) {
                    img.setImageBitmap(out)
                    applyColorFilter()
                }
            }
        }
    }

    private fun applyColorFilter() {
        img.colorFilter = if (colorIdentity(st)) null else ColorMatrixColorFilter(matrix(st))
    }

    private fun resetAll() {
        st = St()
        savedUri = null
        shareBtn.visibility = View.GONE
        buildPanel()
        requestPreview()
    }

    // ------------------------------------------------------------------ pictures

    private fun colorIdentity(s: St) = s.filter == 0 && s.sat == 0 && s.warm == 0 && s.contrast == 0 && s.bright == 0

    private fun contrastM(c: Float, offset: Float = 0f) = ColorMatrix(
        floatArrayOf(
            c, 0f, 0f, 0f, 128f * (1f - c) + offset,
            0f, c, 0f, 0f, 128f * (1f - c) + offset,
            0f, 0f, c, 0f, 128f * (1f - c) + offset,
            0f, 0f, 0f, 1f, 0f
        )
    )

    private fun warmM(w: Float) = ColorMatrix(
        floatArrayOf(
            1f + w, 0f, 0f, 0f, 0f,
            0f, 1f, 0f, 0f, 0f,
            0f, 0f, 1f - w, 0f, 0f,
            0f, 0f, 0f, 1f, 0f
        )
    )

    private fun satM(s: Float) = ColorMatrix().apply { setSaturation(s) }

    /** A ready-made look as a colour matrix (index 0 = none). */
    private fun filterMatrix(f: Int): ColorMatrix? = when (f) {
        1 -> ColorMatrix().apply { postConcat(satM(1.35f)); postConcat(contrastM(1.08f)) }                 // vivid
        2 -> ColorMatrix().apply { postConcat(satM(0f)); postConcat(contrastM(1.12f)) }                    // black and white
        3 -> ColorMatrix(                                                                                  // sepia
            floatArrayOf(
                0.393f, 0.769f, 0.189f, 0f, 0f,
                0.349f, 0.686f, 0.168f, 0f, 0f,
                0.272f, 0.534f, 0.131f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )
        )
        4 -> warmM(0.12f)                                                                                  // warm
        5 -> warmM(-0.12f)                                                                                 // cool
        6 -> ColorMatrix().apply { postConcat(satM(0.8f)); postConcat(contrastM(0.88f, 12f)) }             // fade
        7 -> ColorMatrix().apply { postConcat(satM(0.75f)); postConcat(contrastM(1.3f)) }                  // dramatic
        else -> null
    }

    /** Look first, then saturation, warmth, contrast, brightness. */
    private fun matrix(s: St): ColorMatrix {
        val m = ColorMatrix()
        filterMatrix(s.filter)?.let { m.postConcat(it) }
        if (s.sat != 0) m.postConcat(satM(1f + s.sat / 100f))
        if (s.warm != 0) m.postConcat(warmM(s.warm / 100f * 0.2f))
        if (s.contrast != 0) m.postConcat(contrastM(if (s.contrast > 0) 1f + s.contrast / 100f * 0.8f else 1f + s.contrast / 100f * 0.6f))
        if (s.bright != 0) {
            val o = s.bright / 100f * 80f
            m.postConcat(ColorMatrix(floatArrayOf(1f, 0f, 0f, 0f, o, 0f, 1f, 0f, 0f, o, 0f, 0f, 1f, 0f, o, 0f, 0f, 0f, 1f, 0f)))
        }
        return m
    }

    /** Turn / flip, then crop (shape, zoom, position). Returns [src] itself when nothing has to be done. */
    private fun geometry(src: Bitmap, s: St): Bitmap {
        var b = src
        if (s.rotQ != 0 || s.flipH || s.flipV) {
            val m = Matrix()
            if (s.flipH) m.postScale(-1f, 1f)
            if (s.flipV) m.postScale(1f, -1f)
            m.postRotate(90f * s.rotQ)
            b = Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
        }
        val ar = ASPECTS[s.aspect]
        val z = s.zoom / 100f
        if (ar > 0f || z > 1.001f) {
            val w = b.width
            val h = b.height
            var bw = w.toFloat()
            var bh = h.toFloat()
            if (ar > 0f) {
                if (w.toFloat() / h > ar) bw = h * ar else bh = w / ar
            }
            val cw = (bw / z).toInt().coerceIn(1, w)
            val ch = (bh / z).toInt().coerceIn(1, h)
            val x0 = ((w - cw) * s.px / 100f).toInt().coerceIn(0, w - cw)
            val y0 = ((h - ch) * s.py / 100f).toInt().coerceIn(0, h - ch)
            if (cw != w || ch != h) {
                val c = Bitmap.createBitmap(b, x0, y0, cw, ch)
                if (b !== src && c !== b) b.recycle()
                b = c
            }
        }
        return b
    }

    /** Light sharpening (unsharp mask with a 3x3 blur), in place, one row at a time so it needs no extra copy of the picture. */
    private fun sharpen(bmp: Bitmap, amount: Float) {
        val w = bmp.width
        val h = bmp.height
        if (w < 3 || h < 3 || amount <= 0f) return
        var r0 = IntArray(w)
        var r1 = IntArray(w)
        var r2 = IntArray(w)
        val out = IntArray(w)
        bmp.getPixels(r1, 0, w, 0, 0, w, 1)
        System.arraycopy(r1, 0, r0, 0, w)
        bmp.getPixels(r2, 0, w, 0, 1, w, 1)
        for (y in 0 until h) {
            for (x in 0 until w) {
                val xl = if (x > 0) x - 1 else 0
                val xr = if (x < w - 1) x + 1 else w - 1
                val c = r1[x]
                var res = c and (0xFF shl 24)
                var sh = 16
                while (sh >= 0) {
                    val cv = (c shr sh) and 255
                    val sum = ((r0[xl] shr sh) and 255) + 2 * ((r0[x] shr sh) and 255) + ((r0[xr] shr sh) and 255) +
                        2 * ((r1[xl] shr sh) and 255) + 4 * cv + 2 * ((r1[xr] shr sh) and 255) +
                        ((r2[xl] shr sh) and 255) + 2 * ((r2[x] shr sh) and 255) + ((r2[xr] shr sh) and 255)
                    var v = cv + ((cv - sum / 16f) * amount).toInt()
                    if (v < 0) v = 0 else if (v > 255) v = 255
                    res = res or (v shl sh)
                    sh -= 8
                }
                out[x] = res
            }
            bmp.setPixels(out, 0, w, 0, y, w, 1)
            val t = r0
            r0 = r1
            r1 = r2
            r2 = t
            if (y + 2 < h) bmp.getPixels(r2, 0, w, 0, y + 2, w, 1) else System.arraycopy(r1, 0, r2, 0, w)
        }
    }

    /**
     * The whole chain, same for the preview and for saving: turn / crop, size, auto fix, sharpen, and (saving only) colour.
     * [src] is never changed or recycled; intermediate copies are recycled as soon as they are not needed.
     */
    private fun render(src: Bitmap, s: St, applyColor: Boolean, scale: Float): Bitmap {
        var b = geometry(src, s)
        fun swap(n: Bitmap) {
            if (n !== b) {
                if (b !== src) b.recycle()
                b = n
            }
        }
        if (scale < 0.999f) swap(Bitmap.createScaledBitmap(b, maxOf(1, (b.width * scale).toInt()), maxOf(1, (b.height * scale).toInt()), true))
        if (s.auto) runCatching { Enhance.auto(b) }.getOrNull()?.let { swap(it) }
        if (s.sharp > 0) {
            // never sharpen the shared source in place: work on a private copy when nothing has made one yet
            if (b === src || !b.isMutable) {
                val c: Bitmap? = b.copy(Bitmap.Config.ARGB_8888, true)
                if (c != null) swap(c)
            }
            if (b !== src && b.isMutable) sharpen(b, s.sharp / 100f * 1.6f)
        }
        if (applyColor && !colorIdentity(s)) {
            val o = Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888)
            Canvas(o).drawBitmap(b, 0f, 0f, Paint().apply { colorFilter = ColorMatrixColorFilter(matrix(s)) })
            swap(o)
        }
        return b
    }

    // ------------------------------------------------------------------ saving

    private fun save() {
        val u = uri ?: return
        if (busy) return
        busy = true
        val snap = st
        val scale = SIZES[snap.sizeIdx]
        val dlg = android.app.AlertDialog.Builder(this)
            .setTitle(R.string.pedit_saving)
            .setMessage(R.string.img_wait)
            .setCancelable(false)
            .create()
        dlg.show()
        val app = applicationContext
        val name = Stamp.name(baseName, "edit")
        Thread {
            var error: String? = null
            var outUri: Uri? = null
            var cap = SAVE_CAP
            var tries = 0
            while (tries < 2 && outUri == null) {
                tries++
                try {
                    val full = decode(u, cap) ?: throw IllegalStateException("decode")
                    val res = render(full, snap, true, scale)
                    try {
                        outUri = write(app, res, name, snap.fmt)
                    } finally {
                        if (res !== full) res.recycle()
                        full.recycle()
                    }
                    if (outUri == null) error = "write"
                    break
                } catch (oom: OutOfMemoryError) {
                    cap /= 2          // too big for this phone: try once more at half the size
                    error = "memory"
                } catch (t: Throwable) {
                    error = t.message ?: t.javaClass.simpleName
                    break
                }
            }
            runOnUiThread {
                busy = false
                runCatching { dlg.dismiss() }
                if (isDestroyed) return@runOnUiThread
                if (outUri != null) {
                    savedUri = outUri
                    shareBtn.visibility = View.VISIBLE
                    Toast.makeText(this, getString(R.string.pedit_saved_fmt, name + if (snap.fmt == 1) ".png" else ".jpg"), Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, getString(R.string.pedit_fail_fmt, error ?: "?"), Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    /** Writes [b] into Pictures/ClearOverlay; returns the new picture's uri, or null when it could not be written. */
    private fun write(ctx: Context, b: Bitmap, name: String, fmt: Int): Uri? {
        val png = fmt == 1
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name + if (png) ".png" else ".jpg")
            put(MediaStore.Images.Media.MIME_TYPE, if (png) "image/png" else "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ClearOverlay")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val resolver = ctx.contentResolver
        val out = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        return try {
            val os = resolver.openOutputStream(out)
            if (os == null) {
                resolver.delete(out, null, null)
                null
            } else {
                val ok = os.use { b.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, if (png) 100 else 95, it) }
                if (!ok) {
                    resolver.delete(out, null, null)
                    null
                } else {
                    values.clear()
                    values.put(MediaStore.Images.Media.IS_PENDING, 0)
                    resolver.update(out, values, null, null)
                    out
                }
            }
        } catch (t: Throwable) {
            runCatching { resolver.delete(out, null, null) }
            null
        }
    }

    companion object {
        private const val REQ_PICK = 71
        private const val PREVIEW_CAP = 1280
        private const val SAVE_CAP = 3200
        private val ASPECTS = floatArrayOf(0f, 1f, 4f / 3f, 3f / 2f, 16f / 9f, 3f / 4f, 2f / 3f, 9f / 16f)
        private val ASPECT_LABELS = listOf("", "1:1", "4:3", "3:2", "16:9", "3:4", "2:3", "9:16")
        private val SIZES = floatArrayOf(1f, 0.75f, 0.5f, 0.25f)
        private val FILTER_RES = listOf(
            R.string.pedit_f_none, R.string.pedit_f_vivid, R.string.pedit_f_bw, R.string.pedit_f_sepia,
            R.string.pedit_f_warm, R.string.pedit_f_cool, R.string.pedit_f_fade, R.string.pedit_f_drama
        )
    }
}
