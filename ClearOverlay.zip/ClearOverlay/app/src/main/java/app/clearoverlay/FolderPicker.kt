package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.ListView
import java.io.File

/**
 * A folder chooser inside the app that reads the phone's folders directly (like a file manager does), so folders whose name
 * starts with a dot (hidden ones) are listed and can be chosen, and a folder that only holds hidden files can be chosen too.
 * Needs "All files access"; without it the person is taken to that setting first.
 */
object FolderPicker {
    fun show(a: Activity, onPick: (File) -> Unit) {
        if (!Environment.isExternalStorageManager()) {
            AlertDialog.Builder(a)
                .setTitle(R.string.fm_perm_title)
                .setMessage(R.string.fm_perm_msg)
                .setPositiveButton(R.string.fm_perm_go) { _, _ ->
                    runCatching {
                        a.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${a.packageName}")))
                    }.onFailure {
                        runCatching { a.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
                    }
                }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
            return
        }
        var cur = Environment.getExternalStorageDirectory()
        var dirs: List<File> = emptyList()
        val labels = ArrayList<String>()
        val adapter = ArrayAdapter(a, android.R.layout.simple_list_item_1, labels)
        val list = ListView(a).apply { this.adapter = adapter }
        val dlg = AlertDialog.Builder(a)
            .setView(list)
            .setPositiveButton(R.string.lib_pick_this) { _, _ -> onPick(cur) }
            .setNegativeButton(android.R.string.cancel, null)
            .create()
        fun load() {
            val kids = runCatching { cur.listFiles() }.getOrNull()
            dirs = (kids?.filter { it.isDirectory } ?: emptyList()).sortedBy { it.name.lowercase() }
            labels.clear()
            if (cur.parentFile != null) labels.add("⬆  ..")
            for (d in dirs) labels.add((if (d.name.startsWith(".")) "◌  " else "📁  ") + d.name)
            adapter.notifyDataSetChanged()
            dlg.setTitle(cur.path)
            list.setSelection(0)
        }
        list.setOnItemClickListener { _, _, pos, _ ->
            val up = cur.parentFile != null
            if (up && pos == 0) cur = cur.parentFile!! else cur = dirs[if (up) pos - 1 else pos]
            load()
        }
        dlg.show()
        load()
    }
}
