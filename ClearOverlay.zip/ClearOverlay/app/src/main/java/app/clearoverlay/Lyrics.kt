package app.clearoverlay

import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import java.io.File

/**
 * Synchronised lyrics from a ".lrc" file that sits next to the song (same name, "song.mp3" -> "song.lrc") or in a "Lyrics" / "lyrics"
 * folder beside it. Time stamps [mm:ss.xx] (several per line are fine) and the [offset:ms] tag are read; everything else is ignored.
 */
object Lyrics {
    class Line(val ms: Long, val text: String)

    private val stamp = Regex("\\[(\\d{1,3}):(\\d{1,2})(?:[.:](\\d{1,3}))?]")
    private val offsetTag = Regex("\\[offset:\\s*(-?\\d+)]", RegexOption.IGNORE_CASE)
    private var cacheKey: String? = null
    private var cacheVal: List<Line>? = null

    /** The song's file path when it can be found (file:// or a MediaStore row), else null. */
    private fun pathOf(ctx: Context, uri: Uri): String? {
        if (uri.scheme == "file") return uri.path
        if (uri.scheme != "content") return null
        return runCatching {
            ctx.contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.DATA), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        }.getOrNull()
    }

    /** Parses LRC text; null when there are no time stamps at all. */
    fun parse(text: String): List<Line>? {
        var offset = 0L
        offsetTag.find(text)?.let { offset = it.groupValues[1].toLongOrNull() ?: 0L }
        val out = ArrayList<Line>()
        for (raw in text.lineSequence()) {
            val ms = stamp.findAll(raw).toList()
            if (ms.isEmpty()) continue
            val body = raw.substring(ms.last().range.last + 1).trim().replace(Regex("<\\d+:\\d+(?:[.:]\\d+)?>"), "")
            for (m in ms) {
                val min = m.groupValues[1].toLong()
                val sec = m.groupValues[2].toLong()
                val fr = m.groupValues[3]
                val frMs = if (fr.isEmpty()) 0L else (fr + "00").take(3).toLong()
                out.add(Line(min * 60_000L + sec * 1000L + frMs - offset, body))
            }
        }
        if (out.isEmpty()) return null
        out.sortBy { it.ms }
        return out
    }

    /** Blocking (small file read): call from a background thread. */
    fun load(ctx: Context, uri: Uri): List<Line>? {
        val key = uri.toString()
        synchronized(this) { if (cacheKey == key) return cacheVal }
        val res = runCatching {
            val p = pathOf(ctx, uri) ?: return@runCatching null
            val f = File(p)
            val base = f.nameWithoutExtension
            val dir = f.parentFile ?: return@runCatching null
            val cands = listOf(File(dir, "$base.lrc"), File(dir, "$base.LRC"), File(dir, "Lyrics/$base.lrc"), File(dir, "lyrics/$base.lrc"))
            val lf = cands.firstOrNull { it.isFile && it.length() in 1..2_000_000L } ?: return@runCatching null
            parse(lf.readText(Charsets.UTF_8).removePrefix("﻿"))
        }.getOrNull()
        synchronized(this) { cacheKey = key; cacheVal = res }
        return res
    }

    /** Index of the line that is being sung at [posMs] (-1 before the first line). */
    fun indexAt(lines: List<Line>, posMs: Long): Int {
        var lo = 0
        var hi = lines.size - 1
        var r = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (lines[mid].ms <= posMs) { r = mid; lo = mid + 1 } else hi = mid - 1
        }
        return r
    }
}
