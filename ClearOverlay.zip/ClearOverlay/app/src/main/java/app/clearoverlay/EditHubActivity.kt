package app.clearoverlay

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView

/**
 * One place for every editor, so the main screen needs a single button: edit video, edit audio, edit photo.
 * (Each editor is still its own screen; this only lists them.)
 */
class EditHubActivity : Activity() {

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Cfg.load(this)
        Ui.init(this)
        setTheme(Ui.theme())
        super.onCreate(savedInstanceState)
        Ui.styleBars(window)

        val pg = EditUi.page(this, getString(R.string.edit_hub_title), getString(R.string.edit_hub_hint))
        entry(pg.body, Icons.FILM, getString(R.string.edit_title), getString(R.string.edit_hub_video), EditActivity::class.java)
        entry(pg.body, Icons.MUSIC, getString(R.string.aedit_title), getString(R.string.edit_hub_audio), AudioEditActivity::class.java)
        entry(pg.body, Icons.IMAGE, getString(R.string.pedit_title), getString(R.string.edit_hub_photo), PhotoEditActivity::class.java)
        // the "now playing" bar stays at the bottom, like on the main screen
        MiniPlayer.attach(this, pg.root)
        setContentView(pg.root)
    }

    private fun lp(top: Int) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        .apply { topMargin = dp(this@EditHubActivity, top) }

    /** One card: an icon tile, the editor's name, one line about what it does, and an arrow. */
    private fun entry(parent: LinearLayout, icon: Int, title: String, sub: String, target: Class<*>) {
        val a = this
        val card = LinearLayout(a).apply {
            gravity = android.view.Gravity.CENTER_VERTICAL
            background = Ui.round(Ui.CARD, dp(a, 18).toFloat(), Ui.STROKE, dp(a, 1))
            val p = dp(a, 14)
            setPadding(p, p, p, p)
            isClickable = true
            setOnClickListener { startActivity(Intent(a, target)) }
        }
        card.addView(android.widget.ImageView(a).apply {
            setImageDrawable(LineIcon(icon, Ui.ACCENT))
            background = Ui.round(Ui.CHIP, dp(a, 16).toFloat())
            val p = dp(a, 12)
            setPadding(p, p, p, p)
        }, LinearLayout.LayoutParams(dp(a, 54), dp(a, 54)))
        val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        col.addView(Ui.text(a, title, 17f, Ui.TEXT, true))
        col.addView(Ui.text(a, sub, 12f, Ui.MUTED), lp(3))
        card.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(a, 14); marginEnd = dp(a, 8) })
        card.addView(android.widget.ImageView(a).apply {
            setImageDrawable(LineIcon(Icons.NEXT, Ui.MUTED))
        }, LinearLayout.LayoutParams(dp(a, 20), dp(a, 20)))
        parent.addView(card, lp(12))
    }
}
