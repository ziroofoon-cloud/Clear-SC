package app.clearoverlay

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView

/**
 * One place for every editor, so the main screen needs a single button: edit video, edit audio, edit photo.
 * (Each editor is still its own screen; this only lists them.)
 */
class EditHubActivity : Activity() {

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Cfg.load(this)
        Ui.init(this)
        setTheme(Ui.theme())
        super.onCreate(savedInstanceState)
        Ui.styleBars(window)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(this@EditHubActivity, 18), dp(this@EditHubActivity, 22), dp(this@EditHubActivity, 18), dp(this@EditHubActivity, 28))
        }
        col.addView(Ui.text(this, getString(R.string.edit_hub_title), 20f, Ui.TEXT, true))
        col.addView(Ui.text(this, getString(R.string.edit_hub_hint), 12f, Ui.MUTED), lp(4))

        entry(col, getString(R.string.edit_title), getString(R.string.edit_hub_video), EditActivity::class.java)
        entry(col, getString(R.string.aedit_title), getString(R.string.edit_hub_audio), AudioEditActivity::class.java)
        entry(col, getString(R.string.pedit_title), getString(R.string.edit_hub_photo), PhotoEditActivity::class.java)

        // the "now playing" bar stays at the bottom, like on the main screen
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
        }
        page.addView(ScrollView(this).apply {
            addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        MiniPlayer.attach(this, page)
        setContentView(page)
    }

    private fun lp(top: Int) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        .apply { topMargin = dp(this@EditHubActivity, top) }

    /** One big card: the editor's name and one line about what it does. */
    private fun entry(parent: LinearLayout, title: String, sub: String, target: Class<*>) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.round(Ui.CARD, dp(this@EditHubActivity, 18).toFloat(), Ui.STROKE, dp(this@EditHubActivity, 1))
            val p = dp(this@EditHubActivity, 16)
            setPadding(p, p, p, p)
            isClickable = true
            setOnClickListener { startActivity(Intent(this@EditHubActivity, target)) }
        }
        card.addView(Ui.text(this, title, 17f, Ui.ACCENT, true))
        card.addView(Ui.text(this, sub, 12f, Ui.MUTED), lp(4))
        parent.addView(card, lp(14))
    }
}
