package app.clearoverlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Pictures instead of words for the screen direction: a phone standing up (portrait), lying down (landscape), a phone with "A" (automatic),
 * a phone with two turning arrows (follow the phone / free) and a padlock (lock). One row of big tiles is quicker to hit than a list of text.
 */
object DirIcons {
    const val AUTO = 0
    const val LAND = 1
    const val PORT = 2
    const val FREE = 3
    const val LOCK = 4
    const val MANUAL = 5   // four arrows: choose the exact direction yourself
    const val TOP_UP = 6   // a phone held so that its top (the camera dot) is up / left / down / right
    const val TOP_LEFT = 7
    const val TOP_DOWN = 8
    const val TOP_RIGHT = 9

    /** One icon, drawn with lines only (no image files), in [color]. */
    class IconView(ctx: Context, private val kind: Int) : View(ctx) {
        var color: Int = Ui.TEXT
            set(v) { field = v; invalidate() }
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        private val r = RectF()

        override fun onDraw(c: Canvas) {
            val s = min(width, height).toFloat()
            if (s <= 0f) return
            val ox = (width - s) / 2f
            val oy = (height - s) / 2f
            p.color = color
            p.style = Paint.Style.STROKE
            p.strokeWidth = s * 0.07f
            fun phone(cx: Float, cy: Float, w: Float, h: Float) {
                r.set(ox + (cx - w / 2f) * s, oy + (cy - h / 2f) * s, ox + (cx + w / 2f) * s, oy + (cy + h / 2f) * s)
                c.drawRoundRect(r, s * 0.07f, s * 0.07f, p)
            }
            when (kind) {
                PORT -> {
                    phone(0.5f, 0.5f, 0.40f, 0.72f)
                    c.drawLine(ox + 0.43f * s, oy + 0.78f * s, ox + 0.57f * s, oy + 0.78f * s, p) // the home bar
                }
                LAND -> {
                    phone(0.5f, 0.5f, 0.72f, 0.40f)
                    c.drawLine(ox + 0.78f * s, oy + 0.43f * s, ox + 0.78f * s, oy + 0.57f * s, p)
                }
                AUTO -> {
                    phone(0.5f, 0.5f, 0.62f, 0.62f)
                    val t = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        this.color = this@IconView.color
                        textSize = s * 0.40f
                        textAlign = Paint.Align.CENTER
                        isFakeBoldText = true
                    }
                    c.drawText("A", ox + 0.5f * s, oy + 0.5f * s + t.textSize * 0.35f, t)
                }
                FREE -> {
                    phone(0.5f, 0.5f, 0.26f, 0.44f)
                    r.set(ox + 0.10f * s, oy + 0.10f * s, ox + 0.90f * s, oy + 0.90f * s)
                    c.drawArc(r, 205f, 100f, false, p)
                    c.drawArc(r, 25f, 100f, false, p)
                    arrowHead(c, ox + 0.5f * s, oy + 0.5f * s, 0.40f * s, 305f, s)
                    arrowHead(c, ox + 0.5f * s, oy + 0.5f * s, 0.40f * s, 125f, s)
                }
                MANUAL -> {
                    // four small arrows (up, right, down, left) around a dot
                    p.style = Paint.Style.FILL
                    c.drawCircle(ox + 0.5f * s, oy + 0.5f * s, s * 0.07f, p)
                    for (k in 0 until 4) {
                        val a = Math.toRadians((k * 90 - 90).toDouble())
                        val dx = cos(a).toFloat()
                        val dy = sin(a).toFloat()
                        val tip = 0.42f
                        val base = 0.26f
                        val w = 0.12f
                        val path = Path()
                        path.moveTo(ox + (0.5f + dx * tip) * s, oy + (0.5f + dy * tip) * s)
                        path.lineTo(ox + (0.5f + dx * base - dy * w) * s, oy + (0.5f + dy * base + dx * w) * s)
                        path.lineTo(ox + (0.5f + dx * base + dy * w) * s, oy + (0.5f + dy * base - dx * w) * s)
                        path.close()
                        c.drawPath(path, p)
                    }
                }
                TOP_UP, TOP_DOWN -> {
                    phone(0.5f, 0.5f, 0.40f, 0.72f)
                    p.style = Paint.Style.FILL
                    c.drawCircle(ox + 0.5f * s, oy + (if (kind == TOP_UP) 0.28f else 0.72f) * s, s * 0.05f, p) // the camera: the top of the phone
                }
                TOP_LEFT, TOP_RIGHT -> {
                    phone(0.5f, 0.5f, 0.72f, 0.40f)
                    p.style = Paint.Style.FILL
                    c.drawCircle(ox + (if (kind == TOP_LEFT) 0.28f else 0.72f) * s, oy + 0.5f * s, s * 0.05f, p)
                }
                LOCK -> {
                    r.set(ox + 0.22f * s, oy + 0.45f * s, ox + 0.78f * s, oy + 0.86f * s)
                    c.drawRoundRect(r, s * 0.08f, s * 0.08f, p)
                    r.set(ox + 0.32f * s, oy + 0.14f * s, ox + 0.68f * s, oy + 0.62f * s)
                    c.drawArc(r, 180f, 180f, false, p)
                    c.drawLine(ox + 0.32f * s, oy + 0.38f * s, ox + 0.32f * s, oy + 0.45f * s, p)
                    c.drawLine(ox + 0.68f * s, oy + 0.38f * s, ox + 0.68f * s, oy + 0.45f * s, p)
                    p.style = Paint.Style.FILL
                    c.drawCircle(ox + 0.5f * s, oy + 0.62f * s, s * 0.05f, p)
                }
            }
        }

        /** A small arrow head at the end of an arc (angle in degrees, clockwise from the right), pointing along the arc. */
        private fun arrowHead(c: Canvas, cx: Float, cy: Float, rad: Float, deg: Float, s: Float) {
            val a = Math.toRadians(deg.toDouble())
            val x = cx + rad * cos(a).toFloat()
            val y = cy + rad * sin(a).toFloat()
            val tx = -sin(a).toFloat() // the direction of travel (clockwise)
            val ty = cos(a).toFloat()
            val nx = cos(a).toFloat()
            val ny = sin(a).toFloat()
            val len = s * 0.13f
            val path = Path()
            path.moveTo(x + tx * len * 0.6f, y + ty * len * 0.6f)
            path.lineTo(x - tx * len * 0.4f + nx * len * 0.7f, y - ty * len * 0.4f + ny * len * 0.7f)
            path.lineTo(x - tx * len * 0.4f - nx * len * 0.7f, y - ty * len * 0.4f - ny * len * 0.7f)
            path.close()
            val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = this@IconView.color }
            c.drawPath(path, fill)
        }
    }

    /** One big tile: the icon over a short word. [selected] paints it like a chosen chip. Returns the tile and a function that repaints it. */
    private fun tile(ctx: Context, kind: Int, label: String, selected: Boolean, onClick: () -> Unit): Pair<LinearLayout, (Boolean) -> Unit> {
        val icon = IconView(ctx, kind)
        val word = TextView(ctx).apply {
            text = label
            textSize = 12f
            gravity = Gravity.CENTER
            maxLines = 1
        }
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(ctx, 4), dp(ctx, 10), dp(ctx, 4), dp(ctx, 8))
            addView(icon, LinearLayout.LayoutParams(dp(ctx, 44), dp(ctx, 44)))
            addView(word, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(ctx, 4) })
            setOnClickListener { onClick() }
        }
        val paint = { sel: Boolean ->
            val rad = dp(ctx, 12).toFloat()
            if (sel) {
                box.background = Ui.gradient(rad)
                icon.color = Ui.BG
                word.setTextColor(Ui.BG)
            } else {
                box.background = Ui.round(Ui.CHIP, rad)
                icon.color = Ui.TEXT
                word.setTextColor(Ui.MUTED)
            }
        }
        paint(selected)
        return box to paint
    }

    /**
     * A row of icon tiles, one chosen at a time: [kinds] and [labels] go together; [selected] is the position of the chosen one (-1 = none);
     * [onPick] gets the POSITION that was tapped (so a caller can keep its own numbering).
     */
    fun row(ctx: Context, kinds: IntArray, labels: List<String>, selected: Int, onPick: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; isBaselineAligned = false }
        val paints = ArrayList<(Boolean) -> Unit>()
        kinds.forEachIndexed { i, k ->
            val (t, paint) = tile(ctx, k, labels.getOrElse(i) { "" }, i == selected) {
                paints.forEachIndexed { j, f -> f(j == i) }
                onPick(i)
            }
            paints.add(paint)
            row.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i > 0) marginStart = dp(ctx, 6) })
        }
        return row
    }

    /** A single on / off tile (the lock): painted like a chosen chip while [on]. */
    fun toggle(ctx: Context, kind: Int, label: String, on: Boolean, onToggle: () -> Unit): LinearLayout {
        val holder = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val (t, _) = tile(ctx, kind, label, on) { onToggle() }
        holder.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        return holder
    }
}
