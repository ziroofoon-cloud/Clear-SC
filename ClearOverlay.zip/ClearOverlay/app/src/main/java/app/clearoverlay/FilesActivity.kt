package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.storage.StorageManager
import android.provider.DocumentsContract
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.BaseAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.IOException
import java.text.DateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/**
 * The file manager: the phone's own files, shared folders on the network (the servers saved in the network screen) and cloud
 * accounts (WebDAV), all browsed the same way. Select several items (long-press), copy / cut / paste between any two of them,
 * delete, rename, share, open photos / videos / music / comics in the app's own players.
 */
class FilesActivity : Activity() {

    private class Row(
        val icon: Int,
        val title: String,
        val sub: String,
        val header: Boolean = false,
        val checked: Boolean = false,
        val tap: (() -> Unit)? = null,
        val long: (() -> Unit)? = null,
        /** A hidden file or folder (name starts with a dot): drawn a little fainter. */
        val dim: Boolean = false
    )

    /** What copy / cut put aside: items of one storage ([place]), each as (path, is folder, size). */
    class Clip(val place: String, val items: List<Triple<String, Boolean, Long>>, val move: Boolean)

    companion object {
        @Volatile
        var clip: Clip? = null
        private const val REQ_SAF = 7311
        private const val REQ_CLOUD = 7312
    }

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var titleTv: TextView
    private lateinit var subTv: TextView
    private lateinit var msg: TextView
    private lateinit var list: ListView
    private lateinit var bar: LinearLayout
    private lateinit var refreshBtn: View
    private lateinit var newBtn: View
    private lateinit var moreBtn: View
    private lateinit var hiddenBtn: ImageView

    private var rows: List<Row> = emptyList()
    private var place: String? = null
    private var placeTitle = ""
    private var fs: FmFs? = null
    private var path = ""
    private var items: List<FmItem> = emptyList()
    private var shown: List<FmItem> = emptyList()
    private val picked = LinkedHashSet<String>()
    private var sortBy = 0 // 0 name, 1 date, 2 size
    private var asc = true
    private var showHidden = false
    // looks and list behaviour, kept between visits (prefs "crsc", keys fm_*)
    private var density = 0        // 0 comfortable, 1 compact
    private var textScale = 1      // 0 small, 1 medium, 2 large
    private var details = true     // size and date under each name
    private var foldersFirst = true
    private var natural = true     // "file2" before "file10"
    private var typeFilter = 0     // 0 everything, 1 videos, 2 photos, 3 music, 4 comics and books, 5 archives (folders are always shown)
    private var gen = 0
    /** The error of the last folder load (null = it loaded), so the "empty" note is not shown over an error. */
    private var loadError: String? = null
    /** A phone folder to open as soon as "All files access" has been given (the user is in the system settings now). */
    private var pendingLocal: Triple<String, String, String>? = null
    private var safKind = ""
    private val dateFmt: DateFormat by lazy { DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT) }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Cfg.bind(this, "screen")
        Ui.init(this)
        setTheme(Ui.theme())
        super.onCreate(savedInstanceState)
        Ui.styleBars(window)
        val vp = getSharedPreferences("crsc", Context.MODE_PRIVATE)
        showHidden = vp.getBoolean("fm_hidden", false)
        sortBy = vp.getInt("fm_sort", 0).coerceIn(0, 2)
        asc = vp.getBoolean("fm_asc", true)
        density = vp.getInt("fm_density", 0).coerceIn(0, 1)
        textScale = vp.getInt("fm_text", 1).coerceIn(0, 2)
        details = vp.getBoolean("fm_details", true)
        foldersFirst = vp.getBoolean("fm_folders_first", true)
        natural = vp.getBoolean("fm_natural", true)
        // copies made to open a cloud file are not needed after a day
        Thread {
            runCatching {
                val old = System.currentTimeMillis() - 24L * 3600 * 1000
                Fm.tmpDir(this).listFiles()?.forEach { if (it.isFile && it.lastModified() < old) it.delete() }
            }
        }.start()

        val pad = dp(this, 12)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
        }
        val head = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(pad, dp(this@FilesActivity, 10), pad, dp(this@FilesActivity, 6))
        }
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleTv = Ui.text(this, getString(R.string.fm_title), 22f, Ui.TEXT, true).apply {
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setOnClickListener { goUp() }
        }
        subTv = Ui.text(this, "", 12f, Ui.MUTED).apply {
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.START
            visibility = View.GONE
        }
        titles.addView(titleTv)
        titles.addView(subTv)
        head.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        newBtn = Icons.button(this, Icons.FOLDER_PLUS) { newFolderDialog() }
        head.addView(newBtn)
        // hidden files (names that start with a dot): one tap, and the choice is kept
        hiddenBtn = Icons.button(this, if (showHidden) Icons.EYE else Icons.EYE_OFF) { setHidden(!showHidden) }
        head.addView(hiddenBtn)
        refreshBtn = Icons.button(this, Icons.REFRESH) { refresh() }
        head.addView(refreshBtn)
        moreBtn = Icons.button(this, Icons.MORE) { moreMenu() }
        head.addView(moreBtn)
        root.addView(head)

        msg = Ui.text(this, "", 14f, Ui.MUTED).apply {
            gravity = Gravity.CENTER
            setPadding(pad * 2, pad, pad * 2, pad)
            visibility = View.GONE
        }
        root.addView(msg)

        list = ListView(this).apply {
            divider = android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT)
            dividerHeight = dp(this@FilesActivity, 6)
            setPadding(pad, 0, pad, pad)
            clipToPadding = false
            selector = Ui.round(android.graphics.Color.TRANSPARENT, 0f)
            isVerticalScrollBarEnabled = false
        }
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ -> rows.getOrNull(pos)?.tap?.invoke() }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            rows.getOrNull(pos)?.long?.invoke()
            true
        }
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(this@FilesActivity, 8), dp(this@FilesActivity, 8), dp(this@FilesActivity, 8), dp(this@FilesActivity, 8))
            setBackgroundColor(Ui.CARD)
            visibility = View.GONE
        }
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)
        showHome()
    }

    override fun onResume() {
        super.onResume()
        if (fs == null && !isFinishing) showHome() // e.g. back from the network screen: its server list may have changed
        // back from the system settings where "All files access" was asked for: open the folder that was tapped, no second tap needed
        val p = pendingLocal
        pendingLocal = null
        if (p != null && !isFinishing && Environment.isExternalStorageManager()) openPlace(Fm.LOCAL + p.first, p.third, p.second)
    }

    override fun onDestroy() {
        gen++
        closeFs()
        super.onDestroy()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (fs != null) goUp() else super.onBackPressed()
    }

    private fun closeFs() {
        val f = fs
        fs = null
        if (f != null) Thread { runCatching { f.close() } }.start()
    }

    private fun toast(r: Int) = Toast.makeText(this, r, Toast.LENGTH_SHORT).show()

    // ---- hidden files ---------------------------------------------------------------------------

    private fun updateEye() {
        hiddenBtn.setImageDrawable(LineIcon(if (showHidden) Icons.EYE else Icons.EYE_OFF, Ui.ACCENT))
    }

    /** Shows or hides the files whose name starts with a dot; the choice is kept for the next time. */
    private fun setHidden(on: Boolean) {
        showHidden = on
        getSharedPreferences("crsc", Context.MODE_PRIVATE).edit().putBoolean("fm_hidden", on).apply()
        updateEye()
        toast(if (on) R.string.fm_hidden_now_shown else R.string.fm_hidden_now_hidden)
        if (fs == null) {
            showHome()
            return
        }
        // what is not on the screen must not stay selected (Delete / Cut would still act on it)
        picked.retainAll(visibleItems().map { it.name }.toSet())
        rebuild()
        showEmptyNote()
    }

    private fun showEmptyNote() {
        if (fs == null || loadError != null) return
        if (visibleItems().isEmpty()) {
            msg.text = getString(R.string.fm_empty)
            msg.visibility = View.VISIBLE
        } else {
            msg.visibility = View.GONE
        }
    }

    // ---- home: the places -----------------------------------------------------------------------

    private fun showHome() {
        gen++
        closeFs()
        place = null
        path = ""
        items = emptyList()
        shown = emptyList()
        picked.clear()
        titleTv.text = getString(R.string.fm_title)
        subTv.visibility = View.GONE
        newBtn.visibility = View.GONE
        moreBtn.visibility = View.GONE
        msg.visibility = View.GONE
        val r = ArrayList<Row>()
        r.add(Row(Icons.FOLDER, getString(R.string.fm_phone), "", header = true))
        val root = Environment.getExternalStorageDirectory().absolutePath
        r.add(Row(Icons.FOLDER, getString(R.string.fm_internal), root, tap = { openLocal(root, root, getString(R.string.fm_internal)) }))
        // how full the phone is, and the way to make room (shrink videos / photos / music / comics, or find the biggest files)
        runCatching {
            val st = android.os.StatFs(root)
            val free = st.availableBytes
            val total = st.totalBytes
            r.add(Row(Icons.TRASH, getString(R.string.fm_free_up), getString(R.string.fm_storage_fmt, fmtSize(free), fmtSize(total)), tap = { startActivity(Intent(this, CleanActivity::class.java)) }))
        }
        runCatching {
            val sm = getSystemService(StorageManager::class.java)
            for (v in sm.storageVolumes) {
                val d = v.directory ?: continue
                if (v.isPrimary || v.state != Environment.MEDIA_MOUNTED) continue
                val title = v.getDescription(this)
                r.add(Row(Icons.FOLDER, title, d.absolutePath, tap = { openLocal(d.absolutePath, d.absolutePath, title) }))
            }
        }
        for (n in listOf("Download", "DCIM", "Pictures", "Movies", "Music", "Documents")) {
            val d = File(root, n)
            if (d.isDirectory) r.add(Row(Icons.FOLDER, n, "", tap = { openLocal(root, d.absolutePath, getString(R.string.fm_internal)) }))
        }
        // hidden and protected places (like the root / data folders of a full file manager)
        r.add(Row(Icons.EYE, getString(R.string.fm_hidden_sec), "", header = true))
        r.add(Row(if (showHidden) Icons.EYE else Icons.EYE_OFF, getString(if (showHidden) R.string.fm_hidden_row_on else R.string.fm_hidden_row_off),
            getString(R.string.fm_hidden_row_sub), tap = { setHidden(!showHidden) }))
        r.add(Row(Icons.LOCK, "Android/data", getString(R.string.fm_protected_sub), tap = { openProtected("data") }))
        r.add(Row(Icons.LOCK, "Android/obb", getString(R.string.fm_protected_sub), tap = { openProtected("obb") }))
        val media = File(root, "Android/media")
        if (media.isDirectory) r.add(Row(Icons.FOLDER, "Android/media", "", tap = { openLocal(root, media.absolutePath, getString(R.string.fm_internal)) }))
        val own = applicationInfo.dataDir
        r.add(Row(Icons.GEAR, getString(R.string.fm_app_private), own, tap = { openPlace(Fm.LOCAL + own, getString(R.string.fm_app_private), own) }))
        r.add(Row(Icons.SERVER, getString(R.string.fm_root), "/", tap = { openPlace(Fm.LOCAL + "/", getString(R.string.fm_root), "/") }))
        r.add(Row(Icons.GLOBE, getString(R.string.fm_network), "", header = true))
        for (s in Net.servers(this)) {
            val sub = (if (s.proto == Net.SMB) "SMB  " else "FTP  ") + s.host + (if (s.proto == Net.SMB && s.share.isNotEmpty()) "/" + s.share else "")
            r.add(Row(if (s.proto == Net.SMB) Icons.SERVER else Icons.GLOBE, s.name, sub, tap = {
                val start = Net.lastPath(this, s.id) ?: s.path.ifEmpty { "/" }
                openPlace(Fm.NET + s.id, s.name, start)
            }))
        }
        r.add(Row(Icons.FOLDER_PLUS, getString(R.string.fm_add_servers), "", tap = { startActivity(Intent(this, NetActivity::class.java)) }))
        r.add(Row(Icons.CLOUD, getString(R.string.fm_cloud), "", header = true))
        for (a in FmAccounts.all(this)) {
            r.add(Row(Icons.CLOUD, a.name, if (a.type == FmAccounts.SAF) getString(R.string.fm_cloud_app_sub) else (if (a.type == FmAccounts.S3) "S3  " else "WebDAV  ") + a.url.substringAfter("://").substringBefore('/'),
                tap = { openPlace(Fm.ACC + a.id, a.name, null) }, long = { accountMenu(a) }))
        }
        r.add(Row(Icons.FOLDER_PLUS, getString(R.string.fm_add_cloud), "", tap = { chooseService() }))
        rows = r
        adapter.notifyDataSetChanged()
        list.setSelection(0)
        updateBar()
    }

    private fun refresh() {
        if (fs != null) reload() else showHome()
    }

    // ---- opening a storage ----------------------------------------------------------------------

    private fun openLocal(root: String, start: String, title: String) {
        if (!Environment.isExternalStorageManager()) {
            AlertDialog.Builder(this)
                .setTitle(R.string.fm_perm_title)
                .setMessage(R.string.fm_perm_msg)
                .setPositiveButton(R.string.fm_perm_go) { _, _ ->
                    pendingLocal = Triple(root, start, title)
                    runCatching {
                        startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
                    }.onFailure {
                        runCatching { startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
                    }
                }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
            return
        }
        openPlace(Fm.LOCAL + root, title, start)
    }

    /**
     * Android/data and Android/obb: closed to every app on Android 11 and newer, even with "All files access". First the plain way (older
     * Android, some phones), then the access the user gave once with the folder picker, and if there is none, it is asked for.
     */
    private fun openProtected(kind: String) {
        val root = Environment.getExternalStorageDirectory().absolutePath
        val dir = File(root, "Android/$kind")
        val title = "Android/$kind"
        val direct = Environment.isExternalStorageManager() && runCatching { dir.canRead() && (dir.list()?.isNotEmpty() == true) }.getOrDefault(false)
        if (direct) {
            openPlace(Fm.LOCAL + root, title, dir.absolutePath)
            return
        }
        if (SafFs.treeUri(this, kind) != null) {
            openPlace(Fm.SAF + kind, title, "/")
            return
        }
        // like MT Manager: through Shizuku, when it is running (works on every Android, also where the system picker refuses the folder)
        if (ShizukuAccess.running()) {
            openViaShizuku(kind, title)
            return
        }
        val hint = getString(if (ShizukuAccess.installed(this)) R.string.fm_shz_hint_off else R.string.fm_shz_hint_missing)
        val msgText = getString(R.string.fm_saf_msg) + (if (Build.VERSION.SDK_INT >= 33) "\n\n" + getString(R.string.fm_saf_13) else "") + "\n\n" + hint
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.fm_saf_title_fmt, title))
            .setMessage(msgText)
            .setPositiveButton(R.string.fm_saf_go) { _, _ ->
                safKind = kind
                val init = DocumentsContract.buildDocumentUri("com.android.externalstorage.documents", SafFs.docId(kind))
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
                    .putExtra(DocumentsContract.EXTRA_INITIAL_URI, init)
                    .addFlags(
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                            Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
                    )
                try {
                    startActivityForResult(i, REQ_SAF)
                } catch (e: Exception) {
                    toast(R.string.fm_saf_refused)
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    /** Android/data or Android/obb through the Shizuku helper (asks Shizuku's permission once). */
    private fun openViaShizuku(kind: String, title: String) {
        ShizukuAccess.ask { ok ->
            if (!ok || isFinishing) {
                if (!ok) toast(R.string.fm_shz_denied)
            } else {
                openPlace(Fm.SHZ + kind, title, File(Environment.getExternalStorageDirectory(), "Android/$kind").absolutePath)
            }
        }
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == REQ_CLOUD) {
            val tree = data?.data
            if (res != RESULT_OK || tree == null) { Toast.makeText(this, R.string.fm_saf_refused, Toast.LENGTH_LONG).show(); return }
            runCatching { contentResolver.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
                .onFailure { runCatching { contentResolver.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION) } }
            val base = cloudAppName(tree)
            val folder = runCatching { DocumentsContract.getTreeDocumentId(tree).substringAfterLast('/').substringAfterLast(':') }.getOrDefault("")
            val name = if (folder.isNotEmpty() && folder.length < 40 && !folder.all { it.isDigit() }) "$base · $folder" else base
            FmAccounts.put(this, FmAccounts.Account("saf" + System.currentTimeMillis(), name, FmAccounts.SAF, tree.toString(), "", "", false))
            showHome()
            return
        }
        if (req != REQ_SAF) return
        val kind = safKind
        val u = data?.data
        if (res != RESULT_OK || u == null) {
            Toast.makeText(this, R.string.fm_saf_refused, Toast.LENGTH_LONG).show()
            return
        }
        val id = runCatching { DocumentsContract.getTreeDocumentId(u) }.getOrNull()
        if (id != SafFs.docId(kind)) {
            AlertDialog.Builder(this).setMessage(getString(R.string.fm_saf_wrong_fmt, "Android/$kind")).setPositiveButton(android.R.string.ok, null).show()
            return
        }
        runCatching { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
        getSharedPreferences("crsc", Context.MODE_PRIVATE).edit().putString(SafFs.prefKey(kind), u.toString()).apply()
        openPlace(Fm.SAF + kind, "Android/$kind", "/")
    }

    private fun openPlace(id: String, title: String, start: String?) {
        val mine = ++gen
        msg.text = getString(R.string.fm_connecting)
        msg.visibility = View.VISIBLE
        Thread {
            var f: FmFs? = null
            var err: String? = null
            try {
                f = Fm.open(this, id)
            } catch (t: Throwable) {
                err = (t.cause ?: t).message ?: t.javaClass.simpleName
            }
            val ff = f
            val ee = err
            ui.post {
                if (isDestroyed || mine != gen) {
                    Thread { runCatching { ff?.close() } }.start()
                    return@post
                }
                if (ee != null || ff == null) {
                    msg.visibility = View.GONE
                    AlertDialog.Builder(this).setMessage(getString(R.string.fm_error_fmt, ee ?: "")).setPositiveButton(android.R.string.ok, null).show()
                    return@post
                }
                closeFs()
                fs = ff
                place = id
                placeTitle = title
                picked.clear()
                path = start ?: ff.root()
                newBtn.visibility = View.VISIBLE
                moreBtn.visibility = View.VISIBLE
                reload()
            }
        }.start()
    }

    private fun reload() {
        val f = fs ?: return
        val mine = ++gen
        titleTv.text = placeTitle
        subTv.text = path
        subTv.visibility = View.VISIBLE
        msg.text = getString(R.string.fm_loading)
        msg.visibility = View.VISIBLE
        Thread {
            var l: List<FmItem> = emptyList()
            var err: String? = null
            try {
                l = f.list(path)
            } catch (t: Throwable) {
                err = (t.cause ?: t).message ?: t.javaClass.simpleName
            }
            val ll = l
            val ee = err
            ui.post {
                if (isDestroyed || mine != gen) return@post
                loadError = ee
                if (ee != null) {
                    items = emptyList()
                    msg.text = getString(R.string.fm_error_fmt, ee)
                    msg.visibility = View.VISIBLE
                } else {
                    items = ll
                    msg.visibility = View.GONE
                    place?.let { if (it.startsWith(Fm.NET)) Net.setLastPath(this, it.substring(Fm.NET.length), path) }
                }
                // only what is on the screen can stay selected
                picked.retainAll(visibleItems().map { it.name }.toSet())
                rebuild()
                showEmptyNote()
            }
        }.start()
    }

    private fun goUp() {
        val f = fs ?: return
        if (picked.isNotEmpty()) {
            picked.clear()
            rebuild()
            return
        }
        val p = f.parent(path)
        if (p == null) {
            showHome()
        } else {
            path = p
            reload()
        }
    }

    // ---- the list -------------------------------------------------------------------------------

    private fun visibleItems(): List<FmItem> {
        val l = items.filter { (showHidden || !it.name.startsWith(".")) && (it.dir || matchesFilter(it.name)) }
        val cmp = Comparator<FmItem> { a, b ->
            if (foldersFirst && a.dir != b.dir) return@Comparator if (a.dir) -1 else 1
            val r = when (sortBy) {
                1 -> a.modified.compareTo(b.modified)
                2 -> a.size.compareTo(b.size)
                else -> if (natural) naturalCompare(a.name, b.name) else a.name.compareTo(b.name, ignoreCase = true)
            }
            if (asc) r else -r
        }
        return l.sortedWith(cmp)
    }

    private fun matchesFilter(n: String): Boolean = when (typeFilter) {
        1 -> Net.isVideo(n)
        2 -> Net.isImage(n) || Net.isGif(n)
        3 -> Net.isAudio(n)
        4 -> Net.isManga(n)
        5 -> n.substringAfterLast('.', "").lowercase(Locale.ROOT) in setOf("zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz")
        else -> true
    }

    /** Name order that reads numbers as numbers (file2 before file10) and ignores case. */
    private fun naturalCompare(a: String, b: String): Int {
        var i = 0
        var j = 0
        while (i < a.length && j < b.length) {
            val x = a[i]
            val y = b[j]
            if (x.isDigit() && y.isDigit()) {
                var i2 = i
                while (i2 < a.length && a[i2].isDigit()) i2++
                var j2 = j
                while (j2 < b.length && b[j2].isDigit()) j2++
                val na = a.substring(i, i2).trimStart('0')
                val nb = b.substring(j, j2).trimStart('0')
                if (na.length != nb.length) return na.length - nb.length
                val c = na.compareTo(nb)
                if (c != 0) return c
                i = i2
                j = j2
            } else {
                val c = x.lowercaseChar().compareTo(y.lowercaseChar())
                if (c != 0) return c
                i++
                j++
            }
        }
        return (a.length - i) - (b.length - j)
    }

    private fun saveView() {
        getSharedPreferences("crsc", Context.MODE_PRIVATE).edit()
            .putInt("fm_sort", sortBy).putBoolean("fm_asc", asc).putInt("fm_density", density).putInt("fm_text", textScale)
            .putBoolean("fm_details", details).putBoolean("fm_folders_first", foldersFirst).putBoolean("fm_natural", natural).apply()
    }

    /** Row size, text size, details, folder order, name order: each tap changes one and the menu opens again. */
    private fun viewMenu() {
        fun onOff(b: Boolean) = getString(if (b) R.string.fm_v_on else R.string.fm_v_off)
        val labels = arrayOf(
            getString(R.string.fm_v_density) + ": " + getString(if (density == 0) R.string.fm_v_comfy else R.string.fm_v_compact),
            getString(R.string.fm_v_text) + ": " + getString(when (textScale) { 0 -> R.string.fm_v_small; 2 -> R.string.fm_v_large; else -> R.string.fm_v_medium }),
            getString(R.string.fm_v_details) + ": " + onOff(details),
            getString(R.string.fm_v_folders) + ": " + onOff(foldersFirst),
            getString(R.string.fm_v_natural) + ": " + onOff(natural)
        )
        AlertDialog.Builder(this).setTitle(R.string.fm_view).setItems(labels) { _, w ->
            when (w) {
                0 -> density = 1 - density
                1 -> textScale = (textScale + 1) % 3
                2 -> details = !details
                3 -> foldersFirst = !foldersFirst
                4 -> natural = !natural
            }
            saveView()
            rebuild()
            viewMenu()
        }.setNegativeButton(android.R.string.ok, null).show()
    }

    private fun filterMenu() {
        val names = arrayOf(R.string.fm_f_all, R.string.fm_f_video, R.string.fm_f_photo, R.string.fm_f_music, R.string.fm_f_comics, R.string.fm_f_arch)
            .map { getString(it) }.toTypedArray()
        AlertDialog.Builder(this).setTitle(R.string.fm_filter).setSingleChoiceItems(names, typeFilter) { d, w ->
            typeFilter = w
            d.dismiss()
            picked.retainAll(visibleItems().map { it.name }.toSet())
            rebuild()
            showEmptyNote()
        }.show()
    }

    private fun invertSelection() {
        val now = visibleItems().map { it.name }.toSet()
        val next = now.filter { it !in picked }
        picked.clear()
        picked.addAll(next)
        rebuild()
    }

    private fun copyPathSelected() {
        val f = fs ?: return
        val txt = items.filter { it.name in picked }.joinToString("\n") { f.join(path, it.name) }
        if (txt.isEmpty()) return
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("path", txt))
        toast(R.string.fm_path_copied)
    }

    private fun rebuild() {
        val v = visibleItems()
        shown = v
        rows = v.map { e ->
            Row(iconOf(e), e.name, subOf(e), checked = e.name in picked, tap = { onTap(e) }, long = { toggle(e.name) }, dim = e.name.startsWith("."))
        }
        adapter.notifyDataSetChanged()
        updateBar()
    }

    private fun iconOf(e: FmItem): Int = when {
        e.dir -> Icons.FOLDER
        Net.isVideo(e.name) -> Icons.FILM
        Net.isImage(e.name) || Net.isGif(e.name) -> Icons.IMAGE
        Net.isManga(e.name) -> Icons.BOOK
        Net.isAudio(e.name) -> Icons.MUSIC
        else -> Icons.FILE
    }

    private fun subOf(e: FmItem): String {
        val parts = ArrayList<String>()
        if (!e.dir && e.size >= 0) parts.add(fmtSize(e.size))
        if (e.modified > 0) parts.add(dateFmt.format(Date(e.modified)))
        return parts.joinToString("  •  ")
    }

    private fun toggle(name: String) {
        if (!picked.add(name)) picked.remove(name)
        rebuild()
    }

    private fun onTap(e: FmItem) {
        val f = fs ?: return
        if (picked.isNotEmpty()) {
            toggle(e.name)
        } else if (e.dir) {
            path = f.join(path, e.name)
            reload()
        } else {
            openFile(e)
        }
    }

    private fun updateBar() {
        bar.removeAllViews()
        val c = clip
        if (fs == null) {
            bar.visibility = View.GONE
        } else if (picked.isNotEmpty()) {
            bar.visibility = View.VISIBLE
            barBtn(getString(R.string.fm_copy)) { setClip(false) }
            barBtn(getString(R.string.fm_cut)) { setClip(true) }
            barBtn(getString(R.string.fm_delete)) { confirmDelete() }
            if (picked.size == 1) barBtn(getString(R.string.fm_rename)) { renameDialog() }
            barBtn(getString(R.string.fm_more)) { selectionMenu() }
        } else if (c != null) {
            bar.visibility = View.VISIBLE
            barBtn(getString(R.string.fm_paste_here, c.items.size)) { paste() }
            barBtn(getString(R.string.fm_clear_clip)) {
                clip = null
                updateBar()
            }
        } else {
            bar.visibility = View.GONE
        }
    }

    private fun barBtn(text: String, on: () -> Unit) {
        val t = TextView(this).apply {
            this.text = text
            gravity = Gravity.CENTER
            textSize = 13f
            maxLines = 1
            setTextColor(Ui.ACCENT)
            setPadding(dp(this@FilesActivity, 4), dp(this@FilesActivity, 10), dp(this@FilesActivity, 4), dp(this@FilesActivity, 10))
            background = Ui.round(Ui.CHIP, dp(this@FilesActivity, 10).toFloat())
            setOnClickListener { on() }
        }
        bar.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            setMargins(dp(this@FilesActivity, 3), 0, dp(this@FilesActivity, 3), 0)
        })
    }

    private val adapter = object : BaseAdapter() {
        override fun getCount(): Int = rows.size
        override fun getItem(position: Int): Any = position
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val ctx = this@FilesActivity
            val row = (convertView as? LinearLayout) ?: LinearLayout(ctx).apply {
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = android.widget.AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                val ic = Ui.text(ctx, "", 22f, Ui.TEXT).apply { gravity = Gravity.CENTER }
                addView(ic, LinearLayout.LayoutParams(dp(ctx, 36), ViewGroup.LayoutParams.WRAP_CONTENT))
                val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
                col.addView(Ui.text(ctx, "", 15f, Ui.TEXT).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE })
                col.addView(Ui.text(ctx, "", 12f, Ui.MUTED).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE })
                addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            }
            val ic = row.getChildAt(0) as TextView
            val col = row.getChildAt(1) as LinearLayout
            val t1 = col.getChildAt(0) as TextView
            val t2 = col.getChildAt(1) as TextView
            val r = rows[position]
            row.alpha = if (r.dim) 0.55f else 1f
            val tsz = floatArrayOf(13f, 15f, 17.5f)[textScale]
            val vpad = if (density == 1) 5 else 10
            t1.text = r.title
            t2.text = r.sub
            t2.textSize = tsz - 3f
            t2.visibility = if (r.sub.isEmpty() || (!details && !r.header)) View.GONE else View.VISIBLE
            if (r.header) {
                ic.visibility = View.GONE
                t1.textSize = 13f
                t1.setTextColor(Ui.ACCENT)
                row.background = null
                row.setPadding(dp(ctx, 4), dp(ctx, 14), dp(ctx, 4), dp(ctx, 2))
            } else {
                ic.visibility = View.VISIBLE
                Icons.glyphRow(ic, r.icon, Ui.ACCENT, 26)
                t1.textSize = tsz
                t1.setTextColor(Ui.TEXT)
                row.setPadding(dp(ctx, 12), dp(ctx, vpad), dp(ctx, 12), dp(ctx, vpad))
                row.background = if (r.checked) Ui.round(Ui.CHIP, dp(ctx, 12).toFloat(), Ui.ACCENT, dp(ctx, 2))
                else Ui.round(Ui.CARD, dp(ctx, 12).toFloat())
            }
            return row
        }
    }

    // ---- menus ----------------------------------------------------------------------------------

    private fun moreMenu() {
        val labels = arrayOf(
            getString(R.string.fm_sort) + ": " + getString(R.string.fm_sort_name),
            getString(R.string.fm_sort) + ": " + getString(R.string.fm_sort_date),
            getString(R.string.fm_sort) + ": " + getString(R.string.fm_sort_size),
            getString(if (asc) R.string.fm_desc else R.string.fm_asc),
            getString(if (showHidden) R.string.fm_hidden_hide else R.string.fm_hidden_show),
            getString(R.string.fm_select_all),
            getString(R.string.fm_search),
            getString(R.string.fm_biggest),
            getString(R.string.fm_free_up),
            getString(R.string.fm_dupes),
            getString(R.string.fm_space),
            getString(R.string.fm_view),
            getString(R.string.fm_filter) + ": " + getString(listOf(R.string.fm_f_all, R.string.fm_f_video, R.string.fm_f_photo, R.string.fm_f_music, R.string.fm_f_comics, R.string.fm_f_arch)[typeFilter]),
            getString(R.string.fm_invert)
        )
        AlertDialog.Builder(this).setItems(labels) { _, w ->
            when (w) {
                11 -> {
                    viewMenu()
                    return@setItems
                }
                12 -> {
                    filterMenu()
                    return@setItems
                }
                13 -> invertSelection()
                9 -> {
                    dupesDialog()
                    return@setItems
                }
                10 -> {
                    spaceDialog()
                    return@setItems
                }
                7 -> {
                    biggestDialog()
                    return@setItems
                }
                8 -> {
                    startActivity(Intent(this, CleanActivity::class.java))
                    return@setItems
                }
                0, 1, 2 -> { sortBy = w; saveView() }
                3 -> { asc = !asc; saveView() }
                4 -> {
                    setHidden(!showHidden)
                    return@setItems
                }
                5 -> for (e in visibleItems()) picked.add(e.name)
                6 -> {
                    searchDialog()
                    return@setItems
                }
            }
            rebuild()
        }.show()
    }

    private fun selectionMenu() {
        val labels = arrayOf(
            getString(R.string.fm_share), getString(R.string.fm_select_all), getString(R.string.fm_props),
            getString(R.string.fm_zip), getString(R.string.fm_unzip), getString(R.string.fm_invert), getString(R.string.fm_copy_path)
        )
        AlertDialog.Builder(this).setItems(labels) { _, w ->
            when (w) {
                0 -> shareSelected()
                1 -> {
                    for (e in visibleItems()) picked.add(e.name)
                    rebuild()
                }
                2 -> showProps()
                3 -> zipSelected()
                4 -> unzipSelected()
                5 -> invertSelection()
                6 -> copyPathSelected()
            }
        }.show()
    }

    private fun accountMenu(a: FmAccounts.Account) {
        val labels = arrayOf(getString(R.string.fm_edit), getString(R.string.fm_remove))
        AlertDialog.Builder(this).setTitle(a.name).setItems(labels) { _, w ->
            if (w == 0) {
                if (a.type == FmAccounts.SAF) renameCloudApp(a)
                else if (a.type == FmAccounts.S3) s3Dialog(a, a.name, a.url, a.extra.substringBefore('|'))
                else accountDialog(a, a.name, a.url, a.insecure)
            } else {
                AlertDialog.Builder(this).setMessage(getString(R.string.fm_remove_acc_fmt, a.name))
                    .setPositiveButton(R.string.fm_remove) { _, _ ->
                        FmAccounts.remove(this, a.id)
                        showHome()
                    }
                    .setNegativeButton(android.R.string.cancel, null).show()
            }
        }.show()
    }

    // ---- cloud accounts -------------------------------------------------------------------------

    private class Preset(val name: String, val url: String, val insecure: Boolean, val s3Region: String? = null)

    private val presets = listOf(
        Preset("Nextcloud / ownCloud", "https://YOUR-SERVER/remote.php/dav/files/USERNAME/", false),
        Preset("Box", "https://dav.box.com/dav", false),
        Preset("pCloud (Europe)", "https://ewebdav.pcloud.com", false),
        Preset("pCloud (US)", "https://webdav.pcloud.com", false),
        Preset("Koofr", "https://app.koofr.net/dav/Koofr", false),
        Preset("Yandex Disk", "https://webdav.yandex.com", false),
        Preset("GMX", "https://webdav.mc.gmx.net", false),
        Preset("WEB.DE", "https://webdav.smartdrive.web.de", false),
        Preset("Synology NAS", "https://YOUR-NAS:5006", true),
        Preset("QNAP NAS", "https://YOUR-NAS:5001", true),
        Preset("WebDAV", "https://", false),
        Preset("Amazon S3", "https://s3.YOUR-REGION.amazonaws.com", false, "us-east-1"),
        Preset("Backblaze B2 (S3)", "https://s3.YOUR-REGION.backblazeb2.com", false, "us-west-004"),
        Preset("Wasabi (S3)", "https://s3.YOUR-REGION.wasabisys.com", false, "us-east-1"),
        Preset("Cloudflare R2 (S3)", "https://YOUR-ACCOUNT-ID.r2.cloudflarestorage.com", false, "auto"),
        Preset("MinIO / other S3", "https://", false, "us-east-1")
    )

    /** Google Drive, OneDrive, Dropbox, Mega... : their apps offer their files to other apps; the system folder picker shows them. */
    private fun pickCloudApp() {
        AlertDialog.Builder(this)
            .setTitle(R.string.fm_cloud_apps)
            .setMessage(R.string.fm_cloud_apps_msg)
            .setPositiveButton(R.string.fm_saf_go) { _, _ ->
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
                )
                try {
                    @Suppress("DEPRECATION")
                    startActivityForResult(i, REQ_CLOUD)
                } catch (e: Exception) {
                    toast(R.string.fm_saf_refused)
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun cloudAppName(u: Uri): String {
        val auth = u.authority ?: return "Cloud"
        val label = runCatching { packageManager.resolveContentProvider(auth, 0)?.loadLabel(packageManager)?.toString() }.getOrNull()
        val known = when {
            auth.contains("docs.storage") -> "Google Drive"
            auth.contains("skydrive") -> "OneDrive"
            auth.contains("dropbox") -> "Dropbox"
            else -> null
        }
        return known ?: label ?: auth
    }

    private fun renameCloudApp(a: FmAccounts.Account) {
        val et = EditText(this).apply { setSingleLine(); setText(a.name) }
        AlertDialog.Builder(this).setTitle(R.string.fm_edit).setView(et)
            .setPositiveButton(R.string.net_save) { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) { FmAccounts.put(this, FmAccounts.Account(a.id, n, a.type, a.url, a.user, a.pass, a.insecure, a.extra)); showHome() }
            }
            .setNegativeButton(android.R.string.cancel, null).show()
    }

    private fun chooseService() {
        val names = listOf(getString(R.string.fm_cloud_apps)) + presets.map { it.name }
        AlertDialog.Builder(this).setTitle(R.string.fm_service_title)
            .setItems(names.toTypedArray()) { _, w0 ->
                if (w0 == 0) { pickCloudApp(); return@setItems }
                val w = w0 - 1
                val p = presets[w]
                if (p.s3Region != null) s3Dialog(null, p.name, p.url, p.s3Region) else accountDialog(null, p.name, p.url, p.insecure)
            }
            .setNegativeButton(android.R.string.cancel, null).show()
    }

    private fun accountDialog(old: FmAccounts.Account?, preName: String, preUrl: String, preInsecure: Boolean) {
        val pad = dp(this, 20)
        fun field(hint: String, value: String, pw: Boolean = false) = EditText(this).apply {
            setSingleLine()
            this.hint = hint
            setText(value)
            inputType = if (pw) android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            else android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, dp(this@FilesActivity, 8), pad, 0)
        }
        val name = field(getString(R.string.fm_acc_name), preName)
        val url = field(getString(R.string.fm_acc_url), preUrl)
        val user = field(getString(R.string.fm_acc_user), old?.user ?: "")
        val pass = field(getString(R.string.fm_acc_pass), old?.pass ?: "", pw = true)
        val insecure = CheckBox(this).apply {
            text = getString(R.string.fm_acc_insecure)
            isChecked = preInsecure
        }
        val tip = Ui.text(this, getString(R.string.fm_acc_tip), 12f, Ui.MUTED).apply {
            setPadding(0, dp(this@FilesActivity, 8), 0, dp(this@FilesActivity, 8))
        }
        for (v in listOf(name, url, user, pass, insecure, tip)) box.addView(v)
        val dlg = AlertDialog.Builder(this)
            .setTitle(getString(if (old == null) R.string.fm_add_cloud else R.string.fm_edit))
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton(R.string.net_save, null)
            .setNegativeButton(android.R.string.cancel, null)
            .create()
        dlg.show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener { btn ->
            val u = url.text.toString().trim()
            if (u.isEmpty() || u == "https://" || u.contains("YOUR-")) {
                toast(R.string.fm_acc_need_url)
                return@setOnClickListener
            }
            val acc = FmAccounts.Account(
                old?.id ?: Net.newId(), name.text.toString().trim().ifEmpty { u.substringAfter("://").substringBefore('/') },
                FmAccounts.WEBDAV, u, user.text.toString().trim(), pass.text.toString(), insecure.isChecked
            )
            btn.isEnabled = false
            Toast.makeText(this, R.string.fm_acc_testing, Toast.LENGTH_SHORT).show()
            Thread {
                var err: String? = null
                try {
                    WebDavFs(acc.url, acc.user, acc.pass, acc.insecure, Fm.tmpDir(this)).use { it.list("/") }
                } catch (t: Throwable) {
                    err = (t.cause ?: t).message ?: t.javaClass.simpleName
                }
                val e = err
                ui.post {
                    if (isDestroyed) return@post
                    btn.isEnabled = true
                    if (e != null) {
                        AlertDialog.Builder(this).setMessage(getString(R.string.fm_error_fmt, e)).setPositiveButton(android.R.string.ok, null).show()
                    } else {
                        FmAccounts.put(this, acc)
                        dlg.dismiss()
                        showHome()
                    }
                }
            }.start()
        }
    }

    private fun s3Dialog(old: FmAccounts.Account?, preName: String, preUrl: String, preRegion: String) {
        val pad = dp(this, 20)
        fun field(hint: String, value: String, pw: Boolean = false) = EditText(this).apply {
            setSingleLine()
            this.hint = hint
            setText(value)
            inputType = if (pw) android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            else android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, dp(this@FilesActivity, 8), pad, 0)
        }
        val name = field(getString(R.string.fm_acc_name), preName)
        val url = field(getString(R.string.fm_s3_endpoint), preUrl)
        val region = field(getString(R.string.fm_s3_region), preRegion)
        val bucket = field(getString(R.string.fm_s3_bucket), old?.extra?.substringAfter('|', "") ?: "")
        val access = field(getString(R.string.fm_s3_access), old?.user ?: "")
        val secret = field(getString(R.string.fm_s3_secret), old?.pass ?: "", pw = true)
        val tip = Ui.text(this, getString(R.string.fm_s3_tip), 12f, Ui.MUTED).apply {
            setPadding(0, dp(this@FilesActivity, 8), 0, dp(this@FilesActivity, 8))
        }
        for (v in listOf(name, url, region, bucket, access, secret, tip)) box.addView(v)
        val dlg = AlertDialog.Builder(this)
            .setTitle(getString(if (old == null) R.string.fm_add_cloud else R.string.fm_edit))
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton(R.string.net_save, null)
            .setNegativeButton(android.R.string.cancel, null)
            .create()
        dlg.show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener { btn ->
            val u = url.text.toString().trim()
            if (u.isEmpty() || u == "https://" || u.contains("YOUR-") || access.text.isBlank() || secret.text.isBlank()) {
                toast(R.string.fm_acc_need_url)
                return@setOnClickListener
            }
            val acc = FmAccounts.Account(
                old?.id ?: Net.newId(), name.text.toString().trim().ifEmpty { u.substringAfter("://").substringBefore('/') },
                FmAccounts.S3, u, access.text.toString().trim(), secret.text.toString().trim(), false,
                region.text.toString().trim() + "|" + bucket.text.toString().trim()
            )
            btn.isEnabled = false
            Toast.makeText(this, R.string.fm_acc_testing, Toast.LENGTH_SHORT).show()
            Thread {
                var err: String? = null
                try {
                    S3Fs(acc.url, acc.extra.substringBefore('|'), acc.extra.substringAfter('|', ""), acc.user, acc.pass, false, Fm.tmpDir(this))
                        .use { it.list("/") }
                } catch (t: Throwable) {
                    err = (t.cause ?: t).message ?: t.javaClass.simpleName
                }
                val e = err
                ui.post {
                    if (isDestroyed) return@post
                    btn.isEnabled = true
                    if (e != null) {
                        AlertDialog.Builder(this).setMessage(getString(R.string.fm_error_fmt, e)).setPositiveButton(android.R.string.ok, null).show()
                    } else {
                        FmAccounts.put(this, acc)
                        dlg.dismiss()
                        showHome()
                    }
                }
            }.start()
        }
    }

    private fun searchDialog() {
        val f = fs ?: return
        val start = path
        val input = EditText(this).apply {
            setSingleLine()
            hint = getString(R.string.fm_search_hint)
        }
        AlertDialog.Builder(this).setTitle(R.string.fm_search).setView(input)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val q = input.text.toString().trim()
                if (q.isEmpty()) return@setPositiveButton
                val hits = arrayOfNulls<List<FmSearch.Hit>>(1)
                runJob(getString(R.string.fm_searching), { showHits(hits[0] ?: emptyList()) }) { setText, cancel ->
                    setText(q)
                    hits[0] = FmSearch.find(f, start, q, 300, FmSearch.Cancel { cancel.get() })
                }
            }
            .setNegativeButton(android.R.string.cancel, null).show()
    }

    /** The biggest files of this folder and everything below it: tap one to jump to it (selected), then delete it, move it or shrink it. */
    private fun biggestDialog() {
        val f = fs ?: return
        val start = path
        val hits = arrayOfNulls<List<FmSearch.Hit>>(1)
        runJob(getString(R.string.fm_searching), {
            val l = hits[0] ?: emptyList()
            if (l.isEmpty()) toast(R.string.fm_no_hits)
            else {
                val labels = l.map { fmtSize(it.item.size) + "   " + it.item.name + "\n" + it.dir }.toTypedArray()
                AlertDialog.Builder(this).setTitle(getString(R.string.fm_biggest) + " (" + l.size + ")")
                    .setItems(labels) { _, w ->
                        val h = l[w]
                        if (h.item.name.startsWith(".") && !showHidden) setHidden(true)
                        path = h.dir
                        picked.clear()
                        picked.add(h.item.name)
                        reload()
                    }
                    .setNegativeButton(android.R.string.cancel, null).show()
            }
        }) { setText, cancel ->
            setText(path)
            hits[0] = FmSearch.biggest(f, start, 60, FmSearch.Cancel { cancel.get() })
        }
    }

    /** Identical files below this folder (phone storage only): pick a group, tick the copies to remove (all but the first are ticked). */
    private fun dupesDialog() {
        val f = fs ?: return
        if (!localOnly()) return
        val root = f.localFile(path) ?: return
        val res = arrayOfNulls<List<FmDupes.Group>>(1)
        runJob(getString(R.string.fm_dupes_searching), {
            val l = res[0] ?: emptyList()
            if (l.isEmpty()) toast(R.string.fm_dupes_none) else showDupeGroups(l)
        }) { setText, cancel ->
            setText(path)
            res[0] = FmDupes.find(root, showHidden, { cancel.get() }) { setText(it) }
        }
    }

    /** Where the space went: the size of every item of this folder (folders counted with everything inside), biggest first, with a share bar. */
    private fun spaceDialog() {
        val f = fs ?: return
        val dir = path
        val list = items.filter { showHidden || !it.name.startsWith(".") }
        if (list.isEmpty()) { toast(R.string.fm_empty); return }
        val res = arrayOfNulls<List<Pair<FmItem, Long>>>(1)
        runJob(getString(R.string.fm_space_counting), {
            val l = res[0] ?: emptyList()
            val total = l.sumOf { it.second }.coerceAtLeast(1L)
            val labels = l.map { (e, sz) ->
                val pct = (sz * 100L / total).toInt()
                val bar = "█".repeat((pct / 10).coerceIn(0, 10)) + "░".repeat(10 - (pct / 10).coerceIn(0, 10))
                (if (e.dir) "▸ " else "") + e.name + "\n" + bar + "  " + fmtSize(sz) + "  " + pct + "%"
            }.toTypedArray()
            AlertDialog.Builder(this).setTitle(getString(R.string.fm_space_title_fmt, fmtSize(total)))
                .setItems(labels) { _, w ->
                    val e = l[w].first
                    if (e.dir) {
                        path = f.join(dir, e.name)
                        picked.clear()
                        reload()
                    } else {
                        picked.clear()
                        picked.add(e.name)
                        rebuild()
                    }
                }
                .setNegativeButton(android.R.string.cancel, null).show()
        }) { setText, cancel ->
            val out = ArrayList<Pair<FmItem, Long>>()
            for (e in list) {
                if (cancel.get()) break
                setText(e.name)
                out.add(e to FmCopy.totalSize(f, f.join(dir, e.name), e.dir, e.size).coerceAtLeast(0L))
            }
            out.sortByDescending { it.second }
            res[0] = out
        }
    }

    private fun showDupeGroups(l: List<FmDupes.Group>) {
        val waste = l.sumOf { it.size * (it.files.size - 1) }
        val labels = l.map { fmtSize(it.size) + " × " + it.files.size + "   " + it.files[0].name }.toTypedArray()
        AlertDialog.Builder(this).setTitle(getString(R.string.fm_dupes_title_fmt, l.size, fmtSize(waste)))
            .setItems(labels) { _, w -> showDupeFiles(l, w) }
            .setNegativeButton(android.R.string.cancel, null).show()
    }

    private fun showDupeFiles(all: List<FmDupes.Group>, idx: Int) {
        val g = all[idx]
        val names = g.files.map { it.absolutePath }.toTypedArray()
        val checked = BooleanArray(names.size) { it > 0 }
        AlertDialog.Builder(this).setTitle(fmtSize(g.size) + " × " + g.files.size)
            .setMultiChoiceItems(names, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton(R.string.fm_delete) { _, _ ->
                val del = g.files.filterIndexed { i, _ -> checked[i] }
                if (del.size >= g.files.size) {
                    toast(R.string.fm_dupes_keep_one)
                    showDupeFiles(all, idx)
                } else if (del.isNotEmpty()) {
                    AlertDialog.Builder(this).setMessage(getString(R.string.fm_delete_fmt, del.size))
                        .setPositiveButton(R.string.fm_delete) { _, _ ->
                            var bad = 0
                            for (d in del) if (!d.delete()) bad++
                            if (bad > 0) Toast.makeText(this, getString(R.string.fm_n_failed_fmt, bad, ""), Toast.LENGTH_LONG).show()
                            reload()
                        }
                        .setNegativeButton(android.R.string.cancel, null).show()
                }
            }
            .setNegativeButton(android.R.string.cancel, null).show()
    }

    private fun showHits(hits: List<FmSearch.Hit>) {
        if (hits.isEmpty()) {
            toast(R.string.fm_no_hits)
            return
        }
        val labels = hits.map { it.item.name + "\n" + it.dir }.toTypedArray()
        AlertDialog.Builder(this).setTitle(getString(R.string.fm_search) + " (" + hits.size + ")")
            .setItems(labels) { _, w ->
                val h = hits[w]
                if (h.item.name.startsWith(".") && !showHidden) setHidden(true) // a hidden hit has to be visible to be selected
                path = h.dir
                picked.clear()
                picked.add(h.item.name)
                reload()
            }
            .setNegativeButton(android.R.string.cancel, null).show()
    }

    private fun localOnly(): Boolean {
        val ok = place?.startsWith(Fm.LOCAL) == true
        if (!ok) toast(R.string.fm_local_only)
        return ok
    }

    private fun zipSelected() {
        val f = fs ?: return
        if (!localOnly()) return
        val sel = items.filter { it.name in picked }
        val files = sel.mapNotNull { f.localFile(f.join(path, it.name)) }
        if (files.isEmpty()) return
        val dir = path
        val base = if (sel.size == 1) sel[0].name.substringBeforeLast('.', sel[0].name) else "archive"
        runJob(getString(R.string.fm_zipping), { picked.clear(); reload() }) { setText, cancel ->
            val outName = FmCopy.uniqueName(f, dir, base + ".zip")
            val out = f.localFile(f.join(dir, outName)) ?: throw IOException("not a phone folder")
            ZipTools.zip(files, out, object : FmCopy.Listener {
                private var last = 0L
                override fun progress(done: Long, name: String) {
                    val now = System.nanoTime()
                    if (now - last > 150_000_000L) {
                        last = now
                        setText(name + "\n" + fmtSize(done))
                    }
                }

                override fun cancelled(): Boolean = cancel.get()
            })
        }
    }

    private fun unzipSelected() {
        val f = fs ?: return
        if (!localOnly()) return
        val zips = items.filter {
            val n = it.name.lowercase(Locale.US)
            it.name in picked && !it.dir && ZipTools.canExtract(n)
        }
        if (zips.isEmpty()) {
            toast(R.string.fm_no_zip)
            return
        }
        val dir = path
        runJob(getString(R.string.fm_unzipping), { picked.clear(); reload() }) { setText, cancel ->
            for (z in zips) {
                val file = f.localFile(f.join(dir, z.name)) ?: continue
                val folder = FmCopy.uniqueName(f, dir, z.name.substringBeforeLast('.', z.name))
                val dest = f.localFile(f.join(dir, folder)) ?: continue
                ZipTools.extractAny(file, dest, object : FmCopy.Listener {
                    private var last = 0L
                    override fun progress(done: Long, name: String) {
                        val now = System.nanoTime()
                        if (now - last > 150_000_000L) {
                            last = now
                            setText(name + "\n" + fmtSize(done))
                        }
                    }

                    override fun cancelled(): Boolean = cancel.get()
                })
            }
        }
    }

    // ---- operations -----------------------------------------------------------------------------

    private fun newFolderDialog() {
        val f = fs ?: return
        val dir = path
        val input = EditText(this).apply {
            setSingleLine()
            hint = getString(R.string.fm_name_hint)
        }
        AlertDialog.Builder(this).setTitle(R.string.fm_new_folder).setView(input)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val n = input.text.toString().trim()
                if (n.isNotEmpty() && !n.contains('/')) {
                    runJob(getString(R.string.fm_new_folder), { reload() }) { setText, _ ->
                        setText(n)
                        f.mkdir(f.join(dir, n))
                    }
                }
            }
            .setNegativeButton(android.R.string.cancel, null).show()
    }

    private fun renameDialog() {
        val old = picked.firstOrNull() ?: return
        val f = fs ?: return
        val dir = path
        val input = EditText(this).apply {
            setSingleLine()
            setText(old)
            setSelection(0, old.substringBeforeLast('.', old).length)
        }
        AlertDialog.Builder(this).setTitle(R.string.fm_rename).setView(input)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val n = input.text.toString().trim()
                if (n.isNotEmpty() && n != old && !n.contains('/')) {
                    runJob(getString(R.string.fm_rename), { picked.clear(); reload() }) { setText, _ ->
                        setText(n)
                        f.rename(f.join(dir, old), n)
                    }
                }
            }
            .setNegativeButton(android.R.string.cancel, null).show()
    }

    private fun confirmDelete() {
        val names = picked.toList()
        val f = fs ?: return
        val dir = path
        AlertDialog.Builder(this).setMessage(getString(R.string.fm_delete_fmt, names.size))
            .setPositiveButton(R.string.fm_delete) { _, _ ->
                runJob(getString(R.string.fm_deleting), { picked.clear(); reload() }) { setText, cancel ->
                    var errors = 0
                    var first: String? = null
                    for (n in names) {
                        if (cancel.get()) break
                        setText(n)
                        try {
                            f.delete(f.join(dir, n))
                        } catch (e: Exception) {
                            errors++
                            if (first == null) first = e.message ?: e.javaClass.simpleName
                        }
                    }
                    if (errors > 0) throw IOException(getString(R.string.fm_n_failed_fmt, errors, first ?: ""))
                }
            }
            .setNegativeButton(android.R.string.cancel, null).show()
    }

    private fun setClip(move: Boolean) {
        val p = place ?: return
        val f = fs ?: return
        val sel = items.filter { it.name in picked }
        if (sel.isEmpty()) return
        clip = Clip(p, sel.map { Triple(f.join(path, it.name), it.dir, it.size) }, move)
        picked.clear()
        rebuild()
    }

    private fun paste() {
        val c = clip ?: return
        val dstFs = fs ?: return
        val dstPlace = place ?: return
        val dstDir = path
        val existing = items.map { it.name }.toSet()
        if (c.items.none { FmCopy.baseName(it.first) in existing }) {
            runPaste(c, dstFs, dstPlace, dstDir, FmCopy.RENAME)
            return
        }
        AlertDialog.Builder(this).setMessage(R.string.fm_clash)
            .setPositiveButton(R.string.fm_keep_both) { _, _ -> runPaste(c, dstFs, dstPlace, dstDir, FmCopy.RENAME) }
            .setNeutralButton(R.string.fm_replace) { _, _ -> runPaste(c, dstFs, dstPlace, dstDir, FmCopy.OVERWRITE) }
            .setNegativeButton(R.string.fm_skip) { _, _ -> runPaste(c, dstFs, dstPlace, dstDir, FmCopy.SKIP) }
            .show()
    }

    private fun runPaste(c: Clip, dstFs: FmFs, dstPlace: String, dstDir: String, policy: Int) {
        runJob(getString(if (c.move) R.string.fm_moving else R.string.fm_copying), { if (c.move) clip = null; reload() }) { setText, cancel ->
            var srcFs: FmFs? = null
            var own = false
            try {
                val sfs: FmFs = if (c.place == dstPlace) dstFs else Fm.open(this, c.place).also { srcFs = it; own = true }
                setText(getString(R.string.fm_counting))
                var total = 0L
                for (t in c.items) total += FmCopy.totalSize(sfs, t.first, t.second, t.third)
                val grandTotal = total
                val listener = object : FmCopy.Listener {
                    private var last = 0L
                    override fun progress(done: Long, name: String) {
                        val now = System.nanoTime()
                        if (now - last > 150_000_000L) {
                            last = now
                            setText(name + "\n" + sizeText(done, grandTotal))
                        }
                    }

                    override fun cancelled(): Boolean = cancel.get()
                }
                val job = FmCopy(listener, policy)
                var errors = 0
                var first: String? = null
                for (t in c.items) {
                    try {
                        if (c.move) job.move(sfs, t.first, t.second, t.third, dstFs, dstDir)
                        else job.copy(sfs, t.first, t.second, t.third, dstFs, dstDir)
                    } catch (e: FmCopy.Cancelled) {
                        throw e
                    } catch (e: Exception) {
                        errors++
                        if (first == null) first = e.message ?: e.javaClass.simpleName
                    }
                }
                if (errors > 0) throw IOException(getString(R.string.fm_n_failed_fmt, errors, first ?: ""))
            } finally {
                if (own) Thread { runCatching { srcFs?.close() } }.start()
            }
        }
    }

    private fun shareSelected() {
        val f = fs ?: return
        val files = items.filter { it.name in picked && !it.dir }.mapNotNull { f.localFile(f.join(path, it.name)) }
        if (files.isEmpty()) {
            toast(R.string.fm_share_local_only)
            return
        }
        Share.share(this, files.map { uriOf(it) })
    }

    private fun showProps() {
        val f = fs ?: return
        val sel = items.filter { it.name in picked }
        if (sel.isEmpty()) return
        val sb = StringBuilder()
        if (sel.size == 1) {
            val e = sel[0]
            sb.append(getString(R.string.fm_p_name)).append(": ").append(e.name).append('\n')
            sb.append(getString(R.string.fm_p_path)).append(": ").append(f.join(path, e.name)).append('\n')
            if (!e.dir && e.size >= 0) sb.append(getString(R.string.fm_p_size)).append(": ").append(fmtSize(e.size)).append('\n')
            if (e.modified > 0) sb.append(getString(R.string.fm_p_modified)).append(": ")
                .append(DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM).format(Date(e.modified))).append('\n')
        } else {
            sb.append(getString(R.string.fm_p_items)).append(": ").append(sel.size).append('\n')
        }
        val free = f.freeSpace()
        if (free >= 0) sb.append(getString(R.string.fm_free_fmt, fmtSize(free))).append('\n')
        val base = sb.toString()
        val dlg = AlertDialog.Builder(this).setTitle(R.string.fm_props).setMessage(base + getString(R.string.fm_counting))
            .setPositiveButton(android.R.string.ok, null).show()
        val dir = path
        Thread {
            var total = 0L
            for (e in sel) total += FmCopy.totalSize(f, f.join(dir, e.name), e.dir, e.size)
            val t = total
            val sizeLine = base + getString(R.string.fm_p_size) + ": " + fmtSize(t)
            ui.post { if (!isDestroyed && dlg.isShowing) dlg.setMessage(sizeLine) }
            // one file on the phone: its SHA-256 as well (to compare a download with the original)
            val one = if (sel.size == 1 && !sel[0].dir) f.localFile(f.join(dir, sel[0].name)) else null
            if (one != null && one.isFile) {
                ui.post { if (!isDestroyed && dlg.isShowing) dlg.setMessage(sizeLine + "\nSHA-256: …") }
                val h = FmDupes.sha256(one) { isDestroyed || !dlg.isShowing }
                if (h != null) ui.post { if (!isDestroyed && dlg.isShowing) dlg.setMessage(sizeLine + "\nSHA-256:\n" + h) }
            }
        }.start()
    }

    // ---- opening files --------------------------------------------------------------------------

    private fun uriOf(f: File): Uri = FmProvider.uriOf(this, f)

    private fun openFile(e: FmItem) {
        val f = fs ?: return
        val full = f.join(path, e.name)
        val local = f.localFile(full)
        if (local != null) {
            openLocalFile(local, e, true)
            return
        }
        val pl = place ?: return
        if (pl.startsWith(Fm.NET)) {
            val s = Net.server(this, pl.substring(Fm.NET.length))
            if (s != null && (Net.isVideo(e.name) || Net.isImage(e.name) || Net.isAudio(e.name) || Net.isManga(e.name))) {
                openNetFile(s, e)
                return
            }
        }
        // cloud (or a network file the players cannot stream): download first, then open the copy
        download(f, full, e.name, e.size) { file -> openLocalFile(file, e, false) }
    }

    private fun openLocalFile(file: File, e: FmItem, inFolder: Boolean) {
        val name = e.name
        val f = fs
        val dir = path
        fun siblings(same: (String) -> Boolean): List<FmItem> =
            if (inFolder) shown.filter { !it.dir && same(it.name) } else listOf(e)
        fun fileOf(x: FmItem): File = if (inFolder && f != null) (f.localFile(f.join(dir, x.name)) ?: file) else file
        when {
            Net.isVideo(name) || Net.isImage(name) -> {
                val isVid = Net.isVideo(name)
                val sib = siblings { n -> if (isVid) Net.isVideo(n) else Net.isImage(n) }
                val uris = sib.map { uriOf(fileOf(it)) }
                val idx = sib.indexOfFirst { it.name == name }.coerceAtLeast(0)
                val i = Intent(this, PlayerActivity::class.java).setData(uris[idx]).putExtra(PlayerArgs.FROM_LIB, true)
                if (uris.size > 1) {
                    i.putExtra(PlayerArgs.INDEX, idx)
                    i.putStringArrayListExtra(PlayerArgs.LIST, ArrayList(uris.map { it.toString() }))
                }
                startActivity(i)
            }
            Net.isGif(name) -> startActivity(Intent(this, GifActivity::class.java).setData(Uri.fromFile(file)))
            Net.isAudio(name) -> {
                val sib = siblings { n -> Net.isAudio(n) }
                val tracks = sib.map { MusicPlayer.Track(uriOf(fileOf(it)), it.name.substringBeforeLast('.'), placeTitle, 0L) }
                val idx = sib.indexOfFirst { it.name == name }.coerceAtLeast(0)
                if (tracks.isNotEmpty()) {
                    MusicPlayer.handoff = tracks
                    MusicPlayer.play(this, tracks, idx)
                    startActivity(Intent(this, AudioActivity::class.java))
                }
            }
            Net.isManga(name) -> startActivity(
                Intent(this, MangaActivity::class.java).setData(Uri.fromFile(file)).putExtra(MangaActivity.EXTRA_NAME, name.substringBeforeLast('.'))
            )
            else -> {
                val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase(Locale.US)) ?: "*/*"
                val i = Intent(Intent.ACTION_VIEW).setDataAndType(uriOf(file), mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                try {
                    startActivity(Intent.createChooser(i, name))
                } catch (ex: Exception) {
                    toast(R.string.net_unsupported)
                }
            }
        }
    }

    /** A file on an SMB / FTP server: videos, photos, music and comics stream straight from the server, like in the network screen. */
    private fun openNetFile(s: Net.Server, e: FmItem) {
        val name = e.name
        fun uri(x: FmItem) = Net.uriOf(s, Net.join(path, x.name))
        when {
            Net.isVideo(name) || Net.isImage(name) -> {
                val sib = shown.filter { !it.dir && (if (Net.isVideo(name)) Net.isVideo(it.name) else Net.isImage(it.name)) }
                val uris = sib.map { uri(it) }
                val idx = sib.indexOfFirst { it.name == name }.coerceAtLeast(0)
                val i = Intent(this, PlayerActivity::class.java).setData(uris[idx]).putExtra(PlayerArgs.FROM_LIB, true)
                if (uris.size > 1) {
                    i.putExtra(PlayerArgs.INDEX, idx)
                    i.putStringArrayListExtra(PlayerArgs.LIST, ArrayList(uris.map { it.toString() }))
                }
                startActivity(i)
            }
            Net.isAudio(name) -> {
                val sib = shown.filter { !it.dir && Net.isAudio(it.name) }
                val tracks = sib.map { MusicPlayer.Track(uri(it), it.name.substringBeforeLast('.'), s.name, 0L) }
                val idx = sib.indexOfFirst { it.name == name }.coerceAtLeast(0)
                if (tracks.isNotEmpty()) {
                    MusicPlayer.handoff = tracks
                    MusicPlayer.play(this, tracks, idx)
                    startActivity(Intent(this, AudioActivity::class.java))
                }
            }
            Net.isManga(name) -> startActivity(
                Intent(this, MangaActivity::class.java).setData(uri(e)).putExtra(MangaActivity.EXTRA_NAME, name.substringBeforeLast('.'))
            )
        }
    }

    private fun download(f: FmFs, remote: String, name: String, size: Long, then: (File) -> Unit) {
        val holder = arrayOfNulls<File>(1)
        runJob(getString(R.string.fm_downloading), { holder[0]?.let(then) }) { setText, cancel ->
            val out = File(Fm.tmpDir(this), Integer.toHexString(remote.hashCode()) + "_" + name.replace('/', '_'))
            var ok = false
            try {
                f.open(remote).use { ins ->
                    out.outputStream().use { o ->
                        val buf = ByteArray(64 * 1024)
                        var done = 0L
                        var last = 0L
                        while (true) {
                            val n = ins.read(buf)
                            if (n <= 0) break
                            if (cancel.get()) throw IOException("cancelled")
                            o.write(buf, 0, n)
                            done += n
                            val now = System.nanoTime()
                            if (now - last > 150_000_000L) {
                                last = now
                                setText(sizeText(done, size))
                            }
                        }
                    }
                }
                ok = true
                holder[0] = out
            } finally {
                if (!ok) out.delete()
            }
        }
    }

    // ---- jobs and formatting --------------------------------------------------------------------

    /**
     * Runs [work] on a background thread under a small dialog with a cancel button. [done] runs on the main thread afterwards
     * (also after an error or a cancel, so the list is refreshed); an error is then shown.
     */
    private fun runJob(title: String, done: () -> Unit, work: (setText: (String) -> Unit, cancel: AtomicBoolean) -> Unit) {
        val cancel = AtomicBoolean(false)
        val tv = Ui.text(this, "…", 14f, Ui.TEXT).apply { setPadding(dp(this@FilesActivity, 22), dp(this@FilesActivity, 8), dp(this@FilesActivity, 22), 0) }
        val dlg = AlertDialog.Builder(this)
            .setTitle(title)
            .setView(tv)
            .setCancelable(false)
            .setNegativeButton(android.R.string.cancel) { _, _ -> cancel.set(true) }
            .create()
        dlg.show()
        Thread {
            var err: String? = null
            try {
                work({ t -> ui.post { tv.text = t } }, cancel)
            } catch (t: Throwable) {
                err = if (cancel.get()) null else ((t.cause ?: t).message ?: t.javaClass.simpleName)
            }
            ui.post {
                if (!isDestroyed) runCatching { dlg.dismiss() }
                if (!isDestroyed) done()
                if (err != null && !isDestroyed) {
                    AlertDialog.Builder(this).setMessage(getString(R.string.fm_error_fmt, err)).setPositiveButton(android.R.string.ok, null).show()
                }
            }
        }.start()
    }

    private fun sizeText(done: Long, total: Long): String =
        if (total > 0) "${fmtSize(done)} / ${fmtSize(total)}  (${(done * 100 / total).toInt()}%)" else fmtSize(done)

    private fun fmtSize(b: Long): String = when {
        b < 0 -> ""
        b < 1024 -> "$b B"
        b < 1024L * 1024 -> String.format(Locale.US, "%.1f KB", b / 1024.0)
        b < 1024L * 1024 * 1024 -> String.format(Locale.US, "%.1f MB", b / (1024.0 * 1024))
        else -> String.format(Locale.US, "%.2f GB", b / (1024.0 * 1024 * 1024))
    }
}
