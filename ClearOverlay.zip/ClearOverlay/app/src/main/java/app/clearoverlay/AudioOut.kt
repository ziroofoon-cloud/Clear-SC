package app.clearoverlay

import android.app.AlertDialog
import android.content.Context
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import androidx.media3.exoplayer.ExoPlayer

/**
 * Choice of the sound output for the music player and the video player: "Auto" (the phone decides, as always), the phone's own speaker,
 * wired / USB headphones, a Bluetooth headset or speaker... The choice is saved (type + name of the device) and is given to the player
 * as its preferred audio device; when that device is not connected the player simply uses the phone's normal output.
 */
object AudioOut {
    private const val KEY = "audio_out"

    private val TYPES = intArrayOf(
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER, AudioDeviceInfo.TYPE_BUILTIN_EARPIECE,
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET,
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLE_HEADSET, AudioDeviceInfo.TYPE_BLE_SPEAKER,
        AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_HEARING_AID
    )

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("crsc", Context.MODE_PRIVATE)

    /** The outputs the phone has right now. */
    fun devices(ctx: Context): List<AudioDeviceInfo> =
        runCatching {
            (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager).getDevices(AudioManager.GET_DEVICES_OUTPUTS).filter { it.type in TYPES }
        }.getOrDefault(emptyList())

    private fun key(d: AudioDeviceInfo) = d.type.toString() + ":" + (d.productName?.toString() ?: "")

    fun label(ctx: Context, d: AudioDeviceInfo): String {
        val name = d.productName?.toString()?.takeIf { it.isNotBlank() }
        return when (d.type) {
            AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> ctx.getString(R.string.aout_speaker)
            AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> ctx.getString(R.string.aout_earpiece)
            AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET -> ctx.getString(R.string.aout_wired)
            AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_USB_DEVICE -> ctx.getString(R.string.aout_usb) + (if (name != null) " · $name" else "")
            AudioDeviceInfo.TYPE_HEARING_AID -> ctx.getString(R.string.aout_hearing)
            else -> ctx.getString(R.string.aout_bt) + (if (name != null) " · $name" else "")
        }
    }

    /** The saved device if it is connected now, else null (= let the phone decide). */
    fun chosen(ctx: Context): AudioDeviceInfo? {
        val k = prefs(ctx).getString(KEY, "") ?: ""
        if (k.isEmpty()) return null
        return devices(ctx).firstOrNull { key(it) == k }
    }

    fun apply(ctx: Context, p: ExoPlayer?) {
        if (p == null) return
        runCatching { p.setPreferredAudioDevice(chosen(ctx)) }
    }

    /** Text for a menu line: where the sound goes now. */
    fun current(ctx: Context): String = chosen(ctx)?.let { label(ctx, it) } ?: ctx.getString(R.string.aout_auto)

    private var watching = false

    /** Re-gives the saved choice when a device is connected (e.g. the earbuds come back), to the music player and to [extra] (the video player). */
    fun watch(ctx: Context) {
        if (watching) return
        watching = true
        val app = ctx.applicationContext
        runCatching {
            (app.getSystemService(Context.AUDIO_SERVICE) as AudioManager).registerAudioDeviceCallback(object : AudioDeviceCallback() {
                override fun onAudioDevicesAdded(added: Array<out AudioDeviceInfo>) { apply(app, MusicPlayer.player) }
                override fun onAudioDevicesRemoved(removed: Array<out AudioDeviceInfo>) { apply(app, MusicPlayer.player) }
            }, Handler(Looper.getMainLooper()))
        }
    }

    /** The "Sound output" list. [onChosen] gets the player(s) to refresh: the music player is always updated here. */
    fun show(ctx: Context, videoPlayer: ExoPlayer? = null, onChosen: () -> Unit = {}) {
        val list = devices(ctx)
        val saved = prefs(ctx).getString(KEY, "") ?: ""
        val labels = ArrayList<String>()
        labels.add(ctx.getString(R.string.aout_auto) + if (saved.isEmpty()) "  ✓" else "")
        for (d in list) labels.add(label(ctx, d) + if (key(d) == saved) "  ✓" else "")
        AlertDialog.Builder(ctx)
            .setTitle(R.string.aout_title)
            .setItems(labels.toTypedArray()) { _, i ->
                prefs(ctx).edit().putString(KEY, if (i == 0) "" else key(list[i - 1])).apply()
                apply(ctx, MusicPlayer.player)
                apply(ctx, videoPlayer)
                onChosen()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }
}
