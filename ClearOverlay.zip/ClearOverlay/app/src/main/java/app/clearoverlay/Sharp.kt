package app.clearoverlay

import android.content.Context

/**
 * The sharpness options (`uGain`, the strength of the part the network learned) of the three AI upscalers: one list per upscaler, each with its OWN
 * value (nothing is shared between AI 2x, AI 3x and Nova 3x: separate saved values, separate chips).
 *
 * What the number means in the shader:
 *  - AI 3x, levels Balanced ... Ultra: two trained heads, `result = A + gain * B`. 0 gives the soft head, 1.0 the sharp head (both TRAINED), so Soft 0.6 and
 *    Normal 1.0 are inside what the network learned; above 1.0 the app goes past the trained range (extrapolation).
 *  - AI 3x Light, AI 2x and Nova 3x: one head, `result = gain * A`. Only 1.0 is "as trained" (Nova: with the sharpness 3.5 trained in); every other number is
 *    the app multiplying what the network learned.
 * The chips say it: "● Normal 1.0" / "● Soft 0.6" come from the network, "×1.6" is the app's multiplier (also "×0.5": weaker).
 */
object Sharp {
    const val AI2X = 0
    const val AI3X = 1
    const val NOVA = 2
    const val NEURAL = 3 // the "Neural" upscaler (one head, like AI 2x): its chips are the AI 2x ones
    const val MAX = 10f

    private val V2 = floatArrayOf(0.3f, 0.5f, 0.7f, 1.0f, 1.3f, 1.6f, 2.4f, 3.5f, 5.0f, 7.0f, 10.0f)
    private val V3 = floatArrayOf(0.6f, 0.8f, 1.0f, 1.3f, 1.6f, 2.0f, 2.4f, 3.5f, 5.0f, 7.0f, 10.0f)
    private val VN = floatArrayOf(0.3f, 0.5f, 0.7f, 1.0f, 1.3f, 1.6f, 2.0f, 2.4f, 3.5f, 5.0f, 7.0f, 10.0f)

    fun values(kind: Int): FloatArray = when (kind) { AI3X -> V3; NOVA -> VN; else -> V2 }

    /** AI 3x levels above Light have two trained heads (so values up to 1.0 are the network's own). */
    fun twoHead(kind: Int, ai3Tier: Int): Boolean = kind == AI3X && ai3Tier != 0

    /** True when this value is something the network itself learned (not the app's multiplier). */
    fun own(kind: Int, v: Float, ai3Tier: Int): Boolean = v == 1.0f || (twoHead(kind, ai3Tier) && v < 1.0f)

    fun label(ctx: Context, kind: Int, v: Float, ai3Tier: Int): String {
        val num = String.format(java.util.Locale.US, "%.1f", v)
        if (!own(kind, v, ai3Tier)) return "×$num"
        return "● " + ctx.getString(if (v == 1.0f) R.string.sr_gain_normal else R.string.ai3_gain_soft) + " " + num
    }

    fun labels(ctx: Context, kind: Int, ai3Tier: Int = 1): List<String> = values(kind).map { label(ctx, kind, it, ai3Tier) }

    /** The chip that is closest to [v] (a value saved by an older version, like 1.5, shows as the nearest chip). */
    fun nearest(kind: Int, v: Float): Int {
        val a = values(kind)
        var best = 0
        for (i in a.indices) if (Math.abs(a[i] - v) < Math.abs(a[best] - v)) best = i
        return best
    }
}
