package app.clearoverlay

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Movie
import android.graphics.Paint
import android.graphics.Rect
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.provider.MediaStore
import java.io.ByteArrayInputStream
import java.io.IOException
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** What the GIF upscale screen chose. */
class GifOpts(
    val target: Int = 1080,
    val tier: Int = 1,
    val anime: Boolean = false,
    val mode: Int = Cfg.MODE_FSR,
    /** -1 = the quality tier decides, otherwise 0..1. */
    val sharp: Float = -1f,
    val vivid: Float = 0f
)

/** What a GIF is: size and length. */
class GifInfo(val w: Int, val h: Int, val durMs: Int) {
    val frames get() = (durMs / GifExport.STEP_MS).coerceIn(1, GifExport.MAX_FRAMES)
}

/**
 * Upscales a GIF: every picture of the animation goes through the same GPU effects as video frames and is written
 * into an MP4 video (smaller and smoother than a big GIF; sound is not involved). A GIF is read with the system's
 * own GIF player (android.graphics.Movie) at 25 pictures per second; identical neighbours are only processed once.
 */
object GifExport {
    const val STEP_MS = 40 // 25 pictures per second
    const val MAX_FRAMES = 2500

    fun looksLikeGif(ctx: Context, u: Uri, name: String): Boolean {
        if (name.lowercase().endsWith(".gif")) return true
        if ((u.lastPathSegment ?: "").lowercase().endsWith(".gif")) return true
        return runCatching { ctx.contentResolver.getType(u) }.getOrNull() == "image/gif"
    }

    private fun readBytes(ctx: Context, u: Uri): ByteArray {
        val ins = if (u.scheme == Net.SCHEME) Net.openStream(ctx, u) else ctx.contentResolver.openInputStream(u)
        return (ins ?: throw IOException("cannot open the file")).use { it.readBytes() }
    }

    @Suppress("DEPRECATION")
    private fun movie(bytes: ByteArray): Movie? = Movie.decodeStream(ByteArrayInputStream(bytes))

    /** Size and length of the GIF, or null when it is not an animated GIF. Worker thread. */
    @Suppress("DEPRECATION")
    fun probe(ctx: Context, u: Uri): GifInfo? = runCatching {
        val m = movie(readBytes(ctx, u)) ?: return null
        if (m.duration() <= 0 || m.width() <= 0 || m.height() <= 0) return null
        GifInfo(m.width(), m.height(), m.duration())
    }.getOrNull()

    fun outSize(i: GifInfo, target: Int): Pair<Int, Int> {
        val k = target.toFloat() / min(i.w, i.h)
        val ow = (((i.w * k).roundToInt() + 1) / 2 * 2).coerceIn(64, 4096)
        val oh = (((i.h * k).roundToInt() + 1) / 2 * 2).coerceIn(64, 4096)
        return Pair(ow, oh)
    }

    fun sizeBytes(i: GifInfo, o: GifOpts): Long {
        val (ow, oh) = outSize(i, o.target)
        return VideoExport.bitrate(ow, oh, 25f, o.tier).toLong() * (i.durMs / 1000L).coerceAtLeast(1L) / 8
    }

    fun estimateSec(ctx: Context, i: GifInfo, o: GifOpts): Long {
        val (ow, oh) = outSize(i, o.target)
        val mpx = ExportInfo.measuredMpx(ctx).let { if (it > 0f) it else 50f }
        return (i.frames.toDouble() * (ow.toDouble() * oh / 1e6) * ExportInfo.COST[o.tier.coerceIn(0, 2)] / mpx).toLong() + 2
    }

    /**
     * Runs the whole job on the calling (worker) thread and returns the Uri of the MP4 in Movies/ClearOverlay.
     * [onProgress] gets (picture, total). Throws when cancelled or when something fails.
     */
    @Suppress("DEPRECATION")
    fun run(ctx: Context, u: Uri, name: String, o: GifOpts, cancel: AtomicBoolean, onProgress: (Int, Int) -> Unit): Uri {
        val mv = movie(readBytes(ctx, u)) ?: throw IOException("this is not an animated GIF")
        val w = mv.width()
        val h = mv.height()
        val dur = mv.duration()
        if (dur <= 0 || w <= 0 || h <= 0) throw IOException("this GIF has only one picture; use the photo tools for it")
        val info = GifInfo(w, h, dur)
        val (ow, oh) = outSize(info, o.target)
        val total = info.frames
        val stepMs = if (dur / STEP_MS > MAX_FRAMES) dur.toFloat() / MAX_FRAMES else STEP_MS.toFloat()
        val frameUs = 40_000L
        val fps = 25
        val fx = VideoExport.fxFor(o.tier, o.anime, o.mode, o.sharp, o.vivid)

        val res = ctx.contentResolver
        val base = name.substringBeforeLast('.').replace(Regex("[\\\\/:*?\"<>|]"), "_").ifEmpty { "gif" }
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, base + "_" + o.target + "p.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ClearOverlay")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val out = res.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: throw IOException("cannot create the output file")

        val fxr = MangaFx()
        var enc: MediaCodec? = null
        var mux: MediaMuxer? = null
        var ok = false
        try {
            res.openFileDescriptor(out, "rw")!!.use { pfd ->
                val mime = MediaFormat.MIMETYPE_VIDEO_AVC
                val fmt = MediaFormat.createVideoFormat(mime, ow, oh).apply {
                    setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                    setInteger(MediaFormat.KEY_BIT_RATE, VideoExport.bitrate(ow, oh, fps.toFloat(), o.tier))
                    setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                    setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
                }
                val e = MediaCodec.createEncoderByType(mime)
                enc = e
                e.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                val surface = e.createInputSurface()
                e.start()
                val m = MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                mux = m
                var track = -1
                var written = 0L
                val bi = MediaCodec.BufferInfo()

                fun drain(end: Boolean) {
                    while (true) {
                        val i = e.dequeueOutputBuffer(bi, if (end) 10_000 else 0)
                        when {
                            i == MediaCodec.INFO_TRY_AGAIN_LATER -> if (!end) return
                            i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                                track = m.addTrack(e.outputFormat)
                                m.start()
                            }
                            i >= 0 -> {
                                val buf = e.getOutputBuffer(i)
                                val cfg = (bi.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0
                                if (buf != null && bi.size > 0 && !cfg && track >= 0) {
                                    buf.position(bi.offset)
                                    buf.limit(bi.offset + bi.size)
                                    // the clock of a canvas surface is the wall clock: use the picture number instead
                                    bi.presentationTimeUs = written++ * frameUs
                                    m.writeSampleData(track, buf, bi)
                                }
                                e.releaseOutputBuffer(i, false)
                                if ((bi.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                            }
                        }
                    }
                }

                var cur = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                var prev: Bitmap? = null
                var prevOut: Bitmap? = null
                val paint = Paint(Paint.FILTER_BITMAP_FLAG)
                for (n in 0 until total) {
                    if (cancel.get()) throw IOException("cancelled")
                    val t = min((n * stepMs).toInt(), dur - 1)
                    val cv = Canvas(cur)
                    cv.drawColor(Color.WHITE) // transparent parts of a GIF become white
                    mv.setTime(t)
                    mv.draw(cv, 0f, 0f)
                    val same = prev != null && prevOut != null && prev.sameAs(cur)
                    val img: Bitmap = if (same) prevOut!! else {
                        val r = fxr.processWith(cur, fx, ow, oh) ?: throw IOException("the GPU effects could not start on this phone")
                        prevOut?.recycle()
                        prevOut = r
                        // keep this picture as the one to compare the next with
                        val keep = prev ?: Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        Canvas(keep).drawBitmap(cur, 0f, 0f, null)
                        prev = keep
                        r
                    }
                    val c = surface.lockCanvas(null)
                    try {
                        c.drawBitmap(img, null, Rect(0, 0, c.width, c.height), paint)
                    } finally {
                        surface.unlockCanvasAndPost(c)
                    }
                    drain(false)
                    onProgress(n + 1, total)
                }
                runCatching { cur.recycle() }
                runCatching { prev?.recycle() }
                runCatching { prevOut?.recycle() }
                e.signalEndOfInputStream()
                drain(true)
                if (track < 0 || written == 0L) throw IOException("nothing was written")
                m.stop()
                ok = true
            }
        } finally {
            runCatching { fxr.release() }
            runCatching { enc?.stop() }
            runCatching { enc?.release() }
            runCatching { mux?.release() }
            if (ok) {
                res.update(out, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
            } else {
                runCatching { res.delete(out, null, null) }
            }
        }
        return out
    }
}
