package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.widget.Toast

/**
 * Copy or move a model file out of the app (to any folder the user picks). Models are kept in the app's private
 * storage; "copy" leaves the model in the app, "move" removes it from the app after the copy succeeded.
 */
object ModelFiles {
    const val REQ = 4711
    private var pendingId: String? = null
    private var pendingMove = false

    /** Step 1: which model, step 2: copy or move, step 3: the system "save as" screen. */
    fun start(act: Activity) {
        val list = AiSr.list(act)
        if (list.isEmpty()) return
        AlertDialog.Builder(act)
            .setTitle(act.getString(R.string.model_export_pick))
            .setItems(list.map { it.label }.toTypedArray()) { _, which ->
                val m = list[which]
                if (m.builtin) launch(act, m.id, false) else {
                    AlertDialog.Builder(act)
                        .setTitle(m.label)
                        .setItems(arrayOf(act.getString(R.string.model_copy), act.getString(R.string.model_move))) { _, w ->
                            launch(act, m.id, w == 1)
                        }
                        .setNegativeButton(android.R.string.cancel, null)
                        .show()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun launch(act: Activity, id: String, move: Boolean) {
        pendingId = id
        pendingMove = move
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("application/octet-stream")
            .putExtra(Intent.EXTRA_TITLE, "$id.tflite")
        @Suppress("DEPRECATION")
        act.startActivityForResult(i, REQ)
    }

    /** Call from onActivityResult; returns true when the result was ours. */
    fun handle(act: Activity, req: Int, res: Int, data: Intent?): Boolean {
        if (req != REQ) return false
        val id = pendingId
        val u = data?.data
        pendingId = null
        if (res != Activity.RESULT_OK || u == null || id == null) return true
        val move = pendingMove
        val app = act.applicationContext
        Thread {
            val err = runCatching { AiSr.exportTo(app, id, u) }.exceptionOrNull()
            if (err == null && move) AiSr.remove(app, id)
            act.runOnUiThread {
                val msg = if (err != null) act.getString(R.string.ai_error_fmt, err.message ?: "?")
                else act.getString(if (move) R.string.model_moved_fmt else R.string.model_exported_fmt, id)
                Toast.makeText(act, msg, Toast.LENGTH_LONG).show()
            }
        }.start()
        return true
    }
}
