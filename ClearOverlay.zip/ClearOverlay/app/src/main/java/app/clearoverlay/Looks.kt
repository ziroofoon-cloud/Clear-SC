package app.clearoverlay

/**
 * "Looks": ready colour moods for the picture (cinematic, artistic, cheerful, horror ...). A look only sets the colour / tone settings
 * (brightness, contrast, saturation, vibrance, warmth, tint, shadows, highlights, vivid colours, film grain, clarity); the upscaler and the
 * sharpening are not touched. [apply] scales every value with the look's strength (0..1), so a look can be used lightly.
 */
object Looks {
    class L(
        val name: Int,
        val bright: Float = 0f, val contrast: Float = 0f, val sat: Float = 0f, val vib: Float = 0f,
        val warm: Float = 0f, val tint: Float = 0f, val shadows: Float = 0f, val highlights: Float = 0f,
        val vivid: Float = 0f, val grain: Float = 0f, val clarity: Float = 0f
    )

    val ALL = listOf(
        L(R.string.look_cine, bright = -0.02f, contrast = 0.16f, sat = -0.08f, vib = 0.10f, warm = 0.12f, shadows = -0.10f, highlights = -0.12f, grain = 0.08f, clarity = 0.10f),
        L(R.string.look_art, contrast = 0.12f, sat = 0.15f, vib = 0.20f, warm = 0.05f, vivid = 0.10f, grain = 0.05f, clarity = 0.25f),
        L(R.string.look_vivid, bright = 0.05f, contrast = 0.08f, sat = 0.25f, vib = 0.30f, warm = 0.05f, shadows = 0.08f, vivid = 0.25f),
        L(R.string.look_horror, bright = -0.12f, contrast = 0.30f, sat = -0.35f, warm = -0.25f, tint = -0.15f, shadows = -0.30f, highlights = -0.10f, grain = 0.25f, clarity = 0.20f),
        L(R.string.look_warm, bright = 0.03f, sat = 0.10f, warm = 0.35f, tint = 0.05f, highlights = -0.05f),
        L(R.string.look_cool, contrast = 0.08f, sat = -0.05f, warm = -0.30f),
        L(R.string.look_retro, contrast = -0.08f, sat = -0.20f, warm = 0.25f, tint = 0.08f, shadows = 0.15f, highlights = -0.10f, grain = 0.30f),
        L(R.string.look_bw, contrast = 0.15f, sat = -1.0f, grain = 0.10f, clarity = 0.10f),
        L(R.string.look_noir, contrast = 0.40f, sat = -1.0f, shadows = -0.30f, highlights = 0.10f, grain = 0.20f, clarity = 0.20f),
        L(R.string.look_dream, bright = 0.08f, sat = 0.05f, warm = 0.10f, shadows = 0.10f, highlights = 0.10f, vivid = 0.05f, clarity = -0.30f),
        L(R.string.look_night, bright = 0.10f, sat = 0.05f, warm = -0.10f, shadows = 0.30f),
        L(R.string.look_anime, contrast = 0.12f, sat = 0.20f, vib = 0.20f, vivid = 0.15f, clarity = 0.15f),
        L(R.string.look_eye, bright = -0.05f, contrast = -0.05f, sat = -0.10f, warm = 0.40f),
        // games: punchy and clear (lifted shadows so nothing hides in the dark, strong but clean colours, crisp local contrast, no grain)
        L(R.string.look_game, bright = 0.02f, contrast = 0.14f, sat = 0.16f, vib = 0.26f, shadows = 0.16f, highlights = -0.06f, vivid = 0.10f, clarity = 0.30f)
    )

    private fun c1(v: Float) = v.coerceIn(-1f, 1f)

    /** Puts look [i] (strength 0..1) into the colour settings of [Cfg]; -1 = back to no look (all colour settings 0). */
    fun apply(i: Int, strength: Float) {
        val l = if (i in ALL.indices) ALL[i] else null
        val k = if (l == null) 0f else strength.coerceIn(0f, 1f)
        fun v(x: Float?) = (x ?: 0f) * k
        Cfg.brightness = c1(v(l?.bright))
        Cfg.contrast = c1(v(l?.contrast))
        Cfg.saturation = c1(v(l?.sat))
        Cfg.vibrance = c1(v(l?.vib))
        Cfg.warmth = c1(v(l?.warm))
        Cfg.tint = c1(v(l?.tint))
        Cfg.shadows = c1(v(l?.shadows))
        Cfg.highlights = c1(v(l?.highlights))
        Cfg.vivid = v(l?.vivid).coerceIn(0f, 1f)
        Cfg.grain = v(l?.grain).coerceIn(0f, 1f)
        Cfg.clarity = c1(v(l?.clarity))
        Cfg.userProfile = null
    }

    private fun fields(): FloatArray = floatArrayOf(
        Cfg.brightness, Cfg.contrast, Cfg.saturation, Cfg.vibrance, Cfg.warmth, Cfg.tint, Cfg.shadows, Cfg.highlights, Cfg.vivid, Cfg.grain, Cfg.clarity
    )

    /**
     * Which look (and at what strength 5..100) the colour settings are right now, or null when they are no look. Used when the panel is built
     * again (another photo / video, reopened panel) so the chip that is marked is the one that really is on.
     */
    fun detect(): Pair<Int, Int>? {
        if (neutral()) return null
        val cur = fields()
        for (i in ALL.indices) {
            val l = ALL[i]
            val lv = floatArrayOf(l.bright, l.contrast, l.sat, l.vib, l.warm, l.tint, l.shadows, l.highlights, l.vivid, l.grain, l.clarity)
            var big = 0
            for (j in lv.indices) if (Math.abs(lv[j]) > Math.abs(lv[big])) big = j
            if (Math.abs(lv[big]) < 0.01f) continue
            val s = Math.round(cur[big] / lv[big] * 100f).coerceIn(5, 100)
            if (matches(i, s / 100f)) return i to s
        }
        return null
    }

    /** The "Custom" colours (the user's own settings) are kept when a ready look or Off is chosen, and come back with Custom. */
    fun saveCustom(ctx: android.content.Context) {
        Cfg.kindPut(ctx, "lookcustom", fields().joinToString(","))
    }

    fun restoreCustom(ctx: android.content.Context) {
        val a = Cfg.kindGet(ctx, "lookcustom")?.split(',')?.mapNotNull { it.toFloatOrNull() } ?: return
        if (a.size != 11) return
        Cfg.brightness = a[0]; Cfg.contrast = a[1]; Cfg.saturation = a[2]; Cfg.vibrance = a[3]; Cfg.warmth = a[4]; Cfg.tint = a[5]
        Cfg.shadows = a[6]; Cfg.highlights = a[7]; Cfg.vivid = a[8].coerceIn(0f, 1f); Cfg.grain = a[9].coerceIn(0f, 1f); Cfg.clarity = a[10]
        Cfg.userProfile = null
    }

    /** Forgets the saved custom colours (the Reset of Custom). */
    fun clearCustom(ctx: android.content.Context) = Cfg.kindPut(ctx, "lookcustom", null)

    /** "Off" is remembered (all colours 0 looks the same as Custom with nothing set). */
    fun setOff(ctx: android.content.Context, on: Boolean) = Cfg.kindPut(ctx, "looksoff", if (on) "1" else null)

    fun wasOff(ctx: android.content.Context): Boolean = Cfg.kindGet(ctx, "looksoff") == "1"

    /** True when every colour setting is 0 (no look and nothing set by hand). */
    fun neutral(): Boolean {
        fun z(a: Float) = Math.abs(a) < 0.005f
        return z(Cfg.brightness) && z(Cfg.contrast) && z(Cfg.saturation) && z(Cfg.vibrance) && z(Cfg.warmth) && z(Cfg.tint) &&
            z(Cfg.shadows) && z(Cfg.highlights) && z(Cfg.vivid) && z(Cfg.grain) && z(Cfg.clarity)
    }

    /** True when the colour settings are exactly what look [i] at [strength] gives (so a screen that is refreshed keeps the look marked). */
    fun matches(i: Int, strength: Float): Boolean {
        val l = ALL.getOrNull(i) ?: return false
        val k = strength.coerceIn(0f, 1f)
        fun eq(a: Float, b: Float) = Math.abs(a - b * k) < 0.005f
        return eq(Cfg.brightness, l.bright) && eq(Cfg.contrast, l.contrast) && eq(Cfg.saturation, l.sat) && eq(Cfg.vibrance, l.vib) &&
            eq(Cfg.warmth, l.warm) && eq(Cfg.tint, l.tint) && eq(Cfg.shadows, l.shadows) && eq(Cfg.highlights, l.highlights) &&
            eq(Cfg.vivid, l.vivid) && eq(Cfg.grain, l.grain) && eq(Cfg.clarity, l.clarity)
    }
}
