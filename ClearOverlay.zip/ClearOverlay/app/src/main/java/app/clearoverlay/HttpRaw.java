package app.clearoverlay;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

/**
 * A small HTTP/1.1 client over plain sockets. The phone's HttpURLConnection refuses the WebDAV methods (PROPFIND, MKCOL, MOVE...),
 * so cloud storage that speaks WebDAV needs this. One connection per request ("Connection: close"): simple and safe.
 */
final class HttpRaw {
    private HttpRaw() { }

    static final class Resp implements Closeable {
        int code;
        String message = "";
        final Map<String, String> headers = new HashMap<>(); // lower-case names
        InputStream body;
        Socket sock;

        String header(String n) { return headers.get(n.toLowerCase(Locale.US)); }

        byte[] bytes() throws IOException {
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            byte[] b = new byte[8192];
            int n;
            while (body != null && (n = body.read(b)) > 0) o.write(b, 0, n);
            return o.toByteArray();
        }

        String text() throws IOException { return new String(bytes(), StandardCharsets.UTF_8); }

        @Override public void close() {
            try { if (body != null) body.close(); } catch (Exception ignored) { }
            try { if (sock != null) sock.close(); } catch (Exception ignored) { }
        }
    }

    /**
     * Sends one request. [body] may be null; when given exactly [bodyLen] bytes are sent from it. Follows up to 5 redirects
     * when there is no body. The caller closes the response.
     */
    static Resp request(String method, URL url, Map<String, String> headers, InputStream body, long bodyLen, boolean insecure)
            throws IOException {
        URL u = url;
        for (int hop = 0; ; hop++) {
            Resp r = once(method, u, headers, body, bodyLen, insecure);
            boolean redirect = r.code == 301 || r.code == 302 || r.code == 303 || r.code == 307 || r.code == 308;
            String loc = r.header("location");
            if (!redirect || loc == null || body != null || hop >= 5) return r;
            r.close();
            u = new URL(u, loc);
        }
    }

    private static Resp once(String method, URL u, Map<String, String> headers, InputStream body, long bodyLen, boolean insecure)
            throws IOException {
        boolean https = "https".equalsIgnoreCase(u.getProtocol());
        String host = u.getHost();
        int port = u.getPort() > 0 ? u.getPort() : (https ? 443 : 80);
        Socket s = new Socket();
        try {
            s.connect(new InetSocketAddress(host, port), 15000);
            s.setSoTimeout(60000);
            if (https) {
                SSLSocketFactory f = insecure ? trustAll().getSocketFactory() : (SSLSocketFactory) SSLSocketFactory.getDefault();
                SSLSocket ss = (SSLSocket) f.createSocket(s, host, port, true);
                ss.startHandshake();
                if (!insecure) {
                    HostnameVerifier hv = HttpsURLConnection.getDefaultHostnameVerifier();
                    if (!hv.verify(host, ss.getSession())) {
                        ss.close();
                        throw new IOException("certificate does not match " + host);
                    }
                }
                s = ss;
            }
            OutputStream out = new BufferedOutputStream(s.getOutputStream(), 16384);
            String file = u.getFile();
            if (file == null || file.isEmpty()) file = "/";
            StringBuilder h = new StringBuilder();
            h.append(method).append(' ').append(file).append(" HTTP/1.1\r\n");
            boolean defPort = (https && port == 443) || (!https && port == 80);
            h.append("Host: ").append(host).append(defPort ? "" : ":" + port).append("\r\n");
            h.append("User-Agent: ClearOverlay\r\n");
            h.append("Connection: close\r\n");
            if (headers != null) for (Map.Entry<String, String> e : headers.entrySet()) h.append(e.getKey()).append(": ").append(e.getValue()).append("\r\n");
            if (body != null) h.append("Content-Length: ").append(bodyLen).append("\r\n");
            else if (!"GET".equals(method) && !"HEAD".equals(method) && !"DELETE".equals(method)) h.append("Content-Length: 0\r\n");
            h.append("\r\n");
            out.write(h.toString().getBytes(StandardCharsets.UTF_8));
            if (body != null) {
                byte[] buf = new byte[32768];
                long left = bodyLen;
                while (left > 0) {
                    int n = body.read(buf, 0, (int) Math.min(buf.length, left));
                    if (n < 0) throw new IOException("the data ended early");
                    out.write(buf, 0, n);
                    left -= n;
                }
            }
            out.flush();
            return readResponse(method, s);
        } catch (IOException | RuntimeException e) {
            try { s.close(); } catch (Exception ignored) { }
            throw e;
        }
    }

    private static Resp readResponse(String method, Socket s) throws IOException {
        BufferedInputStream in = new BufferedInputStream(s.getInputStream(), 16384);
        Resp r = new Resp();
        r.sock = s;
        while (true) { // skip "100 Continue" style answers
            String line = readLine(in);
            if (line == null) throw new IOException("the server closed the connection");
            String[] p = line.split(" ", 3);
            if (p.length < 2 || !p[0].startsWith("HTTP/")) throw new IOException("not an HTTP answer: " + line);
            try { r.code = Integer.parseInt(p[1].trim()); } catch (NumberFormatException e) { throw new IOException("bad status: " + line); }
            r.message = p.length > 2 ? p[2] : "";
            r.headers.clear();
            String hl;
            while ((hl = readLine(in)) != null && !hl.isEmpty()) {
                int c = hl.indexOf(':');
                if (c > 0) r.headers.put(hl.substring(0, c).trim().toLowerCase(Locale.US), hl.substring(c + 1).trim());
            }
            if (r.code >= 100 && r.code < 200 && r.code != 101) continue;
            break;
        }
        String te = r.header("transfer-encoding");
        String cl = r.header("content-length");
        if ("HEAD".equals(method) || r.code == 204 || r.code == 304) {
            r.body = new ByteArrayInputStreamEmpty();
        } else if (te != null && te.toLowerCase(Locale.US).contains("chunked")) {
            r.body = new Chunked(in);
        } else if (cl != null) {
            long n;
            try { n = Long.parseLong(cl.trim()); } catch (NumberFormatException e) { n = -1; }
            r.body = n >= 0 ? new Limited(in, n) : in;
        } else {
            r.body = in; // until the server closes
        }
        return r;
    }

    private static String readLine(InputStream in) throws IOException {
        ByteArrayOutputStream o = new ByteArrayOutputStream(80);
        int c;
        boolean any = false;
        while ((c = in.read()) >= 0) {
            any = true;
            if (c == '\n') break;
            if (c != '\r') o.write(c);
            if (o.size() > 65536) throw new IOException("header line too long");
        }
        if (!any) return null;
        return new String(o.toByteArray(), StandardCharsets.ISO_8859_1);
    }

    private static final class ByteArrayInputStreamEmpty extends InputStream {
        @Override public int read() { return -1; }
    }

    private static final class Limited extends InputStream {
        private final InputStream in;
        private long left;
        Limited(InputStream in, long n) { this.in = in; this.left = n; }
        @Override public int read() throws IOException {
            if (left <= 0) return -1;
            int c = in.read();
            if (c >= 0) left--;
            return c;
        }
        @Override public int read(byte[] b, int off, int len) throws IOException {
            if (left <= 0) return -1;
            int n = in.read(b, off, (int) Math.min(len, left));
            if (n > 0) left -= n;
            return n;
        }
    }

    private static final class Chunked extends InputStream {
        private final InputStream in;
        private long left = 0;
        private boolean done = false;
        Chunked(InputStream in) { this.in = in; }

        private boolean next() throws IOException {
            if (done) return false;
            String l = readLine(in);
            while (l != null && l.isEmpty()) l = readLine(in); // the CRLF that ends the previous chunk
            if (l == null) { done = true; return false; }
            int semi = l.indexOf(';');
            if (semi >= 0) l = l.substring(0, semi);
            try { left = Long.parseLong(l.trim(), 16); } catch (NumberFormatException e) { throw new IOException("bad chunk size"); }
            if (left == 0) {
                String t;
                while ((t = readLine(in)) != null && !t.isEmpty()) { /* trailers */ }
                done = true;
                return false;
            }
            return true;
        }

        @Override public int read() throws IOException {
            byte[] b = new byte[1];
            int n = read(b, 0, 1);
            return n <= 0 ? -1 : b[0] & 0xFF;
        }

        @Override public int read(byte[] b, int off, int len) throws IOException {
            if (len == 0) return 0;
            if (left == 0 && !next()) return -1;
            int n = in.read(b, off, (int) Math.min(len, left));
            if (n > 0) left -= n;
            else if (n < 0) throw new IOException("the data ended early");
            return n;
        }
    }

    private static SSLContext trustAll() throws IOException {
        try {
            TrustManager[] tm = new TrustManager[]{new X509TrustManager() {
                @Override public void checkClientTrusted(X509Certificate[] c, String a) { }
                @Override public void checkServerTrusted(X509Certificate[] c, String a) { }
                @Override public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
            }};
            SSLContext c = SSLContext.getInstance("TLS");
            c.init(null, tm, new SecureRandom());
            return c;
        } catch (Exception e) {
            throw new IOException(e);
        }
    }
}
