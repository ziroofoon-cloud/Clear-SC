package app.clearoverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import android.provider.MediaStore
import java.io.BufferedOutputStream
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.max
import kotlin.math.sqrt

/** What to enhance and how (set by [BatchActivity] right before the service starts). */
class BatchJob(
    val uris: List<Uri>,          // separate pictures ...
    val src: Uri?,                // ... or one .cbz / .zip / .pdf file
    val name: String,
    val manga: Boolean,
    val quality: Int,             // 0 standard, 1 high, 2 maximum (offline AI model + polish)
    val scaleIdx: Int,            // 0 same, 1 x1.5, 2 x2, 3 x3
    val png: Boolean,
    val asCbz: Boolean
)

/** Progress of the running (or last) batch, shown by [BatchActivity] and the notification. */
object BatchState {
    @Volatile var job: BatchJob? = null
    @Volatile var running = false
    /** True between asking the service to start and its first line of work (so the screen does not read old results). */
    @Volatile var pending = false
    @Volatile var finished = false
    @Volatile var cancelled = false
    @Volatile var done = 0
    @Volatile var failed = 0
    @Volatile var total = 0
    @Volatile var startedAt = 0L
    @Volatile var message: String? = null
    @Volatile var before: Bitmap? = null
    @Volatile var after: Bitmap? = null
    @Volatile var version = 0
}

/**
 * "Enhance to files" runs here, in a foreground service with a progress notification, so it goes on with the screen
 * off or the app closed. Pictures: Pictures/ClearOverlay/Enhanced; manga: one new .cbz in Download/ClearOverlay.
 */
class BatchService : Service() {
    private val cancel = AtomicBoolean(false)
    private var wl: PowerManager.WakeLock? = null

    companion object {
        const val ACT_START = "app.clearoverlay.BATCH_START"
        const val ACT_CANCEL = "app.clearoverlay.BATCH_CANCEL"
        private const val CH = "crsc_batch"
        private const val ID = 78

        fun start(ctx: Context, job: BatchJob) {
            BatchState.job = job
            BatchState.pending = true
            BatchState.finished = false
            ctx.startForegroundService(Intent(ctx, BatchService::class.java).setAction(ACT_START))
        }

        fun cancel(ctx: Context) {
            ctx.startService(Intent(ctx, BatchService::class.java).setAction(ACT_CANCEL))
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun nm() = getSystemService(NotificationManager::class.java)

    private fun notif(title: String, text: String, pct: Int, ongoing: Boolean): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, BatchActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val b = Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .setOngoing(ongoing)
        if (ongoing) {
            b.setProgress(100, pct, pct <= 0)
            val c = PendingIntent.getService(this, 1, Intent(this, BatchService::class.java).setAction(ACT_CANCEL), PendingIntent.FLAG_IMMUTABLE)
            b.addAction(Notification.Action.Builder(null, getString(R.string.export_cancel), c).build())
        }
        return b.build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACT_CANCEL) {
            cancel.set(true)
            return START_NOT_STICKY
        }
        val job = BatchState.job
        if (intent?.action != ACT_START || job == null || BatchState.running) {
            BatchState.pending = false
            if (!BatchState.running) stopSelf()
            return START_NOT_STICKY
        }
        nm().createNotificationChannel(NotificationChannel(CH, getString(R.string.batch_title), NotificationManager.IMPORTANCE_LOW))
        cancel.set(false)
        BatchState.running = true
        BatchState.pending = false
        BatchState.finished = false
        BatchState.cancelled = false
        BatchState.done = 0
        BatchState.failed = 0
        BatchState.total = if (job.src != null) 0 else job.uris.size
        BatchState.startedAt = SystemClock.elapsedRealtime()
        BatchState.message = null
        BatchState.before = null
        BatchState.after = null
        BatchState.version++
        startForeground(ID, notif(getString(R.string.batch_title), job.name, 0, true), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        wl = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "crsc:batch").also { it.acquire(8L * 3600 * 1000) }
        Thread { work(job) }.start()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        runCatching { wl?.release() }
        super.onDestroy()
    }

    // ---- the work ----------------------------------------------------------------------------------

    private fun work(job: BatchJob) {
        val fx = MangaFx()
        var zip: ZipOutputStream? = null
        var zipUri: Uri? = null
        var source: PageSource? = null
        var msg: String
        try {
            val hasAi = AiSr.hasModel(this)
            val q = job.quality
            val k = floatArrayOf(1f, 1.5f, 2f, 3f)[job.scaleIdx]
            val cbz = job.manga && job.asCbz
            val usePng = job.png
            if (job.src != null) {
                source = PageSource.open(this, job.src)
                BatchState.total = source.count
            }
            val total = BatchState.total
            val tier = if (q == 0) 1 else 2
            val main = fxSet(job.manga, tier, q == 3)
            // after the AI model the picture is already big and clean: only a light polish
            val polish = FxSet(Cfg.MODE_SHARP, 0.3f, 0.12f, 0.4f, 0f, 0f, Cfg.AA_OFF, 0.5f)
            if (cbz) {
                val cv = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, "${job.name}_enhanced.cbz")
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/vnd.comicbook+zip")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/ClearOverlay")
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                zipUri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: error("cannot create the file")
                zip = ZipOutputStream(BufferedOutputStream(contentResolver.openOutputStream(zipUri) ?: error("cannot open the file"), 1 shl 16)).apply { setLevel(1) }
            }
            for (idx in 0 until total) {
                if (cancel.get()) break
                val src = if (source != null) source.load(idx) else decode(job.uris[idx])
                if (src == null) {
                    BatchState.failed++
                    continue
                }
                val (ow, oh) = target(src.width, src.height, k)
                var out: Bitmap? = null
                if (q == 2 && hasAi) {
                    val ai = runCatching { AiSr.upscale(this, src, { }, cancel) }.getOrNull()
                    if (ai != null) {
                        out = fx.processWith(ai, polish, ow, oh) ?: ai
                        if (out !== ai) ai.recycle()
                    }
                }
                if (out == null && !cancel.get()) out = fx.processWith(src, main, ow, oh)
                if (out == null) {
                    BatchState.failed++
                    src.recycle()
                    continue
                }
                val ext = if (usePng) "png" else "jpg"
                val fmt = if (usePng) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG
                val quality = if (usePng) 100 else 93
                if (cbz) {
                    val z = zip!!
                    z.putNextEntry(ZipEntry(String.format(java.util.Locale.US, "%04d.%s", idx + 1, ext)))
                    out.compress(fmt, quality, z)
                    z.closeEntry()
                } else {
                    val base = job.name.ifEmpty { "img" } + "_" + String.format(java.util.Locale.US, "%04d", idx + 1)
                    val cv = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, "${base}_enh.$ext")
                        put(MediaStore.MediaColumns.MIME_TYPE, if (usePng) "image/png" else "image/jpeg")
                        put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/ClearOverlay/Enhanced")
                        put(MediaStore.MediaColumns.IS_PENDING, 1)
                    }
                    val ou = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                    if (ou != null) {
                        contentResolver.openOutputStream(ou)?.use { out.compress(fmt, quality, it) }
                        contentResolver.update(ou, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
                    } else BatchState.failed++
                }
                BatchState.done++
                // preview: the result and the original at the same size (hold to see the original)
                val pw = 1200
                val sc = minOf(1f, pw.toFloat() / max(out.width, out.height))
                val aw = max(2, (out.width * sc).toInt())
                val ah = max(2, (out.height * sc).toInt())
                val a = Bitmap.createScaledBitmap(out, aw, ah, true)
                val b = Bitmap.createScaledBitmap(src, aw, ah, true)
                BatchState.before = b
                BatchState.after = a
                BatchState.version++
                val n = idx + 1
                val pct = (n * 100L / total).toInt()
                nm().notify(ID, notif(getString(R.string.batch_title), job.name + "  " + n + "/" + total, pct, true))
                if (out !== src) out.recycle()
                src.recycle()
            }
            zip?.finish()
            zip?.close()
            zip = null
            if (cancel.get()) {
                zipUri?.let { runCatching { contentResolver.delete(it, null, null) } }
            } else {
                zipUri?.let { contentResolver.update(it, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null) }
            }
            msg = when {
                cancel.get() -> getString(R.string.batch_cancelled)
                cbz -> getString(R.string.batch_done_cbz_fmt, BatchState.done, BatchState.failed)
                else -> getString(R.string.batch_done_fmt, BatchState.done, BatchState.failed)
            }
        } catch (t: Throwable) {
            runCatching { zip?.close() }
            zipUri?.let { runCatching { contentResolver.delete(it, null, null) } }
            msg = getString(R.string.batch_failed) + ": " + (t.message ?: t.javaClass.simpleName)
        } finally {
            runCatching { fx.release() }
            runCatching { source?.close() }
        }
        BatchState.cancelled = cancel.get()
        BatchState.message = msg
        BatchState.running = false
        BatchState.finished = true
        BatchState.version++
        runCatching { wl?.release() }
        stopForeground(STOP_FOREGROUND_REMOVE)
        if (!cancel.get()) nm().notify(ID + 1, notif(getString(R.string.batch_title), msg, 100, false))
        stopSelf()
    }

    /** Tier 1 / 2: the Photo or Manga quick profile at "balanced" / "strong" through FSR 1. */
    private fun fxSet(manga: Boolean, tier: Int, lanczos: Boolean = false): FxSet {
        val type = if (manga) Profiles.MANGA else Profiles.PHOTO
        val v = Profiles.withBudget(Profiles.get(type, tier.coerceIn(0, 2), true), tier.coerceIn(0, 2))
        return FxSet(if (lanczos) Cfg.MODE_LANCZOS else Cfg.MODE_FSR, v.sharp, v.detail, v.detailSize, v.denoise, v.deband, v.aa, v.aaStr)
    }

    /** The result size: k x the picture, within what a phone can hold (long side 6000 px, 20 megapixels). */
    private fun target(w: Int, h: Int, k: Float): Pair<Int, Int> {
        var kk = k
        val long = max(w, h) * kk
        if (long > 6000f) kk *= 6000f / long
        val area = w.toDouble() * h * kk * kk
        if (area > 20_000_000.0) kk *= sqrt(20_000_000.0 / area).toFloat()
        return Pair(max(2, (w * kk).toInt()), max(2, (h * kk).toInt()))
    }

    private fun decode(u: Uri): Bitmap? = runCatching {
        ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, u)) { dec, info, _ ->
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val m = max(info.size.width, info.size.height)
            if (m > 4096) {
                val s = 4096f / m
                dec.setTargetSize(max(1, (info.size.width * s).toInt()), max(1, (info.size.height * s).toInt()))
            }
        }
    }.getOrNull()
}
