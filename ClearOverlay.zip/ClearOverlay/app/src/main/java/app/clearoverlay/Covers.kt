package app.clearoverlay

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Outline
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.util.Size
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.ImageView
import java.util.concurrent.Executors

/**
 * Album art for songs: the picture of the song's album (or the picture stored inside the file), loaded in the background
 * and kept in a small memory cache. A song without a picture shows a music-note placeholder in the app's colours.
 */
object Covers {
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val missing = HashSet<String>()
    private val pool = Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())

    private fun key(u: Uri, px: Int) = "$u#$px"

    /** The picture, or null when it is not loaded yet / the song has none. Never blocks. */
    fun cached(u: Uri, px: Int): Bitmap? = cache.get(key(u, px))

    /** Loads the picture in the background; [done] runs on the main thread (with null when there is none). */
    fun load(ctx: Context, u: Uri, px: Int, done: (Bitmap?) -> Unit) {
        val k = key(u, px)
        cache.get(k)?.let { done(it); return }
        if (synchronized(missing) { missing.contains(k) }) { done(null); return }
        val app = ctx.applicationContext
        pool.execute {
            var bmp: Bitmap? = runCatching { app.contentResolver.loadThumbnail(u, Size(px, px), null) }.getOrNull()
            if (bmp == null) {
                // a file from the file picker (not in the media index): read the picture stored inside it
                bmp = runCatching {
                    val r = MediaMetadataRetriever()
                    try {
                        r.setDataSource(app, u)
                        val raw = r.embeddedPicture
                        if (raw == null) null else {
                            val o = BitmapFactory.Options().apply { inSampleSize = 2 }
                            BitmapFactory.decodeByteArray(raw, 0, raw.size, o)
                        }
                    } finally {
                        runCatching { r.release() }
                    }
                }.getOrNull()
            }
            if (bmp != null) cache.put(k, bmp) else synchronized(missing) { missing.add(k) }
            main.post { done(bmp) }
        }
    }

    /** Rounded cover picture view with a placeholder; call [bind] with the song's uri. */
    class CoverView(ctx: Context, private val sizePx: Int, radiusDp: Int) : ImageView(ctx) {
        private var shown: Uri? = null

        init {
            scaleType = ScaleType.CENTER_CROP
            val r = dp(ctx, radiusDp).toFloat()
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, r)
                }
            }
            clipToOutline = true
            placeholder()
        }

        private fun placeholder() {
            scaleType = ScaleType.CENTER_INSIDE
            setBackgroundColor(Ui.CHIP)
            val pad = (sizePx * 0.22f).toInt()
            setPadding(pad, pad, pad, pad)
            setImageDrawable(LineIcon(Icons.MUSIC, Ui.MUTED))
        }

        fun bind(u: Uri?) {
            shown = u
            if (u == null) {
                placeholder()
                return
            }
            val c = Covers.cached(u, sizePx)
            if (c != null) {
                show(c)
                return
            }
            placeholder()
            Covers.load(context, u, sizePx) { b ->
                if (shown == u && b != null) show(b)
            }
        }

        private fun show(b: Bitmap) {
            scaleType = ScaleType.CENTER_CROP
            setPadding(0, 0, 0, 0)
            setBackgroundColor(0)
            setImageBitmap(b)
        }
    }
}
