package app.clearoverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import java.util.concurrent.atomic.AtomicBoolean

/** What [ShrinkService] works on and how far it is (read by [ShrinkActivity], which may be closed and opened again while the work goes on). */
object ShrinkState {
    @Volatile var items: List<Shrink.Item> = emptyList()
    @Volatile var quality = 0
    /** True between asking the service to start and its first line of work. */
    @Volatile var pending = false
    @Volatile var running = false
    /** The work is over and its result has not been shown yet. */
    @Volatile var finished = false
    @Volatile var results: List<Shrink.Result> = emptyList()
    @Volatile var asked = 0
    /** 0..1 of the whole job; never goes back (a second try of one file does not move it back to 0). */
    @Volatile var progress = 0f
    @Volatile var name = ""
    val cancel = AtomicBoolean(false)
}

/**
 * "Free up space" runs here, in a foreground service with a progress notification and a wake lock, so it goes on with the screen off, in another app,
 * or while the screen turns. (Before, the work ran in a thread of the screen: when the screen was closed, turned or the phone paused the app, the work was
 * lost, started again from 0 % or ended without a file or a message.)
 */
class ShrinkService : Service() {
    private var wl: PowerManager.WakeLock? = null

    companion object {
        const val ACT_START = "app.clearoverlay.SHRINK_START"
        const val ACT_CANCEL = "app.clearoverlay.SHRINK_CANCEL"
        private const val CH = "crsc_shrink"
        private const val ID = 80
        private const val ID_DONE = 81

        /** Starts the job; false when the system refused to start the service. */
        fun start(ctx: Context, items: List<Shrink.Item>, quality: Int): Boolean {
            ShrinkState.items = items
            ShrinkState.quality = quality
            ShrinkState.pending = true
            ShrinkState.finished = false
            return try {
                ctx.startForegroundService(Intent(ctx, ShrinkService::class.java).setAction(ACT_START))
                true
            } catch (t: Throwable) {
                ShrinkState.pending = false
                false
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun nm() = getSystemService(NotificationManager::class.java)

    private fun notif(title: String, text: String, pct: Int, ongoing: Boolean): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, ShrinkActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP), PendingIntent.FLAG_IMMUTABLE)
        val b = Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .setOngoing(ongoing)
            .setAutoCancel(!ongoing)
        if (ongoing) {
            b.setProgress(100, pct, pct <= 0)
            val c = PendingIntent.getService(this, 1, Intent(this, ShrinkService::class.java).setAction(ACT_CANCEL), PendingIntent.FLAG_IMMUTABLE)
            b.addAction(Notification.Action.Builder(null, getString(R.string.export_cancel), c).build())
        }
        return b.build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACT_CANCEL) {
            ShrinkState.cancel.set(true)
            return START_NOT_STICKY
        }
        val items = ShrinkState.items
        nm().createNotificationChannel(NotificationChannel(CH, getString(R.string.shrink_title), NotificationManager.IMPORTANCE_LOW))
        if (intent?.action != ACT_START || items.isEmpty() || ShrinkState.running) {
            // started by startForegroundService, the service must call startForeground within seconds even when there is nothing to do (else the system stops the app)
            if (intent?.action == ACT_START) startForeground(ID, notif(getString(R.string.shrink_working), "", 0, true), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            ShrinkState.pending = false
            if (!ShrinkState.running) { runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }; stopSelf() }
            return START_NOT_STICKY
        }
        ShrinkState.cancel.set(false)
        ShrinkState.running = true
        ShrinkState.pending = false
        ShrinkState.finished = false
        ShrinkState.results = emptyList()
        ShrinkState.asked = items.size
        ShrinkState.progress = 0f
        ShrinkState.name = items.first().name
        nm().cancel(ID_DONE)
        startForeground(ID, notif(getString(R.string.shrink_working), ShrinkState.name, 0, true), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        wl = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "crsc:shrink").also { it.acquire(8L * 3600 * 1000) }
        val q = ShrinkState.quality
        Thread { work(items, q) }.start()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        runCatching { wl?.release() }
        super.onDestroy()
    }

    private fun work(sel: List<Shrink.Item>, q: Int) {
        runCatching { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_LESS_FAVORABLE) } // a little lower than the screen, but not starved (the lowest priority made the codec loop stall)
        val app = applicationContext
        val cancel = ShrinkState.cancel
        val results = ArrayList<Shrink.Result>()
        var lastNote = 0L
        try {
            for ((i, item) in sel.withIndex()) {
                if (cancel.get()) break
                ShrinkState.name = item.name
                val r = try {
                    Shrink.run(app, item, q, cancel) { f ->
                        val p = ((i + f) / sel.size).coerceIn(0f, 1f)
                        if (p > ShrinkState.progress) ShrinkState.progress = p
                        val now = SystemClock.elapsedRealtime()
                        if (now - lastNote > 1500L) {
                            lastNote = now
                            runCatching { nm().notify(ID, notif(getString(R.string.shrink_working), (i + 1).toString() + "/" + sel.size + "  " + item.name, (ShrinkState.progress * 100).toInt(), true)) }
                        }
                    }
                } catch (t: Throwable) {
                    Shrink.Result(item, null, 0, (t.message ?: t.javaClass.simpleName) + " (service)")
                }
                results.add(r)
                val p = (i + 1f) / sel.size
                if (p > ShrinkState.progress) ShrinkState.progress = p
            }
        } finally {
            val ok = results.count { it.out != null }
            ShrinkState.results = results
            ShrinkState.progress = 1f
            ShrinkState.running = false
            ShrinkState.finished = true
            runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }
            runCatching { nm().notify(ID_DONE, notif(getString(R.string.shrink_title), ok.toString() + " / " + sel.size, 100, false)) }
            stopSelf()
        }
    }
}
