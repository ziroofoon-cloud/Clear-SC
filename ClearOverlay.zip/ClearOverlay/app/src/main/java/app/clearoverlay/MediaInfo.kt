package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Typeface
import android.media.MediaCodecList
import android.net.Uri
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.exoplayer.ExoPlayer
import java.io.File
import java.text.DateFormat
import java.util.Date
import java.util.Locale

/** The "File info" window of the player: what the file is (size, format, codec, resolution, frame rate ...) and how it plays right now. */
object MediaInfo {

    fun videoName(m: String?): String = when {
        m.isNullOrEmpty() -> "—"
        m.contains("dolby-vision") -> "Dolby Vision"
        m.contains("avc") -> "H.264 / AVC"
        m.contains("hevc") -> "H.265 / HEVC"
        m.contains("av01") -> "AV1"
        m.contains("vp9") -> "VP9"
        m.contains("vp8") -> "VP8"
        m.contains("mp4v") -> "MPEG-4 Part 2"
        m.contains("mpeg2") -> "MPEG-2"
        m.contains("3gpp") -> "H.263"
        else -> m.substringAfter('/')
    }

    fun audioName(m: String?): String = when {
        m.isNullOrEmpty() -> "—"
        m.contains("mp4a") -> "AAC"
        m.contains("eac3-joc") -> "E-AC-3 JOC (Dolby Atmos)"
        m.contains("eac3") -> "E-AC-3 (Dolby Digital Plus)"
        m.contains("ac3") -> "AC-3 (Dolby Digital)"
        m.contains("true-hd") -> "Dolby TrueHD"
        m.contains("opus") -> "Opus"
        m.contains("vorbis") -> "Vorbis"
        m.contains("flac") -> "FLAC"
        m.contains("dts") -> "DTS"
        m.contains("mpeg") -> "MP3 / MPEG audio"
        m.contains("raw") -> "PCM"
        else -> m.substringAfter('/')
    }

    private fun containerName(m: String?, file: String): String {
        val x = when {
            m == null -> null
            m.contains("mp4") -> "MP4"
            m.contains("matroska") -> "MKV (Matroska)"
            m.contains("webm") -> "WebM"
            m.contains("mp2t") -> "MPEG-TS"
            m.contains("mpegurl") || m.contains("mpegURL") -> "HLS"
            m.contains("dash") -> "DASH"
            m.contains("avi") -> "AVI"
            else -> null
        }
        val ext = file.substringAfterLast('.', "").uppercase(Locale.ROOT)
        return when {
            x != null && ext.isNotEmpty() -> "$x  (.$ext)"
            x != null -> x
            ext.isNotEmpty() -> ".$ext"
            else -> "—"
        }
    }

    fun size(b: Long): String {
        if (b < 0) return "—"
        val mb = b / 1048576.0
        val s = if (mb >= 1024) String.format(Locale.US, "%.2f GB", mb / 1024) else String.format(Locale.US, "%.1f MB", mb)
        return String.format(Locale.US, "%s  (%,d bytes)", s, b)
    }

    fun time(ms: Long): String {
        if (ms <= 0) return "—"
        val s = ms / 1000
        return String.format(Locale.US, "%d:%02d:%02d.%03d", s / 3600, s / 60 % 60, s % 60, ms % 1000)
    }

    private fun rate(bps: Long): String =
        if (bps <= 0) "—" else if (bps >= 1_000_000) String.format(Locale.US, "%.2f Mb/s", bps / 1e6) else String.format(Locale.US, "%d kb/s", bps / 1000)

    /** "Hardware" / "Software" for a decoder name such as c2.qti.avc.decoder or c2.android.avc.decoder. */
    fun decoderKind(ctx: Context, name: String?): String {
        if (name.isNullOrEmpty()) return "—"
        val info = runCatching { MediaCodecList(MediaCodecList.ALL_CODECS).codecInfos.firstOrNull { it.name == name } }.getOrNull()
        val hw = when {
            info != null && info.isHardwareAccelerated -> true
            info != null && info.isSoftwareOnly -> false
            else -> !(name.startsWith("OMX.google.") || name.startsWith("c2.android.") || name.startsWith("c2.google."))
        }
        return ctx.getString(if (hw) R.string.info_hw else R.string.info_sw)
    }

    private fun fileSize(ctx: Context, u: Uri): Long = runCatching {
        when (u.scheme) {
            "file" -> File(u.path ?: "").length()
            "content" -> ctx.contentResolver.query(u, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c -> if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else -1L } ?: -1L
            else -> -1L
        }
    }.getOrDefault(-1L)

    private fun fileDate(ctx: Context, u: Uri): Long = runCatching {
        when (u.scheme) {
            "file" -> File(u.path ?: "").lastModified()
            "content" -> ctx.contentResolver.query(u, arrayOf(MediaStore.MediaColumns.DATE_MODIFIED), null, null, null)?.use { c -> if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) * 1000L else 0L } ?: 0L
            else -> 0L
        }
    }.getOrDefault(0L)

    fun build(ctx: Activity, p: ExoPlayer?, uri: Uri?, name: String, decoder: String?, dropped: Int, liveFps: Float): String {
        val sb = StringBuilder()
        fun head(r: Int) { if (sb.isNotEmpty()) sb.append('\n'); sb.append("── ").append(ctx.getString(r)).append(" ──\n") }
        fun row(r: Int, v: String) { sb.append(ctx.getString(r)).append(": ").append(v).append('\n') }
        val vf: Format? = p?.videoFormat
        val af: Format? = p?.audioFormat
        val dur = p?.duration?.takeIf { it != C.TIME_UNSET } ?: 0L
        val bytes = if (uri != null) fileSize(ctx, uri) else -1L

        head(R.string.info_h_file)
        row(R.string.info_name, name)
        if (uri != null) row(R.string.info_path, Uri.decode(uri.toString()))
        row(R.string.info_size, size(bytes))
        val d = if (uri != null) fileDate(ctx, uri) else 0L
        if (d > 0) row(R.string.info_modified, DateFormat.getDateTimeInstance().format(Date(d)))
        row(R.string.info_duration, time(dur))
        row(R.string.info_container, containerName(vf?.containerMimeType ?: af?.containerMimeType, name))
        if (bytes > 0 && dur > 0) row(R.string.info_avg_rate, "≈ " + rate(bytes * 8000L / dur))

        if (vf != null) {
            head(R.string.info_h_video)
            row(R.string.info_codec, videoName(vf.sampleMimeType) + if (!vf.codecs.isNullOrEmpty()) "  [" + vf.codecs + "]" else "")
            val swap = vf.rotationDegrees == 90 || vf.rotationDegrees == 270
            val w = if (swap) vf.height else vf.width
            val h = if (swap) vf.width else vf.height
            if (w > 0 && h > 0) {
                val par = if (vf.pixelWidthHeightRatio > 0f) vf.pixelWidthHeightRatio else 1f
                val rot = if (vf.rotationDegrees != 0) "  (↻ ${vf.rotationDegrees}°)" else ""
                val parTxt = if (par > 1.01f || par < 0.99f) "  (PAR " + String.format(Locale.US, "%.2f", par) + ")" else ""
                row(R.string.info_res, "$w × $h$rot$parTxt")
                row(R.string.info_aspect, String.format(Locale.US, "%.3f : 1", w * par / h))
            }
            row(R.string.info_fps, if (vf.frameRate > 0f) String.format(Locale.US, "%.3f", vf.frameRate) else ctx.getString(R.string.info_unknown))
            val br = (if (vf.averageBitrate > 0) vf.averageBitrate else vf.bitrate).toLong()
            row(R.string.info_vrate, rate(br))
            val ci = vf.colorInfo
            if (ci != null) {
                val hdr = when (ci.colorTransfer) {
                    C.COLOR_TRANSFER_ST2084 -> "HDR10 / PQ"
                    C.COLOR_TRANSFER_HLG -> "HLG (HDR)"
                    else -> "SDR"
                }
                val sp = when (ci.colorSpace) {
                    C.COLOR_SPACE_BT2020 -> "BT.2020"
                    C.COLOR_SPACE_BT709 -> "BT.709"
                    C.COLOR_SPACE_BT601 -> "BT.601"
                    else -> "—"
                }
                val rg = when (ci.colorRange) {
                    C.COLOR_RANGE_FULL -> "full"
                    C.COLOR_RANGE_LIMITED -> "limited"
                    else -> "—"
                }
                val bits = if (ci.lumaBitdepth > 0) "  ${ci.lumaBitdepth}-bit" else ""
                row(R.string.info_color, "$hdr · $sp · $rg$bits")
            }
            row(R.string.info_decoder, (decoder ?: "—") + "  (" + decoderKind(ctx, decoder) + ")")
        }

        if (af != null) {
            head(R.string.info_h_audio)
            row(R.string.info_codec, audioName(af.sampleMimeType))
            if (af.channelCount > 0) row(R.string.info_channels, af.channelCount.toString())
            if (af.sampleRate > 0) row(R.string.info_samplerate, af.sampleRate.toString() + " Hz")
            val ab = (if (af.averageBitrate > 0) af.averageBitrate else af.bitrate).toLong()
            row(R.string.info_vrate, rate(ab))
            if (!af.language.isNullOrEmpty() && af.language != "und") row(R.string.info_lang, af.language!!)
        }

        if (p != null) {
            var na = 0
            var nt = 0
            runCatching {
                for (g in p.currentTracks.groups) {
                    if (g.type == C.TRACK_TYPE_AUDIO) na++
                    if (g.type == C.TRACK_TYPE_TEXT) nt++
                }
            }
            head(R.string.info_h_play)
            row(R.string.info_tracks, ctx.getString(R.string.info_tracks_fmt, na, nt))
            row(R.string.info_live, String.format(Locale.US, "%.1f FPS", liveFps))
            row(R.string.info_dropped, dropped.toString())
            val dm = ctx.resources.displayMetrics
            val hz = runCatching { ctx.display?.refreshRate ?: 0f }.getOrDefault(0f)
            row(R.string.info_display, "${dm.widthPixels} × ${dm.heightPixels}" + if (hz > 0f) String.format(Locale.US, "  @ %.0f Hz", hz) else "")
        }
        return sb.toString().trimEnd()
    }

    fun show(ctx: Activity, p: ExoPlayer?, uri: Uri?, name: String, decoder: String?, dropped: Int, liveFps: Float) {
        val text = build(ctx, p, uri, name, decoder, dropped, liveFps)
        val tv = TextView(ctx).apply {
            this.text = text
            textSize = 13f
            typeface = Typeface.MONOSPACE
            setTextColor(Ui.TEXT)
            setTextIsSelectable(true)
            setPadding(dp(ctx, 20), dp(ctx, 12), dp(ctx, 20), dp(ctx, 4))
        }
        AlertDialog.Builder(ctx)
            .setTitle(R.string.info_title)
            .setView(ScrollView(ctx).apply { addView(tv) })
            .setPositiveButton(android.R.string.ok, null)
            .setNeutralButton(R.string.info_copy) { _, _ ->
                runCatching {
                    (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("info", text))
                    Toast.makeText(ctx, R.string.info_copied, Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }
}
