package app.clearoverlay

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

/**
 * The folders Android keeps closed even for "All files access" (Android/data and Android/obb on Android 11 and newer), opened through the
 * access the user gave once with the system folder picker ("Use this folder"). Paths are "/a/b" below that folder; the document ids of the
 * phone's storage are the real relative paths, so a path maps straight to a document.
 */
class SafFs(private val ctx: Context, private val tree: Uri, private val baseDoc: String) : FmFs {

    companion object {
        /** The document id of the folder the user has to pick for [kind] ("data" or "obb"). */
        fun docId(kind: String) = "primary:Android/$kind"

        fun prefKey(kind: String) = "fm_saf_$kind"

        /** The saved folder access for [kind], or null when it was never given or has been taken back. */
        fun treeUri(ctx: Context, kind: String): Uri? {
            val s = ctx.getSharedPreferences("crsc", Context.MODE_PRIVATE).getString(prefKey(kind), null) ?: return null
            val u = Uri.parse(s)
            val ok = ctx.contentResolver.persistedUriPermissions.any { it.uri == u && it.isReadPermission && it.isWritePermission }
            return if (ok) u else null
        }

        fun open(ctx: Context, kind: String): SafFs {
            val u = treeUri(ctx, kind) ?: throw IOException("no access to Android/$kind was given")
            return SafFs(ctx, u, DocumentsContract.getTreeDocumentId(u))
        }
    }

    private val cr get() = ctx.contentResolver

    override fun root(): String = "/"

    override fun parent(path: String): String? {
        val p = path.trimEnd('/')
        if (p.isEmpty()) return null
        val i = p.lastIndexOf('/')
        return if (i <= 0) "/" else p.substring(0, i)
    }

    override fun join(dir: String, name: String): String = if (dir.endsWith("/")) dir + name else "$dir/$name"

    private fun docId(path: String): String {
        val p = path.trim('/')
        return if (p.isEmpty()) baseDoc else "$baseDoc/$p"
    }

    private fun docUri(path: String): Uri = DocumentsContract.buildDocumentUriUsingTree(tree, docId(path))

    override fun list(dir: String): MutableList<FmItem> {
        val kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId(dir))
        val cols = arrayOf(Document.COLUMN_DISPLAY_NAME, Document.COLUMN_MIME_TYPE, Document.COLUMN_SIZE, Document.COLUMN_LAST_MODIFIED)
        val out = ArrayList<FmItem>()
        val c = try {
            cr.query(kids, cols, null, null, null)
        } catch (e: Exception) {
            throw IOException("cannot read $dir: " + (e.message ?: e.javaClass.simpleName))
        } ?: throw IOException("cannot read $dir")
        c.use {
            while (it.moveToNext()) {
                val name = it.getString(0) ?: continue
                val d = it.getString(1) == Document.MIME_TYPE_DIR
                val size = if (d || it.isNull(2)) -1L else it.getLong(2)
                val mod = if (it.isNull(3)) 0L else it.getLong(3)
                out.add(FmItem(name, d, size, mod))
            }
        }
        return out
    }

    /** (is a folder) of [path], or null when it does not exist. */
    private fun kind(path: String): Boolean? {
        if (path.trim('/').isEmpty()) return true
        return try {
            cr.query(docUri(path), arrayOf(Document.COLUMN_MIME_TYPE), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) == Document.MIME_TYPE_DIR else null
            }
        } catch (e: Exception) {
            null
        }
    }

    override fun exists(path: String): Boolean = kind(path) != null

    override fun open(path: String): InputStream = cr.openInputStream(docUri(path)) ?: throw IOException("cannot open $path")

    /** An output stream that can be thrown away (a failed copy leaves no half file). */
    private inner class Out(private val o: OutputStream, private val uri: Uri) : OutputStream(), FmAbortable {
        override fun write(b: Int) = o.write(b)
        override fun write(b: ByteArray, off: Int, len: Int) = o.write(b, off, len)
        override fun flush() = o.flush()
        override fun close() = o.close()
        override fun abort() {
            runCatching { o.close() }
            runCatching { DocumentsContract.deleteDocument(cr, uri) }
        }
    }

    override fun create(path: String, size: Long): OutputStream {
        val parent = parent(path) ?: throw IOException("bad path $path")
        if (exists(path)) runCatching { DocumentsContract.deleteDocument(cr, docUri(path)) }
        val name = FmCopy.baseName(path)
        // the real type of the name: with "application/octet-stream" the phone's storage provider can add ".bin" to a name such as "a.mp4"
        val mime = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase(java.util.Locale.US)) ?: "application/octet-stream"
        val uri = DocumentsContract.createDocument(cr, docUri(parent), mime, name) ?: throw IOException("cannot create $name")
        val os = cr.openOutputStream(uri, "wt") ?: throw IOException("cannot write $name")
        return Out(os, uri)
    }

    override fun mkdir(path: String) {
        if (kind(path) == true) return
        val parent = parent(path) ?: return
        mkdir(parent)
        DocumentsContract.createDocument(cr, docUri(parent), Document.MIME_TYPE_DIR, FmCopy.baseName(path)) ?: throw IOException("cannot create $path")
    }

    override fun delete(path: String) {
        if (!exists(path)) return
        if (!DocumentsContract.deleteDocument(cr, docUri(path))) throw IOException("cannot delete $path")
    }

    override fun rename(path: String, newName: String) {
        val parent = parent(path) ?: throw IOException("bad path $path")
        if (exists(join(parent, newName))) throw IOException("already exists: $newName")
        DocumentsContract.renameDocument(cr, docUri(path), newName) ?: throw IOException("cannot rename " + FmCopy.baseName(path))
    }

    override fun moveWithin(from: String, to: String): Boolean {
        val fp = parent(from) ?: return false
        val tp = parent(to) ?: return false
        if (FmCopy.baseName(from) != FmCopy.baseName(to) || exists(to)) return false
        return try {
            DocumentsContract.moveDocument(cr, docUri(from), docUri(fp), docUri(tp)) != null
        } catch (e: Exception) {
            false
        }
    }

    override fun localFile(path: String): File? = null

    override fun freeSpace(): Long = -1L

    override fun close() {}
}
