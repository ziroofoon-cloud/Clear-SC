package app.clearoverlay

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import rikka.shizuku.Shizuku
import java.io.IOException
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Android/data and Android/obb through Shizuku (the way MT Manager does it on new Android): Shizuku starts a small helper of this app
 * ([ShellService]) as the "shell" user, and the file manager talks to it ([ShizukuFs]). Needs the Shizuku app installed and started once
 * after every restart of the phone (Wireless debugging, no computer), and one permission tap.
 */
object ShizukuAccess {
    private const val REQ = 4711
    private const val PKG = "moe.shizuku.privileged.api"
    private val main = Handler(Looper.getMainLooper())
    private var pending: ((Boolean) -> Unit)? = null
    private var listening = false

    @Volatile private var svc: IShellFs? = null
    private var conn: ServiceConnection? = null
    private var args: Shizuku.UserServiceArgs? = null

    /** Shizuku is installed on the phone. */
    fun installed(ctx: Context): Boolean = try {
        ctx.packageManager.getPackageInfo(PKG, 0)
        true
    } catch (e: Throwable) {
        false
    }

    /** Shizuku is installed AND started. */
    fun running(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        false
    }

    private fun granted(): Boolean = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    /** Makes sure this app may use Shizuku (asks once); [done] gets true / false on the main thread. */
    fun ask(done: (Boolean) -> Unit) {
        try {
            if (granted()) { done(true); return }
            if (Shizuku.shouldShowRequestPermissionRationale()) { done(false); return } // refused for good in the Shizuku app
            if (!listening) {
                listening = true
                Shizuku.addRequestPermissionResultListener { _, result ->
                    main.post {
                        val cb = pending
                        pending = null
                        cb?.invoke(result == PackageManager.PERMISSION_GRANTED)
                    }
                }
            }
            pending = done
            Shizuku.requestPermission(REQ)
        } catch (e: Throwable) {
            done(false)
        }
    }

    /** The helper (started when needed). Blocks for a moment: background thread only. */
    @Synchronized
    fun service(ctx: Context): IShellFs {
        svc?.let { if (it.asBinder().pingBinder()) return it }
        if (!running()) throw IOException("Shizuku is not running")
        if (!granted()) throw IOException("Shizuku has not given this app permission")
        val latch = CountDownLatch(1)
        val c = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                if (binder != null && binder.pingBinder()) svc = IShellFs.Stub.asInterface(binder)
                latch.countDown()
            }

            override fun onServiceDisconnected(name: ComponentName?) {
                svc = null
            }
        }
        val a = Shizuku.UserServiceArgs(ComponentName(ctx.packageName, ShellService::class.java.name))
            .daemon(false)
            .processNameSuffix("fs")
            .version(1)
        conn = c
        args = a
        try {
            Shizuku.bindUserService(a, c)
        } catch (e: Throwable) {
            throw IOException("Shizuku could not start the helper: " + (e.message ?: e.javaClass.simpleName))
        }
        if (!latch.await(12, TimeUnit.SECONDS)) throw IOException("Shizuku did not start the helper in time, try again")
        return svc ?: throw IOException("Shizuku helper not available")
    }

    /** Forget the helper (it stopped); the next [service] call starts it again. */
    fun reset() {
        svc = null
    }
}
