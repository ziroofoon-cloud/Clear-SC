package app.clearoverlay

import android.content.Context
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.tanh

/** One set of sound-enhancement amounts (all 0..1). */
class AudioParams(
    /** Restores / adds the very high frequencies that low-bit-rate files lost (harmonic exciter). */
    val clarity: Float,
    /** Low-end warmth (low shelf below ~130 Hz). */
    val bass: Float,
    /** Stereo width: 0 = as recorded, 1 = side signal doubled. */
    val width: Float,
    /** Loudness / dynamics: lifts quiet parts, tames loud peaks. */
    val loud: Float,
    /** Voice clean-up: rumble filter + a soft gate for the hiss between words. */
    val voice: Float,
    /** Five-band equaliser, -1..1 per band (x12 dB): 60 Hz shelf, 250 Hz, 1 kHz, 4 kHz, 12 kHz shelf. */
    val eq: FloatArray = FloatArray(5),
    /** Dialogue boost: a presence lift around 2.8 kHz that makes speech easier to follow (0..1 = up to +7 dB). */
    val dialog: Float = 0f
)

/**
 * Settings of the sound enhancer, shared by the music player, the video player and the file export.
 * The DSP reads the fields on every audio block, so changes are heard at once.
 */
object AudioCfg {
    const val MUSIC = 0
    const val VIDEO = 1
    const val PODCAST = 2
    const val ASMR = 3
    const val CUSTOM = 4

    // clarity, bass, width, loud, voice
    private val PRESETS = arrayOf(
        floatArrayOf(0.45f, 0.30f, 0.25f, 0.25f, 0.00f), // music
        floatArrayOf(0.30f, 0.35f, 0.15f, 0.55f, 0.15f), // video / film: lift dialogue, calm the explosions
        floatArrayOf(0.25f, 0.10f, 0.00f, 0.60f, 0.70f), // podcast / voice
        floatArrayOf(0.35f, 0.05f, 0.35f, 0.30f, 0.00f)  // ASMR: keep the tiny details, no gate
    )

    @Volatile var on = false
    @Volatile var preset = MUSIC
    @Volatile var clarity = PRESETS[0][0]
    @Volatile var bass = PRESETS[0][1]
    @Volatile var width = PRESETS[0][2]
    @Volatile var loud = PRESETS[0][3]
    @Volatile var voice = PRESETS[0][4]
    @Volatile var dialog = 0f
    /** Equaliser bands, -1..1 (x12 dB). The array is replaced, never edited in place, so the audio thread always sees a whole set. */
    @Volatile var eq = FloatArray(5)

    // equaliser quick shapes: flat, bass+, vocal, treble+, "V" loudness
    val EQ_SHAPES = arrayOf(
        floatArrayOf(0f, 0f, 0f, 0f, 0f),
        floatArrayOf(0.55f, 0.35f, 0f, 0f, 0f),
        floatArrayOf(-0.25f, -0.1f, 0.2f, 0.4f, 0.1f),
        floatArrayOf(0f, 0f, 0f, 0.3f, 0.55f),
        floatArrayOf(0.45f, 0.15f, -0.2f, 0.15f, 0.4f)
    )
    private val PRESET_EQ = arrayOf(
        floatArrayOf(0.2f, 0.1f, 0f, 0.05f, 0.15f),   // music
        floatArrayOf(0.1f, 0f, 0.1f, 0.2f, 0.1f),     // video
        floatArrayOf(-0.3f, -0.1f, 0.15f, 0.3f, 0f),  // podcast
        floatArrayOf(0f, 0f, 0f, 0f, 0.2f)            // asmr
    )
    private val PRESET_DIALOG = floatArrayOf(0f, 0.5f, 0.4f, 0f)

    fun applyPreset(i: Int) {
        if (i !in PRESETS.indices) { preset = CUSTOM; return }
        preset = i
        val v = PRESETS[i]
        clarity = v[0]; bass = v[1]; width = v[2]; loud = v[3]; voice = v[4]
        eq = PRESET_EQ[i].copyOf()
        dialog = PRESET_DIALOG[i]
    }

    fun snapshot() = AudioParams(clarity, bass, width, loud, voice, eq, dialog)

    private fun prefs(c: Context) = c.getSharedPreferences("crsc_audio", Context.MODE_PRIVATE)

    fun load(c: Context) {
        val p = prefs(c)
        on = p.getBoolean("on", false)
        preset = p.getInt("preset", MUSIC).coerceIn(0, CUSTOM)
        clarity = p.getFloat("clarity", PRESETS[0][0]).coerceIn(0f, 1f)
        bass = p.getFloat("bass", PRESETS[0][1]).coerceIn(0f, 1f)
        width = p.getFloat("width", PRESETS[0][2]).coerceIn(0f, 1f)
        loud = p.getFloat("loud", PRESETS[0][3]).coerceIn(0f, 1f)
        voice = p.getFloat("voice", PRESETS[0][4]).coerceIn(0f, 1f)
        dialog = p.getFloat("dialog", 0f).coerceIn(0f, 1f)
        eq = FloatArray(5) { p.getFloat("eq$it", PRESET_EQ[0][it]).coerceIn(-1f, 1f) }
    }

    fun save(c: Context) {
        prefs(c).edit()
            .putBoolean("on", on)
            .putInt("preset", preset)
            .putFloat("clarity", clarity)
            .putFloat("bass", bass)
            .putFloat("width", width)
            .putFloat("loud", loud)
            .putFloat("voice", voice)
            .putFloat("dialog", dialog)
            .also { e -> eq.forEachIndexed { i, v -> e.putFloat("eq$i", v) } }
            .apply()
    }
}

/**
 * The sound enhancer itself: works on interleaved float samples (mono or stereo), in place.
 *
 * Chain per sample: voice rumble filter -> bass shelf -> clarity exciter -> stereo width -> dynamics (gate +
 * compressor + make-up gain) -> soft limiter (so the boosts can never clip).
 *
 * "Clarity" is a classic harmonic exciter, not a neural network: the part of the sound above ~3.5 kHz is pushed
 * through a gentle non-linearity, which creates new harmonics; only the part above ~5.5 kHz of that is kept and
 * mixed in softly. It makes dull, low-bit-rate (MP3 128 kbps, old YouTube) sound brighter and more open. It cannot
 * bring back detail that is really gone: it adds a believable top end.
 */
class AudioFxCore {
    private var fs = 44100f
    private var ch = 2

    private val exLp1 = FloatArray(2)
    private val exLp2 = FloatArray(2)
    private val exPost = FloatArray(2)
    private val bassLp = FloatArray(2)
    private val voiceLp = FloatArray(2)
    private var env = 0f
    private var gate = 1f
    private var gain = 1f

    private var aEx = 0.3f
    private var aPost = 0.5f
    private var aBass = 0.02f
    private var aVoice = 0.01f
    private var aAtt = 0.01f
    private var aRel = 0.0001f
    private var aGate = 0.0005f

    private fun coef(hz: Float) = 1f - exp(-2f * Math.PI.toFloat() * hz / fs)

    // ---- equaliser: 5 bands + the dialogue presence band, RBJ biquads (direct form I), per channel
    private val nB = 6
    private val bb0 = FloatArray(nB); private val bb1 = FloatArray(nB); private val bb2 = FloatArray(nB)
    private val ba1 = FloatArray(nB); private val ba2 = FloatArray(nB)
    private val zx1 = FloatArray(nB * 2); private val zx2 = FloatArray(nB * 2)
    private val zy1 = FloatArray(nB * 2); private val zy2 = FloatArray(nB * 2)
    private val gDb = FloatArray(nB) { Float.NaN }
    private val active = BooleanArray(nB)

    /** type 0 = peak, 1 = low shelf, 2 = high shelf */
    private fun design(b: Int, type: Int, hz: Float, q: Float, db: Float) {
        val f0 = min(hz, fs * 0.45f)
        val a = Math.pow(10.0, db / 40.0).toFloat()
        val w = 2.0 * Math.PI * f0 / fs
        val cw = Math.cos(w).toFloat()
        val sw = Math.sin(w).toFloat()
        val al = sw / (2f * q)
        val b0: Float; val b1: Float; val b2: Float; val a0: Float; val a1: Float; val a2: Float
        when (type) {
            0 -> {
                b0 = 1f + al * a; b1 = -2f * cw; b2 = 1f - al * a
                a0 = 1f + al / a; a1 = -2f * cw; a2 = 1f - al / a
            }
            1 -> {
                val sq = 2f * kotlin.math.sqrt(a) * al
                b0 = a * ((a + 1f) - (a - 1f) * cw + sq); b1 = 2f * a * ((a - 1f) - (a + 1f) * cw); b2 = a * ((a + 1f) - (a - 1f) * cw - sq)
                a0 = (a + 1f) + (a - 1f) * cw + sq; a1 = -2f * ((a - 1f) + (a + 1f) * cw); a2 = (a + 1f) + (a - 1f) * cw - sq
            }
            else -> {
                val sq = 2f * kotlin.math.sqrt(a) * al
                b0 = a * ((a + 1f) + (a - 1f) * cw + sq); b1 = -2f * a * ((a - 1f) + (a + 1f) * cw); b2 = a * ((a + 1f) + (a - 1f) * cw - sq)
                a0 = (a + 1f) - (a - 1f) * cw + sq; a1 = 2f * ((a - 1f) - (a + 1f) * cw); a2 = (a + 1f) - (a - 1f) * cw - sq
            }
        }
        bb0[b] = b0 / a0; bb1[b] = b1 / a0; bb2[b] = b2 / a0; ba1[b] = a1 / a0; ba2[b] = a2 / a0
    }

    private fun updateEq(eq: FloatArray, dialog: Float) {
        val db = floatArrayOf(eq[0] * 12f, eq[1] * 12f, eq[2] * 12f, eq[3] * 12f, eq[4] * 12f, dialog * 7f)
        for (b in 0 until nB) {
            if (db[b] == gDb[b]) continue
            gDb[b] = db[b]
            active[b] = abs(db[b]) > 0.2f
            if (!active[b]) {
                for (c in 0 until 2) { zx1[b * 2 + c] = 0f; zx2[b * 2 + c] = 0f; zy1[b * 2 + c] = 0f; zy2[b * 2 + c] = 0f }
                continue
            }
            when (b) {
                0 -> design(0, 1, 60f, 0.8f, db[b])
                1 -> design(1, 0, 250f, 0.9f, db[b])
                2 -> design(2, 0, 1000f, 0.9f, db[b])
                3 -> design(3, 0, 4000f, 0.9f, db[b])
                4 -> design(4, 2, 12000f, 0.8f, db[b])
                else -> design(5, 0, 2800f, 1.1f, db[b])
            }
        }
    }

    fun configure(sampleRate: Int, channels: Int) {
        fs = max(8000, sampleRate).toFloat()
        ch = channels.coerceIn(1, 2)
        aEx = coef(min(3500f, fs * 0.3f))
        aPost = coef(min(5500f, fs * 0.4f))
        aBass = coef(130f)
        aVoice = coef(85f)
        aAtt = 1f - exp(-1f / (0.008f * fs))   // 8 ms attack
        aRel = 1f - exp(-1f / (0.25f * fs))    // 250 ms release
        aGate = 1f - exp(-1f / (0.06f * fs))   // 60 ms gate smoothing
        reset()
    }

    fun reset() {
        exLp1.fill(0f); exLp2.fill(0f); exPost.fill(0f); bassLp.fill(0f); voiceLp.fill(0f)
        zx1.fill(0f); zx2.fill(0f); zy1.fill(0f); zy2.fill(0f); gDb.fill(Float.NaN)
        env = 0f; gate = 1f; gain = 1f
    }

    /** Processes [frames] frames of interleaved samples in [x] (values about -1..1), in place. */
    fun process(x: FloatArray, frames: Int, p: AudioParams) {
        val c = ch
        updateEq(p.eq, p.dialog)
        val clarity = p.clarity * 1.6f
        val bassG = p.bass * 1.3f
        val voiceOn = p.voice > 0.001f
        val voiceAmt = min(1f, p.voice * 1.5f)
        val loud = p.loud
        val ratioInv = 1f / (1f + loud * 3f)     // compressor 1:1 .. 4:1
        val makeup = 1f + loud * 1.1f            // up to about +6.4 dB
        val thr = 0.09f                          // about -21 dBFS
        val widthAmt = 1f + p.width
        val gateDepth = 1f - 0.75f * p.voice     // gate closes down to about -12 dB
        var i = 0
        for (f in 0 until frames) {
            var l = 0f
            var r = 0f
            for (k in 0 until c) {
                var s = x[i + k]
                if (voiceOn) {
                    voiceLp[k] += aVoice * (s - voiceLp[k])
                    s -= voiceLp[k] * voiceAmt
                }
                if (bassG > 0.001f) {
                    bassLp[k] += aBass * (s - bassLp[k])
                    s += bassG * bassLp[k]
                }
                for (b in 0 until nB) {
                    if (!active[b]) continue
                    val zi = b * 2 + k
                    val y = bb0[b] * s + bb1[b] * zx1[zi] + bb2[b] * zx2[zi] - ba1[b] * zy1[zi] - ba2[b] * zy2[zi]
                    zx2[zi] = zx1[zi]; zx1[zi] = s; zy2[zi] = zy1[zi]; zy1[zi] = y
                    s = y
                }
                if (clarity > 0.001f) {
                    exLp1[k] += aEx * (s - exLp1[k])
                    exLp2[k] += aEx * (exLp1[k] - exLp2[k])
                    val e = s - exLp2[k]                     // content above ~3.5 kHz
                    val ae = abs(e)
                    val h = e * ae * 8f / (1f + 8f * ae)     // non-linear part: new harmonics
                    exPost[k] += aPost * (h - exPost[k])
                    s += clarity * (h - exPost[k])           // keep only what is above ~5.5 kHz
                }
                if (k == 0) l = s else r = s
            }
            if (c == 1) r = l
            if (c == 2 && p.width > 0.001f) {
                val m = (l + r) * 0.5f
                val sd = (l - r) * 0.5f * widthAmt
                l = m + sd
                r = m - sd
            }
            // dynamics
            val peak = max(abs(l), abs(r))
            env += (if (peak > env) aAtt else aRel) * (peak - env)
            var g = 1f
            if (loud > 0.001f && env > thr) g = exp(ln(env / thr) * (ratioInv - 1f))
            if (voiceOn) {
                val target = if (env < 0.004f) gateDepth else 1f   // below about -48 dBFS: hiss between words
                gate += aGate * (target - gate)
            } else gate = 1f
            val total = g * makeup * gate
            gain += 0.01f * (total - gain)   // smooth, so there are no zipper clicks when a slider moves
            l = limit(l * gain)
            r = limit(r * gain)
            if (c == 1) {
                x[i] = l
            } else {
                x[i] = l
                x[i + 1] = r
            }
            i += c
        }
    }

    /** Soft limiter: untouched below 0.8, rounds off smoothly above, never beyond 1.0. */
    private fun limit(v: Float): Float {
        val a = abs(v)
        if (a <= 0.8f) return v
        val o = 0.8f + 0.2f * tanh(((a - 0.8f) / 0.2f).toDouble()).toFloat()
        return if (v < 0f) -o else o
    }
}

/** Media3 audio processor: put it in the player's audio sink and the sound is enhanced live. Reads [AudioCfg]. */
@Suppress("UnsafeOptInUsageError")
class AudioFxProcessor : BaseAudioProcessor() {
    private val core = AudioFxCore()
    private var isFloat = false
    private var tmp = FloatArray(0)

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        val enc = inputAudioFormat.encoding
        val okEnc = enc == C.ENCODING_PCM_16BIT || enc == C.ENCODING_PCM_FLOAT
        val okCh = inputAudioFormat.channelCount == 1 || inputAudioFormat.channelCount == 2
        // anything else (5.1, 24-bit ...) passes through untouched
        if (!okEnc || !okCh) return AudioProcessor.AudioFormat.NOT_SET
        isFloat = enc == C.ENCODING_PCM_FLOAT
        core.configure(inputAudioFormat.sampleRate, inputAudioFormat.channelCount)
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val size = inputBuffer.remaining()
        if (size == 0) return
        val out = replaceOutputBuffer(size)
        if (!AudioCfg.on) {
            out.put(inputBuffer)
            out.flip()
            return
        }
        val chn = inputAudioFormat.channelCount
        inputBuffer.order(ByteOrder.nativeOrder())
        val n = size / (if (isFloat) 4 else 2)
        if (tmp.size < n) tmp = FloatArray(n)
        if (isFloat) {
            for (i in 0 until n) tmp[i] = inputBuffer.getFloat()
        } else {
            for (i in 0 until n) tmp[i] = inputBuffer.getShort() / 32768f
        }
        core.process(tmp, n / chn, AudioCfg.snapshot())
        if (isFloat) {
            for (i in 0 until n) out.putFloat(tmp[i].coerceIn(-1f, 1f))
        } else {
            for (i in 0 until n) out.putShort((tmp[i].coerceIn(-1f, 1f) * 32767f).toInt().toShort())
        }
        // a trailing odd byte (never seen in practice) is kept so no data is lost
        while (inputBuffer.hasRemaining()) out.put(inputBuffer.get())
        out.flip()
    }

    override fun onFlush() {
        core.reset()
    }

    override fun onReset() {
        core.reset()
    }
}

/** Renderers whose audio sink contains the sound enhancer: hand this to ExoPlayer.Builder and the player's sound is enhanced. */
@Suppress("UnsafeOptInUsageError")
fun audioFxRenderersFactory(ctx: Context): DefaultRenderersFactory = object : DefaultRenderersFactory(ctx) {
    override fun buildAudioSink(
        context: Context,
        enableFloatOutput: Boolean,
        enableAudioTrackPlaybackParams: Boolean
    ): AudioSink = DefaultAudioSink.Builder(context)
        .setEnableFloatOutput(enableFloatOutput)
        .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
        .setAudioProcessors(arrayOf<AudioProcessor>(AudioFxProcessor()))
        .build()
}
