package app.clearoverlay

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.view.Surface
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

/**
 * "Free up space" without a computer or the cloud: the biggest videos and photos of the phone are written again, smaller, into
 * Movies / Pictures / ClearOverlay / Shrunk. The original is never touched; the screen offers to delete it afterwards (the phone's
 * own "allow" box), and only for files that really got smaller.
 *  - Video: decoded and encoded again as HEVC (H.265, about half the size of H.264 for the same look; H.264 when the phone has no
 *    HEVC encoder), the picture size and the frame times are kept, the sound is copied as it is. HDR videos are skipped.
 *  - Photo (JPEG): written again as JPEG at a lower quality (and, for "Tiny", at most 3000 px on the long side). The turn (EXIF
 *    orientation) is applied to the pixels; other EXIF data (GPS, camera) is not copied, the date taken is.
 */
object Shrink {
    const val FOLDER = "ClearOverlay/Shrunk"

    class Item(
        val uri: Uri,
        val name: String,
        val size: Long,
        val w: Int,
        val h: Int,
        val durMs: Long,
        val video: Boolean,
        val dateTaken: Long
    )

    class Result(val item: Item, val out: Uri?, val outSize: Long, val error: String?)

    /** Quality steps: 0 Balanced, 1 Small, 2 Tiny. */
    private val VIDEO_KEEP = floatArrayOf(0.55f, 0.40f, 0.28f)    // share of the old bit rate kept (H.265)
    private val PHOTO_Q = intArrayOf(88, 80, 70)
    private val PHOTO_KEEP = floatArrayOf(0.55f, 0.40f, 0.28f)    // rough share of the old size kept
    private const val PHOTO_TINY_SIDE = 3000

    // ---- lists ------------------------------------------------------------------------------------

    fun listVideos(ctx: Context): List<Item> {
        val out = ArrayList<Item>()
        val m = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.SIZE, MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.WIDTH, MediaStore.Video.Media.HEIGHT, MediaStore.Video.Media.RELATIVE_PATH, MediaStore.Video.Media.DATE_TAKEN
        )
        runCatching {
            ctx.contentResolver.query(m, proj, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val size = c.getLong(2)
                    if (size < 8_000_000L) continue
                    if ((c.getString(6) ?: "").contains(FOLDER)) continue
                    out.add(Item(Uri.withAppendedPath(m, c.getLong(0).toString()), c.getString(1) ?: "video", size, c.getInt(4), c.getInt(5), c.getLong(3), true, c.getLong(7)))
                }
            }
        }
        out.sortByDescending { it.size }
        return if (out.size > 300) out.subList(0, 300).toList() else out
    }

    fun listPhotos(ctx: Context): List<Item> {
        val out = ArrayList<Item>()
        val m = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.SIZE, MediaStore.Images.Media.WIDTH,
            MediaStore.Images.Media.HEIGHT, MediaStore.Images.Media.RELATIVE_PATH, MediaStore.Images.Media.DATE_TAKEN
        )
        runCatching {
            ctx.contentResolver.query(m, proj, MediaStore.Images.Media.MIME_TYPE + "=?", arrayOf("image/jpeg"), null)?.use { c ->
                while (c.moveToNext()) {
                    val size = c.getLong(2)
                    if (size < 1_200_000L) continue
                    if ((c.getString(5) ?: "").contains(FOLDER)) continue
                    out.add(Item(Uri.withAppendedPath(m, c.getLong(0).toString()), c.getString(1) ?: "photo", size, c.getInt(3), c.getInt(4), 0L, false, c.getLong(6)))
                }
            }
        }
        out.sortByDescending { it.size }
        return if (out.size > 400) out.subList(0, 400).toList() else out
    }

    /** Music of the phone (2 MB and bigger), biggest first. */
    fun listMusic(ctx: Context): List<Item> {
        val out = ArrayList<Item>()
        val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.SIZE, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.DATE_ADDED)
        runCatching {
            ctx.contentResolver.query(base, proj, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val size = c.getLong(2)
                    val name = c.getString(1) ?: continue
                    if (size < 2_000_000L || !isAudioName(name)) continue
                    out.add(Item(android.content.ContentUris.withAppendedId(base, c.getLong(0)), name, size, 0, 0, c.getLong(3), false, c.getLong(4) * 1000L))
                }
            }
        }
        out.sortByDescending { it.size }
        return if (out.size > 500) out.subList(0, 500).toList() else out
    }

    /** Comic files of the phone (.cbz / .cb7 from 1 MB, .zip / .7z from 5 MB; needs the phone's file index, "All files access" makes it complete). */
    fun listComics(ctx: Context): List<Item> {
        val out = ArrayList<Item>()
        val base = MediaStore.Files.getContentUri("external")
        val proj = arrayOf(MediaStore.Files.FileColumns._ID, MediaStore.Files.FileColumns.DISPLAY_NAME, MediaStore.Files.FileColumns.SIZE, MediaStore.Files.FileColumns.DATE_ADDED)
        val sel = "(" + listOf("cbz", "cb7", "zip", "7z").joinToString(" OR ") { MediaStore.Files.FileColumns.DISPLAY_NAME + " LIKE ?" } + ")"
        runCatching {
            ctx.contentResolver.query(base, proj, sel, arrayOf("%.cbz", "%.cb7", "%.zip", "%.7z"), null)?.use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(1) ?: continue
                    val size = c.getLong(2)
                    val ln = name.lowercase()
                    val comicExt = ln.endsWith(".cbz") || ln.endsWith(".cb7")
                    if (size < (if (comicExt) 1_000_000L else 5_000_000L)) continue
                    out.add(Item(android.content.ContentUris.withAppendedId(base, c.getLong(0)), name, size, 0, 0, 0L, false, c.getLong(3) * 1000L))
                }
            }
        }
        out.sortByDescending { it.size }
        return if (out.size > 300) out.subList(0, 300).toList() else out
    }

    /** An item for any file the person picked by hand (any size). Null when it is neither a video nor a JPEG photo. */
    fun itemFor(ctx: Context, picked: Uri): Item? {
        val cr = ctx.contentResolver
        var mime = runCatching { cr.getType(picked) }.getOrNull() ?: ""
        if (mime.isEmpty() || mime == "application/octet-stream") { // a file picked by its path has no type: the ending says what it is
            val ext = (picked.path ?: "").substringAfterLast('.', "").lowercase()
            mime = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: mime
        }
        val isVideo = mime.startsWith("video/")
        val isPhoto = mime.equals("image/jpeg", true) || mime.equals("image/jpg", true)
        if (!isVideo && !isPhoto) return null
        // a file picked in the phone's "Videos" / "Images" list is the same file as in the media index: use that address, so that the originals can be deleted afterwards
        var uri = picked
        if (picked.authority == "com.android.providers.media.documents") {
            val id = runCatching { picked.lastPathSegment!!.substringAfter(':').toLong() }.getOrNull()
            if (id != null) uri = Uri.withAppendedPath(if (isVideo) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id.toString())
        }
        var name = "file"
        var size = 0L
        runCatching {
            cr.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME, android.provider.OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) { name = c.getString(0) ?: name; size = c.getLong(1) }
            }
        }
        if (size <= 0L) size = runCatching { cr.openFileDescriptor(uri, "r")?.use { it.statSize } }.getOrNull() ?: 0L
        var w = 0
        var h = 0
        var dur = 0L
        if (isVideo) {
            val r = android.media.MediaMetadataRetriever()
            runCatching {
                r.setDataSource(ctx, uri)
                w = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toInt() ?: 0
                h = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toInt() ?: 0
                dur = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
            }
            runCatching { r.release() }
        } else {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            runCatching { cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) } }
            w = o.outWidth.coerceAtLeast(0)
            h = o.outHeight.coerceAtLeast(0)
        }
        return Item(uri, name, size, w, h, dur, isVideo, 0L)
    }

    // ---- estimates --------------------------------------------------------------------------------

    private fun hevcEncoder(): Boolean = runCatching {
        MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { ci -> ci.isEncoder && ci.supportedTypes.any { it.equals("video/hevc", true) } }
    }.getOrDefault(false)

    private fun videoBitrate(it: Item, q: Int, hevc: Boolean = hevcEncoder()): Int {
        val dur = max(it.durMs, 1000L)
        val old = it.size * 8.0 * 1000.0 / dur // bits per second of the whole file
        val keep = VIDEO_KEEP[q.coerceIn(0, 2)] * (if (hevc) 1.0 else 1.35)
        val floor = it.w.toDouble() * it.h * 30.0 * 0.03   // never below 0.03 bits per pixel at 30 fps
        val v = max(old * keep, floor).coerceAtMost(old * 0.85)
        return v.toLong().coerceIn(150_000L, 80_000_000L).toInt()
    }

    /**
     * The "Recommended" choice (q = -1): the level that suits THIS file. Balanced (about half the size, looks the same), or Small where the
     * file is far bigger than it needs to be: a video with a very high bit rate (a camera / screen recording, more than 0.25 bits per pixel
     * at 30 fps) and a photo of more than 16 megapixels. Music and comics: Balanced. Never Tiny.
     */
    fun recommended(it: Item): Int {
        if (it.video) {
            if (it.w <= 0 || it.h <= 0) return 0
            val bps = it.size * 8.0 * 1000.0 / max(it.durMs, 1000L)
            return if (bps / (it.w.toDouble() * it.h * 30.0) > 0.25) 1 else 0
        }
        if (isAudioName(it.name)) return 0
        if (it.name.lowercase().let { n -> n.endsWith(".cbz") || n.endsWith(".zip") || n.endsWith(".cb7") || n.endsWith(".7z") }) return 0
        return if (it.w.toLong() * it.h > 16_000_000L) 1 else 0
    }

    /** The real level of a file: [q] itself, or the recommended one when [q] is -1. */
    fun levelFor(it: Item, q: Int): Int = if (q < 0) recommended(it) else q.coerceIn(0, 2)

    /** About how many bytes the result will have (a guess shown before the work starts). */
    fun estimate(it: Item, q0: Int): Long {
        val q = levelFor(it, q0)
        if (!it.video && isAudioName(it.name)) {
            val est = AUDIO_KBPS[q.coerceIn(0, 2)] * 1000L / 8L * max(it.durMs, 1000L) / 1000L // stereo; mono is half of it
            return if (it.durMs > 0) minOf(est, it.size) else (it.size * 0.4f).toLong()
        }
        if (!it.video && it.name.lowercase().let { n -> n.endsWith(".cbz") || n.endsWith(".zip") || n.endsWith(".cb7") || n.endsWith(".7z") }) return (it.size * floatArrayOf(0.6f, 0.45f, 0.33f)[q.coerceIn(0, 2)]).toLong()
        if (!it.video) return (it.size * PHOTO_KEEP[q.coerceIn(0, 2)]).toLong()
        val dur = max(it.durMs, 1000L)
        return videoBitrate(it, q).toLong() * dur / 8000L
    }

    // ---- photo ------------------------------------------------------------------------------------

    fun photo(ctx: Context, it: Item, q: Int, cancel: AtomicBoolean): Result {
        val cr = ctx.contentResolver
        var out: Uri? = null
        var ok = false
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            cr.openInputStream(it.uri)?.use { s -> BitmapFactory.decodeStream(s, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return Result(it, null, 0, "unreadable")
            val cap = if (q >= 2) PHOTO_TINY_SIDE else 8000
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= cap) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bm = cr.openInputStream(it.uri)?.use { s -> BitmapFactory.decodeStream(s, null, opts) } ?: return Result(it, null, 0, "unreadable")
            if (cancel.get()) return Result(it, null, 0, "cancelled")
            val orient = runCatching { cr.openInputStream(it.uri)?.use { s -> ExifInterface(s).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) } }.getOrNull() ?: 1
            val mx = Matrix()
            when (orient) {
                2 -> mx.postScale(-1f, 1f)
                3 -> mx.postRotate(180f)
                4 -> mx.postScale(1f, -1f)
                5 -> { mx.postRotate(90f); mx.postScale(-1f, 1f) }
                6 -> mx.postRotate(90f)
                7 -> { mx.postRotate(270f); mx.postScale(-1f, 1f) }
                8 -> mx.postRotate(270f)
            }
            val longSide = max(bm.width, bm.height)
            if (q >= 2 && longSide > cap) {
                val k = cap.toFloat() / longSide
                mx.postScale(k, k)
            }
            if (!mx.isIdentity) {
                val rb = Bitmap.createBitmap(bm, 0, 0, bm.width, bm.height, mx, true)
                if (rb !== bm) { bm.recycle(); bm = rb }
            }
            val cv = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, it.name.substringBeforeLast('.') + "_small.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/$FOLDER")
                put(MediaStore.Images.Media.IS_PENDING, 1)
                if (it.dateTaken > 0) put(MediaStore.Images.Media.DATE_TAKEN, it.dateTaken)
            }
            val o = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: return Result(it, null, 0, "cannot create the file")
            out = o
            cr.openOutputStream(o)?.use { os -> bm.compress(Bitmap.CompressFormat.JPEG, PHOTO_Q[q.coerceIn(0, 2)], os) }
            bm.recycle()
            cr.update(o, ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }, null, null)
            val size = sizeOf(ctx, o)
            if (size <= 0L) return Result(it, null, size, "empty file")
            if (it.size > 0 && size >= it.size * 0.92) return Result(it, null, size, "no gain")
            ok = true
            return Result(it, o, size, null)
        } catch (t: Throwable) {
            return Result(it, null, 0, t.message ?: t.javaClass.simpleName)
        } finally {
            val o = out
            if (o != null && !ok) runCatching { cr.delete(o, null, null) }
        }
    }

    private fun sizeOf(ctx: Context, u: Uri): Long = runCatching {
        ctx.contentResolver.query(u, arrayOf(MediaStore.MediaColumns.SIZE), null, null, null)?.use { if (it.moveToFirst()) it.getLong(0) else 0L }
    }.getOrNull() ?: 0L

    // ---- video ------------------------------------------------------------------------------------

    private fun intOr(f: MediaFormat, key: String, def: Int): Int {
        if (!f.containsKey(key)) return def
        return try { f.getInteger(key) } catch (e: Exception) { try { f.getFloat(key).toInt() } catch (e2: Exception) { def } }
    }

    /** A video, with a second try when the first one gives nothing: H.264 when the H.265 encoder failed, "Tiny" when the result was not smaller. */
    fun video(ctx: Context, it: Item, q: Int, cancel: AtomicBoolean, progress: (Float) -> Unit): Result {
        var r = videoTry(ctx, it, q, cancel, progress, false)
        val final = setOf("cancelled", "HDR", "already small", "no video")
        if (r.out == null && r.error !in final) {
            if (r.error == "no gain") {
                if (q < 2) r = videoTry(ctx, it, 2, cancel, progress, false)
            } else if (hevcEncoder()) {
                val first = r.error
                r = videoTry(ctx, it, q, cancel, progress, true) // the H.265 encoder failed: the same with H.264
                if (r.out == null && r.error != "no gain") return Result(it, null, 0, "$first / ${r.error}")
            }
        }
        return r
    }

    private fun videoTry(ctx: Context, it: Item, q: Int, cancel: AtomicBoolean, progress: (Float) -> Unit, forceAvc: Boolean): Result {
        var stage = "start"
        val cr = ctx.contentResolver
        val ex = MediaExtractor()
        var ax: MediaExtractor? = null
        var dec: MediaCodec? = null
        var enc: MediaCodec? = null
        var mux: MediaMuxer? = null
        var encSurface: Surface? = null
        var pfd: ParcelFileDescriptor? = null
        var out: Uri? = null
        var ok = false
        var muxStarted = false
        try {
            ex.setDataSource(ctx, it.uri, null)
            var vt = -1
            var at = -1
            for (i in 0 until ex.trackCount) {
                val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
                if (vt < 0 && mime.startsWith("video/")) vt = i
                if (at < 0 && mime.startsWith("audio/")) at = i
            }
            if (vt < 0) return Result(it, null, 0, "no video")
            val vf = ex.getTrackFormat(vt)
            val vmime = vf.getString(MediaFormat.KEY_MIME) ?: return Result(it, null, 0, "no video")
            val w = vf.getInteger(MediaFormat.KEY_WIDTH)
            val h = vf.getInteger(MediaFormat.KEY_HEIGHT)
            val rot = intOr(vf, MediaFormat.KEY_ROTATION, 0)
            val tr = intOr(vf, MediaFormat.KEY_COLOR_TRANSFER, -1)
            if (tr == MediaFormat.COLOR_TRANSFER_ST2084 || tr == MediaFormat.COLOR_TRANSFER_HLG) return Result(it, null, 0, "HDR")
            val durUs = if (vf.containsKey(MediaFormat.KEY_DURATION)) vf.getLong(MediaFormat.KEY_DURATION) else it.durMs * 1000L
            val fps = intOr(vf, MediaFormat.KEY_FRAME_RATE, 30).coerceIn(10, 60)
            val item = if (it.w > 0 && it.durMs > 0) it else Item(it.uri, it.name, it.size, w, h, durUs / 1000L, true, it.dateTaken)
            val useHevc = !forceAvc && hevcEncoder()
            val emime = if (useHevc) MediaFormat.MIMETYPE_VIDEO_HEVC else MediaFormat.MIMETYPE_VIDEO_AVC
            val br = videoBitrate(item, q, useHevc)
            // a file that is already H.265 and thin gains nothing
            if (vmime.equals(MediaFormat.MIMETYPE_VIDEO_HEVC, true)) {
                val bpp = (item.size * 8.0 / max(item.durMs, 1000L) * 1000.0) / (w.toDouble() * h * fps)
                if (bpp < 0.05) return Result(it, null, 0, "already small")
            }

            val ef = MediaFormat.createVideoFormat(emime, w, h).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, br)
                setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
                setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
            }
            stage = "encoder"
            val e = MediaCodec.createEncoderByType(emime)
            enc = e
            e.configure(ef, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            encSurface = e.createInputSurface()
            e.start()

            vf.setInteger(MediaFormat.KEY_ROTATION, 0) // the turn goes into the file as a hint; the pictures stay as stored
            stage = "decoder"
            val d = MediaCodec.createDecoderByType(vmime)
            dec = d
            d.configure(vf, encSurface, null, 0)
            d.start()
            ex.selectTrack(vt)

            val cv = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, it.name.substringBeforeLast('.') + "_small.mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/$FOLDER")
                put(MediaStore.Video.Media.IS_PENDING, 1)
                if (it.dateTaken > 0) put(MediaStore.Video.Media.DATE_TAKEN, it.dateTaken)
            }
            val o = cr.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv) ?: return Result(it, null, 0, "cannot create the file")
            out = o
            pfd = cr.openFileDescriptor(o, "rw") ?: return Result(it, null, 0, "cannot create the file")
            val m = MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            mux = m
            if (rot == 0 || rot == 90 || rot == 180 || rot == 270) m.setOrientationHint(rot)
            if (at >= 0) {
                ax = MediaExtractor().also { a -> a.setDataSource(ctx, it.uri, null); a.selectTrack(at) }
            }

            stage = "converting"
            var lastMove = System.nanoTime()
            val info = MediaCodec.BufferInfo()
            val einfo = MediaCodec.BufferInfo()
            var inDone = false
            var decDone = false
            var encDone = false
            var vTrack = -1
            var aTrack = -1
            while (!encDone) {
                if (cancel.get()) throw IllegalStateException("cancelled")
                if (System.nanoTime() - lastMove > 30_000_000_000L) throw IllegalStateException("the phone's video codec stopped answering")
                if (!inDone) {
                    val ii = d.dequeueInputBuffer(2000)
                    if (ii >= 0) {
                        lastMove = System.nanoTime()
                        val buf = d.getInputBuffer(ii)!!
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0) {
                            d.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            d.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                if (!decDone) {
                    val oi = d.dequeueOutputBuffer(info, 0)
                    if (oi >= 0) {
                        val eos = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                        if (info.size > 0 && info.presentationTimeUs >= 0) {
                            // drawn into the encoder's surface, stamped with the frame's own time
                            d.releaseOutputBuffer(oi, info.presentationTimeUs * 1000L)
                            if (durUs > 0) progress((info.presentationTimeUs.toFloat() / durUs).coerceIn(0f, 1f))
                        } else {
                            d.releaseOutputBuffer(oi, false)
                        }
                        if (eos) {
                            e.signalEndOfInputStream()
                            decDone = true
                        }
                    }
                }
                val ei = e.dequeueOutputBuffer(einfo, 5000)
                if (ei != MediaCodec.INFO_TRY_AGAIN_LATER) lastMove = System.nanoTime()
                when {
                    ei == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        vTrack = m.addTrack(e.outputFormat)
                        val a = ax
                        if (a != null) aTrack = try { m.addTrack(a.getTrackFormat(0)) } catch (t: Exception) { -1 } // a sound the MP4 file cannot hold: left out
                        m.start()
                        muxStarted = true
                    }
                    ei >= 0 -> {
                        val ob = e.getOutputBuffer(ei)
                        if ((einfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) einfo.size = 0
                        if (einfo.size > 0 && muxStarted && ob != null) {
                            ob.position(einfo.offset)
                            ob.limit(einfo.offset + einfo.size)
                            m.writeSampleData(vTrack, ob, einfo)
                        }
                        if ((einfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) encDone = true
                        e.releaseOutputBuffer(ei, false)
                    }
                }
            }
            stage = "sound"
            // the sound is copied untouched after the picture
            val a = ax
            if (a != null && aTrack >= 0 && muxStarted) {
                val buf = ByteBuffer.allocate(2 shl 20)
                val bi = MediaCodec.BufferInfo()
                while (true) {
                    if (cancel.get()) throw IllegalStateException("cancelled")
                    buf.clear()
                    val n = a.readSampleData(buf, 0)
                    if (n < 0) break
                    bi.set(0, n, a.sampleTime, a.sampleFlags)
                    m.writeSampleData(aTrack, buf, bi)
                    a.advance()
                }
            }
            stage = "saving"
            if (muxStarted) { m.stop(); muxStarted = false } else throw IllegalStateException("nothing was encoded")
            mux = null
            m.release()
            val descriptorToClose = pfd
            if (descriptorToClose != null) runCatching { descriptorToClose.close() }
            pfd = null
            cr.update(o, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
            val size = sizeOf(ctx, o)
            if (size <= 0L) return Result(it, null, size, "empty file")
            if (it.size > 0 && size >= it.size * 0.92) return Result(it, null, size, "no gain")
            ok = true
            progress(1f)
            return Result(it, o, size, null)
        } catch (t: Throwable) {
            return Result(it, null, 0, if (t.message == "cancelled") "cancelled" else "${t.message ?: t.javaClass.simpleName} ($stage)")
        } finally {
            runCatching { dec?.stop() }
            runCatching { dec?.release() }
            runCatching { enc?.stop() }
            runCatching { enc?.release() }
            runCatching { encSurface?.release() }
            runCatching { if (muxStarted) mux?.stop() }
            runCatching { mux?.release() }
            runCatching { ax?.release() }
            runCatching { ex.release() }
            runCatching { pfd?.close() }
            val o = out
            if (o != null && !ok) runCatching { cr.delete(o, null, null) }
        }
    }

    // ---- comics (CBZ / ZIP) ---------------------------------------------------------------------

    private val COMIC_Q = intArrayOf(82, 72, 62)         // WebP quality of the pages
    private val COMIC_SIDE = intArrayOf(3000, 2200, 1600) // longest side a page may keep

    /** A comic file the person picked: every page is written again as lossy WebP (and not larger than the steps above); other files inside are copied. */
    fun comicItem(ctx: Context, uri: Uri): Item? {
        var name = "comic.cbz"
        var size = 0L
        runCatching {
            ctx.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME, android.provider.OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) { name = c.getString(0) ?: name; size = c.getLong(1) }
            }
        }
        val ln = name.lowercase()
        if (!ln.endsWith(".cbz") && !ln.endsWith(".zip") && !ln.endsWith(".cb7") && !ln.endsWith(".7z")) return null
        return Item(uri, name, size, 0, 0, 0L, false, 0L)
    }

    fun comic(ctx: Context, it: Item, q: Int, cancel: AtomicBoolean, progress: (Float) -> Unit): Result {
        val cr = ctx.contentResolver
        var out: Uri? = null
        var ok = false
        var stage = "start"
        try {
            val qi = q.coerceIn(0, 2)
            val cv = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, it.name.substringBeforeLast('.') + "_small.cbz")
                put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
                put(MediaStore.Downloads.RELATIVE_PATH, "Download/$FOLDER")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val o = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: return Result(it, null, 0, "cannot create the file")
            out = o
            stage = "reading"
            val os = cr.openOutputStream(o) ?: return Result(it, null, 0, "cannot create the file")
            var done = 0L
            java.util.zip.ZipOutputStream(java.io.BufferedOutputStream(os, 1 shl 16)).use { zout ->
                zout.setLevel(6)
                // one entry of the source: pages are made smaller, other files are copied
                fun emit(entryName: String, bytes: ByteArray) {
                    done += bytes.size
                    if (it.size > 0) progress((done.toFloat() / (it.size * 1.05f)).coerceIn(0f, 0.99f))
                    val ext = entryName.substringAfterLast('.', "").lowercase()
                    var name = entryName
                    var data = bytes
                    if (ext == "jpg" || ext == "jpeg" || ext == "png" || ext == "webp" || ext == "bmp") {
                        stage = "page " + entryName.takeLast(24)
                        val small = pageToWebp(bytes, COMIC_Q[qi], COMIC_SIDE[qi])
                        if (small != null && small.size < bytes.size * 0.92) {
                            data = small
                            name = entryName.substringBeforeLast('.', entryName) + ".webp"
                        }
                    }
                    zout.putNextEntry(java.util.zip.ZipEntry(name))
                    zout.write(data)
                    zout.closeEntry()
                }
                val is7z = it.name.lowercase().let { n -> n.endsWith(".7z") || n.endsWith(".cb7") }
                if (!is7z) {
                    val input = cr.openInputStream(it.uri) ?: throw IllegalStateException("unreadable")
                    java.util.zip.ZipInputStream(java.io.BufferedInputStream(input, 1 shl 16)).use { zin ->
                        while (true) {
                            if (cancel.get()) throw IllegalStateException("cancelled")
                            val e = zin.nextEntry ?: break
                            if (e.isDirectory) { zin.closeEntry(); continue }
                            emit(e.name, zin.readBytes())
                            zin.closeEntry()
                        }
                    }
                } else {
                    // 7z needs a real file to read from: copied into the cache first, removed afterwards
                    stage = "copying"
                    val tmp = java.io.File(ctx.cacheDir, "shrink_" + System.nanoTime() + ".7z")
                    try {
                        (cr.openInputStream(it.uri) ?: throw IllegalStateException("unreadable")).use { i -> tmp.outputStream().use { x -> i.copyTo(x) } }
                        org.apache.commons.compress.archivers.sevenz.SevenZFile(tmp).use { sz ->
                            while (true) {
                                if (cancel.get()) throw IllegalStateException("cancelled")
                                val e = sz.nextEntry ?: break
                                if (e.isDirectory) continue
                                val bo = java.io.ByteArrayOutputStream(maxOf(1024L, e.size).coerceAtMost(64L shl 20).toInt())
                                val buf = ByteArray(1 shl 16)
                                while (true) { val n = sz.read(buf); if (n < 0) break; bo.write(buf, 0, n) }
                                emit(e.name, bo.toByteArray())
                            }
                        }
                    } finally { tmp.delete() }
                }
            }
            cr.update(o, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
            val size = sizeOf(ctx, o)
            if (size <= 0L) return Result(it, null, size, "empty file")
            if (it.size > 0 && size >= it.size * 0.92) return Result(it, null, size, "no gain")
            ok = true
            progress(1f)
            return Result(it, o, size, null)
        } catch (t: Throwable) {
            return Result(it, null, 0, if (t.message == "cancelled") "cancelled" else "${t.message ?: t.javaClass.simpleName} ($stage)")
        } finally {
            val o = out
            if (o != null && !ok) runCatching { cr.delete(o, null, null) }
        }
    }

    // ---- music ------------------------------------------------------------------------------------

    private val AUDIO_EXT = setOf("mp3", "m4a", "aac", "flac", "wav", "ogg", "opus", "wma", "alac", "amr", "mka")
    private val AUDIO_KBPS = intArrayOf(96, 64, 40)   // stereo AAC bit rate for Balanced / Small / Tiny (half of it for mono)

    fun isAudioName(n: String) = n.substringAfterLast('.', "").lowercase() in AUDIO_EXT

    /** A sound file the person picked. Null when it is not one. */
    fun audioItem(ctx: Context, uri: Uri): Item? {
        var name = "music"
        var size = 0L
        runCatching {
            ctx.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME, android.provider.OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) { name = c.getString(0) ?: name; size = c.getLong(1) }
            }
        }
        val mime = runCatching { ctx.contentResolver.getType(uri) }.getOrNull() ?: ""
        if (!mime.startsWith("audio/") && !isAudioName(name)) return null
        if (!isAudioName(name)) name += ".m4a" // the name decides the way (see [run]); the type said it is sound
        var dur = 0L
        val r = android.media.MediaMetadataRetriever()
        runCatching {
            r.setDataSource(ctx, uri)
            dur = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
        }
        runCatching { r.release() }
        return Item(uri, name, size, 0, 0, dur, false, 0L)
    }

    /** Sound written again as AAC (.m4a): about a third to a half of an MP3 / FLAC. Tags and cover pictures are not copied. */
    fun audio(ctx: Context, it: Item, q: Int, cancel: AtomicBoolean, progress: (Float) -> Unit): Result {
        val cr = ctx.contentResolver
        val ex = MediaExtractor()
        var dec: MediaCodec? = null
        var enc: MediaCodec? = null
        var mux: MediaMuxer? = null
        var pfd: ParcelFileDescriptor? = null
        var out: Uri? = null
        var ok = false
        var muxStarted = false
        var stage = "start"
        try {
            ex.setDataSource(ctx, it.uri, null)
            var at = -1
            for (i in 0 until ex.trackCount) if ((ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { at = i; break }
            if (at < 0) return Result(it, null, 0, "no sound")
            val af = ex.getTrackFormat(at)
            val amime = af.getString(MediaFormat.KEY_MIME) ?: return Result(it, null, 0, "no sound")
            val durUs = if (af.containsKey(MediaFormat.KEY_DURATION)) af.getLong(MediaFormat.KEY_DURATION) else it.durMs * 1000L
            val target = AUDIO_KBPS[q.coerceIn(0, 2)]
            if (durUs > 0 && it.size > 0) {
                val kbps = it.size * 8.0 / (durUs / 1000.0)
                if (kbps <= target * 1.15) return Result(it, null, 0, "already small")
            }
            ex.selectTrack(at)
            stage = "decoder"
            val d = MediaCodec.createDecoderByType(amime)
            dec = d
            d.configure(af, null, null, 0)
            d.start()

            val cv = ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, it.name.substringBeforeLast('.') + "_small.m4a")
                put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
                put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/$FOLDER")
                put(MediaStore.Audio.Media.IS_PENDING, 1)
            }
            val o = cr.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, cv) ?: return Result(it, null, 0, "cannot create the file")
            out = o
            pfd = cr.openFileDescriptor(o, "rw") ?: return Result(it, null, 0, "cannot create the file")
            val m = MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            mux = m

            stage = "converting"
            val info = MediaCodec.BufferInfo()
            val einfo = MediaCodec.BufferInfo()
            var inDone = false
            var decEos = false
            var encEos = false
            var encDone = false
            var track = -1
            var sr = 44100
            var ch = 2
            var pend: ByteArray? = null
            var pendOff = 0
            var pendPts = 0L
            var lastPts = 0L
            var lastMove = System.nanoTime()

            fun makeEncoder(f: MediaFormat) {
                sr = if (f.containsKey(MediaFormat.KEY_SAMPLE_RATE)) f.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
                ch = (if (f.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) f.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2).coerceIn(1, 2)
                val ef = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sr, ch).apply {
                    setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                    setInteger(MediaFormat.KEY_BIT_RATE, target * 1000 * ch / 2)
                    setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 1 shl 16)
                }
                val e = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
                enc = e
                e.configure(ef, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                e.start()
            }

            while (!encDone) {
                if (cancel.get()) throw IllegalStateException("cancelled")
                if (System.nanoTime() - lastMove > 30_000_000_000L) throw IllegalStateException("the phone's sound codec stopped answering")
                if (!inDone) {
                    val ii = d.dequeueInputBuffer(2000)
                    if (ii >= 0) {
                        lastMove = System.nanoTime()
                        val buf = d.getInputBuffer(ii)!!
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0) { d.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                        else { d.queueInputBuffer(ii, 0, n, ex.sampleTime, 0); ex.advance() }
                    }
                }
                if (pend == null && !decEos) {
                    val oi = d.dequeueOutputBuffer(info, 0)
                    if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        lastMove = System.nanoTime()
                        if (enc == null) makeEncoder(d.outputFormat)
                    } else if (oi >= 0) {
                        lastMove = System.nanoTime()
                        if (enc == null) makeEncoder(d.outputFormat)
                        if (info.size > 0) {
                            val ob = d.getOutputBuffer(oi)!!
                            ob.position(info.offset)
                            ob.limit(info.offset + info.size)
                            val bytes = ByteArray(info.size)
                            ob.get(bytes)
                            pend = bytes
                            pendOff = 0
                            pendPts = info.presentationTimeUs
                            if (durUs > 0) progress((info.presentationTimeUs.toFloat() / durUs).coerceIn(0f, 0.99f))
                        }
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) decEos = true
                        d.releaseOutputBuffer(oi, false)
                    }
                }
                val e = enc
                if (e != null) {
                    val p = pend
                    if (p != null) {
                        val ei = e.dequeueInputBuffer(2000)
                        if (ei >= 0) {
                            lastMove = System.nanoTime()
                            val buf = e.getInputBuffer(ei)!!
                            buf.clear()
                            val n = minOf(buf.capacity(), p.size - pendOff)
                            buf.put(p, pendOff, n)
                            val pts = pendPts + (pendOff / (2L * ch)) * 1_000_000L / sr
                            e.queueInputBuffer(ei, 0, n, pts, 0)
                            lastPts = pts
                            pendOff += n
                            if (pendOff >= p.size) pend = null
                        }
                    } else if (decEos && !encEos) {
                        val ei = e.dequeueInputBuffer(2000)
                        if (ei >= 0) { e.queueInputBuffer(ei, 0, 0, lastPts, MediaCodec.BUFFER_FLAG_END_OF_STREAM); encEos = true }
                    }
                    val eo = e.dequeueOutputBuffer(einfo, 2000)
                    if (eo == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        lastMove = System.nanoTime()
                        track = m.addTrack(e.outputFormat)
                        m.start()
                        muxStarted = true
                    } else if (eo >= 0) {
                        lastMove = System.nanoTime()
                        val ob = e.getOutputBuffer(eo)
                        if ((einfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) einfo.size = 0
                        if (einfo.size > 0 && muxStarted && ob != null) {
                            ob.position(einfo.offset)
                            ob.limit(einfo.offset + einfo.size)
                            m.writeSampleData(track, ob, einfo)
                        }
                        if ((einfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) encDone = true
                        e.releaseOutputBuffer(eo, false)
                    }
                }
            }
            stage = "saving"
            if (muxStarted) { m.stop(); muxStarted = false } else throw IllegalStateException("nothing was encoded")
            mux = null
            m.release()
            runCatching { pfd?.close() }
            pfd = null
            cr.update(o, ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }, null, null)
            val size = sizeOf(ctx, o)
            if (size <= 0L) return Result(it, null, size, "empty file")
            if (it.size > 0 && size >= it.size * 0.92) return Result(it, null, size, "no gain")
            ok = true
            progress(1f)
            return Result(it, o, size, null)
        } catch (t: Throwable) {
            return Result(it, null, 0, if (t.message == "cancelled") "cancelled" else "${t.message ?: t.javaClass.simpleName} ($stage)")
        } finally {
            runCatching { dec?.stop() }
            runCatching { dec?.release() }
            runCatching { enc?.stop() }
            runCatching { enc?.release() }
            runCatching { if (muxStarted) mux?.stop() }
            runCatching { mux?.release() }
            runCatching { ex.release() }
            runCatching { pfd?.close() }
            val o = out
            if (o != null && !ok) runCatching { cr.delete(o, null, null) }
        }
    }

    private fun pageToWebp(bytes: ByteArray, quality: Int, maxSide: Int): ByteArray? {
        val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, b)
        if (b.outWidth <= 0 || b.outHeight <= 0) return null
        var sample = 1
        while (max(b.outWidth, b.outHeight) / (sample * 2) >= maxSide) sample *= 2
        var bm = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return null
        val side = max(bm.width, bm.height)
        if (side > maxSide) {
            val k = maxSide.toFloat() / side
            val sb = Bitmap.createScaledBitmap(bm, max(1, (bm.width * k).toInt()), max(1, (bm.height * k).toInt()), true)
            if (sb !== bm) { bm.recycle(); bm = sb }
        }
        val bo = java.io.ByteArrayOutputStream(bytes.size / 2)
        val okc = bm.compress(Bitmap.CompressFormat.WEBP_LOSSY, quality, bo)
        bm.recycle()
        return if (okc) bo.toByteArray() else null
    }

    /** One item, the right way for its kind. */
    fun run(ctx: Context, it: Item, q0: Int, cancel: AtomicBoolean, progress: (Float) -> Unit): Result {
        val q = levelFor(it, q0)
        return runLevel(ctx, it, q, cancel, progress)
    }

    private fun runLevel(ctx: Context, it: Item, q: Int, cancel: AtomicBoolean, progress: (Float) -> Unit): Result =
        if (it.video) video(ctx, it, q, cancel, progress)
        else if (isAudioName(it.name)) audio(ctx, it, q, cancel, progress)
        else if (it.name.lowercase().let { n -> n.endsWith(".cbz") || n.endsWith(".zip") || n.endsWith(".cb7") || n.endsWith(".7z") }) comic(ctx, it, q, cancel, progress)
        else photo(ctx, it, q, cancel).also { progress(1f) }
}
