package app.clearoverlay

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.view.Surface
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

/**
 * "Free up space" without a computer or the cloud: the biggest videos and photos of the phone are written again, smaller, into
 * Movies / Pictures / ClearOverlay / Shrunk. The original is never touched; the screen offers to delete it afterwards (the phone's
 * own "allow" box), and only for files that really got smaller.
 *  - Video: decoded and encoded again as HEVC (H.265, about half the size of H.264 for the same look; H.264 when the phone has no
 *    HEVC encoder), the picture size and the frame times are kept, the sound is copied as it is. HDR videos are skipped.
 *  - Photo (JPEG): written again as JPEG at a lower quality (and, for "Tiny", at most 3000 px on the long side). The turn (EXIF
 *    orientation) is applied to the pixels; other EXIF data (GPS, camera) is not copied, the date taken is.
 */
object Shrink {
    const val FOLDER = "ClearOverlay/Shrunk"

    class Item(
        val uri: Uri,
        val name: String,
        val size: Long,
        val w: Int,
        val h: Int,
        val durMs: Long,
        val video: Boolean,
        val dateTaken: Long
    )

    class Result(val item: Item, val out: Uri?, val outSize: Long, val error: String?)

    /** Quality steps: 0 Balanced, 1 Small, 2 Tiny. */
    private val VIDEO_KEEP = floatArrayOf(0.55f, 0.40f, 0.28f)    // share of the old bit rate kept (H.265)
    private val PHOTO_Q = intArrayOf(88, 80, 70)
    private val PHOTO_KEEP = floatArrayOf(0.55f, 0.40f, 0.28f)    // rough share of the old size kept
    private const val PHOTO_TINY_SIDE = 3000

    // ---- lists ------------------------------------------------------------------------------------

    fun listVideos(ctx: Context): List<Item> {
        val out = ArrayList<Item>()
        val m = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.SIZE, MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.WIDTH, MediaStore.Video.Media.HEIGHT, MediaStore.Video.Media.RELATIVE_PATH, MediaStore.Video.Media.DATE_TAKEN
        )
        runCatching {
            ctx.contentResolver.query(m, proj, null, null, MediaStore.Video.Media.SIZE + " DESC")?.use { c ->
                while (c.moveToNext() && out.size < 300) {
                    val size = c.getLong(2)
                    if (size < 8_000_000L) break // sorted by size: everything after this is small
                    if ((c.getString(6) ?: "").contains(FOLDER)) continue
                    out.add(Item(Uri.withAppendedPath(m, c.getLong(0).toString()), c.getString(1) ?: "video", size, c.getInt(4), c.getInt(5), c.getLong(3), true, c.getLong(7)))
                }
            }
        }
        return out
    }

    fun listPhotos(ctx: Context): List<Item> {
        val out = ArrayList<Item>()
        val m = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.SIZE, MediaStore.Images.Media.WIDTH,
            MediaStore.Images.Media.HEIGHT, MediaStore.Images.Media.RELATIVE_PATH, MediaStore.Images.Media.DATE_TAKEN
        )
        runCatching {
            ctx.contentResolver.query(m, proj, MediaStore.Images.Media.MIME_TYPE + "=?", arrayOf("image/jpeg"), MediaStore.Images.Media.SIZE + " DESC")?.use { c ->
                while (c.moveToNext() && out.size < 400) {
                    val size = c.getLong(2)
                    if (size < 1_200_000L) break
                    if ((c.getString(5) ?: "").contains(FOLDER)) continue
                    out.add(Item(Uri.withAppendedPath(m, c.getLong(0).toString()), c.getString(1) ?: "photo", size, c.getInt(3), c.getInt(4), 0L, false, c.getLong(6)))
                }
            }
        }
        return out
    }

    // ---- estimates --------------------------------------------------------------------------------

    private fun hevcEncoder(): Boolean = runCatching {
        MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { ci -> ci.isEncoder && ci.supportedTypes.any { it.equals("video/hevc", true) } }
    }.getOrDefault(false)

    private fun videoBitrate(it: Item, q: Int): Int {
        val dur = max(it.durMs, 1000L)
        val old = it.size * 8.0 * 1000.0 / dur // bits per second of the whole file
        val keep = VIDEO_KEEP[q.coerceIn(0, 2)] * (if (hevcEncoder()) 1.0 else 1.35)
        val floor = it.w.toDouble() * it.h * 30.0 * 0.03   // never below 0.03 bits per pixel at 30 fps
        val v = max(old * keep, floor).coerceAtMost(old * 0.85)
        return v.toLong().coerceIn(150_000L, 80_000_000L).toInt()
    }

    /** About how many bytes the result will have (a guess shown before the work starts). */
    fun estimate(it: Item, q: Int): Long {
        if (!it.video) return (it.size * PHOTO_KEEP[q.coerceIn(0, 2)]).toLong()
        val dur = max(it.durMs, 1000L)
        return videoBitrate(it, q).toLong() * dur / 8000L
    }

    // ---- photo ------------------------------------------------------------------------------------

    fun photo(ctx: Context, it: Item, q: Int, cancel: AtomicBoolean): Result {
        val cr = ctx.contentResolver
        var out: Uri? = null
        var ok = false
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            cr.openInputStream(it.uri)?.use { s -> BitmapFactory.decodeStream(s, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return Result(it, null, 0, "unreadable")
            val cap = if (q >= 2) PHOTO_TINY_SIDE else 8000
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= cap) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bm = cr.openInputStream(it.uri)?.use { s -> BitmapFactory.decodeStream(s, null, opts) } ?: return Result(it, null, 0, "unreadable")
            if (cancel.get()) return Result(it, null, 0, "cancelled")
            val orient = runCatching { cr.openInputStream(it.uri)?.use { s -> ExifInterface(s).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) } }.getOrNull() ?: 1
            val mx = Matrix()
            when (orient) {
                2 -> mx.postScale(-1f, 1f)
                3 -> mx.postRotate(180f)
                4 -> mx.postScale(1f, -1f)
                5 -> { mx.postRotate(90f); mx.postScale(-1f, 1f) }
                6 -> mx.postRotate(90f)
                7 -> { mx.postRotate(270f); mx.postScale(-1f, 1f) }
                8 -> mx.postRotate(270f)
            }
            val longSide = max(bm.width, bm.height)
            if (q >= 2 && longSide > cap) {
                val k = cap.toFloat() / longSide
                mx.postScale(k, k)
            }
            if (!mx.isIdentity) {
                val rb = Bitmap.createBitmap(bm, 0, 0, bm.width, bm.height, mx, true)
                if (rb !== bm) { bm.recycle(); bm = rb }
            }
            val cv = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, it.name.substringBeforeLast('.') + "_small.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/$FOLDER")
                put(MediaStore.Images.Media.IS_PENDING, 1)
                if (it.dateTaken > 0) put(MediaStore.Images.Media.DATE_TAKEN, it.dateTaken)
            }
            val o = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: return Result(it, null, 0, "cannot create the file")
            out = o
            cr.openOutputStream(o)?.use { os -> bm.compress(Bitmap.CompressFormat.JPEG, PHOTO_Q[q.coerceIn(0, 2)], os) }
            bm.recycle()
            cr.update(o, ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }, null, null)
            val size = sizeOf(ctx, o)
            if (size <= 0 || size >= it.size * 0.92) return Result(it, null, size, "no gain")
            ok = true
            return Result(it, o, size, null)
        } catch (t: Throwable) {
            return Result(it, null, 0, t.message ?: t.javaClass.simpleName)
        } finally {
            val o = out
            if (o != null && !ok) runCatching { cr.delete(o, null, null) }
        }
    }

    private fun sizeOf(ctx: Context, u: Uri): Long = runCatching {
        ctx.contentResolver.query(u, arrayOf(MediaStore.MediaColumns.SIZE), null, null, null)?.use { if (it.moveToFirst()) it.getLong(0) else 0L }
    }.getOrNull() ?: 0L

    // ---- video ------------------------------------------------------------------------------------

    private fun intOr(f: MediaFormat, key: String, def: Int): Int {
        if (!f.containsKey(key)) return def
        return try { f.getInteger(key) } catch (e: Exception) { try { f.getFloat(key).toInt() } catch (e2: Exception) { def } }
    }

    fun video(ctx: Context, it: Item, q: Int, cancel: AtomicBoolean, progress: (Float) -> Unit): Result {
        val cr = ctx.contentResolver
        val ex = MediaExtractor()
        var ax: MediaExtractor? = null
        var dec: MediaCodec? = null
        var enc: MediaCodec? = null
        var mux: MediaMuxer? = null
        var encSurface: Surface? = null
        var pfd: ParcelFileDescriptor? = null
        var out: Uri? = null
        var ok = false
        var muxStarted = false
        try {
            ex.setDataSource(ctx, it.uri, null)
            var vt = -1
            var at = -1
            for (i in 0 until ex.trackCount) {
                val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
                if (vt < 0 && mime.startsWith("video/")) vt = i
                if (at < 0 && mime.startsWith("audio/")) at = i
            }
            if (vt < 0) return Result(it, null, 0, "no video")
            val vf = ex.getTrackFormat(vt)
            val vmime = vf.getString(MediaFormat.KEY_MIME) ?: return Result(it, null, 0, "no video")
            val w = vf.getInteger(MediaFormat.KEY_WIDTH)
            val h = vf.getInteger(MediaFormat.KEY_HEIGHT)
            val rot = intOr(vf, MediaFormat.KEY_ROTATION, 0)
            val tr = intOr(vf, MediaFormat.KEY_COLOR_TRANSFER, -1)
            if (tr == MediaFormat.COLOR_TRANSFER_ST2084 || tr == MediaFormat.COLOR_TRANSFER_HLG) return Result(it, null, 0, "HDR")
            val durUs = if (vf.containsKey(MediaFormat.KEY_DURATION)) vf.getLong(MediaFormat.KEY_DURATION) else it.durMs * 1000L
            val fps = intOr(vf, MediaFormat.KEY_FRAME_RATE, 30).coerceIn(10, 60)
            val item = if (it.w > 0 && it.durMs > 0) it else Item(it.uri, it.name, it.size, w, h, durUs / 1000L, true, it.dateTaken)
            val useHevc = hevcEncoder()
            val emime = if (useHevc) MediaFormat.MIMETYPE_VIDEO_HEVC else MediaFormat.MIMETYPE_VIDEO_AVC
            val br = videoBitrate(item, q)
            // a file that is already H.265 and thin gains nothing
            if (vmime.equals(MediaFormat.MIMETYPE_VIDEO_HEVC, true)) {
                val bpp = (item.size * 8.0 / max(item.durMs, 1000L) * 1000.0) / (w.toDouble() * h * fps)
                if (bpp < 0.05) return Result(it, null, 0, "already small")
            }

            val ef = MediaFormat.createVideoFormat(emime, w, h).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, br)
                setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
                setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
            }
            val e = MediaCodec.createEncoderByType(emime)
            enc = e
            e.configure(ef, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            encSurface = e.createInputSurface()
            e.start()

            vf.setInteger(MediaFormat.KEY_ROTATION, 0) // the turn goes into the file as a hint; the pictures stay as stored
            val d = MediaCodec.createDecoderByType(vmime)
            dec = d
            d.configure(vf, encSurface, null, 0)
            d.start()
            ex.selectTrack(vt)

            val cv = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, it.name.substringBeforeLast('.') + "_small.mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/$FOLDER")
                put(MediaStore.Video.Media.IS_PENDING, 1)
                if (it.dateTaken > 0) put(MediaStore.Video.Media.DATE_TAKEN, it.dateTaken)
            }
            val o = cr.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv) ?: return Result(it, null, 0, "cannot create the file")
            out = o
            pfd = cr.openFileDescriptor(o, "rw") ?: return Result(it, null, 0, "cannot create the file")
            val m = MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            mux = m
            if (rot == 0 || rot == 90 || rot == 180 || rot == 270) m.setOrientationHint(rot)
            if (at >= 0) {
                ax = MediaExtractor().also { a -> a.setDataSource(ctx, it.uri, null); a.selectTrack(at) }
            }

            val info = MediaCodec.BufferInfo()
            val einfo = MediaCodec.BufferInfo()
            var inDone = false
            var decDone = false
            var encDone = false
            var vTrack = -1
            var aTrack = -1
            while (!encDone) {
                if (cancel.get()) throw IllegalStateException("cancelled")
                if (!inDone) {
                    val ii = d.dequeueInputBuffer(2000)
                    if (ii >= 0) {
                        val buf = d.getInputBuffer(ii)!!
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0) {
                            d.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            d.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                if (!decDone) {
                    val oi = d.dequeueOutputBuffer(info, 0)
                    if (oi >= 0) {
                        val eos = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                        if (info.size > 0 && info.presentationTimeUs >= 0) {
                            // drawn into the encoder's surface, stamped with the frame's own time
                            d.releaseOutputBuffer(oi, info.presentationTimeUs * 1000L)
                            if (durUs > 0) progress((info.presentationTimeUs.toFloat() / durUs).coerceIn(0f, 1f))
                        } else {
                            d.releaseOutputBuffer(oi, false)
                        }
                        if (eos) {
                            e.signalEndOfInputStream()
                            decDone = true
                        }
                    }
                }
                val ei = e.dequeueOutputBuffer(einfo, 5000)
                when {
                    ei == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        vTrack = m.addTrack(e.outputFormat)
                        val a = ax
                        if (a != null) aTrack = try { m.addTrack(a.getTrackFormat(0)) } catch (t: Exception) { -1 } // a sound the MP4 file cannot hold: left out
                        m.start()
                        muxStarted = true
                    }
                    ei >= 0 -> {
                        val ob = e.getOutputBuffer(ei)
                        if ((einfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) einfo.size = 0
                        if (einfo.size > 0 && muxStarted && ob != null) {
                            ob.position(einfo.offset)
                            ob.limit(einfo.offset + einfo.size)
                            m.writeSampleData(vTrack, ob, einfo)
                        }
                        if ((einfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) encDone = true
                        e.releaseOutputBuffer(ei, false)
                    }
                }
            }
            // the sound is copied untouched after the picture
            val a = ax
            if (a != null && aTrack >= 0 && muxStarted) {
                val buf = ByteBuffer.allocate(2 shl 20)
                val bi = MediaCodec.BufferInfo()
                while (true) {
                    if (cancel.get()) throw IllegalStateException("cancelled")
                    buf.clear()
                    val n = a.readSampleData(buf, 0)
                    if (n < 0) break
                    bi.set(0, n, a.sampleTime, a.sampleFlags)
                    m.writeSampleData(aTrack, buf, bi)
                    a.advance()
                }
            }
            if (muxStarted) { m.stop(); muxStarted = false } else throw IllegalStateException("nothing was encoded")
            mux = null
            m.release()
            val descriptorToClose = pfd
            if (descriptorToClose != null) runCatching { descriptorToClose.close() }
            pfd = null
            cr.update(o, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
            val size = sizeOf(ctx, o)
            if (size <= 0 || size >= it.size * 0.92) return Result(it, null, size, "no gain")
            ok = true
            progress(1f)
            return Result(it, o, size, null)
        } catch (t: Throwable) {
            return Result(it, null, 0, t.message ?: t.javaClass.simpleName)
        } finally {
            runCatching { dec?.stop() }
            runCatching { dec?.release() }
            runCatching { enc?.stop() }
            runCatching { enc?.release() }
            runCatching { encSurface?.release() }
            runCatching { if (muxStarted) mux?.stop() }
            runCatching { mux?.release() }
            runCatching { ax?.release() }
            runCatching { ex.release() }
            runCatching { pfd?.close() }
            val o = out
            if (o != null && !ok) runCatching { cr.delete(o, null, null) }
        }
    }

    /** One item, the right way for its kind. */
    fun run(ctx: Context, it: Item, q: Int, cancel: AtomicBoolean, progress: (Float) -> Unit): Result =
        if (it.video) video(ctx, it, q, cancel, progress) else photo(ctx, it, q, cancel).also { progress(1f) }
}
