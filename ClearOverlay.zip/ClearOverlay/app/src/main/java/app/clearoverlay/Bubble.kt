package app.clearoverlay

import android.animation.ValueAnimator
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import kotlin.math.hypot

/**
 * Floating bubble: tap = effect on/off, hold = settings panel, drag = move (snaps to the nearest
 * screen edge). Both windows are excluded from screen capture so they never end up in the processed
 * image. When left idle it dims and slides part-way past the edge it is snapped to ("sleep"); any
 * touch instantly brings it back (that first touch only wakes it, it does not also toggle the effect).
 */
class Bubble(private val svc: OverlayService, private val wm: WindowManager) {
    private val ctx = Ui.themed(svc)
    private val main = Handler(Looper.getMainLooper())
    private var size = dp(ctx, Cfg.bubbleSizeDp.coerceIn(Cfg.BUBBLE_MIN_DP, Cfg.BUBBLE_MAX_DP))
    private val slop = ViewConfiguration.get(svc).scaledTouchSlop

    /** Which side edge the bubble rests on and how far down the usable height it sits (0..1).
     *  Kept as state (not pixels) so rotating the phone re-places it on the same side and height. */
    private var onRight = true
    private var yFrac = 0.25f

    private val logo = LogoView(ctx).apply {
        circle = true
        active = svc.active
        contentDescription = ctx.getString(R.string.bubble_hint)
    }

    private val lp = WindowManager.LayoutParams(
        size, size,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
    }

    private var shown = false
    private var panel: View? = null
    private var panelLp: WindowManager.LayoutParams? = null

    // ---- sleep (auto-hide when idle) -------------------------------------------------------
    private var asleep = false
    private var awakeX = 0
    private var sleepAnimator: ValueAnimator? = null
    private val sleepRunnable = Runnable { sleep() }

    private val touch = object : View.OnTouchListener {
        private var downX = 0f
        private var downY = 0f
        private var startX = 0
        private var startY = 0
        private var moved = false
        private var longFired = false
        private var wokeThisGesture = false
        private var pushedOut = false
        private val longPress = Runnable {
            if (!moved) {
                longFired = true
                logo.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                togglePanel()
            }
        }

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    wokeThisGesture = asleep
                    if (asleep) wake()
                    startX = lp.x
                    startY = lp.y
                    moved = false
                    pushedOut = false
                    longFired = false
                    main.removeCallbacks(sleepRunnable)
                    main.postDelayed(longPress, 450)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!moved && hypot(dx, dy) > slop) {
                        moved = true
                        main.removeCallbacks(longPress)
                        closePanel()
                    }
                    if (moved) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        clampDrag()
                        // Pushed past the screen edge far enough: let go and it falls asleep right away.
                        val out = isPushedOut()
                        if (out && !pushedOut) logo.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                        pushedOut = out
                        runCatching { wm.updateViewLayout(logo, lp) }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    main.removeCallbacks(longPress)
                    when {
                        moved -> snapToEdge(sleepNow = pushedOut)
                        longFired -> {} // panel already opened/closed by the long-press callback
                        wokeThisGesture -> scheduleSleep() // this tap only woke it up
                        else -> {
                            svc.toggle()
                            scheduleSleep()
                        }
                    }
                }
                MotionEvent.ACTION_CANCEL -> {
                    main.removeCallbacks(longPress)
                    scheduleSleep()
                }
            }
            return true
        }
    }

    init {
        if (Cfg.bubbleYf >= 0f) {
            onRight = Cfg.bubbleRight
            yFrac = Cfg.bubbleYf
        } else if (Cfg.bubbleX >= 0) {
            // settings saved by an older version (pixels): convert once
            lp.x = Cfg.bubbleX
            lp.y = Cfg.bubbleY.coerceAtLeast(0)
            captureState()
        }
        placeFromState()
        awakeX = lp.x
        Win.excludeFromCapture(lp)
        logo.setOnTouchListener(touch)
    }

    private fun bounds() = wm.maximumWindowMetrics.bounds

    /** System bars + display cutout, so the bubble never hides under a notch or the nav bar. */
    private fun ins() = wm.maximumWindowMetrics.windowInsets.getInsetsIgnoringVisibility(
        android.view.WindowInsets.Type.systemBars() or android.view.WindowInsets.Type.displayCutout()
    )

    private fun minXe() = ins().left
    private fun maxXe() = (bounds().width() - ins().right - size).coerceAtLeast(minXe())
    // Keep clear of the top and bottom corners (hard to reach with a thumb). The margin is the same
    // at both ends and measured from the screen edge; system bars / cutouts only matter if bigger.
    private fun cornerMargin() = maxOf(dp(ctx, 56), (bounds().height() * 0.07f).toInt())
    private fun minYe() = maxOf(ins().top, cornerMargin())
    private fun maxYe() = (bounds().height() - maxOf(ins().bottom, cornerMargin()) - size).coerceAtLeast(minYe())

    /** Puts the bubble on its remembered side edge and height for the current screen size. */
    private fun placeFromState() {
        lp.x = if (onRight) maxXe() else minXe()
        lp.y = minYe() + (yFrac.coerceIn(0f, 1f) * (maxYe() - minYe())).toInt()
    }

    /** Remembers the side and relative height from the current pixel position. */
    private fun captureState() {
        onRight = lp.x + size / 2 > bounds().width() / 2
        val range = (maxYe() - minYe()).coerceAtLeast(1)
        yFrac = ((lp.y - minYe()).toFloat() / range).coerceIn(0f, 1f)
    }

    private fun clamp() {
        lp.x = lp.x.coerceIn(minXe(), maxXe())
        lp.y = lp.y.coerceIn(minYe(), maxYe())
    }

    /** While dragging, the bubble may poke past the screen edge by the sleep offset (not further). */
    private fun clampDrag() {
        val over = (size * Cfg.BUBBLE_SLEEP_FRACTION).toInt()
        lp.x = lp.x.coerceIn(minXe() - over, maxXe() + over)
        lp.y = lp.y.coerceIn(minYe(), maxYe())
    }

    /** True once the drag has pushed the bubble about 60% of the sleep offset past a side edge. */
    private fun isPushedOut(): Boolean {
        val need = (size * Cfg.BUBBLE_SLEEP_FRACTION * 0.6f).toInt().coerceAtLeast(1)
        return lp.x <= minXe() - need || lp.x >= maxXe() + need
    }

    private fun snapToEdge(sleepNow: Boolean = false) {
        captureState()
        placeFromState()
        runCatching { wm.updateViewLayout(logo, lp) }
        awakeX = lp.x
        Cfg.bubbleRight = onRight
        Cfg.bubbleYf = yFrac
        Cfg.save(svc)
        if (sleepNow) sleep(force = true) else scheduleSleep()
    }

    /** Cancels any pending/running sleep and instantly restores full position + opacity. */
    private fun wake() {
        main.removeCallbacks(sleepRunnable)
        sleepAnimator?.cancel()
        sleepAnimator = null
        if (!asleep) return
        asleep = false
        lp.x = awakeX
        logo.alpha = 1f
        runCatching { wm.updateViewLayout(logo, lp) }
    }

    /** Smoothly dims the bubble and slides it part-way past the edge it is resting on. */
    private fun sleep(force: Boolean = false) {
        if (asleep || panel != null || !shown || (!Cfg.bubbleSleep && !force)) return
        val toRight = onRight
        val offset = (size * Cfg.BUBBLE_SLEEP_FRACTION).toInt()
        val targetX = if (toRight) awakeX + offset else awakeX - offset
        val fromX = lp.x
        val fromAlpha = logo.alpha
        asleep = true
        sleepAnimator?.cancel()
        sleepAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 220
            addUpdateListener { a ->
                val t = a.animatedValue as Float
                lp.x = (fromX + (targetX - fromX) * t).toInt()
                logo.alpha = fromAlpha + (0.45f - fromAlpha) * t
                runCatching { wm.updateViewLayout(logo, lp) }
            }
            start()
        }
    }

    private fun scheduleSleep() {
        main.removeCallbacks(sleepRunnable)
        if (Cfg.bubbleSleep && panel == null && shown) {
            main.postDelayed(sleepRunnable, Cfg.bubbleSleepSec * 1000L)
        }
    }

    fun show() {
        if (shown) return
        shown = true
        wm.addView(logo, lp)
        logo.post { Win.skipScreenshot(logo) }
        scheduleSleep()
    }

    fun hide() {
        closePanel()
        main.removeCallbacks(sleepRunnable)
        sleepAnimator?.cancel()
        if (!shown) return
        shown = false
        runCatching { wm.removeView(logo) }
    }

    fun onActiveChanged() {
        logo.active = svc.active
    }

    /** Called from the settings panel right after Cfg.bubbleSizeDp changes. */
    fun applySize() {
        val newSize = dp(ctx, Cfg.bubbleSizeDp.coerceIn(Cfg.BUBBLE_MIN_DP, Cfg.BUBBLE_MAX_DP))
        if (newSize == size) return
        wake()
        captureState()
        size = newSize
        lp.width = size
        lp.height = size
        placeFromState()
        awakeX = lp.x
        if (shown) runCatching { wm.updateViewLayout(logo, lp) }
    }

    /** Called from the settings panel when auto-hide is turned off. */
    fun wakeNow() = wake()

    /** Called from the settings panel when auto-hide is turned back on, so idling starts counting
     *  again immediately (otherwise it would only start on the next touch/drag). */
    fun refreshIdleTimer() = scheduleSleep()

    /** Re-adds the windows so they sit above the (re)created processing overlay. */
    fun reattach() {
        main.post {
            if (!shown) return@post
            runCatching { wm.removeView(logo) }
            runCatching { wm.addView(logo, lp) }
            val p = panel
            val plp = panelLp
            if (p != null && plp != null) {
                runCatching { wm.removeView(p) }
                runCatching { wm.addView(p, plp) }
            }
        }
    }

    fun onConfigChanged() {
        closePanel()
        if (asleep) {
            asleep = false
            lp.x = awakeX
            logo.alpha = 1f
        }
        // Rotation: re-place on the same side edge and relative height for the new screen size.
        placeFromState()
        awakeX = lp.x
        if (shown) runCatching { wm.updateViewLayout(logo, lp) }
        scheduleSleep()
    }

    // ---- settings panel -------------------------------------------------------------------

    private fun togglePanel() {
        if (panel != null) closePanel() else openPanel()
    }

    private val fadeRestore = Runnable { panel?.animate()?.alpha(1f)?.setDuration(200)?.start() }

    /** Held slider -> panel nearly transparent so the picture underneath can be judged; restored shortly after release. */
    private fun fadePanel(active: Boolean) {
        val p = panel ?: return
        if (!Cfg.panelFade) return
        main.removeCallbacks(fadeRestore)
        if (active) p.animate().alpha(0.15f).setDuration(120).start() else main.postDelayed(fadeRestore, 1500)
    }

    private fun closePanel() {
        main.removeCallbacks(fadeRestore)
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
        panelLp = null
        scheduleSleep()
    }

    private fun openPanel() {
        if (panel != null || !shown) return
        wake()
        main.removeCallbacks(sleepRunnable)
        val b = bounds()
        val gap = dp(ctx, 8)
        // Landscape has less height to work with, so let the panel use more of the extra width
        // instead of wrapping onto rows that then need scrolling.
        val wCap = if (b.width() > b.height()) dp(ctx, 420) else dp(ctx, 320)
        // Side insets (display cutout / camera hole / side nav bar in landscape): keep the panel clear of them.
        val ins = wm.maximumWindowMetrics.windowInsets.getInsetsIgnoringVisibility(
            android.view.WindowInsets.Type.systemBars() or android.view.WindowInsets.Type.displayCutout()
        )
        val minX = ins.left + gap
        val maxX = b.width() - ins.right - gap
        // The panel opens on the side OPPOSITE the bubble so it never covers it (the bubble stays tappable).
        val room = maxX - minX - size - gap
        val w = minOf(maxX - minX, wCap, room).coerceAtLeast(dp(ctx, 200))

        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.round(Color.parseColor("#F5101522"), dp(ctx, 22).toFloat(), Ui.STROKE, dp(ctx, 1))
            setPadding(dp(ctx, 16), dp(ctx, 14), dp(ctx, 16), dp(ctx, 14))
        }

        val head = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(
            LogoView(ctx).apply { importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO },
            LinearLayout.LayoutParams(dp(ctx, 30), dp(ctx, 30))
        )
        head.addView(
            Ui.text(ctx, "+CRSC", 18f, Ui.TEXT, true).apply { setPadding(dp(ctx, 10), 0, 0, 0) },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        val power = Switch(ctx).apply {
            isChecked = svc.active
            contentDescription = ctx.getString(R.string.effect_toggle_desc)
        }
        power.setOnCheckedChangeListener { _, on -> svc.turn(on) }
        head.addView(power)
        card.addView(head)

        val scroll = ScrollView(ctx).apply {
            isFillViewport = false
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            addView(
                buildControls(ctx, onAdjust = { fadePanel(it) }) { svc.applyConfig() },
                ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )
        }
        card.addView(
            scroll,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(ctx, 12) }
        )

        val foot = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        foot.addView(
            footButton(ctx.getString(R.string.action_stop), Ui.DANGER) { svc.shutdown() },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        foot.addView(
            footButton("✨ " + ctx.getString(R.string.aisnap_button), Ui.ACCENT2) {
                closePanel()
                svc.main.postDelayed({ svc.startAiSnap() }, 200)
            },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.4f)
        )
        foot.addView(
            footButton(ctx.getString(R.string.action_close), Ui.ACCENT) { closePanel() },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        card.addView(
            foot,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(ctx, 10) }
        )

        card.measure(
            View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        var ph = card.measuredHeight
        // Portrait: the panel takes at most about half the screen height (the middle part scrolls).
        val portrait = b.height() >= b.width()
        val maxCardH = if (portrait) minOf(b.height() - gap * 2, (b.height() * 0.5f).toInt()) else b.height() - gap * 2
        if (ph > maxCardH) {
            // Shrink only the scrollable middle by exactly the overflow, so the header and the
            // Stop/Close buttons stay fully visible and reachable; everything else scrolls.
            val scrollH = (scroll.measuredHeight - (ph - maxCardH)).coerceAtLeast(dp(ctx, 120))
            scroll.layoutParams = (scroll.layoutParams as LinearLayout.LayoutParams).apply { height = scrollH }
            card.measure(
                View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
            ph = card.measuredHeight
        }
        val px = if (onRight) minX else (maxX - w).coerceAtLeast(minX)
        // Beside the bubble now, so line the panel up with it vertically and keep it fully on screen.
        val py = lp.y.coerceIn(gap, (b.height() - ph - gap).coerceAtLeast(gap))

        val plp = WindowManager.LayoutParams(
            w, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            // Same as the bubble window: x/y are real screen coordinates even next to a cutout.
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            x = px
            y = py
        }
        Win.excludeFromCapture(plp)

        // A touch outside the panel closes it.
        card.setOnTouchListener { _, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_OUTSIDE) {
                closePanel()
                true
            } else {
                false
            }
        }
        wm.addView(card, plp)
        panel = card
        panelLp = plp
        card.post { Win.skipScreenshot(card) }
    }

    private fun footButton(label: String, color: Int, onClick: () -> Unit): TextView =
        Ui.text(ctx, label, 15f, color, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(ctx, 10), 0, dp(ctx, 10))
            setOnClickListener { onClick() }
        }
}
