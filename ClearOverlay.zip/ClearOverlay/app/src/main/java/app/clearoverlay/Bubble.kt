package app.clearoverlay

import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import kotlin.math.hypot

/**
 * Floating bubble: tap = effect on/off, hold = settings panel, drag = move (snaps to the nearest
 * screen edge). Both windows are excluded from screen capture so they never end up in the processed image.
 */
class Bubble(private val svc: OverlayService, private val wm: WindowManager) {
    private val ctx = Ui.themed(svc)
    private val main = Handler(Looper.getMainLooper())
    private val size = dp(ctx, 52)
    private val slop = ViewConfiguration.get(svc).scaledTouchSlop

    private val logo = LogoView(ctx).apply {
        circle = true
        active = svc.active
    }

    private val lp = WindowManager.LayoutParams(
        size, size,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
    }

    private var shown = false
    private var panel: View? = null
    private var panelLp: WindowManager.LayoutParams? = null

    private val touch = object : View.OnTouchListener {
        private var downX = 0f
        private var downY = 0f
        private var startX = 0
        private var startY = 0
        private var moved = false
        private var longFired = false
        private val longPress = Runnable {
            if (!moved) {
                longFired = true
                logo.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                togglePanel()
            }
        }

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    moved = false
                    longFired = false
                    main.postDelayed(longPress, 450)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!moved && hypot(dx, dy) > slop) {
                        moved = true
                        main.removeCallbacks(longPress)
                        closePanel()
                    }
                    if (moved) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        clamp()
                        runCatching { wm.updateViewLayout(logo, lp) }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    main.removeCallbacks(longPress)
                    if (moved) snapToEdge() else if (!longFired) svc.toggle()
                }
                MotionEvent.ACTION_CANCEL -> main.removeCallbacks(longPress)
            }
            return true
        }
    }

    init {
        val b = bounds()
        lp.x = if (Cfg.bubbleX >= 0) Cfg.bubbleX else b.width() - size
        lp.y = if (Cfg.bubbleY >= 0) Cfg.bubbleY else b.height() / 4
        clamp()
        Win.excludeFromCapture(lp)
        logo.setOnTouchListener(touch)
    }

    private fun bounds() = wm.maximumWindowMetrics.bounds

    private fun clamp() {
        val b = bounds()
        lp.x = lp.x.coerceIn(0, (b.width() - size).coerceAtLeast(0))
        lp.y = lp.y.coerceIn(0, (b.height() - size).coerceAtLeast(0))
    }

    private fun snapToEdge() {
        val b = bounds()
        val toRight = lp.x + size / 2 > b.width() / 2
        lp.x = if (toRight) b.width() - size else 0
        clamp()
        runCatching { wm.updateViewLayout(logo, lp) }
        Cfg.bubbleX = lp.x
        Cfg.bubbleY = lp.y
        Cfg.save(svc)
    }

    fun show() {
        if (shown) return
        shown = true
        wm.addView(logo, lp)
        logo.post { Win.skipScreenshot(logo) }
    }

    fun hide() {
        closePanel()
        if (!shown) return
        shown = false
        runCatching { wm.removeView(logo) }
    }

    fun onActiveChanged() {
        logo.active = svc.active
    }

    /** Re-adds the windows so they sit above the (re)created processing overlay. */
    fun reattach() {
        main.post {
            if (!shown) return@post
            runCatching { wm.removeView(logo) }
            runCatching { wm.addView(logo, lp) }
            val p = panel
            val plp = panelLp
            if (p != null && plp != null) {
                runCatching { wm.removeView(p) }
                runCatching { wm.addView(p, plp) }
            }
        }
    }

    fun onConfigChanged() {
        closePanel()
        clamp()
        if (shown) runCatching { wm.updateViewLayout(logo, lp) }
    }

    // ---- settings panel -------------------------------------------------------------------

    private fun togglePanel() {
        if (panel != null) closePanel() else openPanel()
    }

    private fun closePanel() {
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
        panelLp = null
    }

    private fun openPanel() {
        if (panel != null || !shown) return
        val b = bounds()
        val gap = dp(ctx, 8)
        val w = minOf(b.width() - gap * 2, dp(ctx, 320))

        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.round(Color.parseColor("#F5101522"), dp(ctx, 22).toFloat(), Ui.STROKE, dp(ctx, 1))
            setPadding(dp(ctx, 16), dp(ctx, 14), dp(ctx, 16), dp(ctx, 14))
        }

        val head = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(LogoView(ctx), LinearLayout.LayoutParams(dp(ctx, 30), dp(ctx, 30)))
        head.addView(
            Ui.text(ctx, "+CRSC", 18f, Ui.TEXT, true).apply { setPadding(dp(ctx, 10), 0, 0, 0) },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        val power = Switch(ctx).apply { isChecked = svc.active }
        power.setOnCheckedChangeListener { _, on -> svc.turn(on) }
        head.addView(power)
        card.addView(head)

        card.addView(
            buildControls(ctx) { svc.applyConfig() },
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(ctx, 12) }
        )

        val foot = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        foot.addView(
            footButton("Stop", Ui.DANGER) { svc.shutdown() },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        foot.addView(
            footButton("Close", Ui.ACCENT) { closePanel() },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        card.addView(
            foot,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(ctx, 10) }
        )

        card.measure(
            View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val ph = card.measuredHeight
        val px = (lp.x + size / 2 - w / 2).coerceIn(gap, (b.width() - w - gap).coerceAtLeast(gap))
        val py = if (lp.y + size + gap + ph <= b.height() - gap) {
            lp.y + size + gap
        } else {
            (lp.y - ph - gap).coerceAtLeast(gap)
        }

        val plp = WindowManager.LayoutParams(
            w, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = px
            y = py
        }
        Win.excludeFromCapture(plp)

        // A touch outside the panel closes it.
        card.setOnTouchListener { _, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_OUTSIDE) {
                closePanel()
                true
            } else {
                false
            }
        }
        wm.addView(card, plp)
        panel = card
        panelLp = plp
        card.post { Win.skipScreenshot(card) }
    }

    private fun footButton(label: String, color: Int, onClick: () -> Unit): TextView =
        Ui.text(ctx, label, 15f, color, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(ctx, 10), 0, dp(ctx, 10))
            setOnClickListener { onClick() }
        }
}
