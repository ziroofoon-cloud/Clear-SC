package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/**
 * "Free up space": scans the phone once and shows what can go, in groups (junk, empty folders, installers,
 * duplicates, big old files). Each group opens a list to review; "Clean" removes the safe ones in one tap (never
 * duplicates or old files: those only go after being looked at). The old shrinking of videos / photos / music / comics
 * ([ShrinkActivity]) is the last row.
 */
class CleanActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var page: EditUi.Page
    private lateinit var storageText: TextView
    private lateinit var barUsed: View
    private lateinit var barFree: View
    private lateinit var status: TextView
    private lateinit var listBox: LinearLayout
    private lateinit var action: TextView
    private var result: CleanScan.Result? = null
    private var scanning = false
    private var working = false
    private var cancelScan = AtomicBoolean(false)
    private var autoStarted = false // the scan starts by itself once; after a Cancel it waits for a tap

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Cfg.ensureLoaded(this)
        Ui.init(this)
        setTheme(Ui.theme())
        super.onCreate(savedInstanceState)
        Ui.styleBars(window)
        page = EditUi.page(this, getString(R.string.clean_title), getString(R.string.clean_hint))
        val a = this

        val top = EditUi.card(a, null)
        storageText = Ui.text(a, "", 14f, Ui.TEXT, true)
        top.addView(storageText)
        val bar = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            background = Ui.round(Ui.CHIP, dp(a, 5).toFloat())
        }
        barUsed = View(a).apply { background = Ui.round(Ui.ACCENT, dp(a, 5).toFloat()) }
        barFree = View(a)
        bar.addView(barUsed, LinearLayout.LayoutParams(0, dp(a, 10), 1f))
        bar.addView(barFree, LinearLayout.LayoutParams(0, dp(a, 10), 1f))
        top.addView(bar, EditUi.lp(a, 8))
        status = Ui.text(a, "", 12f, Ui.MUTED)
        top.addView(status, EditUi.lp(a, 8))
        page.body.addView(top)

        listBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        page.body.addView(listBox, EditUi.lp(a, 10))

        action = TextView(a).apply {
            gravity = Gravity.CENTER
            textSize = 15f
            setTextColor(Ui.BG)
            background = Ui.gradient(dp(a, 14).toFloat())
            setPadding(0, dp(a, 13), 0, dp(a, 13))
            setOnClickListener { onAction() }
        }
        page.bottom.addView(action)
        setContentView(page.root)
        paintStorage()
        render()
    }

    override fun onResume() {
        super.onResume()
        paintStorage()
        // first time here (or back from the all-files screen): scan right away
        if (result == null && !scanning && !autoStarted && hasAccess()) {
            autoStarted = true
            startScan()
        } else if (!hasAccess()) render()
    }

    override fun onDestroy() {
        cancelScan.set(true)
        super.onDestroy()
    }

    private fun hasAccess(): Boolean = Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager()

    private fun fmt(b: Long): String = when {
        b >= 1L shl 30 -> String.format(Locale.US, "%.2f GB", b / 1073741824.0)
        b >= 1L shl 20 -> String.format(Locale.US, "%.1f MB", b / 1048576.0)
        b >= 1L shl 10 -> String.format(Locale.US, "%d KB", b shr 10)
        else -> "$b B"
    }

    private fun paintStorage() {
        val f = Environment.getExternalStorageDirectory()
        val total = f.totalSpace.coerceAtLeast(1L)
        val free = f.usableSpace.coerceIn(0L, total)
        storageText.text = getString(R.string.clean_storage_fmt, fmt(free), fmt(total))
        val usedW = (total - free).toFloat() / total
        (barUsed.layoutParams as LinearLayout.LayoutParams).weight = usedW.coerceIn(0.01f, 1f)
        (barFree.layoutParams as LinearLayout.LayoutParams).weight = (1f - usedW).coerceIn(0.0001f, 1f)
        barUsed.requestLayout()
    }

    // ---- scanning -----------------------------------------------------------------------------

    private fun startScan() {
        if (scanning || working) return
        if (!hasAccess()) { askAccess(); return }
        scanning = true
        result = null
        cancelScan = AtomicBoolean(false)
        val cancel = cancelScan
        status.text = getString(R.string.clean_scanning)
        render()
        val app = applicationContext
        Thread {
            val r = runCatching {
                CleanScan.scan(app, { cancel.get() || isDestroyed }) { p ->
                    ui.post { if (!isDestroyed && scanning) status.text = getString(R.string.clean_scanning_fmt, p.substringAfterLast('/')) }
                }
            }.getOrNull()
            ui.post {
                scanning = false
                if (isDestroyed) return@post
                if (cancel.get()) {
                    status.text = getString(R.string.clean_cancelled)
                } else {
                    result = r
                    status.text = ""
                }
                paintStorage()
                render()
            }
        }.start()
    }

    private fun askAccess() {
        AlertDialog.Builder(this)
            .setMessage(R.string.clean_need_access)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                runCatching {
                    startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
                }.onFailure { runCatching { startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) } }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    // ---- the list -----------------------------------------------------------------------------

    private class CatInfo(val id: Int, val title: Int, val desc: Int)

    private val cats = listOf(
        CatInfo(CleanScan.JUNK, R.string.clean_junk, R.string.clean_junk_d),
        CatInfo(CleanScan.DUPES, R.string.clean_dupes, R.string.clean_dupes_d),
        CatInfo(CleanScan.APK, R.string.clean_apk, R.string.clean_apk_d),
        CatInfo(CleanScan.EMPTY, R.string.clean_empty, R.string.clean_empty_d),
        CatInfo(CleanScan.OLD, R.string.clean_old, R.string.clean_old_d)
    )

    private fun render() {
        listBox.removeAllViews()
        val r = result
        if (!hasAccess()) {
            status.text = getString(R.string.clean_need_access)
        }
        if (r != null) {
            var shown = 0
            for (c in cats) {
                val n = r.groups[c.id].size
                if (n == 0) continue
                shown++
                listBox.addView(row(getString(c.title), getString(c.desc), n, r.size(c.id), true) { review(c.id) }, EditUi.lp(this, if (listBox.childCount == 0) 0 else 8))
            }
            if (shown == 0) listBox.addView(Ui.text(this, getString(R.string.clean_nothing), 14f, Ui.TEXT), EditUi.lp(this, 4))
        }
        // the old tool stays: shrink videos, photos, music and comics
        listBox.addView(
            row(getString(R.string.clean_shrink), getString(R.string.clean_shrink_d), -1, 0L, false) { startActivity(Intent(this, ShrinkActivity::class.java)) },
            EditUi.lp(this, 14)
        )
        paintAction()
    }

    private fun row(title: String, desc: String, count: Int, size: Long, showSize: Boolean, onTap: () -> Unit): View {
        val a = this
        val r = LinearLayout(a).apply {
            gravity = Gravity.CENTER_VERTICAL
            val p = dp(a, 14)
            setPadding(p, dp(a, 12), p, dp(a, 12))
            background = Ui.round(Ui.CARD, dp(a, 16).toFloat(), Ui.STROKE, dp(a, 1))
            setOnClickListener { onTap() }
        }
        val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        col.addView(Ui.text(a, title, 15f, Ui.TEXT, true))
        col.addView(Ui.text(a, desc, 12f, Ui.MUTED), EditUi.lp(a, 2))
        r.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (showSize) {
            val right = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.END }
            right.addView(Ui.text(a, fmt(size), 14f, Ui.ACCENT, true))
            right.addView(Ui.text(a, getString(R.string.clean_count_fmt, count), 12f, Ui.MUTED))
            r.addView(right, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(a, 10) })
        }
        return r
    }

    private fun paintAction() {
        if (working) { page.bottom.visibility = View.GONE; return }
        page.bottom.visibility = View.VISIBLE
        val r = result
        when {
            scanning -> action.text = getString(android.R.string.cancel)
            !hasAccess() -> action.text = getString(R.string.clean_grant)
            r == null -> action.text = getString(R.string.clean_scan)
            else -> {
                val one = r.oneTapEntries()
                action.text = if (one.isEmpty()) getString(R.string.clean_rescan)
                else getString(R.string.clean_go_fmt, one.size, fmt(one.sumOf { it.second.size }))
            }
        }
    }

    private fun onAction() {
        val r = result
        when {
            working -> return
            scanning -> cancelScan.set(true)
            !hasAccess() -> askAccess()
            r == null -> startScan()
            else -> {
                val one = r.oneTapEntries()
                if (one.isEmpty()) startScan() else confirmDelete(one, getString(R.string.clean_confirm_safe)) 
            }
        }
    }

    // ---- reviewing a group --------------------------------------------------------------------

    private fun short(p: String): String {
        val root = Environment.getExternalStorageDirectory().absolutePath
        return if (p.startsWith(root)) p.substring(root.length).trimStart('/') else p
    }

    private fun review(cat: Int) {
        val r = result ?: return
        val all = r.groups[cat]
        if (all.isEmpty()) return
        val shownMax = 400
        val list = if (all.size > shownMax) all.subList(0, shownMax) else all
        val labels = list.map { e ->
            val where = short(e.file.parent ?: "")
            val extra = when (cat) {
                CleanScan.DUPES -> "\n" + getString(R.string.clean_keep_fmt, short(e.note))
                CleanScan.APK -> if (e.safe) "\n" + getString(R.string.clean_apk_installed) else ""
                CleanScan.EMPTY -> ""
                else -> ""
            }
            val head = if (cat == CleanScan.EMPTY) short(e.file.absolutePath)
            else e.file.name + "   ·   " + fmt(e.size)
            val sub = if (cat == CleanScan.EMPTY) "" else "\n" + where
            head + sub + extra
        }.toTypedArray()
        val checked = BooleanArray(list.size) { list[it].safe }
        val title = getString(
            when (cat) {
                CleanScan.JUNK -> R.string.clean_junk
                CleanScan.DUPES -> R.string.clean_dupes
                CleanScan.APK -> R.string.clean_apk
                CleanScan.EMPTY -> R.string.clean_empty
                else -> R.string.clean_old
            }
        ) + " (" + list.size + (if (all.size > list.size) "/" + all.size else "") + ")"
        val dlg = AlertDialog.Builder(this).setTitle(title)
            .setMultiChoiceItems(labels, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton(R.string.fm_delete) { _, _ ->
                val pick = list.filterIndexed { i, _ -> checked[i] }.map { cat to it }
                if (pick.isEmpty()) return@setPositiveButton
                confirmDelete(pick, getString(if (cat == CleanScan.DUPES) R.string.clean_confirm_dupes else R.string.clean_confirm_pick))
            }
            .setNegativeButton(android.R.string.cancel, null)
            .setNeutralButton(R.string.clean_toggle, null)
            .create()
        dlg.show()
        // "all / none" must not close the list: its listener is set after show()
        dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            val v = checked.any { !it }
            for (i in checked.indices) {
                checked[i] = v
                dlg.listView.setItemChecked(i, v)
            }
        }
    }

    // ---- deleting -----------------------------------------------------------------------------

    private fun confirmDelete(items: List<Pair<Int, CleanScan.Entry>>, note: String) {
        if (items.isEmpty() || working) return
        val bytes = items.sumOf { it.second.size }
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.clean_confirm_title_fmt, items.size, fmt(bytes)))
            .setMessage(note + "\n\n" + getString(R.string.clean_confirm_forever))
            .setPositiveButton(R.string.fm_delete) { _, _ -> runDelete(items) }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun runDelete(items: List<Pair<Int, CleanScan.Entry>>) {
        working = true
        paintAction()
        val cancel = AtomicBoolean(false)
        val prog = EditProgress(this, getString(R.string.clean_deleting), cancel)
        val app = applicationContext
        Thread {
            val d = CleanScan.delete(app, items, { cancel.get() }) { prog.set(it) }
            ui.post {
                prog.close()
                working = false
                if (isDestroyed) return@post
                var msg = getString(R.string.clean_done_fmt, d.count, fmt(d.bytes))
                if (d.failed > 0) msg += "\n" + getString(R.string.clean_failed_fmt, d.failed)
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                result = null
                paintStorage()
                startScan()
            }
        }.start()
    }
}
