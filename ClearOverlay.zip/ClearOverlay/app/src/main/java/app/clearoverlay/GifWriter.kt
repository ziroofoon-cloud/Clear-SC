package app.clearoverlay

import java.io.OutputStream

/**
 * Writes an animated GIF (GIF89a). Every frame gets its own 256-colour palette (median cut) and is optionally dithered
 * (Floyd-Steinberg), which keeps photos and video frames looking good. Frames are written as they arrive.
 */
class GifWriter(private val out: OutputStream, private val w: Int, private val h: Int, private val loop: Boolean = true) {
    private var started = false

    private fun le(v: Int) { out.write(v and 0xFF); out.write((v shr 8) and 0xFF) }

    private fun header() {
        out.write("GIF89a".toByteArray())
        le(w); le(h)
        out.write(0x70) // no global colour table, 8 bits per colour
        out.write(0); out.write(0)
        if (loop) {
            out.write(0x21); out.write(0xFF); out.write(11)
            out.write("NETSCAPE2.0".toByteArray())
            out.write(3); out.write(1); le(0); out.write(0)
        }
        started = true
    }

    /** Adds one frame: [argb] has w * h pixels, [delayCs] is how long it is shown, in hundredths of a second. */
    fun add(argb: IntArray, delayCs: Int, dither: Boolean = true) {
        if (!started) header()
        val pal = palette(argb) // 256 * 3 bytes
        val idx = map(argb, pal, dither)
        out.write(0x21); out.write(0xF9); out.write(4)
        out.write(0x04) // do not dispose, no transparency
        le(delayCs.coerceIn(2, 65535)); out.write(0); out.write(0)
        out.write(0x2C); le(0); le(0); le(w); le(h)
        out.write(0x87) // local colour table, 256 entries
        out.write(pal)
        Lzw(out).encode(idx, idx.size)
    }

    fun finish() {
        if (!started) header()
        out.write(0x3B)
        out.flush()
    }

    // ---- palette: median cut on a 5-bit-per-channel histogram ----
    private class Box(val cols: IntArray, val from: Int, val to: Int, val counts: IntArray)

    private fun palette(px: IntArray): ByteArray {
        val hist = IntArray(32768)
        var i = 0
        val step = if (px.size > 40000) 3 else 1
        while (i < px.size) {
            val c = px[i]
            hist[(((c shr 19) and 31) shl 10) or (((c shr 11) and 31) shl 5) or ((c shr 3) and 31)]++
            i += step
        }
        var n = 0
        for (v in hist) if (v > 0) n++
        val cols = IntArray(n)
        val cnt = IntArray(n)
        var k = 0
        for (b in 0 until 32768) if (hist[b] > 0) { cols[k] = b; cnt[k] = hist[b]; k++ }
        // boxes are ranges [from, to) of an array that is re-sorted when a box is split
        val order = Array(n) { it }
        val boxes = ArrayList<IntArray>() // [from, to]
        boxes.add(intArrayOf(0, n))
        fun channel(b: Int, ch: Int) = when (ch) { 0 -> (b shr 10) and 31; 1 -> (b shr 5) and 31; else -> b and 31 }
        while (boxes.size < 256) {
            // the box with the most pixels that still has more than one colour
            var best = -1
            var bestPop = 0L
            for ((bi, bx) in boxes.withIndex()) {
                if (bx[1] - bx[0] < 2) continue
                var pop = 0L
                for (j in bx[0] until bx[1]) pop += cnt[order[j]]
                if (pop > bestPop) { bestPop = pop; best = bi }
            }
            if (best < 0) break
            val bx = boxes[best]
            var lo = intArrayOf(31, 31, 31)
            var hi = intArrayOf(0, 0, 0)
            for (j in bx[0] until bx[1]) for (c in 0..2) {
                val v = channel(cols[order[j]], c)
                if (v < lo[c]) lo[c] = v
                if (v > hi[c]) hi[c] = v
            }
            var axis = 0
            var rng = hi[0] - lo[0]
            for (c in 1..2) if (hi[c] - lo[c] > rng) { rng = hi[c] - lo[c]; axis = c }
            val sub = order.copyOfRange(bx[0], bx[1])
            java.util.Arrays.sort(sub) { a, b -> channel(cols[a], axis) - channel(cols[b], axis) }
            System.arraycopy(sub, 0, order, bx[0], sub.size)
            var half = bestPop / 2
            var acc = 0L
            var cut = bx[0] + 1
            for (j in bx[0] until bx[1] - 1) {
                acc += cnt[order[j]]
                cut = j + 1
                if (acc >= half) break
            }
            boxes[best] = intArrayOf(bx[0], cut)
            boxes.add(intArrayOf(cut, bx[1]))
        }
        val pal = ByteArray(768)
        for ((bi, bx) in boxes.withIndex()) {
            var r = 0L; var g = 0L; var b = 0L; var pop = 0L
            for (j in bx[0] until bx[1]) {
                val c = cols[order[j]]
                val m = cnt[order[j]].toLong()
                r += ((c shr 10) and 31) * m; g += ((c shr 5) and 31) * m; b += (c and 31) * m; pop += m
            }
            if (pop == 0L) pop = 1
            pal[bi * 3] = (((r * 8 / pop) + 4).coerceAtMost(255)).toByte()
            pal[bi * 3 + 1] = (((g * 8 / pop) + 4).coerceAtMost(255)).toByte()
            pal[bi * 3 + 2] = (((b * 8 / pop) + 4).coerceAtMost(255)).toByte()
        }
        return pal
    }

    private fun map(px: IntArray, pal: ByteArray, dither: Boolean): ByteArray {
        val lut = IntArray(32768) { -1 }
        fun nearest(r: Int, g: Int, b: Int): Int {
            val key = ((r shr 3) shl 10) or ((g shr 3) shl 5) or (b shr 3)
            var v = lut[key]
            if (v >= 0) return v
            var best = 0
            var bd = Int.MAX_VALUE
            val rr = (r and 0xF8) + 4
            val gg = (g and 0xF8) + 4
            val bb = (b and 0xF8) + 4
            for (p in 0 until 256) {
                val dr = (pal[p * 3].toInt() and 255) - rr
                val dg = (pal[p * 3 + 1].toInt() and 255) - gg
                val db = (pal[p * 3 + 2].toInt() and 255) - bb
                val d = dr * dr * 3 + dg * dg * 4 + db * db * 2
                if (d < bd) { bd = d; best = p }
            }
            lut[key] = best
            return best
        }
        val res = ByteArray(px.size)
        if (!dither) {
            for (i in px.indices) { val c = px[i]; res[i] = nearest((c shr 16) and 255, (c shr 8) and 255, c and 255).toByte() }
            return res
        }
        var cur = FloatArray((w + 2) * 3)
        var nxt = FloatArray((w + 2) * 3)
        for (y in 0 until h) {
            java.util.Arrays.fill(nxt, 0f)
            for (x in 0 until w) {
                val c = px[y * w + x]
                val r = (((c shr 16) and 255) + cur[(x + 1) * 3]).toInt().coerceIn(0, 255)
                val g = (((c shr 8) and 255) + cur[(x + 1) * 3 + 1]).toInt().coerceIn(0, 255)
                val b = ((c and 255) + cur[(x + 1) * 3 + 2]).toInt().coerceIn(0, 255)
                val p = nearest(r, g, b)
                res[y * w + x] = p.toByte()
                val er = (r - (pal[p * 3].toInt() and 255)) * 0.75f // a little less than full, which keeps flat areas calm
                val eg = (g - (pal[p * 3 + 1].toInt() and 255)) * 0.75f
                val eb = (b - (pal[p * 3 + 2].toInt() and 255)) * 0.75f
                val a = (x + 1) * 3
                cur[a + 3] += er * 7f / 16f; cur[a + 4] += eg * 7f / 16f; cur[a + 5] += eb * 7f / 16f
                nxt[a - 3] += er * 3f / 16f; nxt[a - 2] += eg * 3f / 16f; nxt[a - 1] += eb * 3f / 16f
                nxt[a] += er * 5f / 16f; nxt[a + 1] += eg * 5f / 16f; nxt[a + 2] += eb * 5f / 16f
                nxt[a + 3] += er * 1f / 16f; nxt[a + 4] += eg * 1f / 16f; nxt[a + 5] += eb * 1f / 16f
            }
            val t = cur; cur = nxt; nxt = t
        }
        return res
    }

    /** GIF-flavoured LZW with 8-bit pixels. */
    private class Lzw(private val out: OutputStream) {
        private val block = ByteArray(255)
        private var bn = 0
        private var cur = 0L
        private var nbits = 0

        private fun emit(b: Int) { block[bn++] = b.toByte(); if (bn == 255) flushBlock() }
        private fun flushBlock() { if (bn > 0) { out.write(bn); out.write(block, 0, bn); bn = 0 } }
        private fun put(code: Int, size: Int) {
            cur = cur or (code.toLong() shl nbits)
            nbits += size
            while (nbits >= 8) { emit((cur and 0xFF).toInt()); cur = cur shr 8; nbits -= 8 }
        }

        fun encode(data: ByteArray, n: Int) {
            out.write(8)
            val table = IntArray(1 shl 20)
            var stamp = 1
            var codeSize = 9
            var next = 258
            put(256, codeSize)
            var prefix = data[0].toInt() and 0xFF
            for (i in 1 until n) {
                val k = data[i].toInt() and 0xFF
                val key = (prefix shl 8) or k
                val v = table[key]
                if ((v ushr 12) == stamp) {
                    prefix = v and 0xFFF
                } else {
                    put(prefix, codeSize)
                    if (next > (1 shl codeSize) - 1 && codeSize < 12) codeSize++
                    if (next < 4096) {
                        table[key] = (stamp shl 12) or next
                        next++
                    } else {
                        put(256, codeSize)
                        stamp++
                        codeSize = 9
                        next = 258
                    }
                    prefix = k
                }
            }
            put(prefix, codeSize)
            put(257, codeSize)
            if (nbits > 0) emit((cur and 0xFF).toInt())
            flushBlock()
            out.write(0)
        }
    }
}
