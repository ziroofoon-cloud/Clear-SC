package app.clearoverlay

import android.os.SystemClock

/**
 * GPU budget "Auto": the app picks Performance / Balanced / Quality itself so the person does not have to.
 *  - Player: from the picture ([Auto.forVideo] / [Auto.forPhoto]: pixels per second the GPU must process; a photo gets Quality), lowered one
 *    step when frames are dropped and given back after a calm minute (the same rules the global Auto uses, see PlayerActivity).
 *  - Screen layer: from the measured time the GPU needs for a frame ([Cfg.drawMs]); with no fresh measurement yet: Balanced.
 * The chosen budget is written to [Cfg.profileBudget] (everything else reads that), [Cfg.budgetAuto] stays on.
 */
object BudgetAuto {
    /** True when a quick profile is in force and the budget is on Auto (without a profile the budget has nothing to change). */
    fun active(): Boolean = Cfg.budgetAuto && !Cfg.autoMode && Cfg.profileType >= 0 && Cfg.userProfile == null

    /** The budget for the screen layer from the measured frame time (a 60 Hz frame is 16.7 ms). */
    fun fromDrawTime(): Int {
        val fresh = SystemClock.elapsedRealtime() - Cfg.drawMsAt < 5000L && Cfg.drawMs > 0f
        if (!fresh) return Profiles.BALANCED
        return when {
            Cfg.drawMs > 11f -> Profiles.PERF
            Cfg.drawMs > 6f -> Profiles.BALANCED
            else -> Profiles.QUALITY
        }
    }

    /** What Auto would pick now: [pickBudget] = the picture's own budget in the player (null = nothing is open / the screen layer), never above [cap]. */
    fun resolve(inPlayer: Boolean, pickBudget: Int?, cap: Int = Profiles.QUALITY): Int {
        val base = if (inPlayer) (pickBudget ?: Profiles.BALANCED) else fromDrawTime()
        return minOf(base, cap).coerceIn(Profiles.PERF, Profiles.QUALITY)
    }
}
