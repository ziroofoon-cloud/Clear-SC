package app.clearoverlay

import java.io.File
import java.io.RandomAccessFile

/**
 * A small reader for the new RAR format (RAR5) that can list a book and copy the files that are stored without
 * compression ("store" method; many comic archives are made that way because pictures hardly compress).
 * Compressed files (including solid archives) are unpacked with [Rar5Unpacker].
 */
object Rar5 {
    class Entry(
        val name: String, val offset: Long, val packed: Long, val size: Long, val method: Int, val dir: Boolean, val encrypted: Boolean,
        val solid: Boolean = false, val dict: Long = 128L shl 10, val crc: Long = -1L, val split: Boolean = false
    )

    private val SIG = byteArrayOf(0x52, 0x61, 0x72, 0x21, 0x1A, 0x07, 0x01, 0x00)

    fun isRar5(head: ByteArray): Boolean = head.size >= 8 && (0 until 7).all { head[it] == SIG[it] } && head[6] == 1.toByte()

    private class Rd(val f: RandomAccessFile) {
        fun byte(): Int = f.read()
        fun vint(): Long {
            var v = 0L
            var shift = 0
            while (shift < 70) {
                val b = f.read()
                if (b < 0) throw java.io.EOFException()
                v = v or ((b and 0x7F).toLong() shl shift)
                if (b and 0x80 == 0) return v
                shift += 7
            }
            throw java.io.IOException("bad number")
        }
    }

    /** All files of the archive in order. */
    fun list(file: File): List<Entry> {
        val out = ArrayList<Entry>()
        RandomAccessFile(file, "r").use { f ->
            f.seek(8)
            val rd = Rd(f)
            while (f.filePointer < f.length()) {
                val crcBuf = ByteArray(4)
                if (f.read(crcBuf) < 4) break
                val hsize = rd.vint()
                val hstart = f.filePointer
                if (hsize <= 0 || hsize > 1_000_000) break
                val type = rd.vint().toInt()
                val flags = rd.vint()
                if (flags and 0x1L != 0L) rd.vint() // extra area size
                val dataSize = if (flags and 0x2L != 0L) rd.vint() else 0L
                if (type == 2) { // a file
                    val fflags = rd.vint()
                    val unpacked = rd.vint()
                    rd.vint() // attributes
                    if (fflags and 0x2L != 0L) f.skipBytes(4) // time
                    var crc = -1L
                    if (fflags and 0x4L != 0L) { // crc32
                        val cb = ByteArray(4)
                        f.readFully(cb)
                        crc = (cb[0].toLong() and 0xFF) or ((cb[1].toLong() and 0xFF) shl 8) or ((cb[2].toLong() and 0xFF) shl 16) or ((cb[3].toLong() and 0xFF) shl 24)
                    }
                    val comp = rd.vint()
                    rd.vint() // host OS
                    val nlen = rd.vint().toInt()
                    if (nlen < 0 || nlen > 65535) break
                    val nb = ByteArray(nlen)
                    f.readFully(nb)
                    val method = ((comp shr 7) and 7L).toInt()
                    val dataPos = hstart + hsize
                    var dict = (128L shl 10) shl ((comp shr 10) and 15L).toInt()
                    dict += dict / 32 * ((comp shr 15) and 31L)
                    val split = flags and 0x18L != 0L
                    out.add(Entry(String(nb, Charsets.UTF_8), dataPos, dataSize, unpacked, method, fflags and 0x1L != 0L, false, (comp shr 6) and 1L != 0L, dict, crc, split))
                } else if (type == 5) {
                    break
                }
                f.seek(hstart + hsize + dataSize)
            }
        }
        return out
    }

    /** Copies a stored file of the archive to [target]. */
    fun extractStored(file: File, e: Entry, target: File) {
        RandomAccessFile(file, "r").use { f ->
            f.seek(e.offset)
            target.outputStream().use { o ->
                val buf = ByteArray(64 * 1024)
                var left = e.packed
                while (left > 0) {
                    val n = f.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                    if (n < 0) throw java.io.EOFException()
                    o.write(buf, 0, n)
                    left -= n
                }
            }
        }
    }

    /**
     * Unpacks a compressed file of the archive and returns its bytes, or null when the data cannot be unpacked (damaged,
     * encrypted, split over several volumes, too big). Use the same [up] for all files of one archive, in archive order,
     * so solid archives keep their dictionary.
     */
    fun unpack(file: File, e: Entry, up: Rar5Unpacker): ByteArray? {
        if (e.split || e.packed > 200L * 1024 * 1024 || e.size > 200L * 1024 * 1024) return null
        return try {
            val pk = ByteArray(e.packed.toInt())
            RandomAccessFile(file, "r").use { f ->
                f.seek(e.offset)
                f.readFully(pk)
            }
            val data = up.unpack(pk, pk.size, e.size, e.solid, e.dict)
            if (e.crc >= 0) {
                val c = java.util.zip.CRC32()
                c.update(data, 0, data.size)
                if (c.value != e.crc) return null
            }
            data
        } catch (t: Throwable) {
            null
        }
    }
}
