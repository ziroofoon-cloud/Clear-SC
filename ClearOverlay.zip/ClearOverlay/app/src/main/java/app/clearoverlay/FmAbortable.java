package app.clearoverlay;

/** An output stream that can be thrown away without finishing the file (so a failed copy never leaves a half file behind). */
public interface FmAbortable {
    void abort();
}
