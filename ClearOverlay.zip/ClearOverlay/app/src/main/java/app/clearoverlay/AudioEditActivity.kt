package app.clearoverlay

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.atomic.AtomicBoolean

/**
 * "Edit audio": cut a part (from - to), fade in / out, change the volume and (optionally) run the sound enhancer, then
 * save a new .m4a in Music/ClearOverlay. Works on music files and on the sound track of a video. The original is never changed.
 */
class AudioEditActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var box: LinearLayout
    private lateinit var pg: EditUi.Page
    private var uri: Uri? = null
    private var name = ""
    private var durSec = 0L
    private var from = ""
    private var to = ""
    private var fadeIn = 0
    private var fadeOut = 0
    private var gainIdx = 2
    private var enhance = false
    private var speedIdx = 3
    private var addUri: Uri? = null
    private var addName = ""
    private var addVolIdx = 1
    private var addReplace = false
    private var addLoop = true
    private var busy = false
    private val cancel = AtomicBoolean(false)

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Cfg.ensureLoaded(this)
        AudioCfg.load(this)
        Ui.init(this)
        setTheme(Ui.theme())
        super.onCreate(savedInstanceState)
        Ui.styleBars(window)
        pg = EditUi.page(this, getString(R.string.aedit_title), getString(R.string.aedit_hint))
        box = pg.body
        setContentView(pg.root)
        intent?.data?.let { setSource(it) }
        build()
    }

    override fun onDestroy() {
        if (isFinishing) cancel.set(true)
        super.onDestroy()
    }

    private fun gap(v: Int) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@AudioEditActivity, v) }

    private fun button(label: String, primary: Boolean, onClick: () -> Unit) = Ui.text(this, label, 16f, if (primary) Ui.BG else Ui.ACCENT, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(this@AudioEditActivity, 14), dp(this@AudioEditActivity, 13), dp(this@AudioEditActivity, 14), dp(this@AudioEditActivity, 13))
        background = if (primary) Ui.gradient(dp(this@AudioEditActivity, 14).toFloat()) else Ui.round(Ui.CHIP, dp(this@AudioEditActivity, 14).toFloat())
        setOnClickListener { onClick() }
    }

    private fun setSource(u: Uri) {
        uri = u
        name = runCatching {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
        }.getOrNull() ?: (u.lastPathSegment ?: "audio").substringAfterLast('/')
        durSec = 0
        runCatching {
            val r = MediaMetadataRetriever()
            r.setDataSource(this, u)
            durSec = (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) / 1000
            r.release()
        }
        from = ""
        to = ""
    }

    private fun parseTime(text: String): Long? {
        val t = text.trim()
        if (t.isEmpty()) return null
        return try {
            val p = t.split(':')
            when (p.size) {
                1 -> p[0].trim().toDouble().toLong()
                2 -> p[0].trim().toLong() * 60 + p[1].trim().toLong()
                3 -> p[0].trim().toLong() * 3600 + p[1].trim().toLong() * 60 + p[2].trim().toLong()
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun fmt(sec: Long): String {
        val s = sec.coerceAtLeast(0)
        return if (s >= 3600) String.format(java.util.Locale.US, "%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60) else String.format(java.util.Locale.US, "%d:%02d", s / 60, s % 60)
    }

    private fun chips(labels: List<String>, selected: Int, onPick: (Int) -> Unit): View {
        val row = LinearLayout(this)
        val views = ArrayList<TextView>()
        fun paint(sel: Int) {
            val r = dp(this, 10).toFloat()
            views.forEachIndexed { i, c ->
                if (i == sel) {
                    c.background = Ui.gradient(r)
                    c.setTextColor(Ui.BG)
                } else {
                    c.background = Ui.round(Ui.CHIP, r)
                    c.setTextColor(Ui.MUTED)
                }
            }
        }
        labels.forEachIndexed { i, l ->
            val c = TextView(this).apply {
                text = l
                textSize = 14f
                gravity = Gravity.CENTER
                maxLines = 1
                minWidth = dp(this@AudioEditActivity, 60)
                setPadding(dp(this@AudioEditActivity, 14), dp(this@AudioEditActivity, 10), dp(this@AudioEditActivity, 14), dp(this@AudioEditActivity, 10))
                setOnClickListener { paint(i); onPick(i) }
            }
            views.add(c)
            row.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i > 0) marginStart = dp(this@AudioEditActivity, 6) })
        }
        paint(selected)
        return ChipScroller(this, row)
    }

    private fun field(hint: String, value: String, onText: (String) -> Unit) = EditText(this).apply {
        setSingleLine()
        this.hint = hint
        setText(value)
        inputType = android.text.InputType.TYPE_CLASS_DATETIME or android.text.InputType.TYPE_DATETIME_VARIATION_TIME
        setTextColor(Ui.TEXT)
        setHintTextColor(Ui.MUTED)
        addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) { onText(s?.toString() ?: "") }
        })
    }

    private fun build() {
        box.removeAllViews()
        pg.bottom.removeAllViews()
        pg.bottom.visibility = View.GONE
        val a = this
        if (uri == null) {
            box.addView(EditUi.empty(a, Icons.MUSIC, getString(R.string.edit_hub_audio), getString(R.string.export_pick)) { pick() }, EditUi.lp(a, 8))
            return
        }
        val src = EditUi.card(a, null)
        src.addView(EditUi.picked(a, Icons.MUSIC, name, if (durSec > 0) fmt(durSec) else "", { pick() }), EditUi.lp(a, 0))
        box.addView(src, EditUi.lp(a, 4))

        val trim = EditUi.card(a, getString(R.string.edit_cut), getString(R.string.edit_cut_hint))
        val row = LinearLayout(a).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(EditUi.timeField(a, getString(R.string.export_range_from), from) { from = it }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(android.widget.ImageView(a).apply { setImageDrawable(LineIcon(Icons.NEXT, Ui.MUTED)); setPadding(dp(a, 6), 0, dp(a, 6), 0) }, LinearLayout.LayoutParams(dp(a, 36), dp(a, 22)))
        row.addView(EditUi.timeField(a, getString(R.string.export_range_to), to) { to = it }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        trim.addView(row, EditUi.lp(a, 12))
        box.addView(trim, EditUi.lp(a, 12))

        val fades = listOf("0", "1 s", "2 s", "4 s", "8 s")
        val fd = EditUi.card(a, getString(R.string.aedit_card_fade))
        fd.addView(EditUi.label(a, getString(R.string.aedit_fade_in)), EditUi.lp(a, 10))
        fd.addView(EditUi.chips(a, fades, fadeIn) { fadeIn = it }, EditUi.lp(a, 8))
        fd.addView(EditUi.label(a, getString(R.string.aedit_fade_out)), EditUi.lp(a, 14))
        fd.addView(EditUi.chips(a, fades, fadeOut) { fadeOut = it }, EditUi.lp(a, 8))
        box.addView(fd, EditUi.lp(a, 12))

        val lv = EditUi.card(a, getString(R.string.aedit_card_level))
        lv.addView(EditUi.label(a, getString(R.string.aedit_gain)), EditUi.lp(a, 10))
        lv.addView(EditUi.chips(a, GAINS.map { (if (it > 0) "+" else "") + it.toInt() + " dB" }, gainIdx) { gainIdx = it }, EditUi.lp(a, 8))
        lv.addView(EditUi.label(a, getString(R.string.aedit_speed)), EditUi.lp(a, 14))
        lv.addView(EditUi.chips(a, SPEEDS.map { (if (it == 1f) "1" else it.toString().removeSuffix(".0")) + "×" }, speedIdx) { speedIdx = it }, EditUi.lp(a, 8))
        lv.addView(EditUi.note(a, getString(R.string.aedit_speed_hint)), EditUi.lp(a, 6))
        box.addView(lv, EditUi.lp(a, 12))

        val add = EditUi.card(a, getString(R.string.add_sound_title))
        if (addUri == null) add.addView(EditUi.action(a, getString(R.string.add_sound_pick), false, Icons.MUSIC) { pickAdd() }, EditUi.lp(a, 10))
        else {
            add.addView(EditUi.picked(a, Icons.MUSIC, addName, getString(R.string.edit_snd_note), { pickAdd() }, { addUri = null; addName = ""; build() }), EditUi.lp(a, 10))
            add.addView(EditUi.note(a, getString(R.string.add_sound_vol)), EditUi.lp(a, 10))
            add.addView(EditUi.chips(a, ADD_VOLS.map { (if (it > 0) "+" else "") + it.toInt() + " dB" }, addVolIdx) { addVolIdx = it }, EditUi.lp(a, 6))
            add.addView(EditUi.chips(a, listOf(getString(R.string.add_sound_mix), getString(R.string.add_sound_replace)), if (addReplace) 1 else 0) { addReplace = it == 1 }, EditUi.lp(a, 10))
            add.addView(EditUi.chips(a, listOf(getString(R.string.add_sound_loop_on), getString(R.string.add_sound_loop_off)), if (addLoop) 0 else 1) { addLoop = it == 0 }, EditUi.lp(a, 8))
        }
        add.addView(EditUi.note(a, getString(R.string.add_sound_hint_audio)), EditUi.lp(a, 6))
        box.addView(add, EditUi.lp(a, 12))

        val en = EditUi.card(a, getString(R.string.aedit_enhance), getString(R.string.aedit_enh_hint))
        en.addView(EditUi.chips(a, listOf(getString(R.string.aedit_enh_off), getString(R.string.aedit_enh_on)), if (enhance) 1 else 0) { enhance = it == 1 }, EditUi.lp(a, 10))
        box.addView(en, EditUi.lp(a, 12))

        val out = EditUi.card(a, getString(R.string.aedit_card_output))
        out.addView(audioFormatButton(a), EditUi.lp(a, 10))
        box.addView(out, EditUi.lp(a, 12))

        pg.bottom.addView(EditUi.action(a, getString(R.string.aedit_save), true, Icons.SAVE) { start() }, EditUi.lp(a, 0))
        pg.bottom.visibility = View.VISIBLE
    }

    /** The sound to add: from the app's music Library or from the phone's files. */
    private fun pickAdd() {
        android.app.AlertDialog.Builder(this)
            .setItems(arrayOf(getString(R.string.export_pick_lib), getString(R.string.export_pick_files))) { _, w ->
                @Suppress("DEPRECATION")
                if (w == 0) {
                    startActivityForResult(Intent(this, LibraryActivity::class.java).putExtra(LibraryArgs.PICK, true).putExtra(LibraryArgs.PICK_TAB, 4), REQ_ADD_LIB)
                } else {
                    startActivityForResult(
                        Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
                            .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("audio/*", "video/*")),
                        REQ_ADD
                    )
                }
            }
            .show()
    }

    private fun pick() {
        android.app.AlertDialog.Builder(this)
            .setItems(arrayOf(getString(R.string.export_pick_lib), getString(R.string.export_pick_files))) { _, w ->
                @Suppress("DEPRECATION")
                if (w == 0) {
                    startActivityForResult(Intent(this, LibraryActivity::class.java).putExtra(LibraryArgs.PICK, true).putExtra(LibraryArgs.PICK_TAB, 4), REQ_LIB)
                } else {
                    startActivityForResult(
                        Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
                            .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("audio/*", "video/*")),
                        REQ_PICK
                    )
                }
            }
            .show()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val u = data?.data
        if (res != RESULT_OK || u == null) return
        if (req == REQ_ADD || req == REQ_ADD_LIB) {
            if (req == REQ_ADD) runCatching { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            addUri = u
            addName = if (req == REQ_ADD_LIB) (data.getStringExtra(LibraryArgs.NAME) ?: u.lastPathSegment ?: "") else (u.lastPathSegment ?: "").substringAfterLast('/')
            build()
            return
        }
        if (req != REQ_PICK && req != REQ_LIB) return
        if (req == REQ_PICK) runCatching { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        setSource(u)
        build()
    }

    private fun start() {
        val u = uri ?: return
        if (busy) return
        val f = parseTime(from) ?: 0L
        val t = parseTime(to) ?: -1L
        if (t in 0..f) {
            Toast.makeText(this, R.string.edit_bad_range, Toast.LENGTH_LONG).show()
            return
        }
        val fadeSecs = floatArrayOf(0f, 1f, 2f, 4f, 8f)
        val ed = AudioExport.Edit(f * 1_000_000L, if (t >= 0) t * 1_000_000L else -1L, fadeSecs[fadeIn], fadeSecs[fadeOut], GAINS[gainIdx], enhance, speed = SPEEDS[speedIdx], mixUri = addUri, mixGainDb = ADD_VOLS[addVolIdx], mixReplace = addReplace, mixLoop = addLoop)
        busy = true
        cancel.set(false)
        val dlgBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(this@AudioEditActivity, 22), dp(this@AudioEditActivity, 12), dp(this@AudioEditActivity, 22), dp(this@AudioEditActivity, 4))
        }
        val state = TextView(this).apply { text = "0%"; textSize = 16f }
        dlgBox.addView(state)
        val dlg = android.app.AlertDialog.Builder(this)
            .setTitle(R.string.aedit_saving)
            .setView(dlgBox)
            .setCancelable(false)
            .setNegativeButton(android.R.string.cancel) { _, _ -> cancel.set(true) }
            .create()
        dlg.show()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val app = applicationContext
        val base = name.substringBeforeLast('.').replace(Regex("[\\\\/:*?\"<>|]"), "_") + "_edit"
        val params = AudioCfg.snapshot()
        Thread {
            var last = -1
            val r = AudioExport.run(app, u, base, params, cancel, ed) { p ->
                val pct = (p * 100).toInt()
                if (pct != last) {
                    last = pct
                    runOnUiThread { state.text = "$pct%" }
                }
            }
            runOnUiThread {
                busy = false
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                runCatching { dlg.dismiss() }
                if (!isDestroyed) {
                    val msg = when {
                        r.uri != null -> getString(R.string.aud_export_done_fmt, "$base.${r.ext}")
                        r.error == "cancelled" -> null
                        else -> getString(R.string.aud_export_fail_fmt, r.error ?: "?")
                    }
                    if (msg != null) Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    companion object {
        private const val REQ_PICK = 61
        private const val REQ_LIB = 62
        private const val REQ_ADD = 63
        private const val REQ_ADD_LIB = 64
        private val ADD_VOLS = floatArrayOf(-12f, -6f, 0f, 3f, 6f)
        private val SPEEDS = floatArrayOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f, 3f, 4f)
        private val GAINS = floatArrayOf(-6f, -3f, 0f, 3f, 6f, 10f)
    }
}
