package app.clearoverlay

import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.media.ImageReader
import android.os.Handler
import android.os.Looper
import android.view.Surface
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.max

/**
 * Runs the player's picture effects (denoise / upscale / sharpen / vivid ...) on a manga page, off screen:
 * the page goes through the same GL pipeline as photos in the player and comes back as a Bitmap.
 * One instance keeps one GL context alive; call [process] from a worker thread only.
 */
class MangaFx {
    private var g: GlPipeline? = null
    private var input: Surface? = null
    private var reader: ImageReader? = null
    private var failed = false

    /** CRSC Edge level for this renderer (-1 = the app setting). 5 = maximum (very heavy, files only). */
    @Volatile var crsc = -1

    @Synchronized
    private fun ensure(w: Int, h: Int): Boolean {
        if (g != null) return true
        if (failed) return false
        val r = ImageReader.newInstance(2, 2, PixelFormat.RGBA_8888, 2)
        r.setOnImageAvailableListener({ it.acquireLatestImage()?.close() }, Handler(Looper.getMainLooper()))
        val gg = GlPipeline(r.surface)
        gg.manualOnly = true
        gg.crscOverride = crsc
        gg.allowMax = true
        val ready = CountDownLatch(1)
        gg.onError = {
            failed = true
            ready.countDown()
        }
        gg.start(w, h) { s ->
            input = s
            ready.countDown()
        }
        if (!ready.await(6, TimeUnit.SECONDS) || input == null) {
            failed = true
            runCatching { gg.release() }
            runCatching { r.close() }
            return false
        }
        reader = r
        g = gg
        return true
    }

    /** The page with the current effects applied (a bit larger when an upscaler is active), or null if that failed. */
    @Synchronized
    fun process(src: Bitmap): Bitmap? {
        if (src.isRecycled || !ensure(src.width, src.height)) return null
        val gg = g ?: return null
        val inp = input ?: return null
        // input resolution (what the page really is): a page said to be smaller than its file is brought down first
        var cw = src.width
        var ch = src.height
        if (Cfg.inRes > 0) {
            val ms = minOf(cw, ch)
            if (Cfg.inRes < ms) {
                val k = Cfg.inRes.toFloat() / ms
                cw = max(2, (cw * k).toInt())
                ch = max(2, (ch * k).toInt())
            }
        }
        gg.setCaptureSize(cw, ch)
        val latch = CountDownLatch(1)
        gg.frameLatch = latch
        try {
            val c = inp.lockCanvas(null)
            try {
                // a big reduction is done in halving steps (one single bilinear read would alias and look rough)
                var from = src
                while (from.width / 2 >= c.width && from.height / 2 >= c.height) {
                    val hb = Bitmap.createScaledBitmap(from, from.width / 2, from.height / 2, true)
                    if (from !== src && hb !== from) from.recycle()
                    from = hb
                }
                c.drawBitmap(from, null, Rect(0, 0, c.width, c.height), Paint(Paint.FILTER_BITMAP_FLAG))
                if (from !== src) from.recycle()
            } finally {
                inp.unlockCanvasAndPost(c)
            }
        } catch (t: Throwable) {
            return null
        }
        if (!latch.await(3, TimeUnit.SECONDS)) return null
        // output resolution: Auto = a bit larger when an upscaler is active; otherwise the chosen short side
        var k = (3200f / max(src.width, src.height).toFloat()).coerceIn(1f, 1.5f)
        if (Cfg.outRes > 0) {
            k = Cfg.outRes.toFloat() / minOf(src.width, src.height)
            // keep the result within what a phone can hold (long side 6000 px, 20 megapixels)
            val longSide = max(src.width, src.height) * k
            if (longSide > 6000f) k *= 6000f / longSide
            val area = src.width.toDouble() * src.height * k * k
            if (area > 20_000_000.0) k *= Math.sqrt(20_000_000.0 / area).toFloat()
        }
        val ow = (src.width * k).toInt().coerceAtLeast(2)
        val oh = (src.height * k).toInt().coerceAtLeast(2)
        return gg.snapshot(ow, oh)
    }

    /**
     * Same as [process], but with an explicit effect set and result size, so the live settings cannot interfere
     * (used by the GIF export). Null if the GPU part failed.
     */
    @Synchronized
    fun processWith(src: Bitmap, fx: FxView, ow: Int, oh: Int): Bitmap? {
        if (src.isRecycled || !ensure(src.width, src.height)) return null
        val gg = g ?: return null
        val inp = input ?: return null
        gg.fx = fx
        gg.setCaptureSize(src.width, src.height)
        val latch = CountDownLatch(1)
        gg.frameLatch = latch
        try {
            val c = inp.lockCanvas(null)
            try {
                // a big reduction is done in halving steps (one single bilinear read would alias and look rough)
                var from = src
                while (from.width / 2 >= c.width && from.height / 2 >= c.height) {
                    val hb = Bitmap.createScaledBitmap(from, from.width / 2, from.height / 2, true)
                    if (from !== src && hb !== from) from.recycle()
                    from = hb
                }
                c.drawBitmap(from, null, Rect(0, 0, c.width, c.height), Paint(Paint.FILTER_BITMAP_FLAG))
                if (from !== src) from.recycle()
            } finally {
                inp.unlockCanvasAndPost(c)
            }
        } catch (t: Throwable) {
            return null
        }
        if (!latch.await(5, TimeUnit.SECONDS)) return null
        return gg.snapshot(ow, oh)
    }

    @Synchronized
    fun release() {
        runCatching { g?.release() }
        runCatching { reader?.close() }
        g = null
        input = null
        reader = null
    }
}
