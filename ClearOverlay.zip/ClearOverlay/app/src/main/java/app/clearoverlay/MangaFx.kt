package app.clearoverlay

import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.media.ImageReader
import android.os.Handler
import android.os.Looper
import android.view.Surface
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.max

/**
 * Runs the player's picture effects (denoise / upscale / sharpen / vivid ...) on a manga page, off screen:
 * the page goes through the same GL pipeline as photos in the player and comes back as a Bitmap.
 * One instance keeps one GL context alive; call [process] from a worker thread only.
 */
class MangaFx {
    private var g: GlPipeline? = null
    private var input: Surface? = null
    private var reader: ImageReader? = null
    private var failed = false

    @Synchronized
    private fun ensure(w: Int, h: Int): Boolean {
        if (g != null) return true
        if (failed) return false
        val r = ImageReader.newInstance(2, 2, PixelFormat.RGBA_8888, 2)
        r.setOnImageAvailableListener({ it.acquireLatestImage()?.close() }, Handler(Looper.getMainLooper()))
        val gg = GlPipeline(r.surface)
        gg.manualOnly = true
        val ready = CountDownLatch(1)
        gg.onError = {
            failed = true
            ready.countDown()
        }
        gg.start(w, h) { s ->
            input = s
            ready.countDown()
        }
        if (!ready.await(6, TimeUnit.SECONDS) || input == null) {
            failed = true
            runCatching { gg.release() }
            runCatching { r.close() }
            return false
        }
        reader = r
        g = gg
        return true
    }

    /** The page with the current effects applied (a bit larger when an upscaler is active), or null if that failed. */
    @Synchronized
    fun process(src: Bitmap): Bitmap? {
        if (src.isRecycled || !ensure(src.width, src.height)) return null
        val gg = g ?: return null
        val inp = input ?: return null
        gg.setCaptureSize(src.width, src.height)
        val latch = CountDownLatch(1)
        gg.frameLatch = latch
        try {
            val c = inp.lockCanvas(null)
            try {
                c.drawBitmap(src, null, Rect(0, 0, c.width, c.height), Paint(Paint.FILTER_BITMAP_FLAG))
            } finally {
                inp.unlockCanvasAndPost(c)
            }
        } catch (t: Throwable) {
            return null
        }
        if (!latch.await(3, TimeUnit.SECONDS)) return null
        val long = max(src.width, src.height).toFloat()
        val k = (3200f / long).coerceIn(1f, 1.5f)
        val ow = (src.width * k).toInt().coerceAtLeast(2)
        val oh = (src.height * k).toInt().coerceAtLeast(2)
        return gg.snapshot(ow, oh)
    }

    @Synchronized
    fun release() {
        runCatching { g?.release() }
        runCatching { reader?.close() }
        g = null
        input = null
        reader = null
    }
}
