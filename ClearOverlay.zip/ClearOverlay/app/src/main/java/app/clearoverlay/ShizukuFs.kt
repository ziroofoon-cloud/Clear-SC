package app.clearoverlay

import android.os.ParcelFileDescriptor
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

/** Android/data or Android/obb through the Shizuku helper. Paths are the real file paths (like [LocalFs]), [base] is the top. */
class ShizukuFs(private val s: IShellFs, private val base: String) : FmFs {

    private fun <T> call(b: () -> T): T = try {
        b()
    } catch (e: android.os.RemoteException) {
        ShizukuAccess.reset()
        throw IOException("the Shizuku helper stopped, open the folder again")
    }

    override fun root(): String = base

    override fun parent(path: String): String? {
        if (path == base) return null
        val p = File(path).parent ?: return null
        return if (p == base || p.startsWith("$base/")) p else null
    }

    override fun join(dir: String, name: String): String = if (dir.endsWith("/")) dir + name else "$dir/$name"

    override fun list(dir: String): MutableList<FmItem> {
        val rows = call { s.list(dir) } ?: throw IOException("cannot read $dir")
        val out = ArrayList<FmItem>(rows.size)
        for (r in rows) {
            val p = r.split('\t', limit = 4)
            if (p.size < 4) continue
            out.add(FmItem(p[3], p[0] == "d", p[1].toLongOrNull() ?: -1L, p[2].toLongOrNull() ?: 0L))
        }
        return out
    }

    override fun open(path: String): InputStream {
        val pfd = call { s.open(path, "r") } ?: throw IOException("cannot open $path")
        return ParcelFileDescriptor.AutoCloseInputStream(pfd)
    }

    private inner class Out(private val o: OutputStream, private val path: String) : OutputStream(), FmAbortable {
        override fun write(b: Int) = o.write(b)
        override fun write(b: ByteArray, off: Int, len: Int) = o.write(b, off, len)
        override fun flush() = o.flush()
        override fun close() = o.close()
        override fun abort() {
            runCatching { o.close() }
            runCatching { s.deleteTree(path) }
        }
    }

    override fun create(path: String, size: Long): OutputStream {
        val pfd = call { s.open(path, "w") } ?: throw IOException("cannot write $path")
        return Out(ParcelFileDescriptor.AutoCloseOutputStream(pfd), path)
    }

    override fun mkdir(path: String) {
        if (!call { s.mkdirs(path) }) throw IOException("cannot create $path")
    }

    override fun delete(path: String) {
        if (!call { s.exists(path) }) return
        if (!call { s.deleteTree(path) }) throw IOException("cannot delete $path")
    }

    override fun rename(path: String, newName: String) {
        val parent = parent(path) ?: throw IOException("bad path $path")
        val to = join(parent, newName)
        if (call { s.exists(to) }) throw IOException("already exists: $newName")
        if (!call { s.rename(path, to) }) throw IOException("cannot rename " + FmCopy.baseName(path))
    }

    override fun moveWithin(from: String, to: String): Boolean = !call { s.exists(to) } && call { s.rename(from, to) }

    override fun exists(path: String): Boolean = call { s.exists(path) }

    override fun localFile(path: String): File? = null

    override fun freeSpace(): Long = runCatching { call { s.free(base) } }.getOrDefault(-1L)

    override fun close() {}
}
