package app.clearoverlay

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var btn: TextView

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            ui.postDelayed(this, 700)
        }
    }

    override fun attachBaseContext(newBase: android.content.Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Cfg.load(this)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG

        val version = runCatching {
            @Suppress("DEPRECATION")
            packageManager.getPackageInfo(packageName, 0).versionName
        }.getOrNull() ?: "3.1.0"

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(this@MainActivity, 20), dp(this@MainActivity, 28), dp(this@MainActivity, 20), dp(this@MainActivity, 28))
        }

        // ---- header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(
            LogoView(this).apply { importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO },
            LinearLayout.LayoutParams(dp(this, 60), dp(this, 60))
        )
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(this@MainActivity, 14), 0, 0, 0)
        }
        titles.addView(Ui.text(this, "+CRSC", 30f, Ui.TEXT, true))
        titles.addView(Ui.text(this, getString(R.string.main_subtitle_fmt, version), 12f, Ui.MUTED))
        header.addView(titles)
        col.addView(header)

        // ---- status + big button
        status = Ui.text(this, "", 13f, Ui.MUTED, true)
        col.addView(status, lp(16))

        btn = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            setOnClickListener { onToggle() }
        }
        col.addView(btn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(this, 56)).apply {
            topMargin = dp(this@MainActivity, 10)
        })

        // ---- built-in video / photo player
        val playerBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val playerBtn = TextView(this).apply {
            text = getString(R.string.player_button)
            gravity = Gravity.CENTER
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Ui.BG)
            background = Ui.gradient(dp(this@MainActivity, 14).toFloat())
            setOnClickListener { startActivity(Intent(this@MainActivity, PlayerActivity::class.java)) }
        }
        playerBox.addView(
            playerBtn,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(this, 48))
        )
        playerBox.addView(Ui.text(this, getString(R.string.player_hint), 12f, Ui.MUTED), lp(8))
        col.addView(card(playerBox), lp(18))

        // ---- controls card
        col.addView(card(buildControls(this) { OverlayService.instance?.applyConfig() }), lp(12))

        // ---- bubble card
        val bubbleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val bubbleSwitch = Switch(this).apply {
            text = getString(R.string.floating_bubble_switch)
            setTextColor(Ui.TEXT)
            textSize = 15f
            isChecked = Cfg.bubble
            setOnCheckedChangeListener { _, on ->
                Cfg.bubble = on
                Cfg.save(this@MainActivity)
                OverlayService.instance?.updateBubble()
            }
        }
        bubbleBox.addView(bubbleSwitch)
        bubbleBox.addView(
            Ui.text(this, getString(R.string.bubble_hint), 12f, Ui.MUTED),
            lp(6)
        )
        col.addView(card(bubbleBox), lp(12))

        // ---- language card
        val langBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        langBox.addView(Ui.text(this, getString(R.string.lang_label), 12f, Ui.MUTED))
        val langRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val langs = listOf(
            getString(R.string.lang_system) to Lang.SYSTEM,
            "English" to Lang.EN,
            "\u0641\u0627\u0631\u0633\u06cc" to Lang.FA
        )
        langs.forEachIndexed { i, (label, code) ->
            val chip = TextView(this).apply {
                text = label
                textSize = 14f
                gravity = Gravity.CENTER
                setPadding(dp(this@MainActivity, 8), dp(this@MainActivity, 10), dp(this@MainActivity, 8), dp(this@MainActivity, 10))
                val r = dp(this@MainActivity, 12).toFloat()
                if (Cfg.lang == code) {
                    background = Ui.gradient(r)
                    setTextColor(Ui.BG)
                    setTypeface(typeface, Typeface.BOLD)
                } else {
                    background = Ui.round(Ui.CHIP, r)
                    setTextColor(Ui.MUTED)
                }
                setOnClickListener {
                    if (Cfg.lang != code) {
                        Cfg.lang = code
                        Cfg.save(this@MainActivity)
                        recreate()
                    }
                }
            }
            langRow.addView(
                chip,
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    if (i != langs.lastIndex) marginEnd = dp(this@MainActivity, 6)
                }
            )
        }
        langBox.addView(langRow, lp(6))
        col.addView(card(langBox), lp(12))

        // ---- notes
        col.addView(Ui.text(this, getString(R.string.notes_text), 12f, Ui.MUTED), lp(16))
        col.addView(Ui.text(this, getString(R.string.license_line), 11f, Ui.MUTED), lp(10))

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            isFillViewport = true
            addView(col)
        })
    }

    override fun onResume() {
        super.onResume()
        ui.post(ticker)
    }

    override fun onPause() {
        ui.removeCallbacks(ticker)
        super.onPause()
    }

    private fun lp(top: Int) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(this@MainActivity, top) }

    private fun card(content: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = Ui.round(Ui.CARD, dp(this@MainActivity, 20).toFloat(), Ui.STROKE, dp(this@MainActivity, 1))
        val p = dp(this@MainActivity, 16)
        setPadding(p, p, p, p)
        addView(content)
    }

    private fun refresh() {
        val on = OverlayService.running
        val shown = on && (OverlayService.instance?.active == true)
        status.text = when {
            !on -> getString(R.string.status_stopped)
            shown -> getString(R.string.status_running_on)
            else -> getString(R.string.status_running_off)
        }
        status.setTextColor(if (on) Ui.OK else Ui.MUTED)
        btn.text = if (on) getString(R.string.action_stop) else getString(R.string.action_start)
        btn.setTextColor(if (on) Ui.TEXT else Ui.BG)
        btn.background = if (on) {
            Ui.round(Ui.DANGER, dp(this, 18).toFloat())
        } else {
            Ui.gradient(dp(this, 18).toFloat())
        }
    }

    private fun onToggle() {
        if (OverlayService.running) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACT_STOP))
            ui.postDelayed({ refresh() }, 400)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, getString(R.string.toast_allow_overlay), Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            return
        }
        askCapture()
    }

    private fun askCapture() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == REQ_NOTIF) askCapture() // the notification is optional; continue either way
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == REQ_CAPTURE && res == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, OverlayService::class.java)
                    .setAction(OverlayService.ACT_START)
                    .putExtra(OverlayService.EXTRA_CODE, res)
                    .putExtra(OverlayService.EXTRA_DATA, data)
            )
            ui.postDelayed({ refresh() }, 700)
        }
    }

    private companion object {
        const val REQ_CAPTURE = 7
        const val REQ_NOTIF = 8
    }
}
