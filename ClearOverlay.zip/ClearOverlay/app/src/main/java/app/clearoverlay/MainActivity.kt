package app.clearoverlay

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var btn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Cfg.load(this)

        val pad = dp(20)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        col.addView(text("Clear Overlay", 24f))
        status = text("", 15f)
        col.addView(status)

        btn = Button(this)
        btn.setOnClickListener { onToggle() }
        col.addView(btn)

        val sharpLabel = text("", 16f)
        val sharpBar = SeekBar(this).apply {
            max = 100
            progress = (Cfg.sharp * 100).toInt()
        }
        sharpLabel.text = "Sharpness: ${sharpBar.progress}"
        sharpBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                Cfg.sharp = p / 100f
                sharpLabel.text = "Sharpness: $p"
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) = Cfg.save(this@MainActivity)
        })
        col.addView(sharpLabel)
        col.addView(sharpBar)

        val scaleLabel = text("", 16f)
        val scaleBar = SeekBar(this).apply {
            max = 50
            progress = Cfg.scalePct.coerceIn(50, 100) - 50
        }
        scaleLabel.text = scaleText(50 + scaleBar.progress)
        scaleBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                scaleLabel.text = scaleText(50 + p)
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {
                Cfg.scalePct = 50 + s.progress
                Cfg.save(this@MainActivity)
                OverlayService.instance?.applyScale()
            }
        })
        col.addView(scaleLabel)
        col.addView(scaleBar)

        col.addView(
            text(
                "100% = sharpen only (best quality). Lower values capture at a smaller size " +
                    "and upscale it back (upscale mode: lighter, but softer).",
                13f
            )
        )

        setContentView(ScrollView(this).apply { addView(col) })
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun scaleText(pct: Int) =
        if (pct == 100) "Render scale: 100% (sharpen only)" else "Render scale: $pct% (upscale)"

    private fun refresh() {
        val on = OverlayService.running
        status.text = if (on) "Status: running" else "Status: stopped"
        btn.text = if (on) "Stop" else "Start"
    }

    private fun onToggle() {
        if (OverlayService.running) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACT_STOP))
            ui.postDelayed({ refresh() }, 400)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow \"Display over other apps\", then press Start again", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            return
        }
        askCapture()
    }

    private fun askCapture() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == REQ_NOTIF) askCapture() // the notification is optional; continue either way
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == REQ_CAPTURE && res == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, OverlayService::class.java)
                    .setAction(OverlayService.ACT_START)
                    .putExtra(OverlayService.EXTRA_CODE, res)
                    .putExtra(OverlayService.EXTRA_DATA, data)
            )
            ui.postDelayed({ refresh() }, 700)
        }
    }

    private fun text(s: String, size: Float) = TextView(this).apply {
        text = s
        textSize = size
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(12) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private companion object {
        const val REQ_CAPTURE = 7
        const val REQ_NOTIF = 8
    }
}
