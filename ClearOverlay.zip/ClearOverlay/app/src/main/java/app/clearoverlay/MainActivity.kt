package app.clearoverlay

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var btn: TextView

    private val ticker = object : Runnable {
        override fun run() {
            if (::status.isInitialized && ::btn.isInitialized) refresh() // the screen may still be being built behind the opening scene
            ui.postDelayed(this, 700)
        }
    }

    override fun attachBaseContext(newBase: android.content.Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        IntroSplash.markCreate()
        // Reading the settings and making the palette is not needed by the opening scene: when the scene will be shown it goes on the screen
        // FIRST, and this is done in buildScreen after its first frame (the scene starts as early as the process allows)
        val sceneFirst = savedInstanceState == null && IntroSplash.wouldShow(this)
        if (!sceneFirst) {
            Cfg.bind(this, "screen")
            Ui.init(this)
            setTheme(Ui.theme())
            themed = true
        }
        super.onCreate(savedInstanceState)
        val ver0 = runCatching {
            @Suppress("DEPRECATION")
            packageManager.getPackageInfo(packageName, 0).versionName
        }.getOrNull() ?: "3.1.0"
        // the opening scene is drawn FIRST (cheap), the main screen is built after its first frame and put under it: the real loading time hides
        // behind the animation instead of showing a plain logo
        val host = if (savedInstanceState == null) IntroSplash.begin(this, ver0) else null
        IntroSplash.measureFirstFrame(this)
        if (host == null) {
            buildScreen(savedInstanceState, null)
            return
        }
        host.viewTreeObserver.addOnPreDrawListener(object : android.view.ViewTreeObserver.OnPreDrawListener {
            override fun onPreDraw(): Boolean {
                host.viewTreeObserver.removeOnPreDrawListener(this)
                ui.postDelayed({ if (!isFinishing && !isDestroyed) buildScreen(savedInstanceState, host) }, IntroSplash.BUILD_AFTER_MS)
                return true
            }
        })
    }

    private var themed = false // settings read, palette made and theme set (done before the screen is built, or here when the scene went first)
    private var resumed = false
    private var screenBuilt = false

    private fun buildScreen(savedInstanceState: Bundle?, host: FrameLayout?) {
        if (!themed) {
            Cfg.bind(this, "screen")
            Ui.init(this)
            setTheme(Ui.theme())
            window.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Ui.BG)) // the window was made with the launch theme
            themed = true
        }
        val appCtx = applicationContext
        Thread { Storage.autoClean(appCtx) }.start() // old temporary files go away by themselves
        Ui.styleBars(window)

        val version = runCatching {
            @Suppress("DEPRECATION")
            packageManager.getPackageInfo(packageName, 0).versionName
        }.getOrNull() ?: "3.1.0"

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(this@MainActivity, 20), dp(this@MainActivity, 28), dp(this@MainActivity, 20), dp(this@MainActivity, 28))
        }

        // ---- header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(
            LogoView(this).apply { importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO },
            LinearLayout.LayoutParams(dp(this, 50), dp(this, 50))
        )
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(this@MainActivity, 14), 0, 0, 0)
        }
        titles.addView(Ui.text(this, "+CRSC", 30f, Ui.TEXT, true))
        titles.addView(Ui.text(this, getString(R.string.main_subtitle_fmt, version), 12f, Ui.MUTED))
        header.addView(titles)
        col.addView(header)

        // ---- status + big button
        status = Ui.text(this, "", 13f, Ui.MUTED, true)
        col.addView(status, lp(16))

        btn = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            setOnClickListener { onToggle() }
        }
        col.addView(btn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(this, 56)).apply {
            topMargin = dp(this@MainActivity, 10)
        })
        val bubbleSlot = col.childCount // the bubble card (it belongs to the screen layer) is put here further down

        fun secTitle(res: Int) = Ui.text(this, getString(res), 12f, Ui.ACCENT, true).apply { setPadding(dp(this@MainActivity, 4), 0, 0, 0) }
        // ---- built-in video / photo player
        col.addView(secTitle(R.string.home_sec_media), lp(22))
        val playerBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val playerBtn = TextView(this).apply {
            text = getString(R.string.lib_button)
            gravity = Gravity.CENTER
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Ui.BG)
            background = Ui.gradient(dp(this@MainActivity, 14).toFloat())
            setOnClickListener { startActivity(Intent(this@MainActivity, LibraryActivity::class.java)) }
        }
        playerBox.addView(
            playerBtn,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(this, 48))
        )
        // the file manager right under the Library: phone files (also hidden and protected ones), network shares, cloud accounts
        playerBox.addView(
            LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(this@MainActivity, 14), 0, dp(this@MainActivity, 14), 0)
                background = Ui.round(Ui.CARD, dp(this@MainActivity, 14).toFloat(), Ui.ACCENT, dp(this@MainActivity, 1))
                // an ImageView (not a TextView with a drawable): the icon is centred on the text block instead of sitting above it
                val ic = ImageView(this@MainActivity).apply { setImageDrawable(LineIcon(Icons.FOLDER, Ui.ACCENT)); scaleType = ImageView.ScaleType.FIT_CENTER }
                addView(ic, LinearLayout.LayoutParams(dp(this@MainActivity, 28), dp(this@MainActivity, 28)).apply { marginEnd = dp(this@MainActivity, 12) })
                val col = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
                col.addView(Ui.text(this@MainActivity, getString(R.string.fm_title), 16f, Ui.TEXT, true))
                col.addView(Ui.text(this@MainActivity, getString(R.string.fm_button_sub), 11f, Ui.MUTED).apply { maxLines = 1 })
                addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                addView(Ui.text(this@MainActivity, "›", 22f, Ui.ACCENT, true))
                setOnClickListener { startActivity(Intent(this@MainActivity, FilesActivity::class.java)) }
            },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(this, 56)).apply { topMargin = dp(this@MainActivity, 8) }
        )
        // the other entries as a grid of tiles (icon + name), two per row
        fun tile(icon: Int, label: Int, go: () -> Unit): View = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(this@MainActivity, 12), dp(this@MainActivity, 8), dp(this@MainActivity, 10), dp(this@MainActivity, 8))
            background = Ui.round(Ui.CHIP, dp(this@MainActivity, 12).toFloat(), Ui.STROKE, dp(this@MainActivity, 1))
            addView(ImageView(this@MainActivity).apply { setImageDrawable(LineIcon(icon, Ui.ACCENT)); scaleType = ImageView.ScaleType.FIT_CENTER },
                LinearLayout.LayoutParams(dp(this@MainActivity, 24), dp(this@MainActivity, 24)).apply { marginEnd = dp(this@MainActivity, 10) })
            addView(Ui.text(this@MainActivity, getString(label), 13f, Ui.TEXT, true).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            setOnClickListener { go() }
        }
        val tiles = listOf(
            tile(Icons.FILM, R.string.player_button) { startActivity(Intent(this, PlayerActivity::class.java)) },
            tile(Icons.MUSIC, R.string.main_music) { startActivity(Intent(this, AudioActivity::class.java)) },
            tile(Icons.OPEN, R.string.export_title) { startActivity(Intent(this, ExportActivity::class.java)) },
            tile(Icons.EDIT, R.string.edit_hub_button) { startActivity(Intent(this, EditHubActivity::class.java)) },
            tile(Icons.TRASH, R.string.main_storage) { Storage.show(this) }
        )
        var ti = 0
        while (ti < tiles.size) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            r.addView(tiles[ti], LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
            if (ti + 1 < tiles.size) r.addView(tiles[ti + 1], LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply { marginStart = dp(this@MainActivity, 8) })
            playerBox.addView(r, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(this, 54)).apply { topMargin = dp(this@MainActivity, 8) })
            ti += 2
        }
        playerBox.addView(Ui.text(this, getString(R.string.player_hint), 12f, Ui.MUTED), lp(8))
        col.addView(card(playerBox), lp(6))

        col.addView(secTitle(R.string.home_sec_stream), lp(22))
        // ---- PC game streaming (Moonlight): picture settings for the stream + a shortcut to the Moonlight app
        val moonBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        moonBox.addView(
            LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                // the Moonlight client's own logo
                addView(ImageView(this@MainActivity).apply {
                    setImageResource(R.drawable.moonlight_logo)
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    background = Ui.round(Ui.CHIP, dp(this@MainActivity, 14).toFloat())
                    val p = dp(this@MainActivity, 4)
                    setPadding(p, p, p, p)
                }, LinearLayout.LayoutParams(dp(this@MainActivity, 50), dp(this@MainActivity, 50)))
                addView(Ui.text(this@MainActivity, getString(R.string.moon_title), 16f, Ui.TEXT, true),
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(this@MainActivity, 12) })
            }
        )
        moonBox.addView(Ui.text(this, getString(R.string.moon_hint), 12f, Ui.MUTED), lp(6))
        // direct mode: the client's video and sound go straight into the +CRSC engine (no screen capture, no floating layer)
        moonBox.addView(
            panelSwitch(this, getString(R.string.moon_direct), StreamFx.directOn(this)) { StreamFx.setDirect(this, it) },
            lp(10)
        )
        moonBox.addView(Ui.text(this, getString(R.string.moon_direct_hint), 12f, Ui.MUTED), lp(4))
        moonBox.addView(
            TextView(this).apply {
                text = getString(R.string.moon_apply)
                gravity = Gravity.CENTER
                textSize = 14f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Ui.BG)
                background = Ui.gradient(dp(this@MainActivity, 12).toFloat())
                setOnClickListener { applyMoonlight(true) }
            },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(this, 44)).apply { topMargin = dp(this@MainActivity, 10) }
        )
        moonBox.addView(
            TextView(this).apply {
                text = getString(R.string.moon_open)
                gravity = Gravity.CENTER
                textSize = 14f
                setTextColor(Ui.ACCENT)
                background = Ui.round(Ui.CHIP, dp(this@MainActivity, 12).toFloat(), Ui.ACCENT, dp(this@MainActivity, 1))
                setOnClickListener { openMoonlight() }
            },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(this, 42)).apply { topMargin = dp(this@MainActivity, 8) }
        )
        moonBox.addView(
            TextView(this).apply {
                text = getString(R.string.sp_title)
                gravity = Gravity.CENTER
                textSize = 14f
                setTextColor(Ui.ACCENT)
                background = Ui.round(Ui.CHIP, dp(this@MainActivity, 12).toFloat(), Ui.ACCENT, dp(this@MainActivity, 1))
                setOnClickListener { StreamPresets.show(this@MainActivity) }
            },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(this, 42)).apply { topMargin = dp(this@MainActivity, 8) }
        )
        col.addView(card(moonBox), lp(6))

        col.addView(secTitle(R.string.home_sec_fx), lp(22))
        // ---- controls card
        col.addView(card(buildControls(this) { OverlayService.instance?.applyConfig() }), lp(6))

        col.addView(secTitle(R.string.home_sec_app), lp(22))
        // ---- settings backup card
        val bkBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        bkBox.addView(TextView(this).apply { text = getString(R.string.fxb_title); textSize = 16f; setTextColor(Ui.TEXT); typeface = android.graphics.Typeface.DEFAULT_BOLD })
        bkBox.addView(TextView(this).apply { text = getString(R.string.fxb_hint); textSize = 12f; setTextColor(Ui.MUTED) }, lp(4))
        val bkRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun bkBtn(label: Int, act: () -> Unit) = TextView(this).apply {
            text = getString(label)
            gravity = Gravity.CENTER
            textSize = 13f
            setTextColor(Ui.ACCENT)
            background = Ui.round(Ui.CHIP, dp(this@MainActivity, 12).toFloat(), Ui.ACCENT, dp(this@MainActivity, 1))
            setOnClickListener { act() }
        }
        for ((i, b) in listOf(
            bkBtn(R.string.fxb_save) { FxBackup.pickSave(this) },
            bkBtn(R.string.fxb_load) { FxBackup.pickLoad(this) },
            bkBtn(R.string.fxb_share) { FxBackup.share(this) }
        ).withIndex()) bkRow.addView(b, LinearLayout.LayoutParams(0, dp(this, 42), 1f).apply { if (i > 0) marginStart = dp(this@MainActivity, 8) })
        bkBox.addView(bkRow, lp(10))
        col.addView(card(bkBox), lp(6))

        // (the upscaler speed choice lives in the picture settings, section "Speed"; it used to be repeated here)

        // ---- bubble card
        val bubbleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val bubbleSwitch = Switch(this).apply {
            text = getString(R.string.floating_bubble_switch)
            setTextColor(Ui.TEXT)
            textSize = 15f
            isChecked = Cfg.bubble
            setOnCheckedChangeListener { _, on ->
                Cfg.bubble = on
                Cfg.save(this@MainActivity)
                OverlayService.instance?.updateBubble()
            }
        }
        bubbleBox.addView(bubbleSwitch)
        bubbleBox.addView(
            Ui.text(this, getString(R.string.bubble_hint), 12f, Ui.MUTED),
            lp(6)
        )
        col.addView(card(bubbleBox), bubbleSlot, lp(12))

        // ---- appearance card: colour mode + style
        val lookBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        lookBox.addView(Ui.text(this, getString(R.string.theme_label), 12f, Ui.MUTED))
        lookBox.addView(
            chipRow(listOf(getString(R.string.theme_system), getString(R.string.theme_dark), getString(R.string.theme_light)), Cfg.themeMode) { i ->
                Cfg.themeMode = i
                Cfg.save(this)
                recreate()
            },
            lp(6)
        )
        lookBox.addView(Ui.text(this, getString(R.string.theme_style_label), 12f, Ui.MUTED), lp(12))
        lookBox.addView(
            chipRow(listOf(getString(R.string.theme_modern), getString(R.string.theme_classic)), Cfg.themeStyle) { i ->
                Cfg.themeStyle = i
                Cfg.save(this)
                recreate()
            },
            lp(6)
        )
        lookBox.addView(Ui.text(this, getString(R.string.app_dir_label), 12f, Ui.MUTED), lp(12))
        lookBox.addView(
            DirIcons.row(this, intArrayOf(DirIcons.FREE, DirIcons.PORT, DirIcons.LAND), listOf(getString(R.string.app_dir_follow), getString(R.string.app_dir_portrait), getString(R.string.app_dir_landscape)), Cfg.appDir) { i ->
                Cfg.appDir = i
                Cfg.save(this)
                AppDirection.apply(this)
            },
            lp(6)
        )
        // the direction diary (DirLog): copy it when a screen comes up in the wrong direction
        lookBox.addView(Ui.text(this, getString(R.string.dir_report), 13f, Ui.ACCENT, true).apply { setOnClickListener { DirLog.copy(this@MainActivity) } }, lp(10))
        lookBox.addView(Ui.text(this, getString(R.string.theme_accent_label), 12f, Ui.MUTED), lp(12))
        val swatches = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in 0..7) {
            val a = Ui.ACCENTS[if (i == 0) 0 else i]
            val col1 = android.graphics.Color.parseColor(if (Ui.light) a[2] else a[0])
            val col2 = android.graphics.Color.parseColor(if (Ui.light) a[3] else a[1])
            val sel = Cfg.themeAccent == i
            val dot = View(this).apply {
                background = android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR, intArrayOf(col1, col2)).apply {
                    shape = android.graphics.drawable.GradientDrawable.OVAL
                    if (sel) setStroke(dp(this@MainActivity, 3), Ui.TEXT)
                }
                setOnClickListener {
                    Cfg.themeAccent = i
                    Cfg.save(this@MainActivity)
                    recreate()
                }
            }
            swatches.addView(dot, LinearLayout.LayoutParams(dp(this, 32), dp(this, 32)).apply { if (i > 0) marginStart = dp(this@MainActivity, 10) })
        }
        lookBox.addView(android.widget.HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(swatches) }, lp(8))
        lookBox.addView(Ui.text(this, getString(R.string.ui_mode_label), 12f, Ui.MUTED), lp(12))
        lookBox.addView(
            chipRow(listOf(getString(R.string.ui_mode_full), getString(R.string.ui_mode_light), getString(R.string.ui_mode_minimal)), Cfg.uiMode) { i ->
                Cfg.uiMode = i
                Cfg.save(this)
                recreate()
            },
            lp(6)
        )
        col.addView(card(lookBox), lp(12))

        // ---- language card
        val langBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        langBox.addView(Ui.text(this, getString(R.string.lang_label), 12f, Ui.MUTED))
        val langRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val langs = listOf(
            getString(R.string.lang_system) to Lang.SYSTEM,
            "English" to Lang.EN,
            "\u0641\u0627\u0631\u0633\u06cc" to Lang.FA
        )
        langs.forEachIndexed { i, (label, code) ->
            val chip = TextView(this).apply {
                text = label
                textSize = 14f
                gravity = Gravity.CENTER
                setPadding(dp(this@MainActivity, 8), dp(this@MainActivity, 10), dp(this@MainActivity, 8), dp(this@MainActivity, 10))
                val r = dp(this@MainActivity, 12).toFloat()
                if (Cfg.lang == code) {
                    background = Ui.gradient(r)
                    setTextColor(Ui.BG)
                    setTypeface(typeface, Typeface.BOLD)
                } else {
                    background = Ui.round(Ui.CHIP, r)
                    setTextColor(Ui.MUTED)
                }
                setOnClickListener {
                    if (Cfg.lang != code) {
                        Cfg.lang = code
                        Cfg.save(this@MainActivity)
                        recreate()
                    }
                }
            }
            langRow.addView(
                chip,
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    if (i != langs.lastIndex) marginEnd = dp(this@MainActivity, 6)
                }
            )
        }
        langBox.addView(langRow, lp(6))
        // ---- opening scene: on / off, how long it stays, and how long the plain logo before it took (that is the app's real loading time)
        val introLen = Ui.text(this, "", 13f, Ui.TEXT)
        fun holdText(ms: Int) = getString(R.string.intro_len_fmt, String.format(java.util.Locale.US, "%.1f", ms / 1000f))
        val introBar = SeekBar(this).apply {
            max = (IntroSplash.HOLD_MAX - IntroSplash.HOLD_MIN) / 100
            progress = (IntroSplash.holdMs(this@MainActivity) - IntroSplash.HOLD_MIN) / 100
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    val ms = IntroSplash.HOLD_MIN + p * 100
                    introLen.text = holdText(ms)
                    if (fromUser) IntroSplash.setHoldMs(this@MainActivity, ms)
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        introLen.text = holdText(IntroSplash.holdMs(this))
        val introOpts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(introLen, lp(8))
            addView(introBar, lp(2))
            IntroSplash.lastStart(this@MainActivity)?.let { (frame, _) ->
                addView(Ui.text(this@MainActivity, getString(R.string.intro_boot_fmt, frame), 11f, Ui.MUTED), lp(6))
            }
        }
        introOpts.visibility = if (IntroSplash.enabled(this)) View.VISIBLE else View.GONE
        // the opening scene belongs to how the app looks (it was under the language choice): at the end of the appearance card
        lookBox.addView(panelSwitch(this, getString(R.string.intro_switch), IntroSplash.enabled(this)) {
            IntroSplash.setEnabled(this, it)
            introOpts.visibility = if (it) View.VISIBLE else View.GONE
        }, lp(14))
        lookBox.addView(introOpts)
        col.addView(card(langBox), lp(12))

        // ---- AI model files: copy / move them out of the app (to any folder)
        col.addView(
            Ui.text(this, getString(R.string.model_files_button), 14f, Ui.ACCENT, true).apply {
                gravity = Gravity.CENTER
                background = Ui.round(Ui.CHIP, dp(this@MainActivity, 12).toFloat(), Ui.STROKE, dp(this@MainActivity, 1))
                setPadding(dp(this@MainActivity, 12), dp(this@MainActivity, 12), dp(this@MainActivity, 12), dp(this@MainActivity, 12))
                setOnClickListener { if (AiSr.list(this@MainActivity).isEmpty()) Toast.makeText(this@MainActivity, R.string.model_files_none, Toast.LENGTH_LONG).show() else ModelFiles.start(this@MainActivity) }
            },
            lp(12)
        )

        // ---- notes
        col.addView(Ui.text(this, getString(R.string.notes_text), 12f, Ui.MUTED), lp(16))
        col.addView(Ui.text(this, getString(R.string.license_line), 11f, Ui.MUTED), lp(10))

        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Ui.BG) }
        page.addView(ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            isFillViewport = true
            addView(col)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        MiniPlayer.attach(this, page)
        if (host != null) host.addView(page, 0, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)) else setContentView(page)
        builtPalette = paletteSig()
        screenBuilt = true
        if (resumed) ui.post(ticker) // onResume came while the scene was still up and did not start it
        IntroSplash.markReady()
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        if (!screenBuilt) return // the opening scene is up and the screen is not built yet: buildScreen does the set-up and starts the ticker
        Cfg.bind(this, "screen")
        Ui.init(this)
        // the colours are shared by all screens (the video / photo screens switch them to the dark set): when they are not the ones this
        // screen was built with (it came back from such a screen), the buttons would stay in the wrong colours (black) until touched
        if (builtPalette != 0 && builtPalette != paletteSig()) {
            recreate()
            return
        }
        ui.post(ticker)
    }

    private var builtPalette = 0
    private fun paletteSig(): Int = ((Ui.BG * 31 + Ui.CHIP) * 31 + Ui.ACCENT) * 31 + (if (Ui.classic) 1 else 0)

    override fun onPause() {
        resumed = false
        ui.removeCallbacks(ticker)
        super.onPause()
    }

    /** A row of equal chips; the one at [selected] is highlighted. */
    private fun chipRow(labels: List<String>, selected: Int, onPick: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        labels.forEachIndexed { i, label ->
            val chip = TextView(this).apply {
                text = label
                textSize = 14f
                gravity = Gravity.CENTER
                setPadding(dp(this@MainActivity, 8), dp(this@MainActivity, 10), dp(this@MainActivity, 8), dp(this@MainActivity, 10))
                val r = dp(this@MainActivity, 12).toFloat()
                if (i == selected) {
                    background = Ui.gradient(r)
                    setTextColor(Ui.BG)
                    setTypeface(typeface, Typeface.BOLD)
                } else {
                    background = Ui.round(Ui.CHIP, r)
                    setTextColor(Ui.MUTED)
                }
                setOnClickListener { if (i != selected) onPick(i) }
            }
            row.addView(chip, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                if (i != labels.lastIndex) marginEnd = dp(this@MainActivity, 6)
            })
        }
        row.isBaselineAligned = false
        return row
    }

    private fun lp(top: Int) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(this@MainActivity, top) }

    private fun card(content: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = Ui.round(Ui.CARD, dp(this@MainActivity, 20).toFloat(), Ui.STROKE, dp(this@MainActivity, 1))
        val p = dp(this@MainActivity, 16)
        setPadding(p, p, p, p)
        addView(content)
    }

    private fun refresh() {
        if (!::status.isInitialized || !::btn.isInitialized) return
        val on = OverlayService.running
        val shown = on && (OverlayService.instance?.active == true)
        status.text = when {
            !on -> getString(R.string.status_stopped)
            shown -> getString(R.string.status_running_on)
            else -> getString(R.string.status_running_off)
        }
        status.setTextColor(if (on) Ui.OK else Ui.MUTED)
        btn.text = if (on) getString(R.string.action_stop) else getString(R.string.action_start)
        btn.setTextColor(if (on) Ui.TEXT else Ui.BG)
        btn.background = if (on) {
            Ui.round(Ui.DANGER, dp(this, 18).toFloat())
        } else {
            Ui.gradient(dp(this, 18).toFloat())
        }
    }

    private fun onToggle() {
        if (OverlayService.running) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACT_STOP))
            ui.postDelayed({ refresh() }, 400)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, getString(R.string.toast_allow_overlay), Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            return
        }
        askCapture()
    }

    /** The "Stream / Moonlight" quick profile on the screen layer (cheapest budget = least delay), then start the layer. */
    private fun applyMoonlight(thenOpen: Boolean = false) {
        // direct mode: the stream is processed inside the client itself, so no screen capture / layer is needed
        if (thenOpen && StreamFx.directOn(this)) {
            openMoonlight()
            return
        }
        Cfg.bind(this, "screen")
        Profiles.applyPick(Profiles.STREAM, 1, Profiles.PERF, false, 1f)
        Cfg.save(this)
        OverlayService.instance?.applyConfig()
        Toast.makeText(this, getString(R.string.moon_applied), Toast.LENGTH_SHORT).show()
        if (OverlayService.running) {
            if (thenOpen) openMoonlight()
            return
        }
        // the screen layer (with its bubble: tap = on / off, hold = settings) is started first; the streaming client opens when it is running
        openMoonAfterStart = thenOpen
        onToggle()
    }

    private var openMoonAfterStart = false

    /** Opens the built-in game streaming client (Artemis / Moonlight): add the PC, pair with the PIN, start a game. */
    private fun openMoonlight() {
        startActivity(Intent(this, com.limelight.PcView::class.java))
    }

    private fun askCapture() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == REQ_NOTIF) askCapture() // the notification is optional; continue either way
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (ModelFiles.handle(this, req, res, data)) return
        if (FxBackup.handle(this, req, res, data)) return
        if (req == REQ_CAPTURE && res == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, OverlayService::class.java)
                    .setAction(OverlayService.ACT_START)
                    .putExtra(OverlayService.EXTRA_CODE, res)
                    .putExtra(OverlayService.EXTRA_DATA, data)
            )
            ui.postDelayed({ refresh() }, 700)
            if (openMoonAfterStart) {
                openMoonAfterStart = false
                ui.postDelayed({ openMoonlight() }, 500)
            }
        } else if (req == REQ_CAPTURE) {
            openMoonAfterStart = false
        }
    }

    private companion object {
        const val REQ_CAPTURE = 7
        const val REQ_NOTIF = 8
    }
}
