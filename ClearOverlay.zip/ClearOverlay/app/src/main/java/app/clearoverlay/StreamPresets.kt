package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.preference.PreferenceManager
import android.widget.Toast

/**
 * One-tap setups for the built-in game streaming client (Artemis): picture size, frame rate, bit rate, codec, frame pacing and
 * delay choices that suit a phone. They only write the client's own settings (the same ones as in its settings screen), so they
 * can still be changed there afterwards. The last choice before streaming is "720p + the app's upscaler": the PC sends a small,
 * clean picture and +CRSC makes it sharp on the phone, which needs less network and less PC power.
 */
object StreamPresets {
    private class P(val label: Int, val hint: Int, val res: String, val fps: String, val kbps: Int, val format: String,
                    val pacing: String, val lowLatency: Boolean, val direct: Boolean? = null)

    private val LIST = listOf(
        P(R.string.sp_best, R.string.sp_best_h, "1920x1080", "60", 30000, "auto", "balanced", false),
        P(R.string.sp_bal, R.string.sp_bal_h, "1920x1080", "60", 20000, "auto", "balanced", false),
        P(R.string.sp_fast, R.string.sp_fast_h, "1280x720", "60", 12000, "auto", "latency", true),
        P(R.string.sp_weak, R.string.sp_weak_h, "1280x720", "30", 5000, "auto", "balanced", false),
        P(R.string.sp_up, R.string.sp_up_h, "1280x720", "60", 15000, "auto", "balanced", false, true),
        P(R.string.sp_smooth, R.string.sp_smooth_h, "1920x1080", "120", 40000, "auto", "balanced", false),
        P(R.string.sp_4k, R.string.sp_4k_h, "3840x2160", "60", 60000, "auto", "balanced", false),
        P(R.string.sp_batt, R.string.sp_batt_h, "1280x720", "30", 8000, "auto", "balanced", false)
    )

    /** The Wi-Fi link speed in Mbps (0 = unknown) and whether the phone is on mobile data. */
    private fun network(a: Activity): Pair<Int, Boolean> {
        var link = 0
        var cell = false
        runCatching {
            val cm = a.getSystemService(android.net.ConnectivityManager::class.java)
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            cell = caps != null && caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR) && !caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI)
            if (caps != null && caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI)) {
                @Suppress("DEPRECATION")
                link = (a.applicationContext.getSystemService(android.content.Context.WIFI_SERVICE) as android.net.wifi.WifiManager).connectionInfo.linkSpeed.coerceAtLeast(0)
            }
        }
        return Pair(link, cell)
    }

    private fun refreshHz(a: Activity): Int = runCatching { a.display?.refreshRate?.let { Math.round(it) } }.getOrNull() ?: 60

    /** The preset that suits this phone and its network: mobile data / slow Wi-Fi get the light ones, fast Wi-Fi and a 90+ Hz screen the smooth one. */
    private fun recommended(link: Int, cell: Boolean, hz: Int): Int = when {
        cell -> 3
        link <= 0 -> 1
        link >= 600 && hz >= 100 -> 5
        link >= 400 -> 0
        link >= 170 -> 1
        link >= 90 -> 2
        else -> 3
    }

    private fun inUse(a: Activity, p: P): Boolean {
        val sp = PreferenceManager.getDefaultSharedPreferences(a)
        return sp.getString("list_resolution", null) == p.res && sp.getString("list_fps", null) == p.fps &&
            runCatching { sp.getInt("seekbar_bitrate_kbps", 0) }.getOrDefault(0) == p.kbps &&
            (p.direct == null || StreamFx.directOn(a) == p.direct)
    }

    fun show(a: Activity) {
        val (link, cell) = network(a)
        val hz = refreshHz(a)
        val reco = recommended(link, cell, hz)
        val info = if (cell) a.getString(R.string.sp_info_cell, hz) else if (link > 0) a.getString(R.string.sp_info_wifi, link, hz) else a.getString(R.string.sp_info_unknown, hz)
        AlertDialog.Builder(a)
            .setTitle(a.getString(R.string.sp_title) + "\n" + info)
            .setItems(LIST.mapIndexed { i, it ->
                a.getString(it.label) + (if (i == reco) "  ★ " + a.getString(R.string.sp_reco) else "") + (if (inUse(a, it)) "  ✓ " + a.getString(R.string.sp_inuse) else "") + "\n" + a.getString(it.hint)
            }.toTypedArray()) { _, i -> apply(a, LIST[i]) }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun apply(a: Activity, p: P) {
        val sp = PreferenceManager.getDefaultSharedPreferences(a)
        sp.edit()
            .putString("list_resolution", p.res)
            .putString("list_fps", p.fps)
            .putInt("seekbar_bitrate_kbps", p.kbps)
            .putString("video_format", p.format)
            .putString("frame_pacing", p.pacing)
            .putBoolean("checkbox_ultra_low_latency", p.lowLatency)
            .putInt("seekbar_resolution_scale_factor", 100)
            .remove("edit_diy_w_h") // a hand-typed size would override the choice
            .remove("edit_diy_bitrate")
            .apply()
        if (p.direct != null) StreamFx.setDirect(a, p.direct)
        Toast.makeText(a, R.string.moon_applied, Toast.LENGTH_SHORT).show()
    }
}
