package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.preference.PreferenceManager
import android.widget.Toast

/**
 * One-tap setups for the built-in game streaming client (Artemis): picture size, frame rate, bit rate, codec, frame pacing and
 * delay choices that suit a phone. They only write the client's own settings (the same ones as in its settings screen), so they
 * can still be changed there afterwards. The last choice before streaming is "720p + the app's upscaler": the PC sends a small,
 * clean picture and +CRSC makes it sharp on the phone, which needs less network and less PC power.
 */
object StreamPresets {
    private class P(val label: Int, val hint: Int, val res: String, val fps: String, val kbps: Int, val format: String,
                    val pacing: String, val lowLatency: Boolean, val direct: Boolean? = null)

    private val LIST = listOf(
        P(R.string.sp_best, R.string.sp_best_h, "1920x1080", "60", 30000, "auto", "balanced", false),
        P(R.string.sp_bal, R.string.sp_bal_h, "1920x1080", "60", 20000, "auto", "balanced", false),
        P(R.string.sp_fast, R.string.sp_fast_h, "1280x720", "60", 12000, "auto", "latency", true),
        P(R.string.sp_weak, R.string.sp_weak_h, "1280x720", "30", 5000, "auto", "balanced", false),
        P(R.string.sp_up, R.string.sp_up_h, "1280x720", "60", 15000, "auto", "balanced", false, true)
    )

    fun show(a: Activity) {
        AlertDialog.Builder(a)
            .setTitle(R.string.sp_title)
            .setItems(LIST.map { a.getString(it.label) + "\n" + a.getString(it.hint) }.toTypedArray()) { _, i -> apply(a, LIST[i]) }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun apply(a: Activity, p: P) {
        val sp = PreferenceManager.getDefaultSharedPreferences(a)
        sp.edit()
            .putString("list_resolution", p.res)
            .putString("list_fps", p.fps)
            .putInt("seekbar_bitrate_kbps", p.kbps)
            .putString("video_format", p.format)
            .putString("frame_pacing", p.pacing)
            .putBoolean("checkbox_ultra_low_latency", p.lowLatency)
            .putInt("seekbar_resolution_scale_factor", 100)
            .remove("edit_diy_w_h") // a hand-typed size would override the choice
            .remove("edit_diy_bitrate")
            .apply()
        if (p.direct != null) StreamFx.setDirect(a, p.direct)
        Toast.makeText(a, R.string.moon_applied, Toast.LENGTH_SHORT).show()
    }
}
