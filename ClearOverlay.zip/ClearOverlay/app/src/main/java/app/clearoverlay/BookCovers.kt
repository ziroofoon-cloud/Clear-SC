package app.clearoverlay

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.util.LruCache
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.zip.ZipFile

/**
 * The cover of a comic file (.cbz / .zip / .cbr / .rar / .cb7 / .7z / .pdf): its first page, cut to a square thumbnail, for the library list.
 * Built in the background (the first time only: the thumbnail is then kept on disk and in a small memory cache); a file that has no
 * readable first page simply keeps the book icon. The file is read in place (no copy) whenever the phone lets us open it that way.
 */
object BookCovers {
    private const val SIDE = 360
    private val cache = object : LruCache<String, Bitmap>(12 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val missing = HashSet<String>()
    private val pool = java.util.concurrent.Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())
    private val PIC = listOf(".jpg", ".jpeg", ".jfif", ".png", ".webp", ".gif", ".bmp", ".avif", ".heic", ".heif")

    /** The cover when it is already in memory, else null. Never blocks. */
    fun cached(u: Uri): Bitmap? = cache.get(u.toString())

    /** Loads the cover in the background; [done] runs on the main thread (with null when the file has none). */
    fun load(ctx: Context, u: Uri, done: (Bitmap?) -> Unit) {
        val k = u.toString()
        cache.get(k)?.let { done(it); return }
        if (synchronized(missing) { missing.contains(k) }) { done(null); return }
        val app = ctx.applicationContext
        pool.execute {
            val bmp = runCatching {
                val size = runCatching { app.contentResolver.openFileDescriptor(u, "r")?.use { it.statSize } ?: -1L }.getOrDefault(-1L)
                val disk = File(File(app.cacheDir, "book_covers").apply { mkdirs() }, md5("$k|$size") + ".jpg")
                var b: Bitmap? = if (disk.exists() && disk.length() > 0L) BitmapFactory.decodeFile(disk.path) else null
                if (b == null) {
                    val nb = build(app, u)
                    if (nb != null) runCatching { disk.outputStream().use { nb.compress(Bitmap.CompressFormat.JPEG, 85, it) } }
                    b = nb
                }
                b
            }.getOrNull()
            if (bmp != null) cache.put(k, bmp) else synchronized(missing) { missing.add(k) }
            main.post { done(bmp) }
        }
    }

    private fun md5(s: String): String =
        MessageDigest.getInstance("MD5").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    private fun order(a: String, b: String): Int = Media.natural(a.replace('\\', '/'), b.replace('\\', '/'))

    private fun isPic(name: String): Boolean {
        if (name.contains("__MACOSX")) return false
        val base = name.lowercase().substringAfterLast('/').substringAfterLast('\\')
        return !base.startsWith(".") && base != "thumbs.db" && PIC.any { base.endsWith(it) }
    }

    private fun build(app: Context, u: Uri): Bitmap? {
        val pfd = app.contentResolver.openFileDescriptor(u, "r") ?: return null
        var tmp: File? = null
        try {
            // a regular file can be opened again through its descriptor: no copy needed
            var f = File("/proc/self/fd/" + pfd.fd)
            val direct = runCatching { RandomAccessFile(f, "r").use { it.length() > 0L } }.getOrDefault(false)
            if (!direct) {
                if (pfd.statSize > 400L * 1024 * 1024) return null
                val t = File(app.cacheDir, "bookcover_" + System.nanoTime() + ".bin")
                tmp = t
                (app.contentResolver.openInputStream(u) ?: return null).use { i -> t.outputStream().use { o -> i.copyTo(o) } }
                f = t
            }
            val head = ByteArray(8)
            val n = RandomAccessFile(f, "r").use { it.read(head) }
            if (n < 4) return null
            fun b(i: Int) = head[i].toInt() and 0xFF
            val raw: Bitmap? = when {
                b(0) == 0x25 && b(1) == 0x50 && b(2) == 0x44 && b(3) == 0x46 -> pdfCover(f)
                b(0) == 0x50 && b(1) == 0x4B -> zipCover(f)
                b(0) == 0x37 && b(1) == 0x7A -> sevenCover(f)
                b(0) == 0x52 && b(1) == 0x61 && b(2) == 0x72 -> if (n >= 8 && Rar5.isRar5(head)) rar5Cover(app, f) else rar4Cover(f)
                else -> null
            }
            return raw?.let { square(it) }
        } finally {
            runCatching { pfd.close() }
            tmp?.delete()
        }
    }

    /** The first page, cut to a square that starts near the top (that is where a cover's title is). */
    private fun square(b: Bitmap): Bitmap {
        val w = b.width
        val h = b.height
        var x = 0
        var y = 0
        var cw = w
        var ch = h
        if (h > w) {
            ch = w
            y = ((h - w) * 0.1f).toInt()
        } else if (w > h) {
            cw = h
            x = (w - h) / 2
        }
        val c = Bitmap.createBitmap(b, x, y, cw, ch)
        return if (c.width > SIDE) Bitmap.createScaledBitmap(c, SIDE, SIDE, true) else c
    }

    private fun decode(bytes: ByteArray): Bitmap? = runCatching {
        ImageDecoder.decodeBitmap(ImageDecoder.createSource(ByteBuffer.wrap(bytes))) { dec, info, _ ->
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val m = maxOf(info.size.width, info.size.height)
            val lim = SIDE * 2
            if (m > lim) {
                val s = lim.toFloat() / m
                dec.setTargetSize(maxOf(1, (info.size.width * s).toInt()), maxOf(1, (info.size.height * s).toInt()))
            }
        }
    }.getOrNull()

    private fun pdfCover(f: File): Bitmap? {
        val pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
        val r = try { PdfRenderer(pfd) } catch (t: Throwable) { runCatching { pfd.close() }; throw t }
        try {
            if (r.pageCount == 0) return null
            val page = r.openPage(0)
            try {
                val k = (SIDE * 2).toFloat() / maxOf(page.width, page.height)
                val bmp = Bitmap.createBitmap(maxOf(1, (page.width * k).toInt()), maxOf(1, (page.height * k).toInt()), Bitmap.Config.ARGB_8888)
                bmp.eraseColor(Color.WHITE)
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                return bmp
            } finally {
                page.close()
            }
        } finally {
            runCatching { r.close() }
            runCatching { pfd.close() }
        }
    }

    private fun zipCover(f: File): Bitmap? {
        val z = try { ZipFile(f) } catch (e: Exception) { ZipFile(f, Charsets.ISO_8859_1) } // names that are not UTF-8
        return z.use { zz ->
            val names = ArrayList<String>()
            val en = zz.entries()
            while (en.hasMoreElements()) {
                val e = en.nextElement()
                if (!e.isDirectory && isPic(e.name)) names.add(e.name)
            }
            val name = names.minWithOrNull { a, b -> order(a, b) }
            val entry = if (name == null) null else zz.getEntry(name)
            if (entry == null) null else decode(zz.getInputStream(entry).use { it.readBytes() })
        }
    }

    private fun sevenCover(f: File): Bitmap? {
        val names = ArrayList<String>()
        org.apache.commons.compress.archivers.sevenz.SevenZFile(f).use { sz ->
            var en = sz.nextEntry
            while (en != null) {
                if (!en.isDirectory && isPic(en.name)) names.add(en.name)
                en = sz.nextEntry
            }
        }
        val name = names.minWithOrNull { a, b -> order(a, b) } ?: return null
        var data: ByteArray? = null
        org.apache.commons.compress.archivers.sevenz.SevenZFile(f).use { sz ->
            var en = sz.nextEntry
            while (en != null && data == null) {
                if (en.name == name) {
                    val o = ByteArrayOutputStream()
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val r = sz.read(buf)
                        if (r < 0) break
                        o.write(buf, 0, r)
                    }
                    data = o.toByteArray()
                } else {
                    en = sz.nextEntry
                }
            }
        }
        return data?.let { decode(it) }
    }

    private fun rar4Cover(f: File): Bitmap? {
        val arc = com.github.junrar.Archive(f)
        return arc.use { a ->
            val fh = a.fileHeaders.filter { !it.isDirectory && isPic(it.fileName) }
                .minWithOrNull { x, y -> order(x.fileName, y.fileName) }
            if (fh == null) null else {
                val o = ByteArrayOutputStream()
                a.extractFile(fh, o)
                decode(o.toByteArray())
            }
        }
    }

    private fun rar5Cover(app: Context, f: File): Bitmap? {
        val all = Rar5.list(f).filter { !it.dir }
        val target = all.filter { isPic(it.name) }.minWithOrNull { x, y -> order(x.name, y.name) } ?: return null
        val data: ByteArray? = when {
            target.method == 0 -> {
                val t = File.createTempFile("bc", ".img", app.cacheDir)
                try {
                    Rar5.extractStored(f, target, t)
                    t.readBytes()
                } finally {
                    t.delete()
                }
            }
            !target.solid -> Rar5.unpack(f, target, Rar5Unpacker())
            else -> {
                // a solid archive: every entry before it must be unpacked first (it continues from their data)
                val up = Rar5Unpacker()
                var res: ByteArray? = null
                for (en in all) {
                    if (en.method == 0) continue
                    val d = Rar5.unpack(f, en, up)
                    if (en === target) {
                        res = d
                        break
                    }
                    if (d == null) break
                }
                res
            }
        }
        return data?.let { decode(it) }
    }
}
