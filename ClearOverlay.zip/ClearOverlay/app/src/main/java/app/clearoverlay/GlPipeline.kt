package app.clearoverlay

import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES30
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.Surface
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Captured frame (external OES texture) -> RGBA copy -> [EASU | SGSR1 | Bilinear] -> RCAS
 * -> optional Vivid colors pass -> overlay surface.
 *
 *  Sharpen : copy -> RCAS (x1, x2 with boost)
 *  FSR 1   : copy -> EASU (upscale) -> RCAS (x1, x2 with boost)
 *  SGSR 1  : copy -> SGSR1 -> (RCAS only with boost)
 *  Fast    : copy -> hardware bilinear upscale -> RCAS (x1, x2 with boost)
 *  Render scale > 100% (any mode, Sharpen included): copy -> RCAS at the big size -> 4-tap downscale to the panel.
 *  Vivid colors, when enabled, always runs last regardless of mode.
 */
class GlPipeline(private val out: Surface) {
    private class Prog(val id: Int) {
        private val cache = HashMap<String, Int>()
        fun u(name: String): Int = cache.getOrPut(name) { GLES30.glGetUniformLocation(id, name) }
    }

    private class Rt {
        var tex = 0
        var fbo = 0
        var w = 0
        var h = 0
    }

    private val ht = HandlerThread("crsc-gl").also { it.start() }
    private val hd = Handler(ht.looper)

    private var dpy: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var ctx: EGLContext = EGL14.EGL_NO_CONTEXT
    private var srf: EGLSurface = EGL14.EGL_NO_SURFACE
    private var oesTex = 0
    private var st: SurfaceTexture? = null
    private var inSurface: Surface? = null

    private lateinit var pCopy: Prog
    private lateinit var pEasu: Prog
    private lateinit var pRcas: Prog
    private lateinit var pSgsr: Prog
    private lateinit var pBilinear: Prog
    private lateinit var pColor: Prog
    private lateinit var pDown: Prog
    private val t0 = Rt()
    private val t1 = Rt()
    private val t2 = Rt()
    private val t3 = Rt()

    private val m = FloatArray(16)
    private val sz = IntArray(1)

    @Volatile private var capW = 2
    @Volatile private var capH = 2
    @Volatile private var alive = true
    private var failed = false

    /** Called (on the GL thread) when GL setup or rendering fails; the message is shown to the user. */
    @Volatile var onError: ((String) -> Unit)? = null

    /** Builds GL on its own thread, then hands back the Surface the VirtualDisplay must write to. */
    fun start(w: Int, h: Int, onReady: (Surface) -> Unit) {
        capW = w
        capH = h
        hd.post {
            try {
                init()
                onReady(inSurface!!)
            } catch (t: Throwable) {
                Log.e(TAG, "GL init failed", t)
                onError?.invoke(t.message ?: "GL init failed")
            }
        }
    }

    fun setCaptureSize(w: Int, h: Int) {
        capW = w
        capH = h
        st?.setDefaultBufferSize(w, h)
    }

    private fun init() {
        dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val v = IntArray(2)
        EGL14.eglInitialize(dpy, v, 0, v, 1)
        val attrs = intArrayOf(
            EGL14.EGL_RENDERABLE_TYPE, EGLExt.EGL_OPENGL_ES3_BIT_KHR,
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8,
            EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_NONE
        )
        val cfgs = arrayOfNulls<EGLConfig>(1)
        val n = IntArray(1)
        EGL14.eglChooseConfig(dpy, attrs, 0, cfgs, 0, 1, n, 0)
        ctx = EGL14.eglCreateContext(
            dpy, cfgs[0], EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 3, EGL14.EGL_NONE), 0
        )
        srf = EGL14.eglCreateWindowSurface(dpy, cfgs[0], out, intArrayOf(EGL14.EGL_NONE), 0)
        EGL14.eglMakeCurrent(dpy, srf, srf, ctx)
        EGL14.eglSwapInterval(dpy, 0)

        val t = IntArray(1)
        GLES30.glGenTextures(1, t, 0)
        oesTex = t[0]
        val oes = GLES11Ext.GL_TEXTURE_EXTERNAL_OES
        GLES30.glBindTexture(oes, oesTex)
        GLES30.glTexParameteri(oes, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(oes, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(oes, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(oes, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)

        pCopy = Prog(link(Shaders.VERT, Shaders.OES_COPY, "copy"))
        pEasu = Prog(link(Shaders.VERT, Shaders.EASU, "easu"))
        pRcas = Prog(link(Shaders.VERT, Shaders.RCAS, "rcas"))
        pSgsr = Prog(link(Shaders.VERT, Shaders.SGSR1, "sgsr1"))
        pBilinear = Prog(link(Shaders.VERT, Shaders.BILINEAR, "bilinear"))
        pColor = Prog(link(Shaders.VERT, Shaders.COLOR_ENHANCE, "color"))
        pDown = Prog(link(Shaders.VERT, Shaders.DOWNSCALE, "downscale"))

        val s = SurfaceTexture(oesTex)
        s.setDefaultBufferSize(capW, capH)
        s.setOnFrameAvailableListener({ draw() }, hd)
        st = s
        inSurface = Surface(s)
    }

    private fun draw() {
        if (!alive) return
        val s = st ?: return
        try {
            s.updateTexImage()
        } catch (e: Exception) {
            return
        }
        s.getTransformMatrix(m)
        EGL14.eglQuerySurface(dpy, srf, EGL14.EGL_WIDTH, sz, 0)
        val w = sz[0]
        EGL14.eglQuerySurface(dpy, srf, EGL14.EGL_HEIGHT, sz, 0)
        val h = sz[0]
        if (w <= 0 || h <= 0) return
        try {
            render(w, h)
        } catch (t: Throwable) {
            if (!failed) {
                failed = true
                Log.e(TAG, "render failed", t)
                onError?.invoke(t.message ?: "render error")
            }
        }
    }

    private fun render(w: Int, h: Int) {
        val mode = Cfg.mode
        val boost = Cfg.boost
        val vivid = Cfg.vivid > 0f
        val sharpOnly = mode == Cfg.MODE_SHARP
        val cw = if (sharpOnly) maxOf(w, capW) else capW
        val ch = if (sharpOnly) maxOf(h, capH) else capH

        // 0) external texture -> plain RGBA texture (capture size)
        ensure(t0, cw, ch)
        bindOut(t0, cw, ch)
        GLES30.glUseProgram(pCopy.id)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTex)
        GLES30.glUniform1i(pCopy.u("uSrc"), 0)
        GLES30.glUniformMatrix4fv(pCopy.u("uTexMatrix"), 1, false, m, 0)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)

        // Supersampling: the render scale is above the panel size, so there is nothing to upscale.
        // Sharpen at the big size, then shrink back to the panel with a 4-tap filter.
        if (cw > w || ch > h) {
            var big = t0
            var n = 0
            val passes = if (boost) 2 else 1
            while (n < passes) {
                val dstBig = if (big === t1) t2 else t1
                ensure(dstBig, cw, ch)
                bindOut(dstBig, cw, ch)
                rcas(big)
                big = dstBig
                n++
            }
            if (vivid) {
                ensure(t3, w, h)
                bindOut(t3, w, h)
            } else {
                bindOut(null, w, h)
            }
            downscale(big, w, h)
            if (vivid) {
                bindOut(null, w, h)
                colorEnhance(t3)
            }
            EGL14.eglSwapBuffers(dpy, srf)
            return
        }

        // 1) upscale stage
        var cur = t0
        var rcasPasses: Int
        when (mode) {
            Cfg.MODE_FSR -> {
                ensure(t1, w, h)
                bindOut(t1, w, h)
                easu(t0, w, h)
                cur = t1
                rcasPasses = if (boost) 2 else 1
            }
            Cfg.MODE_SGSR -> {
                if (boost || vivid) {
                    // Need an offscreen target either to feed a second RCAS pass or the Vivid pass.
                    ensure(t1, w, h)
                    bindOut(t1, w, h)
                    sgsr(t0)
                    cur = t1
                    rcasPasses = if (boost) 1 else 0
                } else {
                    bindOut(null, w, h)
                    sgsr(t0)
                    rcasPasses = 0
                }
            }
            Cfg.MODE_FAST -> {
                ensure(t1, w, h)
                bindOut(t1, w, h)
                bilinear(t0, w, h)
                cur = t1
                rcasPasses = if (boost) 2 else 1
            }
            else -> rcasPasses = if (boost) 2 else 1
        }

        // 2) sharpening passes. The last one goes straight to the screen, unless a Vivid colors
        // pass still needs to run after it, in which case it goes to an offscreen target instead.
        var i = 0
        while (i < rcasPasses) {
            val last = i == rcasPasses - 1
            val dst: Rt? = if (last && !vivid) null else (if (cur === t1) t2 else t1)
            if (dst != null) ensure(dst, w, h)
            bindOut(dst, w, h)
            rcas(cur)
            if (dst != null) cur = dst
            i++
        }

        // 3) optional color enhance, always the last pass when enabled
        if (vivid) {
            bindOut(null, w, h)
            colorEnhance(cur)
        }
        EGL14.eglSwapBuffers(dpy, srf)
    }

    // ---- passes ---------------------------------------------------------------------------

    private fun bindSrc(rt: Rt) {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, rt.tex)
    }

    private fun easu(src: Rt, ow: Int, oh: Int) {
        val p = pEasu
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2i(p.u("uSrcSize"), src.w, src.h)
        val iw = src.w.toFloat()
        val ih = src.h.toFloat()
        val ox = ow.toFloat()
        val oy = oh.toFloat()
        // FsrEasuCon (ffx_fsr1.h)
        GLES30.glUniform4f(p.u("uCon0"), iw / ox, ih / oy, 0.5f * iw / ox - 0.5f, 0.5f * ih / oy - 0.5f)
        GLES30.glUniform4f(p.u("uCon1"), 1f / iw, 1f / ih, 1f / iw, -1f / ih)
        GLES30.glUniform4f(p.u("uCon2"), -1f / iw, 2f / ih, 1f / iw, 2f / ih)
        GLES30.glUniform4f(p.u("uCon3"), 0f, 4f / ih, 0f, 0f)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private fun rcas(src: Rt) {
        val p = pRcas
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2i(p.u("uSrcSize"), src.w, src.h)
        // The slider is 0..100%; RCAS stays stable up to ~1.3, so 100% = 1.2 (stronger than stock FSR).
        GLES30.glUniform1f(p.u("uSharpness"), Cfg.sharp * 1.2f)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private fun sgsr(src: Rt) {
        val p = pSgsr
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2i(p.u("uSrcSize"), src.w, src.h)
        val w = src.w.toFloat()
        val h = src.h.toFloat()
        GLES30.glUniform4f(p.u("uViewportInfo"), 1f / w, 1f / h, w, h)
        // Reference default is 2.0; the slider spans 1.0 (soft) .. 4.0 (strong).
        GLES30.glUniform1f(p.u("uEdgeSharpness"), 1f + 3f * Cfg.sharp)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private fun bilinear(src: Rt, ow: Int, oh: Int) {
        val p = pBilinear
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private fun downscale(src: Rt, ow: Int, oh: Int) {
        val p = pDown
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2f(p.u("uStep"), 0.25f / ow, 0.25f / oh)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private fun colorEnhance(src: Rt) {
        val p = pColor
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform1f(p.u("uVivid"), Cfg.vivid)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private fun bindOut(rt: Rt?, w: Int, h: Int) {
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, rt?.fbo ?: 0)
        GLES30.glViewport(0, 0, w, h)
    }

    private fun ensure(rt: Rt, w: Int, h: Int) {
        if (rt.tex != 0 && rt.w == w && rt.h == h) return
        free(rt)
        val t = IntArray(1)
        GLES30.glGenTextures(1, t, 0)
        rt.tex = t[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, rt.tex)
        GLES30.glTexImage2D(
            GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA8, w, h, 0,
            GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, null
        )
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        val f = IntArray(1)
        GLES30.glGenFramebuffers(1, f, 0)
        rt.fbo = f[0]
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, rt.fbo)
        GLES30.glFramebufferTexture2D(
            GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, rt.tex, 0
        )
        val status = GLES30.glCheckFramebufferStatus(GLES30.GL_FRAMEBUFFER)
        if (status != GLES30.GL_FRAMEBUFFER_COMPLETE) error("framebuffer incomplete: $status ($w x $h)")
        rt.w = w
        rt.h = h
    }

    private fun free(rt: Rt) {
        if (rt.fbo != 0) GLES30.glDeleteFramebuffers(1, intArrayOf(rt.fbo), 0)
        if (rt.tex != 0) GLES30.glDeleteTextures(1, intArrayOf(rt.tex), 0)
        rt.fbo = 0
        rt.tex = 0
        rt.w = 0
        rt.h = 0
    }

    /** Tears everything down. Blocks briefly so EGL is gone before the window surface dies. */
    fun release() {
        alive = false
        val done = CountDownLatch(1)
        hd.post {
            runCatching {
                st?.setOnFrameAvailableListener(null)
                inSurface?.release()
                st?.release()
                free(t0)
                free(t1)
                free(t2)
                free(t3)
                if (oesTex != 0) GLES30.glDeleteTextures(1, intArrayOf(oesTex), 0)
                for (p in arrayOf(pCopy, pEasu, pRcas, pSgsr, pBilinear, pColor, pDown)) GLES30.glDeleteProgram(p.id)
            }
            runCatching {
                EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                EGL14.eglDestroySurface(dpy, srf)
                EGL14.eglDestroyContext(dpy, ctx)
                EGL14.eglTerminate(dpy)
            }
            done.countDown()
        }
        done.await(400, TimeUnit.MILLISECONDS)
        ht.quitSafely()
    }

    private fun link(vs: String, fs: String, name: String): Int {
        val v = compile(GLES30.GL_VERTEX_SHADER, vs, "$name.vert")
        val f = compile(GLES30.GL_FRAGMENT_SHADER, fs, "$name.frag")
        val p = GLES30.glCreateProgram()
        GLES30.glAttachShader(p, v)
        GLES30.glAttachShader(p, f)
        GLES30.glLinkProgram(p)
        val ok = IntArray(1)
        GLES30.glGetProgramiv(p, GLES30.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) error("link $name: " + GLES30.glGetProgramInfoLog(p))
        GLES30.glDeleteShader(v)
        GLES30.glDeleteShader(f)
        return p
    }

    private fun compile(type: Int, src: String, name: String): Int {
        val s = GLES30.glCreateShader(type)
        GLES30.glShaderSource(s, src)
        GLES30.glCompileShader(s)
        val ok = IntArray(1)
        GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) error("shader $name: " + GLES30.glGetShaderInfoLog(s))
        return s
    }

    private companion object {
        const val TAG = "CRSC"
    }
}
