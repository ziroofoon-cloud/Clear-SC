package app.clearoverlay

import android.graphics.Bitmap
import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES30
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Captured frame (external OES texture) -> RGBA copy -> [EASU | SGSR1 | Bilinear] -> RCAS
 * -> optional Vivid colors pass -> overlay surface.
 *
 *  Sharpen : copy -> RCAS (x1, x2 with boost)
 *  FSR 1   : copy -> EASU (upscale) -> RCAS (x1, x2 with boost)
 *  SGSR 1  : copy -> SGSR1 -> (RCAS only with boost)
 *  Fast    : copy -> hardware bilinear upscale -> RCAS (x1, x2 with boost)
 *  Raw     : copy -> nearest-neighbour to the panel (no upscale filter, no sharpening); for comparing resolutions
 *  Render scale > 100% (any mode, Sharpen included): copy -> RCAS at the big size -> 4-tap downscale to the panel.
 *  Denoise / deblock and Deband (when enabled) run first, then anti-aliasing, all at capture size.
 *  Anti-aliasing (FXAA fast / FXAA quality / Edge Smooth), when enabled, runs right after the copy, before
 *  any upscale or sharpening.
 *  Vivid colors, when enabled, always runs last regardless of mode.
 */
class GlPipeline(private val out: Surface) {
    private class Prog(val id: Int) {
        private val cache = HashMap<String, Int>()
        fun u(name: String): Int = cache.getOrPut(name) { GLES30.glGetUniformLocation(id, name) }
    }

    private class Rt {
        var tex = 0
        var fbo = 0
        var w = 0
        var h = 0
    }

    private val ht = HandlerThread("crsc-gl").also { it.start() }
    private val hd = Handler(ht.looper)

    private var dpy: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var ctx: EGLContext = EGL14.EGL_NO_CONTEXT
    private var srf: EGLSurface = EGL14.EGL_NO_SURFACE
    private var oesTex = 0
    private var st: SurfaceTexture? = null
    private var inSurface: Surface? = null

    private lateinit var pCopy: Prog
    private lateinit var pEasu: Prog
    private lateinit var pRcas: Prog
    private lateinit var pSgsr: Prog
    private lateinit var pBilinear: Prog
    private lateinit var pBicubic: Prog
    private lateinit var pColor: Prog
    private lateinit var pDown: Prog
    private lateinit var pFxaaFast: Prog
    private lateinit var pFxaaQ: Prog
    private lateinit var pEdge: Prog
    private lateinit var pNearest: Prog
    private lateinit var pDetail: Prog
    private lateinit var pDenoise: Prog
    private lateinit var pDeband: Prog
    private lateinit var pTemporal: Prog
    private lateinit var pEdgeRefine: Prog
    private lateinit var pCrscSharp: Prog
    private lateinit var pCrscDown: Prog
    private lateinit var pEdgeShock: Prog
    private lateinit var pNis: Prog
    private lateinit var pNisOrig: Prog
    private lateinit var pCrscBp: Prog
    private val crscD = Rt()
    private val midRt = Rt()
    private val inRt = Rt()
    private val shrA = Rt()
    private val shrB = Rt()
    private lateinit var pFgMotion: Prog
    private lateinit var pFgInterp: Prog

    /** Frame generation: one extra frame is made between every two source frames (2x the frame rate). */
    /** Video export with an AI model: gets the cleaned frame (upside down, plain RGBA) and returns the bigger picture, or null. */
    @Volatile var aiHook: ((Bitmap) -> Bitmap?)? = null
    private val tAi = Rt()

    /** Temporal clean-up using the previous frames: 0 off, 1 light, 2 strong. */
    @Volatile var temporal = 0

    /** CRSC quality override (export); -1 = use the app setting. */
    @Volatile var crscOverride = -1
    private val thA = Rt()
    private val thB = Rt()
    private val tMv = Rt()
    private var thCur: Rt? = null
    @Volatile private var tmpNew = false

    @Volatile var frameGen = false
    /** Frames per source frame: 2 (x2), 3 or 4. */
    @Volatile var frameGenN = 2
    /** Motion search quality: 0 light (a quarter of the work), 1 normal, 2 high (smaller blocks and a finer search). */
    @Volatile var fgQuality = 1
    private val fgA = Rt()
    private val fgB = Rt()
    private val fgMv = Rt()
    /** Small copies of the two last frames: the motion search runs on these (a quarter of the work at 1920 px and more). */
    private val fgSA = Rt()
    private val fgSB = Rt()
    private var fgMvScale = 1f
    private var fgNo = 0L
    private var fgANo = 0L
    private var fgBNo = 0L
    private var fgSANo = 0L
    private var fgSBNo = 0L
    private var fgCurRt: Rt = fgA
    private var fgPrevRt: Rt? = null
    private var fgHave = false
    private var fgLastNs = 0L
    private var fgInterval = 33_000_000L
    private var fgSeq = 0
    @Volatile private var capturing = false
    private val t0 = Rt()
    private val t1 = Rt()
    private val t2 = Rt()
    private val t3 = Rt()
    private val t4 = Rt() // anti-aliasing output
    private val t5 = Rt() // detail pass output (panel size)
    private val t6 = Rt() // second ping-pong target for the capture-size cleanup passes
    private val tFix = Rt() // tiny copy of the frame measured by Smart fix
    private val t7 = Rt() // offscreen result used by [snapshot] (save to gallery)

    /** True while [snapshot] renders into [t7] instead of the window: no zoom, no buffer swap. */
    @Volatile private var snap = false
    @Volatile private var outFbo = 0

    private val m = FloatArray(16)
    private val sz = IntArray(1)

    @Volatile private var capW = 2
    @Volatile private var capH = 2
    @Volatile private var alive = true
    private var failed = false

    /** True = skip every effect: the frame is only copied and scaled with the hardware bilinear filter
     *  (what a normal player would show). Used by the player's effect on/off switch. */
    @Volatile var bypass = false

    /** Zoom into the frame (player only): [zoom] >= 1, centre ([zoomX], [zoomY]) in 0..1 (y up). The cropped part is
     *  taken from the real source pixels and goes through the normal pipeline, so effects can be inspected up close. */
    @Volatile var zoom = 1f
    @Volatile var zoomX = 0.5f
    @Volatile var zoomY = 0.5f

    fun setZoom(z: Float, x: Float, y: Float) {
        zoom = z
        zoomX = x
        zoomY = y
        redraw()
    }

    /** Called (on the GL thread) when GL setup or rendering fails; the message is shown to the user. */
    @Volatile var onError: ((String) -> Unit)? = null

    /** Builds GL on its own thread, then hands back the Surface the VirtualDisplay must write to. */
    fun start(w: Int, h: Int, onReady: (Surface) -> Unit) {
        capW = w
        capH = h
        hd.post {
            try {
                init()
                onReady(inSurface!!)
            } catch (t: Throwable) {
                Log.e(TAG, "GL init failed", t)
                onError?.invoke(t.message ?: "GL init failed")
            }
        }
    }

    fun setCaptureSize(w: Int, h: Int) {
        capW = w
        capH = h
        st?.setDefaultBufferSize(w, h)
    }

    private fun init() {
        dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val v = IntArray(2)
        EGL14.eglInitialize(dpy, v, 0, v, 1)
        val attrs = if (recordable) intArrayOf(
            EGL14.EGL_RENDERABLE_TYPE, EGLExt.EGL_OPENGL_ES3_BIT_KHR,
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8,
            EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            0x3142, 1, // EGL_RECORDABLE_ANDROID
            EGL14.EGL_NONE
        ) else intArrayOf(
            EGL14.EGL_RENDERABLE_TYPE, EGLExt.EGL_OPENGL_ES3_BIT_KHR,
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8,
            EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_NONE
        )
        val cfgs = arrayOfNulls<EGLConfig>(1)
        val n = IntArray(1)
        EGL14.eglChooseConfig(dpy, attrs, 0, cfgs, 0, 1, n, 0)
        ctx = EGL14.eglCreateContext(
            dpy, cfgs[0], EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 3, EGL14.EGL_NONE), 0
        )
        srf = EGL14.eglCreateWindowSurface(dpy, cfgs[0], out, intArrayOf(EGL14.EGL_NONE), 0)
        EGL14.eglMakeCurrent(dpy, srf, srf, ctx)
        EGL14.eglSwapInterval(dpy, 0)

        val t = IntArray(1)
        GLES30.glGenTextures(1, t, 0)
        oesTex = t[0]
        val oes = GLES11Ext.GL_TEXTURE_EXTERNAL_OES
        GLES30.glBindTexture(oes, oesTex)
        GLES30.glTexParameteri(oes, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(oes, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(oes, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(oes, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)

        pCopy = Prog(link(Shaders.VERT, Shaders.OES_COPY, "copy"))
        pEasu = Prog(link(Shaders.VERT, Shaders.EASU, "easu"))
        pRcas = Prog(link(Shaders.VERT, Shaders.RCAS, "rcas"))
        pSgsr = Prog(link(Shaders.VERT, Shaders.SGSR1, "sgsr1"))
        pBilinear = Prog(link(Shaders.VERT, Shaders.BILINEAR, "bilinear"))
        pBicubic = Prog(link(Shaders.VERT, Shaders.BICUBIC, "bicubic"))
        pColor = Prog(link(Shaders.VERT, Shaders.COLOR_ENHANCE, "color"))
        pDown = Prog(link(Shaders.VERT, Shaders.DOWNSCALE, "downscale"))
        pFxaaFast = Prog(link(Shaders.VERT, Shaders.FXAA_FAST, "fxaa_fast"))
        pFxaaQ = Prog(link(Shaders.VERT, Shaders.FXAA_QUALITY, "fxaa_quality"))
        pEdge = Prog(link(Shaders.VERT, Shaders.EDGE_SMOOTH, "edge_smooth"))
        pNearest = Prog(link(Shaders.VERT, Shaders.NEAREST, "nearest"))
        pDetail = Prog(link(Shaders.VERT, Shaders.DETAIL, "detail"))
        pDenoise = Prog(link(Shaders.VERT, Shaders.DENOISE, "denoise"))
        pDeband = Prog(link(Shaders.VERT, Shaders.DEBAND, "deband"))
        pTemporal = Prog(link(Shaders.VERT, Shaders.TEMPORAL, "temporal"))
        pEdgeRefine = Prog(link(Shaders.VERT, Shaders.EDGE_REFINE, "edge_refine"))
        pCrscSharp = Prog(link(Shaders.VERT, Shaders.CRSC_SHARP, "crsc_sharp"))
        pCrscDown = Prog(link(Shaders.VERT, Shaders.CRSC_DOWN, "crsc_down"))
        pNis = Prog(link(Shaders.VERT, Shaders.NIS, "nis"))
        pNisOrig = Prog(link(Shaders.VERT, Shaders.NIS_ORIG, "nis_orig"))
        pEdgeShock = Prog(link(Shaders.VERT, Shaders.EDGE_SHOCK, "edge_shock"))
        pCrscBp = Prog(link(Shaders.VERT, Shaders.CRSC_BP, "crsc_bp"))
        pFgMotion = Prog(link(Shaders.VERT, Shaders.FG_MOTION, "fg_motion"))
        pFgInterp = Prog(link(Shaders.VERT, Shaders.FG_INTERP, "fg_interp"))

        val s = SurfaceTexture(oesTex)
        s.setDefaultBufferSize(capW, capH)
        s.setOnFrameAvailableListener({ draw() }, hd)
        st = s
        inSurface = Surface(s)
    }

    private fun draw() {
        try {
            drawInner()
        } finally {
            exportLatch?.countDown()
        }
    }

    private fun drawInner() {
        if (!alive) return
        val s = st ?: return
        try {
            s.updateTexImage()
        } catch (e: Exception) {
            return
        }
        s.getTransformMatrix(m)
        if (manualOnly) {
            // offscreen use (manga pages): only take the new frame; the result is rendered by snapshot()
            frameLatch?.countDown()
            return
        }
        val t0 = System.nanoTime()
        renderNow(true)
        val dt = (System.nanoTime() - t0) / 1_000_000f
        // moving average of the time one frame takes to submit (grows when the GPU cannot keep up): used by Auto
        avgDrawMs = if (avgDrawMs <= 0f) dt else avgDrawMs * 0.9f + dt * 0.1f
    }

    /** Settings the passes read: null = the live app settings ([Cfg]); a video export sets its own fixed set. */
    @Volatile var fx: FxView? = null
    private val f: FxView get() = fx ?: LiveFx

    /** Video export: the output surface is a MediaCodec encoder input; frames get the source timestamp and [exportLatch] is counted down after each one. */
    @Volatile var exportMode = false
    @Volatile var exportLatch: CountDownLatch? = null

    /** Set after a jump in the video: the next frame must not be blended / interpolated with the one before the jump. */
    @Volatile var resetHist = false
    /** Ask EGL for a config usable by a MediaCodec input surface (set before [start]). */
    @Volatile var recordable = false

    /** CRSC Edge level 5 (maximum) is only used when saving to a file: set by the offline renderers (batch). */
    @Volatile var allowMax = false

    /** True = never draw to the window; frames are only consumed and [snapshot] renders them (used by [MangaFx]). */
    @Volatile var manualOnly = false

    /** Counted down once the next input frame has been taken (manualOnly). */
    @Volatile var frameLatch: java.util.concurrent.CountDownLatch? = null

    /** true for the overlay service: its capture scale already is the render resolution, f.inRes / outRes do not apply. */
    @Volatile var fixedOut = false

    private var infoKey = 0L
    private fun noteInfo(sw: Int, sh: Int, cw: Int, ch: Int, mw: Int, mh: Int, ow: Int, oh: Int, w: Int, h: Int) {
        val key = ((((sw * 31L + sh) * 31 + cw) * 31 + ch) * 31 + ow * 7L + oh * 3L + w * 5L + h) * 31 + mw * 11L + mh * 13L
        if (key == infoKey) return
        infoKey = key
        Cfg.resInfo = if (mw > 0) "$sw×$sh  →  $cw×$ch  →  $mw×$mh  →  $ow×$oh  →  $w×$h" else "$sw×$sh  →  $cw×$ch  →  $ow×$oh  →  $w×$h"
    }

    /** > 0: the processing size is limited to this many times the output size (player only; 0 = off). */
    @Volatile var maxProcRatio = 0f

    /** Smoothed milliseconds per processed frame (0 = no frame yet). Reset it to 0 after changing settings. */
    @Volatile var avgDrawMs = 0f

    /** Re-renders the last frame with the current settings (paused video, still images, live setting changes). */
    fun redraw() {
        hd.post { if (alive && st != null && srf != EGL14.EGL_NO_SURFACE) renderNow() }
    }

    private fun present(tsNs: Long = st?.timestamp ?: 0L) {
        if (!snap && !capturing) {
            if (exportMode) EGLExt.eglPresentationTimeANDROID(dpy, srf, tsNs)
            EGL14.eglSwapBuffers(dpy, srf)
        }
    }

    /**
     * Renders the current picture with the current settings at [w] x [h] (whole image, no zoom) and returns it as a
     * Bitmap, or null on failure. Blocks the caller, so call it from a worker thread, never from the UI thread.
     */
    fun snapshot(w: Int, h: Int): Bitmap? {
        val latch = CountDownLatch(1)
        var result: Bitmap? = null
        val queued = hd.post {
            try {
                result = snapshotNow(w, h)
            } catch (t: Throwable) {
                Log.e(TAG, "snapshot failed", t)
            } finally {
                latch.countDown()
            }
        }
        if (!queued) return null
        latch.await(120, TimeUnit.SECONDS)
        return result
    }

    /**
     * The last captured frame exactly as the screen showed it (no effects), at capture size. Worker thread only.
     * Used by the AI still-frame tool: the AI should see the real pixels, not an already sharpened picture.
     */
    fun rawFrame(): Bitmap? {
        bypass = true
        try {
            return snapshot(capW, capH)
        } finally {
            bypass = false
            redraw()
        }
    }

    private fun snapshotNow(w: Int, h: Int): Bitmap? {
        if (!alive || st == null || w <= 0 || h <= 0) return null
        try {
            ensure(t7, w, h)
            snap = true
            outFbo = t7.fbo
            render(w, h)
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, t7.fbo)
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val band = 128
            val buf = ByteBuffer.allocateDirect(w * band * 4).order(ByteOrder.nativeOrder())
            val px = IntArray(w * band)
            var y = 0
            while (y < h) {
                val rows = minOf(band, h - y)
                buf.clear()
                GLES30.glReadPixels(0, y, w, rows, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, buf)
                buf.clear()
                buf.asIntBuffer().get(px, 0, w * rows)
                for (i in 0 until w * rows) {
                    val v = px[i]
                    // bytes R,G,B,A read as a little-endian int = ABGR; Bitmap wants ARGB. OpenGL rows run bottom-up.
                    px[i] = (v and 0xFF00FF00.toInt()) or ((v and 0xFF) shl 16) or ((v shr 16) and 0xFF) or 0xFF000000.toInt()
                }
                for (r in 0 until rows) bmp.setPixels(px, r * w, w, 0, h - 1 - (y + r), w, 1)
                y += rows
            }
            return bmp
        } finally {
            snap = false
            outFbo = 0
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
            free(t7)
            renderNow()
        }
    }

    private fun renderNow(newFrame: Boolean = false) {
        tmpNew = newFrame
        EGL14.eglQuerySurface(dpy, srf, EGL14.EGL_WIDTH, sz, 0)
        val w = sz[0]
        EGL14.eglQuerySurface(dpy, srf, EGL14.EGL_HEIGHT, sz, 0)
        val h = sz[0]
        if (w <= 0 || h <= 0) return
        try {
            if (frameGen && !snap && !bypass) renderFg(w, h, newFrame) else render(w, h)
        } catch (t: Throwable) {
            capturing = false
            outFbo = 0
            if (!failed) {
                failed = true
                Log.e(TAG, "render failed", t)
                onError?.invoke(t.message ?: "render error")
            }
        }
    }

    /** Renders the frame into a texture, builds the in-between picture from the previous frame and shows both. */
    private fun renderFg(w: Int, h: Int, newFrame: Boolean) {
        var havePrev = false
        if (resetHist) {
            resetHist = false
            fgHave = false
            thCur = null
        }
        if (newFrame) {
            if (fgHave) {
                fgPrevRt = fgCurRt
                fgCurRt = if (fgCurRt === fgA) fgB else fgA
                havePrev = true
            }
            fgHave = true
        }
        val cur = fgCurRt
        ensure(cur, w, h)
        if (newFrame) {
            fgNo++
            if (cur === fgA) fgANo = fgNo else fgBNo = fgNo
        }
        capturing = true
        outFbo = cur.fbo
        try {
            render(w, h)
        } finally {
            capturing = false
            outFbo = 0
        }
        val prev = fgPrevRt
        val ts = st?.timestamp ?: 0L
        val now = System.nanoTime()
        if (newFrame) {
            if (fgLastNs != 0L) fgInterval = ((fgInterval * 3 + (now - fgLastNs).coerceIn(8_000_000L, 120_000_000L)) / 4)
            fgLastNs = now
        }
        if (havePrev && prev != null && prev.w == w && prev.h == h) {
            // the search runs on small copies when the picture is big
            val searchW = if (fgQuality == 3) FG_SEARCH_W / 2 else FG_SEARCH_W
            val sc = if (w > searchW) searchW.toFloat() / w else 1f
            val sw = maxOf(16, (w * sc).toInt())
            val sh = maxOf(16, (h * sc).toInt())
            var mp = prev
            var mc = cur
            if (sc < 1f) {
                val curIsA = cur === fgA
                val sCur = if (curIsA) fgSA else fgSB
                val sPrev = if (curIsA) fgSB else fgSA
                val curNo = if (curIsA) fgANo else fgBNo
                val prevNo = if (curIsA) fgBNo else fgANo
                if (fgSA.w != sw || fgSA.h != sh) fgSANo = 0L // a new size: the old copies are gone
                if (fgSB.w != sw || fgSB.h != sh) fgSBNo = 0L
                val sCurNo = if (curIsA) fgSANo else fgSBNo
                val sPrevNo = if (curIsA) fgSBNo else fgSANo
                ensure(sCur, sw, sh)
                ensure(sPrev, sw, sh)
                // a small copy is made only when it does not already hold that frame
                if (sCurNo != curNo) {
                    bindOut(sCur, sw, sh)
                    downscale(cur, sw, sh)
                    if (curIsA) fgSANo = curNo else fgSBNo = curNo
                }
                if (sPrevNo != prevNo) {
                    bindOut(sPrev, sw, sh)
                    downscale(prev, sw, sh)
                    if (curIsA) fgSBNo = prevNo else fgSANo = prevNo
                }
                mp = sPrev
                mc = sCur
            }
            fgMvScale = if (sc < 1f) w.toFloat() / sw else 1f
            val blkFull = if (fgQuality == 2) 8 else 16
            val blk = if (sc < 1f) (blkFull * sc).toInt().coerceAtLeast(if (fgQuality == 3) 8 else 4) else blkFull
            val gw = maxOf(1, sw / blk)
            val gh = maxOf(1, sh / blk)
            ensure(fgMv, gw, gh)
            bindOut(fgMv, gw, gh)
            GLES30.glUseProgram(pFgMotion.id)
            bindTex(0, mp)
            bindTex(1, mc)
            GLES30.glUniform1i(pFgMotion.u("uPrev"), 0)
            GLES30.glUniform1i(pFgMotion.u("uCur"), 1)
            GLES30.glUniform2f(pFgMotion.u("uInv"), 1f / sw, 1f / sh)
            // light mode: a quarter of the search work (coarser steps, same reach)
            // light / very light: log search (36 matches per block, reach 15 px of the small picture, 1 px precision) instead of a flat grid:
            // the flat grid could only follow about 4 px of motion, so fast motion was not found and the result looked like a plain blend
            val logSearch = fgQuality == 0 || fgQuality == 3
            GLES30.glUniform1f(pFgMotion.u("uStep"), if (logSearch) 8f else (4f).let { if (sc < 1f) maxOf(1f, it * sc) else it })
            GLES30.glUniform1i(pFgMotion.u("uRange"), 4)
            GLES30.glUniform1f(pFgMotion.u("uBlock"), blk.toFloat())
            GLES30.glUniform1i(pFgMotion.u("uRefine"), if (logSearch) 2 else 1)
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)

            val n = frameGenN.coerceIn(2, 4)
            val prevTs = fgPrevTs
            val seq = ++fgSeq
            drawMid(prev, cur, w, h, 1f / n, if (exportMode && prevTs > 0L && prevTs < ts) prevTs + (ts - prevTs) / n else ts)
            if (exportMode) {
                for (k in 2 until n) drawMid(prev, cur, w, h, k.toFloat() / n, if (prevTs > 0L && prevTs < ts) prevTs + (ts - prevTs) * k / n else ts)
                blitFg(cur, w, h, ts)
            } else {
                // live: the other in-between frames and the new frame follow, one step of (interval / n) apart
                val step = fgInterval / n / 1_000_000L
                val spent = (System.nanoTime() - now) / 1_000_000L
                for (k in 2 until n) {
                    val wait = ((k - 1) * step - spent).coerceIn(0L, 90L)
                    hd.postDelayed({ if (alive && seq == fgSeq && st != null) drawMid(prev, cur, w, h, k.toFloat() / n, ts) }, wait)
                }
                val wait = ((n - 1) * step - spent).coerceIn(0L, 90L)
                hd.postDelayed({ if (alive && seq == fgSeq && st != null) blitFg(cur, w, h, ts) }, wait)
            }
            fgPrevTs = ts
        } else {
            fgSeq++
            fgPrevTs = ts
            blitFg(cur, w, h, ts)
        }
    }

    private var fgPrevTs = 0L

    /** The picture at position [t] (0..1) between [prev] and [cur], from the motion in [fgMv]. */
    private fun drawMid(prev: Rt, cur: Rt, w: Int, h: Int, t: Float, ts: Long) {
        if (prev.tex == 0 || cur.tex == 0 || fgMv.tex == 0 || srf == EGL14.EGL_NO_SURFACE) return
        bindOut(null, w, h)
        GLES30.glUseProgram(pFgInterp.id)
        bindTex(0, prev)
        bindTex(1, cur)
        bindTex(2, fgMv)
        GLES30.glUniform1i(pFgInterp.u("uPrev"), 0)
        GLES30.glUniform1i(pFgInterp.u("uCur"), 1)
        GLES30.glUniform1i(pFgInterp.u("uMv"), 2)
        GLES30.glUniform2f(pFgInterp.u("uInv"), 1f / w, 1f / h)
        GLES30.glUniform1f(pFgInterp.u("uT"), t)
        GLES30.glUniform1f(pFgInterp.u("uMvScale"), fgMvScale)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        present(ts)
    }

    private fun blitFg(src: Rt, w: Int, h: Int, ts: Long) {
        if (src.tex == 0 || srf == EGL14.EGL_NO_SURFACE) return
        bindOut(null, w, h)
        bilinear(src, w, h)
        present(ts)
    }

    /** Temporal clean-up at the size of the source frame. Returns the Rt that holds the result. */
    private fun temporalStage(src: Rt): Rt {
        val w = src.w
        val h = src.h
        if (resetHist) {
            resetHist = false
            thCur = null
            fgHave = false
        }
        val prev = thCur
        if (!tmpNew) {
            // the same frame drawn again (a setting changed): keep the result that was already made
            return if (prev != null && prev.w == w && prev.h == h) prev else src
        }
        val out = if (prev === thA) thB else thA
        ensure(out, w, h)
        if (prev == null || prev.w != w || prev.h != h) {
            bindOut(out, w, h)
            bilinear(src, w, h)
            thCur = out
            return out
        }
        val blk = 16
        val gw = maxOf(1, w / blk)
        val gh = maxOf(1, h / blk)
        ensure(tMv, gw, gh)
        bindOut(tMv, gw, gh)
        GLES30.glUseProgram(pFgMotion.id)
        bindTex(0, prev)
        bindTex(1, src)
        GLES30.glUniform1i(pFgMotion.u("uPrev"), 0)
        GLES30.glUniform1i(pFgMotion.u("uCur"), 1)
        GLES30.glUniform2f(pFgMotion.u("uInv"), 1f / w, 1f / h)
        GLES30.glUniform1f(pFgMotion.u("uStep"), 4f)
        GLES30.glUniform1i(pFgMotion.u("uRange"), 4)
        GLES30.glUniform1f(pFgMotion.u("uBlock"), blk.toFloat())
        GLES30.glUniform1i(pFgMotion.u("uRefine"), 1)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)

        bindOut(out, w, h)
        GLES30.glUseProgram(pTemporal.id)
        bindTex(0, src)
        bindTex(1, prev)
        bindTex(2, tMv)
        GLES30.glUniform1i(pTemporal.u("uCur"), 0)
        GLES30.glUniform1i(pTemporal.u("uHist"), 1)
        GLES30.glUniform1i(pTemporal.u("uMv"), 2)
        GLES30.glUniform2f(pTemporal.u("uInv"), 1f / w, 1f / h)
        // Light: 0.5 / tolerance 0.06 (about +1 dB on noisy test video); Strong: 0.93 / 0.11 (about +2.3..3.6 dB, more smoothing, more risk of ghosts)
        GLES30.glUniform1f(pTemporal.u("uAmt"), if (temporal >= 2) 0.93f else 0.5f)
        GLES30.glUniform1f(pTemporal.u("uTol"), if (temporal >= 2) 0.11f else 0.06f)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        thCur = out
        return out
    }

    private fun aiStage(src: Rt, hook: (Bitmap) -> Bitmap?): Rt? {
        val w = src.w
        val h = src.h
        if (w <= 0 || h <= 0) return null
        val buf = ByteBuffer.allocateDirect(w * h * 4).order(ByteOrder.nativeOrder())
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, src.fbo)
        GLES30.glReadPixels(0, 0, w, h, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, buf)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        buf.rewind()
        bmp.copyPixelsFromBuffer(buf)
        val res = try { hook(bmp) } finally { bmp.recycle() }
        val out = res ?: return null
        try {
            ensure(tAi, out.width, out.height)
            GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tAi.tex)
            android.opengl.GLUtils.texSubImage2D(GLES30.GL_TEXTURE_2D, 0, 0, 0, out)
        } finally {
            out.recycle()
        }
        return tAi
    }

    private fun bindTex(unit: Int, rt: Rt) {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + unit)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, rt.tex)
    }

    private fun render(w: Int, h: Int) {
        val mode = f.mode
        val boost = f.boost
        val fixOn = f.smartFix && !byp0() // Smart fix: measured from the frame itself
        val vivid = f.vivid > 0f || f.contrast != 0f || fixOn // "colour pass": vivid colours, contrast and / or Smart fix
        val detail = f.detail > 0f
        rcasK = 1f // every frame starts with the normal RCAS strength (CRSC Edge lowers it itself)
        val post = vivid || detail
        val byp = bypass
        // Output size chain (player / photo): f.outRes = short side of the size everything is rendered at
        val outShort = f.outRes
        val customOut = !snap && !byp && mode != Cfg.MODE_RAW && outShort > 0 && !fixedOut
        val ow = if (customOut) maxOf(2, Math.round(w * outShort.toFloat() / minOf(w, h))).coerceAtMost(8192) else w
        val oh = if (customOut) maxOf(2, Math.round(h * outShort.toFloat() / minOf(w, h))).coerceAtMost(8192) else h
        val sharpOnly = mode == Cfg.MODE_SHARP && !customOut
        val z = if (snap) 1f else zoom.coerceAtLeast(1f)
        var sw = if (z > 1f) maxOf(2, (capW / z).toInt()) else capW
        var sh = if (z > 1f) maxOf(2, (capH / z).toInt()) else capH
        if (maxProcRatio > 0f && !snap && !byp) {
            // the source is much bigger than the output (e.g. 4K video on a 1080p screen): work at most
            // maxProcRatio x the output size instead of at the full source size (several times cheaper)
            val k = minOf(1f, w * maxProcRatio / sw, h * maxProcRatio / sh)
            if (k < 1f) {
                sw = maxOf(2, (sw * k).toInt())
                sh = maxOf(2, (sh * k).toInt())
            }
        }
        val half = 0.5f / z
        val cropX = (zoomX - half).coerceIn(0f, 1f - 1f / z)
        val cropY = (zoomY - half).coerceIn(0f, 1f - 1f / z)
        var cw = if (byp) sw else if (sharpOnly) maxOf(w, sw) else sw
        var ch = if (byp) sh else if (sharpOnly) maxOf(h, sh) else sh
        // Input step: the source is said to be really only this big. The copy is made at full size and then shrunk with a proper
        // filter (halving steps + 4 taps), so the result is clean, not the aliased result of one single-tap bilinear read.
        var iw = 0
        var ih = 0
        if (!snap && !byp && f.inRes > 0 && !fixedOut && !sharpOnly) {
            val ms0 = minOf(cw, ch)
            if (f.inRes < ms0) {
                val k = f.inRes.toFloat() / ms0
                iw = maxOf(2, Math.round(cw * k))
                ih = maxOf(2, Math.round(ch * k))
            }
        }
        val workW = if (iw > 0) iw else cw
        val workH = if (iw > 0) ih else ch
        // Middle step: the cleaned picture is brought down to this short side (only when that is smaller than the work size)
        val midShort = f.midRes
        var mw = 0
        var mh = 0
        if (midShort > 0 && !byp && !fixedOut && mode != Cfg.MODE_RAW && !sharpOnly) {
            val ms = minOf(workW, workH)
            if (midShort < ms) {
                val k = midShort.toFloat() / ms
                mw = maxOf(2, Math.round(workW * k))
                mh = maxOf(2, Math.round(workH * k))
            }
        }
        if (!snap && fx == null) noteInfo(capW, capH, workW, workH, mw, mh, ow, oh, w, h)

        // 0) external texture -> plain RGBA texture (capture size)
        ensure(t0, cw, ch)
        bindOut(t0, cw, ch)
        GLES30.glUseProgram(pCopy.id)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTex)
        GLES30.glUniform1i(pCopy.u("uSrc"), 0)
        GLES30.glUniformMatrix4fv(pCopy.u("uTexMatrix"), 1, false, m, 0)
        GLES30.glUniform4f(pCopy.u("uCrop"), cropX, cropY, 1f / z, 1f / z)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)

        if (fixOn) {
            if (!fixWasOn) fixFresh = true // just switched on: measure this very frame
            fixWasOn = true
            smartFixMeasure(w0 = cw, h0 = ch)
        } else fixWasOn = false

        // Effects off: just show the copied frame, scaled by the GPU's own bilinear filter.
        if (byp) {
            bindOut(null, w, h)
            bilinear(t0, w, h)
            present()
            return
        }

        // 0b) optional anti-aliasing at capture size; everything after reads from [base]
        // Cleanup stages run in this order, each reading the previous result (t4 / t6 ping-pong):
        // denoise / deblock -> deband -> anti-aliasing. All happen before upscaling and sharpening,
        // so sharpening never amplifies compression noise.
        var base = t0
        if (iw > 0) {
            ensure(inRt, iw, ih)
            shrink(t0, iw, ih, inRt)
            base = inRt
            cw = iw
            ch = ih
        }
        if (f.denoise > 0f) {
            val dst = if (base === t4) t6 else t4
            ensure(dst, cw, ch)
            bindOut(dst, cw, ch)
            denoisePass(base)
            base = dst
        }
        if (f.deband > 0f) {
            val dst = if (base === t4) t6 else t4
            ensure(dst, cw, ch)
            bindOut(dst, cw, ch)
            debandPass(base)
            base = dst
        }
        val aa = f.aaMode
        if (aa != Cfg.AA_OFF) {
            val dst = if (base === t4) t6 else t4
            ensure(dst, cw, ch)
            bindOut(dst, cw, ch)
            antiAlias(base, aa)
            base = dst
        }

        // 0b2) temporal clean-up: the previous result, moved along the motion, is blended into this frame
        // (before every output path below, so Raw and the chosen-output-size path get it too)
        if (temporal > 0 && !snap) base = temporalStage(base)

        // 0b3) middle step: shrink the cleaned picture (4-tap filter = clean anti-aliasing); everything below works from the small one
        if (mw > 0) {
            ensure(midRt, mw, mh)
            shrink(base, mw, mh, midRt)
            base = midRt
            cw = mw
            ch = mh
        }

        // Raw: show the captured frame as-is (nearest-neighbour), no upscale filter and no sharpening.
        if (mode == Cfg.MODE_RAW) {
            if (vivid) {
                ensure(t1, w, h)
                bindOut(t1, w, h)
                nearest(base)
                bindOut(null, w, h)
                colorEnhance(t1)
            } else {
                bindOut(null, w, h)
                nearest(base)
            }
            present()
            return
        }

        // Chosen output size (f.outRes): upscale (or downscale) to exactly that size, then show it on the screen.
        if (customOut) {
            val passes = if (boost) 2 else 1
            var cur: Rt
            if (cw > ow || ch > oh) {
                // DOWNSCALE: sharpen at the source size, then shrink to the output size (the shrink is an anti-aliasing filter)
                var big = base
                var n = 0
                while (n < passes) {
                    val d = if (big === t1) t2 else t1
                    ensure(d, cw, ch)
                    bindOut(d, cw, ch)
                    rcas(big)
                    big = d
                    n++
                }
                ensure(t3, ow, oh)
                bindOut(t3, ow, oh)
                downscale(big, ow, oh)
                cur = t3
            } else {
                // UPSCALE to the output size with the chosen method, then sharpen there
                if (mode == Cfg.MODE_LANCZOS) {
                    cur = crscEdge(base, ow, oh)
                } else {
                    ensure(t1, ow, oh)
                    bindOut(t1, ow, oh)
                    when (mode) {
                        Cfg.MODE_FSR -> easu(base, ow, oh)
                        Cfg.MODE_SGSR -> sgsr(base)
                        Cfg.MODE_NIS, Cfg.MODE_NIS_ORIG, Cfg.MODE_NIS_SOFT -> nis(base)
                        Cfg.MODE_SHARP -> bicubic(base)
                        else -> bilinear(base, ow, oh)
                    }
                    cur = t1
                }
                val rp = if (mode == Cfg.MODE_SGSR || mode == Cfg.MODE_NIS || mode == Cfg.MODE_NIS_ORIG || mode == Cfg.MODE_NIS_SOFT) (if (boost) 1 else 0) else passes
                var n = 0
                while (n < rp) {
                    val d = if (cur === t1) t2 else t1
                    ensure(d, ow, oh)
                    bindOut(d, ow, oh)
                    rcas(cur)
                    cur = d
                    n++
                }
            }
            if (detail) {
                val d = if (cur === t1) t2 else t1
                ensure(d, ow, oh)
                bindOut(d, ow, oh)
                detailPass(cur)
                cur = d
            }
            if (vivid) {
                val d = if (cur === t1) t2 else t1
                ensure(d, ow, oh)
                bindOut(d, ow, oh)
                colorEnhance(cur)
                cur = d
            }
            bindOut(null, w, h)
            if (ow > w || oh > h) downscale(cur, w, h) else bilinear(cur, w, h)
            present()
            return
        }

        // Supersampling: the render scale is above the panel size, so there is nothing to upscale.
        // Sharpen at the big size, then shrink back to the panel with a 4-tap filter.
        if (cw > w || ch > h) {
            var big = base
            var n = 0
            val passes = if (boost) 2 else 1
            while (n < passes) {
                val dstBig = if (big === t1) t2 else t1
                ensure(dstBig, cw, ch)
                bindOut(dstBig, cw, ch)
                rcas(big)
                big = dstBig
                n++
            }
            if (post) {
                ensure(t3, w, h)
                bindOut(t3, w, h)
            } else {
                bindOut(null, w, h)
            }
            downscale(big, w, h)
            if (post) finishPost(t3, t5, w, h, detail, vivid)
            present()
            return
        }

        // 0c) AI model (video export only): the cleaned frame is made bigger by the model; FSR / Lanczos / sharpening carry on from it
        var aiBig = false
        val hook = aiHook
        if (hook != null && !snap && !byp) {
            val ai = aiStage(base, hook)
            if (ai != null) {
                base = ai
                aiBig = ai.w > w || ai.h > h
            }
        }

        // 1) upscale stage
        var cur = base
        var rcasPasses: Int
        rcasK = 1f
        when (if (aiBig) Cfg.MODE_FAST else mode) {
            Cfg.MODE_FSR -> {
                ensure(t1, w, h)
                bindOut(t1, w, h)
                easu(base, w, h)
                cur = t1
                rcasPasses = if (boost) 2 else 1
            }
            Cfg.MODE_SGSR -> {
                if (boost || post) {
                    // Need an offscreen target either to feed a second RCAS pass or the Detail / Vivid pass.
                    ensure(t1, w, h)
                    bindOut(t1, w, h)
                    sgsr(base)
                    cur = t1
                    rcasPasses = if (boost) 1 else 0
                } else {
                    bindOut(null, w, h)
                    sgsr(base)
                    rcasPasses = 0
                }
            }
            Cfg.MODE_NIS, Cfg.MODE_NIS_ORIG, Cfg.MODE_NIS_SOFT -> {
                if (boost || post) {
                    ensure(t1, w, h)
                    bindOut(t1, w, h)
                    nis(base)
                    cur = t1
                    rcasPasses = if (boost) 1 else 0
                } else {
                    bindOut(null, w, h)
                    nis(base)
                    rcasPasses = 0
                }
            }
            Cfg.MODE_LANCZOS -> {
                cur = crscEdge(base, w, h)
                rcasPasses = if (boost) 2 else 1
            }
            Cfg.MODE_FAST -> {
                ensure(t1, w, h)
                bindOut(t1, w, h)
                bilinear(base, w, h)
                cur = t1
                rcasPasses = if (boost) 2 else 1
            }
            else -> rcasPasses = if (boost) 2 else 1
        }

        // 2) sharpening passes. The last one goes straight to the screen, unless a Vivid colors
        // pass still needs to run after it, in which case it goes to an offscreen target instead.
        var i = 0
        while (i < rcasPasses) {
            val last = i == rcasPasses - 1
            val dst: Rt? = if (last && !post) null else (if (cur === t1) t2 else t1)
            if (dst != null) ensure(dst, w, h)
            bindOut(dst, w, h)
            rcas(cur)
            if (dst != null) cur = dst
            i++
        }

        // 3) optional Detail / deblur, then optional color enhance (always last)
        if (post) finishPost(cur, if (cur === t1) t2 else t1, w, h, detail, vivid)
        present()
    }

    /** Runs Detail (if on) then Vivid (if on) from [src]; the final pass goes to the screen. [spare] is the
     *  offscreen target used between the two passes. */
    private fun finishPost(src: Rt, spare: Rt, w: Int, h: Int, detail: Boolean, vivid: Boolean) {
        var cur = src
        if (detail) {
            val dst: Rt? = if (vivid) spare else null
            if (dst != null) ensure(dst, w, h)
            bindOut(dst, w, h)
            detailPass(cur)
            if (dst != null) cur = dst
        }
        if (vivid) {
            bindOut(null, w, h)
            colorEnhance(cur)
        }
    }

    private fun detailPass(src: Rt) {
        val p = pDetail
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2f(p.u("uInv"), 1f / src.w, 1f / src.h)
        GLES30.glUniform1f(p.u("uAmt"), f.detail)
        GLES30.glUniform1f(p.u("uRadius"), 1f + 3f * f.detailSize)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    // ---- passes ---------------------------------------------------------------------------

    private fun bindSrc(rt: Rt) {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, rt.tex)
    }

    private fun easu(src: Rt, ow: Int, oh: Int) {
        val p = pEasu
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2i(p.u("uSrcSize"), src.w, src.h)
        val iw = src.w.toFloat()
        val ih = src.h.toFloat()
        val ox = ow.toFloat()
        val oy = oh.toFloat()
        // FsrEasuCon (ffx_fsr1.h)
        GLES30.glUniform4f(p.u("uCon0"), iw / ox, ih / oy, 0.5f * iw / ox - 0.5f, 0.5f * ih / oy - 0.5f)
        GLES30.glUniform4f(p.u("uCon1"), 1f / iw, 1f / ih, 1f / iw, -1f / ih)
        GLES30.glUniform4f(p.u("uCon2"), -1f / iw, 2f / ih, 1f / iw, 2f / ih)
        GLES30.glUniform4f(p.u("uCon3"), 0f, 4f / ih, 0f, 0f)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private var rcasK = 1f

    private fun rcas(src: Rt) {
        val p = pRcas
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2i(p.u("uSrcSize"), src.w, src.h)
        // The slider is 0..100%; RCAS stays stable up to ~1.3, so 100% = 1.2 (stronger than stock FSR).
        GLES30.glUniform1f(p.u("uSharpness"), f.sharp * 1.2f * rcasK)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private fun nis(src: Rt) {
        val orig = f.mode == Cfg.MODE_NIS_ORIG
        val p = if (orig) pNisOrig else pNis
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2i(p.u("uSrcSize"), src.w, src.h)
        // the output size is the size of the target that is bound now (viewport)
        val vp = IntArray(4)
        GLES30.glGetIntegerv(GLES30.GL_VIEWPORT, vp, 0)
        if (orig) {
            GLES30.glUniform2f(p.u("uScale"), src.w.toFloat() / vp[2], src.h.toFloat() / vp[3])
            GLES30.glUniform1f(p.u("uSharp"), (0.15f + 0.7f * f.sharp).coerceIn(0f, 1f))
        } else {
            // NIS Lite: the slider maps inside the shader; the enlargement factor widens and strengthens the sharpening
            GLES30.glUniform1f(p.u("uFactor"), vp[2].toFloat() / src.w)
            GLES30.glUniform1f(p.u("uGain"), if (f.mode == Cfg.MODE_NIS_SOFT) 0.4f else 1f)
            GLES30.glUniform1f(p.u("uSharp"), f.sharp.coerceIn(0f, 1f))
        }
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private fun sgsr(src: Rt) {
        val p = pSgsr
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2i(p.u("uSrcSize"), src.w, src.h)
        val w = src.w.toFloat()
        val h = src.h.toFloat()
        GLES30.glUniform4f(p.u("uViewportInfo"), 1f / w, 1f / h, w, h)
        // Reference default is 2.0; the slider spans 1.0 (soft) .. 4.0 (strong).
        GLES30.glUniform1f(p.u("uEdgeSharpness"), 1f + 3f * f.sharp)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    // CRSC Edge level tables, index = level 0 Light, 1 Balanced, 2 Strong, 3 Crisp, 4 Ultra, 5 Maximum (saving a file only).
    // Offline test (x3, sharpness 70%, compressed source): edge sharpness 0.71 / 0.76 / 0.81 / 0.87 / 0.91 / 0.93 of the original,
    // halo overshoot 0.17 / 0.25 / 0.37 / 0.56 / 0.75 / 0.8 (FSR 1: 0.23, NIS: 1.0), so the steps are even. On sources that are already
    // sharpened AND compressed the top levels halo more (Ultra about 1.8, the original NIS 2.1): use Balanced or Strong for those.
    private val CRSC_ROUNDS = intArrayOf(1, 1, 1, 1, 1, 3)
    private val CRSC_BOOST = floatArrayOf(0f, 2.0f, 3.0f, 4.0f, 5.0f, 5.0f)
    private val CRSC_OVER = floatArrayOf(0f, 0.03f, 0.04f, 0.05f, 0.06f, 0.06f)
    private val CRSC_RADIUS = floatArrayOf(1f, 1f, 1.15f, 1.25f, 1.33f, 1.33f)
    private val CRSC_SHOCK = floatArrayOf(0f, 1.4f, 1.8f, 2.2f, 2.6f, 2.6f)
    private val CRSC_RCAS = floatArrayOf(0.6f, 0.5f, 0.55f, 0.6f, 0.6f, 0.6f)

    /** CRSC Edge: FSR 1's edge-directed enlargement, then back-projection (the big picture is shrunk back to the source size,
     *  compared with the real source and the difference is added back), edge smoothing, detail boost and edge steepening.
     *  Returns the target that holds the result (t1 or t2) and sets [rcasK] for the last RCAS pass. Used by the normal path and
     *  by the chosen-output-size path (before, the chosen-size path silently did plain bilinear for CRSC Edge). */
    private fun crscEdge(base: Rt, w: Int, h: Int): Rt {
        ensure(t1, w, h)
        bindOut(t1, w, h)
        easu(base, w, h)
        var cur = t1
        // CRSC Edge levels: one back-projection round each (3 for Maximum), then edge smoothing, and from Balanced up a wide
        // detail boost + edge steepening that grow step by step (see the CRSC_* tables), so every level is visibly sharper than the last.
        var lv = if (crscOverride >= 0) crscOverride.coerceIn(0, 5) else Cfg.crscLevel.coerceIn(0, 5)
        if (lv == 5 && !exportMode && !allowMax) lv = 4
        repeat(CRSC_ROUNDS[lv]) {
            ensure(crscD, base.w, base.h)
            bindOut(crscD, base.w, base.h)
            val dq = pCrscDown
            GLES30.glUseProgram(dq.id)
            bindSrc(cur)
            GLES30.glUniform1i(dq.u("uSrc"), 0)
            GLES30.glUniform2f(dq.u("uInv"), 1f / base.w, 1f / base.h)
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
            val dst = if (cur === t1) t2 else t1
            ensure(dst, w, h)
            bindOut(dst, w, h)
            val bp = pCrscBp
            GLES30.glUseProgram(bp.id)
            bindSrc(cur)
            bindTex(1, base)
            bindTex(2, crscD)
            GLES30.glUniform1i(bp.u("uSrc"), 0)
            GLES30.glUniform1i(bp.u("uLow"), 1)
            GLES30.glUniform1i(bp.u("uD"), 2)
            GLES30.glUniform2f(bp.u("uInv"), 1f / base.w, 1f / base.h)
            GLES30.glUniform1f(bp.u("uG"), if (lv == 5) 1.3f else 0.9f)
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
            GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
            cur = dst
        }
        val ratio = (w.toFloat() / base.w).coerceIn(1f, 4f)
        val sk = f.sharp.coerceIn(0f, 1f)
        // 1) anti-aliasing: smooth along every edge (removes the stair-steps of the enlargement)
        run {
            val dst = if (cur === t1) t2 else t1
            ensure(dst, w, h)
            bindOut(dst, w, h)
            val er = pEdgeRefine
            GLES30.glUseProgram(er.id)
            bindSrc(cur)
            GLES30.glUniform1i(er.u("uSrc"), 0)
            GLES30.glUniform2f(er.u("uInv"), 1f / w, 1f / h)
            GLES30.glUniform1f(er.u("uR"), (0.67f * ratio).coerceIn(1f, 2.5f))
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
            cur = dst
        }
        // 2) wide detail boost on mid-contrast detail (no halo, never leaves the local range)
        if (lv > 0) {
            val dst = if (cur === t1) t2 else t1
            ensure(dst, w, h)
            bindOut(dst, w, h)
            val us = pCrscSharp
            GLES30.glUseProgram(us.id)
            bindSrc(cur)
            GLES30.glUniform1i(us.u("uSrc"), 0)
            GLES30.glUniform2f(us.u("uInv"), 1f / w, 1f / h)
            GLES30.glUniform1f(us.u("uR"), (0.5f * ratio * CRSC_RADIUS[lv]).coerceIn(1f, 2f))
            GLES30.glUniform1f(us.u("uAmt"), CRSC_BOOST[lv] * (0.3f + sk))
            GLES30.glUniform1f(us.u("uOver"), CRSC_OVER[lv])
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
            cur = dst
        }
        // 3) steepen the edges (shock filter: narrower ramp, no halo, no overshoot)
        if (lv > 0) {
            val sdst = if (cur === t1) t2 else t1
            ensure(sdst, w, h)
            bindOut(sdst, w, h)
            val esh = pEdgeShock
            GLES30.glUseProgram(esh.id)
            bindSrc(cur)
            GLES30.glUniform1i(esh.u("uSrc"), 0)
            GLES30.glUniform2f(esh.u("uInv"), 1f / w, 1f / h)
            GLES30.glUniform1f(esh.u("uR"), ratio)
            GLES30.glUniform1f(esh.u("uAmt"), (0.1f + 0.2f * sk) * CRSC_SHOCK[lv])
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
            cur = sdst
        }
        // the last RCAS pass is lighter here, the passes above already did most of the sharpening
        rcasK = CRSC_RCAS[lv]
        return cur
    }

    private fun bicubic(src: Rt) {
        val p = pBicubic
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2f(p.u("uSrcSize"), src.w.toFloat(), src.h.toFloat())
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private fun bilinear(src: Rt, ow: Int, oh: Int) {
        val p = pBilinear
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    /** Shrinks [src] into [dst] (already sized tw x th): halving steps while the factor is 2 or more, then one 4-tap step. */
    private fun shrink(src: Rt, tw: Int, th: Int, dst: Rt) {
        var cur = src
        var useA = true
        while (cur.w / 2 >= tw && cur.h / 2 >= th) {
            val t = if (useA) shrA else shrB
            val nw = cur.w / 2
            val nh = cur.h / 2
            ensure(t, nw, nh)
            bindOut(t, nw, nh)
            downscale(cur, nw, nh)
            cur = t
            useA = !useA
        }
        bindOut(dst, tw, th)
        downscale(cur, tw, th)
    }

    private fun downscale(src: Rt, ow: Int, oh: Int) {
        val p = pDown
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2f(p.u("uStep"), 0.25f / ow, 0.25f / oh)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private fun denoisePass(src: Rt) {
        val p = pDenoise
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2f(p.u("uInv"), 1f / src.w, 1f / src.h)
        GLES30.glUniform1f(p.u("uAmt"), f.denoise)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private fun debandPass(src: Rt) {
        val p = pDeband
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2f(p.u("uInv"), 1f / src.w, 1f / src.h)
        GLES30.glUniform1f(p.u("uAmt"), f.deband)
        GLES30.glUniform1f(p.u("uRange"), 24f)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private fun nearest(src: Rt) {
        val p = pNearest
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2i(p.u("uSrcSize"), src.w, src.h)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private fun antiAlias(src: Rt, mode: Int) {
        val p = when (mode) {
            Cfg.AA_FXAA_FAST -> pFxaaFast
            Cfg.AA_FXAA_QUALITY -> pFxaaQ
            else -> pEdge
        }
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2f(p.u("uInv"), 1f / src.w, 1f / src.h)
        GLES30.glUniform1f(p.u("uAmt"), f.aaStrength)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private fun colorEnhance(src: Rt) {
        val p = pColor
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform1f(p.u("uVivid"), f.vivid)
        GLES30.glUniform1f(p.u("uContrast"), f.contrast)
        if (f.smartFix) {
            GLES30.glUniform3f(p.u("uFixGain"), fixGain[0], fixGain[1], fixGain[2])
            GLES30.glUniform3f(p.u("uFixLvl"), fixLo, 1f / fixSpan, fixGamma)
        } else {
            GLES30.glUniform3f(p.u("uFixGain"), 1f, 1f, 1f)
            GLES30.glUniform3f(p.u("uFixLvl"), 0f, 1f, 1f)
        }
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    // ---- Smart fix: the frame is looked at (a tiny copy), the correction is smoothed over time ----------------

    private val fixGain = floatArrayOf(1f, 1f, 1f)
    private var fixLo = 0f
    private var fixSpan = 1f
    private var fixGamma = 1f
    private var fixFrames = 0
    private var fixFresh = true
    private var fixWasOn = false
    private val fixBuf: java.nio.ByteBuffer = java.nio.ByteBuffer.allocateDirect(96 * 54 * 4).order(java.nio.ByteOrder.nativeOrder())

    /** Forgets what was measured (a new video / photo starts, or Smart fix was just switched on). */
    fun resetSmartFix() {
        fixFresh = true
    }

    private fun byp0() = bypass

    /** Measures the copied frame [t0] about twice a second (at once for a still picture or a snapshot) and moves the correction towards it. */
    private fun smartFixMeasure(w0: Int, h0: Int) {
        fixFrames++
        if (!(fixFresh || snap || fixFrames % 15 == 0)) return
        ensure(tFix, 96, 54)
        bindOut(tFix, 96, 54)
        bilinear(t0, 96, 54)
        fixBuf.clear()
        GLES30.glReadPixels(0, 0, 96, 54, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, fixBuf)
        val px = IntArray(96 * 54)
        fixBuf.rewind()
        for (i in px.indices) {
            val r = fixBuf.get().toInt() and 0xFF
            val g = fixBuf.get().toInt() and 0xFF
            val b = fixBuf.get().toInt() and 0xFF
            fixBuf.get()
            px[i] = (r shl 16) or (g shl 8) or b
        }
        val m = SmartFix.measure(px) ?: SmartFix.Params.NONE
        val k = if (fixFresh || snap) 1f else 0.2f // a still picture takes the measured values at once, video moves gently (no flicker)
        for (i in 0..2) fixGain[i] += (m.gain[i] - fixGain[i]) * k
        fixLo += (m.lo - fixLo) * k
        fixSpan += (m.span - fixSpan) * k
        fixGamma += (m.gamma - fixGamma) * k
        fixFresh = false
    }

    private fun bindOut(rt: Rt?, w: Int, h: Int) {
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, rt?.fbo ?: outFbo)
        GLES30.glViewport(0, 0, w, h)
    }

    private fun ensure(rt: Rt, w: Int, h: Int) {
        if (rt.tex != 0 && rt.w == w && rt.h == h) return
        free(rt)
        val t = IntArray(1)
        GLES30.glGenTextures(1, t, 0)
        rt.tex = t[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, rt.tex)
        GLES30.glTexImage2D(
            GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA8, w, h, 0,
            GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, null
        )
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        val f = IntArray(1)
        GLES30.glGenFramebuffers(1, f, 0)
        rt.fbo = f[0]
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, rt.fbo)
        GLES30.glFramebufferTexture2D(
            GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, rt.tex, 0
        )
        val status = GLES30.glCheckFramebufferStatus(GLES30.GL_FRAMEBUFFER)
        if (status != GLES30.GL_FRAMEBUFFER_COMPLETE) error("framebuffer incomplete: $status ($w x $h)")
        rt.w = w
        rt.h = h
    }

    private fun free(rt: Rt) {
        if (rt.fbo != 0) GLES30.glDeleteFramebuffers(1, intArrayOf(rt.fbo), 0)
        if (rt.tex != 0) GLES30.glDeleteTextures(1, intArrayOf(rt.tex), 0)
        rt.fbo = 0
        rt.tex = 0
        rt.w = 0
        rt.h = 0
    }

    /** Tears everything down. Blocks briefly so EGL is gone before the window surface dies. */
    fun release() {
        alive = false
        val done = CountDownLatch(1)
        hd.post {
            runCatching {
                st?.setOnFrameAvailableListener(null)
                inSurface?.release()
                st?.release()
                free(t0)
                free(t1)
                free(t2)
                free(t3)
                free(t4)
                free(t5)
                free(t6)
                free(t7)
                free(tFix)
                free(fgA)
                free(tAi)
                free(thA)
                free(thB)
                free(tMv)
                free(crscD)
                free(midRt)
                free(inRt)
                free(shrA)
                free(shrB)
                free(fgB)
                free(fgMv)
                free(fgSA)
                free(fgSB)
                if (oesTex != 0) GLES30.glDeleteTextures(1, intArrayOf(oesTex), 0)
                for (p in arrayOf(pCopy, pEasu, pRcas, pSgsr, pBilinear, pBicubic, pColor, pDown, pFxaaFast, pFxaaQ, pEdge, pNearest, pDetail, pDenoise, pDeband, pTemporal, pEdgeRefine, pCrscSharp, pCrscDown, pCrscBp, pEdgeShock, pNis, pNisOrig, pFgMotion, pFgInterp)) GLES30.glDeleteProgram(p.id)
            }
            runCatching {
                EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                EGL14.eglDestroySurface(dpy, srf)
                EGL14.eglDestroyContext(dpy, ctx)
                EGL14.eglTerminate(dpy)
            }
            done.countDown()
        }
        done.await(400, TimeUnit.MILLISECONDS)
        ht.quitSafely()
    }

    private fun link(vs: String, fs: String, name: String): Int {
        val v = compile(GLES30.GL_VERTEX_SHADER, vs, "$name.vert")
        val f = compile(GLES30.GL_FRAGMENT_SHADER, fs, "$name.frag")
        val p = GLES30.glCreateProgram()
        GLES30.glAttachShader(p, v)
        GLES30.glAttachShader(p, f)
        GLES30.glLinkProgram(p)
        val ok = IntArray(1)
        GLES30.glGetProgramiv(p, GLES30.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) error("link $name: " + GLES30.glGetProgramInfoLog(p))
        GLES30.glDeleteShader(v)
        GLES30.glDeleteShader(f)
        return p
    }

    private fun compile(type: Int, src: String, name: String): Int {
        val s = GLES30.glCreateShader(type)
        GLES30.glShaderSource(s, src)
        GLES30.glCompileShader(s)
        val ok = IntArray(1)
        GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) error("shader $name: " + GLES30.glGetShaderInfoLog(s))
        return s
    }

    private companion object {
        /** Frame generation searches for motion on a copy that is at most this wide. */
        const val FG_SEARCH_W = 960
        const val TAG = "CRSC"
    }
}
