package app.clearoverlay

import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES30
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.Surface
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Receives captured frames (external OES texture), runs ONE shader pass
 * (Catmull-Rom upscale when the capture is smaller than the screen + contrast-adaptive
 * sharpening) and presents the result on [out] (the overlay's surface).
 */
class GlPipeline(private val out: Surface) {
    private val ht = HandlerThread("clear-gl").also { it.start() }
    private val hd = Handler(ht.looper)

    private var dpy: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var ctx: EGLContext = EGL14.EGL_NO_CONTEXT
    private var srf: EGLSurface = EGL14.EGL_NO_SURFACE
    private var tex = 0
    private var prog = 0
    private var st: SurfaceTexture? = null
    private var inSurface: Surface? = null

    private var uTexM = 0
    private var uSrc = 0
    private var uOut = 0
    private var uSharp = 0
    private var uUp = 0

    private val m = FloatArray(16)
    private val sz = IntArray(1)

    @Volatile private var capW = 2
    @Volatile private var capH = 2
    @Volatile private var alive = true

    /** Builds GL on its own thread, then hands back the Surface the VirtualDisplay must write to. */
    fun start(w: Int, h: Int, onReady: (Surface) -> Unit) {
        capW = w
        capH = h
        hd.post {
            try {
                init()
                onReady(inSurface!!)
            } catch (t: Throwable) {
                Log.e(TAG, "GL init failed", t)
            }
        }
    }

    fun setCaptureSize(w: Int, h: Int) {
        capW = w
        capH = h
        st?.setDefaultBufferSize(w, h)
    }

    private fun init() {
        dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val v = IntArray(2)
        EGL14.eglInitialize(dpy, v, 0, v, 1)
        val attrs = intArrayOf(
            EGL14.EGL_RENDERABLE_TYPE, EGLExt.EGL_OPENGL_ES3_BIT_KHR,
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8,
            EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_NONE
        )
        val cfgs = arrayOfNulls<EGLConfig>(1)
        val n = IntArray(1)
        EGL14.eglChooseConfig(dpy, attrs, 0, cfgs, 0, 1, n, 0)
        ctx = EGL14.eglCreateContext(
            dpy, cfgs[0], EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 3, EGL14.EGL_NONE), 0
        )
        srf = EGL14.eglCreateWindowSurface(dpy, cfgs[0], out, intArrayOf(EGL14.EGL_NONE), 0)
        EGL14.eglMakeCurrent(dpy, srf, srf, ctx)
        EGL14.eglSwapInterval(dpy, 0)

        val t = IntArray(1)
        GLES30.glGenTextures(1, t, 0)
        tex = t[0]
        val oes = GLES11Ext.GL_TEXTURE_EXTERNAL_OES
        GLES30.glBindTexture(oes, tex)
        GLES30.glTexParameteri(oes, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(oes, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(oes, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(oes, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)

        prog = link(VERT, FRAG)
        GLES30.glUseProgram(prog)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(prog, "uTex"), 0)
        uTexM = GLES30.glGetUniformLocation(prog, "uTexM")
        uSrc = GLES30.glGetUniformLocation(prog, "uSrc")
        uOut = GLES30.glGetUniformLocation(prog, "uOut")
        uSharp = GLES30.glGetUniformLocation(prog, "uSharp")
        uUp = GLES30.glGetUniformLocation(prog, "uUp")

        val s = SurfaceTexture(tex)
        s.setDefaultBufferSize(capW, capH)
        s.setOnFrameAvailableListener({ draw() }, hd)
        st = s
        inSurface = Surface(s)
    }

    private fun draw() {
        if (!alive) return
        val s = st ?: return
        try {
            s.updateTexImage()
        } catch (e: Exception) {
            return
        }
        s.getTransformMatrix(m)
        EGL14.eglQuerySurface(dpy, srf, EGL14.EGL_WIDTH, sz, 0)
        val w = sz[0]
        EGL14.eglQuerySurface(dpy, srf, EGL14.EGL_HEIGHT, sz, 0)
        val h = sz[0]
        if (w <= 0 || h <= 0) return

        GLES30.glViewport(0, 0, w, h)
        GLES30.glUseProgram(prog)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex)
        GLES30.glUniformMatrix4fv(uTexM, 1, false, m, 0)
        GLES30.glUniform2f(uSrc, capW.toFloat(), capH.toFloat())
        GLES30.glUniform2f(uOut, w.toFloat(), h.toFloat())
        GLES30.glUniform1f(uSharp, Cfg.sharp)
        GLES30.glUniform1f(uUp, if (capW < w * 0.98f) 1f else 0f)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
        EGL14.eglSwapBuffers(dpy, srf)
    }

    /** Tears everything down. Blocks briefly so EGL is gone before the window surface dies. */
    fun release() {
        alive = false
        val done = CountDownLatch(1)
        hd.post {
            runCatching {
                st?.setOnFrameAvailableListener(null)
                inSurface?.release()
                st?.release()
                if (tex != 0) GLES30.glDeleteTextures(1, intArrayOf(tex), 0)
                if (prog != 0) GLES30.glDeleteProgram(prog)
                EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                EGL14.eglDestroySurface(dpy, srf)
                EGL14.eglDestroyContext(dpy, ctx)
                EGL14.eglTerminate(dpy)
            }
            done.countDown()
        }
        done.await(400, TimeUnit.MILLISECONDS)
        ht.quitSafely()
    }

    private fun link(vs: String, fs: String): Int {
        val v = compile(GLES30.GL_VERTEX_SHADER, vs)
        val f = compile(GLES30.GL_FRAGMENT_SHADER, fs)
        val p = GLES30.glCreateProgram()
        GLES30.glAttachShader(p, v)
        GLES30.glAttachShader(p, f)
        GLES30.glLinkProgram(p)
        val ok = IntArray(1)
        GLES30.glGetProgramiv(p, GLES30.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) error("link: " + GLES30.glGetProgramInfoLog(p))
        GLES30.glDeleteShader(v)
        GLES30.glDeleteShader(f)
        return p
    }

    private fun compile(type: Int, src: String): Int {
        val s = GLES30.glCreateShader(type)
        GLES30.glShaderSource(s, src)
        GLES30.glCompileShader(s)
        val ok = IntArray(1)
        GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) error("shader: " + GLES30.glGetShaderInfoLog(s))
        return s
    }

    private companion object {
        const val TAG = "ClearGl"

        // Fullscreen triangle generated from gl_VertexID (no buffers needed).
        const val VERT = """#version 300 es
out vec2 vUv;
void main() {
    vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
    vUv = p;
    gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
}
"""

        const val FRAG = """#version 300 es
#extension GL_OES_EGL_image_external_essl3 : require
precision highp float;
precision highp samplerExternalOES;

uniform samplerExternalOES uTex;
uniform mat4 uTexM;
uniform vec2 uSrc;     // capture size in texels
uniform vec2 uOut;     // output size in pixels
uniform float uSharp;  // 0..1
uniform float uUp;     // 1 = capture smaller than output (use bicubic)
in vec2 vUv;
out vec4 o;

vec3 tap(vec2 uv) {
    return texture(uTex, (uTexM * vec4(uv, 0.0, 1.0)).xy).rgb;
}

// Catmull-Rom bicubic using 9 bilinear taps.
vec3 catmull(vec2 uv) {
    vec2 pos = uv * uSrc;
    vec2 c = floor(pos - 0.5) + 0.5;
    vec2 f = pos - c;
    vec2 w0 = f * (-0.5 + f * (1.0 - 0.5 * f));
    vec2 w1 = 1.0 + f * f * (-2.5 + 1.5 * f);
    vec2 w2 = f * (0.5 + f * (2.0 - 1.5 * f));
    vec2 w3 = f * f * (-0.5 + 0.5 * f);
    vec2 w12 = w1 + w2;
    vec2 t12 = w2 / w12;
    vec2 p0 = (c - 1.0) / uSrc;
    vec2 p3 = (c + 2.0) / uSrc;
    vec2 p12 = (c + t12) / uSrc;
    vec3 col =
        tap(vec2(p0.x,  p0.y))  * (w0.x  * w0.y)  +
        tap(vec2(p12.x, p0.y))  * (w12.x * w0.y)  +
        tap(vec2(p3.x,  p0.y))  * (w3.x  * w0.y)  +
        tap(vec2(p0.x,  p12.y)) * (w0.x  * w12.y) +
        tap(vec2(p12.x, p12.y)) * (w12.x * w12.y) +
        tap(vec2(p3.x,  p12.y)) * (w3.x  * w12.y) +
        tap(vec2(p0.x,  p3.y))  * (w0.x  * w3.y)  +
        tap(vec2(p12.x, p3.y))  * (w12.x * w3.y)  +
        tap(vec2(p3.x,  p3.y))  * (w3.x  * w3.y);
    return clamp(col, 0.0, 1.0);
}

void main() {
    vec2 px = 1.0 / uOut;
    vec3 c = (uUp > 0.5) ? catmull(vUv) : tap(vUv);
    if (uSharp <= 0.001) {
        o = vec4(c, 1.0);
        return;
    }
    vec3 a = tap(vUv + vec2(0.0, -px.y));
    vec3 b = tap(vUv + vec2(-px.x, 0.0));
    vec3 d = tap(vUv + vec2(px.x, 0.0));
    vec3 e = tap(vUv + vec2(0.0, px.y));

    // Contrast-adaptive sharpening (idea from AMD FidelityFX CAS): sharpen less
    // where local contrast is already high, so edges don't ring.
    vec3 mn = min(min(min(a, b), min(d, e)), c);
    vec3 mx = max(max(max(a, b), max(d, e)), c);
    vec3 amp = sqrt(clamp(min(mn, 1.0 - mx) / max(mx, vec3(1e-4)), 0.0, 1.0));
    vec3 w = -amp * (0.2 * uSharp);
    vec3 res = (c + (a + b + d + e) * w) / (1.0 + 4.0 * w);
    o = vec4(clamp(res, 0.0, 1.0), 1.0);
}
"""
    }
}
