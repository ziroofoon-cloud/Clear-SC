package app.clearoverlay

import android.graphics.Bitmap
import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES30
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Captured frame (external OES texture) -> RGBA copy -> [EASU | SGSR1 | Bilinear] -> RCAS
 * -> optional Vivid colors pass -> overlay surface.
 *
 *  Sharpen : copy -> RCAS (x1, x2 with boost)
 *  FSR 1   : copy -> EASU (upscale) -> RCAS (x1, x2 with boost)
 *  SGSR 1  : copy -> SGSR1 -> (RCAS only with boost)
 *  Fast    : copy -> hardware bilinear upscale -> RCAS (x1, x2 with boost)
 *  Raw     : copy -> nearest-neighbour to the panel (no upscale filter, no sharpening); for comparing resolutions
 *  Render scale > 100% (any mode, Sharpen included): copy -> RCAS at the big size -> 4-tap downscale to the panel.
 *  Denoise / deblock and Deband (when enabled) run first, then anti-aliasing, all at capture size.
 *  Anti-aliasing (FXAA fast / FXAA quality / Edge Smooth), when enabled, runs right after the copy, before
 *  any upscale or sharpening.
 *  Vivid colors, when enabled, always runs last regardless of mode.
 */
class GlPipeline(private val out: Surface) {
    private class Prog(val id: Int) {
        private val cache = HashMap<String, Int>()
        fun u(name: String): Int = cache.getOrPut(name) { GLES30.glGetUniformLocation(id, name) }
    }

    private class Rt {
        var tex = 0
        var fbo = 0
        var w = 0
        var h = 0
    }

    private val ht = HandlerThread("crsc-gl").also { it.start() }
    private val hd = Handler(ht.looper)

    private var dpy: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var ctx: EGLContext = EGL14.EGL_NO_CONTEXT
    private var srf: EGLSurface = EGL14.EGL_NO_SURFACE
    private var oesTex = 0
    private var st: SurfaceTexture? = null
    private var inSurface: Surface? = null

    private lateinit var pCopy: Prog
    private lateinit var pEasu: Prog
    private lateinit var pRcas: Prog
    private lateinit var pSgsr: Prog
    private lateinit var pBilinear: Prog
    private lateinit var pBicubic: Prog
    private lateinit var pColor: Prog
    private lateinit var pDown: Prog
    private lateinit var pFxaaFast: Prog
    private lateinit var pFxaaQ: Prog
    private lateinit var pEdge: Prog
    private lateinit var pSmart: Prog
    private lateinit var pNearest: Prog
    private lateinit var pDetail: Prog
    private lateinit var pDenoise: Prog
    private var pChroma: Prog? = null // "Colour clean-up" (Shaders.CHROMA); null = the driver refused it, the step is skipped
    private lateinit var pPreSharp: Prog
    private var pPixelCrisp: Prog? = null // "Fine pixels", second step (Shaders.PIXEL_CRISP); null = the one-step version is used
    private val tPix = Rt() // one pixel per block
    private var pPixelPost: Prog? = null // "Fine pixels" as a finishing step (Shaders.PIXEL_POST); null = driver refused it, the step is skipped
    private var pPixel: Prog? = null // "Fine pixels" upscaler; null if the driver refused the shader (then bilinear is used)
    private var pGameLight: Prog? = null // "Game Light" pass; null if the driver refused the shader (then it is simply not drawn)
    private var pArtUp: Prog? = null // "Wow" upscaler, pass 1 (Shaders.ART_UP); null if the driver refused it
    private var pArtStyle: Prog? = null // "Wow" upscaler, pass 2 (Shaders.ART_STYLE); null = pass 1 only
    // between the two "Wow" passes. One target per stage: the stages have different sizes, and one shared target would be re-made every frame
    private val tArtMid = Rt() // middle step
    private val tArtOut = Rt() // output step
    private val tArt = Rt() // final stage
    private var pClear: Prog? = null // "Clear" upscaler; null if the driver refused the shader (then FSR 1 is used)
    private var postAa = Cfg.AA_OFF // Clean upscale: the anti-aliasing mode that runs AFTER the upscale this frame (AA_OFF = none)
    private lateinit var pDeband: Prog
    private lateinit var pDeint: Prog
    private val BAR_W = 192
    private val BAR_H = 108
    private lateinit var pTemporal: Prog
    private lateinit var pTemporalMv: Prog
    private lateinit var pEdgeRefine: Prog
    private lateinit var pCrscSharp: Prog
    private lateinit var pCrscDown: Prog
    private lateinit var pEdgeShock: Prog
    private lateinit var pNis: Prog
    private lateinit var pNisOrig: Prog
    private var pNisMid: Prog? = null // NIS mid; null / pNisOrig when the driver refused the shader (same uniforms as NIS original)
    // textureGather versions of NIS fast / NIS mid (OpenGL ES 3.1+): the luma of the source is made once per frame into an R32F texture (lumaRt)
    // and read 4 pixels per fetch. Same picture as the normal shaders. gatherState: 0 not decided yet, 1 usable, -1 not usable on this device
    // (older ES, no float render target, shader refused, ...): then the normal shaders are used, as before.
    private val lumaRt = Rt()
    private var pLuma: Prog? = null
    private var pLumaD: Prog? = null // the luma pass of the Aura gather version (the same dot() as the Aura shader)
    private var pNisAuraG: Prog? = null
    private val pNisFastG = arrayOfNulls<Prog>(6) // gather versions: index = level, +3 for "NIS fast (clean)"
    private var gatherState = 0
    private var gatherChecked = false // the first frame drawn with a gather shader is checked for a GL error once (then the normal shaders take over)
    private val vert310: String by lazy { Shaders.VERT.replace("#version 300 es", "#version 310 es") }
    private val pNisFastLv = arrayOfNulls<Prog>(6) // NIS fast: exact / medium / light (the lighter two are built on first use); +3 for "NIS fast (clean)"
    // light version of the original NIS sharpener for scale 1 (CRSC Edge + NIS crispness); null if this phone's driver refuses it
    private var pNisSharp: Prog? = null
    // "Crisp Fast": the same picture as pNisSharp with less work (see Shaders.NIS_CRISP_FAST); null if the driver refuses it
    private var pCrispFast: Prog? = null
    private lateinit var pCrscBp: Prog
    private val crscD = Rt()
    private val midRt = Rt()
    private val inRt = Rt()
    private val shrA = Rt()
    private val shrB = Rt()
    private lateinit var pFgMotion: Prog
    private lateinit var pFgInterp: Prog

    /** Frame generation: one extra frame is made between every two source frames (2x the frame rate). */
    /** Video export with an AI model: gets the cleaned frame (upside down, plain RGBA) and returns the bigger picture, or null. */
    @Volatile var aiHook: ((Bitmap) -> Bitmap?)? = null
    private val tAi = Rt()

    /** Temporal clean-up using the previous frames: 0 off, 1 light, 2 strong. */
    @Volatile var temporal = 0

    /** CRSC quality override (export); -1 = use the app setting. */
    @Volatile var crscOverride = -1
    private val thA = Rt()
    private val thB = Rt()
    private val tMv = Rt()
    private var thCur: Rt? = null
    @Volatile private var tmpNew = false

    @Volatile var frameGen = false
    /** Frames per source frame: 2 (x2), 3 or 4. */
    @Volatile var frameGenN = 2
    /** Motion search quality: 0 light (a quarter of the work), 1 normal, 2 high (smaller blocks and a finer search). */
    @Volatile var fgQuality = 1
    private val fgA = Rt()
    private val fgB = Rt()
    private val fgMv = Rt()
    /** Small copies of the two last frames: the motion search runs on these (a quarter of the work at 1920 px and more). */
    private val fgSA = Rt()
    private val fgSB = Rt()
    private var fgMvScale = 1f
    private var fgNo = 0L
    private var fgANo = 0L
    private var fgBNo = 0L
    private var fgSANo = 0L
    private var fgSBNo = 0L
    private var fgCurRt: Rt = fgA
    private var fgPrevRt: Rt? = null
    private var fgHave = false
    private var fgLastNs = 0L
    private var fgInterval = 33_000_000L
    private var fgSeq = 0
    @Volatile private var capturing = false
    private val t0 = Rt()
    private val t1 = Rt()
    private val t2 = Rt()
    private val t3 = Rt()
    private val t4 = Rt() // anti-aliasing output
    private val t5 = Rt() // detail pass output (panel size)
    private val t6 = Rt() // second ping-pong target for the capture-size cleanup passes
    private val tBar = Rt()
    private val tFix = Rt() // tiny copy of the frame measured by Smart fix
    private val t7 = Rt() // offscreen result used by [snapshot] (save to gallery)

    /** True while [snapshot] renders into [t7] instead of the window: no zoom, no buffer swap. */
    @Volatile private var snap = false
    @Volatile private var outFbo = 0

    private val m = FloatArray(16)
    private val sz = IntArray(1)

    @Volatile private var capW = 2
    @Volatile private var capH = 2
    @Volatile private var alive = true
    private var failed = false

    /** True = skip every effect: the frame is only copied and scaled with the hardware bilinear filter
     *  (what a normal player would show). Used by the player's effect on/off switch. */
    @Volatile var bypass = false

    /** Zoom into the frame (player only): [zoom] >= 1, centre ([zoomX], [zoomY]) in 0..1 (y up). The cropped part is
     *  taken from the real source pixels and goes through the normal pipeline, so effects can be inspected up close. */
    @Volatile var zoom = 1f
    @Volatile var zoomX = 0.5f
    @Volatile var zoomY = 0.5f

    /** The part of the frame that fills the view while zoomed, as fractions of the frame's width / height (1 / zoom each when the view has
     *  the frame's shape; the player makes the view bigger than the fitted picture while zoomed, so the fractions can differ). */
    @Volatile var zoomWX = 1f
    @Volatile var zoomWY = 1f

    /** Auto crop of black bars (player only): the bars found at the left / bottom / right / top of the frame, as fractions of its size (y up).
     *  The part of the frame inside them is what the view shows (the player makes the view the shape of that part). [onBars] gets a new
     *  stable measurement (left, bottom, right, top) on the GL thread; the player applies it and sets the fields above. */
    @Volatile var barL = 0f
    @Volatile var barB = 0f
    @Volatile var barR = 0f
    @Volatile var barT = 0f
    @Volatile var onBars: ((FloatArray) -> Unit)? = null
    private val barHist = ArrayList<FloatArray>()
    private var barFrames = 0
    private var barResetSent = false
    private val barBuf: java.nio.ByteBuffer = java.nio.ByteBuffer.allocateDirect(BAR_W * BAR_H * 4).order(java.nio.ByteOrder.nativeOrder())

    fun setZoom(z: Float, x: Float, y: Float, wx: Float = 1f / z, wy: Float = 1f / z) {
        zoom = z
        zoomX = x
        zoomY = y
        zoomWX = wx
        zoomWY = wy
        redraw()
    }

    /** Called (on the GL thread) when GL setup or rendering fails; the message is shown to the user. */
    @Volatile var onError: ((String) -> Unit)? = null

    /** Builds GL on its own thread, then hands back the Surface the VirtualDisplay must write to. */
    fun start(w: Int, h: Int, onReady: (Surface) -> Unit) {
        capW = w
        capH = h
        hd.post {
            try {
                init()
                onReady(inSurface!!)
            } catch (t: Throwable) {
                Log.e(TAG, "GL init failed", t)
                onError?.invoke(t.message ?: "GL init failed")
            }
        }
    }

    fun setCaptureSize(w: Int, h: Int) {
        capW = w
        capH = h
        st?.setDefaultBufferSize(w, h)
    }

    private fun init() {
        dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val v = IntArray(2)
        EGL14.eglInitialize(dpy, v, 0, v, 1)
        val attrs = if (recordable) intArrayOf(
            EGL14.EGL_RENDERABLE_TYPE, EGLExt.EGL_OPENGL_ES3_BIT_KHR,
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8,
            EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            0x3142, 1, // EGL_RECORDABLE_ANDROID
            EGL14.EGL_NONE
        ) else intArrayOf(
            EGL14.EGL_RENDERABLE_TYPE, EGLExt.EGL_OPENGL_ES3_BIT_KHR,
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8,
            EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_NONE
        )
        val cfgs = arrayOfNulls<EGLConfig>(1)
        val n = IntArray(1)
        EGL14.eglChooseConfig(dpy, attrs, 0, cfgs, 0, 1, n, 0)
        ctx = EGL14.eglCreateContext(
            dpy, cfgs[0], EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 3, EGL14.EGL_NONE), 0
        )
        srf = EGL14.eglCreateWindowSurface(dpy, cfgs[0], out, intArrayOf(EGL14.EGL_NONE), 0)
        EGL14.eglMakeCurrent(dpy, srf, srf, ctx)
        EGL14.eglSwapInterval(dpy, 0)

        val t = IntArray(1)
        GLES30.glGenTextures(1, t, 0)
        oesTex = t[0]
        val oes = GLES11Ext.GL_TEXTURE_EXTERNAL_OES
        GLES30.glBindTexture(oes, oesTex)
        GLES30.glTexParameteri(oes, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(oes, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(oes, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(oes, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)

        pCopy = Prog(link(Shaders.VERT, Shaders.OES_COPY, "copy"))
        upOptApplied = Cfg.upOpt.coerceIn(0, 2)
        pEasu = Prog(link(Shaders.VERT, if (upOptApplied >= 2 && LITE_TEXEL_SHADERS) Shaders.EASU_L else Shaders.EASU, "easu"))
        pRcas = Prog(link(Shaders.VERT, Shaders.RCAS, "rcas"))
        pSgsr = Prog(link(Shaders.VERT, Shaders.SGSR1, "sgsr1"))
        pBilinear = Prog(link(Shaders.VERT, Shaders.BILINEAR, "bilinear"))
        pBicubic = Prog(link(Shaders.VERT, Shaders.BICUBIC, "bicubic"))
        pColor = Prog(link(Shaders.VERT, Shaders.COLOR_ENHANCE, "color"))
        pDown = Prog(link(Shaders.VERT, Shaders.DOWNSCALE, "downscale"))
        pFxaaFast = Prog(link(Shaders.VERT, Shaders.FXAA_FAST, "fxaa_fast"))
        pFxaaQ = Prog(link(Shaders.VERT, Shaders.FXAA_QUALITY, "fxaa_quality"))
        pEdge = Prog(link(Shaders.VERT, Shaders.EDGE_SMOOTH, "edge_smooth"))
        pSmart = Prog(link(Shaders.VERT, Shaders.EDGE_SMART, "edge_smart"))
        pNearest = Prog(link(Shaders.VERT, Shaders.NEAREST, "nearest"))
        pDetail = Prog(link(Shaders.VERT, Shaders.DETAIL, "detail"))
        pDenoise = Prog(link(Shaders.VERT, Shaders.DENOISE, "denoise"))
        pChroma = runCatching { Prog(link(Shaders.VERT, Shaders.CHROMA, "chroma")) }.getOrNull()
        pPreSharp = Prog(link(Shaders.VERT, Shaders.PRESHARP, "presharp"))
        pDeband = Prog(link(Shaders.VERT, Shaders.DEBAND, "deband"))
        pDeint = Prog(link(Shaders.VERT, Shaders.DEINT, "deint"))
        pTemporal = Prog(link(Shaders.VERT, Shaders.TEMPORAL, "temporal"))
        pTemporalMv = Prog(link(Shaders.VERT, Shaders.TEMPORAL_MOTION, "temporal_motion"))
        pEdgeRefine = Prog(link(Shaders.VERT, if (upOptApplied >= 2 && LITE_TEXEL_SHADERS) Shaders.EDGE_REFINE_L else Shaders.EDGE_REFINE, "edge_refine"))
        pCrscSharp = Prog(link(Shaders.VERT, Shaders.CRSC_SHARP, "crsc_sharp"))
        pCrscDown = Prog(link(Shaders.VERT, Shaders.CRSC_DOWN, "crsc_down"))
        pNis = Prog(link(Shaders.VERT, if (upOptApplied >= 2) Shaders.NIS_L else Shaders.NIS, "nis"))
        pNisOrig = Prog(link(Shaders.VERT, Shaders.NIS_ORIG, "nis_orig"))
        // a refused NIS mid / NIS fast shader must not break the whole pipeline: the original NIS (same uniforms) stands in
        pNisMid = null // NIS mid runs the NIS fast shader (3.89.20); the old separate shader is no longer built
        pNisFastLv[0] = runCatching { Prog(link(Shaders.VERT, Shaders.NIS_FAST, "nis_fast")) }.getOrNull() ?: pNisOrig
        for (k in 1 until pNisFastLv.size) pNisFastLv[k] = null
        gatherState = 0
        gatherChecked = false
        pLuma = null
        pLumaD = null
        pNisAuraG = null
        pNisFastG.fill(null)
        pNisSharp = runCatching { Prog(link(Shaders.VERT, Shaders.NIS_SHARP1, "nis_sharp1")) }.getOrNull()
        pClear = runCatching { Prog(link(Shaders.VERT, Shaders.CLEAR, "clear")) }.getOrNull()
        pArtUp = runCatching { Prog(link(Shaders.VERT, Shaders.ART_UP, "art_up")) }.getOrNull()
        pArtStyle = runCatching { Prog(link(Shaders.VERT, Shaders.ART_STYLE, "art_style")) }.getOrNull()
        pGameLight = runCatching { Prog(link(Shaders.VERT, Shaders.GAME_LIGHT, "gamelight")) }.getOrNull()
        pPixel = runCatching { Prog(link(Shaders.VERT, Shaders.PIXEL, "pixel")) }.getOrNull()
        pPixelPost = runCatching { Prog(link(Shaders.VERT, Shaders.PIXEL_POST, "pixelpost")) }.getOrNull()
        pPixelCrisp = runCatching { Prog(link(Shaders.VERT, Shaders.PIXEL_CRISP, "pixelcrisp")) }.getOrNull()
        pCrispFast = runCatching { Prog(link(Shaders.VERT, Shaders.NIS_CRISP_FAST, "nis_crisp_fast")) }.getOrNull()
        pEdgeShock = Prog(link(Shaders.VERT, if (upOptApplied >= 2 && LITE_TEXEL_SHADERS) Shaders.EDGE_SHOCK_L else Shaders.EDGE_SHOCK, "edge_shock"))
        pCrscBp = Prog(link(Shaders.VERT, if (upOptApplied >= 1) Shaders.CRSC_BP_L else Shaders.CRSC_BP, "crsc_bp"))
        pFgMotion = Prog(link(Shaders.VERT, Shaders.FG_MOTION, "fg_motion"))
        pFgInterp = Prog(link(Shaders.VERT, Shaders.FG_INTERP, "fg_interp"))

        val s = SurfaceTexture(oesTex)
        s.setDefaultBufferSize(capW, capH)
        s.setOnFrameAvailableListener({ draw() }, hd)
        st = s
        inSurface = Surface(s)
    }

    private fun draw() {
        try {
            drawInner()
        } finally {
            exportLatch?.countDown()
        }
    }

    private fun drawInner() {
        if (!alive) return
        val s = st ?: return
        try {
            s.updateTexImage()
        } catch (e: Exception) {
            return
        }
        s.getTransformMatrix(m)
        if (manualOnly) {
            // offscreen use (manga pages): only take the new frame; the result is rendered by snapshot()
            frameLatch?.countDown()
            return
        }
        val t0 = System.nanoTime()
        renderNow(true)
        val dt = (System.nanoTime() - t0) / 1_000_000f
        // moving average of the time one frame takes to submit (grows when the GPU cannot keep up): used by Auto
        avgDrawMs = if (avgDrawMs <= 0f) dt else avgDrawMs * 0.9f + dt * 0.1f
        if (!exportMode && !PassTimer.running) { Cfg.drawMs = avgDrawMs; Cfg.drawMsAt = android.os.SystemClock.elapsedRealtime() }
        if (smoothOn) govUpdate(dt) else if (gov != 0) govResetNow()
    }

    /** Settings the passes read: null = the live app settings ([Cfg]); a video export sets its own fixed set. */
    @Volatile var fx: FxView? = null
    private val f: FxView
        get() {
            val b = fx ?: LiveFx
            if (!smoothOn || gov == 0) return b
            var v = govView
            if (v == null || govBase !== b || govViewLvl != gov) {
                v = GovFx(b, gov)
                govView = v
                govBase = b
                govViewLvl = gov
            }
            return v
        }

    // ---- "Smooth live": when a frame takes longer than the video allows, the heaviest effects are lightened step by step (see [GovFx]) and come back when there is room again
    /** The player allows the governor (the overlay and the offline renderers never do); it is really on when the setting [Cfg.smoothLive] is on too. */
    @Volatile var govAllowed = false
    /** Milliseconds one frame may take (1000 / the video's frame rate). */
    @Volatile var frameBudgetMs = 33f
    /** Called on the GL thread when the level changes. */
    @Volatile var onGov: ((Int) -> Unit)? = null
    @Volatile private var gov = 0
    // not while "Measure speed" runs: its glFinish waits would look like lag, and the levels would change under the measurement
    private val smoothOn: Boolean get() = govAllowed && Cfg.smoothLive && !exportMode && !PassTimer.running
    private val govLv: Int get() = if (smoothOn) gov else 0
    private var govView: FxView? = null
    private var govBase: FxView? = null
    private var govViewLvl = -1
    private var govEma = 0f
    private var govN = 0
    private var govCool = 0
    private var govGood = 0
    private var govBackoff = 120
    private var govFrame = 0L
    private var govLoweredAt = -10_000L

    /** A new video (or a new setting): start from the full quality again. */
    fun govReset() {
        govResetReq = true
    }

    @Volatile private var govResetReq = false

    private fun govResetNow() {
        govEma = 0f
        govN = 0
        govCool = 0
        govGood = 0
        govBackoff = 120
        if (gov != 0) {
            gov = 0
            onGov?.invoke(0)
        }
    }

    /** The player saw dropped frames: lighten one step at once. */
    fun govBump() {
        if (smoothOn) govBumpReq = true // taken on the GL thread (the level must not change in the middle of a frame)
    }

    @Volatile private var govBumpReq = false

    private fun govStep(d: Int) {
        val n = (gov + d).coerceIn(0, 5)
        if (n == gov) return
        if (d > 0) {
            // raised soon after it was lowered: it was too early, wait longer next time
            if (govFrame - govLoweredAt < 300L) govBackoff = minOf(govBackoff * 2, 2400)
        } else govLoweredAt = govFrame
        gov = n
        govEma = 0f
        govN = 0
        govGood = 0
        govCool = if (d > 0) 20 else 30
        onGov?.invoke(n)
    }

    private fun govUpdate(dt: Float) {
        govFrame++
        if (govResetReq) {
            govResetReq = false
            govResetNow()
        }
        if (govBumpReq) {
            govBumpReq = false
            if (gov < 5 && govCool == 0) {
                govStep(+1)
                return
            }
        }
        val budget = frameBudgetMs.coerceIn(8f, 70f)
        govEma = if (govEma <= 0f) dt else govEma * 0.85f + dt * 0.15f
        govN++
        if (govCool > 0) {
            govCool--
            return
        }
        if (govN < 8) return
        if (govEma > budget * 0.92f && gov < 5) govStep(+1)
        else if (gov > 0 && govEma * 1.6f < budget * 0.85f) {
            // there seems to be room: one level back only after a long calm stretch (the heavier level costs about 1.6 times as much)
            govGood++
            if (govGood >= govBackoff) govStep(-1)
        } else govGood = 0
        if (gov == 0 && govBackoff > 120 && govFrame % 1500L == 0L) govBackoff = maxOf(120, govBackoff / 2)
    }

    /** Video export: the output surface is a MediaCodec encoder input; frames get the source timestamp and [exportLatch] is counted down after each one. */
    @Volatile var exportMode = false
    @Volatile var exportLatch: CountDownLatch? = null

    /** Set after a jump in the video: the next frame must not be blended / interpolated with the one before the jump. */
    @Volatile var resetHist = false
    /** Ask EGL for a config usable by a MediaCodec input surface (set before [start]). */
    @Volatile var recordable = false

    /** CRSC Edge level 5 (maximum) is only used when saving to a file: set by the offline renderers (batch). */
    @Volatile var allowMax = false

    /** True = never draw to the window; frames are only consumed and [snapshot] renders them (used by [MangaFx]). */
    @Volatile var manualOnly = false

    /** Counted down once the next input frame has been taken (manualOnly). */
    @Volatile var frameLatch: java.util.concurrent.CountDownLatch? = null

    /** true for the overlay service: its capture scale already is the render resolution, f.inRes / outRes do not apply. */
    @Volatile var fixedOut = false

    private var infoKey = 0L
    private fun noteInfo(sw: Int, sh: Int, cw: Int, ch: Int, mw: Int, mh: Int, ow: Int, oh: Int, w: Int, h: Int) {
        val key = ((((sw * 31L + sh) * 31 + cw) * 31 + ch) * 31 + ow * 7L + oh * 3L + w * 5L + h) * 31 + mw * 11L + mh * 13L
        if (key == infoKey) return
        infoKey = key
        Cfg.resInfo = if (mw > 0) "$sw×$sh  →  $cw×$ch  →  $mw×$mh  →  $ow×$oh  →  $w×$h" else "$sw×$sh  →  $cw×$ch  →  $ow×$oh  →  $w×$h"
    }

    /** > 0: the processing size is limited to this many times the output size (player only; 0 = off). */
    @Volatile var maxProcRatio = 0f

    /** Smoothed milliseconds per processed frame (0 = no frame yet). Reset it to 0 after changing settings. */
    @Volatile var avgDrawMs = 0f

    /** Live content analysis for Auto: while on, a 96x54 copy of the frame is passed to [onContent] (GL thread) about every 30 frames. */
    @Volatile var contentOn = false
    @Volatile var onContent: ((IntArray) -> Unit)? = null
    @Volatile private var contentFresh = true
    private var contentFrames = 0

    /** Measure the very next frame (a new video / photo was opened) and draw it again. */
    fun measureContentNow() {
        contentFresh = true
        redraw()
    }

    /** Re-renders the last frame with the current settings (paused video, still images, live setting changes). */
    fun redraw() {
        hd.post { if (alive && st != null && srf != EGL14.EGL_NO_SURFACE) renderNow() }
    }

    private fun present(tsNs: Long = st?.timestamp ?: 0L) {
        if (!snap && !capturing) {
            if (exportMode) EGLExt.eglPresentationTimeANDROID(dpy, srf, tsNs)
            EGL14.eglSwapBuffers(dpy, srf)
        }
    }

    /**
     * Renders the current picture with the current settings at [w] x [h] (whole image, no zoom) and returns it as a
     * Bitmap, or null on failure. Blocks the caller, so call it from a worker thread, never from the UI thread.
     */
    fun snapshot(w: Int, h: Int): Bitmap? {
        val latch = CountDownLatch(1)
        var result: Bitmap? = null
        val queued = hd.post {
            try {
                result = snapshotNow(w, h)
            } catch (t: Throwable) {
                Log.e(TAG, "snapshot failed", t)
            } finally {
                latch.countDown()
            }
        }
        if (!queued) return null
        latch.await(120, TimeUnit.SECONDS)
        return result
    }

    /**
     * The last captured frame exactly as the screen showed it (no effects), at capture size. Worker thread only.
     * Used by the AI still-frame tool: the AI should see the real pixels, not an already sharpened picture.
     */
    fun rawFrame(): Bitmap? {
        bypass = true
        try {
            return snapshot(capW, capH)
        } finally {
            bypass = false
            redraw()
        }
    }

    private fun snapshotNow(w: Int, h: Int): Bitmap? {
        if (!alive || st == null || w <= 0 || h <= 0) return null
        try {
            ensure(t7, w, h)
            snap = true
            outFbo = t7.fbo
            render(w, h)
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, t7.fbo)
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val band = 128
            val buf = ByteBuffer.allocateDirect(w * band * 4).order(ByteOrder.nativeOrder())
            val px = IntArray(w * band)
            var y = 0
            while (y < h) {
                val rows = minOf(band, h - y)
                buf.clear()
                GLES30.glReadPixels(0, y, w, rows, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, buf)
                buf.clear()
                buf.asIntBuffer().get(px, 0, w * rows)
                for (i in 0 until w * rows) {
                    val v = px[i]
                    // bytes R,G,B,A read as a little-endian int = ABGR; Bitmap wants ARGB. OpenGL rows run bottom-up.
                    px[i] = (v and 0xFF00FF00.toInt()) or ((v and 0xFF) shl 16) or ((v shr 16) and 0xFF) or 0xFF000000.toInt()
                }
                for (r in 0 until rows) bmp.setPixels(px, r * w, w, 0, h - 1 - (y + r), w, 1)
                y += rows
            }
            return bmp
        } finally {
            snap = false
            outFbo = 0
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
            free(t7)
            if (!manualOnly) renderNow() // offscreen users (manga pages, GIF frames) never show the window: no wasted full render after each one
        }
    }

    private fun renderNow(newFrame: Boolean = false) {
        tmpNew = newFrame
        EGL14.eglQuerySurface(dpy, srf, EGL14.EGL_WIDTH, sz, 0)
        val w = sz[0]
        EGL14.eglQuerySurface(dpy, srf, EGL14.EGL_HEIGHT, sz, 0)
        val h = sz[0]
        if (w <= 0 || h <= 0) return
        try {
            if (PassTimer.running) PassTimer.context(w, h, if (govAllowed) frameBudgetMs else 0f)
            PassTimer.begin()
            if (frameGen && govLv < 1 && !snap && !bypass) renderFg(w, h, newFrame) else render(w, h)
            PassTimer.end()
        } catch (t: Throwable) {
            capturing = false
            outFbo = 0
            if (!failed) {
                failed = true
                Log.e(TAG, "render failed", t)
                onError?.invoke(t.message ?: "render error")
            }
        }
    }

    /** Renders the frame into a texture, builds the in-between picture from the previous frame and shows both. */
    private fun renderFg(w: Int, h: Int, newFrame: Boolean) {
        var havePrev = false
        if (resetHist) {
            resetHist = false
            fgHave = false
            thCur = null
        }
        if (newFrame) {
            if (fgHave) {
                fgPrevRt = fgCurRt
                fgCurRt = if (fgCurRt === fgA) fgB else fgA
                havePrev = true
            }
            fgHave = true
        }
        val cur = fgCurRt
        ensure(cur, w, h)
        if (newFrame) {
            fgNo++
            if (cur === fgA) fgANo = fgNo else fgBNo = fgNo
        }
        capturing = true
        outFbo = cur.fbo
        try {
            render(w, h)
        } finally {
            capturing = false
            outFbo = 0
        }
        val prev = fgPrevRt
        val ts = st?.timestamp ?: 0L
        val now = System.nanoTime()
        if (newFrame) {
            if (fgLastNs != 0L) fgInterval = ((fgInterval * 3 + (now - fgLastNs).coerceIn(8_000_000L, 120_000_000L)) / 4)
            fgLastNs = now
        }
        if (havePrev && prev != null && prev.w == w && prev.h == h) {
            // the search runs on small copies when the picture is big
            val searchW = if (fgQuality == 3) FG_SEARCH_W / 2 else FG_SEARCH_W
            val sc = if (w > searchW) searchW.toFloat() / w else 1f
            val sw = maxOf(16, (w * sc).toInt())
            val sh = maxOf(16, (h * sc).toInt())
            var mp = prev
            var mc = cur
            if (sc < 1f) {
                val curIsA = cur === fgA
                val sCur = if (curIsA) fgSA else fgSB
                val sPrev = if (curIsA) fgSB else fgSA
                val curNo = if (curIsA) fgANo else fgBNo
                val prevNo = if (curIsA) fgBNo else fgANo
                if (fgSA.w != sw || fgSA.h != sh) fgSANo = 0L // a new size: the old copies are gone
                if (fgSB.w != sw || fgSB.h != sh) fgSBNo = 0L
                val sCurNo = if (curIsA) fgSANo else fgSBNo
                val sPrevNo = if (curIsA) fgSBNo else fgSANo
                ensure(sCur, sw, sh)
                ensure(sPrev, sw, sh)
                // a small copy is made only when it does not already hold that frame
                if (sCurNo != curNo) {
                    bindOut(sCur, sw, sh)
                    downscale(cur, sw, sh)
                    if (curIsA) fgSANo = curNo else fgSBNo = curNo
                }
                if (sPrevNo != prevNo) {
                    bindOut(sPrev, sw, sh)
                    downscale(prev, sw, sh)
                    if (curIsA) fgSBNo = prevNo else fgSANo = prevNo
                }
                mp = sPrev
                mc = sCur
            }
            fgMvScale = if (sc < 1f) w.toFloat() / sw else 1f
            val blkFull = if (fgQuality == 2) 8 else 16
            val blk = if (sc < 1f) (blkFull * sc).toInt().coerceAtLeast(if (fgQuality == 3) 8 else 4) else blkFull
            val gw = maxOf(1, sw / blk)
            val gh = maxOf(1, sh / blk)
            ensure(fgMv, gw, gh)
            bindOut(fgMv, gw, gh)
            GLES30.glUseProgram(pFgMotion.id)
            bindTex(0, mp)
            bindTex(1, mc)
            GLES30.glUniform1i(pFgMotion.u("uPrev"), 0)
            GLES30.glUniform1i(pFgMotion.u("uCur"), 1)
            GLES30.glUniform2f(pFgMotion.u("uInv"), 1f / sw, 1f / sh)
            // light mode: a quarter of the search work (coarser steps, same reach)
            // light / very light: log search (36 matches per block, reach 15 px of the small picture, 1 px precision) instead of a flat grid:
            // the flat grid could only follow about 4 px of motion, so fast motion was not found and the result looked like a plain blend
            val logSearch = fgQuality == 0 || fgQuality == 3
            GLES30.glUniform1f(pFgMotion.u("uStep"), if (logSearch) 8f else (4f).let { if (sc < 1f) maxOf(1f, it * sc) else it })
            GLES30.glUniform1i(pFgMotion.u("uRange"), 4)
            GLES30.glUniform1f(pFgMotion.u("uBlock"), blk.toFloat())
            GLES30.glUniform1i(pFgMotion.u("uRefine"), if (logSearch) 2 else 1)
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)

            val n = frameGenN.coerceIn(2, 4)
            val prevTs = fgPrevTs
            val seq = ++fgSeq
            drawMid(prev, cur, w, h, 1f / n, if (exportMode && prevTs > 0L && prevTs < ts) prevTs + (ts - prevTs) / n else ts)
            if (exportMode) {
                for (k in 2 until n) drawMid(prev, cur, w, h, k.toFloat() / n, if (prevTs > 0L && prevTs < ts) prevTs + (ts - prevTs) * k / n else ts)
                blitFg(cur, w, h, ts)
            } else {
                // live: the other in-between frames and the new frame follow, one step of (interval / n) apart
                val step = fgInterval / n / 1_000_000L
                val spent = (System.nanoTime() - now) / 1_000_000L
                for (k in 2 until n) {
                    val wait = ((k - 1) * step - spent).coerceIn(0L, 90L)
                    hd.postDelayed({ if (alive && seq == fgSeq && st != null) drawMid(prev, cur, w, h, k.toFloat() / n, ts) }, wait)
                }
                val wait = ((n - 1) * step - spent).coerceIn(0L, 90L)
                hd.postDelayed({ if (alive && seq == fgSeq && st != null) blitFg(cur, w, h, ts) }, wait)
            }
            fgPrevTs = ts
        } else {
            fgSeq++
            fgPrevTs = ts
            blitFg(cur, w, h, ts)
        }
    }

    private var fgPrevTs = 0L

    /** The picture at position [t] (0..1) between [prev] and [cur], from the motion in [fgMv]. */
    private fun drawMid(prev: Rt, cur: Rt, w: Int, h: Int, t: Float, ts: Long) {
        if (prev.tex == 0 || cur.tex == 0 || fgMv.tex == 0 || srf == EGL14.EGL_NO_SURFACE) return
        bindOut(null, w, h)
        GLES30.glUseProgram(pFgInterp.id)
        bindTex(0, prev)
        bindTex(1, cur)
        bindTex(2, fgMv)
        GLES30.glUniform1i(pFgInterp.u("uPrev"), 0)
        GLES30.glUniform1i(pFgInterp.u("uCur"), 1)
        GLES30.glUniform1i(pFgInterp.u("uMv"), 2)
        GLES30.glUniform2f(pFgInterp.u("uInv"), 1f / w, 1f / h)
        GLES30.glUniform1f(pFgInterp.u("uT"), t)
        GLES30.glUniform1f(pFgInterp.u("uMvScale"), fgMvScale)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        present(ts)
    }

    private fun blitFg(src: Rt, w: Int, h: Int, ts: Long) {
        if (src.tex == 0 || srf == EGL14.EGL_NO_SURFACE) return
        bindOut(null, w, h)
        bilinear(src, w, h)
        present(ts)
    }

    /** Temporal clean-up at the size of the source frame. Returns the Rt that holds the result. */
    private fun temporalStage(src: Rt): Rt {
        val w = src.w
        val h = src.h
        if (resetHist) {
            resetHist = false
            thCur = null
            fgHave = false
        }
        val prev = thCur
        if (!tmpNew) {
            // the same frame drawn again (a setting changed): keep the result that was already made
            return if (prev != null && prev.w == w && prev.h == h) prev else src
        }
        val out = if (prev === thA) thB else thA
        ensure(out, w, h)
        if (prev == null || prev.w != w || prev.h != h) {
            bindOut(out, w, h)
            bilinear(src, w, h)
            thCur = out
            return out
        }
        val blk = 16
        val gw = maxOf(1, w / blk)
        val gh = maxOf(1, h / blk)
        ensure(tMv, gw, gh)
        bindOut(tMv, gw, gh)
        GLES30.glUseProgram(pTemporalMv.id)
        bindTex(0, prev)
        bindTex(1, src)
        GLES30.glUniform1i(pTemporalMv.u("uPrev"), 0)
        GLES30.glUniform1i(pTemporalMv.u("uCur"), 1)
        GLES30.glUniform2f(pTemporalMv.u("uInv"), 1f / w, 1f / h)
        GLES30.glUniform1f(pTemporalMv.u("uStep"), 8f)
        GLES30.glUniform1f(pTemporalMv.u("uBlock"), blk.toFloat())
        GLES30.glUniform1i(pTemporalMv.u("uRounds"), 5)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)

        bindOut(out, w, h)
        GLES30.glUseProgram(pTemporal.id)
        bindTex(0, src)
        bindTex(1, prev)
        bindTex(2, tMv)
        GLES30.glUniform1i(pTemporal.u("uCur"), 0)
        GLES30.glUniform1i(pTemporal.u("uHist"), 1)
        GLES30.glUniform1i(pTemporal.u("uMv"), 2)
        GLES30.glUniform2f(pTemporal.u("uInv"), 1f / w, 1f / h)
        // 3.96.5: new motion search (half-pixel), sharp (Catmull-Rom) sampling of the old picture, neighbourhood clipping and a gate for fades and
        // cuts. Offline test (noisy / compressed video: still, slow and fast pan, a moving object, a cut, shaking, zoom, rotation, a fast object, a
        // fade; PSNR against the clean frame, mean over 20 cases): old Light +0.9 dB, old Strong +0.8 dB, new Light +1.6 dB, new Strong +1.9 dB;
        // the worst single case is +0.4 dB or better for both new levels.
        // 3.99.31: Strong widened (it was too close to Light to see): blend weight 0.9 -> 0.93 (about 14 frames of memory instead of 10), tolerance 0.24 -> 0.30, still-area smoothing 0.3 -> 0.5, motion back-off 0.2 -> 0.15, luma tolerance 0.08 -> 0.10
        val strong = temporal >= 2
        GLES30.glUniform1f(pTemporal.u("uAmt"), if (strong) 0.93f else 0.8f)
        GLES30.glUniform1f(pTemporal.u("uTol"), if (strong) 0.30f else 0.18f)
        GLES30.glUniform1f(pTemporal.u("uSp"), if (strong) 0.5f else 0.1f)
        GLES30.glUniform1f(pTemporal.u("uMot"), if (strong) 0.15f else 0.35f)
        GLES30.glUniform1f(pTemporal.u("uClip"), 1.5f)
        GLES30.glUniform1f(pTemporal.u("uSig"), 0.03f)
        GLES30.glUniform1f(pTemporal.u("uTolL"), if (strong) 0.10f else 0.07f)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        thCur = out
        return out
    }

    private fun aiStage(src: Rt, hook: (Bitmap) -> Bitmap?): Rt? {
        val w = src.w
        val h = src.h
        if (w <= 0 || h <= 0) return null
        val buf = ByteBuffer.allocateDirect(w * h * 4).order(ByteOrder.nativeOrder())
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, src.fbo)
        GLES30.glReadPixels(0, 0, w, h, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, buf)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        buf.rewind()
        bmp.copyPixelsFromBuffer(buf)
        val res = try { hook(bmp) } finally { bmp.recycle() }
        val out = res ?: return null
        try {
            ensure(tAi, out.width, out.height)
            GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tAi.tex)
            android.opengl.GLUtils.texSubImage2D(GLES30.GL_TEXTURE_2D, 0, 0, 0, out)
        } finally {
            out.recycle()
        }
        return tAi
    }

    private fun bindTex(unit: Int, rt: Rt) {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + unit)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, rt.tex)
    }

    private fun render(w: Int, h: Int) {
        applyUpOpt()
        val mode = f.mode
        val boost = f.boost
        val fixOn = f.smartFix && !byp0() // Smart fix: measured from the frame itself
        val vivid = f.vivid > 0f || f.contrast != 0f || toneOn() || fixOn || (f.cleanUp && !byp0()) // "colour pass": vivid colours, contrast and / or Smart fix
        val detail = f.detail > 0f || f.clarity != 0f || f.antiRing > 0f || lightOn()
        rcasK = 1f // every frame starts with the normal RCAS strength (CRSC Edge lowers it itself)
        // Clean upscale: the anti-aliasing runs after the upscale (denoise -> sharpen -> upscale -> anti-aliasing -> colour). Raw has no upscale, so it keeps AA before.
        val aaSel = if (f.aaMode != Cfg.AA_OFF) f.aaMode else if (f.cleanUp) Cfg.AA_FXAA_QUALITY else Cfg.AA_OFF
        postAa = if (f.cleanUp && mode != Cfg.MODE_RAW && !byp0()) aaSel else Cfg.AA_OFF
        val post = vivid || detail || postAa != Cfg.AA_OFF
        // "Fine pixels" (its own option, on top of any upscaler): the last spatial step. Raw already is square blocks of source pixels; the old
        // Fine-pixels upscaler (export only) makes its own blocks; Smooth live drops it when the phone cannot keep up; a file export never uses the live switch (it has the Fine pixels upscaler choice instead).
        val fine = Cfg.finePixels && govLv < 2 && !exportMode && mode != Cfg.MODE_RAW && mode != Cfg.MODE_PIXEL && !byp0()
        val byp = bypass
        // Output size chain (player / photo): f.outRes = short side of the size everything is rendered at
        val outShort = f.outRes
        val customOut = !snap && !byp && mode != Cfg.MODE_RAW && outShort > 0 && !fixedOut
        var ow = if (customOut) maxOf(2, Math.round(w * outShort.toFloat() / minOf(w, h))) else w
        var oh = if (customOut) maxOf(2, Math.round(h * outShort.toFloat() / minOf(w, h))) else h
        if (customOut && maxOf(ow, oh) > 8192) { val k = 8192f / maxOf(ow, oh); ow = maxOf(2, Math.round(ow * k)); oh = maxOf(2, Math.round(oh * k)) } // one factor: the shape stays
        // "Sharpen only" renders at the screen size and never changes the picture size, except when the person chose an Input / Middle size:
        // then those steps (shrink) run, and the picture is brought back up to the screen with a bicubic filter below
        val chainOn = !snap && !byp && !fixedOut && (f.inRes > 0 || f.midRes > 0)
        val sharpOnly = mode == Cfg.MODE_SHARP && !customOut && !chainOn
        val z = if (snap) 1f else zoom.coerceAtLeast(1f)
        val bl = if (snap) 0f else barL.coerceIn(0f, 0.45f)
        val bb = if (snap) 0f else barB.coerceIn(0f, 0.45f)
        val bwf = 1f - bl - (if (snap) 0f else barR.coerceIn(0f, 0.45f))
        val bhf = 1f - bb - (if (snap) 0f else barT.coerceIn(0f, 0.45f))
        val zwx = if (z > 1f) zoomWX.coerceIn(0.001f, 1f) else 1f
        val zwy = if (z > 1f) zoomWY.coerceIn(0.001f, 1f) else 1f
        val barred = bwf < 0.999f || bhf < 0.999f
        var sw = if (z > 1f || barred) maxOf(2, (capW * zwx * bwf).toInt()) else capW
        var sh = if (z > 1f || barred) maxOf(2, (capH * zwy * bhf).toInt()) else capH
        if (maxProcRatio > 0f && !snap && !byp) {
            // the source is much bigger than the output (e.g. 4K video on a 1080p screen): work at most
            // maxProcRatio x the output size instead of at the full source size (several times cheaper)
            val k = minOf(1f, w * maxProcRatio / sw, h * maxProcRatio / sh)
            if (k < 1f) {
                sw = maxOf(2, (sw * k).toInt())
                sh = maxOf(2, (sh * k).toInt())
            }
        }
        val cropX = (zoomX - 0.5f * zwx).coerceIn(0f, 1f - zwx)
        val cropY = (zoomY - 0.5f * zwy).coerceIn(0f, 1f - zwy)
        var cw = if (byp) sw else if (sharpOnly) maxOf(w, sw) else sw
        var ch = if (byp) sh else if (sharpOnly) maxOf(h, sh) else sh
        // Input step: the source is said to be really only this big. The copy is made at full size and then shrunk with a proper
        // filter (halving steps + 4 taps), so the result is clean, not the aliased result of one single-tap bilinear read.
        var iw = 0
        var ih = 0
        if (!snap && !byp && f.inRes > 0 && !fixedOut && !sharpOnly) {
            val ms0 = minOf(cw, ch)
            if (f.inRes < ms0) {
                val k = f.inRes.toFloat() / ms0
                iw = maxOf(2, Math.round(cw * k))
                ih = maxOf(2, Math.round(ch * k))
            }
        }
        val workW = if (iw > 0) iw else cw
        val workH = if (iw > 0) ih else ch
        // Middle step: the cleaned picture is brought to this short side. Smaller than the work size = shrunk (clean anti-aliasing);
        // bigger = made bigger with the chosen upscaler (then the Output step goes down or up from there)
        val midShort = f.midRes
        var mw = 0
        var mh = 0
        var midUp = false
        if (midShort > 0 && !byp && !fixedOut && mode != Cfg.MODE_RAW && !sharpOnly) {
            val ms = minOf(workW, workH)
            if (midShort != ms) {
                var k = midShort.toFloat() / ms
                val longSide = maxOf(workW, workH) * k
                if (longSide > 8192f) k *= 8192f / longSide // one factor for both sides: the shape of the picture stays
                mw = maxOf(2, Math.round(workW * k)).coerceAtMost(8192)
                mh = maxOf(2, Math.round(workH * k)).coerceAtMost(8192)
                midUp = midShort > ms
                if (midUp && (mw <= workW || mh <= workH)) { mw = 0; mh = 0; midUp = false } // the 8192 limit left nothing to do
            }
        }
        if (!snap && fx == null) noteInfo(capW, capH, workW, workH, mw, mh, ow, oh, w, h)

        // 0) external texture -> plain RGBA texture (capture size)
        ensure(t0, cw, ch)
        bindOutD(t0, cw, ch)
        GLES30.glUseProgram(pCopy.id)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTex)
        GLES30.glUniform1i(pCopy.u("uSrc"), 0)
        GLES30.glUniformMatrix4fv(pCopy.u("uTexMatrix"), 1, false, m, 0)
        GLES30.glUniform4f(pCopy.u("uCrop"), bl + cropX * bwf, bb + cropY * bhf, zwx * bwf, zwy * bhf)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
        PassTimer.mark("capture: copy of the frame")
        if (!snap && fx == null) {
            if (Cfg.autoCrop) {
                barResetSent = false
                detectBars(m)
            } else if (barL + barB + barR + barT > 0f && !barResetSent) {
                barResetSent = true // switched off while bars are cut: the player puts the whole frame back
                onBars?.invoke(FloatArray(4))
            }
        }

        if (fixOn) {
            if (!fixWasOn) fixFresh = true // just switched on: measure this very frame
            fixWasOn = true
            smartFixMeasure(w0 = cw, h0 = ch)
        } else fixWasOn = false

        // Auto (player): now and then a tiny copy of the frame is handed to [onContent], which says what kind of picture it is
        if (contentOn && !snap && fx == null) {
            contentFrames++
            if (contentFresh || contentFrames % 30 == 0) {
                contentFresh = false
                ensure(tFix, 96, 54)
                bindOut(tFix, 96, 54)
                bilinear(t0, 96, 54)
                fixBuf.clear()
                GLES30.glReadPixels(0, 0, 96, 54, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, fixBuf)
                val cpx = IntArray(96 * 54)
                fixBuf.rewind()
                for (i in cpx.indices) {
                    val r = fixBuf.get().toInt() and 0xFF
                    val g = fixBuf.get().toInt() and 0xFF
                    val b = fixBuf.get().toInt() and 0xFF
                    fixBuf.get()
                    cpx[i] = (r shl 16) or (g shl 8) or b
                }
                onContent?.invoke(cpx)
            }
        }

        // Effects off: just show the copied frame, scaled by the GPU's own bilinear filter.
        if (byp) {
            bindOut(null, w, h)
            bilinear(t0, w, h)
            present()
            return
        }

        // 0b) optional anti-aliasing at capture size; everything after reads from [base]
        // Cleanup stages run in this order, each reading the previous result (t4 / t6 ping-pong):
        // denoise / deblock -> deband -> anti-aliasing. All happen before upscaling and sharpening,
        // so sharpening never amplifies compression noise.
        var base = t0
        if (iw > 0) {
            ensure(inRt, iw, ih)
            shrink(t0, iw, ih, inRt)
            base = inRt
            cw = iw
            ch = ih
        }
        cleanKNow = cleanK(ch)
        if (f.deint > 0) {
            val dst = if (base === t4) t6 else t4
            ensure(dst, cw, ch)
            bindOutD(dst, cw, ch)
            deintPass(base)
            base = dst
        }
        val clean = f.cleanUp
        if (f.denoise > 0f || clean) {
            val dst = if (base === t4) t6 else t4
            ensure(dst, cw, ch)
            bindOutD(dst, cw, ch)
            denoisePass(base)
            base = dst
        }
        val chroma = chromaAmt()
        if (chroma > 0f) {
            // Colour clean-up: only the colour is smoothed (brightness, and so the detail, is kept)
            val dst = if (base === t4) t6 else t4
            ensure(dst, cw, ch)
            bindOutD(dst, cw, ch)
            chromaPass(base, (chroma * cleanKNow).coerceIn(0f, 1f))
            base = dst
        }
        if (clean) {
            // Clean upscale: sharpen the denoised picture (the anti-aliasing comes after the upscale)
            val dst = if (base === t4) t6 else t4
            ensure(dst, cw, ch)
            bindOutD(dst, cw, ch)
            preSharpPass(base)
            base = dst
        }
        if (f.deband > 0f) {
            val dst = if (base === t4) t6 else t4
            ensure(dst, cw, ch)
            bindOutD(dst, cw, ch)
            debandPass(base)
            base = dst
        }
        val aa = if (postAa != Cfg.AA_OFF) Cfg.AA_OFF else aaSel
        if (aa != Cfg.AA_OFF) {
            val dst = if (base === t4) t6 else t4
            ensure(dst, cw, ch)
            bindOutD(dst, cw, ch)
            antiAlias(base, aa)
            base = dst
        }
        PassTimer.mark("clean-up (de-interlace / denoise / deband / anti-aliasing)")

        // 0b2) temporal clean-up: the previous result, moved along the motion, is blended into this frame
        // (before every output path below, so Raw and the chosen-output-size path get it too)
        if (temporal > 0 && govLv < 1 && !snap) base = temporalStage(base)

        // 0b3) middle step: shrink the cleaned picture (4-tap filter = clean anti-aliasing); everything below works from the small one
        if (mw > 0) {
            ensure(midRt, mw, mh)
            if (!midUp) {
                shrink(base, mw, mh, midRt)
            } else if (mode == Cfg.MODE_LANCZOS) {
                // CRSC Edge makes its own targets: its result is copied 1:1 into the middle target (so no later pass reads what it draws into)
                val up = crscEdge(base, mw, mh, noCrisp = true)
                ensure(midRt, mw, mh)
                bindOutD(midRt, mw, mh)
                bilinear(up, mw, mh)
            } else {
                // the chosen upscaler (no sharpening here: the final stage sharpens)
                bindOutD(midRt, mw, mh)
                when (mode) {
                    Cfg.MODE_FSR -> easu(base, mw, mh)
                    Cfg.MODE_SGSR -> sgsr(base)
                    Cfg.MODE_CLEAR -> clearUp(base, mw, mh)
                    Cfg.MODE_ART -> artUp(base, midRt, tArtMid, mw, mh)
                    Cfg.MODE_PIXEL -> pixelUp(base, mw, mh)
                    Cfg.MODE_NIS, Cfg.MODE_NIS_ORIG, Cfg.MODE_NIS_SOFT, Cfg.MODE_NIS_FAST, Cfg.MODE_NIS_FINE, Cfg.MODE_NIS_MID -> nis(base)
                    Cfg.MODE_SHARP -> bicubic(base)
                    else -> bilinear(base, mw, mh)
                }
            }
            base = midRt
            cw = mw
            ch = mh
        }

        // Raw: show the captured frame as-is (nearest-neighbour), no upscale filter and no sharpening.
        if (mode == Cfg.MODE_RAW) {
            if (vivid) {
                ensure(t1, w, h)
                bindOutD(t1, w, h)
                nearest(base)
                bindOut(null, w, h)
                colorEnhance(t1)
            } else {
                bindOut(null, w, h)
                nearest(base)
            }
            present()
            return
        }

        // Chosen output size (f.outRes): upscale (or downscale) to exactly that size, then show it on the screen.
        if (customOut) {
            val passes = if (boost) 2 else 1
            var cur: Rt
            if (cw > ow || ch > oh) {
                // DOWNSCALE: sharpen at the source size, then shrink to the output size (the shrink is an anti-aliasing filter)
                var big = base
                var n = 0
                while (n < passes) {
                    val d = if (big === t1) t2 else t1
                    ensure(d, cw, ch)
                    bindOutD(d, cw, ch)
                    rcas(big, boost && n == passes - 1)
                    big = d
                    n++
                }
                ensure(t3, ow, oh)
                bindOutD(t3, ow, oh)
                downscale(big, ow, oh)
                cur = t3
            } else {
                // UPSCALE to the output size with the chosen method, then sharpen there
                if (mode == Cfg.MODE_LANCZOS) {
                    cur = crscEdge(base, ow, oh)
                } else {
                    ensure(t1, ow, oh)
                    bindOutD(t1, ow, oh)
                    when (mode) {
                        Cfg.MODE_FSR -> easu(base, ow, oh)
                        Cfg.MODE_SGSR -> sgsr(base)
                        Cfg.MODE_CLEAR -> clearUp(base, ow, oh)
                        Cfg.MODE_ART -> artUp(base, t1, tArtOut, ow, oh)
                        Cfg.MODE_PIXEL -> pixelUp(base, ow, oh)
                        Cfg.MODE_NIS, Cfg.MODE_NIS_ORIG, Cfg.MODE_NIS_SOFT, Cfg.MODE_NIS_FAST, Cfg.MODE_NIS_FINE, Cfg.MODE_NIS_MID -> nis(base)
                        Cfg.MODE_SHARP -> bicubic(base)
                        else -> bilinear(base, ow, oh)
                    }
                    cur = t1
                }
                if (Cfg.crscNis > 0 && govLv < 2 && mode != Cfg.MODE_LANCZOS && mode != Cfg.MODE_CLEAR && mode != Cfg.MODE_ART && mode != Cfg.MODE_PIXEL) {
                    cur = nisCrisp(cur, ow, oh, (ow.toFloat() / base.w).coerceIn(1f, 4f), false)
                    rcasK = 0.6f
                }
                val rp = if (mode == Cfg.MODE_PIXEL) 0 else if (mode == Cfg.MODE_ART) (if (boost) 1 else 0) else if (mode == Cfg.MODE_SGSR || mode == Cfg.MODE_NIS || mode == Cfg.MODE_NIS_ORIG || mode == Cfg.MODE_NIS_SOFT || mode == Cfg.MODE_NIS_FAST || mode == Cfg.MODE_NIS_FINE || mode == Cfg.MODE_NIS_MID) (if (boost) 1 else 0) else passes
                var n = 0
                while (n < rp) {
                    val d = if (cur === t1) t2 else t1
                    ensure(d, ow, oh)
                    bindOutD(d, ow, oh)
                    rcas(cur, boost && n == rp - 1)
                    cur = d
                    n++
                }
            }
            if (postAa != Cfg.AA_OFF) {
                val d = if (cur === t1) t2 else t1
                ensure(d, ow, oh)
                bindOutD(d, ow, oh)
                antiAlias(cur, postAa)
                cur = d
            }
            if (detail) {
                val d = if (cur === t1) t2 else t1
                ensure(d, ow, oh)
                bindOutD(d, ow, oh)
                detailPass(cur)
                cur = d
            }
            if (vivid) {
                val d = if (cur === t1) t2 else t1
                ensure(d, ow, oh)
                bindOutD(d, ow, oh)
                colorEnhance(cur)
                cur = d
            }
            if (fine) {
                val cwF = fineCells(base.w, ow)
                val chF = fineCells(base.h, oh)
                val small = pixelPre(cur, cwF, chF)
                val d = if (cur === t1) t2 else t1
                ensure(d, ow, oh)
                bindOutD(d, ow, oh)
                pixelPost(cur, cwF, chF, small)
                cur = d
            }
            bindOut(null, w, h)
            if (ow > w || oh > h) downscale(cur, w, h) else bilinear(cur, w, h)
            present()
            return
        }

        // Supersampling: the render scale is above the panel size, so there is nothing to upscale.
        // Sharpen at the big size, then shrink back to the panel with a 4-tap filter.
        if (cw > w || ch > h) {
            var big = base
            var n = 0
            val passes = if (boost) 2 else 1
            while (n < passes) {
                val dstBig = if (big === t1) t2 else t1
                ensure(dstBig, cw, ch)
                bindOutD(dstBig, cw, ch)
                rcas(big, boost && n == passes - 1)
                big = dstBig
                n++
            }
            if (post) {
                ensure(t3, w, h)
                bindOutD(t3, w, h)
            } else {
                bindOut(null, w, h)
            }
            downscale(big, w, h)
            if (post) finishPost(t3, t5, w, h, detail, vivid)
            present()
            return
        }

        // 0c) AI model (video export only): the cleaned frame is made bigger by the model; FSR / Lanczos / sharpening carry on from it
        var aiBig = false
        val hook = aiHook
        if (hook != null && !snap && !byp) {
            val ai = aiStage(base, hook)
            if (ai != null) {
                base = ai
                aiBig = ai.w > w || ai.h > h
            }
        }

        // 1) upscale stage
        val postM = post || fine // the offscreen route is also needed when only Fine pixels runs after the upscale
        var cur = base
        var rcasPasses: Int
        rcasK = 1f
        // NIS crispness for every upscaler except CRSC Edge (which runs it inside its own pipeline)
        val crispOn = Cfg.crscNis > 0 && govLv < 2 && mode != Cfg.MODE_LANCZOS && mode != Cfg.MODE_CLEAR && mode != Cfg.MODE_ART && mode != Cfg.MODE_PIXEL && mode != Cfg.MODE_RAW
        when (if (aiBig) Cfg.MODE_FAST else mode) {
            Cfg.MODE_FSR -> {
                ensure(t1, w, h)
                bindOutD(t1, w, h)
                easu(base, w, h)
                cur = t1
                rcasPasses = if (boost) 2 else 1
            }
            Cfg.MODE_SGSR -> {
                if (boost || postM || crispOn) {
                    // Need an offscreen target either to feed a second RCAS pass or the Detail / Vivid pass.
                    ensure(t1, w, h)
                    bindOutD(t1, w, h)
                    sgsr(base)
                    cur = t1
                    rcasPasses = if (boost) 1 else 0
                } else {
                    bindOut(null, w, h)
                    sgsr(base)
                    rcasPasses = 0
                }
            }
            Cfg.MODE_NIS, Cfg.MODE_NIS_ORIG, Cfg.MODE_NIS_SOFT, Cfg.MODE_NIS_FAST, Cfg.MODE_NIS_FINE, Cfg.MODE_NIS_MID -> {
                if (boost || postM || crispOn) {
                    ensure(t1, w, h)
                    bindOutD(t1, w, h)
                    nis(base)
                    cur = t1
                    rcasPasses = if (boost) 1 else 0
                } else {
                    bindOut(null, w, h)
                    nis(base)
                    rcasPasses = 0
                }
            }
            Cfg.MODE_LANCZOS -> {
                cur = crscEdge(base, w, h)
                rcasPasses = if (boost) 2 else 1
            }
            Cfg.MODE_CLEAR -> {
                ensure(t1, w, h)
                bindOutD(t1, w, h)
                clearUp(base, w, h)
                cur = t1
                rcasPasses = if (boost) 2 else 1
            }
            Cfg.MODE_ART -> {
                ensure(t1, w, h)
                bindOutD(t1, w, h)
                artUp(base, t1, tArt, w, h)
                cur = t1
                rcasPasses = if (boost) 1 else 0 // the finishing pass already sharpens; a second RCAS only on "boost"
            }
            Cfg.MODE_PIXEL -> {
                ensure(t1, w, h)
                bindOutD(t1, w, h)
                pixelUp(base, w, h)
                cur = t1
                rcasPasses = 0 // sharpening would only put halos around the blocks
            }
            Cfg.MODE_FAST -> {
                ensure(t1, w, h)
                bindOutD(t1, w, h)
                bilinear(base, w, h)
                cur = t1
                rcasPasses = if (boost) 2 else 1
            }
            Cfg.MODE_SHARP -> {
                if (base.w < w || base.h < h) { // an Input / Middle size made the picture smaller than the screen: bring it back up first
                    ensure(t1, w, h)
                    bindOutD(t1, w, h)
                    bicubic(base)
                    cur = t1
                }
                rcasPasses = if (boost) 2 else 1
            }
            else -> rcasPasses = if (boost) 2 else 1
        }

        if (crispOn) {
            cur = nisCrisp(cur, w, h, (w.toFloat() / base.w).coerceIn(1f, 4f), rcasPasses == 0 && !postM)
            rcasK = 0.6f // the picture is already sharpened: the final RCAS is lighter
        }

        // 2) sharpening passes. The last one goes straight to the screen, unless a Vivid colors
        // pass still needs to run after it, in which case it goes to an offscreen target instead.
        var i = 0
        while (i < rcasPasses) {
            val last = i == rcasPasses - 1
            val dst: Rt? = if (last && !postM) null else (if (cur === t1) t2 else t1)
            if (dst != null) ensure(dst, w, h)
            bindOutD(dst, w, h)
            rcas(cur, boost && i == rcasPasses - 1)
            if (dst != null) cur = dst
            i++
        }
        if (rcasPasses > 0) PassTimer.mark("sharpen (RCAS, " + rcasPasses + " pass)")

        // 3) optional Detail / deblur, then optional color enhance (always last)
        if (postM) finishPost(cur, if (cur === t1) t2 else t1, w, h, detail, vivid, fine, fineCells(base.w, w), fineCells(base.h, h))
        present()
        PassTimer.mark("show (bars, overlay, present)")
    }

    /** Runs Detail (if on) then Vivid (if on) from [src]; the final pass goes to the screen. [spare] is the
     *  offscreen target used between the two passes. */
    private fun finishPost(src: Rt, spare: Rt, w: Int, h: Int, detail: Boolean, vivid: Boolean, fine: Boolean = false, cellsW: Int = 0, cellsH: Int = 0) {
        var cur = src
        var other = spare
        val aaM = postAa
        if (aaM != Cfg.AA_OFF) {
            val dst: Rt? = if (detail || vivid || fine) other else null
            if (dst != null) ensure(dst, w, h)
            bindOutD(dst, w, h)
            antiAlias(cur, aaM)
            PassTimer.mark("anti-aliasing (after the upscale)")
            if (dst != null) { other = cur; cur = dst }
        }
        if (detail) {
            val doDetail = f.detail > 0f || f.clarity != 0f || f.antiRing > 0f
            val light = lightOn()
            if (doDetail) {
                val dst: Rt? = if (light || vivid || fine) other else null
                if (dst != null) ensure(dst, w, h)
                bindOutD(dst, w, h)
                detailPass(cur)
                PassTimer.mark("detail / clarity")
                if (dst != null) { other = cur; cur = dst }
            }
            if (light) {
                val dst: Rt? = if (vivid || fine) other else null
                if (dst != null) ensure(dst, w, h)
                bindOutD(dst, w, h)
                gameLightPass(cur)
                PassTimer.mark("Game Light")
                if (dst != null) { other = cur; cur = dst }
            }
        }
        if (vivid) {
            val dst: Rt? = if (fine) other else null
            if (dst != null) ensure(dst, w, h)
            bindOutD(dst, w, h)
            colorEnhance(cur)
            PassTimer.mark("colour (vivid / contrast / smart fix / tone)")
            if (dst != null) { other = cur; cur = dst }
        }
        if (fine) {
            val small = pixelPre(cur, cellsW, cellsH)
            bindOut(null, w, h)
            pixelPost(cur, cellsW, cellsH, small)
        }
    }

    /** Blocks across (or down) for "Fine pixels": the source pixels times the chosen factor, never more than the output has pixels. */
    private fun fineCells(srcPx: Int, outPx: Int): Int = Math.round(srcPx * Cfg.pixelFactor.coerceIn(Cfg.PIXEL_MIN, Cfg.PIXEL_MAX)).coerceIn(1, maxOf(1, outPx))

    /** How much the edges between blocks are given back (0 = plain block averages). */
    private val PIX_CRISP = 0.45f

    /**
     * "Fine pixels", step 1: the colour of every block, drawn as ONE pixel per block into a small target (the average of taps x taps samples of
     * [src] spread over the block, see Shaders.PIXEL_POST). Returns that target, or null when the second step is not available (then
     * [pixelPost] does everything itself). Must be called BEFORE the destination is bound.
     */
    private fun pixelPre(src: Rt, cw: Int, ch: Int): Rt? {
        val p = pPixelPost
        if (p == null || pPixelCrisp == null) return null
        ensure(tPix, cw, ch)
        bindOutD(tPix, cw, ch)
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2f(p.u("uCells"), cw.toFloat(), ch.toFloat())
        val cellPx = minOf(src.w.toFloat() / maxOf(1, cw), src.h.toFloat() / maxOf(1, ch))
        GLES30.glUniform1f(p.u("uTaps"), Math.ceil((cellPx / 2f - 0.25f).toDouble()).toInt().coerceIn(1, 4).toFloat())
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
        return tPix
    }

    /** "Fine pixels" finishing step: [src] cut into [cw] x [ch] blocks, every block one colour; with [small] (from [pixelPre]) the edges between blocks are crisper. */
    private fun pixelPost(src: Rt, cw: Int, ch: Int, small: Rt? = null) {
        val p = pPixelPost
        if (p == null) { // the driver refused the shader: the picture is shown as it is
            bilinear(src, src.w, src.h)
            return
        }
        val crisp = pPixelCrisp
        if (small != null && crisp != null) {
            GLES30.glUseProgram(crisp.id)
            bindSrc(small)
            GLES30.glUniform1i(crisp.u("uSrc"), 0)
            GLES30.glUniform2f(crisp.u("uCells"), cw.toFloat(), ch.toFloat())
            // tiny blocks (1 - 3 output pixels, the finest settings) are not "blocks" any more: the sharpening fades out so that the finest setting stays a plain picture
            val cellPx = minOf(src.w.toFloat() / maxOf(1, cw), src.h.toFloat() / maxOf(1, ch))
            GLES30.glUniform1f(crisp.u("uK"), PIX_CRISP * ((cellPx - 1f) / 2f).coerceIn(0f, 1f))
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
            PassTimer.mark("finish: Fine pixels")
            return
        }
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2f(p.u("uCells"), cw.toFloat(), ch.toFloat())
        // every block is the average of taps x taps bilinear samples spread evenly over it (a bilinear sample already averages 2 x 2 pixels, so
        // about half the block width in pixels gives the exact average of the block, at most 4 x 4 samples): clean, steady colours, no flicker on
        // video, and no colour of the next block in this one
        val cellPx = minOf(src.w.toFloat() / maxOf(1, cw), src.h.toFloat() / maxOf(1, ch))
        GLES30.glUniform1f(p.u("uTaps"), Math.ceil((cellPx / 2f - 0.25f).toDouble()).toInt().coerceIn(1, 4).toFloat())
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
        PassTimer.mark("finish: Fine pixels")
    }

    /** Game Light is drawn when it is set, the driver accepted the shader, the picture is not a plain copy / export, and Smooth live has not asked for less work. */
    private fun lightOn() = Cfg.gameLight > 0.004f && pGameLight != null && !byp0() && !exportMode && govLv < 1

    private fun gameLightPass(src: Rt) {
        val p = pGameLight ?: return
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2f(p.u("uInv"), 1f / src.w, 1f / src.h)
        GLES30.glUniform1f(p.u("uAmt"), Cfg.gameLight.coerceIn(0f, 1f))
        GLES30.glUniform1f(p.u("uRad"), (0.0035f * minOf(src.w, src.h)).coerceIn(1.5f, 8f))
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private fun detailPass(src: Rt) {
        val p = pDetail
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2f(p.u("uInv"), 1f / src.w, 1f / src.h)
        GLES30.glUniform1f(p.u("uAmt"), f.detail)
        GLES30.glUniform1f(p.u("uRadius"), 1f + 3f * f.detailSize)
        GLES30.glUniform1f(p.u("uClar"), f.clarity)
        GLES30.glUniform1f(p.u("uClarR"), (0.008f * minOf(src.w, src.h)).coerceIn(3f, 24f))
        GLES30.glUniform1f(p.u("uRing"), f.antiRing)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    // ---- passes ---------------------------------------------------------------------------

    private fun bindSrc(rt: Rt) {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, rt.tex)
    }

    private fun easu(src: Rt, ow: Int, oh: Int) {
        PassTimer.mark("capture / prepare")
        val p = pEasu
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2i(p.u("uSrcSize"), src.w, src.h)
        val iw = src.w.toFloat()
        val ih = src.h.toFloat()
        val ox = ow.toFloat()
        val oy = oh.toFloat()
        // FsrEasuCon (ffx_fsr1.h)
        GLES30.glUniform4f(p.u("uCon0"), iw / ox, ih / oy, 0.5f * iw / ox - 0.5f, 0.5f * ih / oy - 0.5f)
        GLES30.glUniform4f(p.u("uCon1"), 1f / iw, 1f / ih, 1f / iw, -1f / ih)
        GLES30.glUniform4f(p.u("uCon2"), -1f / iw, 2f / ih, 1f / iw, 2f / ih)
        GLES30.glUniform4f(p.u("uCon3"), 0f, 4f / ih, 0f, 0f)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
        PassTimer.mark("enlarge: FSR 1 / CRSC Edge (EASU)")
    }

    private var rcasK = 1f

    private fun rcas(src: Rt, boostPass: Boolean = false) {
        val p = pRcas
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2i(p.u("uSrcSize"), src.w, src.h)
        // The slider is 0..100%; RCAS stays stable up to ~1.3, so 100% = 1.2 (stronger than stock FSR).
        val s1 = f.sharp * 1.2f * rcasK
        // Boost (the extra pass) used to repeat the same strength: at a low slider that changed almost nothing (it looked like Boost did not
        // work), at a high slider it doubled an already strong pass (halos, ringing). Measured offline: now the extra pass is strong where the
        // normal pass is weak and gentle where it is already strong, so Boost adds a steady amount of crispness at every slider position.
        val s = if (boostPass) (0.55f * (1.2f - s1) + 0.15f).coerceIn(0.15f, 0.6f) else s1
        GLES30.glUniform1f(p.u("uSharpness"), s)
        GLES30.glUniform1f(p.u("uProtect"), if (exportMode || govLv >= 2 || byp0()) 0f else Cfg.sharpProtect)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    /** Quality level of the NIS fast shader: NIS mid is NIS fast "Medium" (almost the picture of NIS original, less work in flat areas) with a gentler push; its own "Medium" choice uses the "Light" shader (level 2). */
    private fun fastLevel(): Int = if (f.mode == Cfg.MODE_NIS_MID) Cfg.nisMidLevel.coerceIn(0, 2) else Cfg.nisFastLevel.coerceIn(0, 2)

    /** The NIS fast program for the chosen quality; a level whose shader the driver refuses falls back to the exact one. */
    private fun nisFastProg(): Prog {
        val lv = fastLevel()
        val fine = f.mode == Cfg.MODE_NIS_FINE
        val ix = lv + if (fine) 3 else 0
        pNisFastLv[ix]?.let { return it }
        val p = try {
            Prog(link(Shaders.VERT, Shaders.NIS_FAST.replace("#define NF_LEVEL 0", "#define NF_LEVEL " + lv + if (fine) "\n#define NF_REFINE" else ""), "nis_fast" + ix))
        } catch (e: Exception) {
            pNisFastLv[0]!! // a refused shader: plain NIS fast (exact level) stands in
        }
        pNisFastLv[ix] = p
        return p
    }

    /** OpenGL ES 3.1 and a float render target are needed for the textureGather versions. Decided once per GL context. */
    private fun gatherUsable(): Boolean {
        if (gatherState != 0) return gatherState > 0
        gatherState = -1
        try {
            val ma = IntArray(1)
            val mi = IntArray(1)
            GLES30.glGetIntegerv(GLES30.GL_MAJOR_VERSION, ma, 0)
            GLES30.glGetIntegerv(GLES30.GL_MINOR_VERSION, mi, 0)
            val ver = ma[0] * 10 + mi[0]
            if (ver < 31) return false
            // rendering into R32F: core in ES 3.2, an extension before
            if (ver < 32 && GLES30.glGetString(GLES30.GL_EXTENSIONS)?.contains("GL_EXT_color_buffer_float") != true) return false
            pLuma = Prog(link(Shaders.VERT, Shaders.NIS_LUMA, "nis_luma"))
            gatherState = 1
        } catch (e: Throwable) {
            Log.w(TAG, "NIS gather path not available: " + e.message)
            gatherState = -1
        }
        return gatherState > 0
    }

    /** The upscaler speed setting in force for the programs built in this GL context (Cfg.upOpt: 0 Original, 1 Light, 2 Lightest). */
    private var upOptApplied = 1

    /** Called at the start of every frame: when the setting changed, the 5 upscaler programs are built again from the other shader text. */
    private fun applyUpOpt() {
        val lv = Cfg.upOpt.coerceIn(0, 2)
        if (lv == upOptApplied) return
        val was = upOptApplied
        upOptApplied = lv
        try {
            val newEasu = Prog(link(Shaders.VERT, if (lv >= 2 && LITE_TEXEL_SHADERS) Shaders.EASU_L else Shaders.EASU, "easu"))
            val newRefine = Prog(link(Shaders.VERT, if (lv >= 2 && LITE_TEXEL_SHADERS) Shaders.EDGE_REFINE_L else Shaders.EDGE_REFINE, "edge_refine"))
            val newShock = Prog(link(Shaders.VERT, if (lv >= 2 && LITE_TEXEL_SHADERS) Shaders.EDGE_SHOCK_L else Shaders.EDGE_SHOCK, "edge_shock"))
            val newBp = Prog(link(Shaders.VERT, if (lv >= 1) Shaders.CRSC_BP_L else Shaders.CRSC_BP, "crsc_bp"))
            val newNis = Prog(link(Shaders.VERT, if (lv >= 2) Shaders.NIS_L else Shaders.NIS, "nis"))
            for (o in arrayOf(pEasu, pEdgeRefine, pEdgeShock, pCrscBp, pNis)) GLES30.glDeleteProgram(o.id)
            pEasu = newEasu; pEdgeRefine = newRefine; pEdgeShock = newShock; pCrscBp = newBp; pNis = newNis
            // the gather programs and the choice made for them are decided again (Original: off; Light: NIS fast / mid; Lightest: also Aura)
            gatherState = 0
            gatherChecked = false
        } catch (t: Throwable) {
            Log.w(TAG, "upscaler setting $lv could not be built: " + t.message)
            upOptApplied = was
            Cfg.upOpt = was
        }
    }

    private fun nisFastGProg(): Prog? {
        val lv = fastLevel()
        val fine = f.mode == Cfg.MODE_NIS_FINE
        val ix = lv + if (fine) 3 else 0
        pNisFastG[ix]?.let { return it }
        val p = Prog(link(vert310, Shaders.NIS_FAST_G.replace("#define NF_LEVEL 0", "#define NF_LEVEL " + lv + if (fine) "\n#define NF_REFINE" else ""), "nis_fast_g" + ix))
        pNisFastG[ix] = p
        return p
    }

    private fun nisAuraGProg(): Prog? {
        pNisAuraG?.let { return it }
        val p = Prog(link(vert310, Shaders.NIS_G, "nis_aura_g"))
        pNisAuraG = p
        return p
    }

    private fun lumaDProg(): Prog? {
        pLumaD?.let { return it }
        val p = Prog(link(Shaders.VERT, Shaders.NIS_LUMA_D, "nis_luma_d"))
        pLumaD = p
        return p
    }

    /** The R32F luma texture (same size as the source); false when the device cannot render into it. */
    private fun ensureLuma(w: Int, h: Int): Boolean {
        val rt = lumaRt
        if (rt.tex != 0 && rt.w == w && rt.h == h) return true
        free(rt)
        val t = IntArray(1)
        GLES30.glGenTextures(1, t, 0)
        rt.tex = t[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, rt.tex)
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_R32F, w, h, 0, GLES30.GL_RED, GLES30.GL_FLOAT, null)
        // a float texture cannot be filtered in ES 3.x without an extension: NEAREST keeps it complete (gather and texelFetch ignore the filter anyway)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_NEAREST)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        val fb = IntArray(1)
        GLES30.glGenFramebuffers(1, fb, 0)
        rt.fbo = fb[0]
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, rt.fbo)
        GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, rt.tex, 0)
        if (GLES30.glCheckFramebufferStatus(GLES30.GL_FRAMEBUFFER) != GLES30.GL_FRAMEBUFFER_COMPLETE) {
            free(rt)
            return false
        }
        rt.w = w
        rt.h = h
        return true
    }

    /** Luma of every source pixel into [lumaRt]. Leaves the framebuffer and the viewport as they were. */
    private fun lumaPass(src: Rt, lp: Prog? = null): Boolean {
        val fb = IntArray(1)
        val vp = IntArray(4)
        GLES30.glGetIntegerv(GLES30.GL_FRAMEBUFFER_BINDING, fb, 0)
        GLES30.glGetIntegerv(GLES30.GL_VIEWPORT, vp, 0)
        try {
            if (!ensureLuma(src.w, src.h)) return false
            val p = lp ?: pLuma ?: return false
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, lumaRt.fbo)
            GLES30.glViewport(0, 0, src.w, src.h)
            GLES30.glUseProgram(p.id)
            bindSrc(src)
            GLES30.glUniform1i(p.u("uSrc"), 0)
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
            return true
        } finally {
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fb[0])
            GLES30.glViewport(vp[0], vp[1], vp[2], vp[3])
        }
    }

    /**
     * The textureGather program for NIS fast / NIS mid / Aura (Standard and Soft) with the luma pass already done, or null (any other mode, or the device cannot do it):
     * then the normal program is used. After one failure the gather path stays off for this GL context.
     */
    private fun nisGatherProg(src: Rt): Prog? {
        val m = f.mode
        val aura = (m == Cfg.MODE_NIS || m == Cfg.MODE_NIS_SOFT) && upOptApplied >= 2 // Aura / Aura soft read their window with their own luma pass (Lightest only)
        if (m != Cfg.MODE_NIS_FAST && m != Cfg.MODE_NIS_FINE && m != Cfg.MODE_NIS_MID && !aura) return null
        if (!gatherUsable()) return null
        try {
            val p = if (aura) nisAuraGProg() else nisFastGProg()
            if (p != null && lumaPass(src, if (aura) lumaDProg() else null)) return p
        } catch (e: Throwable) {
            Log.w(TAG, "NIS gather path failed: " + e.message)
        }
        gatherState = -1
        return null
    }

    private fun nis(src: Rt) {
        PassTimer.mark("capture / prepare")
        val orig = f.mode == Cfg.MODE_NIS_ORIG || f.mode == Cfg.MODE_NIS_FAST || f.mode == Cfg.MODE_NIS_FINE || f.mode == Cfg.MODE_NIS_MID   // these use the original NIS uniforms (uScale, uSharp)
        val firstGather = !gatherChecked && (f.mode == Cfg.MODE_NIS_FAST || f.mode == Cfg.MODE_NIS_FINE || f.mode == Cfg.MODE_NIS_MID || ((f.mode == Cfg.MODE_NIS || f.mode == Cfg.MODE_NIS_SOFT) && upOptApplied >= 2)) && gatherState >= 0
        if (firstGather) repeat(8) { GLES30.glGetError() } // clears old errors, so only the gather path is judged below
        val gp = nisGatherProg(src) // before the program is chosen: the luma pass changes the bound program, target and texture
        val p = gp ?: when (f.mode) { Cfg.MODE_NIS_ORIG -> pNisOrig; Cfg.MODE_NIS_FAST, Cfg.MODE_NIS_FINE, Cfg.MODE_NIS_MID -> nisFastProg(); else -> pNis }
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        if (gp != null) {
            GLES30.glActiveTexture(GLES30.GL_TEXTURE1)
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, lumaRt.tex)
            GLES30.glUniform1i(p.u("uLuma"), 1)
            GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        }
        GLES30.glUniform2i(p.u("uSrcSize"), src.w, src.h)
        // the output size is the size of the target that is bound now (viewport)
        val vp = IntArray(4)
        GLES30.glGetIntegerv(GLES30.GL_VIEWPORT, vp, 0)
        if (orig) {
            GLES30.glUniform2f(p.u("uScale"), src.w.toFloat() / vp[2], src.h.toFloat() / vp[3])
            // NIS mid pushes 0.75 times NIS fast / original: edge sharpness between Aura Standard and NIS original (measured)
            GLES30.glUniform1f(p.u("uSharp"), ((0.15f + 0.7f * f.sharp) * (if (f.mode == Cfg.MODE_NIS_MID) 0.75f else 1f)).coerceIn(0f, 1f))
        } else {
            // NIS Lite: the slider maps inside the shader; the enlargement factor widens and strengthens the sharpening
            GLES30.glUniform1f(p.u("uFactor"), vp[2].toFloat() / src.w)
            GLES30.glUniform1f(p.u("uGain"), if (f.mode == Cfg.MODE_NIS_SOFT) 0.6f else 1f)
            GLES30.glUniform1f(p.u("uClean"), if (f.mode == Cfg.MODE_NIS_SOFT) 0.7f else 0f)
            GLES30.glUniform1f(p.u("uSharp"), f.sharp.coerceIn(0f, 1f))
        }
        // NIS original is the heaviest shader here: its bands start small and grow only while the phone keeps up
        drawTiled(vp[2], vp[3], if (f.mode == Cfg.MODE_NIS_ORIG) 250_000 else 1_000_000)
        PassTimer.mark("upscale: Aura / NIS")
        if (gp != null && firstGather) {
            gatherChecked = true
            if (GLES30.glGetError() != GLES30.GL_NO_ERROR) {
                // this driver does not like the gather path (an error in the luma pass or the draw): switch it off and draw this frame again, normally
                Log.w(TAG, "NIS gather path gave a GL error: off")
                gatherState = -1
                nis(src)
            }
        }
    }

    /**
     * A full-screen draw, split into bands when the target is big. The heavy NIS shaders on a huge still image (many
     * megapixels) took so long as ONE draw that the GPU watchdog killed the context and the viewer closed; bands with a
     * glFinish between them keep every GPU submission short. Normal live sizes (under about 3 megapixels) are one draw.
     */
    private fun drawTiled(w: Int, h: Int, bandPixels: Int = 1_000_000) {
        if (w <= 0 || h <= 0 || w.toLong() * h <= 3_000_000L) {
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
            return
        }
        // the band height adapts to the phone: a band that took long (the GPU watchdog kills a submission after a few seconds) is halved, a quick one grows
        var rows = (bandPixels / w).coerceAtLeast(16)
        val maxRows = (4_000_000 / w).coerceAtLeast(16)
        GLES30.glEnable(GLES30.GL_SCISSOR_TEST)
        var y = 0
        while (y < h) {
            val t0 = System.nanoTime()
            GLES30.glScissor(0, y, w, minOf(rows, h - y))
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
            GLES30.glFinish()
            val ms = (System.nanoTime() - t0) / 1_000_000L
            y += rows
            if (ms > 250L && rows > 16) rows = maxOf(16, rows / 2) else if (ms < 40L && rows < maxRows) rows = minOf(maxRows, rows * 2)
        }
        GLES30.glDisable(GLES30.GL_SCISSOR_TEST)
    }

    /** "Fine pixels" upscaler (Shaders.PIXEL): square blocks, [Cfg.pixelFactor] blocks per source pixel. No sharpening after it. */
    private fun pixelUp(src: Rt, ow: Int, oh: Int) {
        val p = pPixel
        if (p == null) { // the driver refused the shader: plain bilinear
            bilinear(src, ow, oh)
            return
        }
        PassTimer.mark("capture / prepare")
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2i(p.u("uSrcSize"), src.w, src.h)
        GLES30.glUniform1f(p.u("uGrid"), Cfg.pixelFactor.coerceIn(Cfg.PIXEL_MIN, Cfg.PIXEL_MAX))
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
        PassTimer.mark("upscale: Fine pixels")
    }

    /** "Clear" upscaler (Shaders.CLEAR). The sharpening afterwards is the normal RCAS pass. */
    private fun clearUp(src: Rt, ow: Int, oh: Int) {
        val p = pClear
        if (p == null) { // the driver refused the shader: FSR 1 instead
            easu(src, ow, oh)
            return
        }
        PassTimer.mark("capture / prepare")
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2i(p.u("uSrcSize"), src.w, src.h)
        GLES30.glUniform1f(p.u("uSharp"), f.sharp.coerceIn(0f, 1f))
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
        PassTimer.mark("upscale: Clear")
    }

    /** "Wow" upscaler: pass 1 (Shaders.ART_UP) rebuilds the picture at [ow] x [oh] into [tArt], pass 2 (Shaders.ART_STYLE) finishes it into [dst].
     *  Strength follows the Sharpness slider (never below 0.35, so the effect is always visible). If the driver refused pass 2 the result of pass 1 is
     *  copied; if it refused pass 1, FSR 1 is used. */
    private fun artUp(src: Rt, dst: Rt, tmp: Rt, ow: Int, oh: Int) {
        val pu = pArtUp
        if (pu == null) { // the driver refused the shader: FSR 1 instead
            easu(src, ow, oh)
            return
        }
        // when the source is already close to the output size (the player upscaled it before the capture) there is little to rebuild: go gentle
        val gentle = if (ow < src.w * 1.25f) 0.5f else 1f
        val amt = f.sharp.coerceIn(0.35f, 1f) * gentle
        val ps = pArtStyle
        PassTimer.mark("capture / prepare")
        ensure(tmp, ow, oh)
        bindOutD(if (ps != null) tmp else dst, ow, oh)
        GLES30.glUseProgram(pu.id)
        bindSrc(src)
        GLES30.glUniform1i(pu.u("uSrc"), 0)
        GLES30.glUniform2i(pu.u("uSrcSize"), src.w, src.h)
        GLES30.glUniform1f(pu.u("uAmt"), amt)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
        PassTimer.mark("upscale: Wow (rebuild)")
        if (ps == null) return
        bindOutD(dst, ow, oh)
        GLES30.glUseProgram(ps.id)
        bindSrc(tmp)
        GLES30.glUniform1i(ps.u("uSrc"), 0)
        GLES30.glUniform2f(ps.u("uInv"), 1f / ow, 1f / oh)
        GLES30.glUniform1f(ps.u("uAmt"), amt)
        GLES30.glUniform1f(ps.u("uColor"), 0.25f)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
        PassTimer.mark("upscale: Wow (finish)")
    }

    private fun sgsr(src: Rt) {
        PassTimer.mark("capture / prepare")
        val p = pSgsr
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2i(p.u("uSrcSize"), src.w, src.h)
        val w = src.w.toFloat()
        val h = src.h.toFloat()
        GLES30.glUniform4f(p.u("uViewportInfo"), 1f / w, 1f / h, w, h)
        // Reference default is 2.0; the slider spans 1.0 (soft) .. 4.0 (strong).
        GLES30.glUniform1f(p.u("uEdgeSharpness"), 1f + 3f * f.sharp)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
        PassTimer.mark("upscale: SGSR 1")
    }

    // CRSC Edge level tables, index = level 0 Light, 1 Balanced, 2 Strong, 3 Crisp, 4 Ultra, 5 Maximum (saving a file only).
    // Offline test (x3, sharpness 70%, compressed source): edge sharpness 0.71 / 0.76 / 0.81 / 0.87 / 0.91 / 0.93 of the original,
    // halo overshoot 0.17 / 0.25 / 0.37 / 0.56 / 0.75 / 0.8 (FSR 1: 0.23, NIS: 1.0), so the steps are even. On sources that are already
    // sharpened AND compressed the top levels halo more (Ultra about 1.8, the original NIS 2.1): use Balanced or Strong for those.
    private val CRSC_ROUNDS = intArrayOf(1, 1, 1, 1, 1, 3)
    // Flat-pixel early-outs of the CRSC Edge passes (the alpha channel carries how flat each pixel's surroundings are, x8).
    // Measured against the full computation on real pictures: PSNR 67-101 dB, nothing visible (see README 3.84.0).
    private val SKIP_REFINE = 0.08f
    private val SKIP_SHARP = 0.0625f
    private val SKIP_SHOCK = 0.1f
    private val CRSC_BOOST = floatArrayOf(0f, 2.0f, 3.0f, 4.0f, 5.0f, 5.0f)
    private val CRSC_OVER = floatArrayOf(0f, 0.03f, 0.04f, 0.05f, 0.06f, 0.06f)
    private val CRSC_RADIUS = floatArrayOf(1f, 1f, 1.15f, 1.25f, 1.33f, 1.33f)
    private val CRSC_SHOCK = floatArrayOf(0f, 1.4f, 1.8f, 2.2f, 2.6f, 2.6f)
    private val CRSC_RCAS = floatArrayOf(0.6f, 0.5f, 0.55f, 0.6f, 0.6f, 0.6f)

    /** CRSC Edge: FSR 1's edge-directed enlargement, then back-projection (the big picture is shrunk back to the source size,
     *  compared with the real source and the difference is added back), edge smoothing, detail boost and edge steepening.
     *  Returns the target that holds the result (t1 or t2) and sets [rcasK] for the last RCAS pass. Used by the normal path and
     *  by the chosen-output-size path (before, the chosen-size path silently did plain bilinear for CRSC Edge). */
    private fun crscEdge(base: Rt, w: Int, h: Int, noCrisp: Boolean = false): Rt {
        PassTimer.mark("capture / prepare")
        ensure(t1, w, h)
        bindOut(t1, w, h)
        discardOld(t1)
        easu(base, w, h)
        var cur = t1
        // CRSC Edge levels: one back-projection round each (3 for Maximum), then edge smoothing, and from Balanced up a wide
        // detail boost + edge steepening that grow step by step (see the CRSC_* tables), so every level is visibly sharper than the last.
        var lv = if (crscOverride >= 0) crscOverride.coerceIn(0, 5) else Cfg.crscLevel.coerceIn(0, 5)
        if (govLv >= 2) lv = maxOf(0, lv - 1)
        // Max (5) works live too now; it and "exact mode" switch the flat-area shortcuts off (the full computation for every pixel)
        val exact = (Cfg.crscExact && govLv < 2) || lv == 5
        // Lightest: the three flat-area shortcuts skip about 4x more pixels (the ones whose surroundings are nearly flat: measured on a 640x360 video frame
        // enlarged 2x, the picture differs from Light by 59 - 87 dB at levels 1 - 4, i.e. nothing visible), and Max (3 rounds of back-projection) runs 2 rounds
        // (49.8 dB, the one visible step: slightly less crisp). Light and Original are untouched.
        val lite = upOptApplied >= 2
        val km = if (lite) 4f else 1f
        val rounds = if (lite && CRSC_ROUNDS[lv] > 2) 2 else CRSC_ROUNDS[lv]
        repeat(rounds) {
            ensure(crscD, base.w, base.h)
            bindOut(crscD, base.w, base.h)
            discardOld(crscD)
            val dq = pCrscDown
            GLES30.glUseProgram(dq.id)
            bindSrc(cur)
            GLES30.glUniform1i(dq.u("uSrc"), 0)
            GLES30.glUniform2f(dq.u("uInv"), 1f / base.w, 1f / base.h)
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
            PassTimer.mark("CRSC Edge: shrunk copy")
            val dst = if (cur === t1) t2 else t1
            ensure(dst, w, h)
            bindOut(dst, w, h)
            discardOld(dst)
            val bp = pCrscBp
            GLES30.glUseProgram(bp.id)
            bindSrc(cur)
            bindTex(1, base)
            bindTex(2, crscD)
            GLES30.glUniform1i(bp.u("uSrc"), 0)
            GLES30.glUniform1i(bp.u("uLow"), 1)
            GLES30.glUniform1i(bp.u("uD"), 2)
            GLES30.glUniform2f(bp.u("uInv"), 1f / base.w, 1f / base.h)
            GLES30.glUniform1f(bp.u("uG"), if (lv == 5) 1.3f else 0.9f)
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
            GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
            PassTimer.mark("CRSC Edge: back-projection")
            cur = dst
        }
        val ratio = (w.toFloat() / base.w).coerceIn(1f, 4f)
        val sk = f.sharp.coerceIn(0f, 1f)
        // 1) anti-aliasing: smooth along every edge (removes the stair-steps of the enlargement)
        run {
            val dst = if (cur === t1) t2 else t1
            ensure(dst, w, h)
            bindOut(dst, w, h)
            discardOld(dst)
            val er = pEdgeRefine
            GLES30.glUseProgram(er.id)
            bindSrc(cur)
            GLES30.glUniform1i(er.u("uSrc"), 0)
            GLES30.glUniform2f(er.u("uInv"), 1f / w, 1f / h)
            GLES30.glUniform2i(er.u("uSize"), w, h)
            GLES30.glUniform1f(er.u("uR"), (0.67f * ratio).coerceIn(1f, 2.5f))
            GLES30.glUniform1f(er.u("uSkipR"), if (exact) 0f else SKIP_REFINE * km)
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
            PassTimer.mark("CRSC Edge: edge smoothing")
            cur = dst
        }
        // 2) wide detail boost on mid-contrast detail (no halo, never leaves the local range)
        if (lv > 0) {
            val dst = if (cur === t1) t2 else t1
            ensure(dst, w, h)
            bindOut(dst, w, h)
            discardOld(dst)
            val us = pCrscSharp
            GLES30.glUseProgram(us.id)
            bindSrc(cur)
            GLES30.glUniform1i(us.u("uSrc"), 0)
            GLES30.glUniform2f(us.u("uInv"), 1f / w, 1f / h)
            GLES30.glUniform1f(us.u("uR"), (0.5f * ratio * CRSC_RADIUS[lv]).coerceIn(1f, 2f))
            GLES30.glUniform1f(us.u("uAmt"), CRSC_BOOST[lv] * (0.3f + sk))
            GLES30.glUniform1f(us.u("uOver"), CRSC_OVER[lv])
            GLES30.glUniform1f(us.u("uSkip"), if (exact) 0f else SKIP_SHARP * km)
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
            PassTimer.mark("CRSC Edge: detail boost")
            cur = dst
        }
        // 3) steepen the edges (shock filter: narrower ramp, no halo, no overshoot)
        if (lv > 0) {
            val sdst = if (cur === t1) t2 else t1
            ensure(sdst, w, h)
            bindOut(sdst, w, h)
            discardOld(sdst)
            val esh = pEdgeShock
            GLES30.glUseProgram(esh.id)
            bindSrc(cur)
            GLES30.glUniform1i(esh.u("uSrc"), 0)
            GLES30.glUniform2f(esh.u("uInv"), 1f / w, 1f / h)
            GLES30.glUniform2i(esh.u("uSize"), w, h)
            GLES30.glUniform1f(esh.u("uR"), ratio)
            GLES30.glUniform1f(esh.u("uSkip"), if (exact) 0f else SKIP_SHOCK * km)
            GLES30.glUniform1f(esh.u("uAmt"), (0.1f + 0.2f * sk) * CRSC_SHOCK[lv])
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
            PassTimer.mark("CRSC Edge: edge steepening")
            cur = sdst
        }
        // 4) "NIS crispness" on the finished picture (see nisCrisp; it works with every upscaler, here it follows CRSC Edge)
        val nl = if (noCrisp) 0 else Cfg.crscNis.coerceIn(0, 4) // the middle step does not sharpen: the final stage does
        if (nl > 0) { cur = nisCrisp(cur, w, h, ratio, false); PassTimer.mark("NIS crispness") }
        // the last RCAS pass is lighter here, the passes above already did most of the sharpening
        rcasK = CRSC_RCAS[lv] * (if (nl > 0) 0.6f else 1f) // NIS already sharpened: the final RCAS is lighter
        return cur
    }

    /**
     * "NIS crispness": the NIS sharpener (directional filter + contrast-adaptive sharpening) run on a finished picture at scale 1,
     * so any upscaler keeps its own clean reconstruction and gets NIS's punchy edges and texture on top. Level 1 and 2 use the cheap
     * NIS Lite sharpener (about half the work of the original), level 3 the original NIS (36 fetches per pixel).
     * [toScreen]: draw straight to the screen (the last stage); otherwise returns the target that holds the result.
     */
    private fun nisCrisp(src: Rt, w: Int, h: Int, ratio: Float, toScreen: Boolean): Rt {
        val nl = Cfg.crscNis.coerceIn(0, 4)
        if (nl == 0) return src
        val sk = f.sharp.coerceIn(0f, 1f)
        val ndst = if (src === t1) t2 else t1
        if (toScreen) {
            bindOut(null, w, h)
        } else {
            ensure(ndst, w, h)
            bindOutD(ndst, w, h)
        }
        // The light scale-1 version of the original NIS sharpener (same picture, far less work); only if this phone's driver refused
        // to build it, the older paths are used (NIS Lite for Soft / Medium, the original shader for Strong).
        // "Crisp Fast": the same picture again with still less work (Shaders.NIS_CRISP_FAST); if its program is missing, Standard is used.
        val crisp = if (Cfg.crscNisFast) pCrispFast else null
        val fast = crisp ?: pNisSharp
        val np = fast ?: (if (nl >= 3) pNisOrig else pNis)
        GLES30.glUseProgram(np.id)
        bindSrc(src)
        GLES30.glUniform1i(np.u("uSrc"), 0)
        GLES30.glUniform2i(np.u("uSrcSize"), w, h)
        if (fast != null) {
            // Measured against NIS (original) on photos (2x): a plain upscaler needs about 2x the old push to reach NIS original's edge
            // sharpness at level 3; an upscaler that is already a NIS (Aura, NIS, NIS fast, NIS mid) only needs a light push on top
            // (NIS mid + level 3 is then about NIS original, the old levels sharpened it twice as much as NIS original, with 3x the halos).
            val onNis = f.mode == Cfg.MODE_NIS || f.mode == Cfg.MODE_NIS_SOFT || f.mode == Cfg.MODE_NIS_ORIG || f.mode == Cfg.MODE_NIS_FAST || f.mode == Cfg.MODE_NIS_FINE || f.mode == Cfg.MODE_NIS_MID
            val gain = if (onNis) floatArrayOf(0f, 0.15f, 0.3f, 0.45f, 0.6f) else floatArrayOf(0f, 0.45f, 0.9f, 1.35f, 1.8f)
            val sharp = ((0.15f + 0.7f * sk) * gain[nl]).coerceIn(0f, 1f)
            if (crisp != null) {
                // the constants NIS_SHARP1 works out for every pixel, worked out once here (same formulas)
                val sl = sharp - 0.5f
                val up = sl >= 0f
                val maxScale = if (up) 1.25f else 1.75f
                val minScale = if (up) 1.25f else 1.0f
                val limScale = if (up) 1.25f else 1.0f
                val strMin = maxOf(0f, 0.4f + sl * minScale * 1.2f)
                val strMax = 1.6f + sl * maxScale * 1.8f
                val limMin = maxOf(0.1f, 0.14f + sl * limScale * 0.32f)
                val limMax = 0.5f + sl * limScale * 0.6f
                GLES30.glUniform4f(np.u("uCfg"), strMin, strMax - strMin, limMin, limMax - limMin)
            } else {
                GLES30.glUniform1f(np.u("uSharp"), sharp)
            }
        } else if (nl >= 3) {
            GLES30.glUniform2f(np.u("uScale"), 1f, 1f)
            GLES30.glUniform1f(np.u("uSharp"), ((0.15f + 0.7f * sk) * 1.1f).coerceIn(0f, 1f))
        } else {
            GLES30.glUniform1f(np.u("uFactor"), ratio.coerceAtLeast(1.5f))
            GLES30.glUniform1f(np.u("uGain"), if (nl == 1) 0.7f else 1f)
            GLES30.glUniform1f(np.u("uClean"), if (nl == 1) 0.3f else 0f)
            GLES30.glUniform1f(np.u("uSharp"), sk)
        }
        drawTiled(w, h)
        return if (toScreen) src else ndst
    }

    private fun bicubic(src: Rt) {
        val p = pBicubic
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2f(p.u("uSrcSize"), src.w.toFloat(), src.h.toFloat())
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private fun bilinear(src: Rt, ow: Int, oh: Int) {
        val p = pBilinear
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    /** Shrinks [src] into [dst] (already sized tw x th): halving steps while the factor is 2 or more, then one 4-tap step. */
    private fun shrink(src: Rt, tw: Int, th: Int, dst: Rt) {
        var cur = src
        var useA = true
        while (cur.w / 2 >= tw && cur.h / 2 >= th) {
            val t = if (useA) shrA else shrB
            val nw = cur.w / 2
            val nh = cur.h / 2
            ensure(t, nw, nh)
            bindOut(t, nw, nh)
            downscale(cur, nw, nh)
            cur = t
            useA = !useA
        }
        bindOut(dst, tw, th)
        downscale(cur, tw, th)
    }

    private fun downscale(src: Rt, ow: Int, oh: Int) {
        val p = pDown
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2f(p.u("uStep"), 0.25f / ow, 0.25f / oh)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private fun denoisePass(src: Rt) {
        val p = pDenoise
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2f(p.u("uInv"), 1f / src.w, 1f / src.h)
        // Clean upscale always removes at least a light amount of noise (keeps fine detail: the sharpen comes after)
        val dn = (f.denoise * cleanKNow).coerceIn(0f, 1f)
        GLES30.glUniform1f(p.u("uAmt"), if (f.cleanUp) maxOf(dn, 0.08f + 0.25f * cleanLvNow()) else dn)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    /** "Colour clean-up" strength in force: not in a file export (it has its own settings), not when Smooth live had to lighten, not on the original. */
    private fun chromaAmt(): Float = if (exportMode || govLv >= 2 || byp0() || pChroma == null) 0f else Cfg.chromaClean

    /** "Adapt clean-up to the video size": how much stronger (up to 1.5x) or weaker (down to 0.4x) Denoise, Colour clean-up and Deband work for a source [h] pixels high. */
    private var cleanKNow = 1f
    /** Strength of the Clean upscale chain in force: the slider, scaled by the same size factor ("Adapt clean-up to the video size"; 1 when that is off). */
    private fun cleanLvNow(): Float = (f.cleanLevel * cleanKNow).coerceIn(0f, 1f)
    private fun cleanK(h: Int): Float = if (!Cfg.cleanAuto || exportMode) 1f else (1.6f - 0.0011f * h).coerceIn(0.4f, 1.5f)

    private fun chromaPass(src: Rt, amt: Float) {
        val p = pChroma ?: return
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2f(p.u("uInv"), 1f / src.w, 1f / src.h)
        GLES30.glUniform1f(p.u("uAmt"), amt)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private fun preSharpPass(src: Rt) {
        val p = pPreSharp
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2f(p.u("uInv"), 1f / src.w, 1f / src.h)
        GLES30.glUniform1f(p.u("uAmt"), maxOf(f.sharp * 0.6f, 0.15f + 0.8f * cleanLvNow()))
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    /** Looks for black bars now and then: the whole frame (not the cropped part) is drawn tiny into [tBar] and read back. A bar must be pure
     *  black across the whole row / column; a change is reported only when 6 measurements in a row agree (a dark scene does not count). */
    private fun detectBars(m: FloatArray) {
        barFrames++
        if (barFrames % 12 != 1) return
        ensure(tBar, BAR_W, BAR_H)
        bindOut(tBar, BAR_W, BAR_H)
        GLES30.glUseProgram(pCopy.id)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTex)
        GLES30.glUniform1i(pCopy.u("uSrc"), 0)
        GLES30.glUniformMatrix4fv(pCopy.u("uTexMatrix"), 1, false, m, 0)
        GLES30.glUniform4f(pCopy.u("uCrop"), 0f, 0f, 1f, 1f)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
        barBuf.clear()
        GLES30.glReadPixels(0, 0, BAR_W, BAR_H, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, barBuf)
        val lumaMax = IntArray(BAR_W * BAR_H)
        var any = false
        barBuf.rewind()
        for (i in lumaMax.indices) {
            val r = barBuf.get().toInt() and 0xFF
            val g = barBuf.get().toInt() and 0xFF
            val b = barBuf.get().toInt() and 0xFF
            barBuf.get()
            val y = (r * 77 + g * 150 + b * 29) shr 8
            lumaMax[i] = y
            if (y > 24) any = true
        }
        if (!any) return // the whole frame is black (a fade): says nothing about bars
        val th = 14 // about 0.055 of full range: bars are exactly black, picture noise is not
        // rows are counted from the bottom (row 0 = bottom of the picture)
        fun rowBlack(y: Int): Boolean {
            var n = 0
            for (x in 0 until BAR_W) if (lumaMax[y * BAR_W + x] > th) n++
            return n <= 1
        }
        fun colBlack(x: Int): Boolean {
            var n = 0
            for (y in 0 until BAR_H) if (lumaMax[y * BAR_W + x] > th) n++
            return n <= 1
        }
        var bot = 0
        while (bot < BAR_H * 2 / 5 && rowBlack(bot)) bot++
        var top = 0
        while (top < BAR_H * 2 / 5 && rowBlack(BAR_H - 1 - top)) top++
        var lef = 0
        while (lef < BAR_W * 2 / 5 && colBlack(lef)) lef++
        var rig = 0
        while (rig < BAR_W * 2 / 5 && colBlack(BAR_W - 1 - rig)) rig++
        // a bar thinner than 2.5 % is no bar; keep one row / column of margin so the real picture edge is never cut
        fun fr(n: Int, tot: Int): Float = if (n < tot * 0.025f) 0f else ((n - 1).toFloat() / tot)
        val cur = floatArrayOf(fr(lef, BAR_W), fr(bot, BAR_H), fr(rig, BAR_W), fr(top, BAR_H))
        barHist.add(cur)
        if (barHist.size > 6) barHist.removeAt(0)
        if (barHist.size < 6) return
        val res = FloatArray(4)
        for (k in 0 until 4) {
            var lo = 1f
            var hi = 0f
            for (h in barHist) { lo = minOf(lo, h[k]); hi = maxOf(hi, h[k]) }
            if (hi - lo > 0.012f) return // not stable yet
            res[k] = lo
        }
        val applied = floatArrayOf(barL, barB, barR, barT)
        var diff = false
        for (k in 0 until 4) if (Math.abs(res[k] - applied[k]) > 0.012f) diff = true
        if (diff) {
            barHist.clear()
            onBars?.invoke(res)
        }
    }

    private fun deintPass(src: Rt) {
        val p = pDeint
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2f(p.u("uInv"), 1f / src.w, 1f / src.h)
        GLES30.glUniform1f(p.u("uOdd"), if (f.deint == 1) 1f else 0f)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private fun debandPass(src: Rt) {
        val p = pDeband
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2f(p.u("uInv"), 1f / src.w, 1f / src.h)
        GLES30.glUniform1f(p.u("uAmt"), (f.deband * cleanKNow).coerceIn(0f, 1f))
        GLES30.glUniform1f(p.u("uRange"), 24f)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private fun nearest(src: Rt) {
        val p = pNearest
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2i(p.u("uSrcSize"), src.w, src.h)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private fun antiAlias(src: Rt, mode: Int) {
        val p = when (mode) {
            Cfg.AA_FXAA_FAST -> pFxaaFast
            Cfg.AA_FXAA_QUALITY -> pFxaaQ
            Cfg.AA_SMART -> pSmart
            else -> pEdge
        }
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2f(p.u("uInv"), 1f / src.w, 1f / src.h)
        GLES30.glUniform1f(p.u("uAmt"), f.aaStrength)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private fun toneOn() = f.shadows != 0f || f.highlights != 0f || f.saturation != 0f || f.warmth != 0f || f.grain > 0f ||
        f.brightness != 0f || f.vibrance != 0f || f.tint != 0f || vigFadeOn()
    /** Vignette / fade: live effects only (a file export keeps its own settings). */
    private fun vigFadeOn() = !exportMode && (Cfg.vignette != 0f || Cfg.fade > 0f)
    private var grainSeed = 0f

    private fun colorEnhance(src: Rt) {
        val p = pColor
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform1f(p.u("uVivid"), f.vivid)
        GLES30.glUniform1f(p.u("uContrast"), f.contrast)
        GLES30.glUniform4f(p.u("uTone"), f.shadows, f.highlights, f.saturation, f.warmth)
        GLES30.glUniform3f(p.u("uTone2"), f.brightness, f.vibrance, f.tint)
        GLES30.glUniform1f(p.u("uRestore"), if (f.cleanUp) (0.65f * cleanLvNow()).coerceIn(0f, 1f) else 0f)
        grainSeed = (grainSeed + 1f) % 97f
        GLES30.glUniform2f(p.u("uGrain"), f.grain, grainSeed)
        GLES30.glUniform2f(p.u("uVF"), if (exportMode) 0f else Cfg.vignette, if (exportMode) 0f else Cfg.fade)
        if (f.smartFix) {
            GLES30.glUniform3f(p.u("uFixGain"), fixGain[0], fixGain[1], fixGain[2])
            GLES30.glUniform3f(p.u("uFixLvl"), fixLo, 1f / fixSpan, fixGamma)
            GLES30.glUniform1f(p.u("uFixSat"), fixSat)
        } else {
            GLES30.glUniform1f(p.u("uFixSat"), 0f)
            GLES30.glUniform3f(p.u("uFixGain"), 1f, 1f, 1f)
            GLES30.glUniform3f(p.u("uFixLvl"), 0f, 1f, 1f)
        }
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    // ---- Smart fix: the frame is looked at (a tiny copy), the correction is smoothed over time ----------------

    private val fixGain = floatArrayOf(1f, 1f, 1f)
    private var fixLo = 0f
    private var fixSpan = 1f
    private var fixGamma = 1f
    private var fixFrames = 0
    private var fixFresh = true
    private var fixWasOn = false
    private val fixBuf: java.nio.ByteBuffer = java.nio.ByteBuffer.allocateDirect(96 * 54 * 4).order(java.nio.ByteOrder.nativeOrder())

    private fun byp0() = bypass

    // the measured correction (target) and the one in use: the one in use follows the target a little every frame (no jumps, no flicker)
    private val fixTgtGain = floatArrayOf(1f, 1f, 1f)
    private var fixTgtLo = 0f
    private var fixTgtSpan = 1f
    private var fixTgtGamma = 1f
    private var fixTgtSat = 0f
    private var fixSat = 0f
    private var fixRaw = SmartFix.Params.NONE // the last measurement as it is; "Smart fix strength" scales it every frame

    private fun fixFollow(rate: Float) {
        for (i in 0..2) fixGain[i] += (fixTgtGain[i] - fixGain[i]) * rate
        fixLo += (fixTgtLo - fixLo) * rate
        fixSpan += (fixTgtSpan - fixSpan) * rate
        fixGamma += (fixTgtGamma - fixGamma) * rate
        fixSat += (fixTgtSat - fixSat) * rate
    }

    /** Measures the copied frame [t0] about twice a second (at once for a still picture or a snapshot); the correction in use moves towards it every frame. */
    private fun smartFixMeasure(w0: Int, h0: Int) {
        fixFrames++
        if (fixFresh || snap || fixFrames % 15 == 0) {
            ensure(tFix, 96, 54)
            bindOut(tFix, 96, 54)
            bilinear(t0, 96, 54)
            fixBuf.clear()
            GLES30.glReadPixels(0, 0, 96, 54, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, fixBuf)
            val px = IntArray(96 * 54)
            fixBuf.rewind()
            for (i in px.indices) {
                val r = fixBuf.get().toInt() and 0xFF
                val g = fixBuf.get().toInt() and 0xFF
                val b = fixBuf.get().toInt() and 0xFF
                fixBuf.get()
                px[i] = (r shl 16) or (g shl 8) or b
            }
            val m = SmartFix.measure(px, 96) ?: SmartFix.Params.NONE
            // a big jump of the measurement = a new scene: follow it faster
            fixCut = Math.abs(m.gamma - fixRaw.gamma) > 0.2f || Math.abs(m.lo - fixRaw.lo) > 0.12f || Math.abs(m.gain[0] - fixRaw.gain[0]) > 0.1f || Math.abs(m.gain[2] - fixRaw.gain[2]) > 0.1f
            fixRaw = m
        }
        // the strength slider works on the measurement at once (also between two measurements)
        val sc = fixRaw.scaled(Cfg.fixLevel)
        for (i in 0..2) fixTgtGain[i] = sc.gain[i]
        fixTgtLo = sc.lo
        fixTgtSpan = sc.span
        fixTgtGamma = sc.gamma
        fixTgtSat = sc.sat
        if (fixFresh || snap) fixFollow(1f) // a still picture / the first frame takes the measured values at once
        else fixFollow(if (fixCut) 0.25f else 0.02f + 0.13f * Cfg.fixSpeed)
        fixFresh = false
    }
    private var fixCut = false

    private fun bindOut(rt: Rt?, w: Int, h: Int) {
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, rt?.fbo ?: outFbo)
        GLES30.glViewport(0, 0, w, h)
    }

    /** [bindOut] for a pass that draws every pixel of the target (a full-screen draw): also tells the GPU the old picture of the target is not needed. */
    private fun bindOutD(rt: Rt?, w: Int, h: Int) {
        bindOut(rt, w, h)
        discardOld(rt)
    }

    private val discardAtt = intArrayOf(GLES30.GL_COLOR_ATTACHMENT0)

    /**
     * Call right after [bindOut] when the pass that follows draws EVERY pixel of that target (a full-screen triangle, no scissor): the GPU is told
     * that what was in the target before does not matter, so a tile-based GPU (nearly every phone) does not read the old picture back from memory
     * at the start of the pass. Nothing in the result changes; it only saves memory traffic.
     */
    private fun discardOld(rt: Rt?) {
        if (rt != null && upOptApplied >= 1) GLES30.glInvalidateFramebuffer(GLES30.GL_FRAMEBUFFER, 1, discardAtt, 0)
    }

    private fun ensure(rt: Rt, w: Int, h: Int) {
        if (rt.tex != 0 && rt.w == w && rt.h == h) return
        free(rt)
        val t = IntArray(1)
        GLES30.glGenTextures(1, t, 0)
        rt.tex = t[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, rt.tex)
        GLES30.glTexImage2D(
            GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA8, w, h, 0,
            GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, null
        )
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        val f = IntArray(1)
        GLES30.glGenFramebuffers(1, f, 0)
        rt.fbo = f[0]
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, rt.fbo)
        GLES30.glFramebufferTexture2D(
            GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, rt.tex, 0
        )
        val status = GLES30.glCheckFramebufferStatus(GLES30.GL_FRAMEBUFFER)
        if (status != GLES30.GL_FRAMEBUFFER_COMPLETE) error("framebuffer incomplete: $status ($w x $h)")
        rt.w = w
        rt.h = h
    }

    private fun free(rt: Rt) {
        if (rt.fbo != 0) GLES30.glDeleteFramebuffers(1, intArrayOf(rt.fbo), 0)
        if (rt.tex != 0) GLES30.glDeleteTextures(1, intArrayOf(rt.tex), 0)
        rt.fbo = 0
        rt.tex = 0
        rt.w = 0
        rt.h = 0
    }

    /** Tears everything down. Blocks briefly so EGL is gone before the window surface dies. */
    fun release() {
        alive = false
        val done = CountDownLatch(1)
        hd.post {
            runCatching {
                st?.setOnFrameAvailableListener(null)
                inSurface?.release()
                st?.release()
                free(t0)
                free(t1)
                free(t2)
                free(t3)
                free(t4)
                free(t5)
                free(t6)
                free(t7)
                free(tPix)
                free(tArt)
                free(tArtMid)
                free(tArtOut)
                free(tFix)
                free(tBar)
                free(fgA)
                free(tAi)
                free(thA)
                free(thB)
                free(tMv)
                free(crscD)
                free(midRt)
                free(inRt)
                free(shrA)
                free(shrB)
                free(fgB)
                free(fgMv)
                free(fgSA)
                free(fgSB)
                if (oesTex != 0) GLES30.glDeleteTextures(1, intArrayOf(oesTex), 0)
                for (p in arrayOf(pCopy, pEasu, pRcas, pSgsr, pBilinear, pBicubic, pColor, pDown, pFxaaFast, pFxaaQ, pEdge, pSmart, pNearest, pDetail, pDenoise, pDeband, pDeint, pTemporal, pTemporalMv, pEdgeRefine, pCrscSharp, pCrscDown, pCrscBp, pEdgeShock, pNis, pNisOrig, pFgMotion, pFgInterp)) GLES30.glDeleteProgram(p.id)
                pChroma?.let { GLES30.glDeleteProgram(it.id) }
                for (p in pNisFastLv.filterNotNull().distinct()) if (p !== pNisOrig) GLES30.glDeleteProgram(p.id)
                pNisMid?.let { if (it !== pNisOrig) GLES30.glDeleteProgram(it.id) }
                free(lumaRt)
                pLuma?.let { GLES30.glDeleteProgram(it.id) }
                pLumaD?.let { GLES30.glDeleteProgram(it.id) }
                pNisAuraG?.let { GLES30.glDeleteProgram(it.id) }
                runCatching { GLES30.glDeleteProgram(pPreSharp.id) }
                pClear?.let { GLES30.glDeleteProgram(it.id) }
                pArtUp?.let { GLES30.glDeleteProgram(it.id) }
                pArtStyle?.let { GLES30.glDeleteProgram(it.id) }
                pGameLight?.let { GLES30.glDeleteProgram(it.id) }
                pPixel?.let { GLES30.glDeleteProgram(it.id) }
                pPixelPost?.let { GLES30.glDeleteProgram(it.id) }
                pPixelCrisp?.let { GLES30.glDeleteProgram(it.id) }
                for (g in pNisFastG) g?.let { GLES30.glDeleteProgram(it.id) }
                pNisMid = null
                pNisFastLv.fill(null)
                pNisSharp?.let { GLES30.glDeleteProgram(it.id) }
                pCrispFast?.let { GLES30.glDeleteProgram(it.id) }
            }
            runCatching {
                EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                EGL14.eglDestroySurface(dpy, srf)
                EGL14.eglDestroyContext(dpy, ctx)
                EGL14.eglTerminate(dpy)
            }
            done.countDown()
        }
        done.await(400, TimeUnit.MILLISECONDS)
        ht.quitSafely()
    }

    private fun link(vs: String, fs: String, name: String): Int {
        val v = compile(GLES30.GL_VERTEX_SHADER, vs, "$name.vert")
        val f = compile(GLES30.GL_FRAGMENT_SHADER, fs, "$name.frag")
        val p = GLES30.glCreateProgram()
        GLES30.glAttachShader(p, v)
        GLES30.glAttachShader(p, f)
        GLES30.glLinkProgram(p)
        val ok = IntArray(1)
        GLES30.glGetProgramiv(p, GLES30.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) error("link $name: " + GLES30.glGetProgramInfoLog(p))
        GLES30.glDeleteShader(v)
        GLES30.glDeleteShader(f)
        return p
    }

    private fun compile(type: Int, src: String, name: String): Int {
        val s = GLES30.glCreateShader(type)
        GLES30.glShaderSource(s, src)
        GLES30.glCompileShader(s)
        val ok = IntArray(1)
        GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) error("shader $name: " + GLES30.glGetShaderInfoLog(s))
        return s
    }

    private companion object {
    /**
     * 3.99.79: the rewritten texelFetch versions of EASU / edge smoothing / edge steepening (Shaders.*_L) gave a blocky, source-pixel-sized
     * picture on some phones (seen at Lightest with CRSC Edge: squares instead of a smooth enlargement), and measured no faster than Light
     * (see FxCost). So Lightest now uses the same smooth shaders as Light for these three passes; Lightest keeps its Aura / NIS gather path.
     * Set to true to bring the old rewritten shaders back.
     */
    private const val LITE_TEXEL_SHADERS = false

        /** Frame generation searches for motion on a copy that is at most this wide. */
        const val FG_SEARCH_W = 960
        const val TAG = "CRSC"
    }
}
