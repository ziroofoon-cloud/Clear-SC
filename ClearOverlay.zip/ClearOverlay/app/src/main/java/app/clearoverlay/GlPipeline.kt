package app.clearoverlay

import android.graphics.Bitmap
import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES30
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Captured frame (external OES texture) -> RGBA copy -> [EASU | SGSR1 | Bilinear] -> RCAS
 * -> optional Vivid colors pass -> overlay surface.
 *
 *  Sharpen : copy -> RCAS (x1, x2 with boost)
 *  FSR 1   : copy -> EASU (upscale) -> RCAS (x1, x2 with boost)
 *  SGSR 1  : copy -> SGSR1 -> (RCAS only with boost)
 *  Fast    : copy -> hardware bilinear upscale -> RCAS (x1, x2 with boost)
 *  Raw     : copy -> nearest-neighbour to the panel (no upscale filter, no sharpening); for comparing resolutions
 *  Render scale > 100% (any mode, Sharpen included): copy -> RCAS at the big size -> 4-tap downscale to the panel.
 *  Denoise / deblock and Deband (when enabled) run first, then anti-aliasing, all at capture size.
 *  Anti-aliasing (FXAA fast / FXAA quality / Edge Smooth), when enabled, runs right after the copy, before
 *  any upscale or sharpening.
 *  Vivid colors, when enabled, always runs last regardless of mode.
 */
class GlPipeline(private val out: Surface) {
    private class Prog(val id: Int) {
        private val cache = HashMap<String, Int>()
        fun u(name: String): Int = cache.getOrPut(name) { GLES30.glGetUniformLocation(id, name) }
    }

    private class Rt {
        var tex = 0
        var fbo = 0
        var w = 0
        var h = 0
    }

    private val ht = HandlerThread("crsc-gl").also { it.start() }
    private val hd = Handler(ht.looper)

    private var dpy: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var ctx: EGLContext = EGL14.EGL_NO_CONTEXT
    private var srf: EGLSurface = EGL14.EGL_NO_SURFACE
    private var oesTex = 0
    private var st: SurfaceTexture? = null
    private var inSurface: Surface? = null

    private lateinit var pCopy: Prog
    private lateinit var pEasu: Prog
    private lateinit var pRcas: Prog
    private lateinit var pSgsr: Prog
    private lateinit var pBilinear: Prog
    private lateinit var pColor: Prog
    private lateinit var pDown: Prog
    private lateinit var pFxaaFast: Prog
    private lateinit var pFxaaQ: Prog
    private lateinit var pEdge: Prog
    private lateinit var pNearest: Prog
    private lateinit var pDetail: Prog
    private lateinit var pDenoise: Prog
    private lateinit var pDeband: Prog
    private val t0 = Rt()
    private val t1 = Rt()
    private val t2 = Rt()
    private val t3 = Rt()
    private val t4 = Rt() // anti-aliasing output
    private val t5 = Rt() // detail pass output (panel size)
    private val t6 = Rt() // second ping-pong target for the capture-size cleanup passes
    private val t7 = Rt() // offscreen result used by [snapshot] (save to gallery)

    /** True while [snapshot] renders into [t7] instead of the window: no zoom, no buffer swap. */
    @Volatile private var snap = false
    @Volatile private var outFbo = 0

    private val m = FloatArray(16)
    private val sz = IntArray(1)

    @Volatile private var capW = 2
    @Volatile private var capH = 2
    @Volatile private var alive = true
    private var failed = false

    /** True = skip every effect: the frame is only copied and scaled with the hardware bilinear filter
     *  (what a normal player would show). Used by the player's effect on/off switch. */
    @Volatile var bypass = false

    /** Zoom into the frame (player only): [zoom] >= 1, centre ([zoomX], [zoomY]) in 0..1 (y up). The cropped part is
     *  taken from the real source pixels and goes through the normal pipeline, so effects can be inspected up close. */
    @Volatile var zoom = 1f
    @Volatile var zoomX = 0.5f
    @Volatile var zoomY = 0.5f

    fun setZoom(z: Float, x: Float, y: Float) {
        zoom = z
        zoomX = x
        zoomY = y
        redraw()
    }

    /** Called (on the GL thread) when GL setup or rendering fails; the message is shown to the user. */
    @Volatile var onError: ((String) -> Unit)? = null

    /** Builds GL on its own thread, then hands back the Surface the VirtualDisplay must write to. */
    fun start(w: Int, h: Int, onReady: (Surface) -> Unit) {
        capW = w
        capH = h
        hd.post {
            try {
                init()
                onReady(inSurface!!)
            } catch (t: Throwable) {
                Log.e(TAG, "GL init failed", t)
                onError?.invoke(t.message ?: "GL init failed")
            }
        }
    }

    fun setCaptureSize(w: Int, h: Int) {
        capW = w
        capH = h
        st?.setDefaultBufferSize(w, h)
    }

    private fun init() {
        dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val v = IntArray(2)
        EGL14.eglInitialize(dpy, v, 0, v, 1)
        val attrs = intArrayOf(
            EGL14.EGL_RENDERABLE_TYPE, EGLExt.EGL_OPENGL_ES3_BIT_KHR,
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8,
            EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_NONE
        )
        val cfgs = arrayOfNulls<EGLConfig>(1)
        val n = IntArray(1)
        EGL14.eglChooseConfig(dpy, attrs, 0, cfgs, 0, 1, n, 0)
        ctx = EGL14.eglCreateContext(
            dpy, cfgs[0], EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 3, EGL14.EGL_NONE), 0
        )
        srf = EGL14.eglCreateWindowSurface(dpy, cfgs[0], out, intArrayOf(EGL14.EGL_NONE), 0)
        EGL14.eglMakeCurrent(dpy, srf, srf, ctx)
        EGL14.eglSwapInterval(dpy, 0)

        val t = IntArray(1)
        GLES30.glGenTextures(1, t, 0)
        oesTex = t[0]
        val oes = GLES11Ext.GL_TEXTURE_EXTERNAL_OES
        GLES30.glBindTexture(oes, oesTex)
        GLES30.glTexParameteri(oes, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(oes, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(oes, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(oes, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)

        pCopy = Prog(link(Shaders.VERT, Shaders.OES_COPY, "copy"))
        pEasu = Prog(link(Shaders.VERT, Shaders.EASU, "easu"))
        pRcas = Prog(link(Shaders.VERT, Shaders.RCAS, "rcas"))
        pSgsr = Prog(link(Shaders.VERT, Shaders.SGSR1, "sgsr1"))
        pBilinear = Prog(link(Shaders.VERT, Shaders.BILINEAR, "bilinear"))
        pColor = Prog(link(Shaders.VERT, Shaders.COLOR_ENHANCE, "color"))
        pDown = Prog(link(Shaders.VERT, Shaders.DOWNSCALE, "downscale"))
        pFxaaFast = Prog(link(Shaders.VERT, Shaders.FXAA_FAST, "fxaa_fast"))
        pFxaaQ = Prog(link(Shaders.VERT, Shaders.FXAA_QUALITY, "fxaa_quality"))
        pEdge = Prog(link(Shaders.VERT, Shaders.EDGE_SMOOTH, "edge_smooth"))
        pNearest = Prog(link(Shaders.VERT, Shaders.NEAREST, "nearest"))
        pDetail = Prog(link(Shaders.VERT, Shaders.DETAIL, "detail"))
        pDenoise = Prog(link(Shaders.VERT, Shaders.DENOISE, "denoise"))
        pDeband = Prog(link(Shaders.VERT, Shaders.DEBAND, "deband"))

        val s = SurfaceTexture(oesTex)
        s.setDefaultBufferSize(capW, capH)
        s.setOnFrameAvailableListener({ draw() }, hd)
        st = s
        inSurface = Surface(s)
    }

    private fun draw() {
        if (!alive) return
        val s = st ?: return
        try {
            s.updateTexImage()
        } catch (e: Exception) {
            return
        }
        s.getTransformMatrix(m)
        if (manualOnly) {
            // offscreen use (manga pages): only take the new frame; the result is rendered by snapshot()
            frameLatch?.countDown()
            return
        }
        val t0 = System.nanoTime()
        renderNow()
        val dt = (System.nanoTime() - t0) / 1_000_000f
        // moving average of the time one frame takes to submit (grows when the GPU cannot keep up): used by Auto
        avgDrawMs = if (avgDrawMs <= 0f) dt else avgDrawMs * 0.9f + dt * 0.1f
    }

    /** True = never draw to the window; frames are only consumed and [snapshot] renders them (used by [MangaFx]). */
    @Volatile var manualOnly = false

    /** Counted down once the next input frame has been taken (manualOnly). */
    @Volatile var frameLatch: java.util.concurrent.CountDownLatch? = null

    /** > 0: the processing size is limited to this many times the output size (player only; 0 = off). */
    @Volatile var maxProcRatio = 0f

    /** Smoothed milliseconds per processed frame (0 = no frame yet). Reset it to 0 after changing settings. */
    @Volatile var avgDrawMs = 0f

    /** Re-renders the last frame with the current settings (paused video, still images, live setting changes). */
    fun redraw() {
        hd.post { if (alive && st != null && srf != EGL14.EGL_NO_SURFACE) renderNow() }
    }

    private fun present() {
        if (!snap) EGL14.eglSwapBuffers(dpy, srf)
    }

    /**
     * Renders the current picture with the current settings at [w] x [h] (whole image, no zoom) and returns it as a
     * Bitmap, or null on failure. Blocks the caller, so call it from a worker thread, never from the UI thread.
     */
    fun snapshot(w: Int, h: Int): Bitmap? {
        val latch = CountDownLatch(1)
        var result: Bitmap? = null
        val queued = hd.post {
            try {
                result = snapshotNow(w, h)
            } catch (t: Throwable) {
                Log.e(TAG, "snapshot failed", t)
            } finally {
                latch.countDown()
            }
        }
        if (!queued) return null
        latch.await(120, TimeUnit.SECONDS)
        return result
    }

    /**
     * The last captured frame exactly as the screen showed it (no effects), at capture size. Worker thread only.
     * Used by the AI still-frame tool: the AI should see the real pixels, not an already sharpened picture.
     */
    fun rawFrame(): Bitmap? {
        bypass = true
        try {
            return snapshot(capW, capH)
        } finally {
            bypass = false
            redraw()
        }
    }

    private fun snapshotNow(w: Int, h: Int): Bitmap? {
        if (!alive || st == null || w <= 0 || h <= 0) return null
        try {
            ensure(t7, w, h)
            snap = true
            outFbo = t7.fbo
            render(w, h)
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, t7.fbo)
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val band = 128
            val buf = ByteBuffer.allocateDirect(w * band * 4).order(ByteOrder.nativeOrder())
            val px = IntArray(w * band)
            var y = 0
            while (y < h) {
                val rows = minOf(band, h - y)
                buf.clear()
                GLES30.glReadPixels(0, y, w, rows, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, buf)
                buf.clear()
                buf.asIntBuffer().get(px, 0, w * rows)
                for (i in 0 until w * rows) {
                    val v = px[i]
                    // bytes R,G,B,A read as a little-endian int = ABGR; Bitmap wants ARGB. OpenGL rows run bottom-up.
                    px[i] = (v and 0xFF00FF00.toInt()) or ((v and 0xFF) shl 16) or ((v shr 16) and 0xFF) or 0xFF000000.toInt()
                }
                for (r in 0 until rows) bmp.setPixels(px, r * w, w, 0, h - 1 - (y + r), w, 1)
                y += rows
            }
            return bmp
        } finally {
            snap = false
            outFbo = 0
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
            free(t7)
            renderNow()
        }
    }

    private fun renderNow() {
        EGL14.eglQuerySurface(dpy, srf, EGL14.EGL_WIDTH, sz, 0)
        val w = sz[0]
        EGL14.eglQuerySurface(dpy, srf, EGL14.EGL_HEIGHT, sz, 0)
        val h = sz[0]
        if (w <= 0 || h <= 0) return
        try {
            render(w, h)
        } catch (t: Throwable) {
            if (!failed) {
                failed = true
                Log.e(TAG, "render failed", t)
                onError?.invoke(t.message ?: "render error")
            }
        }
    }

    private fun render(w: Int, h: Int) {
        val mode = Cfg.mode
        val boost = Cfg.boost
        val vivid = Cfg.vivid > 0f
        val detail = Cfg.detail > 0f
        val post = vivid || detail
        val sharpOnly = mode == Cfg.MODE_SHARP
        val byp = bypass
        val z = if (snap) 1f else zoom.coerceAtLeast(1f)
        var sw = if (z > 1f) maxOf(2, (capW / z).toInt()) else capW
        var sh = if (z > 1f) maxOf(2, (capH / z).toInt()) else capH
        if (maxProcRatio > 0f && !snap && !byp) {
            // the source is much bigger than the output (e.g. 4K video on a 1080p screen): work at most
            // maxProcRatio x the output size instead of at the full source size (several times cheaper)
            val k = minOf(1f, w * maxProcRatio / sw, h * maxProcRatio / sh)
            if (k < 1f) {
                sw = maxOf(2, (sw * k).toInt())
                sh = maxOf(2, (sh * k).toInt())
            }
        }
        val half = 0.5f / z
        val cropX = (zoomX - half).coerceIn(0f, 1f - 1f / z)
        val cropY = (zoomY - half).coerceIn(0f, 1f - 1f / z)
        val cw = if (byp) sw else if (sharpOnly) maxOf(w, sw) else sw
        val ch = if (byp) sh else if (sharpOnly) maxOf(h, sh) else sh

        // 0) external texture -> plain RGBA texture (capture size)
        ensure(t0, cw, ch)
        bindOut(t0, cw, ch)
        GLES30.glUseProgram(pCopy.id)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTex)
        GLES30.glUniform1i(pCopy.u("uSrc"), 0)
        GLES30.glUniformMatrix4fv(pCopy.u("uTexMatrix"), 1, false, m, 0)
        GLES30.glUniform4f(pCopy.u("uCrop"), cropX, cropY, 1f / z, 1f / z)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)

        // Effects off: just show the copied frame, scaled by the GPU's own bilinear filter.
        if (byp) {
            bindOut(null, w, h)
            bilinear(t0, w, h)
            present()
            return
        }

        // 0b) optional anti-aliasing at capture size; everything after reads from [base]
        // Cleanup stages run in this order, each reading the previous result (t4 / t6 ping-pong):
        // denoise / deblock -> deband -> anti-aliasing. All happen before upscaling and sharpening,
        // so sharpening never amplifies compression noise.
        var base = t0
        if (Cfg.denoise > 0f) {
            val dst = if (base === t4) t6 else t4
            ensure(dst, cw, ch)
            bindOut(dst, cw, ch)
            denoisePass(base)
            base = dst
        }
        if (Cfg.deband > 0f) {
            val dst = if (base === t4) t6 else t4
            ensure(dst, cw, ch)
            bindOut(dst, cw, ch)
            debandPass(base)
            base = dst
        }
        val aa = Cfg.aaMode
        if (aa != Cfg.AA_OFF) {
            val dst = if (base === t4) t6 else t4
            ensure(dst, cw, ch)
            bindOut(dst, cw, ch)
            antiAlias(base, aa)
            base = dst
        }

        // Raw: show the captured frame as-is (nearest-neighbour), no upscale filter and no sharpening.
        if (mode == Cfg.MODE_RAW) {
            if (vivid) {
                ensure(t1, w, h)
                bindOut(t1, w, h)
                nearest(base)
                bindOut(null, w, h)
                colorEnhance(t1)
            } else {
                bindOut(null, w, h)
                nearest(base)
            }
            present()
            return
        }

        // Supersampling: the render scale is above the panel size, so there is nothing to upscale.
        // Sharpen at the big size, then shrink back to the panel with a 4-tap filter.
        if (cw > w || ch > h) {
            var big = base
            var n = 0
            val passes = if (boost) 2 else 1
            while (n < passes) {
                val dstBig = if (big === t1) t2 else t1
                ensure(dstBig, cw, ch)
                bindOut(dstBig, cw, ch)
                rcas(big)
                big = dstBig
                n++
            }
            if (post) {
                ensure(t3, w, h)
                bindOut(t3, w, h)
            } else {
                bindOut(null, w, h)
            }
            downscale(big, w, h)
            if (post) finishPost(t3, t5, w, h, detail, vivid)
            present()
            return
        }

        // 1) upscale stage
        var cur = base
        var rcasPasses: Int
        when (mode) {
            Cfg.MODE_FSR -> {
                ensure(t1, w, h)
                bindOut(t1, w, h)
                easu(base, w, h)
                cur = t1
                rcasPasses = if (boost) 2 else 1
            }
            Cfg.MODE_SGSR -> {
                if (boost || post) {
                    // Need an offscreen target either to feed a second RCAS pass or the Detail / Vivid pass.
                    ensure(t1, w, h)
                    bindOut(t1, w, h)
                    sgsr(base)
                    cur = t1
                    rcasPasses = if (boost) 1 else 0
                } else {
                    bindOut(null, w, h)
                    sgsr(base)
                    rcasPasses = 0
                }
            }
            Cfg.MODE_FAST -> {
                ensure(t1, w, h)
                bindOut(t1, w, h)
                bilinear(base, w, h)
                cur = t1
                rcasPasses = if (boost) 2 else 1
            }
            else -> rcasPasses = if (boost) 2 else 1
        }

        // 2) sharpening passes. The last one goes straight to the screen, unless a Vivid colors
        // pass still needs to run after it, in which case it goes to an offscreen target instead.
        var i = 0
        while (i < rcasPasses) {
            val last = i == rcasPasses - 1
            val dst: Rt? = if (last && !post) null else (if (cur === t1) t2 else t1)
            if (dst != null) ensure(dst, w, h)
            bindOut(dst, w, h)
            rcas(cur)
            if (dst != null) cur = dst
            i++
        }

        // 3) optional Detail / deblur, then optional color enhance (always last)
        if (post) finishPost(cur, if (cur === t1) t2 else t1, w, h, detail, vivid)
        present()
    }

    /** Runs Detail (if on) then Vivid (if on) from [src]; the final pass goes to the screen. [spare] is the
     *  offscreen target used between the two passes. */
    private fun finishPost(src: Rt, spare: Rt, w: Int, h: Int, detail: Boolean, vivid: Boolean) {
        var cur = src
        if (detail) {
            val dst: Rt? = if (vivid) spare else null
            if (dst != null) ensure(dst, w, h)
            bindOut(dst, w, h)
            detailPass(cur)
            if (dst != null) cur = dst
        }
        if (vivid) {
            bindOut(null, w, h)
            colorEnhance(cur)
        }
    }

    private fun detailPass(src: Rt) {
        val p = pDetail
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2f(p.u("uInv"), 1f / src.w, 1f / src.h)
        GLES30.glUniform1f(p.u("uAmt"), Cfg.detail)
        GLES30.glUniform1f(p.u("uRadius"), 1f + 3f * Cfg.detailSize)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    // ---- passes ---------------------------------------------------------------------------

    private fun bindSrc(rt: Rt) {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, rt.tex)
    }

    private fun easu(src: Rt, ow: Int, oh: Int) {
        val p = pEasu
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2i(p.u("uSrcSize"), src.w, src.h)
        val iw = src.w.toFloat()
        val ih = src.h.toFloat()
        val ox = ow.toFloat()
        val oy = oh.toFloat()
        // FsrEasuCon (ffx_fsr1.h)
        GLES30.glUniform4f(p.u("uCon0"), iw / ox, ih / oy, 0.5f * iw / ox - 0.5f, 0.5f * ih / oy - 0.5f)
        GLES30.glUniform4f(p.u("uCon1"), 1f / iw, 1f / ih, 1f / iw, -1f / ih)
        GLES30.glUniform4f(p.u("uCon2"), -1f / iw, 2f / ih, 1f / iw, 2f / ih)
        GLES30.glUniform4f(p.u("uCon3"), 0f, 4f / ih, 0f, 0f)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private fun rcas(src: Rt) {
        val p = pRcas
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2i(p.u("uSrcSize"), src.w, src.h)
        // The slider is 0..100%; RCAS stays stable up to ~1.3, so 100% = 1.2 (stronger than stock FSR).
        GLES30.glUniform1f(p.u("uSharpness"), Cfg.sharp * 1.2f)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private fun sgsr(src: Rt) {
        val p = pSgsr
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2i(p.u("uSrcSize"), src.w, src.h)
        val w = src.w.toFloat()
        val h = src.h.toFloat()
        GLES30.glUniform4f(p.u("uViewportInfo"), 1f / w, 1f / h, w, h)
        // Reference default is 2.0; the slider spans 1.0 (soft) .. 4.0 (strong).
        GLES30.glUniform1f(p.u("uEdgeSharpness"), 1f + 3f * Cfg.sharp)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private fun bilinear(src: Rt, ow: Int, oh: Int) {
        val p = pBilinear
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private fun downscale(src: Rt, ow: Int, oh: Int) {
        val p = pDown
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2f(p.u("uStep"), 0.25f / ow, 0.25f / oh)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private fun denoisePass(src: Rt) {
        val p = pDenoise
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2f(p.u("uInv"), 1f / src.w, 1f / src.h)
        GLES30.glUniform1f(p.u("uAmt"), Cfg.denoise)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private fun debandPass(src: Rt) {
        val p = pDeband
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2f(p.u("uInv"), 1f / src.w, 1f / src.h)
        GLES30.glUniform1f(p.u("uAmt"), Cfg.deband)
        GLES30.glUniform1f(p.u("uRange"), 24f)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private fun nearest(src: Rt) {
        val p = pNearest
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2i(p.u("uSrcSize"), src.w, src.h)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private fun antiAlias(src: Rt, mode: Int) {
        val p = when (mode) {
            Cfg.AA_FXAA_FAST -> pFxaaFast
            Cfg.AA_FXAA_QUALITY -> pFxaaQ
            else -> pEdge
        }
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform2f(p.u("uInv"), 1f / src.w, 1f / src.h)
        GLES30.glUniform1f(p.u("uAmt"), Cfg.aaStrength)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private fun colorEnhance(src: Rt) {
        val p = pColor
        GLES30.glUseProgram(p.id)
        bindSrc(src)
        GLES30.glUniform1i(p.u("uSrc"), 0)
        GLES30.glUniform1f(p.u("uVivid"), Cfg.vivid)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
    }

    private fun bindOut(rt: Rt?, w: Int, h: Int) {
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, rt?.fbo ?: outFbo)
        GLES30.glViewport(0, 0, w, h)
    }

    private fun ensure(rt: Rt, w: Int, h: Int) {
        if (rt.tex != 0 && rt.w == w && rt.h == h) return
        free(rt)
        val t = IntArray(1)
        GLES30.glGenTextures(1, t, 0)
        rt.tex = t[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, rt.tex)
        GLES30.glTexImage2D(
            GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA8, w, h, 0,
            GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, null
        )
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        val f = IntArray(1)
        GLES30.glGenFramebuffers(1, f, 0)
        rt.fbo = f[0]
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, rt.fbo)
        GLES30.glFramebufferTexture2D(
            GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, rt.tex, 0
        )
        val status = GLES30.glCheckFramebufferStatus(GLES30.GL_FRAMEBUFFER)
        if (status != GLES30.GL_FRAMEBUFFER_COMPLETE) error("framebuffer incomplete: $status ($w x $h)")
        rt.w = w
        rt.h = h
    }

    private fun free(rt: Rt) {
        if (rt.fbo != 0) GLES30.glDeleteFramebuffers(1, intArrayOf(rt.fbo), 0)
        if (rt.tex != 0) GLES30.glDeleteTextures(1, intArrayOf(rt.tex), 0)
        rt.fbo = 0
        rt.tex = 0
        rt.w = 0
        rt.h = 0
    }

    /** Tears everything down. Blocks briefly so EGL is gone before the window surface dies. */
    fun release() {
        alive = false
        val done = CountDownLatch(1)
        hd.post {
            runCatching {
                st?.setOnFrameAvailableListener(null)
                inSurface?.release()
                st?.release()
                free(t0)
                free(t1)
                free(t2)
                free(t3)
                free(t4)
                free(t5)
                free(t6)
                free(t7)
                if (oesTex != 0) GLES30.glDeleteTextures(1, intArrayOf(oesTex), 0)
                for (p in arrayOf(pCopy, pEasu, pRcas, pSgsr, pBilinear, pColor, pDown, pFxaaFast, pFxaaQ, pEdge, pNearest, pDetail, pDenoise, pDeband)) GLES30.glDeleteProgram(p.id)
            }
            runCatching {
                EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                EGL14.eglDestroySurface(dpy, srf)
                EGL14.eglDestroyContext(dpy, ctx)
                EGL14.eglTerminate(dpy)
            }
            done.countDown()
        }
        done.await(400, TimeUnit.MILLISECONDS)
        ht.quitSafely()
    }

    private fun link(vs: String, fs: String, name: String): Int {
        val v = compile(GLES30.GL_VERTEX_SHADER, vs, "$name.vert")
        val f = compile(GLES30.GL_FRAGMENT_SHADER, fs, "$name.frag")
        val p = GLES30.glCreateProgram()
        GLES30.glAttachShader(p, v)
        GLES30.glAttachShader(p, f)
        GLES30.glLinkProgram(p)
        val ok = IntArray(1)
        GLES30.glGetProgramiv(p, GLES30.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) error("link $name: " + GLES30.glGetProgramInfoLog(p))
        GLES30.glDeleteShader(v)
        GLES30.glDeleteShader(f)
        return p
    }

    private fun compile(type: Int, src: String, name: String): Int {
        val s = GLES30.glCreateShader(type)
        GLES30.glShaderSource(s, src)
        GLES30.glCompileShader(s)
        val ok = IntArray(1)
        GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) error("shader $name: " + GLES30.glGetShaderInfoLog(s))
        return s
    }

    private companion object {
        const val TAG = "CRSC"
    }
}
