package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.min

/**
 * "Upscale a video to a new file": pick the size and the quality, start, watch the progress. The work itself runs in
 * [ExportService]; this screen only shows [ExportState] and can be closed and opened again at any time.
 */
class ExportActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var box: LinearLayout
    private var uri: Uri? = null
    private var name = ""
    private var target = 1080
    private var tier = 1
    private var anime = false
    private var hevc = false
    private var upMode = Cfg.MODE_FSR
    private var autoMode = true
    /** Video quality: 0 Auto, 1 Fast, 2 Balanced, 3 Best, 4 Maximum. Upscaler: 0 Auto, 1 FSR 1, 2 SGSR 1. Encoder: 0 Auto, 1 H.264, 2 H.265. */
    private var vTier = 0
    private var vUp = 0
    private var vFg = false
    private var vFull = false
    private var vTemporal = 0
    private var fgInfoTv: TextView? = null
    private var vAi = 0
    private var vAiAuto = false
    private var vAiHalf = false
    private var vSize = 0
    private var vFgN = 2
    private var vFgQ = 1
    private var vEnc = 0
    private var pace = 0
    private var sharpP = 0
    private var vividP = 0
    private var srcInfo: SrcInfo? = null
    private var shownRunning: Boolean? = null
    private var lastSegCount = -1

    // progress widgets
    private var bar: ProgressBar? = null
    private var lineA: TextView? = null
    private var lineB: TextView? = null
    private var lineC: TextView? = null
    private var watchBtn: TextView? = null
    private var resumeTv: TextView? = null
    private var isGif = false
    // "only a part of the video": the texts as typed ("14:00"), so they survive rebuilding the screen
    private var rangeOn = false
    private var streamOn = false
    private var streamLaunched = false
    private var rangeFrom = ""
    private var rangeTo = ""
    private val cancelGif = java.util.concurrent.atomic.AtomicBoolean(false)
    private var restartBtn: TextView? = null

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Cfg.load(this)
        Ui.init(this)
        setTheme(Ui.theme())
        super.onCreate(savedInstanceState)
        Ui.styleBars(window)
        intent?.data?.let {
            setSource(it, intent.getStringExtra(X_NAME) ?: nameOf(it))
        }
        val root = ScrollView(this).apply { setBackgroundColor(Ui.BG) }
        box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(this@ExportActivity, 18), dp(this@ExportActivity, 22), dp(this@ExportActivity, 18), dp(this@ExportActivity, 28))
        }
        root.addView(box, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        ui.post(tick)
    }

    override fun onPause() {
        ui.removeCallbacks(tick)
        super.onPause()
    }

    private val tick: Runnable = object : Runnable {
        override fun run() {
            if (isDestroyed) return
            update()
            ui.postDelayed(this, 600)
        }
    }

    private fun setSource(u: Uri, n: String) {
        uri = u
        name = n
        isGif = GifExport.looksLikeGif(this, u, n)
    }

    private fun nameOf(u: Uri): String = runCatching {
        contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
    }.getOrNull() ?: (u.lastPathSegment ?: "video").substringAfterLast('/')

    private fun gap(v: Int) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@ExportActivity, v) }

    private fun button(label: String, primary: Boolean, onClick: () -> Unit) = Ui.text(this, label, 16f, if (primary) Ui.BG else Ui.ACCENT, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(this@ExportActivity, 14), dp(this@ExportActivity, 13), dp(this@ExportActivity, 14), dp(this@ExportActivity, 13))
        background = if (primary) Ui.gradient(dp(this@ExportActivity, 14).toFloat()) else Ui.round(Ui.CHIP, dp(this@ExportActivity, 14).toFloat())
        setOnClickListener { onClick() }
    }

    /** A row of equal chips; [onPick] gets the index. */
    private fun chips(labels: List<String>, selected: Int, onPick: (Int) -> Unit): View {
        val row = LinearLayout(this)
        val views = ArrayList<TextView>()
        fun paint(sel: Int) {
            val r = dp(this, 10).toFloat()
            views.forEachIndexed { i, c ->
                if (i == sel) {
                    c.background = Ui.gradient(r)
                    c.setTextColor(Ui.BG)
                } else {
                    c.background = Ui.round(Ui.CHIP, r)
                    c.setTextColor(Ui.MUTED)
                }
            }
        }
        labels.forEachIndexed { i, l ->
            val c = TextView(this).apply {
                text = l
                textSize = 14f
                gravity = Gravity.CENTER
                maxLines = 1
                minWidth = dp(this@ExportActivity, 60)
                setPadding(dp(this@ExportActivity, 14), dp(this@ExportActivity, 10), dp(this@ExportActivity, 14), dp(this@ExportActivity, 10))
                setOnClickListener {
                    paint(i)
                    onPick(i)
                }
            }
            views.add(c)
            row.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i > 0) marginStart = dp(this@ExportActivity, 6) })
        }
        paint(selected)
        return ChipScroller(this, row) // swipes sideways when the labels do not fit
    }

    // ---- screens ----------------------------------------------------------------------------------

    private fun refresh() {
        box.removeAllViews()
        bar = null
        lineA = null
        lineB = null
        lineC = null
        watchBtn = null
        resumeTv = null
        restartBtn = null
        shownRunning = ExportState.running
        lastSegCount = -1
        if (ExportState.running) showProgress() else showConfig()
    }

    private fun showConfig() {
        if (isGif) {
            showGifConfig()
            return
        }
        box.addView(Ui.text(this, getString(R.string.export_title), 22f, Ui.TEXT, true))
        box.addView(Ui.text(this, getString(R.string.export_note), 13f, Ui.MUTED), gap(8))
        if (ExportState.finished) box.addView(finishedCard(), gap(14))
        unfinishedCard()?.let { box.addView(it, gap(14)) }

        box.addView(Ui.text(this, if (uri == null) getString(R.string.export_need_video) else name, 15f, Ui.TEXT, true), gap(16))
        val srcTv = Ui.text(this, "", 12f, Ui.MUTED)
        box.addView(srcTv, gap(4))
        box.addView(button(getString(R.string.export_pick), false) { pick() }, gap(8))

        val estTv = Ui.text(this, "", 13f, Ui.TEXT)
        val encTv = Ui.text(this, "", 12f, Ui.MUTED)

        // which part of the video
        addRangeSection(estTv, encTv)
        addStreamSection(estTv, encTv)

        // what is being made
        box.addView(Ui.text(this, getString(R.string.export_target), 13f, Ui.ACCENT, true), gap(18))
        val targets = intArrayOf(480, 720, 1080, 1440)
        box.addView(chips(listOf("480p", "720p", "1080p", "1440p"), targets.indexOf(target).coerceAtLeast(0)) {
            target = targets[it]
            updateEst(estTv, encTv)
        }, gap(6))

        // everything is chosen by the app, or by hand
        box.addView(Ui.text(this, getString(R.string.export_settings_mode_title), 13f, Ui.ACCENT, true), gap(18))
        val custom = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val fullHint = Ui.text(this, getString(R.string.export_full_hint), 12f, Ui.MUTED)
        box.addView(chips(listOf(getString(R.string.export_full_auto), getString(R.string.export_full_custom)), if (vFull) 0 else 1) {
            vFull = it == 0
            custom.visibility = if (vFull) View.GONE else View.VISIBLE
            fullHint.visibility = if (vFull) View.VISIBLE else View.GONE
            updateEst(estTv, encTv)
        }, gap(6))
        box.addView(fullHint, gap(6))
        custom.visibility = if (vFull) View.GONE else View.VISIBLE
        fullHint.visibility = if (vFull) View.VISIBLE else View.GONE
        box.addView(custom, gap(0))

        // quality (Auto picks one for this video and this phone)
        custom.addView(panelSection(this, getString(R.string.export_sec_quality)), gap(16))
        custom.addView(Ui.text(this, getString(R.string.export_tier), 13f, Ui.ACCENT, true), gap(8))
        val desc = Ui.text(this, vTierDesc(), 12f, Ui.MUTED)
        custom.addView(chips(
            listOf(getString(R.string.export_auto), getString(R.string.export_tier_fast), getString(R.string.export_tier_med), getString(R.string.export_tier_high), getString(R.string.export_tier_max)),
            vTier
        ) {
            vTier = it
            desc.text = vTierDesc()
            updateEst(estTv, encTv)
        }, gap(6))
        custom.addView(desc, gap(6))

        addAiSection(estTv, encTv, custom)

        custom.addView(Ui.text(this, getString(R.string.export_content), 13f, Ui.ACCENT, true), gap(16))
        custom.addView(chips(listOf(getString(R.string.export_content_video), getString(R.string.export_content_anime)), if (anime) 1 else 0) {
            anime = it == 1
            updateEst(estTv, encTv)
        }, gap(6))

        custom.addView(Ui.text(this, getString(R.string.export_upscaler), 13f, Ui.ACCENT, true), gap(16))
        custom.addView(chips(listOf(getString(R.string.export_auto), "FSR 1", "SGSR 1", getString(R.string.mode_lanczos)), vUp) {
            vUp = it
            updateEst(estTv, encTv)
        }, gap(6))
        custom.addView(Ui.text(this, getString(R.string.export_upscaler_hint), 12f, Ui.MUTED), gap(6))

        custom.addView(Ui.text(this, getString(R.string.export_temporal), 13f, Ui.ACCENT, true), gap(16))
        custom.addView(chips(listOf(getString(R.string.export_fg_off), getString(R.string.export_temporal_light), getString(R.string.export_temporal_strong)), vTemporal) {
            vTemporal = it
            updateEst(estTv, encTv)
        }, gap(6))
        custom.addView(Ui.text(this, getString(R.string.export_temporal_hint), 12f, Ui.MUTED), gap(6))

        custom.addView(panelSection(this, getString(R.string.export_sec_output)), gap(18))
        custom.addView(Ui.text(this, getString(R.string.export_encoder), 13f, Ui.ACCENT, true), gap(8))
        custom.addView(chips(listOf(getString(R.string.export_auto), "H.264", "H.265"), vEnc) {
            vEnc = it
            updateEst(estTv, encTv)
        }, gap(6))
        custom.addView(Ui.text(this, getString(R.string.export_encoder_hint), 12f, Ui.MUTED), gap(6))
        custom.addView(encTv, gap(4))

        custom.addView(Ui.text(this, getString(R.string.export_size), 13f, Ui.ACCENT, true), gap(16))
        custom.addView(chips(listOf(getString(R.string.export_size_normal), getString(R.string.export_size_small), getString(R.string.export_size_smallest)), vSize) {
            vSize = it
            if (it > 0 && vEnc == 0) { /* Auto already prefers H.265 when the phone has it */ }
            updateEst(estTv, encTv)
        }, gap(6))
        custom.addView(Ui.text(this, getString(R.string.export_size_hint), 12f, Ui.MUTED), gap(6))

        custom.addView(panelSection(this, getString(R.string.export_fg)), gap(18))
        fgInfoTv = Ui.text(this, "", 13f, Ui.TEXT)
        custom.addView(fgInfoTv, gap(8))
        custom.addView(chips(listOf(getString(R.string.export_fg_off), "2x", "3x", "4x"), if (vFg) vFgN - 1 else 0) {
            vFg = it > 0
            if (it > 0) vFgN = it + 1
            updateEst(estTv, encTv)
        }, gap(8))
        custom.addView(Ui.text(this, getString(R.string.export_fg_quality), 12f, Ui.MUTED), gap(10))
        custom.addView(chips(listOf(getString(R.string.export_fg_vlight), getString(R.string.export_fg_light), getString(R.string.export_fg_normal), getString(R.string.export_fg_high)), FG_Q_ORDER.indexOf(vFgQ).coerceAtLeast(0)) {
            vFgQ = FG_Q_ORDER[it]
            updateEst(estTv, encTv)
        }, gap(6))
        custom.addView(Ui.text(this, getString(R.string.export_fg_hint), 12f, Ui.MUTED), gap(8))

        custom.addView(panelSection(this, getString(R.string.export_sec_fine)), gap(18))
        val sharpTv = Ui.text(this, "", 14f, Ui.TEXT)
        fun sharpText(p: Int) = getString(R.string.export_sharp_fmt, if (p == 0) getString(R.string.export_auto_word) else "${p - 1}%")
        sharpTv.text = sharpText(sharpP)
        custom.addView(sharpTv, gap(10))
        custom.addView(slider(101, sharpP) { sharpP = it; sharpTv.text = sharpText(it) }, gap(2))

        val vividTv = Ui.text(this, "", 14f, Ui.TEXT)
        fun vividText(p: Int) = getString(R.string.export_vivid_fmt, p)
        vividTv.text = vividText(vividP)
        custom.addView(vividTv, gap(14))
        custom.addView(slider(100, vividP) { vividP = it; vividTv.text = vividText(it) }, gap(2))

        // load on the phone
        custom.addView(Ui.text(this, getString(R.string.export_pace), 13f, Ui.ACCENT, true), gap(16))
        custom.addView(chips(listOf(getString(R.string.export_pace_max), getString(R.string.export_pace_bal), getString(R.string.export_pace_gentle)), pace) {
            pace = it
            updateEst(estTv, encTv)
        }, gap(6))
        custom.addView(Ui.text(this, getString(R.string.export_pace_hint), 12f, Ui.MUTED), gap(6))

        // estimate
        box.addView(Ui.text(this, getString(R.string.export_est_title), 13f, Ui.ACCENT, true), gap(18))
        box.addView(estTv, gap(6))

        // an unfinished export of the same video with the same settings: Start continues it
        resumeTv = Ui.text(this, "", 13f, Ui.ACCENT, true).apply { visibility = View.GONE }
        box.addView(resumeTv, gap(10))
        restartBtn = button(getString(R.string.export_restart), false) {
            val u2 = uri
            if (u2 != null) {
                VideoExport.discard(this, ExportService.jobId(u2, currentOpts()))
                updateResume()
            }
        }.apply { visibility = View.GONE }
        box.addView(restartBtn, gap(6))

        box.addView(button(getString(R.string.export_start), true) { start() }, gap(24))
        box.addView(button(getString(R.string.ovid_button), false) { onlineVideoDialog() }, gap(10))
        box.addView(Ui.text(this, getString(R.string.ovid_hint), 12f, Ui.MUTED), gap(6))
        val ovTv = Ui.text(this, "", 13f, Ui.ACCENT)
        box.addView(ovTv, gap(6))
        val tick = object : Runnable {
            override fun run() {
                if (isDestroyed) return
                ovTv.text = when {
                    OnlineVideoState.running -> getString(R.string.ovid_title) + ": " + OnlineVideoState.status
                    OnlineVideoState.error != null -> getString(R.string.ovid_failed) + "\n" + OnlineVideoState.error
                    OnlineVideoState.result != null -> getString(R.string.ovid_done)
                    else -> ""
                }
                ui.postDelayed(this, 1500)
            }
        }
        ui.post(tick)

        // read the file and test the encoders in the background, then fill the lines in
        val u = uri
        srcInfo = null
        Thread {
            val enc = ExportInfo.testEncoders()
            val info = if (u != null) ExportInfo.probe(this, u) else null
            val srcBytes = if (u != null) sizeOf(u) else 0L
            ui.post {
                if (isDestroyed) return@post
                srcInfo = info
                srcTv.text = if (info != null) getString(
                    R.string.export_src_fmt, "${info.dispW}\u00d7${info.dispH} \u00b7 ${"%.0f".format(info.fps)} fps \u00b7 ${info.codec} \u00b7 " + fmtTime(info.durUs / 1_000_000) + (if (srcBytes > 0) " \u00b7 " + fmtBytes(srcBytes) else "")
                ) else if (u != null) getString(R.string.export_src_unknown) else ""
                updateEst(estTv, encTv)
            }
        }.start()
        updateEst(estTv, encTv)
    }

    private fun slider(max: Int, value: Int, onChange: (Int) -> Unit): android.widget.SeekBar =
        android.widget.SeekBar(this).apply {
            this.max = max
            progress = value
            progressTintList = android.content.res.ColorStateList.valueOf(Ui.ACCENT)
            thumbTintList = android.content.res.ColorStateList.valueOf(Ui.ACCENT)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Ui.STROKE)
            setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: android.widget.SeekBar, p: Int, fromUser: Boolean) {
                    if (fromUser) onChange(p)
                }

                override fun onStartTrackingTouch(s: android.widget.SeekBar) {}
                override fun onStopTrackingTouch(s: android.widget.SeekBar) {}
            })
        }

    /** The settings as they will really be used (Auto fills in the best choices for this video and this phone). */
    private fun currentOpts(): ExportOpts {
        val a = ExportInfo.autoPlan(this, srcInfo, target, anime, if (vFull) 0 else pace)
        val o0 = if (vFull) ExportOpts(a.target, a.tier, a.anime, a.hevc, a.mode or (1 shl 18), a.sharp, a.vivid, a.pace) else { // automatic: light temporal clean-up on
            val t = if (vTier == 0) a.tier else vTier - 1
            val hv = when (vEnc) { 1 -> false; 2 -> true; else -> a.hevc }
            val md = (when (vUp) { 2 -> Cfg.MODE_SGSR; 3 -> Cfg.MODE_LANCZOS; else -> Cfg.MODE_FSR }) or VideoAi.bits(vAi, vAiHalf) or VideoExport.fgBits(vFg, vFgN, vFgQ) or (vSize shl 9) or (vTemporal shl 18)
            ExportOpts(target, t, anime, hv, md, if (sharpP == 0) -1f else (sharpP - 1) / 100f, vividP / 100f, pace)
        }
        val o = if (streamOn) o0.withStream(true) else o0
        if (!rangeOn) return o
        val (s, e) = rangeUs()
        return o.withRange(s, e)
    }

    /** "14:00", "1:02:03" or a lone number of minutes -> seconds; null when it is not a time. */
    private fun parseTime(text: String): Long? {
        val t = text.trim()
        if (t.isEmpty()) return null
        return try {
            val p = t.split(':')
            when (p.size) {
                1 -> (p[0].trim().toDouble() * 60).toLong()
                2 -> p[0].trim().toLong() * 60 + p[1].trim().toLong()
                3 -> p[0].trim().toLong() * 3600 + p[1].trim().toLong() * 60 + p[2].trim().toLong()
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }

    /** The chosen part in microseconds: (start, end); an empty or wrong end means "to the end of the video". */
    private fun rangeUs(): Pair<Long, Long> {
        val s = (parseTime(rangeFrom) ?: 0L).coerceAtLeast(0L) * 1_000_000L
        val e = (parseTime(rangeTo) ?: 0L).coerceAtLeast(0L) * 1_000_000L
        return Pair(s, if (e > s) e else 0L)
    }

    /** Switch + two time fields (from / to) + "next part": upscale only a part, for example minute 14 to 19. */
    private fun addRangeSection(estTv: TextView, encTv: TextView) {
        box.addView(Ui.text(this, getString(R.string.export_range_title), 13f, Ui.ACCENT, true), gap(18))
        val rb = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        rb.visibility = if (rangeOn) View.VISIBLE else View.GONE
        box.addView(panelSwitch(this, getString(R.string.export_range_switch), rangeOn) {
            rangeOn = it
            rb.visibility = if (it) View.VISIBLE else View.GONE
            updateEst(estTv, encTv)
        }, gap(6))
        box.addView(Ui.text(this, getString(R.string.export_range_hint), 12f, Ui.MUTED), gap(2))
        box.addView(rb, gap(4))

        fun field(hint: String, value: String, onText: (String) -> Unit) = android.widget.EditText(this).apply {
            setSingleLine()
            this.hint = hint
            setText(value)
            inputType = android.text.InputType.TYPE_CLASS_DATETIME or android.text.InputType.TYPE_DATETIME_VARIATION_TIME
            setTextColor(Ui.TEXT)
            setHintTextColor(Ui.MUTED)
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) {
                    onText(s?.toString() ?: "")
                    updateEst(estTv, encTv)
                }
            })
        }
        val row = LinearLayout(this)
        val fromEt = field(getString(R.string.export_range_from), rangeFrom) { rangeFrom = it }
        val toEt = field(getString(R.string.export_range_to), rangeTo) { rangeTo = it }
        row.addView(fromEt, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(Ui.text(this, "  \u2192  ", 16f, Ui.MUTED), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        row.addView(toEt, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        rb.addView(row)
        rb.addView(button(getString(R.string.export_range_next), false) {
            val s = parseTime(rangeFrom) ?: 0L
            val e = parseTime(rangeTo)
            if (e == null || e <= s) {
                Toast.makeText(this, R.string.export_range_need_end, Toast.LENGTH_SHORT).show()
            } else {
                val next = nextRange(s, e, (srcInfo?.durUs ?: 0L) / 1_000_000L)
                if (next == null) Toast.makeText(this, R.string.export_range_last, Toast.LENGTH_SHORT).show()
                else {
                    rangeFrom = fmtTime(next.first)
                    rangeTo = fmtTime(next.second)
                    fromEt.setText(rangeFrom)
                    toEt.setText(rangeTo)
                }
            }
        }, gap(10))
    }

    /** File or stream: stream makes only a few minutes ahead of the viewer and deletes what was watched (little free space needed). */
    /** Offline AI model for short videos (Light / Medium / Heavy), with the model download and a speed test. */
    private fun addAiSection(estTv: TextView, encTv: TextView, into: LinearLayout) {
        into.addView(panelSection(this, getString(R.string.export_ai_sec)), gap(18))
        into.addView(Ui.text(this, getString(R.string.export_ai), 13f, Ui.ACCENT, true), gap(8))
        val status = Ui.text(this, "", 12f, Ui.MUTED)
        val dl = button(getString(R.string.export_ai_download), false) { }
        val test = button(getString(R.string.export_ai_test), false) { }
        val rate = chips(listOf(getString(R.string.export_ai_rate_full), getString(R.string.export_ai_rate_half)), if (vAiHalf) 1 else 0) {
            vAiHalf = it == 1
            updateEst(estTv, encTv)
        }
        fun autoPick() {
            val i = srcInfo ?: return
            val frames = (if (rangeOn) { val (a, b) = rangeUs(); (if (b > a) b - a else (i.durUs - a).coerceAtLeast(0L)) } else i.durUs) / 1e6 * i.fps
            val (l, h) = VideoAiAuto.pick(this, i.dispW, i.dispH, frames)
            vAi = l
            vAiHalf = h
        }
        fun refresh() {
            if (vAiAuto) autoPick()
            val on = vAi > 0
            status.visibility = if (on) View.VISIBLE else View.GONE
            rate.visibility = if (on) View.VISIBLE else View.GONE
            if (!on) {
                dl.visibility = View.GONE
                test.visibility = View.GONE
                return
            }
            val id = VideoAi.modelFor(this, vAi)
            if (id != null) {
                val i = srcInfo
                val spf = if (i != null) VideoAi.secPerFrame(this, i.dispW, i.dispH, vAi) else 0f
                val cat = AiSr.CATALOG.firstOrNull { it.id == id }
                status.text = (if (vAiAuto) getString(R.string.export_ai_auto_fmt, levelLabel(vAi), if (vAiHalf) " · " + getString(R.string.export_ai_rate_half) else "") + "\n" else "") +
                    getString(R.string.export_ai_ready_fmt, cat?.label ?: id, spf)
                dl.visibility = View.GONE
                test.visibility = View.VISIBLE
            } else {
                val cat = VideoAi.catalogFor(vAi).first()
                status.text = getString(R.string.export_ai_missing_fmt, cat.label, cat.sizeKb / 1024f)
                dl.visibility = View.VISIBLE
                test.visibility = View.GONE
            }
        }
        val labels = VideoAi.UI_LEVELS.map { levelLabel(it) } + getString(R.string.export_ai_auto)
        val sel = if (vAiAuto) labels.size - 1 else VideoAi.UI_LEVELS.indexOf(vAi).coerceAtLeast(0)
        into.addView(chips(labels, sel) {
            vAiAuto = it == labels.size - 1
            if (vAiAuto) {
                vAi = 3
                vAiHalf = false
            } else {
                vAi = VideoAi.UI_LEVELS[it]
            }
            refresh()
            updateEst(estTv, encTv)
        }, gap(6))
        into.addView(Ui.text(this, getString(R.string.export_ai_hint), 12f, Ui.MUTED), gap(6))
        into.addView(status, gap(6))
        into.addView(rate, gap(6))
        into.addView(dl, gap(6))
        into.addView(test, gap(6))
        dl.setOnClickListener {
            val cat = VideoAi.catalogFor(vAi).firstOrNull() ?: return@setOnClickListener
            dl.isEnabled = false
            Thread {
                val err = runCatching { AiSr.installCatalog(this, cat) { p -> ui.post { status.text = getString(R.string.export_ai_downloading_fmt, cat.label, p) } } }.exceptionOrNull()
                ui.post {
                    dl.isEnabled = true
                    if (err != null) Toast.makeText(this, (err.message ?: "download failed").take(200), Toast.LENGTH_LONG).show()
                    refresh()
                    updateEst(estTv, encTv)
                }
            }.start()
        }
        test.setOnClickListener {
            val id = VideoAi.modelFor(this, vAi) ?: return@setOnClickListener
            test.isEnabled = false
            status.text = getString(R.string.export_ai_testing)
            Thread {
                val r = runCatching { AiSr.msPerTile(this, id) }
                ui.post {
                    test.isEnabled = true
                    r.getOrNull()?.let { VideoAi.saveMs(this, id, it) }
                    if (r.isFailure) Toast.makeText(this, (r.exceptionOrNull()?.message ?: "test failed").take(200), Toast.LENGTH_LONG).show()
                    refresh()
                    updateEst(estTv, encTv)
                }
            }.start()
        }
        refresh()
    }

    private fun addStreamSection(estTv: TextView, encTv: TextView) {
        box.addView(Ui.text(this, getString(R.string.export_stream_title), 13f, Ui.ACCENT, true), gap(18))
        // "how much to keep" only means something when watching now, so it is shown only for that choice
        val keep = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        keep.visibility = if (streamOn) View.VISIBLE else View.GONE
        box.addView(chips(listOf(getString(R.string.export_out_file), getString(R.string.export_out_stream)), if (streamOn) 1 else 0) {
            streamOn = it == 1
            keep.visibility = if (streamOn) View.VISIBLE else View.GONE
            updateEst(estTv, encTv)
        }, gap(6))
        box.addView(Ui.text(this, getString(R.string.export_stream_hint), 12f, Ui.MUTED), gap(6))
        val sp = getSharedPreferences("crsc", Context.MODE_PRIVATE)
        val ahead = intArrayOf(0, 30, 60, 120, 300, 600)
        val behind = intArrayOf(0, 10, 30, 60, 120)
        fun kgap(v: Int) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@ExportActivity, v) }
        keep.addView(Ui.text(this, getString(R.string.export_stream_ahead), 13f, Ui.TEXT, true), kgap(10))
        keep.addView(chips(listOf(getString(R.string.export_auto), "30 s", "1 min", "2 min", "5 min", "10 min"), ahead.indexOf(sp.getInt("stream_ahead_s", 0)).coerceAtLeast(0)) {
            sp.edit().putInt("stream_ahead_s", ahead[it]).apply()
        }, kgap(6))
        keep.addView(Ui.text(this, getString(R.string.export_stream_behind), 13f, Ui.TEXT, true), kgap(10))
        keep.addView(chips(listOf(getString(R.string.export_auto), "10 s", "30 s", "1 min", "2 min"), behind.indexOf(sp.getInt("stream_behind_s", 0)).coerceAtLeast(0)) {
            sp.edit().putInt("stream_behind_s", behind[it]).apply()
        }, kgap(6))
        keep.addView(Ui.text(this, getString(R.string.export_stream_keep_hint), 12f, Ui.MUTED), kgap(6))
        box.addView(keep, gap(0))
    }

    /** The part right after [s]..[e] with the same length (cut at the end of the video); null when the video is over. */
    private fun nextRange(s: Long, e: Long, durSec: Long): Pair<Long, Long>? {
        if (durSec > 0 && e >= durSec) return null
        var ne = e + (e - s)
        if (durSec > 0 && ne > durSec) ne = durSec
        return Pair(e, ne)
    }

    /** Shows how much of an unfinished export of this video (same settings) is already done. */
    private fun updateResume() {
        val u = uri
        val tv = resumeTv ?: return
        val rb = restartBtn ?: return
        val ro = currentOpts()
        val done = if (u != null) (VideoExport.doneUs(this, ExportService.jobId(u, ro)) - ro.rangeStartUs).coerceAtLeast(0L) else 0L
        if (done > 0L) {
            val total = srcInfo?.let { ExportInfo.spanUs(it, ro) } ?: 0L
            tv.text = getString(R.string.export_resume_found_fmt, fmtTime(done / 1_000_000), if (total > 0) fmtTime(total / 1_000_000) else "?")
            tv.visibility = View.VISIBLE
            rb.visibility = View.VISIBLE
        } else {
            tv.visibility = View.GONE
            rb.visibility = View.GONE
        }
    }

    private fun updateEst(estTv: TextView, encTv: TextView) {
        updateResume()
        val enc = ExportInfo.encoders
        encTv.text = if (enc == null) getString(R.string.export_enc_testing) else getString(
            R.string.export_enc_support_fmt,
            enc.joinToString("  ") { e -> e.label + " " + (if (e.works) (if (e.hardware) "\u2713 hw" else "\u2713 sw") else "\u2717") }
        )
        val i = srcInfo
        if (i == null) {
            estTv.text = getString(R.string.export_est_unknown)
            fgInfoTv?.text = ""
            return
        }
        val o = currentOpts()
        val fgN = VideoExport.fgFactor(o.mode)
        fgInfoTv?.text = if (fgN > 1) getString(R.string.export_fg_info_fmt, "%.0f".format(i.fps), "%.0f".format(i.fps * fgN), fgN)
        else getString(R.string.export_fg_info_off_fmt, "%.0f".format(i.fps))
        val (ow, oh) = ExportInfo.outSize(i, o.target)
        val sec = ExportInfo.estimateSec(this, i, o)
        val dur = (ExportInfo.spanUs(i, o) / 1_000_000L).coerceAtLeast(1L)
        val ratio = sec.toFloat() / dur
        val load = getString(if (ratio < 0.8f) R.string.export_load_light else if (ratio < 2.5f) R.string.export_load_medium else R.string.export_load_heavy)
        val mb = ExportInfo.sizeBytes(i, o) / (1024 * 1024)
        val sb = StringBuilder()
        if (rangeOn) {
            val span = ExportInfo.spanUs(i, o) / 1_000_000L
            sb.append(getString(R.string.export_range_est_fmt, fmtTime(o.rangeStartUs / 1_000_000L), if (o.rangeEndUs > 0L) fmtTime(o.rangeEndUs / 1_000_000L) else getString(R.string.export_range_end_word), fmtTime(span))).append('\n')
        }
        sb.append(getString(R.string.export_out_fmt, ow, oh, if (o.hevc) "H.265" else "H.264", mb.toString()))
        sb.append('\n').append(getString(R.string.export_time_fmt, fmtTime(sec), if (ExportInfo.measuredMpx(this) > 0f) "" else getString(R.string.export_time_rough)))
        sb.append('\n').append(getString(R.string.export_load_fmt, load))
        sb.append('\n').append(getString(R.string.export_auto_picked_fmt, getString(when (o.tier) { 0 -> R.string.export_tier_fast; 2 -> R.string.export_tier_high; 3 -> R.string.export_tier_max; else -> R.string.export_tier_med }), if (o.hevc) "H.265" else "H.264"))
        if (i.shortSide >= o.target) sb.append('\n').append(getString(R.string.export_no_upscale))
        if (streamOn) sb.append('\n').append(getString(R.string.export_stream_note))
        estTv.text = sb.toString()
    }

    private fun vTierDesc() = getString(
        when (vTier) {
            0 -> R.string.export_auto_hint
            1 -> R.string.export_tier_fast_desc
            3 -> R.string.export_tier_high_desc
            4 -> R.string.export_tier_max_desc
            else -> R.string.export_tier_med_desc
        }
    )

    private fun tierDesc() = getString(
        when (tier) {
            0 -> R.string.export_tier_fast_desc
            2 -> R.string.export_tier_high_desc
            else -> R.string.export_tier_med_desc
        }
    )

    private fun finishedCard(): View {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.round(Ui.CARD, dp(this@ExportActivity, 14).toFloat())
            setPadding(dp(this@ExportActivity, 14), dp(this@ExportActivity, 12), dp(this@ExportActivity, 14), dp(this@ExportActivity, 12))
        }
        val r = ExportState.result
        val err = ExportState.error
        when {
            r != null -> {
                c.addView(
                    Ui.text(
                        this,
                        if (ExportState.partial) getString(R.string.export_partial_done_fmt, fmtTime(ExportState.doneUs / 1_000_000), fmtTime(ExportState.totalUs / 1_000_000))
                        else getString(R.string.export_done),
                        14f, Ui.OK, true
                    )
                )
                ExportState.job?.let { j ->
                    if (j.rangeEndUs > 0L && !ExportState.partial) {
                        val next = nextRange(j.rangeStartUs / 1_000_000L, j.rangeEndUs / 1_000_000L, (srcInfo?.durUs ?: 0L) / 1_000_000L)
                        if (next != null) c.addView(
                            button(getString(R.string.export_range_next_fmt, fmtTime(next.first), fmtTime(next.second)), false) {
                                rangeOn = true
                                rangeFrom = fmtTime(next.first)
                                rangeTo = fmtTime(next.second)
                                refresh()
                            },
                            gap(10)
                        )
                    }
                }
                val outSz = sizeOf(r)
                val srcSz = ExportState.job?.let { sizeOf(Uri.parse(it.uri)) } ?: 0L
                if (outSz > 0) c.addView(
                    Ui.text(this, if (srcSz > 0) getString(R.string.export_size_done_fmt, fmtBytes(outSz), fmtBytes(srcSz)) else getString(R.string.export_size_only_fmt, fmtBytes(outSz)), 13f, Ui.TEXT),
                    gap(4)
                )
                if (AudioNote.skipped) c.addView(Ui.text(this, getString(R.string.export_nosound), 12f, Ui.MUTED), gap(4))
                c.addView(button(getString(R.string.export_open), false) { openResult(r) }, gap(10))
                c.addView(button(getString(R.string.share), false) { Share.share(this, listOf(r)) }, gap(8))
            }
            ExportState.paused -> c.addView(
                Ui.text(this, getString(R.string.export_paused_msg_fmt, fmtTime(ExportState.doneUs / 1_000_000), fmtTime(ExportState.totalUs / 1_000_000)), 14f, Ui.OK, true)
            )
            err != null -> c.addView(Ui.text(this, getString(R.string.export_failed_fmt, err), 13f, Ui.DANGER))
            ExportState.cancelled -> c.addView(Ui.text(this, getString(R.string.export_cancelled), 14f, Ui.MUTED))
        }
        return c
    }

    /** "Unfinished upscale: name, 12:30 of 45:00 done" with Continue / Discard, for a paused, failed or interrupted job. */
    private fun unfinishedCard(): View? {
        val j = ExportInfo.unfinished(this) ?: return null
        val done = (VideoExport.doneUs(this, j.id) - j.rangeStartUs).coerceAtLeast(0L)
        if (done <= 0L) {
            ExportInfo.clearUnfinished(this)
            return null
        }
        val total = (if (j.rangeEndUs > 0L) j.rangeEndUs else VideoExport.totalUs(this, j.id)) - j.rangeStartUs
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.round(Ui.CARD, dp(this@ExportActivity, 14).toFloat())
            setPadding(dp(this@ExportActivity, 14), dp(this@ExportActivity, 12), dp(this@ExportActivity, 14), dp(this@ExportActivity, 12))
        }
        c.addView(Ui.text(this, getString(R.string.export_unfinished_title), 14f, Ui.ACCENT, true))
        c.addView(Ui.text(this, j.name, 15f, Ui.TEXT, true), gap(4))
        c.addView(
            Ui.text(
                this,
                getString(R.string.export_unfinished_fmt, fmtTime(done / 1_000_000), if (total > 0) fmtTime(total / 1_000_000) else "?", fmtBytes(VideoExport.bytesSoFar(this, j.id))),
                13f, Ui.MUTED
            ),
            gap(4)
        )
        val row = LinearLayout(this)
        row.addView(button(getString(R.string.export_continue), true) {
            if (ExportState.running) Toast.makeText(this, R.string.export_busy, Toast.LENGTH_SHORT).show()
            else {
                ExportService.resume(this, j)
                ui.postDelayed({ refresh() }, 300)
            }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(button(getString(R.string.export_discard), false) {
            AlertDialog.Builder(this)
                .setMessage(R.string.export_discard_ask)
                .setPositiveButton(android.R.string.ok) { _, _ ->
                    VideoExport.discard(this, j.id)
                    ExportInfo.clearUnfinished(this)
                    refresh()
                }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(this@ExportActivity, 8) })
        c.addView(row, gap(10))
        return c
    }

    // ---- GIF: upscaled frame by frame, saved as an MP4 -----------------------------------------------

    private fun gifOpts(info: GifInfo?): GifOpts {
        if (!autoMode) return GifOpts(target, tier, anime, upMode, if (sharpP == 0) -1f else (sharpP - 1) / 100f, vividP / 100f)
        // Auto: the strongest cleanup that still finishes in a few minutes
        var t = 2
        if (info != null) while (t > 0 && GifExport.estimateSec(this, info, GifOpts(target, t, anime)) > 600) t--
        return GifOpts(target, t, anime)
    }

    private fun showGifConfig() {
        box.addView(Ui.text(this, getString(R.string.export_title), 22f, Ui.TEXT, true))
        box.addView(Ui.text(this, getString(R.string.export_gif_note), 13f, Ui.MUTED), gap(8))
        box.addView(Ui.text(this, name, 15f, Ui.TEXT, true), gap(16))
        val srcTv = Ui.text(this, "", 12f, Ui.MUTED)
        box.addView(srcTv, gap(4))
        box.addView(button(getString(R.string.export_pick), false) { pick() }, gap(8))
        val estTv = Ui.text(this, "", 13f, Ui.TEXT)
        var info: GifInfo? = null

        fun est() {
            val i = info
            if (i == null) {
                estTv.text = getString(R.string.export_est_unknown)
                return
            }
            val o = gifOpts(i)
            val (ow, oh) = GifExport.outSize(i, o.target)
            val sec = GifExport.estimateSec(this, i, o)
            val dur = (i.durMs / 1000L).coerceAtLeast(1L)
            val load = getString(if (sec.toFloat() / dur < 4f) R.string.export_load_light else if (sec.toFloat() / dur < 20f) R.string.export_load_medium else R.string.export_load_heavy)
            val sb = StringBuilder()
            sb.append(getString(R.string.export_gif_out_fmt, ow, oh, fmtBytes(GifExport.sizeBytes(i, o))))
            sb.append('\n').append(getString(R.string.export_time_fmt, fmtTime(sec), if (ExportInfo.measuredMpx(this) > 0f) "" else getString(R.string.export_time_rough)))
            sb.append('\n').append(getString(R.string.export_load_fmt, load))
            if (autoMode) sb.append('\n').append(getString(R.string.export_auto_picked_gif_fmt, getString(when (o.tier) { 0 -> R.string.export_tier_fast; 2 -> R.string.export_tier_high; else -> R.string.export_tier_med })))
            if (min(i.w, i.h) >= o.target) sb.append('\n').append(getString(R.string.export_no_upscale))
            estTv.text = sb.toString()
        }

        box.addView(Ui.text(this, getString(R.string.export_target), 13f, Ui.ACCENT, true), gap(18))
        val targets = intArrayOf(480, 720, 1080, 1440)
        box.addView(chips(listOf("480p", "720p", "1080p", "1440p"), targets.indexOf(target).coerceAtLeast(0)) {
            target = targets[it]
            est()
        }, gap(6))

        box.addView(Ui.text(this, getString(R.string.export_settings_mode), 13f, Ui.ACCENT, true), gap(16))
        val manualBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        manualBox.visibility = if (autoMode) View.GONE else View.VISIBLE
        val autoHint = Ui.text(this, getString(R.string.export_auto_hint), 12f, Ui.MUTED)
        autoHint.visibility = if (autoMode) View.VISIBLE else View.GONE
        box.addView(chips(listOf(getString(R.string.export_auto), getString(R.string.export_manual)), if (autoMode) 0 else 1) {
            autoMode = it == 0
            manualBox.visibility = if (autoMode) View.GONE else View.VISIBLE
            autoHint.visibility = if (autoMode) View.VISIBLE else View.GONE
            est()
        }, gap(6))
        box.addView(autoHint, gap(6))
        box.addView(manualBox, gap(0))

        manualBox.addView(Ui.text(this, getString(R.string.export_tier), 13f, Ui.ACCENT, true), gap(16))
        val desc = Ui.text(this, tierDesc(), 12f, Ui.MUTED)
        manualBox.addView(chips(listOf(getString(R.string.export_tier_fast), getString(R.string.export_tier_med), getString(R.string.export_tier_high)), tier) {
            tier = it
            desc.text = tierDesc()
            est()
        }, gap(6))
        manualBox.addView(desc, gap(6))

        box.addView(Ui.text(this, getString(R.string.export_content), 13f, Ui.ACCENT, true), gap(16))
        box.addView(chips(listOf(getString(R.string.export_content_video), getString(R.string.export_content_anime)), if (anime) 1 else 0) {
            anime = it == 1
            est()
        }, gap(6))

        manualBox.addView(Ui.text(this, getString(R.string.export_upscaler), 13f, Ui.ACCENT, true), gap(16))
        manualBox.addView(chips(listOf("FSR 1", "SGSR 1"), if (upMode == Cfg.MODE_SGSR) 1 else 0) { upMode = if (it == 1) Cfg.MODE_SGSR else Cfg.MODE_FSR }, gap(6))

        val sharpTv = Ui.text(this, "", 14f, Ui.TEXT)
        fun sharpText(p: Int) = getString(R.string.export_sharp_fmt, if (p == 0) getString(R.string.export_auto_word) else "${p - 1}%")
        sharpTv.text = sharpText(sharpP)
        manualBox.addView(sharpTv, gap(16))
        manualBox.addView(slider(101, sharpP) { sharpP = it; sharpTv.text = sharpText(it) }, gap(2))
        val vividTv = Ui.text(this, "", 14f, Ui.TEXT)
        vividTv.text = getString(R.string.export_vivid_fmt, vividP)
        manualBox.addView(vividTv, gap(14))
        manualBox.addView(slider(100, vividP) { vividP = it; vividTv.text = getString(R.string.export_vivid_fmt, it) }, gap(2))

        box.addView(Ui.text(this, getString(R.string.export_est_title), 13f, Ui.ACCENT, true), gap(18))
        box.addView(estTv, gap(6))
        box.addView(button(getString(R.string.export_start), true) { startGif(info) }, gap(24))

        val u = uri
        Thread {
            val gi = if (u != null) GifExport.probe(this, u) else null
            val bytes = if (u != null) sizeOf(u) else 0L
            ui.post {
                if (isDestroyed) return@post
                info = gi
                srcTv.text = if (gi != null) getString(
                    R.string.export_gif_src_fmt, gi.w, gi.h, fmtTime((gi.durMs / 1000).toLong()) + (if (bytes > 0) " \u00b7 " + fmtBytes(bytes) else ""), gi.frames
                ) else getString(R.string.export_gif_not_animated)
                est()
            }
        }.start()
        est()
    }

    private fun startGif(info: GifInfo?) {
        val u = uri
        if (u == null) {
            Toast.makeText(this, R.string.export_need_video, Toast.LENGTH_SHORT).show()
            return
        }
        if (info == null) {
            Toast.makeText(this, R.string.export_gif_not_animated, Toast.LENGTH_LONG).show()
            return
        }
        val o = gifOpts(info)
        cancelGif.set(false)
        val tv = Ui.text(this, "…", 14f, Ui.TEXT).apply { setPadding(dp(this@ExportActivity, 22), dp(this@ExportActivity, 8), dp(this@ExportActivity, 22), 0) }
        val dlg = AlertDialog.Builder(this)
            .setTitle(R.string.export_notif_title)
            .setView(tv)
            .setCancelable(false)
            .setNegativeButton(android.R.string.cancel) { _, _ -> cancelGif.set(true) }
            .create()
        dlg.show()
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Thread {
            var res: Uri? = null
            var err: String? = null
            try {
                res = GifExport.run(this, u, name, o, cancelGif) { n, t -> ui.post { tv.text = getString(R.string.export_gif_working, n, t) } }
            } catch (t: Throwable) {
                err = if (cancelGif.get()) null else (t.message ?: t.javaClass.simpleName)
            }
            ui.post {
                window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                if (isDestroyed) return@post
                runCatching { dlg.dismiss() }
                if (res != null) {
                    val r = res
                    AlertDialog.Builder(this)
                        .setMessage(getString(R.string.export_gif_done_fmt, fmtBytes(sizeOf(r))))
                        .setPositiveButton(R.string.export_open) { _, _ -> openResult(r) }
                        .setNegativeButton(android.R.string.ok, null)
                        .show()
                } else if (err != null) {
                    AlertDialog.Builder(this).setMessage(getString(R.string.export_failed_fmt, err)).setPositiveButton(android.R.string.ok, null).show()
                }
            }
        }.start()
    }

    private fun fmtBytes(b: Long): String = when {
        b >= 1L shl 30 -> String.format("%.2f GB", b / 1073741824.0)
        b >= 1L shl 20 -> String.format("%.1f MB", b / 1048576.0)
        b >= 1L shl 10 -> String.format("%d KB", b shr 10)
        else -> "$b B"
    }

    /** Size of a file in bytes (0 when the provider does not tell). */
    private fun sizeOf(u: Uri): Long = runCatching {
        contentResolver.query(u, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { if (it.moveToFirst()) it.getLong(0) else 0L }
    }.getOrNull() ?: 0L

    private fun showProgress() {
        val j = ExportState.job
        box.addView(Ui.text(this, getString(R.string.export_title), 22f, Ui.TEXT, true))
        box.addView(Ui.text(this, j?.name ?: "", 15f, Ui.TEXT, true), gap(10))
        val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000 }
        bar = pb
        box.addView(pb, gap(14))
        lineA = Ui.text(this, "", 15f, Ui.TEXT, true).also { box.addView(it, gap(8)) }
        lineB = Ui.text(this, "", 13f, Ui.MUTED).also { box.addView(it, gap(4)) }
        lineC = Ui.text(this, "", 13f, Ui.MUTED).also { box.addView(it, gap(4)) }
        val w = button(getString(R.string.export_watch), false) { watchParts() }
        watchBtn = w
        box.addView(w, gap(18))
        if (j?.stream == true) {
            box.addView(Ui.text(this, getString(R.string.export_stream_running), 12f, Ui.MUTED), gap(10))
        } else {
            box.addView(button(getString(R.string.export_pause), false) { ExportService.pause(this) }, gap(10))
            box.addView(button(getString(R.string.export_save_partial), false) {
                AlertDialog.Builder(this)
                    .setMessage(R.string.export_save_partial_ask)
                    .setPositiveButton(android.R.string.ok) { _, _ -> ExportService.saveAndStop(this) }
                    .setNegativeButton(android.R.string.cancel, null)
                    .show()
            }, gap(10))
        }
        box.addView(button(getString(R.string.export_cancel), false) {
            AlertDialog.Builder(this)
                .setMessage(R.string.export_cancel_ask)
                .setPositiveButton(android.R.string.ok) { _, _ -> ExportService.cancel(this) }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        }, gap(10))
        box.addView(Ui.text(this, getString(R.string.export_bg_hint), 12f, Ui.MUTED), gap(14))
        update()
    }

    private fun levelLabel(l: Int) = getString(
        when (l) {
            0 -> R.string.export_ai_off
            4 -> R.string.export_ai_vlight
            1 -> R.string.export_ai_light
            2 -> R.string.export_ai_medium
            else -> R.string.export_ai_heavy
        }
    )

    private fun fmtTime(sec: Long): String {
        val s = sec.coerceAtLeast(0)
        return if (s >= 3600) String.format("%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60) else String.format("%d:%02d", s / 60, s % 60)
    }

    private fun update() {
        if (shownRunning != ExportState.running) {
            refresh()
            return
        }
        if (!ExportState.running) return
        val total = ExportState.totalUs
        val done = ExportState.doneUs
        val pct = if (total > 0) (done * 1000 / total).toInt().coerceIn(0, 1000) else 0
        bar?.progress = pct
        lineA?.text = getString(R.string.export_progress_fmt, pct / 10, fmtTime(done / 1_000_000), fmtTime(total / 1_000_000))
        val sp = ExportState.speed
        lineB?.text = if (sp > 0f && total > 0) {
            val left = ((total - done) / 1_000_000f / sp).toLong()
            getString(R.string.export_speed_fmt, sp, fmtTime(left))
        } else getString(R.string.export_speed_wait)
        val n = ExportState.segs.size
        val soFar = ExportState.segs.sumOf { it.file.length() }
        lineC?.text = getString(R.string.export_pieces_fmt, n) +
            (if (soFar > 0) "\n" + (if (done > 0) getString(R.string.export_size_fmt, fmtBytes(soFar), fmtBytes(soFar * total / done)) else getString(R.string.export_size_only_fmt, fmtBytes(soFar))) else "")
        watchBtn?.alpha = if (n > 0) 1f else 0.4f
        lastSegCount = n
        val ready = ExportState.segs.sumOf { it.durUs } / 1_000_000f
        val need = if (sp >= 1.2f || sp <= 0f) 6f else (20f / sp).coerceIn(8f, 120f) // slower than the video: wait for a bigger head start
        if (ExportState.job?.stream == true && n >= 1 && ready >= need && !streamLaunched) {
            streamLaunched = true // the player opens by itself when the first piece is ready
            watchParts()
        }
    }

    // ---- actions ----------------------------------------------------------------------------------

    private fun pick() {
        AlertDialog.Builder(this)
            .setItems(arrayOf(getString(R.string.export_pick_lib), getString(R.string.export_pick_lib_gif), getString(R.string.export_pick_files))) { _, w ->
                @Suppress("DEPRECATION")
                if (w < 2) {
                    startActivityForResult(
                        Intent(this, LibraryActivity::class.java).putExtra(LibraryArgs.PICK, true).putExtra(LibraryArgs.PICK_TAB, if (w == 0) 0 else 3), REQ_LIB
                    )
                } else {
                    val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
                        .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("video/*", "image/gif"))
                    startActivityForResult(i, REQ_PICK)
                }
            }
            .show()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val u = data?.data
        if (req == REQ_LIB && res == RESULT_OK && u != null) {
            setSource(u, data.getStringExtra(LibraryArgs.NAME) ?: nameOf(u))
            refresh()
        }
        if (req == REQ_PICK && res == RESULT_OK && u != null) {
            runCatching { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            setSource(u, nameOf(u))
            refresh()
        }
    }

    private fun onlineVideoDialog() {
        val u = uri
        if (u == null) {
            Toast.makeText(this, R.string.export_need_video, Toast.LENGTH_SHORT).show()
            return
        }
        if (OnlineVideoState.running) {
            Toast.makeText(this, R.string.export_busy, Toast.LENGTH_SHORT).show()
            return
        }
        if (!Online.hasKey(this)) {
            Online.showSettings(this)
            return
        }
        val names = OnlineVideo.RESOLUTIONS
        var pick = 1
        AlertDialog.Builder(this)
            .setTitle(R.string.ovid_title)
            .setMessage(getString(R.string.ovid_confirm, Online.videoModel(this), OnlineVideo.MAX_UPLOAD shr 20))
            .setSingleChoiceItems(names.toTypedArray(), pick) { _, w -> pick = w }
            .setPositiveButton(R.string.export_start) { _, _ ->
                val (s, e) = if (rangeOn) rangeUs() else (0L to 0L)
                OnlineVideoService.start(this, u, name, s, e, names[pick])
            }
            .setNeutralButton(R.string.online_settings) { _, _ -> Online.showSettings(this) }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun start() {
        val u = uri
        if (u == null) {
            Toast.makeText(this, R.string.export_need_video, Toast.LENGTH_SHORT).show()
            return
        }
        if (ExportState.running) {
            Toast.makeText(this, R.string.export_busy, Toast.LENGTH_SHORT).show()
            return
        }
        if (rangeOn) {
            val s = parseTime(rangeFrom) ?: 0L
            val e = parseTime(rangeTo)
            val dur = (srcInfo?.durUs ?: 0L) / 1_000_000L
            if ((e != null && e <= s) || (rangeTo.isNotBlank() && e == null) || (rangeFrom.isNotBlank() && parseTime(rangeFrom) == null) || (dur > 0 && s >= dur)) {
                Toast.makeText(this, R.string.export_range_invalid, Toast.LENGTH_LONG).show()
                return
            }
        }
        if (vAiAuto) {
            srcInfo?.let { i ->
                val frames = (if (rangeOn) { val (a, b) = rangeUs(); (if (b > a) b - a else (i.durUs - a).coerceAtLeast(0L)) } else i.durUs) / 1e6 * i.fps
                val (l, h) = VideoAiAuto.pick(this, i.dispW, i.dispH, frames)
                vAi = l
                vAiHalf = h
            }
        }
        if (vAi > 0 && VideoAi.modelFor(this, vAi) == null) {
            Toast.makeText(this, R.string.export_ai_need_model, Toast.LENGTH_LONG).show()
            return
        }
        streamLaunched = false
        ExportService.start(this, u, name, currentOpts())
        ui.postDelayed({ refresh() }, 300)
    }

    private fun parts(): ArrayList<String> = ArrayList(ExportState.segs.sortedBy { it.startUs }.map { Uri.fromFile(it.file).toString() })

    private fun watchParts() {
        val l = parts()
        if (l.isEmpty()) {
            Toast.makeText(this, R.string.export_no_parts, Toast.LENGTH_SHORT).show()
            return
        }
        val i = Intent(this, PlayerActivity::class.java).setData(Uri.parse(l[0])).putExtra(PlayerArgs.FROM_LIB, true)
        if (ExportState.job?.stream == true) {
            i.putExtra(PlayerArgs.STREAM, true)
        } else if (l.size > 1) {
            i.putExtra(PlayerArgs.INDEX, 0)
            i.putStringArrayListExtra(PlayerArgs.LIST, l)
        }
        startActivity(i)
    }

    private fun openResult(r: Uri) {
        startActivity(Intent(this, PlayerActivity::class.java).setData(r).putExtra(PlayerArgs.FROM_LIB, true))
    }

    companion object {
        const val X_NAME = "app.clearoverlay.EXPORT_NAME"
        /** The order of the frame generation levels on screen (3 = very light is listed first). */
        private val FG_Q_ORDER = intArrayOf(3, 0, 1, 2)
        private const val REQ_PICK = 31
        private const val REQ_LIB = 33
    }
}
