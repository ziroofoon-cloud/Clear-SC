package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.min

/**
 * "Upscale a video to a new file": pick the size and the quality, start, watch the progress. The work itself runs in
 * [ExportService]; this screen only shows [ExportState] and can be closed and opened again at any time.
 */
class ExportActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var box: LinearLayout
    private var uri: Uri? = null
    private var name = ""
    private var target = 1080
    private var tier = 1
    private var anime = false
    private var hevc = false
    private var upMode = Cfg.MODE_FSR
    private var autoMode = true
    /** Video quality: 0 Auto, 1 Fast, 2 Balanced, 3 Best, 4 Maximum. Upscaler: 0 Auto, 1 FSR 1, 2 SGSR 1. Encoder: 0 Auto, 1 H.264, 2 H.265. */
    private var vTier = 0
    private var vUp = 0
    private var vFg = false
    private var vFull = false
    private var vFix = false
    private var vTemporal = 0
    private var vCrsc = 1
    private var fgInfoTv: TextView? = null
    private var vAi = 0
    private var vAiAuto = false
    private var vAiHalf = false
    private var vSize = 0
    private var vFgN = 2
    private var vFgQ = 1
    private var vEnc = 0
    private var pace = 0
    private var sharpP = 0
    private var vividP = 0
    /** The newer picture settings (see [Look]); they go into the file like Sharpness / Vivid colours. */
    private var look = Look()
    private var srcInfo: SrcInfo? = null
    private var shownRunning: Boolean? = null
    private var lastSegCount = -1

    // progress widgets
    private var bar: ProgressBar? = null
    private var lineA: TextView? = null
    private var lineB: TextView? = null
    private var lineC: TextView? = null
    private var watchBtn: TextView? = null
    private var resumeTv: TextView? = null
    private var isGif = false
    /** Started from the Library's "Save": the live settings of this kind of file are used and the export starts by itself. */
    private var liveStart = false
    // "only a part of the video": the texts as typed ("14:00"), so they survive rebuilding the screen
    private var rangeOn = false
    private var streamOn = false

    /** "Smooth live" (a kind of Watch now): the player's own settings, made ahead at the size of the screen. */
    private var liveOn = false
    private var rangeFrom = ""
    private var rangeTo = ""
    private val cancelGif = java.util.concurrent.atomic.AtomicBoolean(false)
    private var restartBtn: TextView? = null

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Cfg.ensureLoaded(this)
        Ui.init(this)
        setTheme(Ui.theme())
        super.onCreate(savedInstanceState)
        Ui.styleBars(window)
        intent?.data?.let {
            setSource(it, intent.getStringExtra(X_NAME) ?: nameOf(it))
        }
        if (intent?.getBooleanExtra(X_LIVE, false) == true && uri != null) {
            applyLive()
            liveStart = true
        }
        val root = ScrollView(this).apply { setBackgroundColor(Ui.BG) }
        box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(this@ExportActivity, 18), dp(this@ExportActivity, 22), dp(this@ExportActivity, 18), dp(this@ExportActivity, 28))
        }
        root.addView(box, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        ui.post(tick)
    }

    override fun onPause() {
        ui.removeCallbacks(tick)
        super.onPause()
    }

    private val tick: Runnable = object : Runnable {
        override fun run() {
            if (isDestroyed) return
            update()
            ui.postDelayed(this, 600)
        }
    }

    /** Takes over what the player / GIF viewer uses live (upscaler, CRSC level, sharpness, colour, temporal, frame generation). */
    private fun applyLive() {
        Cfg.bind(this, if (isGif) "gif" else "video")
        // "Fine pixels" is an option on top of the upscaler in the player; a file has it as an upscaler choice (blocks of the source pixels)
        val up = if (Cfg.finePixels && Cfg.mode != Cfg.MODE_RAW) 10 else when (Cfg.mode) {
            Cfg.MODE_SGSR -> 2
            Cfg.MODE_LANCZOS -> 3
            Cfg.MODE_NIS -> 4
            Cfg.MODE_NIS_ORIG -> 5
            Cfg.MODE_NIS_SOFT -> 6
            Cfg.MODE_NIS_FAST -> 7
            Cfg.MODE_NIS_MID -> 8
            Cfg.MODE_CLEAR -> 9
            Cfg.MODE_PIXEL -> 10
            Cfg.MODE_ART -> 11
            Cfg.MODE_NIS_FINE -> 12
            else -> 0
        }
        vFull = false
        autoMode = false
        vUp = up
        upMode = when (up) { 2 -> Cfg.MODE_SGSR; 3 -> Cfg.MODE_LANCZOS; 4 -> Cfg.MODE_NIS; 5 -> Cfg.MODE_NIS_ORIG; 6 -> Cfg.MODE_NIS_SOFT; 7 -> Cfg.MODE_NIS_FAST; 8 -> Cfg.MODE_NIS_MID; 9 -> Cfg.MODE_CLEAR; 10 -> Cfg.MODE_PIXEL; 11 -> Cfg.MODE_ART; 12 -> Cfg.MODE_NIS_FINE; else -> Cfg.MODE_FSR }
        vCrsc = Cfg.crscLevel.coerceIn(0, 5)
        vFix = Cfg.smartFix
        sharpP = Math.round(Cfg.sharp.coerceIn(0f, 1f) * 100f) + 1
        vividP = Math.round(Cfg.vivid.coerceIn(0f, 1f) * 100f)
        look = Look.fromCfg()
        if (!isGif) Look.copyLive(look) // started from Save: the file gets the same picture as playing it
        if (!isGif) {
            vTemporal = Cfg.playerTemporal.coerceIn(0, 2)
            vFg = Cfg.playerFg
            vFgN = Cfg.playerFgN.coerceIn(2, 4)
            vFgQ = Cfg.playerFgQ.coerceIn(0, 3)
        }
        if (Cfg.outRes > 0) target = Cfg.outRes.coerceAtMost(3240) // 4K / 6K are made when the phone's encoder takes them (the size shrinks by itself otherwise)
    }

    private fun setSource(u: Uri, n: String) {
        uri = u
        name = n
        isGif = GifExport.looksLikeGif(this, u, n)
    }

    private fun nameOf(u: Uri): String = runCatching {
        contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
    }.getOrNull() ?: (u.lastPathSegment ?: "video").substringAfterLast('/')

    private fun gap(v: Int) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@ExportActivity, v) }

    private fun button(label: String, primary: Boolean, onClick: () -> Unit) = Ui.text(this, label, 16f, if (primary) Ui.BG else Ui.ACCENT, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(this@ExportActivity, 14), dp(this@ExportActivity, 13), dp(this@ExportActivity, 14), dp(this@ExportActivity, 13))
        background = if (primary) Ui.gradient(dp(this@ExportActivity, 14).toFloat()) else Ui.round(Ui.CHIP, dp(this@ExportActivity, 14).toFloat())
        setOnClickListener { onClick() }
    }

    /** A row of equal chips; [onPick] gets the index. */
    private fun chips(labels: List<String>, selected: Int, onPick: (Int) -> Unit): View {
        val row = LinearLayout(this)
        val views = ArrayList<TextView>()
        fun paint(sel: Int) {
            val r = dp(this, 10).toFloat()
            views.forEachIndexed { i, c ->
                if (i == sel) {
                    c.background = Ui.gradient(r)
                    c.setTextColor(Ui.BG)
                } else {
                    c.background = Ui.round(Ui.CHIP, r)
                    c.setTextColor(Ui.MUTED)
                }
            }
        }
        labels.forEachIndexed { i, l ->
            val c = TextView(this).apply {
                text = l
                textSize = 14f
                gravity = Gravity.CENTER
                maxLines = 1
                minWidth = dp(this@ExportActivity, 60)
                setPadding(dp(this@ExportActivity, 14), dp(this@ExportActivity, 10), dp(this@ExportActivity, 14), dp(this@ExportActivity, 10))
                setOnClickListener {
                    paint(i)
                    onPick(i)
                }
            }
            views.add(c)
            row.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i > 0) marginStart = dp(this@ExportActivity, 6) })
        }
        paint(selected)
        return ChipScroller(this, row) // swipes sideways when the labels do not fit
    }

    // ---- screens ----------------------------------------------------------------------------------

    private fun refresh() {
        box.removeAllViews()
        bar = null
        lineA = null
        lineB = null
        lineC = null
        watchBtn = null
        resumeTv = null
        restartBtn = null
        shownRunning = ExportState.running
        lastSegCount = -1
        if (ExportState.running) showProgress() else showConfig()
    }

    private fun showConfig() {
        if (isGif) {
            showGifConfig()
            return
        }
        box.addView(Ui.text(this, getString(R.string.export_title), 22f, Ui.TEXT, true))
        box.addView(Ui.text(this, getString(R.string.export_note), 13f, Ui.MUTED), gap(8))
        if (ExportState.finished) box.addView(finishedCard(), gap(14))
        unfinishedCard()?.let { box.addView(it, gap(14)) }

        box.addView(Ui.text(this, if (uri == null) getString(R.string.export_need_video) else name, 15f, Ui.TEXT, true), gap(16))
        val srcTv = Ui.text(this, "", 12f, Ui.MUTED)
        box.addView(srcTv, gap(4))
        box.addView(button(getString(R.string.export_pick), false) { pick() }, gap(8))
        // many big videos / photos at once, written smaller (this used to be a separate "Free up space" entry on the main screen)
        box.addView(button(getString(R.string.main_shrink), false) { startActivity(Intent(this, ShrinkActivity::class.java)) }, gap(8))

        val estTv = Ui.text(this, "", 13f, Ui.TEXT)
        val encTv = Ui.text(this, "", 12f, Ui.MUTED)

        // which part of the video
        addRangeSection(estTv, encTv)
        addStreamSection(estTv, encTv)
        addFpsSection(estTv, encTv)

        // what is being made
        box.addView(Ui.text(this, getString(R.string.export_target), 13f, Ui.ACCENT, true), gap(18))
        val targets = intArrayOf(480, 720, 1080, 1440, 2160, 3240)
        box.addView(chips(listOf("480p", "720p", "1080p", "1440p", "4K", "6K"), targets.indexOf(target).coerceAtLeast(0)) {
            target = targets[it]
            updateEst(estTv, encTv)
        }, gap(6))
        box.addView(Ui.text(this, getString(R.string.export_target_big_hint), 12f, Ui.MUTED), gap(4))

        // everything is chosen by the app, or by hand
        box.addView(Ui.text(this, getString(R.string.export_settings_mode_title), 13f, Ui.ACCENT, true), gap(18))
        val custom = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val fullHint = Ui.text(this, getString(R.string.export_full_hint), 12f, Ui.MUTED)
        box.addView(chips(listOf(getString(R.string.export_full_auto), getString(R.string.export_full_custom)), if (vFull) 0 else 1) {
            vFull = it == 0
            custom.visibility = if (vFull) View.GONE else View.VISIBLE
            fullHint.visibility = if (vFull) View.VISIBLE else View.GONE
            updateEst(estTv, encTv)
        }, gap(6))
        box.addView(fullHint, gap(6))
        custom.visibility = if (vFull) View.GONE else View.VISIBLE
        fullHint.visibility = if (vFull) View.VISIBLE else View.GONE
        box.addView(custom, gap(0))

        // quality (Auto picks one for this video and this phone)
        custom.addView(panelSection(this, getString(R.string.export_sec_quality)), gap(16))
        custom.addView(Ui.text(this, getString(R.string.export_tier), 13f, Ui.ACCENT, true), gap(8))
        val desc = Ui.text(this, vTierDesc(), 12f, Ui.MUTED)
        custom.addView(chips(
            listOf(getString(R.string.export_auto), getString(R.string.export_tier_fast), getString(R.string.export_tier_med), getString(R.string.export_tier_high), getString(R.string.export_tier_max)),
            vTier
        ) {
            vTier = it
            desc.text = vTierDesc()
            updateEst(estTv, encTv)
        }, gap(6))
        custom.addView(desc, gap(6))

        addAiSection(estTv, encTv, custom)

        custom.addView(Ui.text(this, getString(R.string.export_content), 13f, Ui.ACCENT, true), gap(16))
        custom.addView(chips(listOf(getString(R.string.export_content_video), getString(R.string.export_content_anime)), if (anime) 1 else 0) {
            anime = it == 1
            updateEst(estTv, encTv)
        }, gap(6))

        custom.addView(Ui.text(this, getString(R.string.export_upscaler), 13f, Ui.ACCENT, true), gap(16))
        // the CRSC Edge levels only matter (and are only shown) when CRSC Edge is the chosen upscaler
        val crscBoxE = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = if (vUp == 3) View.VISIBLE else View.GONE }
        custom.addView(chips(listOf(getString(R.string.export_auto), "FSR 1", "SGSR 1", getString(R.string.mode_lanczos), getString(R.string.mode_nis), getString(R.string.mode_nis_orig), getString(R.string.mode_nis_soft), getString(R.string.mode_nis_fast), getString(R.string.mode_nis_mid), getString(R.string.mode_clear), getString(R.string.mode_pixel), getString(R.string.mode_art), getString(R.string.mode_nis_fine)), vUp) {
            vUp = it
            crscBoxE.visibility = if (vUp == 3) View.VISIBLE else View.GONE
            updateEst(estTv, encTv)
        }, gap(6))
        crscBoxE.addView(Ui.text(this, getString(R.string.crsc_quality), 12f, Ui.MUTED), gap(8))
        crscBoxE.addView(chips(listOf(R.string.crsc_l0, R.string.crsc_l1, R.string.crsc_l2, R.string.crsc_l3, R.string.crsc_l4, R.string.crsc_l5).map { getString(it) }, vCrsc) {
            vCrsc = it
            updateEst(estTv, encTv)
        }, gap(6))
        custom.addView(crscBoxE, gap(0))
        custom.addView(Ui.text(this, getString(R.string.export_upscaler_hint), 12f, Ui.MUTED), gap(6))

        custom.addView(Ui.text(this, getString(R.string.export_temporal), 13f, Ui.ACCENT, true), gap(16))
        custom.addView(chips(listOf(getString(R.string.export_fg_off), getString(R.string.export_temporal_light), getString(R.string.export_temporal_strong)), vTemporal) {
            vTemporal = it
            updateEst(estTv, encTv)
        }, gap(6))
        custom.addView(Ui.text(this, getString(R.string.export_temporal_hint), 12f, Ui.MUTED), gap(6))

        custom.addView(panelSection(this, getString(R.string.export_sec_output)), gap(18))
        custom.addView(Ui.text(this, getString(R.string.export_encoder), 13f, Ui.ACCENT, true), gap(8))
        custom.addView(chips(listOf(getString(R.string.export_auto), "H.264", "H.265"), vEnc) {
            vEnc = it
            updateEst(estTv, encTv)
        }, gap(6))
        custom.addView(Ui.text(this, getString(R.string.export_encoder_hint), 12f, Ui.MUTED), gap(6))
        custom.addView(encTv, gap(4))

        custom.addView(Ui.text(this, getString(R.string.export_size), 13f, Ui.ACCENT, true), gap(16))
        custom.addView(chips(listOf(getString(R.string.export_size_normal), getString(R.string.export_size_small), getString(R.string.export_size_smallest)), vSize) {
            vSize = it
            if (it > 0 && vEnc == 0) { /* Auto already prefers H.265 when the phone has it */ }
            updateEst(estTv, encTv)
        }, gap(6))
        custom.addView(Ui.text(this, getString(R.string.export_size_hint), 12f, Ui.MUTED), gap(6))

        custom.addView(panelSection(this, getString(R.string.export_fg)), gap(18))
        fgInfoTv = Ui.text(this, "", 13f, Ui.TEXT)
        custom.addView(fgInfoTv, gap(8))
        custom.addView(Ui.text(this, getString(R.string.export_fg_factor), 13f, Ui.ACCENT, true), gap(10))
        // the quality choice and its explanation are shown only while Frame generation is on (a factor other than Off)
        val fgOptViews = ArrayList<View>()
        custom.addView(chips(listOf(getString(R.string.export_fg_off), "2x", "3x", "4x"), if (vFg) vFgN - 1 else 0) {
            vFg = it > 0
            if (it > 0) vFgN = it + 1
            for (v in fgOptViews) v.visibility = if (vFg) View.VISIBLE else View.GONE
            updateEst(estTv, encTv)
        }, gap(6))
        val fgQTitle = Ui.text(this, getString(R.string.export_fg_quality), 13f, Ui.ACCENT, true)
        custom.addView(fgQTitle, gap(14))
        val fgQChips = chips(listOf(getString(R.string.export_fg_vlight), getString(R.string.export_fg_light), getString(R.string.export_fg_normal), getString(R.string.export_fg_high)), FG_Q_ORDER.indexOf(vFgQ).coerceAtLeast(0)) {
            vFgQ = FG_Q_ORDER[it]
            updateEst(estTv, encTv)
        }
        custom.addView(fgQChips, gap(6))
        val fgHintTv = Ui.text(this, getString(R.string.export_fg_hint), 12f, Ui.MUTED)
        custom.addView(fgHintTv, gap(6))
        fgOptViews.addAll(listOf(fgQTitle, fgQChips, fgHintTv))
        for (v in fgOptViews) v.visibility = if (vFg) View.VISIBLE else View.GONE

        custom.addView(panelSection(this, getString(R.string.export_sec_fine)), gap(18))
        val sharpTv = Ui.text(this, "", 14f, Ui.TEXT)
        fun sharpText(p: Int) = getString(R.string.export_sharp_fmt, if (p == 0) getString(R.string.export_auto_word) else "${p - 1}%")
        sharpTv.text = sharpText(sharpP)
        custom.addView(sharpTv, gap(10))
        custom.addView(slider(101, sharpP) { sharpP = it; sharpTv.text = sharpText(it) }, gap(2))

        val vividTv = Ui.text(this, "", 14f, Ui.TEXT)
        fun vividText(p: Int) = getString(R.string.export_vivid_fmt, p)
        vividTv.text = vividText(vividP)
        custom.addView(vividTv, gap(14))
        custom.addView(slider(100, vividP) { vividP = it; vividTv.text = vividText(it) }, gap(2))
        custom.addView(panelSwitch(this, getString(R.string.smartfix_switch), vFix) { vFix = it }, gap(14))
        if (!isGif) {
            // the picture of the player, exactly: the quality tier does not choose the effects then (denoise, detail, deband, anti-aliasing, Clean upscale, Game Light, Faint detail ...)
            custom.addView(panelSwitch(this, getString(R.string.export_same_live), look.live) { on ->
                if (on) {
                    Cfg.bind(this, "video")
                    Look.copyLive(look)
                    Cfg.bind(this, "screen")
                } else look.live = false
            }, gap(14))
            custom.addView(Ui.text(this, getString(R.string.export_same_live_hint), 12f, Ui.MUTED), gap(2))
        }
        custom.addView(Ui.text(this, getString(R.string.smartfix_hint), 12f, Ui.MUTED), gap(2))
        addLookControls(custom, true)

        // load on the phone
        custom.addView(Ui.text(this, getString(R.string.export_pace), 13f, Ui.ACCENT, true), gap(16))
        custom.addView(chips(listOf(getString(R.string.export_pace_max), getString(R.string.export_pace_bal), getString(R.string.export_pace_gentle)), pace) {
            pace = it
            updateEst(estTv, encTv)
        }, gap(6))
        custom.addView(Ui.text(this, getString(R.string.export_pace_hint), 12f, Ui.MUTED), gap(6))

        // estimate
        box.addView(Ui.text(this, getString(R.string.export_est_title), 13f, Ui.ACCENT, true), gap(18))
        box.addView(estTv, gap(6))

        // an unfinished export of the same video with the same settings: Start continues it
        resumeTv = Ui.text(this, "", 13f, Ui.ACCENT, true).apply { visibility = View.GONE }
        box.addView(resumeTv, gap(10))
        restartBtn = button(getString(R.string.export_restart), false) {
            val u2 = uri
            if (u2 != null) {
                VideoExport.discard(this, ExportService.jobId(u2, currentOpts()))
                updateResume()
            }
        }.apply { visibility = View.GONE }
        box.addView(restartBtn, gap(6))

        box.addView(button(getString(R.string.export_start), true) { start() }, gap(24))
        box.addView(button(getString(R.string.ovid_button), false) { onlineVideoDialog() }, gap(10))
        box.addView(Ui.text(this, getString(R.string.ovid_hint), 12f, Ui.MUTED), gap(6))
        val ovTv = Ui.text(this, "", 13f, Ui.ACCENT)
        box.addView(ovTv, gap(6))
        val tick = object : Runnable {
            override fun run() {
                if (isDestroyed) return
                ovTv.text = when {
                    OnlineVideoState.running -> getString(R.string.ovid_title) + ": " + OnlineVideoState.status
                    OnlineVideoState.error != null -> getString(R.string.ovid_failed) + "\n" + OnlineVideoState.error
                    OnlineVideoState.result != null -> getString(R.string.ovid_done)
                    else -> ""
                }
                ui.postDelayed(this, 1500)
            }
        }
        ui.post(tick)

        // read the file and test the encoders in the background, then fill the lines in
        val u = uri
        srcInfo = null
        Thread {
            val enc = ExportInfo.testEncoders()
            val info = if (u != null) ExportInfo.probe(this, u) else null
            val srcBytes = if (u != null) sizeOf(u) else 0L
            ui.post {
                if (isDestroyed) return@post
                srcInfo = info
                if (liveStart) {
                    liveStart = false
                    if (info != null) start()
                }
                srcTv.text = if (info != null) getString(
                    R.string.export_src_fmt, "${info.dispW}\u00d7${info.dispH} \u00b7 ${String.format(java.util.Locale.US, "%.0f", info.fps)} fps \u00b7 ${info.codec} \u00b7 " + fmtTime(info.durUs / 1_000_000) + (if (srcBytes > 0) " \u00b7 " + fmtBytes(srcBytes) else "")
                ) else if (u != null) getString(R.string.export_src_unknown) else ""
                updateEst(estTv, encTv)
            }
        }.start()
        updateEst(estTv, encTv)
    }

    private fun slider(max: Int, value: Int, onChange: (Int) -> Unit): android.widget.SeekBar =
        android.widget.SeekBar(this).apply {
            this.max = max
            progress = value
            progressTintList = android.content.res.ColorStateList.valueOf(Ui.ACCENT)
            thumbTintList = android.content.res.ColorStateList.valueOf(Ui.ACCENT)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Ui.STROKE)
            setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: android.widget.SeekBar, p: Int, fromUser: Boolean) {
                    if (fromUser) onChange(p)
                }

                override fun onStartTrackingTouch(s: android.widget.SeekBar) {}
                override fun onStopTrackingTouch(s: android.widget.SeekBar) {}
            })
        }

    /**
     * The newer picture settings (shadows, highlights, saturation, warmth, film grain, clarity, anti-ringing, deinterlace, contrast and, for a video,
     * cutting the black bars). They start off, or at the player's values when the export is started from the Library's Save ([applyLive]), and go
     * into the file like the Sharpness / Vivid colours above.
     */
    private fun addLookControls(parent: LinearLayout, video: Boolean) {
        parent.addView(panelSection(this, getString(R.string.export_sec_look)), gap(18))
        parent.addView(Ui.text(this, getString(R.string.export_look_hint), 12f, Ui.MUTED), gap(6))
        // the hand-made settings live in one box that Auto hides
        val inner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (video) {
            parent.addView(panelSwitch(this, getString(R.string.export_look_auto), look.auto) {
                look.auto = it
                inner.visibility = if (it) View.GONE else View.VISIBLE
            }, gap(10))
            parent.addView(Ui.text(this, getString(R.string.export_look_auto_hint), 12f, Ui.MUTED), gap(2))
        }
        inner.visibility = if (video && look.auto) View.GONE else View.VISIBLE
        parent.addView(inner, gap(0))
        // max = slider range, zero = slider position of 0 (what is shown is position - zero), div = positions per 1.0 of the value
        class Row(val fmt: Int, val max: Int, val zero: Int, val div: Float, val get: () -> Float, val set: (Float) -> Unit)
        val rows = listOf(
            Row(R.string.contrast_fmt, 100, 50, 50f, { look.contrast }, { look.contrast = it }),
            Row(R.string.shadows_fmt, 200, 100, 100f, { look.shadows }, { look.shadows = it }),
            Row(R.string.highlights_fmt, 200, 100, 100f, { look.highlights }, { look.highlights = it }),
            Row(R.string.saturation_fmt, 200, 100, 100f, { look.saturation }, { look.saturation = it }),
            Row(R.string.warmth_fmt, 200, 100, 100f, { look.warmth }, { look.warmth = it }),
            Row(R.string.grain_fmt, 100, 0, 100f, { look.grain }, { look.grain = it }),
            Row(R.string.clarity_fmt, 200, 100, 100f, { look.clarity }, { look.clarity = it }),
            Row(R.string.antiring_fmt, 100, 0, 100f, { look.antiRing }, { look.antiRing = it })
        )
        for (r in rows) {
            val tv = Ui.text(this, "", 14f, Ui.TEXT)
            val start = Math.round(r.get() * r.div).toInt().plus(r.zero).coerceIn(0, r.max)
            tv.text = getString(r.fmt, start - r.zero)
            inner.addView(tv, gap(14))
            inner.addView(slider(r.max, start) { p ->
                r.set((p - r.zero) / r.div)
                tv.text = getString(r.fmt, p - r.zero)
            }, gap(2))
        }
        inner.addView(Ui.text(this, getString(R.string.deint_label), 12f, Ui.MUTED), gap(14))
        inner.addView(chips(listOf(getString(R.string.deint_off), getString(R.string.deint_odd), getString(R.string.deint_even)), look.deint.coerceIn(0, 2)) { look.deint = it }, gap(6))
        inner.addView(Ui.text(this, getString(R.string.deint_hint), 12f, Ui.MUTED), gap(4))
        if (video) {
            inner.addView(panelSwitch(this, getString(R.string.export_cut_bars), look.cutBars) { look.cutBars = it }, gap(14))
            inner.addView(Ui.text(this, getString(R.string.export_cut_bars_hint), 12f, Ui.MUTED), gap(2))
        }
    }

    /**
     * "Smooth live": the effects are what the video player has now (upscaler, sharpening, detail, colour, bars ...), copied here, and the
     * picture is made at the size of the screen - what playing it directly would show - so even a heavy setting is light to make: no 4K,
     * no second set of choices. Made a little ahead of the viewer like Watch now, nothing is saved.
     */
    private fun liveOpts(): ExportOpts {
        Cfg.bind(this, "video")
        val lk = Look.fromCfg()
        Look.copyLive(lk)
        val md = ((if (Cfg.finePixels && Cfg.mode != Cfg.MODE_RAW) Cfg.MODE_PIXEL else Cfg.mode) and 0xFF) or (Cfg.crscLevel.coerceIn(0, 7) shl 21) or (Cfg.playerTemporal.coerceIn(0, 2) shl 18) or (if (Cfg.smartFix) VideoExport.SMARTFIX_FLAG else 0)
        Cfg.bind(this, "screen")
        val side = minOf(resources.displayMetrics.widthPixels, resources.displayMetrics.heightPixels).coerceIn(720, 1440)
        val o = ExportOpts(side, 2, false, false, md, -1f, 0f, pace).withStream(true).withLook(lk.encode())
        if (!rangeOn) return o
        val (s, e) = rangeUs()
        return o.withRange(s, e)
    }

    /** The settings as they will really be used (Auto fills in the best choices for this video and this phone). */
    private fun currentOpts(): ExportOpts {
        if (liveOn) return liveOpts()
        val a = ExportInfo.autoPlan(this, srcInfo, target, anime, if (vFull) 0 else pace)
        val o0 = if (vFull) ExportOpts(a.target, a.tier, a.anime, a.hevc, a.mode or (1 shl 18) or VideoExport.SMARTFIX_FLAG, a.sharp, a.vivid, a.pace) else { // automatic: light temporal clean-up on
            val t = if (vTier == 0) a.tier else vTier - 1
            val hv = when (vEnc) { 1 -> false; 2 -> true; else -> a.hevc }
            val md = (when (vUp) { 2 -> Cfg.MODE_SGSR; 3 -> Cfg.MODE_LANCZOS; 4 -> Cfg.MODE_NIS; 5 -> Cfg.MODE_NIS_ORIG; 6 -> Cfg.MODE_NIS_SOFT; 7 -> Cfg.MODE_NIS_FAST; 8 -> Cfg.MODE_NIS_MID; 9 -> Cfg.MODE_CLEAR; 10 -> Cfg.MODE_PIXEL; 11 -> Cfg.MODE_ART; 12 -> Cfg.MODE_NIS_FINE; else -> Cfg.MODE_FSR }) or (vCrsc shl 21) or VideoAi.bits(vAi, vAiHalf) or VideoExport.fgBits(vFg, vFgN, vFgQ) or (vSize shl 9) or (vTemporal shl 18) or (if (vFix) VideoExport.SMARTFIX_FLAG else 0)
            ExportOpts(target, t, anime, hv, md, if (sharpP == 0) -1f else (sharpP - 1) / 100f, vividP / 100f, pace)
        }
        val o = (if (streamOn) o0.withStream(true) else o0).withLook(if (vFull) Look(auto = true).encode() else look.encode())
        if (!rangeOn) return o
        val (s, e) = rangeUs()
        return o.withRange(s, e)
    }

    /** "14:00", "1:02:03" or a lone number of minutes -> seconds; null when it is not a time. */
    private fun parseTime(text: String): Long? {
        val t = text.trim()
        if (t.isEmpty()) return null
        return try {
            val p = t.split(':')
            when (p.size) {
                1 -> (p[0].trim().toDouble() * 60).toLong()
                2 -> p[0].trim().toLong() * 60 + p[1].trim().toLong()
                3 -> p[0].trim().toLong() * 3600 + p[1].trim().toLong() * 60 + p[2].trim().toLong()
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }

    /** The chosen part in microseconds: (start, end); an empty or wrong end means "to the end of the video". */
    private fun rangeUs(): Pair<Long, Long> {
        val s = (parseTime(rangeFrom) ?: 0L).coerceAtLeast(0L) * 1_000_000L
        val e = (parseTime(rangeTo) ?: 0L).coerceAtLeast(0L) * 1_000_000L
        return Pair(s, if (e > s) e else 0L)
    }

    /** Switch + two time fields (from / to) + "next part": upscale only a part, for example minute 14 to 19. */
    private fun addRangeSection(estTv: TextView, encTv: TextView) {
        box.addView(Ui.text(this, getString(R.string.export_range_title), 13f, Ui.ACCENT, true), gap(18))
        val rb = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        rb.visibility = if (rangeOn) View.VISIBLE else View.GONE
        box.addView(panelSwitch(this, getString(R.string.export_range_switch), rangeOn) {
            rangeOn = it
            rb.visibility = if (it) View.VISIBLE else View.GONE
            updateEst(estTv, encTv)
        }, gap(6))
        box.addView(Ui.text(this, getString(R.string.export_range_hint), 12f, Ui.MUTED), gap(2))
        box.addView(rb, gap(4))

        fun field(hint: String, value: String, onText: (String) -> Unit) = android.widget.EditText(this).apply {
            setSingleLine()
            this.hint = hint
            setText(value)
            inputType = android.text.InputType.TYPE_CLASS_DATETIME or android.text.InputType.TYPE_DATETIME_VARIATION_TIME
            setTextColor(Ui.TEXT)
            setHintTextColor(Ui.MUTED)
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) {
                    onText(s?.toString() ?: "")
                    updateEst(estTv, encTv)
                }
            })
        }
        val row = LinearLayout(this)
        val fromEt = field(getString(R.string.export_range_from), rangeFrom) { rangeFrom = it }
        val toEt = field(getString(R.string.export_range_to), rangeTo) { rangeTo = it }
        row.addView(fromEt, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(Ui.text(this, "  \u2192  ", 16f, Ui.MUTED), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        row.addView(toEt, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        rb.addView(row)
        rb.addView(button(getString(R.string.export_range_next), false) {
            val s = parseTime(rangeFrom) ?: 0L
            val e = parseTime(rangeTo)
            if (e == null || e <= s) {
                Toast.makeText(this, R.string.export_range_need_end, Toast.LENGTH_SHORT).show()
            } else {
                val next = nextRange(s, e, (srcInfo?.durUs ?: 0L) / 1_000_000L)
                if (next == null) Toast.makeText(this, R.string.export_range_last, Toast.LENGTH_SHORT).show()
                else {
                    rangeFrom = fmtTime(next.first)
                    rangeTo = fmtTime(next.second)
                    fromEt.setText(rangeFrom)
                    toEt.setText(rangeTo)
                }
            }
        }, gap(10))
    }

    /** File or stream: stream makes only a few minutes ahead of the viewer and deletes what was watched (little free space needed). */
    /** Offline AI model for short videos (Light / Medium / Heavy), with the model download and a speed test. */
    private fun addAiSection(estTv: TextView, encTv: TextView, into: LinearLayout) {
        into.addView(panelSection(this, getString(R.string.export_ai_sec)), gap(18))
        into.addView(Ui.text(this, getString(R.string.export_ai), 13f, Ui.ACCENT, true), gap(8))
        val status = Ui.text(this, "", 12f, Ui.MUTED)
        val dl = button(getString(R.string.export_ai_download), false) { }
        val test = button(getString(R.string.export_ai_test), false) { }
        val rate = chips(listOf(getString(R.string.export_ai_rate_full), getString(R.string.export_ai_rate_half)), if (vAiHalf) 1 else 0) {
            vAiHalf = it == 1
            updateEst(estTv, encTv)
        }
        fun autoPick() {
            val i = srcInfo ?: return
            val frames = (if (rangeOn) { val (a, b) = rangeUs(); (if (b > a) b - a else (i.durUs - a).coerceAtLeast(0L)) } else i.durUs) / 1e6 * i.fps
            val (l, h) = VideoAiAuto.pick(this, i.dispW, i.dispH, frames)
            vAi = l
            vAiHalf = h
        }
        fun refresh() {
            if (vAiAuto) autoPick()
            val on = vAi > 0
            status.visibility = if (on) View.VISIBLE else View.GONE
            rate.visibility = if (on) View.VISIBLE else View.GONE
            if (!on) {
                dl.visibility = View.GONE
                test.visibility = View.GONE
                return
            }
            val id = VideoAi.modelFor(this, vAi)
            if (id != null) {
                val i = srcInfo
                val spf = if (i != null) VideoAi.secPerFrame(this, i.dispW, i.dispH, vAi) else 0f
                val cat = AiSr.CATALOG.firstOrNull { it.id == id }
                status.text = (if (vAiAuto) getString(R.string.export_ai_auto_fmt, levelLabel(vAi), if (vAiHalf) " · " + getString(R.string.export_ai_rate_half) else "") + "\n" else "") +
                    getString(R.string.export_ai_ready_fmt, cat?.label ?: id, spf)
                dl.visibility = View.GONE
                test.visibility = View.VISIBLE
            } else {
                val cat = VideoAi.catalogFor(vAi).first()
                status.text = getString(R.string.export_ai_missing_fmt, cat.label, cat.sizeKb / 1024f)
                dl.visibility = View.VISIBLE
                test.visibility = View.GONE
            }
        }
        val labels = VideoAi.UI_LEVELS.map { levelLabel(it) } + getString(R.string.export_ai_auto)
        val sel = if (vAiAuto) labels.size - 1 else VideoAi.UI_LEVELS.indexOf(vAi).coerceAtLeast(0)
        into.addView(chips(labels, sel) {
            vAiAuto = it == labels.size - 1
            if (vAiAuto) {
                vAi = 3
                vAiHalf = false
            } else {
                vAi = VideoAi.UI_LEVELS[it]
            }
            refresh()
            updateEst(estTv, encTv)
        }, gap(6))
        into.addView(Ui.text(this, getString(R.string.export_ai_hint), 12f, Ui.MUTED), gap(6))
        into.addView(status, gap(6))
        into.addView(rate, gap(6))
        into.addView(dl, gap(6))
        into.addView(test, gap(6))
        dl.setOnClickListener {
            val cat = VideoAi.catalogFor(vAi).firstOrNull() ?: return@setOnClickListener
            dl.isEnabled = false
            Thread {
                val err = runCatching { AiSr.installCatalog(this, cat) { p -> ui.post { status.text = getString(R.string.export_ai_downloading_fmt, cat.label, p) } } }.exceptionOrNull()
                ui.post {
                    dl.isEnabled = true
                    if (err != null) Toast.makeText(this, (err.message ?: "download failed").take(200), Toast.LENGTH_LONG).show()
                    refresh()
                    updateEst(estTv, encTv)
                }
            }.start()
        }
        test.setOnClickListener {
            val id = VideoAi.modelFor(this, vAi) ?: return@setOnClickListener
            test.isEnabled = false
            status.text = getString(R.string.export_ai_testing)
            Thread {
                val r = runCatching { AiSr.msPerTile(this, id) }
                val g = runCatching { AiSr.gpuMsPerTile(this, id) }
                ui.post {
                    test.isEnabled = true
                    r.getOrNull()?.let { VideoAi.saveMs(this, id, it) }
                    if (r.isFailure) Toast.makeText(this, (r.exceptionOrNull()?.message ?: "test failed").take(200), Toast.LENGTH_LONG).show()
                    Toast.makeText(this, AiSr.speedLine(r.getOrNull(), g), Toast.LENGTH_LONG).show()
                    refresh()
                    updateEst(estTv, encTv)
                }
            }.start()
        }
        refresh()
    }

    private fun addStreamSection(estTv: TextView, encTv: TextView) {
        box.addView(Ui.text(this, getString(R.string.export_stream_title), 13f, Ui.ACCENT, true), gap(18))
        // "how much to keep" only means something when watching now, so it is shown only for that choice
        val keep = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        keep.visibility = if (streamOn) View.VISIBLE else View.GONE
        // Smooth live: what to do when the phone is slower than the video
        val liveBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        liveBox.visibility = if (liveOn) View.VISIBLE else View.GONE
        val lsp = getSharedPreferences("crsc", Context.MODE_PRIVATE)
        fun lgap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@ExportActivity, 8) }
        val liveFpsVals = intArrayOf(0, 1, 30, 24)
        liveBox.addView(Ui.text(this, getString(R.string.live_fps_title), 13f, Ui.TEXT, true), lgap())
        liveBox.addView(chips(listOf(getString(R.string.export_auto), getString(R.string.export_fps_all), "30 fps", "24 fps"), liveFpsVals.indexOf(lsp.getInt("live_fps", 0)).coerceAtLeast(0)) {
            lsp.edit().putInt("live_fps", liveFpsVals[it]).apply()
            updateEst(estTv, encTv)
        }, lgap())
        liveBox.addView(Ui.text(this, getString(R.string.live_fps_hint), 12f, Ui.MUTED), lgap())
        box.addView(chips(listOf(getString(R.string.export_out_file), getString(R.string.export_out_stream), getString(R.string.export_out_live)), if (liveOn) 2 else if (streamOn) 1 else 0) {
            streamOn = it >= 1
            liveOn = it == 2
            liveBox.visibility = if (liveOn) View.VISIBLE else View.GONE
            keep.visibility = if (streamOn) View.VISIBLE else View.GONE
            updateEst(estTv, encTv)
        }, gap(6))
        box.addView(Ui.text(this, getString(R.string.export_stream_hint), 12f, Ui.MUTED), gap(6))
        box.addView(Ui.text(this, getString(R.string.export_live_hint), 12f, Ui.MUTED), gap(4))
        box.addView(liveBox, gap(0))
        val sp = getSharedPreferences("crsc", Context.MODE_PRIVATE)
        val ahead = intArrayOf(0, 30, 60, 120, 300, 600)
        val behind = intArrayOf(0, 10, 30, 60, 120)
        fun kgap(v: Int) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@ExportActivity, v) }
        keep.addView(Ui.text(this, getString(R.string.export_stream_ahead), 13f, Ui.TEXT, true), kgap(10))
        keep.addView(chips(listOf(getString(R.string.export_auto), "30 s", "1 min", "2 min", "5 min", "10 min"), ahead.indexOf(sp.getInt("stream_ahead_s", 0)).coerceAtLeast(0)) {
            sp.edit().putInt("stream_ahead_s", ahead[it]).apply()
        }, kgap(6))
        keep.addView(Ui.text(this, getString(R.string.export_stream_behind), 13f, Ui.TEXT, true), kgap(10))
        keep.addView(chips(listOf(getString(R.string.export_auto), "10 s", "30 s", "1 min", "2 min"), behind.indexOf(sp.getInt("stream_behind_s", 0)).coerceAtLeast(0)) {
            sp.edit().putInt("stream_behind_s", behind[it]).apply()
        }, kgap(6))
        keep.addView(Ui.text(this, getString(R.string.export_stream_space), 13f, Ui.TEXT, true), kgap(10))
        val spaces = intArrayOf(50, 100, 300, 600, 1000, 2000, 0)
        keep.addView(chips(listOf("50 MB", "100 MB", "300 MB", "600 MB", "1 GB", "2 GB", getString(R.string.export_stream_space_none)), spaces.indexOf(sp.getInt("stream_space_mb", 600)).coerceAtLeast(0)) {
            sp.edit().putInt("stream_space_mb", spaces[it]).apply()
        }, kgap(6))
        keep.addView(Ui.text(this, getString(R.string.export_stream_space_hint), 12f, Ui.MUTED), kgap(6))
        keep.addView(Ui.text(this, getString(R.string.export_stream_keep_hint), 12f, Ui.MUTED), kgap(6))
        keep.addView(panelSwitch(this, getString(R.string.stream_keep_switch), sp.getBoolean("stream_keep", false)) { sp.edit().putBoolean("stream_keep", it).apply() }, kgap(12))
        keep.addView(Ui.text(this, getString(R.string.stream_keep_hint), 12f, Ui.MUTED), kgap(4))
        box.addView(keep, gap(0))
    }

    /** A cap on the frame rate that is worked on (30 / 24 fps): a 60 fps video is made about twice as fast, every frame has the same quality. */
    private fun addFpsSection(estTv: TextView, encTv: TextView) {
        if (isGif) return
        val sp = getSharedPreferences("crsc", Context.MODE_PRIVATE)
        box.addView(Ui.text(this, getString(R.string.export_fps_title), 13f, Ui.ACCENT, true), gap(18))
        val caps = intArrayOf(0, 30, 24)
        box.addView(chips(listOf(getString(R.string.export_fps_all), "30 fps", "24 fps"), caps.indexOf(sp.getInt("export_fps_cap", 0)).coerceAtLeast(0)) {
            sp.edit().putInt("export_fps_cap", caps[it]).apply()
            updateEst(estTv, encTv)
        }, gap(6))
        box.addView(Ui.text(this, getString(R.string.export_fps_hint), 12f, Ui.MUTED), gap(6))
    }

    /** The part right after [s]..[e] with the same length (cut at the end of the video); null when the video is over. */
    private fun nextRange(s: Long, e: Long, durSec: Long): Pair<Long, Long>? {
        if (durSec > 0 && e >= durSec) return null
        var ne = e + (e - s)
        if (durSec > 0 && ne > durSec) ne = durSec
        return Pair(e, ne)
    }

    /** Shows how much of an unfinished export of this video (same settings) is already done. */
    private fun updateResume() {
        val u = uri
        val tv = resumeTv ?: return
        val rb = restartBtn ?: return
        val ro = currentOpts()
        val done = if (u != null) (VideoExport.doneUs(this, ExportService.jobId(u, ro)) - ro.rangeStartUs).coerceAtLeast(0L) else 0L
        if (done > 0L) {
            val total = srcInfo?.let { ExportInfo.spanUs(it, ro) } ?: 0L
            tv.text = getString(R.string.export_resume_found_fmt, fmtTime(done / 1_000_000), if (total > 0) fmtTime(total / 1_000_000) else "?")
            tv.visibility = View.VISIBLE
            rb.visibility = View.VISIBLE
        } else {
            tv.visibility = View.GONE
            rb.visibility = View.GONE
        }
    }

    private fun updateEst(estTv: TextView, encTv: TextView) {
        updateResume()
        val enc = ExportInfo.encoders
        encTv.text = if (enc == null) getString(R.string.export_enc_testing) else getString(
            R.string.export_enc_support_fmt,
            enc.joinToString("  ") { e -> e.label + " " + (if (e.works) (if (e.hardware) "\u2713 hw" else "\u2713 sw") else "\u2717") }
        )
        val i = srcInfo
        if (i == null) {
            estTv.text = getString(R.string.export_est_unknown)
            fgInfoTv?.text = ""
            return
        }
        val o = currentOpts()
        val fgN = VideoExport.fgFactor(o.mode)
        fgInfoTv?.text = if (fgN > 1) getString(R.string.export_fg_info_fmt, String.format(java.util.Locale.US, "%.0f", i.fps), String.format(java.util.Locale.US, "%.0f", i.fps * fgN), fgN)
        else getString(R.string.export_fg_info_off_fmt, String.format(java.util.Locale.US, "%.0f", i.fps))
        val (ow, oh) = ExportInfo.outSize(i, o.target, o.hevc)
        val sec = ExportInfo.estimateSec(this, i, o)
        val dur = (ExportInfo.spanUs(i, o) / 1_000_000L).coerceAtLeast(1L)
        val ratio = sec.toFloat() / dur
        val load = getString(if (ratio < 0.8f) R.string.export_load_light else if (ratio < 2.5f) R.string.export_load_medium else R.string.export_load_heavy)
        val mb = ExportInfo.sizeBytes(i, o) / (1024 * 1024)
        val sb = StringBuilder()
        if (rangeOn) {
            val span = ExportInfo.spanUs(i, o) / 1_000_000L
            sb.append(getString(R.string.export_range_est_fmt, fmtTime(o.rangeStartUs / 1_000_000L), if (o.rangeEndUs > 0L) fmtTime(o.rangeEndUs / 1_000_000L) else getString(R.string.export_range_end_word), fmtTime(span))).append('\n')
        }
        sb.append(getString(R.string.export_out_fmt, ow, oh, if (o.hevc) "H.265" else "H.264", mb.toString()))
        sb.append('\n').append(getString(R.string.export_time_fmt, fmtTime(sec), if (ExportInfo.measuredMpx(this) > 0f) "" else getString(R.string.export_time_rough)))
        sb.append('\n').append(getString(R.string.export_load_fmt, load))
        sb.append('\n').append(getString(R.string.export_auto_picked_fmt, getString(when (o.tier) { 0 -> R.string.export_tier_fast; 2 -> R.string.export_tier_high; 3 -> R.string.export_tier_max; else -> R.string.export_tier_med }), if (o.hevc) "H.265" else "H.264"))
        if (i.shortSide >= o.target) sb.append('\n').append(getString(R.string.export_no_upscale))
        if (vFull) {
            val up = when (o.mode and 0xFF) {
                Cfg.MODE_LANCZOS -> getString(R.string.mode_lanczos)
                Cfg.MODE_CLEAR -> getString(R.string.mode_clear)
                Cfg.MODE_ART -> getString(R.string.mode_art)
                Cfg.MODE_PIXEL -> getString(R.string.mode_pixel)
                Cfg.MODE_NIS_MID -> getString(R.string.mode_nis_mid)
                else -> "FSR 1"
            }
            sb.append('\n').append(getString(R.string.export_full_summary_fmt, up))
        }
        if (liveOn) sb.append('\n').append(getString(R.string.export_live_note, o.target))
        else if (streamOn) sb.append('\n').append(getString(R.string.export_stream_note))
        estTv.text = sb.toString()
    }

    private fun vTierDesc() = getString(
        when (vTier) {
            0 -> R.string.export_auto_hint
            1 -> R.string.export_tier_fast_desc
            3 -> R.string.export_tier_high_desc
            4 -> R.string.export_tier_max_desc
            else -> R.string.export_tier_med_desc
        }
    )

    private fun tierDesc() = getString(
        when (tier) {
            0 -> R.string.export_tier_fast_desc
            2 -> R.string.export_tier_high_desc
            else -> R.string.export_tier_med_desc
        }
    )

    private fun finishedCard(): View {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.round(Ui.CARD, dp(this@ExportActivity, 14).toFloat())
            setPadding(dp(this@ExportActivity, 14), dp(this@ExportActivity, 12), dp(this@ExportActivity, 14), dp(this@ExportActivity, 12))
        }
        val r = ExportState.result
        val err = ExportState.error
        when {
            r != null -> {
                c.addView(
                    Ui.text(
                        this,
                        if (ExportState.partial) getString(R.string.export_partial_done_fmt, fmtTime(ExportState.doneUs / 1_000_000), fmtTime(ExportState.totalUs / 1_000_000))
                        else getString(R.string.export_done),
                        14f, Ui.OK, true
                    )
                )
                ExportState.job?.let { j ->
                    if (j.rangeEndUs > 0L && !ExportState.partial) {
                        val next = nextRange(j.rangeStartUs / 1_000_000L, j.rangeEndUs / 1_000_000L, (srcInfo?.durUs ?: 0L) / 1_000_000L)
                        if (next != null) c.addView(
                            button(getString(R.string.export_range_next_fmt, fmtTime(next.first), fmtTime(next.second)), false) {
                                rangeOn = true
                                rangeFrom = fmtTime(next.first)
                                rangeTo = fmtTime(next.second)
                                refresh()
                            },
                            gap(10)
                        )
                    }
                }
                val outSz = sizeOf(r)
                val srcSz = ExportState.job?.let { sizeOf(Uri.parse(it.uri)) } ?: 0L
                if (outSz > 0) c.addView(
                    Ui.text(this, if (srcSz > 0) getString(R.string.export_size_done_fmt, fmtBytes(outSz), fmtBytes(srcSz)) else getString(R.string.export_size_only_fmt, fmtBytes(outSz)), 13f, Ui.TEXT),
                    gap(4)
                )
                // how much the size changed and how long this run took
                if (outSz > 0 && srcSz > 0 && !ExportState.partial) {
                    val pct = ((outSz - srcSz) * 100.0 / srcSz).toInt()
                    c.addView(Ui.text(this, getString(if (pct <= 0) R.string.export_smaller_fmt else R.string.export_bigger_fmt, kotlin.math.abs(pct)), 12f, Ui.MUTED), gap(2))
                }
                if (ExportState.endedAt > ExportState.startedAt && ExportState.startedAt > 0L) {
                    c.addView(Ui.text(this, getString(R.string.export_took_fmt, fmtTime((ExportState.endedAt - ExportState.startedAt) / 1000L)), 12f, Ui.MUTED), gap(2))
                }
                if (AudioNote.skipped) c.addView(Ui.text(this, getString(R.string.export_nosound), 12f, Ui.MUTED), gap(4))
                c.addView(button(getString(R.string.export_open), false) { openResult(r) }, gap(10))
                c.addView(button(getString(R.string.share), false) { Share.share(this, listOf(r)) }, gap(8))
            }
            ExportState.paused -> c.addView(
                Ui.text(this, getString(R.string.export_paused_msg_fmt, fmtTime(ExportState.doneUs / 1_000_000), fmtTime(ExportState.totalUs / 1_000_000)), 14f, Ui.OK, true)
            )
            err != null -> c.addView(Ui.text(this, getString(R.string.export_failed_fmt, err), 13f, Ui.DANGER))
            ExportState.cancelled -> c.addView(Ui.text(this, getString(R.string.export_cancelled), 14f, Ui.MUTED))
        }
        return c
    }

    /** "Unfinished upscale: name, 12:30 of 45:00 done" with Continue / Discard, for a paused, failed or interrupted job. */
    private fun unfinishedCard(): View? {
        val j = ExportInfo.unfinished(this) ?: return null
        val done = (VideoExport.doneUs(this, j.id) - j.rangeStartUs).coerceAtLeast(0L)
        if (done <= 0L) {
            ExportInfo.clearUnfinished(this)
            return null
        }
        val total = (if (j.rangeEndUs > 0L) j.rangeEndUs else VideoExport.totalUs(this, j.id)) - j.rangeStartUs
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.round(Ui.CARD, dp(this@ExportActivity, 14).toFloat())
            setPadding(dp(this@ExportActivity, 14), dp(this@ExportActivity, 12), dp(this@ExportActivity, 14), dp(this@ExportActivity, 12))
        }
        c.addView(Ui.text(this, getString(R.string.export_unfinished_title), 14f, Ui.ACCENT, true))
        c.addView(Ui.text(this, j.name, 15f, Ui.TEXT, true), gap(4))
        c.addView(
            Ui.text(
                this,
                getString(R.string.export_unfinished_fmt, fmtTime(done / 1_000_000), if (total > 0) fmtTime(total / 1_000_000) else "?", fmtBytes(VideoExport.bytesSoFar(this, j.id))),
                13f, Ui.MUTED
            ),
            gap(4)
        )
        val row = LinearLayout(this)
        row.addView(button(getString(R.string.export_continue), true) {
            if (ExportState.running) Toast.makeText(this, R.string.export_busy, Toast.LENGTH_SHORT).show()
            else {
                ExportService.resume(this, j)
                ui.postDelayed({ refresh() }, 300)
            }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(button(getString(R.string.export_discard), false) {
            AlertDialog.Builder(this)
                .setMessage(R.string.export_discard_ask)
                .setPositiveButton(android.R.string.ok) { _, _ ->
                    VideoExport.discard(this, j.id)
                    ExportInfo.clearUnfinished(this)
                    refresh()
                }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(this@ExportActivity, 8) })
        c.addView(row, gap(10))
        return c
    }

    // ---- GIF: upscaled frame by frame, saved as an MP4 -----------------------------------------------

    private fun gifOpts(info: GifInfo?): GifOpts {
        if (!autoMode) return GifOpts(target, tier, anime, upMode or (if (vFix) VideoExport.SMARTFIX_FLAG else 0), if (sharpP == 0) -1f else (sharpP - 1) / 100f, vividP / 100f, look.encode())
        // Auto: the strongest cleanup that still finishes in a few minutes
        var t = 2
        if (info != null) while (t > 0 && GifExport.estimateSec(this, info, GifOpts(target, t, anime)) > 600) t--
        return GifOpts(target, t, anime, Cfg.MODE_FSR or VideoExport.SMARTFIX_FLAG)
    }

    private fun showGifConfig() {
        box.addView(Ui.text(this, getString(R.string.export_title), 22f, Ui.TEXT, true))
        box.addView(Ui.text(this, getString(R.string.export_gif_note), 13f, Ui.MUTED), gap(8))
        box.addView(Ui.text(this, name, 15f, Ui.TEXT, true), gap(16))
        val srcTv = Ui.text(this, "", 12f, Ui.MUTED)
        box.addView(srcTv, gap(4))
        box.addView(button(getString(R.string.export_pick), false) { pick() }, gap(8))
        val estTv = Ui.text(this, "", 13f, Ui.TEXT)
        var info: GifInfo? = null

        fun est() {
            val i = info
            if (i == null) {
                estTv.text = getString(R.string.export_est_unknown)
                return
            }
            val o = gifOpts(i)
            val (ow, oh) = GifExport.outSize(i, o.target)
            val sec = GifExport.estimateSec(this, i, o)
            val dur = (i.durMs / 1000L).coerceAtLeast(1L)
            val load = getString(if (sec.toFloat() / dur < 4f) R.string.export_load_light else if (sec.toFloat() / dur < 20f) R.string.export_load_medium else R.string.export_load_heavy)
            val sb = StringBuilder()
            sb.append(getString(R.string.export_gif_out_fmt, ow, oh, fmtBytes(GifExport.sizeBytes(i, o))))
            sb.append('\n').append(getString(R.string.export_time_fmt, fmtTime(sec), if (ExportInfo.measuredMpx(this) > 0f) "" else getString(R.string.export_time_rough)))
            sb.append('\n').append(getString(R.string.export_load_fmt, load))
            if (autoMode) sb.append('\n').append(getString(R.string.export_auto_picked_gif_fmt, getString(when (o.tier) { 0 -> R.string.export_tier_fast; 2 -> R.string.export_tier_high; else -> R.string.export_tier_med })))
            if (min(i.w, i.h) >= o.target) sb.append('\n').append(getString(R.string.export_no_upscale))
            estTv.text = sb.toString()
        }

        box.addView(Ui.text(this, getString(R.string.export_target), 13f, Ui.ACCENT, true), gap(18))
        val targets = intArrayOf(480, 720, 1080, 1440)
        box.addView(chips(listOf("480p", "720p", "1080p", "1440p"), targets.indexOf(target).coerceAtLeast(0)) {
            target = targets[it]
            est()
        }, gap(6))

        box.addView(Ui.text(this, getString(R.string.export_settings_mode), 13f, Ui.ACCENT, true), gap(16))
        val manualBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        manualBox.visibility = if (autoMode) View.GONE else View.VISIBLE
        val autoHint = Ui.text(this, getString(R.string.export_auto_hint), 12f, Ui.MUTED)
        autoHint.visibility = if (autoMode) View.VISIBLE else View.GONE
        box.addView(chips(listOf(getString(R.string.export_auto), getString(R.string.export_manual)), if (autoMode) 0 else 1) {
            autoMode = it == 0
            manualBox.visibility = if (autoMode) View.GONE else View.VISIBLE
            autoHint.visibility = if (autoMode) View.VISIBLE else View.GONE
            est()
        }, gap(6))
        box.addView(autoHint, gap(6))
        box.addView(manualBox, gap(0))

        manualBox.addView(Ui.text(this, getString(R.string.export_tier), 13f, Ui.ACCENT, true), gap(16))
        val desc = Ui.text(this, tierDesc(), 12f, Ui.MUTED)
        manualBox.addView(chips(listOf(getString(R.string.export_tier_fast), getString(R.string.export_tier_med), getString(R.string.export_tier_high)), tier) {
            tier = it
            desc.text = tierDesc()
            est()
        }, gap(6))
        manualBox.addView(desc, gap(6))

        box.addView(Ui.text(this, getString(R.string.export_content), 13f, Ui.ACCENT, true), gap(16))
        box.addView(chips(listOf(getString(R.string.export_content_video), getString(R.string.export_content_anime)), if (anime) 1 else 0) {
            anime = it == 1
            est()
        }, gap(6))

        manualBox.addView(Ui.text(this, getString(R.string.export_upscaler), 13f, Ui.ACCENT, true), gap(16))
        manualBox.addView(chips(listOf("FSR 1", "SGSR 1"), if (upMode == Cfg.MODE_SGSR) 1 else 0) { upMode = if (it == 1) Cfg.MODE_SGSR else Cfg.MODE_FSR }, gap(6))

        val sharpTv = Ui.text(this, "", 14f, Ui.TEXT)
        fun sharpText(p: Int) = getString(R.string.export_sharp_fmt, if (p == 0) getString(R.string.export_auto_word) else "${p - 1}%")
        sharpTv.text = sharpText(sharpP)
        manualBox.addView(sharpTv, gap(16))
        manualBox.addView(slider(101, sharpP) { sharpP = it; sharpTv.text = sharpText(it) }, gap(2))
        val vividTv = Ui.text(this, "", 14f, Ui.TEXT)
        vividTv.text = getString(R.string.export_vivid_fmt, vividP)
        manualBox.addView(vividTv, gap(14))
        manualBox.addView(slider(100, vividP) { vividP = it; vividTv.text = getString(R.string.export_vivid_fmt, it) }, gap(2))
        manualBox.addView(panelSwitch(this, getString(R.string.smartfix_switch), vFix) { vFix = it }, gap(14))
        addLookControls(manualBox, false)

        box.addView(Ui.text(this, getString(R.string.export_est_title), 13f, Ui.ACCENT, true), gap(18))
        box.addView(estTv, gap(6))
        box.addView(button(getString(R.string.export_start), true) { startGif(info) }, gap(24))

        val u = uri
        Thread {
            val gi = if (u != null) GifExport.probe(this, u) else null
            val bytes = if (u != null) sizeOf(u) else 0L
            ui.post {
                if (isDestroyed) return@post
                info = gi
                if (liveStart) {
                    liveStart = false
                    if (gi != null) startGif(gi)
                }
                srcTv.text = if (gi != null) getString(
                    R.string.export_gif_src_fmt, gi.w, gi.h, fmtTime((gi.durMs / 1000).toLong()) + (if (bytes > 0) " \u00b7 " + fmtBytes(bytes) else ""), gi.frames
                ) else getString(R.string.export_gif_not_animated)
                est()
            }
        }.start()
        est()
    }

    private fun startGif(info: GifInfo?) {
        val u = uri
        if (u == null) {
            Toast.makeText(this, R.string.export_need_video, Toast.LENGTH_SHORT).show()
            return
        }
        if (info == null) {
            Toast.makeText(this, R.string.export_gif_not_animated, Toast.LENGTH_LONG).show()
            return
        }
        val o = gifOpts(info)
        cancelGif.set(false)
        val tv = Ui.text(this, "…", 14f, Ui.TEXT).apply { setPadding(dp(this@ExportActivity, 22), dp(this@ExportActivity, 8), dp(this@ExportActivity, 22), 0) }
        val dlg = AlertDialog.Builder(this)
            .setTitle(R.string.export_notif_title)
            .setView(tv)
            .setCancelable(false)
            .setNegativeButton(android.R.string.cancel) { _, _ -> cancelGif.set(true) }
            .create()
        dlg.show()
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Thread {
            var res: Uri? = null
            var err: String? = null
            try {
                res = GifExport.run(this, u, name, o, cancelGif) { n, t -> ui.post { tv.text = getString(R.string.export_gif_working, n, t) } }
            } catch (t: Throwable) {
                err = if (cancelGif.get()) null else (t.message ?: t.javaClass.simpleName)
            }
            ui.post {
                window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                if (isDestroyed) return@post
                runCatching { dlg.dismiss() }
                if (res != null) {
                    val r = res
                    AlertDialog.Builder(this)
                        .setMessage(getString(R.string.export_gif_done_fmt, fmtBytes(sizeOf(r))))
                        .setPositiveButton(R.string.export_open) { _, _ -> openResult(r) }
                        .setNegativeButton(android.R.string.ok, null)
                        .show()
                } else if (err != null) {
                    AlertDialog.Builder(this).setMessage(getString(R.string.export_failed_fmt, err)).setPositiveButton(android.R.string.ok, null).show()
                }
            }
        }.start()
    }

    private fun fmtBytes(b: Long): String = when {
        b >= 1L shl 30 -> String.format(java.util.Locale.US, "%.2f GB", b / 1073741824.0)
        b >= 1L shl 20 -> String.format(java.util.Locale.US, "%.1f MB", b / 1048576.0)
        b >= 1L shl 10 -> String.format(java.util.Locale.US, "%d KB", b shr 10)
        else -> "$b B"
    }

    /** Size of a file in bytes (0 when the provider does not tell). */
    private fun sizeOf(u: Uri): Long = runCatching {
        contentResolver.query(u, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { if (it.moveToFirst()) it.getLong(0) else 0L }
    }.getOrNull() ?: 0L

    private fun showProgress() {
        val j = ExportState.job
        box.addView(Ui.text(this, getString(R.string.export_title), 22f, Ui.TEXT, true))
        box.addView(Ui.text(this, j?.name ?: "", 15f, Ui.TEXT, true), gap(10))
        val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000 }
        bar = pb
        box.addView(pb, gap(14))
        lineA = Ui.text(this, "", 15f, Ui.TEXT, true).also { box.addView(it, gap(8)) }
        lineB = Ui.text(this, "", 13f, Ui.MUTED).also { box.addView(it, gap(4)) }
        lineC = Ui.text(this, "", 13f, Ui.MUTED).also { box.addView(it, gap(4)) }
        val w = button(getString(R.string.export_watch), false) { watchParts() }
        watchBtn = w
        box.addView(w, gap(18))
        if (j?.stream == true) {
            box.addView(button(getString(R.string.stream_save_ready), false) {
                if (ExportState.segs.isEmpty()) Toast.makeText(this, R.string.stream_nothing, Toast.LENGTH_SHORT).show()
                else {
                    ExportState.saving = true
                    Toast.makeText(this, R.string.stream_saving, Toast.LENGTH_SHORT).show()
                    Thread {
                        val files = runCatching { ExportState.saveReady(this) }.getOrDefault(emptyList())
                        ui.post { if (!isDestroyed) Toast.makeText(this, if (files.isEmpty()) getString(R.string.stream_save_failed) else getString(R.string.stream_saved_fmt, files.size), Toast.LENGTH_LONG).show() }
                    }.start()
                }
            }, gap(10))
            box.addView(Ui.text(this, getString(R.string.export_stream_running), 12f, Ui.MUTED), gap(10))
        } else {
            box.addView(button(getString(R.string.export_pause), false) { ExportService.pause(this) }, gap(10))
            box.addView(button(getString(R.string.export_save_partial), false) {
                AlertDialog.Builder(this)
                    .setMessage(R.string.export_save_partial_ask)
                    .setPositiveButton(android.R.string.ok) { _, _ -> ExportService.saveAndStop(this) }
                    .setNegativeButton(android.R.string.cancel, null)
                    .show()
            }, gap(10))
        }
        box.addView(button(getString(R.string.export_cancel), false) {
            AlertDialog.Builder(this)
                .setMessage(R.string.export_cancel_ask)
                .setPositiveButton(android.R.string.ok) { _, _ -> ExportService.cancel(this) }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        }, gap(10))
        box.addView(Ui.text(this, getString(R.string.export_bg_hint), 12f, Ui.MUTED), gap(14))
        update()
    }

    private fun levelLabel(l: Int) = getString(
        when (l) {
            0 -> R.string.export_ai_off
            4 -> R.string.export_ai_vlight
            1 -> R.string.export_ai_light
            2 -> R.string.export_ai_medium
            else -> R.string.export_ai_heavy
        }
    )

    private fun fmtTime(sec: Long): String {
        val s = sec.coerceAtLeast(0)
        return if (s >= 3600) String.format(java.util.Locale.US, "%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60) else String.format(java.util.Locale.US, "%d:%02d", s / 60, s % 60)
    }

    private fun update() {
        if (shownRunning != ExportState.running) {
            refresh()
            return
        }
        if (!ExportState.running) return
        val total = ExportState.totalUs
        val done = ExportState.doneUs
        val pct = if (total > 0) (done * 1000 / total).toInt().coerceIn(0, 1000) else 0
        val sp = ExportState.speed
        val n = ExportState.segs.size
        val soFar = ExportState.segs.sumOf { it.file.length() }
        if (ExportState.job?.stream == true) {
            // "Watch now": a percentage of the whole video means nothing; show how much is ready ahead of the viewer instead
            val ref = if (ExportState.playUs >= 0L) ExportState.playUs else (ExportState.job?.rangeStartUs ?: 0L)
            var end = ref
            for (s in ExportState.segs.sortedBy { it.startUs }) {
                if (s.startUs <= end + 400_000L && s.startUs + s.durUs > end) end = s.startUs + s.durUs
            }
            val aheadSec = ((end - ref) / 1_000_000L).coerceAtLeast(0L)
            val goal = getSharedPreferences("crsc", Context.MODE_PRIVATE).getInt("stream_ahead_s", 0).let { if (it > 0) it else 60 }
            bar?.progress = (aheadSec * 1000L / goal).toInt().coerceIn(0, 1000)
            lineA?.text = getString(R.string.stream_ready_fmt, fmtTime(aheadSec))
            lineB?.text = when {
                sp <= 0f -> getString(R.string.export_speed_wait)
                sp >= 1.05f -> getString(R.string.stream_speed_fast_fmt, sp)
                else -> getString(R.string.stream_speed_slow_fmt, sp)
            }
            lineC?.text = getString(R.string.stream_disk_fmt, n, fmtBytes(soFar))
        } else {
            bar?.progress = pct
            lineA?.text = getString(R.string.export_progress_fmt, pct / 10, fmtTime(done / 1_000_000), fmtTime(total / 1_000_000))
            lineB?.text = if (sp > 0f && total > 0) {
                val left = ((total - done) / 1_000_000f / sp).toLong()
                getString(R.string.export_speed_fmt, sp, fmtTime(left))
            } else getString(R.string.export_speed_wait)
            lineC?.text = getString(R.string.export_pieces_fmt, n) +
                (if (soFar > 0) "\n" + (if (done > 0) getString(R.string.export_size_fmt, fmtBytes(soFar), fmtBytes(soFar * total / done)) else getString(R.string.export_size_only_fmt, fmtBytes(soFar))) else "")
        }
        watchBtn?.alpha = if (n > 0) 1f else 0.4f
        lastSegCount = n
        val ready = ExportState.segs.sumOf { it.durUs } / 1_000_000f
        val need = if (sp >= 1.2f || sp <= 0f) 6f else (20f / sp).coerceIn(8f, 120f) // slower than the video: wait for a bigger head start
        if (ExportState.job?.stream == true && n >= 1 && ready >= need && !ExportState.autoOpened) {
            ExportState.autoOpened = true // the player opens by itself once, when the first piece is ready (not again when this screen is opened later)
            watchParts()
        }
    }

    // ---- actions ----------------------------------------------------------------------------------

    private fun pick() {
        AlertDialog.Builder(this)
            .setItems(arrayOf(getString(R.string.export_pick_lib), getString(R.string.export_pick_lib_gif), getString(R.string.export_pick_files))) { _, w ->
                @Suppress("DEPRECATION")
                if (w < 2) {
                    startActivityForResult(
                        Intent(this, LibraryActivity::class.java).putExtra(LibraryArgs.PICK, true).putExtra(LibraryArgs.PICK_TAB, if (w == 0) 0 else 3), REQ_LIB
                    )
                } else {
                    val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
                        .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("video/*", "image/gif"))
                    startActivityForResult(i, REQ_PICK)
                }
            }
            .show()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val u = data?.data
        if (req == REQ_LIB && res == RESULT_OK && u != null) {
            setSource(u, data.getStringExtra(LibraryArgs.NAME) ?: nameOf(u))
            refresh()
        }
        if (req == REQ_PICK && res == RESULT_OK && u != null) {
            runCatching { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            setSource(u, nameOf(u))
            refresh()
        }
    }

    private fun onlineVideoDialog() {
        val u = uri
        if (u == null) {
            Toast.makeText(this, R.string.export_need_video, Toast.LENGTH_SHORT).show()
            return
        }
        if (OnlineVideoState.running) {
            Toast.makeText(this, R.string.export_busy, Toast.LENGTH_SHORT).show()
            return
        }
        if (!Online.hasKey(this)) {
            Online.showSettings(this)
            return
        }
        val names = OnlineVideo.RESOLUTIONS
        var pick = 1
        AlertDialog.Builder(this)
            .setTitle(R.string.ovid_title)
            .setMessage(getString(R.string.ovid_confirm, Online.videoModel(this), OnlineVideo.MAX_UPLOAD shr 20))
            .setSingleChoiceItems(names.toTypedArray(), pick) { _, w -> pick = w }
            .setPositiveButton(R.string.export_start) { _, _ ->
                val (s, e) = if (rangeOn) rangeUs() else (0L to 0L)
                OnlineVideoService.start(this, u, name, s, e, names[pick])
            }
            .setNeutralButton(R.string.online_settings) { _, _ -> Online.showSettings(this) }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun start() {
        val u = uri
        if (u == null) {
            Toast.makeText(this, R.string.export_need_video, Toast.LENGTH_SHORT).show()
            return
        }
        if (ExportState.running) {
            Toast.makeText(this, R.string.export_busy, Toast.LENGTH_SHORT).show()
            return
        }
        if (rangeOn) {
            val s = parseTime(rangeFrom) ?: 0L
            val e = parseTime(rangeTo)
            val dur = (srcInfo?.durUs ?: 0L) / 1_000_000L
            if ((e != null && e <= s) || (rangeTo.isNotBlank() && e == null) || (rangeFrom.isNotBlank() && parseTime(rangeFrom) == null) || (dur > 0 && s >= dur)) {
                Toast.makeText(this, R.string.export_range_invalid, Toast.LENGTH_LONG).show()
                return
            }
        }
        if (vAiAuto) {
            srcInfo?.let { i ->
                val frames = (if (rangeOn) { val (a, b) = rangeUs(); (if (b > a) b - a else (i.durUs - a).coerceAtLeast(0L)) } else i.durUs) / 1e6 * i.fps
                val (l, h) = VideoAiAuto.pick(this, i.dispW, i.dispH, frames)
                vAi = l
                vAiHalf = h
            }
        }
        if (vAi > 0 && VideoAi.modelFor(this, vAi) == null) {
            Toast.makeText(this, R.string.export_ai_need_model, Toast.LENGTH_LONG).show()
            return
        }
        if (streamOn && !liveOn && adviseStream()) return // (Smooth live has its own size: the screen)
        launchExport(u)
    }

    private fun launchExport(u: Uri) {
        ExportState.autoOpened = false
        ExportService.start(this, u, name, currentOpts())
        ui.postDelayed({ refresh() }, 300)
    }

    /**
     * "Watch now" can only play smoothly when the phone makes the picture at least as fast as the video plays. When the guess says it
     * will not (e.g. 4K on a middle-class phone) the person is told and can take a smaller size that will be smooth. Returns true when
     * a question was shown (the export starts from its buttons).
     */
    private fun adviseStream(): Boolean {
        val u = uri ?: return false
        val i = srcInfo ?: return false
        val o = currentOpts()
        val now = ExportInfo.streamSpeed(this, i, o)
        if (now >= 0.95f) return false
        val better = intArrayOf(2160, 1440, 1080, 720, 480).filter { it < target }.firstOrNull { ExportInfo.streamSpeed(this, i, o.withTarget(it)) >= 1.1f }
        val b = AlertDialog.Builder(this)
        if (better != null) {
            val sp2 = ExportInfo.streamSpeed(this, i, o.withTarget(better))
            b.setMessage(getString(R.string.stream_advice_fmt, target, now, better, sp2))
            b.setPositiveButton(getString(R.string.stream_advice_use_fmt, better)) { _, _ ->
                target = better
                refresh()
                launchExport(u)
            }
            b.setNeutralButton(R.string.stream_advice_keep) { _, _ -> launchExport(u) }
        } else {
            b.setMessage(getString(R.string.stream_advice_none_fmt, target, now))
            b.setPositiveButton(R.string.stream_advice_keep) { _, _ -> launchExport(u) }
        }
        b.setNegativeButton(android.R.string.cancel, null).show()
        return true
    }

    private fun parts(): ArrayList<String> = ArrayList(ExportState.segs.sortedBy { it.startUs }.map { Uri.fromFile(it.file).toString() })

    private fun watchParts() {
        ExportState.autoOpened = true // (opened by hand or by itself: this screen must never open the player again after it was closed)
        val l = parts()
        if (l.isEmpty()) {
            Toast.makeText(this, R.string.export_no_parts, Toast.LENGTH_SHORT).show()
            return
        }
        // the whole video on one timeline; the player plays the finished pieces one after another without a gap (a file export
        // keeps going while it is watched; a stream also prepares around the spot that is watched)
        startActivity(Intent(this, PlayerActivity::class.java).setData(Uri.parse(l[0])).putExtra(PlayerArgs.FROM_LIB, true).putExtra(PlayerArgs.STREAM, true))
    }

    private fun openResult(r: Uri) {
        startActivity(Intent(this, PlayerActivity::class.java).setData(r).putExtra(PlayerArgs.FROM_LIB, true))
    }

    companion object {
        const val X_NAME = "app.clearoverlay.EXPORT_NAME"
        const val X_LIVE = "app.clearoverlay.EXPORT_LIVE"
        /** The order of the frame generation levels on screen (3 = very light is listed first). */
        private val FG_Q_ORDER = intArrayOf(3, 0, 1, 2)
        private const val REQ_PICK = 31
        private const val REQ_LIB = 33
    }
}
