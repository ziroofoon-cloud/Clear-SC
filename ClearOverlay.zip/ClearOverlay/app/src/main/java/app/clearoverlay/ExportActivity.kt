package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * "Upscale a video to a new file": pick the size and the quality, start, watch the progress. The work itself runs in
 * [ExportService]; this screen only shows [ExportState] and can be closed and opened again at any time.
 */
class ExportActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var box: LinearLayout
    private var uri: Uri? = null
    private var name = ""
    private var target = 1080
    private var tier = 1
    private var anime = false
    private var hevc = false
    private var upMode = Cfg.MODE_FSR
    private var shownRunning: Boolean? = null
    private var lastSegCount = -1

    // progress widgets
    private var bar: ProgressBar? = null
    private var lineA: TextView? = null
    private var lineB: TextView? = null
    private var lineC: TextView? = null
    private var watchBtn: TextView? = null

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Cfg.load(this)
        Ui.init(this)
        setTheme(Ui.theme())
        super.onCreate(savedInstanceState)
        Ui.styleBars(window)
        intent?.data?.let {
            uri = it
            name = intent.getStringExtra(X_NAME) ?: nameOf(it)
        }
        val root = ScrollView(this).apply { setBackgroundColor(Ui.BG) }
        box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(this@ExportActivity, 18), dp(this@ExportActivity, 22), dp(this@ExportActivity, 18), dp(this@ExportActivity, 28))
        }
        root.addView(box, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        ui.post(tick)
    }

    override fun onPause() {
        ui.removeCallbacks(tick)
        super.onPause()
    }

    private val tick: Runnable = object : Runnable {
        override fun run() {
            if (isDestroyed) return
            update()
            ui.postDelayed(this, 600)
        }
    }

    private fun nameOf(u: Uri): String = runCatching {
        contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
    }.getOrNull() ?: (u.lastPathSegment ?: "video").substringAfterLast('/')

    private fun gap(v: Int) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@ExportActivity, v) }

    private fun button(label: String, primary: Boolean, onClick: () -> Unit) = Ui.text(this, label, 16f, if (primary) Ui.BG else Ui.ACCENT, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(this@ExportActivity, 14), dp(this@ExportActivity, 13), dp(this@ExportActivity, 14), dp(this@ExportActivity, 13))
        background = if (primary) Ui.gradient(dp(this@ExportActivity, 14).toFloat()) else Ui.round(Ui.CHIP, dp(this@ExportActivity, 14).toFloat())
        setOnClickListener { onClick() }
    }

    /** A row of equal chips; [onPick] gets the index. */
    private fun chips(labels: List<String>, selected: Int, onPick: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this)
        val views = ArrayList<TextView>()
        fun paint(sel: Int) {
            val r = dp(this, 10).toFloat()
            views.forEachIndexed { i, c ->
                if (i == sel) {
                    c.background = Ui.gradient(r)
                    c.setTextColor(Ui.BG)
                } else {
                    c.background = Ui.round(Ui.CHIP, r)
                    c.setTextColor(Ui.MUTED)
                }
            }
        }
        labels.forEachIndexed { i, l ->
            val c = TextView(this).apply {
                text = l
                textSize = 14f
                gravity = Gravity.CENTER
                setPadding(dp(this@ExportActivity, 6), dp(this@ExportActivity, 10), dp(this@ExportActivity, 6), dp(this@ExportActivity, 10))
                setOnClickListener {
                    paint(i)
                    onPick(i)
                }
            }
            views.add(c)
            row.addView(c, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i > 0) marginStart = dp(this@ExportActivity, 6) })
        }
        paint(selected)
        return row
    }

    // ---- screens ----------------------------------------------------------------------------------

    private fun refresh() {
        box.removeAllViews()
        bar = null
        lineA = null
        lineB = null
        lineC = null
        watchBtn = null
        shownRunning = ExportState.running
        lastSegCount = -1
        if (ExportState.running) showProgress() else showConfig()
    }

    private fun showConfig() {
        box.addView(Ui.text(this, getString(R.string.export_title), 22f, Ui.TEXT, true))
        box.addView(Ui.text(this, getString(R.string.export_note), 13f, Ui.MUTED), gap(8))
        if (ExportState.finished) box.addView(finishedCard(), gap(14))

        box.addView(Ui.text(this, if (uri == null) getString(R.string.export_need_video) else name, 15f, Ui.TEXT, true), gap(16))
        box.addView(button(getString(R.string.export_pick), false) { pick() }, gap(8))

        box.addView(Ui.text(this, getString(R.string.export_target), 13f, Ui.ACCENT, true), gap(18))
        box.addView(chips(listOf("720p", "1080p"), if (target == 720) 0 else 1) { target = if (it == 0) 720 else 1080 }, gap(6))

        box.addView(Ui.text(this, getString(R.string.export_tier), 13f, Ui.ACCENT, true), gap(16))
        val desc = Ui.text(this, tierDesc(), 12f, Ui.MUTED)
        box.addView(chips(listOf(getString(R.string.export_tier_fast), getString(R.string.export_tier_med), getString(R.string.export_tier_high)), tier) {
            tier = it
            desc.text = tierDesc()
        }, gap(6))
        box.addView(desc, gap(6))

        box.addView(Ui.text(this, getString(R.string.export_content), 13f, Ui.ACCENT, true), gap(16))
        box.addView(chips(listOf(getString(R.string.export_content_video), getString(R.string.export_content_anime)), if (anime) 1 else 0) { anime = it == 1 }, gap(6))

        box.addView(Ui.text(this, getString(R.string.export_upscaler), 13f, Ui.ACCENT, true), gap(16))
        box.addView(chips(listOf("FSR 1", "SGSR 1"), if (upMode == Cfg.MODE_SGSR) 1 else 0) { upMode = if (it == 1) Cfg.MODE_SGSR else Cfg.MODE_FSR }, gap(6))

        box.addView(Ui.text(this, getString(R.string.export_encoder), 13f, Ui.ACCENT, true), gap(16))
        box.addView(chips(listOf("H.264", "H.265"), if (hevc) 1 else 0) { hevc = it == 1 }, gap(6))
        box.addView(Ui.text(this, getString(R.string.export_encoder_hint), 12f, Ui.MUTED), gap(6))

        box.addView(button(getString(R.string.export_start), true) { start() }, gap(24))
    }

    private fun tierDesc() = getString(
        when (tier) {
            0 -> R.string.export_tier_fast_desc
            2 -> R.string.export_tier_high_desc
            else -> R.string.export_tier_med_desc
        }
    )

    private fun finishedCard(): View {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.round(Ui.CARD, dp(this@ExportActivity, 14).toFloat())
            setPadding(dp(this@ExportActivity, 14), dp(this@ExportActivity, 12), dp(this@ExportActivity, 14), dp(this@ExportActivity, 12))
        }
        val r = ExportState.result
        val err = ExportState.error
        when {
            r != null -> {
                c.addView(Ui.text(this, getString(R.string.export_done), 14f, Ui.OK, true))
                if (AudioNote.skipped) c.addView(Ui.text(this, getString(R.string.export_nosound), 12f, Ui.MUTED), gap(4))
                c.addView(button(getString(R.string.export_open), false) { openResult(r) }, gap(10))
            }
            err != null -> c.addView(Ui.text(this, getString(R.string.export_failed_fmt, err), 13f, Ui.DANGER))
            ExportState.cancelled -> c.addView(Ui.text(this, getString(R.string.export_cancelled), 14f, Ui.MUTED))
        }
        return c
    }

    private fun showProgress() {
        val j = ExportState.job
        box.addView(Ui.text(this, getString(R.string.export_title), 22f, Ui.TEXT, true))
        box.addView(Ui.text(this, j?.name ?: "", 15f, Ui.TEXT, true), gap(10))
        val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000 }
        bar = pb
        box.addView(pb, gap(14))
        lineA = Ui.text(this, "", 15f, Ui.TEXT, true).also { box.addView(it, gap(8)) }
        lineB = Ui.text(this, "", 13f, Ui.MUTED).also { box.addView(it, gap(4)) }
        lineC = Ui.text(this, "", 13f, Ui.MUTED).also { box.addView(it, gap(4)) }
        val w = button(getString(R.string.export_watch), false) { watchParts() }
        watchBtn = w
        box.addView(w, gap(18))
        box.addView(button(getString(R.string.export_cancel), false) {
            AlertDialog.Builder(this)
                .setMessage(R.string.export_cancel_ask)
                .setPositiveButton(android.R.string.ok) { _, _ -> ExportService.cancel(this) }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        }, gap(10))
        box.addView(Ui.text(this, getString(R.string.export_bg_hint), 12f, Ui.MUTED), gap(14))
        update()
    }

    private fun fmtTime(sec: Long): String {
        val s = sec.coerceAtLeast(0)
        return if (s >= 3600) String.format("%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60) else String.format("%d:%02d", s / 60, s % 60)
    }

    private fun update() {
        if (shownRunning != ExportState.running) {
            refresh()
            return
        }
        if (!ExportState.running) return
        val total = ExportState.totalUs
        val done = ExportState.doneUs
        val pct = if (total > 0) (done * 1000 / total).toInt().coerceIn(0, 1000) else 0
        bar?.progress = pct
        lineA?.text = getString(R.string.export_progress_fmt, pct / 10, fmtTime(done / 1_000_000), fmtTime(total / 1_000_000))
        val sp = ExportState.speed
        lineB?.text = if (sp > 0f && total > 0) {
            val left = ((total - done) / 1_000_000f / sp).toLong()
            getString(R.string.export_speed_fmt, sp, fmtTime(left))
        } else getString(R.string.export_speed_wait)
        val n = ExportState.segs.size
        lineC?.text = getString(R.string.export_pieces_fmt, n)
        watchBtn?.alpha = if (n > 0) 1f else 0.4f
        lastSegCount = n
    }

    // ---- actions ----------------------------------------------------------------------------------

    private fun pick() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("video/*")
        @Suppress("DEPRECATION")
        startActivityForResult(i, REQ_PICK)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val u = data?.data
        if (req == REQ_PICK && res == RESULT_OK && u != null) {
            runCatching { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            uri = u
            name = nameOf(u)
            refresh()
        }
    }

    private fun start() {
        val u = uri
        if (u == null) {
            Toast.makeText(this, R.string.export_need_video, Toast.LENGTH_SHORT).show()
            return
        }
        if (ExportState.running) {
            Toast.makeText(this, R.string.export_busy, Toast.LENGTH_SHORT).show()
            return
        }
        ExportService.start(this, u, name, target, tier, anime, hevc, upMode)
        ui.postDelayed({ refresh() }, 300)
    }

    private fun parts(): ArrayList<String> = ArrayList(ExportState.segs.sortedBy { it.startUs }.map { Uri.fromFile(it.file).toString() })

    private fun watchParts() {
        val l = parts()
        if (l.isEmpty()) {
            Toast.makeText(this, R.string.export_no_parts, Toast.LENGTH_SHORT).show()
            return
        }
        val i = Intent(this, PlayerActivity::class.java).setData(Uri.parse(l[0])).putExtra(PlayerArgs.FROM_LIB, true)
        if (l.size > 1) {
            i.putExtra(PlayerArgs.INDEX, 0)
            i.putStringArrayListExtra(PlayerArgs.LIST, l)
        }
        startActivity(i)
    }

    private fun openResult(r: Uri) {
        startActivity(Intent(this, PlayerActivity::class.java).setData(r).putExtra(PlayerArgs.FROM_LIB, true))
    }

    companion object {
        const val X_NAME = "app.clearoverlay.EXPORT_NAME"
        private const val REQ_PICK = 31
    }
}
