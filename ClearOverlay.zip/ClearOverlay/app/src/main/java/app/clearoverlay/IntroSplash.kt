package app.clearoverlay

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * The short opening scene of the app (first start of the process only), kept minimal: the dark background of the system splash with one soft
 * glow, the ring that draws itself, the plus, the name and one quiet line under it, then a quick fade to the app.
 * A tap skips it. Nothing is shown when the phone has animations switched off. (The system's own splash screen before it, with the same
 * background and the icon, is set in `Theme.Crsc.Launch`.)
 */
object IntroSplash {
    private var shown = false

    private const val PREF = "intro"

    /** The setting "Opening scene" (main screen), on by default. */
    fun enabled(c: Context): Boolean = runCatching { c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean("on", true) }.getOrDefault(true)

    fun setEnabled(c: Context, on: Boolean) {
        runCatching { c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putBoolean("on", on).apply() }
    }

    /** How long the animated scene stays before it fades (ms), set on the main screen; 500 - 5000, default 1800. */
    const val HOLD_MIN = 500
    const val HOLD_MAX = 5000
    const val HOLD_DEFAULT = 1500

    fun holdMs(c: Context): Int = runCatching { c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getInt("hold", HOLD_DEFAULT) }.getOrDefault(HOLD_DEFAULT).coerceIn(HOLD_MIN, HOLD_MAX)

    fun setHoldMs(c: Context, ms: Int) {
        runCatching { c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putInt("hold", ms.coerceIn(HOLD_MIN, HOLD_MAX)).apply() }
    }

    // ---- how long the plain-logo part (the system splash = the app really loading) took on the last cold start
    private var createAt = 0L

    /** Call first thing in onCreate of the main screen. */
    fun markCreate() {
        if (createAt == 0L) createAt = android.os.SystemClock.elapsedRealtime()
    }

    /** Call after the screen is set: records process start -> first frame (and -> onCreate) once per process. */
    fun measureFirstFrame(a: Activity) {
        val c0 = createAt
        if (c0 == 0L) return
        val start = android.os.Process.getStartElapsedRealtime()
        val v = a.window.decorView
        v.viewTreeObserver.addOnPreDrawListener(object : android.view.ViewTreeObserver.OnPreDrawListener {
            override fun onPreDraw(): Boolean {
                v.viewTreeObserver.removeOnPreDrawListener(this)
                val frame = android.os.SystemClock.elapsedRealtime() - start
                val boot = c0 - start
                // only a real cold start (a process that was started a moment ago), not a late first opening of an old process
                if (frame in 1..15000) {
                    runCatching { a.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putInt("frame_ms", frame.toInt()).putInt("boot_ms", boot.toInt()).apply() }
                }
                return true
            }
        })
    }

    /** "frame, boot" in ms of the last cold start, or null. */
    fun lastStart(c: Context): Pair<Int, Int>? = runCatching {
        val p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        if (!p.contains("frame_ms")) null else p.getInt("frame_ms", 0) to p.getInt("boot_ms", 0)
    }.getOrNull()

    /** True when the main screen is on the screen (set by [markReady]): the scene does not fade before that. */
    @Volatile private var ready = false

    fun markReady() { ready = true }

    /**
     * The main screen is built on the main thread in one go (it takes a good part of a second on a slow phone) and nothing is drawn meanwhile:
     * built while the ring is drawing, the scene stuttered. So it is built when the scene's own motion (ring, plus, name) is over and only the
     * calm background is moving. [begin] returned a scene: wait this long first.
     */
    const val BUILD_AFTER_MS = 1050L

    /**
     * Opening scene, started BEFORE the main screen is built: it becomes the first thing the window draws (so the system splash leaves at once),
     * and the main screen is built behind it while it plays, then put under it ([markReady]). Returns the layout the main screen must be added to
     * (at index 0), or null when there is no scene (not opened from the launcher, switched off, animations off): then the caller sets its screen as usual.
     */
    fun begin(a: Activity, version: String): FrameLayout? {
        if (shown) return null
        // only when the person opened the app from the launcher (not from a notification, a shortcut or another screen), and has not switched it off
        val i = a.intent
        if (i == null || i.action != android.content.Intent.ACTION_MAIN || !i.hasCategory(android.content.Intent.CATEGORY_LAUNCHER)) return null
        shown = true
        if (!enabled(a)) return null
        val scale = runCatching { Settings.Global.getFloat(a.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) }.getOrDefault(1f)
        if (scale == 0f) return null
        ready = false
        val host = FrameLayout(a).apply { setBackgroundColor(0xFF0B0F26.toInt()) } // the colour of the system splash
        a.setContentView(host)
        val root = IntroView(a, version, holdMs(a))
        host.addView(root, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.start()
        return host
    }

    /** The logo of the scene: a faint ring that is drawn in full, from nothing, by a bright arc (cyan to violet), then the plus pops in. */
    private class RingLogo(ctx: Context) : View(ctx) {
        var sweep = 0f // 0..1: how much of the ring is drawn
        var plus = 0f  // 0..1.2: size of the plus
        private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0x2467E8F9 }
        private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        private val shade = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = 0x55000000 }
        private val white = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = Color.WHITE }
        private val rect = android.graphics.RectF()
        private var shaderSize = 0f

        override fun onDraw(c: Canvas) {
            val s = minOf(width, height).toFloat()
            if (s <= 0f) return
            val cx = s / 2f
            val cy = s / 2f
            val r = s * 0.40f
            val sw = s * 0.07f
            if (shaderSize != s) {
                arc.shader = LinearGradient(cx - r, cy - r, cx + r, cy + r, 0xFF67E8F9.toInt(), 0xFFA78BFA.toInt(), Shader.TileMode.CLAMP)
                shaderSize = s
            }
            track.strokeWidth = sw
            c.drawCircle(cx, cy, r, track)
            if (sweep > 0f) {
                arc.strokeWidth = sw
                rect.set(cx - r, cy - r, cx + r, cy + r)
                c.drawArc(rect, -90f, 360f * sweep.coerceAtMost(1f), false, arc)
            }
            if (plus > 0f) {
                val k = s * 0.15f
                val pw = s * 0.085f
                c.save()
                c.scale(plus, plus, cx, cy)
                shade.strokeWidth = pw
                c.drawLine(cx, cy - k + pw * 0.2f, cx, cy + k + pw * 0.2f, shade)
                c.drawLine(cx - k, cy + pw * 0.2f, cx + k, cy + pw * 0.2f, shade)
                white.strokeWidth = pw
                c.drawLine(cx, cy - k, cx, cy + k, white)
                c.drawLine(cx - k, cy, cx + k, cy, white)
                c.restore()
            }
        }
    }

    /** The background: the flat colour of the system splash, a very faint vertical shade and one soft glow behind the logo that breathes slowly. Nothing else moves. */
    private class BgView(ctx: Context) : View(ctx) {
        var t = 0f // 0..1, loops
        private val base = Paint(Paint.ANTI_ALIAS_FLAG)
        private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
        private var sizeKey = 0L
        private var big = 0f

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            if (w <= 0f || h <= 0f) return
            val key = width * 100003L + height
            if (key != sizeKey) {
                sizeKey = key
                big = maxOf(w, h)
                base.shader = LinearGradient(0f, 0f, 0f, h, intArrayOf(0xFF0B0F26.toInt(), 0xFF0B0F26.toInt(), 0xFF15154A.toInt()), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
                // made around (0, 0) and moved with the canvas
                glow.shader = RadialGradient(0f, 0f, big * 0.55f, 0x4D7C6CF0, 0x007C6CF0, Shader.TileMode.CLAMP)
            }
            c.drawRect(0f, 0f, w, h, base)
            val breathe = 0.85f + 0.15f * Math.sin(t * 2.0 * Math.PI).toFloat()
            c.save()
            c.translate(w / 2f, h * 0.40f)
            c.scale(breathe, breathe)
            c.drawRect(-big, -big, big, big, glow)
            c.restore()
        }
    }

    private class IntroView(ctx: Context, version: String, private val hold: Int) : FrameLayout(ctx) {
        private val bg = BgView(ctx)
        private val logo = RingLogo(ctx).apply { importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO }
        private val title: TextView
        private val tag: TextView
        private val ver: TextView
        private var loop: ValueAnimator? = null
        private var finished = false
        private val d = ctx.resources.displayMetrics.density

        init {
            isClickable = true // swallow touches while it is up
            setOnClickListener { tryFinish(0) }
            addView(bg, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
            col.addView(logo, LinearLayout.LayoutParams((96 * d).toInt(), (96 * d).toInt()))
            title = TextView(ctx).apply {
                text = "+CRSC"
                setTextColor(Color.WHITE)
                textSize = 28f
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                letterSpacing = 0.24f
                gravity = Gravity.CENTER
            }
            col.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = (20 * d).toInt() })
            tag = TextView(ctx).apply {
                text = ctx.getString(R.string.intro_tagline)
                setTextColor(0xFF8F98C4.toInt())
                textSize = 13f
                letterSpacing = 0.05f
                gravity = Gravity.CENTER
            }
            col.addView(tag, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = (6 * d).toInt() })
            // the logo sits at 40% of the height: the column is moved up by the same
            addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER).apply { bottomMargin = (110 * d).toInt() })
            ver = TextView(ctx).apply {
                text = "v$version"
                setTextColor(0xFF5E668C.toInt())
                textSize = 11f
                letterSpacing = 0.08f
            }
            addView(ver, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = (36 * d).toInt() })
            bg.alpha = 0f // fades in from the flat colour of the system splash (no jump)
            title.alpha = 0f
            tag.alpha = 0f
            ver.alpha = 0f
        }

        fun start() {
            loop = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = maxOf(6000L, hold + 600L) // longer than the scene: the glow never wraps
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                addUpdateListener { bg.t = it.animatedValue as Float; bg.invalidate() }
                start()
            }
            bg.animate().alpha(1f).setDuration(300).start()
            // the ring draws itself from nothing (0.6 s), then the plus pops in; the same moment-to-moment on every start
            val od = OvershootInterpolator(1.2f)
            val dc = DecelerateInterpolator(1.6f)
            ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 1000
                interpolator = LinearInterpolator()
                addUpdateListener {
                    val t = it.animatedValue as Float
                    logo.sweep = dc.getInterpolation((t / 0.6f).coerceIn(0f, 1f))
                    logo.plus = od.getInterpolation(((t - 0.45f) / 0.35f).coerceIn(0f, 1f))
                    logo.invalidate()
                }
                start()
            }
            title.translationY = 8 * d
            title.animate().alpha(1f).translationY(0f).setStartDelay(520).setDuration(420).setInterpolator(DecelerateInterpolator()).start()
            tag.translationY = 6 * d
            tag.animate().alpha(1f).translationY(0f).setStartDelay(640).setDuration(420).setInterpolator(DecelerateInterpolator()).start()
            ver.animate().alpha(1f).setStartDelay(760).setDuration(350).start()
            postDelayed({ tryFinish(0) }, hold.toLong())
        }

        /** Fades only when the main screen is there (a slow start would show an empty screen); gives up waiting after 4 s. */
        private fun tryFinish(waited: Int) {
            if (finished) return
            if (!ready && waited < 4000) { postDelayed({ tryFinish(waited + 60) }, 60); return }
            finish()
        }

        private fun finish() {
            if (finished) return
            finished = true
            animate().alpha(0f).setDuration(240).setListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    loop?.cancel()
                    (parent as? ViewGroup)?.removeView(this@IntroView)
                }
            }).start()
        }

        override fun onDetachedFromWindow() {
            loop?.cancel()
            super.onDetachedFromWindow()
        }
    }
}
