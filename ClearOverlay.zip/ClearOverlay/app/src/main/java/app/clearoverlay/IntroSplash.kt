package app.clearoverlay

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * The short opening scene of the app (first start of the process only): the dark violet background of the icon with two slowly drifting
 * glows, rings that spread from the logo, the logo that pops in, the name and one line under it, then everything fades away to the app.
 * A tap skips it. Nothing is shown when the phone has animations switched off. (The system's own splash screen before it, with the same
 * background and the icon, is set in `Theme.Crsc.Launch`.)
 */
object IntroSplash {
    private var shown = false

    private const val PREF = "intro"

    /** The setting "Opening scene" (main screen), on by default. */
    fun enabled(c: Context): Boolean = runCatching { c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean("on", true) }.getOrDefault(true)

    fun setEnabled(c: Context, on: Boolean) {
        runCatching { c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putBoolean("on", on).apply() }
    }

    fun show(a: Activity, version: String) {
        if (shown) return
        // only when the person opened the app from the launcher (not from a notification, a shortcut or another screen), and has not switched it off
        val i = a.intent
        if (i == null || i.action != android.content.Intent.ACTION_MAIN || !i.hasCategory(android.content.Intent.CATEGORY_LAUNCHER)) return
        shown = true
        if (!enabled(a)) return
        val scale = runCatching { Settings.Global.getFloat(a.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) }.getOrDefault(1f)
        if (scale == 0f) return
        val root = IntroView(a, version)
        a.addContentView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.start()
    }

    /** The moving background: gradient, two glows and the spreading rings. */
    private class BgView(ctx: Context) : View(ctx) {
        var t = 0f // 0..1, loops
        private val base = Paint(Paint.ANTI_ALIAS_FLAG)
        private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val spark = Paint(Paint.ANTI_ALIAS_FLAG)
        // small sparks drifting up (fixed seed: the same pretty picture every time; the intro is shorter than one loop, so no jump at the wrap)
        private val sx = FloatArray(30)
        private val sy = FloatArray(30)
        private val sr = FloatArray(30)
        private val sv = FloatArray(30)
        private val sp = FloatArray(30)

        init {
            val r = java.util.Random(7)
            for (i in sx.indices) {
                sx[i] = r.nextFloat(); sy[i] = r.nextFloat(); sr[i] = 0.8f + r.nextFloat() * 1.8f
                sv[i] = 0.15f + r.nextFloat() * 0.3f; sp[i] = r.nextFloat() * 6.28f
            }
        }

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            if (w <= 0f || h <= 0f) return
            base.shader = LinearGradient(0f, 0f, w, h, intArrayOf(0xFF070B18.toInt(), 0xFF1E1B5C.toInt(), 0xFF4C3AB0.toInt()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, base)
            val ph = (t * 2.0 * Math.PI).toFloat()
            val big = maxOf(w, h)
            // cyan glow, upper left, drifting
            var cx = w * (0.25f + 0.12f * Math.sin(ph.toDouble()).toFloat())
            var cy = h * (0.28f + 0.07f * Math.cos(ph.toDouble()).toFloat())
            glow.shader = RadialGradient(cx, cy, big * 0.6f, 0x4422D3EE, 0x0022D3EE, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, glow)
            // violet glow, lower right, drifting the other way
            cx = w * (0.8f - 0.12f * Math.sin(ph.toDouble()).toFloat())
            cy = h * (0.78f + 0.06f * Math.cos((ph * 1.0).toDouble()).toFloat())
            glow.shader = RadialGradient(cx, cy, big * 0.65f, 0x55A78BFA, 0x00A78BFA, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, glow)
            // rings spreading from the logo
            val lx = w / 2f
            val ly = h * 0.40f
            for (k in 0 until 3) {
                val p = (t * 2f + k / 3f) % 1f
                ring.strokeWidth = 2.5f * resources.displayMetrics.density
                ring.color = Color.argb(((1f - p) * 70f).toInt(), 103, 232, 249)
                c.drawCircle(lx, ly, big * 0.08f + big * 0.5f * p, ring)
            }
            // sparks
            val dens = resources.displayMetrics.density
            for (i in sx.indices) {
                val yy = ((sy[i] - t * sv[i]) % 1f + 1f) % 1f
                val tw = 0.5f + 0.5f * Math.sin((t * 12.5f + sp[i]).toDouble()).toFloat()
                spark.color = Color.argb((120 * tw).toInt().coerceIn(0, 255), 199, 210, 254)
                c.drawCircle(sx[i] * w, yy * h, sr[i] * dens, spark)
            }
        }
    }

    private class IntroView(ctx: Context, version: String) : FrameLayout(ctx) {
        private val bg = BgView(ctx)
        private val logo = LogoView(ctx).apply { importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO }
        private val title: TextView
        private val tag: TextView
        private val ver: TextView
        private var loop: ValueAnimator? = null
        private var finished = false
        private val d = ctx.resources.displayMetrics.density

        init {
            isClickable = true // swallow touches while it is up
            setOnClickListener { finish() }
            addView(bg, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
            col.addView(logo, LinearLayout.LayoutParams((112 * d).toInt(), (112 * d).toInt()))
            title = TextView(ctx).apply {
                text = "+CRSC"
                setTextColor(Color.WHITE)
                textSize = 36f
                typeface = Typeface.DEFAULT_BOLD
                letterSpacing = 0.1f
                gravity = Gravity.CENTER
            }
            col.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = (22 * d).toInt() })
            tag = TextView(ctx).apply {
                text = ctx.getString(R.string.intro_tagline)
                setTextColor(0xFFC7D2FE.toInt())
                textSize = 14f
                gravity = Gravity.CENTER
            }
            col.addView(tag, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = (6 * d).toInt() })
            // the logo sits at 40% of the height: the column is moved up by the same
            addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER).apply { bottomMargin = (110 * d).toInt() })
            ver = TextView(ctx).apply {
                text = "v$version"
                setTextColor(0xFF94A3B8.toInt())
                textSize = 12f
            }
            addView(ver, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = (36 * d).toInt() })
            logo.alpha = 0f
            title.alpha = 0f
            tag.alpha = 0f
            ver.alpha = 0f
        }

        fun start() {
            loop = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 3200
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                addUpdateListener { bg.t = it.animatedValue as Float; bg.invalidate() }
                start()
            }
            logo.scaleX = 0.55f
            logo.scaleY = 0.55f
            logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(450).setInterpolator(OvershootInterpolator(1.6f)).start()
            title.translationY = 22 * d
            title.animate().alpha(1f).translationY(0f).setStartDelay(150).setDuration(380).setInterpolator(DecelerateInterpolator()).start()
            tag.translationY = 14 * d
            tag.animate().alpha(1f).translationY(0f).setStartDelay(260).setDuration(380).setInterpolator(DecelerateInterpolator()).start()
            ver.animate().alpha(1f).setStartDelay(300).setDuration(350).start()
            postDelayed({ finish() }, 850)
        }

        private fun finish() {
            if (finished) return
            finished = true
            animate().alpha(0f).setDuration(280).setListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    loop?.cancel()
                    (parent as? ViewGroup)?.removeView(this@IntroView)
                }
            }).start()
        }

        override fun onDetachedFromWindow() {
            loop?.cancel()
            super.onDetachedFromWindow()
        }
    }
}
