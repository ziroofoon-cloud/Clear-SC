package app.clearoverlay;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * WebDAV storage: Nextcloud / ownCloud, Box, pCloud, Koofr, Yandex Disk, NAS boxes, many mail providers' cloud drives.
 * Uploads are first written to a temporary file (the size must be known before the request) and sent when the stream is closed.
 */
public final class WebDavFs implements FmFs {
    private final String scheme;
    private final String hostPart;   // host[:port]
    private final String basePath;   // encoded, no trailing slash ("" = top)
    private final String baseDecoded;
    private final String auth;       // "Basic ..." or null
    private final boolean insecure;
    private final File tmpDir;

    public WebDavFs(String url, String user, String pass, boolean insecure, File tmpDir) throws IOException {
        String u = url.trim();
        if (!u.contains("://")) u = "https://" + u;
        URL x = new URL(u);
        this.scheme = x.getProtocol().toLowerCase(Locale.US);
        this.hostPart = x.getPort() > 0 ? x.getHost() + ":" + x.getPort() : x.getHost();
        String p = x.getPath();
        while (p.endsWith("/")) p = p.substring(0, p.length() - 1);
        this.basePath = p;
        this.baseDecoded = decode(p);
        this.auth = (user == null || user.isEmpty()) ? null
                : "Basic " + Base64.getEncoder().encodeToString((user + ":" + (pass == null ? "" : pass)).getBytes(StandardCharsets.UTF_8));
        this.insecure = insecure;
        this.tmpDir = tmpDir;
    }

    // ---- paths -----------------------------------------------------------------------------------

    @Override public String root() { return "/"; }

    @Override public String parent(String path) {
        String p = norm(path);
        if (p.equals("/")) return null;
        int i = p.lastIndexOf('/');
        return i <= 0 ? "/" : p.substring(0, i);
    }

    @Override public String join(String dir, String name) { return dir.endsWith("/") ? dir + name : dir + "/" + name; }

    private static String norm(String p) {
        if (p == null || p.isEmpty()) return "/";
        String r = p.startsWith("/") ? p : "/" + p;
        while (r.length() > 1 && r.endsWith("/")) r = r.substring(0, r.length() - 1);
        return r;
    }

    static String encode(String path) {
        StringBuilder sb = new StringBuilder();
        for (byte b : path.getBytes(StandardCharsets.UTF_8)) {
            int c = b & 0xFF;
            if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '-' || c == '.' || c == '_' || c == '~' || c == '/') {
                sb.append((char) c);
            } else {
                sb.append('%').append(Character.toUpperCase(Character.forDigit(c >> 4, 16))).append(Character.toUpperCase(Character.forDigit(c & 15, 16)));
            }
        }
        return sb.toString();
    }

    static String decode(String s) {
        if (s.indexOf('%') < 0) return s;
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] in = s.getBytes(StandardCharsets.UTF_8);
        for (int i = 0; i < in.length; i++) {
            if (in[i] == '%' && i + 2 < in.length) {
                int h = Character.digit((char) in[i + 1], 16), l = Character.digit((char) in[i + 2], 16);
                if (h >= 0 && l >= 0) { o.write(h * 16 + l); i += 2; continue; }
            }
            o.write(in[i]);
        }
        return new String(o.toByteArray(), StandardCharsets.UTF_8);
    }

    private URL urlOf(String path) throws IOException {
        String p = norm(path);
        return new URL(scheme + "://" + hostPart + basePath + encode(p.equals("/") ? "/" : p));
    }

    private Map<String, String> hdr() {
        Map<String, String> h = new HashMap<>();
        if (auth != null) h.put("Authorization", auth);
        return h;
    }

    private IOException fail(String what, HttpRaw.Resp r) {
        return new IOException(what + ": " + r.code + " " + r.message + (r.code == 401 ? " (check the user name / password)" : ""));
    }

    // ---- reading ---------------------------------------------------------------------------------

    private static final String PROPFIND_BODY =
            "<?xml version=\"1.0\" encoding=\"utf-8\"?><d:propfind xmlns:d=\"DAV:\"><d:prop><d:resourcetype/><d:getcontentlength/>"
                    + "<d:getlastmodified/></d:prop></d:propfind>";

    private HttpRaw.Resp propfind(String path, int depth) throws IOException {
        Map<String, String> h = hdr();
        h.put("Depth", Integer.toString(depth));
        h.put("Content-Type", "application/xml; charset=utf-8");
        byte[] b = PROPFIND_BODY.getBytes(StandardCharsets.UTF_8);
        return HttpRaw.request("PROPFIND", urlOf(path), h, new ByteArrayInputStream(b), b.length, insecure);
    }

    @Override public List<FmItem> list(String dir) throws IOException {
        String d = norm(dir);
        try (HttpRaw.Resp r = propfind(d, 1)) {
            if (r.code != 207 && r.code != 200) throw fail("cannot list " + d, r);
            Document doc;
            try {
                DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
                f.setNamespaceAware(true);
                try { f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true); } catch (Exception ignored) { }
                DocumentBuilder b = f.newDocumentBuilder();
                doc = b.parse(new ByteArrayInputStream(r.bytes()));
            } catch (IOException e) {
                throw e;
            } catch (Exception e) {
                throw new IOException("the server's answer could not be read: " + e.getMessage(), e);
            }
            String self = trimSlash(baseDecoded + (d.equals("/") ? "" : d));
            List<FmItem> out = new ArrayList<>();
            NodeList rs = doc.getElementsByTagNameNS("*", "response");
            for (int i = 0; i < rs.getLength(); i++) {
                Element e = (Element) rs.item(i);
                String href = text(first(e, "href"));
                if (href == null) continue;
                String hp = hrefPath(href);
                String dec = trimSlash(decode(hp));
                if (dec.equals(self) || dec.isEmpty() && self.isEmpty()) continue;
                String name = dec.substring(dec.lastIndexOf('/') + 1);
                if (name.isEmpty()) continue;
                boolean isDir = false;
                long size = -1, mod = 0;
                NodeList ps = e.getElementsByTagNameNS("*", "prop");
                for (int k = 0; k < ps.getLength(); k++) {
                    Element p = (Element) ps.item(k);
                    Element rt = first(p, "resourcetype");
                    if (rt != null && first(rt, "collection") != null) isDir = true;
                    String len = text(first(p, "getcontentlength"));
                    if (len != null) try { size = Long.parseLong(len.trim()); } catch (NumberFormatException ignored) { }
                    String lm = text(first(p, "getlastmodified"));
                    if (lm != null) mod = parseDate(lm.trim());
                }
                out.add(new FmItem(name, isDir, isDir ? -1 : size, mod));
            }
            return out;
        }
    }

    private static String hrefPath(String href) {
        String h = href.trim();
        int s = h.indexOf("://");
        if (s >= 0) {
            int slash = h.indexOf('/', s + 3);
            h = slash < 0 ? "/" : h.substring(slash);
        }
        int q = h.indexOf('?');
        return q >= 0 ? h.substring(0, q) : h;
    }

    private static String trimSlash(String s) {
        String r = s;
        while (r.endsWith("/")) r = r.substring(0, r.length() - 1);
        return r;
    }

    private static Element first(Element parent, String local) {
        NodeList n = parent.getElementsByTagNameNS("*", local);
        return n.getLength() > 0 ? (Element) n.item(0) : null;
    }

    private static String text(Element e) {
        if (e == null) return null;
        StringBuilder sb = new StringBuilder();
        for (Node c = e.getFirstChild(); c != null; c = c.getNextSibling()) {
            if (c.getNodeType() == Node.TEXT_NODE || c.getNodeType() == Node.CDATA_SECTION_NODE) sb.append(c.getNodeValue());
        }
        return sb.toString();
    }

    private static long parseDate(String s) {
        String[] fmts = {"EEE, dd MMM yyyy HH:mm:ss zzz", "EEEE, dd-MMM-yy HH:mm:ss zzz", "EEE MMM d HH:mm:ss yyyy", "yyyy-MM-dd'T'HH:mm:ss'Z'"};
        for (String f : fmts) {
            try {
                SimpleDateFormat d = new SimpleDateFormat(f, Locale.US);
                d.setTimeZone(TimeZone.getTimeZone("GMT"));
                return d.parse(s).getTime();
            } catch (Exception ignored) { }
        }
        return 0;
    }

    @Override public InputStream open(String path) throws IOException {
        HttpRaw.Resp r = HttpRaw.request("GET", urlOf(path), hdr(), null, 0, insecure);
        if (r.code != 200) {
            IOException e = fail("cannot read " + path, r);
            r.close();
            throw e;
        }
        final HttpRaw.Resp resp = r;
        return new InputStream() {
            @Override public int read() throws IOException { return resp.body.read(); }
            @Override public int read(byte[] b, int off, int len) throws IOException { return resp.body.read(b, off, len); }
            @Override public void close() { resp.close(); }
        };
    }

    @Override public boolean exists(String path) throws IOException {
        try (HttpRaw.Resp r = propfind(path, 0)) {
            if (r.code == 404) return false;
            if (r.code == 207 || r.code == 200) return true;
            throw fail("cannot look at " + path, r);
        }
    }

    // ---- writing ---------------------------------------------------------------------------------

    private final class Upload extends OutputStream implements FmAbortable {
        private final String path;
        private final File tmp;
        private OutputStream out;
        private boolean finished;

        Upload(String path) throws IOException {
            this.path = path;
            this.tmp = File.createTempFile("dav", ".up", tmpDir);
            this.out = new FileOutputStream(tmp);
        }

        @Override public void write(int b) throws IOException { out.write(b); }
        @Override public void write(byte[] b, int off, int len) throws IOException { out.write(b, off, len); }

        @Override public void close() throws IOException {
            if (finished) return;
            finished = true;
            try {
                out.close();
                long n = tmp.length();
                try (InputStream in = new FileInputStream(tmp); HttpRaw.Resp r = HttpRaw.request("PUT", urlOf(path), hdr(), in, n, insecure)) {
                    if (r.code != 200 && r.code != 201 && r.code != 204) throw fail("cannot write " + path, r);
                }
            } finally {
                //noinspection ResultOfMethodCallIgnored
                tmp.delete();
            }
        }

        @Override public void abort() {
            if (finished) return;
            finished = true;
            try { out.close(); } catch (IOException ignored) { }
            //noinspection ResultOfMethodCallIgnored
            tmp.delete();
        }
    }

    @Override public OutputStream create(String path, long size) throws IOException { return new Upload(path); }

    @Override public void mkdir(String path) throws IOException {
        try (HttpRaw.Resp r = HttpRaw.request("MKCOL", urlOf(path), hdr(), null, 0, insecure)) {
            if (r.code == 201 || r.code == 200) return;
            if (r.code == 405) return; // already there
            throw fail("cannot create " + path, r);
        }
    }

    @Override public void delete(String path) throws IOException {
        try (HttpRaw.Resp r = HttpRaw.request("DELETE", urlOf(path), hdr(), null, 0, insecure)) {
            if (r.code == 200 || r.code == 202 || r.code == 204 || r.code == 404) return;
            if (r.code == 207) {
                String t = r.text();
                if (t.contains(" 4") || t.contains(" 5")) throw new IOException("the server could not delete everything in " + path);
                return;
            }
            throw fail("cannot delete " + path, r);
        }
    }

    @Override public void rename(String path, String newName) throws IOException {
        String p = parent(path);
        String to = join(p == null ? "/" : p, newName);
        if (!moveWithin(path, to)) throw new IOException("cannot rename " + path);
    }

    @Override public boolean moveWithin(String from, String to) throws IOException {
        Map<String, String> h = hdr();
        h.put("Destination", scheme + "://" + hostPart + basePath + encode(norm(to)));
        h.put("Overwrite", "F");
        try (HttpRaw.Resp r = HttpRaw.request("MOVE", urlOf(from), h, null, 0, insecure)) {
            if (r.code == 201 || r.code == 204 || r.code == 200) return true;
            if (r.code == 412) throw new IOException("already exists: " + to);
            return false;
        }
    }

    @Override public File localFile(String path) { return null; }

    @Override public long freeSpace() { return -1; }

    @Override public void close() { }
}
