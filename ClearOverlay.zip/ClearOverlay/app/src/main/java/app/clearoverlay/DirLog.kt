package app.clearoverlay

import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.provider.Settings
import java.io.File
import java.util.Locale

/**
 * A short diary of everything that decides the screen direction: every direction request of the player, every turn the system reports,
 * every screen of the app that comes back, with the direction that was asked for, the real rotation of the display and the switch
 * "auto-rotate" of the phone. Nothing is changed by it. When the direction goes wrong, "Direction report" (Settings, and the player's
 * direction picker) copies it, and the lines show who asked for what and when. The last [MAX] lines are also kept in a file
 * (`dirlog.txt` in the app's files) so the diary can still be read after the app was closed.
 */
object DirLog {
    private const val MAX = 240
    private val lines = ArrayList<String>()
    private var loaded = false
    private val io = java.util.concurrent.Executors.newSingleThreadExecutor { r -> Thread(r, "dirlog").apply { isDaemon = true } }
    private val fmt = java.text.SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    private fun name(o: Int): String = when (o) {
        ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED -> "UNSPEC"
        ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE -> "LAND"
        ActivityInfo.SCREEN_ORIENTATION_PORTRAIT -> "PORT"
        ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE -> "SENSOR_LAND"
        ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT -> "SENSOR_PORT"
        ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE -> "REV_LAND"
        ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT -> "REV_PORT"
        ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR -> "FULL_SENSOR"
        ActivityInfo.SCREEN_ORIENTATION_LOCKED -> "LOCKED"
        ActivityInfo.SCREEN_ORIENTATION_USER -> "USER"
        else -> "o$o"
    }

    /** Writes one line: [what] happened on [a]; [extra] is whatever the caller knows (the player's own state). */
    @Synchronized
    fun add(a: Activity, what: String, extra: String = "") {
        runCatching {
            val req = runCatching { name(a.requestedOrientation) }.getOrDefault("?")
            val rot = runCatching { a.display?.rotation ?: -1 }.getOrDefault(-1)
            val b = runCatching { a.windowManager.maximumWindowMetrics.bounds }.getOrNull()
            val auto = runCatching { Settings.System.getInt(a.contentResolver, Settings.System.ACCELEROMETER_ROTATION, -1) }.getOrDefault(-1)
            val line = fmt.format(java.util.Date()) + " " + a.javaClass.simpleName.removeSuffix("Activity") + " " + what +
                " | req=" + req + " disp=" + rot + (if (b != null) " win=" + b.width() + "x" + b.height() else "") + " autoRot=" + auto +
                (if (extra.isNotEmpty()) " | $extra" else "")
            val f = File(a.filesDir, "dirlog.txt")
            if (!loaded) { // the first line of this run: keep what the file holds from the earlier run (it used to be overwritten here)
                loaded = true
                runCatching { if (f.exists()) { lines.addAll(f.readLines()); lines.add("---- the app was started again ----") } }
            }
            lines.add(line)
            while (lines.size > MAX) lines.removeAt(0)
            val text = lines.joinToString("\n")
            io.execute { runCatching { f.writeText(text) } } // not on the main thread: this is called on every turn and every resume
        }
    }

    private fun userRot(a: Activity): Int = runCatching { Settings.System.getInt(a.contentResolver, Settings.System.USER_ROTATION, -1) }.getOrDefault(-1)

    /**
     * Writes a line for every turn of the display, also the flip between the two landscape ends (it sends no configuration change, so the lines above
     * never showed it), with the raw angle of the phone's sensor at that moment (0 = upright, 90 = turned right, 180 = upside down, 270 = turned left,
     * -1 = flat or unknown). Then the report shows whether the system turned the screen with the sensor or against it. Close it when the screen goes away.
     */
    fun watch(a: Activity): java.io.Closeable {
        val dm = runCatching { a.getSystemService(android.hardware.display.DisplayManager::class.java) }.getOrNull()
        var last = runCatching { a.display?.rotation ?: -1 }.getOrDefault(-1)
        var deg = -1
        val sensor = object : android.view.OrientationEventListener(a) {
            override fun onOrientationChanged(orientation: Int) {
                deg = orientation
            }
        }
        val listener = object : android.hardware.display.DisplayManager.DisplayListener {
            override fun onDisplayAdded(displayId: Int) {}
            override fun onDisplayRemoved(displayId: Int) {}
            override fun onDisplayChanged(displayId: Int) {
                val r = runCatching { a.display?.rotation ?: -1 }.getOrDefault(-1)
                if (r != last) {
                    val was = last
                    last = r
                    add(a, "display turned $was -> $r", "sensor=" + deg + " user_rotation=" + userRot(a))
                }
            }
        }
        runCatching { sensor.enable() }
        runCatching { dm?.registerDisplayListener(listener, android.os.Handler(android.os.Looper.getMainLooper())) }
        return java.io.Closeable {
            runCatching { sensor.disable() }
            runCatching { dm?.unregisterDisplayListener(listener) }
        }
    }

    /** The whole diary as text, with the phone and the app version on top (for copying). */
    @Synchronized
    fun report(ctx: Context): String {
        val ver = runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "?"
        val head = "device=" + android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL + " android=" + android.os.Build.VERSION.RELEASE + " app=" + ver +
            "\n(disp: 0 = portrait, 1 = landscape, 2 = upside down, 3 = landscape the other way; autoRot: 1 = the phone's auto-rotate is on, 0 = off;\n \"display turned a -> b\" = the system turned the screen, sensor = the phone's angle then, user_rotation = the rotation the phone keeps while auto-rotate is off)"
        val body = if (lines.isNotEmpty()) lines.joinToString("\n") else runCatching { File(ctx.filesDir, "dirlog.txt").readText() }.getOrDefault("")
        return head + "\n" + body
    }

    /** Copies [report] to the clipboard. */
    fun copy(ctx: Context) {
        runCatching {
            val cm = ctx.getSystemService(android.content.ClipboardManager::class.java)
            cm?.setPrimaryClip(android.content.ClipData.newPlainText("direction report", report(ctx)))
            android.widget.Toast.makeText(ctx, R.string.pt_copied, android.widget.Toast.LENGTH_SHORT).show()
        }
    }
}
