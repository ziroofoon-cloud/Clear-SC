package app.clearoverlay;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/** Zip and unzip for files on the phone (with progress, cancel and protection against entries that try to leave the target folder). */
public final class ZipTools {
    private ZipTools() { }

    /** Packs files and folders into [out]; every item is stored under its own name (folders with their content). */
    public static void zip(List<File> sources, File out, FmCopy.Listener l) throws IOException {
        long[] done = {0};
        boolean ok = false;
        try (ZipOutputStream z = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(out), 64 * 1024), StandardCharsets.UTF_8)) {
            byte[] buf = new byte[64 * 1024];
            for (File f : sources) add(z, f, f.getName(), buf, done, l, out);
            ok = true;
        } finally {
            if (!ok) //noinspection ResultOfMethodCallIgnored
                out.delete(); // no half archive left behind
        }
    }

    private static void add(ZipOutputStream z, File f, String name, byte[] buf, long[] done, FmCopy.Listener l, File outFile) throws IOException {
        if (l != null && l.cancelled()) throw new FmCopy.Cancelled();
        if (f.getCanonicalFile().equals(outFile.getCanonicalFile())) return; // never pack the archive into itself
        if (f.isDirectory()) {
            if (java.nio.file.Files.isSymbolicLink(f.toPath())) return; // a linked folder can lead back to a folder above it
            z.putNextEntry(new ZipEntry(name + "/"));
            z.closeEntry();
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) add(z, k, name + "/" + k.getName(), buf, done, l, outFile);
            return;
        }
        ZipEntry e = new ZipEntry(name);
        e.setTime(f.lastModified());
        z.putNextEntry(e);
        try (InputStream in = new FileInputStream(f)) {
            int n;
            while ((n = in.read(buf)) > 0) {
                if (l != null && l.cancelled()) throw new FmCopy.Cancelled();
                z.write(buf, 0, n);
                done[0] += n;
                if (l != null) l.progress(done[0], f.getName());
            }
        }
        z.closeEntry();
    }

    /** Unpacks [zip] into [dest] (created if needed). Returns the number of files written. */
    public static int unzip(File zip, File dest, FmCopy.Listener l) throws IOException {
        ZipFile zf;
        try {
            zf = new ZipFile(zip, StandardCharsets.UTF_8);
        } catch (IllegalArgumentException | java.util.zip.ZipException e) {
            zf = new ZipFile(zip, StandardCharsets.ISO_8859_1); // names that are not UTF-8
        }
        if (!dest.isDirectory() && !dest.mkdirs()) throw new IOException("cannot create " + dest.getPath());
        String base = dest.getCanonicalPath() + File.separator;
        int files = 0;
        long done = 0;
        byte[] buf = new byte[64 * 1024];
        try {
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                if (l != null && l.cancelled()) throw new FmCopy.Cancelled();
                ZipEntry e = en.nextElement();
                File t = new File(dest, e.getName());
                String canon = t.getCanonicalPath();
                // "../x" or an absolute name would write outside the target folder: skipped
                if (!(canon + (e.isDirectory() ? File.separator : "")).startsWith(base)) continue;
                if (e.isDirectory()) {
                    //noinspection ResultOfMethodCallIgnored
                    t.mkdirs();
                    continue;
                }
                File p = t.getParentFile();
                if (p != null && !p.isDirectory() && !p.mkdirs()) throw new IOException("cannot create " + p.getPath());
                boolean ok = false;
                try (InputStream in = new BufferedInputStream(zf.getInputStream(e)); OutputStream o = new FileOutputStream(t)) {
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        if (l != null && l.cancelled()) throw new FmCopy.Cancelled();
                        o.write(buf, 0, n);
                        done += n;
                        if (l != null) l.progress(done, t.getName());
                    }
                    ok = true;
                } finally {
                    if (!ok) //noinspection ResultOfMethodCallIgnored
                        t.delete();
                }
                if (e.getTime() > 0) //noinspection ResultOfMethodCallIgnored
                    t.setLastModified(e.getTime());
                files++;
            }
        } finally {
            zf.close();
        }
        return files;
    }

    // ---- other archives: 7z, rar (RAR 4), tar, tar.gz / tgz, tar.xz, tar.bz2, single .gz / .xz / .bz2 ------------------

    /** True when [extractAny] knows the file by its name. */
    public static boolean canExtract(String name) {
        String n = name.toLowerCase(java.util.Locale.US);
        return n.endsWith(".zip") || n.endsWith(".cbz") || n.endsWith(".7z") || n.endsWith(".cb7") || n.endsWith(".rar") || n.endsWith(".cbr")
            || n.endsWith(".tar") || n.endsWith(".tgz") || n.endsWith(".tar.gz") || n.endsWith(".txz") || n.endsWith(".tar.xz")
            || n.endsWith(".tar.bz2") || n.endsWith(".tbz2") || n.endsWith(".gz") || n.endsWith(".xz") || n.endsWith(".bz2");
    }

    /** Unpacks any archive that [canExtract] accepts into [dest]. Returns the number of files written. */
    public static int extractAny(File src, File dest, FmCopy.Listener l) throws IOException {
        String n = src.getName().toLowerCase(java.util.Locale.US);
        if (n.endsWith(".zip") || n.endsWith(".cbz")) return unzip(src, dest, l);
        if (!dest.isDirectory() && !dest.mkdirs()) throw new IOException("cannot create " + dest.getPath());
        if (n.endsWith(".7z") || n.endsWith(".cb7")) return extract7z(src, dest, l);
        if (n.endsWith(".rar") || n.endsWith(".cbr")) return extractRar(src, dest, l);
        InputStream raw = new BufferedInputStream(new FileInputStream(src), 1 << 16);
        try {
            boolean tarGz = n.endsWith(".tar.gz") || n.endsWith(".tgz");
            boolean tarXz = n.endsWith(".tar.xz") || n.endsWith(".txz");
            boolean tarBz = n.endsWith(".tar.bz2") || n.endsWith(".tbz2");
            InputStream dec = raw;
            if (tarGz || n.endsWith(".gz")) dec = new org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream(raw);
            else if (tarXz || n.endsWith(".xz")) dec = new org.apache.commons.compress.compressors.xz.XZCompressorInputStream(raw);
            else if (tarBz || n.endsWith(".bz2")) dec = new org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream(raw);
            if (n.endsWith(".tar") || tarGz || tarXz || tarBz) return extractTar(dec, dest, l);
            // a single compressed file: written under its name without the ending
            String base = src.getName();
            int dot = base.lastIndexOf('.');
            File t = new File(dest, dot > 0 ? base.substring(0, dot) : base + ".out");
            copyTo(dec, t, -1, l, new long[1]);
            return 1;
        } finally {
            raw.close();
        }
    }

    private static int extractTar(InputStream in, File dest, FmCopy.Listener l) throws IOException {
        String base = dest.getCanonicalPath() + File.separator;
        long[] done = new long[1];
        int files = 0;
        try (org.apache.commons.compress.archivers.tar.TarArchiveInputStream tin = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(in)) {
            org.apache.commons.compress.archivers.tar.TarArchiveEntry e;
            while ((e = tin.getNextTarEntry()) != null) {
                if (l != null && l.cancelled()) throw new FmCopy.Cancelled();
                File t = new File(dest, e.getName());
                String canon = t.getCanonicalPath();
                if (!(canon + (e.isDirectory() ? File.separator : "")).startsWith(base)) continue;
                if (e.isDirectory()) { //noinspection ResultOfMethodCallIgnored
                    t.mkdirs(); continue; }
                if (!e.isFile()) continue; // links and devices are not unpacked
                copyTo(tin, t, e.getModTime() == null ? -1 : e.getModTime().getTime(), l, done);
                files++;
            }
        }
        return files;
    }

    private static int extract7z(File src, File dest, FmCopy.Listener l) throws IOException {
        String base = dest.getCanonicalPath() + File.separator;
        long[] done = new long[1];
        int files = 0;
        try (org.apache.commons.compress.archivers.sevenz.SevenZFile sz = new org.apache.commons.compress.archivers.sevenz.SevenZFile(src)) {
            org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry e;
            while ((e = sz.getNextEntry()) != null) {
                if (l != null && l.cancelled()) throw new FmCopy.Cancelled();
                File t = new File(dest, e.getName());
                String canon = t.getCanonicalPath();
                if (!(canon + (e.isDirectory() ? File.separator : "")).startsWith(base)) continue;
                if (e.isDirectory()) { //noinspection ResultOfMethodCallIgnored
                    t.mkdirs(); continue; }
                File p = t.getParentFile();
                if (p != null && !p.isDirectory() && !p.mkdirs()) throw new IOException("cannot create " + p.getPath());
                boolean ok = false;
                byte[] buf = new byte[64 * 1024];
                try (OutputStream o = new FileOutputStream(t)) {
                    int n;
                    while ((n = sz.read(buf)) > 0) {
                        if (l != null && l.cancelled()) throw new FmCopy.Cancelled();
                        o.write(buf, 0, n);
                        done[0] += n;
                        if (l != null) l.progress(done[0], t.getName());
                    }
                    ok = true;
                } finally {
                    if (!ok) //noinspection ResultOfMethodCallIgnored
                        t.delete();
                }
                files++;
            }
        }
        return files;
    }

    private static int extractRar(File src, File dest, FmCopy.Listener l) throws IOException {
        String base = dest.getCanonicalPath() + File.separator;
        long[] done = new long[1];
        int files = 0;
        com.github.junrar.Archive a = null;
        try {
            a = new com.github.junrar.Archive(src);
            com.github.junrar.rarfile.FileHeader fh;
            while ((fh = a.nextFileHeader()) != null) {
                if (l != null && l.cancelled()) throw new FmCopy.Cancelled();
                String name = fh.getFileName().replace('\\', '/');
                File t = new File(dest, name);
                String canon = t.getCanonicalPath();
                if (!(canon + (fh.isDirectory() ? File.separator : "")).startsWith(base)) continue;
                if (fh.isDirectory()) { //noinspection ResultOfMethodCallIgnored
                    t.mkdirs(); continue; }
                File p = t.getParentFile();
                if (p != null && !p.isDirectory() && !p.mkdirs()) throw new IOException("cannot create " + p.getPath());
                boolean ok = false;
                try (OutputStream o = new FileOutputStream(t)) {
                    a.extractFile(fh, o);
                    ok = true;
                } finally {
                    if (!ok) //noinspection ResultOfMethodCallIgnored
                        t.delete();
                }
                done[0] += t.length();
                if (l != null) l.progress(done[0], t.getName());
                files++;
            }
        } catch (com.github.junrar.exception.RarException e) {
            throw new IOException("RAR: " + (e.getMessage() == null ? "this kind of RAR file is not supported (RAR 5)" : e.getMessage()));
        } finally {
            if (a != null) a.close();
        }
        return files;
    }

    private static void copyTo(InputStream in, File t, long modified, FmCopy.Listener l, long[] done) throws IOException {
        File p = t.getParentFile();
        if (p != null && !p.isDirectory() && !p.mkdirs()) throw new IOException("cannot create " + p.getPath());
        boolean ok = false;
        byte[] buf = new byte[64 * 1024];
        try (OutputStream o = new FileOutputStream(t)) {
            int n;
            while ((n = in.read(buf)) > 0) {
                if (l != null && l.cancelled()) throw new FmCopy.Cancelled();
                o.write(buf, 0, n);
                done[0] += n;
                if (l != null) l.progress(done[0], t.getName());
            }
            ok = true;
        } finally {
            if (!ok) //noinspection ResultOfMethodCallIgnored
                t.delete();
        }
        if (modified > 0) //noinspection ResultOfMethodCallIgnored
            t.setLastModified(modified);
    }
}
