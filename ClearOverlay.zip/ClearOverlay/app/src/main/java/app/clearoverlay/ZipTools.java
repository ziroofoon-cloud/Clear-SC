package app.clearoverlay;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/** Zip and unzip for files on the phone (with progress, cancel and protection against entries that try to leave the target folder). */
public final class ZipTools {
    private ZipTools() { }

    /** Packs files and folders into [out]; every item is stored under its own name (folders with their content). */
    public static void zip(List<File> sources, File out, FmCopy.Listener l) throws IOException {
        long[] done = {0};
        boolean ok = false;
        try (ZipOutputStream z = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(out), 64 * 1024), StandardCharsets.UTF_8)) {
            byte[] buf = new byte[64 * 1024];
            for (File f : sources) add(z, f, f.getName(), buf, done, l, out);
            ok = true;
        } finally {
            if (!ok) //noinspection ResultOfMethodCallIgnored
                out.delete(); // no half archive left behind
        }
    }

    private static void add(ZipOutputStream z, File f, String name, byte[] buf, long[] done, FmCopy.Listener l, File outFile) throws IOException {
        if (l != null && l.cancelled()) throw new FmCopy.Cancelled();
        if (f.getCanonicalFile().equals(outFile.getCanonicalFile())) return; // never pack the archive into itself
        if (f.isDirectory()) {
            z.putNextEntry(new ZipEntry(name + "/"));
            z.closeEntry();
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) add(z, k, name + "/" + k.getName(), buf, done, l, outFile);
            return;
        }
        ZipEntry e = new ZipEntry(name);
        e.setTime(f.lastModified());
        z.putNextEntry(e);
        try (InputStream in = new FileInputStream(f)) {
            int n;
            while ((n = in.read(buf)) > 0) {
                if (l != null && l.cancelled()) throw new FmCopy.Cancelled();
                z.write(buf, 0, n);
                done[0] += n;
                if (l != null) l.progress(done[0], f.getName());
            }
        }
        z.closeEntry();
    }

    /** Unpacks [zip] into [dest] (created if needed). Returns the number of files written. */
    public static int unzip(File zip, File dest, FmCopy.Listener l) throws IOException {
        ZipFile zf;
        try {
            zf = new ZipFile(zip, StandardCharsets.UTF_8);
        } catch (IllegalArgumentException | java.util.zip.ZipException e) {
            zf = new ZipFile(zip, StandardCharsets.ISO_8859_1); // names that are not UTF-8
        }
        if (!dest.isDirectory() && !dest.mkdirs()) throw new IOException("cannot create " + dest.getPath());
        String base = dest.getCanonicalPath() + File.separator;
        int files = 0;
        long done = 0;
        byte[] buf = new byte[64 * 1024];
        try {
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                if (l != null && l.cancelled()) throw new FmCopy.Cancelled();
                ZipEntry e = en.nextElement();
                File t = new File(dest, e.getName());
                String canon = t.getCanonicalPath();
                // "../x" or an absolute name would write outside the target folder: skipped
                if (!(canon + (e.isDirectory() ? File.separator : "")).startsWith(base)) continue;
                if (e.isDirectory()) {
                    //noinspection ResultOfMethodCallIgnored
                    t.mkdirs();
                    continue;
                }
                File p = t.getParentFile();
                if (p != null && !p.isDirectory() && !p.mkdirs()) throw new IOException("cannot create " + p.getPath());
                boolean ok = false;
                try (InputStream in = new BufferedInputStream(zf.getInputStream(e)); OutputStream o = new FileOutputStream(t)) {
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        if (l != null && l.cancelled()) throw new FmCopy.Cancelled();
                        o.write(buf, 0, n);
                        done += n;
                        if (l != null) l.progress(done, t.getName());
                    }
                    ok = true;
                } finally {
                    if (!ok) //noinspection ResultOfMethodCallIgnored
                        t.delete();
                }
                if (e.getTime() > 0) //noinspection ResultOfMethodCallIgnored
                    t.setLastModified(e.getTime());
                files++;
            }
        } finally {
            zf.close();
        }
        return files;
    }
}
