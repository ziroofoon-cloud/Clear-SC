package app.clearoverlay

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Watch / read history: the videos and manga that were left half way, newest first, so they can be continued from
 * the library ("History"). The playing position itself is kept by the player / reader; this list only remembers
 * what to show and how to open it again.
 *
 * kind 0 = video (id = its uri), kind 1 = manga (id = the reader's key; src = "file" | "tree" | "bucket", ref = its uri / id).
 */
object History {
    class Entry(
        val kind: Int,
        val id: String,
        val title: String,
        val pos: Long,
        val total: Long,
        val time: Long,
        val src: String = "",
        val ref: String = ""
    )

    private const val MAX = 60
    private const val PREF = "crsc_hist"
    private var cache: MutableList<Entry>? = null

    @Synchronized
    private fun all(ctx: Context): MutableList<Entry> {
        cache?.let { return it }
        val l = ArrayList<Entry>()
        runCatching {
            val s = ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("list", null)
            if (s != null) {
                val a = JSONArray(s)
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    l.add(Entry(o.getInt("k"), o.getString("i"), o.optString("t"), o.optLong("p"), o.optLong("n"), o.optLong("d"), o.optString("s"), o.optString("r")))
                }
            }
        }
        cache = l
        return l
    }

    private fun save(ctx: Context) {
        val a = JSONArray()
        for (e in cache ?: return) {
            a.put(JSONObject().put("k", e.kind).put("i", e.id).put("t", e.title).put("p", e.pos).put("n", e.total).put("d", e.time).put("s", e.src).put("r", e.ref))
        }
        ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("list", a.toString()).apply()
    }

    /** Entries of one kind, newest first. */
    @Synchronized
    fun list(ctx: Context, kind: Int): List<Entry> = all(ctx).filter { it.kind == kind }.sortedByDescending { it.time }

    @Synchronized
    fun put(ctx: Context, e: Entry) {
        val l = all(ctx)
        l.removeAll { it.kind == e.kind && it.id == e.id }
        l.add(e)
        while (l.size > MAX) {
            val old = l.minByOrNull { it.time } ?: break
            l.remove(old)
        }
        save(ctx)
    }

    @Synchronized
    fun remove(ctx: Context, kind: Int, id: String) {
        if (all(ctx).removeAll { it.kind == kind && it.id == id }) save(ctx)
    }

    @Synchronized
    fun clear(ctx: Context, kind: Int) {
        all(ctx).removeAll { it.kind == kind }
        save(ctx)
    }
}
