package app.clearoverlay

import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.os.Build
import java.io.File
import java.util.Locale

/**
 * The engine of "Free up space": one walk over the phone's storage that sorts what it finds into groups the person can
 * review, and the deleting. Nothing here deletes by itself; [CleanActivity] shows every group first.
 *
 *  - JUNK: temporary and unfinished-download files, thumbnail caches, empty (0 byte) files
 *  - EMPTY: folders with nothing but other folders inside
 *  - APK: installers (.apk); the ones whose app is already installed in the same or a newer version are marked as safe
 *  - OLD: big files (50 MB and more) not changed for 6 months: only a hint, the person decides, nothing is pre-ticked
 *  - DUPES: identical files (same size, same start / end, same SHA-256); the copy to keep is chosen by [keeperFirst]
 *
 * The top-level "Android" folder (other apps' data) is never walked: deleting inside it could break an app.
 */
object CleanScan {
    const val JUNK = 0
    const val EMPTY = 1
    const val APK = 2
    const val DUPES = 3
    const val OLD = 4
    const val COUNT = 5

    private const val DAY = 24L * 3600 * 1000
    private const val OLD_SIZE = 50L * 1024 * 1024
    private const val OLD_AGE = 180L * DAY
    private const val OLD_MAX = 300
    private const val DUPE_MIN = 4096L

    /** One thing that can be deleted. [dir] = an empty tree of folders (only folders are removed). [safe] = tick it by default. */
    class Entry(val file: File, val size: Long, val mtime: Long, val dir: Boolean = false, val safe: Boolean = true, val note: String = "")

    class Result(val groups: Array<List<Entry>>) {
        fun size(cat: Int): Long = groups[cat].sumOf { it.size }
        fun safeSize(cat: Int): Long = groups[cat].filter { it.safe }.sumOf { it.size }
        /** What the one-tap "Clean" removes: junk, empty folders and installed apps' installers. Never duplicates or old files. */
        fun oneTapEntries(): List<Pair<Int, Entry>> {
            val out = ArrayList<Pair<Int, Entry>>()
            for (c in intArrayOf(JUNK, EMPTY, APK)) for (e in groups[c]) if (e.safe) out.add(c to e)
            return out
        }
    }

    private val JUNK_EXT = setOf("tmp", "temp", "log", "chk", "dmp", "crdownload", "part", "partial", "download", "opdownload", "!ut")
    private val JUNK_NAMES = setOf("thumbs.db", ".ds_store", "desktop.ini")

    private fun ext(n: String): String = n.substringAfterLast('.', "").lowercase(Locale.ROOT)

    private fun isJunkName(n: String): Boolean {
        val l = n.lowercase(Locale.ROOT)
        if (l in JUNK_NAMES) return true
        if (l.startsWith(".thumbdata") || l.startsWith(".thumbcache")) return true
        return ext(l) in JUNK_EXT
    }

    /** Names that look like a second copy: "photo (1).jpg", "photo - Copy.jpg", "photo_copy.jpg". Those are the ones to delete first. */
    private val COPY_LIKE = Regex(""".*(\(\d{1,2}\)|[ _-]copy( \d+)?|[ _-]کپی)(\.[^.]*)?$""", RegexOption.IGNORE_CASE)

    /**
     * Orders a group of identical files so the one to KEEP comes first: a name that does not look like a copy, then the
     * oldest one (the original), then the shortest path (usually the less buried place).
     */
    fun keeperFirst(files: List<File>): List<File> = files.sortedWith(
        compareBy<File>({ if (COPY_LIKE.matches(it.name)) 1 else 0 }, { it.lastModified() }, { it.absolutePath.length }, { it.absolutePath })
    )

    fun root(): File = android.os.Environment.getExternalStorageDirectory()

    fun scan(ctx: Context, cancel: () -> Boolean, progress: (String) -> Unit): Result {
        val root = root()
        val now = System.currentTimeMillis()
        val junk = ArrayList<Entry>()
        val empty = ArrayList<Entry>()
        val apk = ArrayList<Entry>()
        val old = ArrayList<Entry>()
        val bySize = HashMap<Long, MutableList<File>>()
        val pm = ctx.packageManager
        var seen = 0

        // true = this folder holds something (a file, a hidden folder, something unreadable) and so is not an empty tree.
        // An empty tree is listed once, at its top-most folder (the parent lists it when the parent itself has other content).
        fun walk(d: File, depth: Int, inThumbs: Boolean): Boolean {
            if (cancel() || depth > 40) return true
            val kids = d.listFiles() ?: return true // unreadable: never call it empty
            var hasContent = false
            val emptyKids = ArrayList<File>()
            for (k in kids) {
                if (cancel()) return true
                if (depth == 0 && k.name == "Android") { hasContent = true; continue }
                if (runCatching { java.nio.file.Files.isSymbolicLink(k.toPath()) }.getOrDefault(false)) { hasContent = true; continue }
                if (k.isDirectory) {
                    val thumbs = inThumbs || k.name == ".thumbnails"
                    // other hidden folders belong to apps (or to the person): left alone, and never "empty"
                    if (k.name.startsWith(".") && !thumbs) { hasContent = true; continue }
                    if (walk(k, depth + 1, thumbs)) hasContent = true else emptyKids.add(k)
                    continue
                }
                hasContent = true
                if (!k.isFile) continue
                val size = k.length()
                val mt = k.lastModified()
                val name = k.name
                if (++seen % 300 == 0) progress(k.parent ?: "")
                if (name == ".nomedia") continue
                if (inThumbs) { junk.add(Entry(k, size, mt)); continue }
                val recent = now - mt < DAY // something changed in the last day may still be in use
                if (isJunkName(name) && !recent) { junk.add(Entry(k, size, mt)); continue }
                if (size == 0L && !name.startsWith(".") && !recent) { junk.add(Entry(k, 0L, mt)); continue }
                if (ext(name) == "apk") {
                    val st = apkState(pm, k)
                    apk.add(Entry(k, size, mt, safe = st.first, note = st.second))
                    continue
                }
                if (size >= DUPE_MIN) bySize.getOrPut(size) { ArrayList() }.add(k)
                if (size >= OLD_SIZE && now - mt > OLD_AGE) old.add(Entry(k, size, mt, safe = false))
            }
            if (hasContent || depth == 0) for (e in emptyKids) empty.add(Entry(e, 0L, e.lastModified(), dir = true))
            return hasContent
        }

        // the standard top folders are never listed as empty (Android recreates them; the person expects them)
        walk(root, 0, false)
        val keepTop = setOf("DCIM", "Download", "Downloads", "Pictures", "Movies", "Music", "Documents", "Podcasts", "Ringtones", "Alarms", "Notifications", "Audiobooks", "Recordings")
        empty.removeAll { it.file.parentFile == root && it.file.name in keepTop }

        // identical files
        val dupes = ArrayList<Entry>()
        if (!cancel()) {
            progress("…")
            val groups = FmDupes.groups(bySize, cancel, progress)
            for (g in groups) {
                val ordered = keeperFirst(g.files)
                val keeper = ordered[0]
                for (f in ordered.drop(1)) dupes.add(Entry(f, g.size, f.lastModified(), safe = true, note = keeper.absolutePath))
            }
            dupes.sortByDescending { it.size }
        }
        old.sortByDescending { it.size }
        val oldCut = if (old.size > OLD_MAX) old.subList(0, OLD_MAX).toList() else old.toList()

        junk.sortByDescending { it.size }
        apk.sortByDescending { it.size }
        empty.sortBy { it.file.absolutePath }
        val arr = arrayOf<List<Entry>>(junk, empty, apk, dupes, oldCut)
        return Result(arr)
    }

    /** (installed already in this version or newer -> safe to delete, a short note). Unknown / unreadable -> not safe. */
    private fun apkState(pm: PackageManager, f: File): Pair<Boolean, String> = runCatching {
        val info = pm.getPackageArchiveInfo(f.absolutePath, 0) ?: return@runCatching false to ""
        val label = info.packageName ?: ""
        val apkVer = versionOf(info)
        val cur = runCatching { pm.getPackageInfo(info.packageName, 0) }.getOrNull()
        if (cur == null) return@runCatching false to label
        val curVer = versionOf(cur)
        (curVer >= apkVer) to label
    }.getOrDefault(false to "")

    @Suppress("DEPRECATION")
    private fun versionOf(i: android.content.pm.PackageInfo): Long =
        if (Build.VERSION.SDK_INT >= 28) i.longVersionCode else i.versionCode.toLong()

    /** Deletes the entries. Returns how many bytes really went and how many failed. Worker thread. */
    class Deleted(val bytes: Long, val failed: Int, val count: Int)

    fun delete(ctx: Context, items: List<Pair<Int, Entry>>, cancel: () -> Boolean, progress: (Float) -> Unit): Deleted {
        val rootPath = runCatching { root().canonicalPath }.getOrDefault(root().absolutePath)
        var bytes = 0L
        var failed = 0
        var count = 0
        val gone = ArrayList<String>()
        for ((i, p) in items.withIndex()) {
            if (cancel()) break
            val e = p.second
            progress(i / items.size.toFloat())
            // a path that is not below the storage root (a symbolic link trick) is never touched
            val inside = runCatching { e.file.canonicalPath.startsWith(rootPath) }.getOrDefault(false)
            if (!inside) { failed++; continue }
            val ok = runCatching {
                when {
                    e.dir -> { deleteEmptyTree(e.file) }
                    else -> e.file.delete()
                }
            }.getOrDefault(false)
            if (ok) {
                bytes += e.size
                count++
                if (!e.dir) gone.add(e.file.absolutePath)
            } else failed++
        }
        progress(1f)
        // the gallery and the music app should not keep showing what is gone
        if (gone.isNotEmpty()) runCatching { MediaScannerConnection.scanFile(ctx.applicationContext, gone.take(2000).toTypedArray(), null, null) }
        return Deleted(bytes, failed, count)
    }

    /** Removes a folder only if it holds nothing but folders: it never deletes a file, even one that appeared after the scan. */
    private fun deleteEmptyTree(d: File): Boolean {
        d.listFiles()?.forEach { if (it.isDirectory) deleteEmptyTree(it) }
        return d.delete()
    }
}
