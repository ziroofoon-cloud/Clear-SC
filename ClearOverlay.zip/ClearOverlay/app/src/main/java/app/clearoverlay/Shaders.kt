package app.clearoverlay

/*
 * GLSL ES 3.0 shaders.
 *
 *  - EASU / RCAS : AMD FidelityFX Super Resolution 1 (MIT License, Copyright (c) 2021 Advanced Micro Devices, Inc.)
 *  - SGSR1       : Snapdragon Game Super Resolution v1 (BSD-3-Clause, Copyright (c) 2023 Qualcomm Innovation Center, Inc.)
 *                  https://github.com/SnapdragonStudios/snapdragon-gsr
 *
 * The GLSL ES ports below were taken from the Nebula APK supplied with this project
 * (textureGather is emulated with texelFetch, so no ES 3.1 features are needed).
 * See licenses/ for the license texts.
 */
object Shaders {
    const val VERT = """#version 300 es
out highp vec2 vUv;
void main() {
    vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
    vUv = p;
    gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
}
"""

    const val OES_COPY = """#version 300 es
#extension GL_OES_EGL_image_external_essl3 : require
precision highp float;
uniform samplerExternalOES uSrc;
uniform mat4 uTexMatrix;
// Crop window inside the frame (x, y offset and x, y size, all 0..1): 1:1 pixels when zooming in the player.
uniform vec4 uCrop;
in highp vec2 vUv;
out vec4 outColor;
void main() {
    vec2 uv = (uTexMatrix * vec4(vUv * uCrop.zw + uCrop.xy, 0.0, 1.0)).xy;
    outColor = vec4(texture(uSrc, uv).rgb, 1.0);
}
"""

    const val RCAS = """#version 300 es

precision highp float;
precision highp int;
// Source size comes from a uniform: textureSize() returned 1x1 on the emulator's GLES translator.
uniform ivec2 uSrcSize;
vec4 fetchC(sampler2D t, ivec2 p) {
    return texelFetch(t, clamp(p, ivec2(0), uSrcSize - ivec2(1)), 0);
}
// textureGather emulation: the 2x2 footprint a bilinear sample at uv p would use.
void gather4(sampler2D t, vec2 p, out vec4 x, out vec4 y, out vec4 z, out vec4 w) {
    vec2 q = p * vec2(uSrcSize) - 0.5;
    ivec2 i0 = ivec2(floor(q));
    ivec2 i1 = i0 + ivec2(1);
    x = fetchC(t, ivec2(i0.x, i1.y));
    y = fetchC(t, ivec2(i1.x, i1.y));
    z = fetchC(t, ivec2(i1.x, i0.y));
    w = fetchC(t, ivec2(i0.x, i0.y));
}
float aRcpLo(float a) { return uintBitsToFloat(uint(0x7ef07ebb) - floatBitsToUint(a)); }
float aRsqLo(float a) { return uintBitsToFloat(uint(0x5f347d74) - (floatBitsToUint(a) >> uint(1))); }
float aRcpMed(float a) { float b = uintBitsToFloat(uint(0x7ef19fff) - floatBitsToUint(a)); return b * (-b * a + 2.0); }
float sat(float a) { return clamp(a, 0.0, 1.0); }
float min3(float a, float b, float c) { return min(a, min(b, c)); }
float max3(float a, float b, float c) { return max(a, max(b, c)); }
vec3 min3v(vec3 a, vec3 b, vec3 c) { return min(a, min(b, c)); }
vec3 max3v(vec3 a, vec3 b, vec3 c) { return max(a, max(b, c)); }

uniform sampler2D uSrc;
uniform float uSharpness;
out vec4 outColor;
#define FSR_RCAS_LIMIT (0.25 - (1.0 / 16.0))
void main() {
    ivec2 sp = ivec2(floor(gl_FragCoord.xy));
    vec3 b = fetchC(uSrc, sp + ivec2(0, -1)).rgb;
    vec3 d = fetchC(uSrc, sp + ivec2(-1, 0)).rgb;
    vec3 e = fetchC(uSrc, sp).rgb;
    vec3 f = fetchC(uSrc, sp + ivec2(1, 0)).rgb;
    vec3 h = fetchC(uSrc, sp + ivec2(0, 1)).rgb;
    vec3 mn4 = min(min3v(b, d, f), h);
    vec3 mx4 = max(max3v(b, d, f), h);
    vec2 peakC = vec2(1.0, -4.0);
    // Denominators kept off zero: flat white or black areas would give 0/0, which GPUs treat
    // differently (AMD's HLSL relies on max() dropping NaN).
    vec3 hitMin = min(mn4, e) / max(4.0 * mx4, vec3(1.0 / 65536.0));
    vec3 hitMax = (peakC.x - max(mx4, e)) / min(4.0 * mn4 + peakC.y, vec3(-1.0 / 65536.0));
    vec3 lobeRGB = max(-hitMin, hitMax);
    float lobe = max(-FSR_RCAS_LIMIT, min(max3(lobeRGB.r, lobeRGB.g, lobeRGB.b), 0.0)) * uSharpness;
    float rcpL = aRcpMed(4.0 * lobe + 1.0);
    vec3 pix = (lobe * b + lobe * d + lobe * h + lobe * f + e) * rcpL;
    outColor = vec4(clamp(pix, 0.0, 1.0), 1.0);
}
"""

    const val SGSR1 = """#version 300 es

precision highp float;
precision highp int;
// Source size comes from a uniform: textureSize() returned 1x1 on the emulator's GLES translator.
uniform ivec2 uSrcSize;
vec4 fetchC(sampler2D t, ivec2 p) {
    return texelFetch(t, clamp(p, ivec2(0), uSrcSize - ivec2(1)), 0);
}
// textureGather emulation: the 2x2 footprint a bilinear sample at uv p would use.
void gather4(sampler2D t, vec2 p, out vec4 x, out vec4 y, out vec4 z, out vec4 w) {
    vec2 q = p * vec2(uSrcSize) - 0.5;
    ivec2 i0 = ivec2(floor(q));
    ivec2 i1 = i0 + ivec2(1);
    x = fetchC(t, ivec2(i0.x, i1.y));
    y = fetchC(t, ivec2(i1.x, i1.y));
    z = fetchC(t, ivec2(i1.x, i0.y));
    w = fetchC(t, ivec2(i0.x, i0.y));
}
float aRcpLo(float a) { return uintBitsToFloat(uint(0x7ef07ebb) - floatBitsToUint(a)); }
float aRsqLo(float a) { return uintBitsToFloat(uint(0x5f347d74) - (floatBitsToUint(a) >> uint(1))); }
float aRcpMed(float a) { float b = uintBitsToFloat(uint(0x7ef19fff) - floatBitsToUint(a)); return b * (-b * a + 2.0); }
float sat(float a) { return clamp(a, 0.0, 1.0); }
float min3(float a, float b, float c) { return min(a, min(b, c)); }
float max3(float a, float b, float c) { return max(a, max(b, c)); }
vec3 min3v(vec3 a, vec3 b, vec3 c) { return min(a, min(b, c)); }
vec3 max3v(vec3 a, vec3 b, vec3 c) { return max(a, max(b, c)); }

uniform sampler2D uSrc;
uniform highp vec4 uViewportInfo;
uniform float uEdgeSharpness;
in highp vec2 vUv;
out vec4 outColor;

float fastLanczos2(float x) {
    float wA = x - 4.0;
    float wB = x * wA - wA;
    wA *= wA;
    return wB * wA;
}
vec2 weightY(float dx, float dy, float c, float stdv) {
    float x = ((dx * dx) + (dy * dy)) * 0.55 + clamp(abs(c) * stdv, 0.0, 1.0);
    float w = fastLanczos2(x);
    return vec2(w, w * c);
}
vec4 gatherG(vec2 p) {
    vec4 x, y, z, w;
    gather4(uSrc, p, x, y, z, w);
    return vec4(x.g, y.g, z.g, w.g);
}
void main() {
    const float edgeThreshold = 8.0 / 255.0;
    vec4 color;
    color.xyz = textureLod(uSrc, vUv, 0.0).xyz;
    highp vec2 imgCoord = (vUv * uViewportInfo.zw) + vec2(-0.5, 0.5);
    highp vec2 imgCoordPixel = floor(imgCoord);
    highp vec2 coord = imgCoordPixel * uViewportInfo.xy;
    vec2 pl = imgCoord - imgCoordPixel;
    vec4 left = gatherG(coord);
    float edgeVote = abs(left.z - left.y) + abs(color.g - left.y) + abs(color.g - left.z);
    if (edgeVote > edgeThreshold) {
        coord.x += uViewportInfo.x;
        vec4 right = gatherG(coord + vec2(uViewportInfo.x, 0.0));
        vec4 upDown;
        upDown.xy = gatherG(coord + vec2(0.0, -uViewportInfo.y)).wz;
        upDown.zw = gatherG(coord + vec2(0.0, uViewportInfo.y)).yx;
        float mean = (left.y + left.z + right.x + right.w) * 0.25;
        left -= vec4(mean);
        right -= vec4(mean);
        upDown -= vec4(mean);
        color.w = color.g - mean;
        float sum = abs(left.x) + abs(left.y) + abs(left.z) + abs(left.w)
                  + abs(right.x) + abs(right.y) + abs(right.z) + abs(right.w)
                  + abs(upDown.x) + abs(upDown.y) + abs(upDown.z) + abs(upDown.w);
        float stdv = 2.181818 / sum;
        vec2 aWY = weightY(pl.x, pl.y + 1.0, upDown.x, stdv);
        aWY += weightY(pl.x - 1.0, pl.y + 1.0, upDown.y, stdv);
        aWY += weightY(pl.x - 1.0, pl.y - 2.0, upDown.z, stdv);
        aWY += weightY(pl.x, pl.y - 2.0, upDown.w, stdv);
        aWY += weightY(pl.x + 1.0, pl.y - 1.0, left.x, stdv);
        aWY += weightY(pl.x, pl.y - 1.0, left.y, stdv);
        aWY += weightY(pl.x, pl.y, left.z, stdv);
        aWY += weightY(pl.x + 1.0, pl.y, left.w, stdv);
        aWY += weightY(pl.x - 1.0, pl.y - 1.0, right.x, stdv);
        aWY += weightY(pl.x - 2.0, pl.y - 1.0, right.y, stdv);
        aWY += weightY(pl.x - 2.0, pl.y, right.z, stdv);
        aWY += weightY(pl.x - 1.0, pl.y, right.w, stdv);
        float finalY = aWY.y / aWY.x;
        float maxY = max(max(left.y, left.z), max(right.x, right.w));
        float minY = min(min(left.y, left.z), min(right.x, right.w));
        finalY = clamp(uEdgeSharpness * finalY, minY, maxY);
        float deltaY = clamp(finalY - color.w, -23.0 / 255.0, 23.0 / 255.0);
        color.xyz = clamp(color.xyz + deltaY, 0.0, 1.0);
    }
    outColor = vec4(color.xyz, 1.0);
}
"""

    /** Plain hardware-filtered upscale: zero extra math, relies on GL_LINEAR on the source texture.
     *  Used by "Fast" mode for GPUs too weak to afford EASU/SGSR1. */
    const val BILINEAR = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
in highp vec2 vUv;
out vec4 outColor;
void main() {
    outColor = vec4(texture(uSrc, vUv).rgb, 1.0);
}
"""

    /** Supersampling downscale: 4 hardware-bilinear taps at +-1/4 output pixel, averaged.
     *  Used when the render scale is above 100% to shrink the sharpened big frame back to the panel size.
     *  uStep = 0.25 / output size, in uv units. */
    const val DOWNSCALE = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform vec2 uStep;
in highp vec2 vUv;
out vec4 outColor;
void main() {
    vec3 c = texture(uSrc, vUv + vec2(-uStep.x, -uStep.y)).rgb
           + texture(uSrc, vUv + vec2( uStep.x, -uStep.y)).rgb
           + texture(uSrc, vUv + vec2(-uStep.x,  uStep.y)).rgb
           + texture(uSrc, vUv + vec2( uStep.x,  uStep.y)).rgb;
    outColor = vec4(c * 0.25, 1.0);
}
"""

    /** Saturation + mild contrast lift ("Vivid colors"), in the spirit of MX Player's enhance filter.
     *  uVivid is 0..1; 0 leaves the image untouched. */
    const val COLOR_ENHANCE = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform float uVivid;
uniform float uContrast;
in highp vec2 vUv;
out vec4 outColor;
void main() {
    vec3 c = texture(uSrc, vUv).rgb;
    float luma = dot(c, vec3(0.299, 0.587, 0.114));
    vec3 sat = mix(vec3(luma), c, 1.0 + uVivid * 0.6);
    vec3 cst = (sat - 0.5) * (1.0 + uVivid * 0.15) * (1.0 + uContrast * 0.7) + 0.5;
    outColor = vec4(clamp(cst, 0.0, 1.0), 1.0);
}
"""

    const val EASU = """#version 300 es

precision highp float;
precision highp int;
// Source size comes from a uniform: textureSize() returned 1x1 on the emulator's GLES translator.
uniform ivec2 uSrcSize;
vec4 fetchC(sampler2D t, ivec2 p) {
    return texelFetch(t, clamp(p, ivec2(0), uSrcSize - ivec2(1)), 0);
}
// textureGather emulation: the 2x2 footprint a bilinear sample at uv p would use.
void gather4(sampler2D t, vec2 p, out vec4 x, out vec4 y, out vec4 z, out vec4 w) {
    vec2 q = p * vec2(uSrcSize) - 0.5;
    ivec2 i0 = ivec2(floor(q));
    ivec2 i1 = i0 + ivec2(1);
    x = fetchC(t, ivec2(i0.x, i1.y));
    y = fetchC(t, ivec2(i1.x, i1.y));
    z = fetchC(t, ivec2(i1.x, i0.y));
    w = fetchC(t, ivec2(i0.x, i0.y));
}
float aRcpLo(float a) { return uintBitsToFloat(uint(0x7ef07ebb) - floatBitsToUint(a)); }
float aRsqLo(float a) { return uintBitsToFloat(uint(0x5f347d74) - (floatBitsToUint(a) >> uint(1))); }
float aRcpMed(float a) { float b = uintBitsToFloat(uint(0x7ef19fff) - floatBitsToUint(a)); return b * (-b * a + 2.0); }
float sat(float a) { return clamp(a, 0.0, 1.0); }
float min3(float a, float b, float c) { return min(a, min(b, c)); }
float max3(float a, float b, float c) { return max(a, max(b, c)); }
vec3 min3v(vec3 a, vec3 b, vec3 c) { return min(a, min(b, c)); }
vec3 max3v(vec3 a, vec3 b, vec3 c) { return max(a, max(b, c)); }

uniform sampler2D uSrc;
uniform vec4 uCon0;
uniform vec4 uCon1;
uniform vec4 uCon2;
uniform vec4 uCon3;
out vec4 outColor;

void tap(inout vec3 aC, inout float aW, vec2 off, vec2 dir, vec2 len, float lob, float clp, vec3 c) {
    vec2 v;
    v.x = (off.x * dir.x) + (off.y * dir.y);
    v.y = (off.x * (-dir.y)) + (off.y * dir.x);
    v *= len;
    float d2 = min(v.x * v.x + v.y * v.y, clp);
    float wB = (2.0 / 5.0) * d2 - 1.0;
    float wA = lob * d2 - 1.0;
    wB *= wB;
    wA *= wA;
    wB = (25.0 / 16.0) * wB - (25.0 / 16.0 - 1.0);
    float w = wB * wA;
    aC += c * w;
    aW += w;
}

void setDir(inout vec2 dir, inout float len, vec2 pp, int corner, float lA, float lB, float lC, float lD, float lE) {
    float w = 0.0;
    if (corner == 0) w = (1.0 - pp.x) * (1.0 - pp.y);
    if (corner == 1) w = pp.x * (1.0 - pp.y);
    if (corner == 2) w = (1.0 - pp.x) * pp.y;
    if (corner == 3) w = pp.x * pp.y;
    float dc = lD - lC;
    float cb = lC - lB;
    float lenX = aRcpLo(max(abs(dc), abs(cb)));
    float dirX = lD - lB;
    dir.x += dirX * w;
    lenX = sat(abs(dirX) * lenX);
    len += lenX * lenX * w;
    float ec = lE - lC;
    float ca = lC - lA;
    float lenY = aRcpLo(max(abs(ec), abs(ca)));
    float dirY = lE - lA;
    dir.y += dirY * w;
    lenY = sat(abs(dirY) * lenY);
    len += lenY * lenY * w;
}

void main() {
    vec2 ip = floor(gl_FragCoord.xy);
    vec2 pp = ip * uCon0.xy + uCon0.zw;
    vec2 fp = floor(pp);
    pp -= fp;
    vec2 p0 = fp * uCon1.xy + uCon1.zw;
    vec2 p1 = p0 + uCon2.xy;
    vec2 p2 = p0 + uCon2.zw;
    vec2 p3 = p0 + uCon3.xy;
    vec4 b0, b1, b2, b3; gather4(uSrc, p0, b0, b1, b2, b3); // b c z z  (x y z w)
    vec4 i0, i1, i2, i3; gather4(uSrc, p1, i0, i1, i2, i3); // i j f e
    vec4 k0, k1, k2, k3; gather4(uSrc, p2, k0, k1, k2, k3); // k l h g
    vec4 z0, z1, z2, z3; gather4(uSrc, p3, z0, z1, z2, z3); // z z o n
    vec3 b = b0.rgb, c = b1.rgb;
    vec3 i = i0.rgb, j = i1.rgb, f = i2.rgb, e = i3.rgb;
    vec3 k = k0.rgb, l = k1.rgb, h = k2.rgb, g = k3.rgb;
    vec3 o = z2.rgb, n = z3.rgb;
    // Luma times 2.
    #define L(v) (v.b * 0.5 + (v.r * 0.5 + v.g))
    float bL = L(b), cL = L(c), iL = L(i), jL = L(j), fL = L(f), eL = L(e);
    float kL = L(k), lL = L(l), hL = L(h), gL = L(g), oL = L(o), nL = L(n);
    vec2 dir = vec2(0.0);
    float len = 0.0;
    setDir(dir, len, pp, 0, bL, eL, fL, gL, jL);
    setDir(dir, len, pp, 1, cL, fL, gL, hL, kL);
    setDir(dir, len, pp, 2, fL, iL, jL, kL, nL);
    setDir(dir, len, pp, 3, gL, jL, kL, lL, oL);
    vec2 dir2 = dir * dir;
    float dirR = dir2.x + dir2.y;
    bool zro = dirR < (1.0 / 32768.0);
    dirR = aRsqLo(dirR);
    dirR = zro ? 1.0 : dirR;
    dir.x = zro ? 1.0 : dir.x;
    dir *= vec2(dirR);
    len = len * 0.5;
    len *= len;
    float stretch = (dir.x * dir.x + dir.y * dir.y) * aRcpLo(max(abs(dir.x), abs(dir.y)));
    vec2 len2 = vec2(1.0 + (stretch - 1.0) * len, 1.0 - 0.5 * len);
    float lob = 0.5 + ((1.0 / 4.0 - 0.04) - 0.5) * len;
    float clp = aRcpLo(lob);
    vec3 min4 = min(min3v(f, g, j), k);
    vec3 max4 = max(max3v(f, g, j), k);
    vec3 aC = vec3(0.0);
    float aW = 0.0;
    tap(aC, aW, vec2( 0.0, -1.0) - pp, dir, len2, lob, clp, b);
    tap(aC, aW, vec2( 1.0, -1.0) - pp, dir, len2, lob, clp, c);
    tap(aC, aW, vec2(-1.0,  1.0) - pp, dir, len2, lob, clp, i);
    tap(aC, aW, vec2( 0.0,  1.0) - pp, dir, len2, lob, clp, j);
    tap(aC, aW, vec2( 0.0,  0.0) - pp, dir, len2, lob, clp, f);
    tap(aC, aW, vec2(-1.0,  0.0) - pp, dir, len2, lob, clp, e);
    tap(aC, aW, vec2( 1.0,  1.0) - pp, dir, len2, lob, clp, k);
    tap(aC, aW, vec2( 2.0,  1.0) - pp, dir, len2, lob, clp, l);
    tap(aC, aW, vec2( 2.0,  0.0) - pp, dir, len2, lob, clp, h);
    tap(aC, aW, vec2( 1.0,  0.0) - pp, dir, len2, lob, clp, g);
    tap(aC, aW, vec2( 1.0,  2.0) - pp, dir, len2, lob, clp, o);
    tap(aC, aW, vec2( 0.0,  2.0) - pp, dir, len2, lob, clp, n);
    vec3 pix = min(max4, max(min4, aC * (1.0 / aW)));
    outColor = vec4(max(pix, vec3(0.0)), 1.0);
}
"""

    /** FXAA "Fast": Lottes' compact 5-tap FXAA (console-style). Very cheap, mild smoothing.
     *  uInv = 1 / source size, uAmt = 0..1 blend with the original pixel. */
    const val FXAA_FAST = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform vec2 uInv;
uniform float uAmt;
in highp vec2 vUv;
out vec4 outColor;
float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
void main() {
    vec3 rgbM = texture(uSrc, vUv).rgb;
    vec3 rgbNW = textureOffset(uSrc, vUv, ivec2(-1,  1)).rgb;
    vec3 rgbNE = textureOffset(uSrc, vUv, ivec2( 1,  1)).rgb;
    vec3 rgbSW = textureOffset(uSrc, vUv, ivec2(-1, -1)).rgb;
    vec3 rgbSE = textureOffset(uSrc, vUv, ivec2( 1, -1)).rgb;
    float lM = luma(rgbM), lNW = luma(rgbNW), lNE = luma(rgbNE), lSW = luma(rgbSW), lSE = luma(rgbSE);
    float lMin = min(lM, min(min(lNW, lNE), min(lSW, lSE)));
    float lMax = max(lM, max(max(lNW, lNE), max(lSW, lSE)));
    vec2 dir;
    dir.x = -((lNW + lNE) - (lSW + lSE));
    dir.y =  ((lNE + lSE) - (lNW + lSW));
    float dirReduce = max((lNW + lNE + lSW + lSE) * (0.25 * (1.0 / 8.0)), 1.0 / 128.0);
    float rcpDirMin = 1.0 / (min(abs(dir.x), abs(dir.y)) + dirReduce);
    dir = clamp(dir * rcpDirMin, vec2(-8.0), vec2(8.0)) * uInv;
    vec3 rgbA = 0.5 * (texture(uSrc, vUv + dir * (1.0 / 3.0 - 0.5)).rgb
                     + texture(uSrc, vUv + dir * (2.0 / 3.0 - 0.5)).rgb);
    vec3 rgbB = rgbA * 0.5 + 0.25 * (texture(uSrc, vUv + dir * -0.5).rgb
                                   + texture(uSrc, vUv + dir *  0.5).rgb);
    float lB = luma(rgbB);
    vec3 res = (lB < lMin || lB > lMax) ? rgbA : rgbB;
    outColor = vec4(mix(rgbM, res, uAmt), 1.0);
}
"""

    /** FXAA "Quality": FXAA 3.11 style. Edge detection, end-of-edge search along the edge (up to ~12 steps
     *  each way) and sub-pixel blend. Better on long jaggy lines than the fast one, still one pass. */
    const val FXAA_QUALITY = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform vec2 uInv;
uniform float uAmt;
in highp vec2 vUv;
out vec4 outColor;
float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
float lumaAt(vec2 p) { return luma(texture(uSrc, p).rgb); }
void main() {
    vec3 cM = texture(uSrc, vUv).rgb;
    float lM = luma(cM);
    float lN = luma(textureOffset(uSrc, vUv, ivec2( 0,  1)).rgb);
    float lS = luma(textureOffset(uSrc, vUv, ivec2( 0, -1)).rgb);
    float lW = luma(textureOffset(uSrc, vUv, ivec2(-1,  0)).rgb);
    float lE = luma(textureOffset(uSrc, vUv, ivec2( 1,  0)).rgb);
    float rMin = min(lM, min(min(lS, lN), min(lW, lE)));
    float rMax = max(lM, max(max(lS, lN), max(lW, lE)));
    float range = rMax - rMin;
    if (range < max(1.0 / 16.0, rMax * (1.0 / 8.0))) { outColor = vec4(cM, 1.0); return; }
    float lNW = luma(textureOffset(uSrc, vUv, ivec2(-1,  1)).rgb);
    float lNE = luma(textureOffset(uSrc, vUv, ivec2( 1,  1)).rgb);
    float lSW = luma(textureOffset(uSrc, vUv, ivec2(-1, -1)).rgb);
    float lSE = luma(textureOffset(uSrc, vUv, ivec2( 1, -1)).rgb);
    float lNS = lN + lS, lWE = lW + lE;
    float lNWSW = lNW + lSW, lNESE = lNE + lSE, lNWNE = lNW + lNE, lSWSE = lSW + lSE;
    float edgeH = abs(-2.0 * lW + lNWSW) + abs(-2.0 * lM + lNS) * 2.0 + abs(-2.0 * lE + lNESE);
    float edgeV = abs(-2.0 * lN + lNWNE) + abs(-2.0 * lM + lWE) * 2.0 + abs(-2.0 * lS + lSWSE);
    bool horz = edgeH >= edgeV;
    // neighbours across the edge: +side / -side
    float lPos = horz ? lN : lE;
    float lNeg = horz ? lS : lW;
    float gPos = lPos - lM, gNeg = lNeg - lM;
    bool toPos = abs(gPos) >= abs(gNeg);
    float grad = max(abs(gPos), abs(gNeg)) * 0.25;
    float lAvgEdge = 0.5 * ((toPos ? lPos : lNeg) + lM);
    vec2 perp = horz ? vec2(0.0, uInv.y) : vec2(uInv.x, 0.0);
    vec2 along = horz ? vec2(uInv.x, 0.0) : vec2(0.0, uInv.y);
    float sgn = toPos ? 1.0 : -1.0;
    vec2 uvE = vUv + perp * sgn * 0.5;
    vec2 p1 = uvE - along;
    vec2 p2 = uvE + along;
    float e1 = lumaAt(p1) - lAvgEdge;
    float e2 = lumaAt(p2) - lAvgEdge;
    bool d1 = abs(e1) >= grad;
    bool d2 = abs(e2) >= grad;
    for (int i = 0; i < 12; i++) {
        if (d1 && d2) break;
        float stp = i < 4 ? 1.0 : (i < 8 ? 1.5 : 2.5);
        if (!d1) { p1 -= along * stp; e1 = lumaAt(p1) - lAvgEdge; d1 = abs(e1) >= grad; }
        if (!d2) { p2 += along * stp; e2 = lumaAt(p2) - lAvgEdge; d2 = abs(e2) >= grad; }
    }
    float dist1 = horz ? (vUv.x - p1.x) : (vUv.y - p1.y);
    float dist2 = horz ? (p2.x - vUv.x) : (p2.y - vUv.y);
    bool nearer1 = dist1 < dist2;
    float distFinal = min(dist1, dist2);
    float spanLen = max(dist1 + dist2, 1e-6);
    float pixOff = 0.5 - distFinal / spanLen;
    bool centerDark = lM < lAvgEdge;
    bool goodSpan = ((nearer1 ? e1 : e2) < 0.0) != centerDark;
    float pixOffGood = goodSpan ? pixOff : 0.0;
    float lL = (2.0 * (lNS + lWE) + lNWSW + lNESE) * (1.0 / 12.0);
    float sA = clamp(abs(lL - lM) / range, 0.0, 1.0);
    float sB = (-2.0 * sA + 3.0) * sA;
    float sub = sB * sB * 0.75;
    float off = max(pixOffGood, sub);
    vec3 res = texture(uSrc, vUv + perp * sgn * off).rgb;
    outColor = vec4(mix(cM, res, uAmt), 1.0);
}
"""

    /** "Edge Smooth": own edge-directed filter. Sobel finds the edge direction, then the pixel is blurred
     *  ALONG the edge (never across it), so lines get smoother while text and fine detail stay crisp.
     *  Flat areas are left untouched. */
    const val EDGE_SMOOTH = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform vec2 uInv;
uniform float uAmt;
in highp vec2 vUv;
out vec4 outColor;
float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
void main() {
    vec3 cM = texture(uSrc, vUv).rgb;
    float a = luma(textureOffset(uSrc, vUv, ivec2(-1,  1)).rgb);
    float b = luma(textureOffset(uSrc, vUv, ivec2( 0,  1)).rgb);
    float c = luma(textureOffset(uSrc, vUv, ivec2( 1,  1)).rgb);
    float d = luma(textureOffset(uSrc, vUv, ivec2(-1,  0)).rgb);
    float e = luma(cM);
    float f = luma(textureOffset(uSrc, vUv, ivec2( 1,  0)).rgb);
    float g = luma(textureOffset(uSrc, vUv, ivec2(-1, -1)).rgb);
    float h = luma(textureOffset(uSrc, vUv, ivec2( 0, -1)).rgb);
    float i = luma(textureOffset(uSrc, vUv, ivec2( 1, -1)).rgb);
    float gx = (c + 2.0 * f + i) - (a + 2.0 * d + g);
    float gy = (a + 2.0 * b + c) - (g + 2.0 * h + i);
    float mag = length(vec2(gx, gy));
    float mn = min(min(min(a, b), min(c, d)), min(min(e, f), min(g, min(h, i))));
    float mx = max(max(max(a, b), max(c, d)), max(max(e, f), max(g, max(h, i))));
    // ignore flat areas / very faint edges; fully active on strong contrast
    float k = smoothstep(0.06, 0.30, mag) * uAmt;
    if (k <= 0.0 || (mx - mn) < 0.04) { outColor = vec4(cM, 1.0); return; }
    vec2 t = normalize(vec2(-gy, gx)) * uInv;   // tangent = along the edge
    vec3 acc = cM * 3.0;
    acc += (texture(uSrc, vUv + t * 0.75).rgb + texture(uSrc, vUv - t * 0.75).rgb) * 2.0;
    acc += (texture(uSrc, vUv + t * 1.75).rgb + texture(uSrc, vUv - t * 1.75).rgb);
    vec3 smoothC = acc * (1.0 / 9.0);
    // cheap second tap set a little off-axis catches stair-steps on shallow slopes
    vec2 n = vec2(-t.y, t.x);
    vec3 side = 0.5 * (texture(uSrc, vUv + n * 0.35).rgb + texture(uSrc, vUv - n * 0.35).rgb);
    smoothC = mix(smoothC, side, 0.25);
    outColor = vec4(mix(cM, smoothC, k), 1.0);
}
"""

    /** "Raw": shows the captured low-resolution frame exactly as it is, nearest-neighbour, no filtering at all.
     *  Every captured pixel becomes a visible block, so you can see what the chosen render resolution really looks like. */
    const val NEAREST = """#version 300 es
precision highp float;
precision highp int;
uniform sampler2D uSrc;
uniform ivec2 uSrcSize;
in highp vec2 vUv;
out vec4 outColor;
void main() {
    ivec2 p = clamp(ivec2(floor(vUv * vec2(uSrcSize))), ivec2(0), uSrcSize - ivec2(1));
    outColor = vec4(texelFetch(uSrc, p, 0).rgb, 1.0);
}
"""

    /** "Detail / deblur": wide, halo-limited unsharp mask on luma, aimed at soft sources that were already upscaled
     *  by a player (e.g. a 360p video stretched to the screen). RCAS only looks 1 px away, which is too small to
     *  undo a 3x bilinear blur; this looks 1..4 px away. Small differences are ignored (keeps noise and blocks calm)
     *  and the result is clamped to the local min/max so it cannot ring. */
    const val DETAIL = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform vec2 uInv;
uniform float uAmt;
uniform float uRadius;
in highp vec2 vUv;
out vec4 outColor;
float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
float lumaAt(vec2 o) { return luma(texture(uSrc, vUv + o * uInv).rgb); }
void main() {
    vec3 c = texture(uSrc, vUv).rgb;
    float l0 = luma(c);
    float r1 = uRadius, r2 = uRadius * 2.0;
    float a = lumaAt(vec2(-r1,  r1)), b = lumaAt(vec2(0.0,  r1)), d = lumaAt(vec2( r1,  r1));
    float e = lumaAt(vec2(-r1, 0.0)),                              f = lumaAt(vec2( r1, 0.0));
    float g = lumaAt(vec2(-r1, -r1)), h = lumaAt(vec2(0.0, -r1)), i = lumaAt(vec2( r1, -r1));
    float blur1 = (4.0 * l0 + 2.0 * (b + e + f + h) + (a + d + g + i)) * (1.0 / 16.0);
    float a2 = lumaAt(vec2(-r2,  r2)), b2 = lumaAt(vec2(0.0,  r2)), d2 = lumaAt(vec2( r2,  r2));
    float e2 = lumaAt(vec2(-r2, 0.0)),                               f2 = lumaAt(vec2( r2, 0.0));
    float g2 = lumaAt(vec2(-r2, -r2)), h2 = lumaAt(vec2(0.0, -r2)), i2 = lumaAt(vec2( r2, -r2));
    float blur2 = (4.0 * l0 + 2.0 * (b2 + e2 + f2 + h2) + (a2 + d2 + g2 + i2)) * (1.0 / 16.0);
    float blur = 0.6 * blur1 + 0.4 * blur2;
    float diff = l0 - blur;
    // coring: tiny differences (noise, compression blocks) get little gain, real edges full gain
    float gain = smoothstep(0.004, 0.035, abs(diff));
    float mn = min(min(min(a, b), min(d, e)), min(min(f, g), min(h, min(i, l0))));
    float mx = max(max(max(a, b), max(d, e)), max(max(f, g), max(h, max(i, l0))));
    float nl = clamp(l0 + diff * uAmt * 3.0 * gain, mn - 0.02, mx + 0.02);
    outColor = vec4(clamp(c + (nl - l0), 0.0, 1.0), 1.0);
}
"""

    /** "Denoise / deblock": edge-preserving bilateral filter (12 taps). Pixels are averaged only with neighbours of
     *  similar brightness, so flat areas lose their compression noise and the faint steps at block borders,
     *  while real edges stay. uAmt 0..1 widens the "similar enough" range. */
    const val DENOISE = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform vec2 uInv;
uniform float uAmt;
in highp vec2 vUv;
out vec4 outColor;
float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
void main() {
    vec3 c = texture(uSrc, vUv).rgb;
    float l0 = luma(c);
    float sigma = 0.012 + 0.11 * uAmt;
    float inv2s = 1.0 / (2.0 * sigma * sigma);
    vec3 sum = c;
    float ws = 1.0;
    const vec2 OFF[12] = vec2[12](
        vec2(-1.0, -1.0), vec2(0.0, -1.0), vec2(1.0, -1.0),
        vec2(-1.0,  0.0),                  vec2(1.0,  0.0),
        vec2(-1.0,  1.0), vec2(0.0,  1.0), vec2(1.0,  1.0),
        vec2(-2.0,  0.0), vec2(2.0,  0.0), vec2(0.0, -2.0), vec2(0.0, 2.0));
    for (int i = 0; i < 12; i++) {
        vec3 s = texture(uSrc, vUv + OFF[i] * uInv).rgb;
        float d = luma(s) - l0;
        float sp = i < 8 ? 1.0 : 0.6;
        float w = sp * exp(-d * d * inv2s);
        sum += s * w;
        ws += w;
    }
    outColor = vec4(sum / ws, 1.0);
}
"""

    /** "Deband": for each pixel, takes a few random pairs of far-away samples (up to uRange px) and averages
     *  only those that are almost the same colour, so gradients turn smooth but real edges are untouched.
     *  A 1-level dither hides the last steps of 8-bit output. uAmt 0..1 = how different samples may be. */
    const val DEBAND = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform vec2 uInv;
uniform float uAmt;
uniform float uRange;
in highp vec2 vUv;
out vec4 outColor;
float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
void main() {
    vec3 c = texture(uSrc, vUv).rgb;
    vec2 p = gl_FragCoord.xy;
    float thr = 0.004 + 0.03 * uAmt;
    vec3 acc = c;
    float n = 1.0;
    for (int i = 0; i < 4; i++) {
        float fi = float(i);
        float a = hash(p + fi * 17.0) * 6.2831853;
        float d = (0.25 + 0.75 * hash(p * 1.7 + fi * 31.0)) * uRange;
        vec2 o = vec2(cos(a), sin(a)) * d * uInv;
        vec3 s1 = texture(uSrc, vUv + o).rgb;
        vec3 s2 = texture(uSrc, vUv - o).rgb;
        vec3 d1 = abs(s1 - c);
        vec3 d2 = abs(s2 - c);
        if (max(max(d1.r, d1.g), d1.b) < thr && max(max(d2.r, d2.g), d2.b) < thr) {
            acc += s1 + s2;
            n += 2.0;
        }
    }
    vec3 res = acc / n;
    res += (hash(p * 3.1) - 0.5) * (1.0 / 255.0);
    outColor = vec4(clamp(res, 0.0, 1.0), 1.0);
}
"""


    /** Frame generation, step 1: block matching between two frames. One output texel = one 16x16 pixel block of the
     *  in-between picture; the result is the motion (prev -> cur, +-16 px) and the match error. */
    const val FG_MOTION = """#version 300 es
precision highp float;
uniform sampler2D uPrev;
uniform sampler2D uCur;
uniform vec2 uInv;
uniform float uStep;
uniform int uRange;
uniform float uBlock;
uniform int uRefine;
in highp vec2 vUv;
out vec4 outColor;
float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
void main() {
    float best = 1e9;
    vec2 bestD = vec2(0.0);
    for (int dy = -uRange; dy <= uRange; dy++) {
        for (int dx = -uRange; dx <= uRange; dx++) {
            vec2 d = vec2(float(dx), float(dy)) * uStep;
            float cost = 0.0;
            for (int j = 0; j < 4; j++) {
                for (int i = 0; i < 4; i++) {
                    vec2 s = (vec2(float(i), float(j)) + 0.5) * (uBlock * 0.25) - uBlock * 0.5;
                    float a = luma(texture(uPrev, vUv + (s - d * 0.5) * uInv).rgb);
                    float b = luma(texture(uCur, vUv + (s + d * 0.5) * uInv).rgb);
                    cost += abs(a - b);
                }
            }
            cost += 0.004 * length(d); // prefer the smaller motion when two matches are equal
            if (cost < best) { best = cost; bestD = d; }
        }
    }
    if (uRefine > 0) { // finer search (1 px steps) around the best coarse match
        vec2 c0 = bestD;
        for (int ry = -2; ry <= 2; ry++) {
            for (int rx = -2; rx <= 2; rx++) {
                vec2 d = c0 + vec2(float(rx), float(ry));
                float cost = 0.0;
                for (int j = 0; j < 4; j++) {
                    for (int i = 0; i < 4; i++) {
                        vec2 s = (vec2(float(i), float(j)) + 0.5) * (uBlock * 0.25) - uBlock * 0.5;
                        float a = luma(texture(uPrev, vUv + (s - d * 0.5) * uInv).rgb);
                        float b = luma(texture(uCur, vUv + (s + d * 0.5) * uInv).rgb);
                        cost += abs(a - b);
                    }
                }
                cost += 0.004 * length(d);
                if (cost < best) { best = cost; bestD = d; }
            }
        }
    }
    float avg = best / 16.0;
    outColor = vec4(bestD / 40.0 + 0.5, clamp(avg * 4.0, 0.0, 1.0), 1.0);
}
"""

    /** Frame generation, step 2: the picture at position uT between the two frames, built along the motion of each block
     *  (motion smoothed over the neighbouring blocks); where the two warped pictures disagree (hidden / uncovered areas)
     *  the nearest real frame is used instead of a blend of both, which would leave a ghost. */
    const val FG_INTERP = """#version 300 es
precision highp float;
uniform sampler2D uPrev;
uniform sampler2D uCur;
uniform sampler2D uMv;
uniform vec2 uInv;
uniform float uT;
uniform float uMvScale;
in highp vec2 vUv;
out vec4 outColor;
void main() {
    vec4 m = texture(uMv, vUv);
    vec3 pc = texture(uPrev, vUv).rgb;
    vec3 cc = texture(uCur, vUv).rgb;
    if (m.b > 0.8) { outColor = vec4(cc, 1.0); return; } // scene cut: nothing to blend
    vec2 g = 1.0 / vec2(textureSize(uMv, 0));
    vec4 m1 = texture(uMv, vUv + vec2(g.x, 0.0));
    vec4 m2 = texture(uMv, vUv - vec2(g.x, 0.0));
    vec4 m3 = texture(uMv, vUv + vec2(0.0, g.y));
    vec4 m4 = texture(uMv, vUv - vec2(0.0, g.y));
    float w0 = 1.2 - m.b, w1 = 1.0 - m1.b, w2 = 1.0 - m2.b, w3 = 1.0 - m3.b, w4 = 1.0 - m4.b;
    vec2 mv = (m.rg * w0 + m1.rg * w1 + m2.rg * w2 + m3.rg * w3 + m4.rg * w4) / (w0 + w1 + w2 + w3 + w4);
    vec2 d = (mv - 0.5) * 40.0 * uMvScale;
    vec3 a = texture(uPrev, vUv - d * uT * uInv).rgb;
    vec3 b = texture(uCur, vUv + d * (1.0 - uT) * uInv).rgb;
    vec3 warped = mix(a, b, uT);
    vec3 nearest = mix(pc, cc, smoothstep(0.35, 0.65, uT));
    float err = length(a - b);
    float conf = 1.0 - smoothstep(0.08, 0.26, err);
    outColor = vec4(mix(nearest, warped, conf), 1.0);
}
"""

    /** Temporal clean-up: the previous result, moved along the motion of each block, is blended into the new frame where
     *  the two agree (less compression noise and flicker, a little more real detail). */
    const val TEMPORAL = """#version 300 es
precision highp float;
uniform sampler2D uCur;uniform sampler2D uHist;uniform sampler2D uMv;uniform vec2 uInv;uniform float uAmt;
in highp vec2 vUv;out vec4 outColor;
void main(){
 vec3 cc=texture(uCur,vUv).rgb;
 vec4 m=texture(uMv,vUv);
 if(m.b>0.8){outColor=vec4(cc,1.0);return;}
 vec2 d=(m.rg-0.5)*40.0;
 if(length(d)>6.0){outColor=vec4(cc,1.0);return;}
 
 vec3 h=texture(uHist,vUv-d*uInv).rgb;
 vec3 lo=cc,hi=cc;
 for(int j=-1;j<=1;j++)for(int i=-1;i<=1;i++){vec3 v=texture(uCur,vUv+vec2(float(i),float(j))*uInv).rgb;lo=min(lo,v);hi=max(hi,v);}
 vec3 hc=clamp(h,lo-0.05,hi+0.05);
 float diff=length(hc-cc);
 float w=uAmt*exp(-(diff*diff)/(0.12*0.12));
 outColor=vec4(mix(cc,hc,w),1.0);}
"""

    /** Edge refinement after the Lanczos upscale: along every edge the picture is smoothed (removes stair-steps),
     *  across it nothing is touched; the sharpening that follows then makes the edge crisp. */
    const val EDGE_REFINE = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform vec2 uInv;
uniform float uR;
in highp vec2 vUv;
out vec4 outColor;
float lum(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
void main() {
    vec3 c = texture(uSrc, vUv).rgb;
    float tl = lum(texture(uSrc, vUv + vec2(-1.0, -1.0) * uInv).rgb);
    float tc = lum(texture(uSrc, vUv + vec2(0.0, -1.0) * uInv).rgb);
    float tr = lum(texture(uSrc, vUv + vec2(1.0, -1.0) * uInv).rgb);
    float ml = lum(texture(uSrc, vUv + vec2(-1.0, 0.0) * uInv).rgb);
    float mr = lum(texture(uSrc, vUv + vec2(1.0, 0.0) * uInv).rgb);
    float bl = lum(texture(uSrc, vUv + vec2(-1.0, 1.0) * uInv).rgb);
    float bc = lum(texture(uSrc, vUv + vec2(0.0, 1.0) * uInv).rgb);
    float br = lum(texture(uSrc, vUv + vec2(1.0, 1.0) * uInv).rgb);
    float gx = (tr + 2.0 * mr + br) - (tl + 2.0 * ml + bl);
    float gy = (bl + 2.0 * bc + br) - (tl + 2.0 * tc + tr);
    float m = length(vec2(gx, gy));
    if (m < 0.04) { outColor = vec4(c, 1.0); return; }
    vec2 n = vec2(gx, gy) / m;
    vec2 t = vec2(-n.y, n.x) * uInv * uR;
    // 1) smooth along the edge: removes the stair-steps of the enlargement
    vec3 s = c * 3.0
        + (texture(uSrc, vUv + t * 0.5).rgb + texture(uSrc, vUv - t * 0.5).rgb) * 2.5
        + (texture(uSrc, vUv + t).rgb + texture(uSrc, vUv - t).rgb) * 1.5
        + (texture(uSrc, vUv + t * 1.5).rgb + texture(uSrc, vUv - t * 1.5).rgb) * 0.5;
    s /= 12.0;
    float k = smoothstep(0.15, 0.6, m) * 0.35; // only clear edges are smoothed: texture stays crisp
    vec3 r = mix(c, s, k);
    outColor = vec4(r, 1.0);
}
"""

    /** Own upscaler (CRSC): edge-directed Lanczos (6x6 taps stretched along the local edge direction, found with a structure tensor)
     *  with an anti-ringing clamp; then edge smoothing + steepening, then RCAS. */
    const val LANCZOS = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform ivec2 uSrcSize;
in highp vec2 vUv;
out vec4 outColor;
float lumf(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
float lz(float x) {
    x = abs(x);
    if (x < 1e-4) return 1.0;
    if (x >= 3.0) return 0.0;
    float px = 3.14159265 * x;
    return 3.0 * sin(px) * sin(px / 3.0) / (px * px);
}
void main() {
    vec2 sz = vec2(uSrcSize);
    vec2 pos = vUv * sz - 0.5;
    vec2 b = floor(pos);
    vec2 f = pos - b;
    ivec2 mx = uSrcSize - 1;
    ivec2 c0 = ivec2(b);
    // luma of the 6x6 window around the sample point
    float L[36];
    for (int j = 0; j < 6; j++) {
        for (int i = 0; i < 6; i++) {
            ivec2 p = clamp(c0 + ivec2(i - 2, j - 2), ivec2(0), mx);
            L[j * 6 + i] = lumf(texelFetch(uSrc, p, 0).rgb);
        }
    }
    // structure tensor of the 4x4 pixels in the middle: which way do the edges run, and how clear are they
    float gxx = 0.0;
    float gyy = 0.0;
    float gxy = 0.0;
    for (int j = 1; j < 5; j++) {
        for (int i = 1; i < 5; i++) {
            float gx = (L[j * 6 + i + 1] - L[j * 6 + i - 1]) * 0.5;
            float gy = (L[(j + 1) * 6 + i] - L[(j - 1) * 6 + i]) * 0.5;
            vec2 d = vec2(float(i - 2), float(j - 2)) - f;
            float w = exp(-dot(d, d) * 0.55);
            gxx += w * gx * gx;
            gyy += w * gy * gy;
            gxy += w * gx * gy;
        }
    }
    float tr = gxx + gyy;
    float disc = sqrt(max((gxx - gyy) * (gxx - gyy) + 4.0 * gxy * gxy, 0.0));
    float l1 = 0.5 * (tr + disc);
    float l2 = 0.5 * (tr - disc);
    float coh = (l1 - l2) / (l1 + l2 + 1e-6) * smoothstep(0.0004, 0.01, l1);
    float ang = 0.5 * atan(2.0 * gxy, gxx - gyy + 1e-7);
    vec2 n = vec2(cos(ang), sin(ang));   // across the edge
    vec2 t = vec2(-n.y, n.x);            // along the edge
    float ka = 1.0 + 1.1 * coh;          // narrower across the edge (sharper), wider along it (smoother)
    float kl = 1.0 / (1.0 + 0.45 * coh);
    vec3 acc = vec3(0.0);
    float ws = 0.0;
    for (int j = 0; j < 6; j++) {
        for (int i = 0; i < 6; i++) {
            vec2 d = vec2(float(i - 2), float(j - 2)) - f;
            float u = dot(d, n) * ka;
            float v = dot(d, t) * kl;
            float w = lz(sqrt(u * u + v * v));
            ivec2 p = clamp(c0 + ivec2(i - 2, j - 2), ivec2(0), mx);
            acc += texelFetch(uSrc, p, 0).rgb * w;
            ws += w;
        }
    }
    acc /= max(ws, 1e-4);
    // anti-ringing: stay inside the range of the 4 nearest source pixels
    vec3 a0 = texelFetch(uSrc, clamp(c0, ivec2(0), mx), 0).rgb;
    vec3 a1 = texelFetch(uSrc, clamp(c0 + ivec2(1, 0), ivec2(0), mx), 0).rgb;
    vec3 a2 = texelFetch(uSrc, clamp(c0 + ivec2(0, 1), ivec2(0), mx), 0).rgb;
    vec3 a3 = texelFetch(uSrc, clamp(c0 + ivec2(1, 1), ivec2(0), mx), 0).rgb;
    vec3 lo = min(min(a0, a1), min(a2, a3));
    vec3 hi = max(max(a0, a1), max(a2, a3));
    outColor = vec4(clamp(acc, lo - 0.015, hi + 0.015), 1.0);
}
"""

    /** CRSC finishing sharpen: an unsharp mask whose radius follows the enlargement factor (an enlarged picture is blurred
     *  over about that many pixels, which RCAS's fixed 1-pixel reach cannot undo). It works on mid-contrast detail,
     *  leaves flat areas (noise) and already strong edges (halos) alone, and never overshoots the local range. */
    const val CRSC_SHARP = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform vec2 uInv;
uniform float uR;
uniform float uAmt;
in highp vec2 vUv;
out vec4 outColor;
float lum(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
void main() {
    vec3 c = texture(uSrc, vUv).rgb;
    vec2 r = uInv * uR;
    vec3 n = texture(uSrc, vUv + vec2(0.0, -1.0) * r).rgb;
    vec3 s = texture(uSrc, vUv + vec2(0.0, 1.0) * r).rgb;
    vec3 w = texture(uSrc, vUv + vec2(-1.0, 0.0) * r).rgb;
    vec3 e = texture(uSrc, vUv + vec2(1.0, 0.0) * r).rgb;
    vec3 nw = texture(uSrc, vUv + vec2(-1.0, -1.0) * r).rgb;
    vec3 ne = texture(uSrc, vUv + vec2(1.0, -1.0) * r).rgb;
    vec3 sw = texture(uSrc, vUv + vec2(-1.0, 1.0) * r).rgb;
    vec3 se = texture(uSrc, vUv + vec2(1.0, 1.0) * r).rgb;
    vec3 blur = (c * 4.0 + (n + s + w + e) * 2.0 + nw + ne + sw + se) / 16.0;
    float d = lum(c) - lum(blur);
    float a = abs(d);
    float gain = uAmt * smoothstep(0.008, 0.05, a) * (1.0 - smoothstep(0.22, 0.5, a));
    vec3 o = c + (c - blur) * gain;
    vec3 lo = min(min(min(n, s), min(w, e)), c);
    vec3 hi = max(max(max(n, s), max(w, e)), c);
    outColor = vec4(clamp(o, lo - 0.02, hi + 0.02), 1.0);
}
"""

    /** CRSC back-projection: shrink the big picture back to the source size. */
    const val CRSC_DOWN = """#version 300 es
precision highp float;
uniform sampler2D uSrc;uniform vec2 uInv; // uInv = 1/low size
in highp vec2 vUv;out vec4 outColor;
void main(){vec2 o=uInv*0.25;
vec3 s=texture(uSrc,vUv+vec2(-o.x,-o.y)).rgb+texture(uSrc,vUv+vec2(o.x,-o.y)).rgb+texture(uSrc,vUv+vec2(-o.x,o.y)).rgb+texture(uSrc,vUv+vec2(o.x,o.y)).rgb;
outColor=vec4(s*0.25,1.0);}
"""

    /** CRSC back-projection: add (source - shrunk picture) back, limited to the source's local range (no ringing). */
    const val CRSC_BP = """#version 300 es
precision highp float;
uniform sampler2D uSrc;uniform sampler2D uLow;uniform sampler2D uD;uniform vec2 uInv;uniform float uG;
in highp vec2 vUv;out vec4 outColor;
void main(){vec3 u=texture(uSrc,vUv).rgb;
vec3 e=texture(uLow,vUv).rgb-texture(uD,vUv).rgb;
// local range of the low-res picture: the result may not leave it by much (no ringing)
vec3 lo=vec3(1.0),hi=vec3(0.0);
for(int j=-1;j<=1;j++)for(int i=-1;i<=1;i++){vec3 v=texture(uLow,vUv+vec2(float(i),float(j))*uInv).rgb;lo=min(lo,v);hi=max(hi,v);}
vec3 r=u+e*uG;
outColor=vec4(clamp(r,lo-0.04,hi+0.04),1.0);}
"""
}
