package app.clearoverlay

/*
 * GLSL ES 3.0 shaders.
 *
 *  - EASU / RCAS : AMD FidelityFX Super Resolution 1 (MIT License, Copyright (c) 2021 Advanced Micro Devices, Inc.)
 *  - SGSR1       : Snapdragon Game Super Resolution v1 (BSD-3-Clause, Copyright (c) 2023 Qualcomm Innovation Center, Inc.)
 *                  https://github.com/SnapdragonStudios/snapdragon-gsr
 *
 * The GLSL ES ports below were taken from the Nebula APK supplied with this project
 * (textureGather is emulated with texelFetch, so no ES 3.1 features are needed).
 * See licenses/ for the license texts.
 */
object Shaders {
    const val VERT = """#version 300 es
out highp vec2 vUv;
void main() {
    vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
    vUv = p;
    gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
}
"""

    const val OES_COPY = """#version 300 es
#extension GL_OES_EGL_image_external_essl3 : require
precision highp float;
uniform samplerExternalOES uSrc;
uniform mat4 uTexMatrix;
// Crop window inside the frame (x, y offset and x, y size, all 0..1): 1:1 pixels when zooming in the player.
uniform vec4 uCrop;
in highp vec2 vUv;
out vec4 outColor;
void main() {
    vec2 uv = (uTexMatrix * vec4(vUv * uCrop.zw + uCrop.xy, 0.0, 1.0)).xy;
    outColor = vec4(texture(uSrc, uv).rgb, 1.0);
}
"""

    const val RCAS = """#version 300 es

precision highp float;
precision highp int;
// Source size comes from a uniform: textureSize() returned 1x1 on the emulator's GLES translator.
uniform ivec2 uSrcSize;
vec4 fetchC(sampler2D t, ivec2 p) {
    return texelFetch(t, clamp(p, ivec2(0), uSrcSize - ivec2(1)), 0);
}
// textureGather emulation: the 2x2 footprint a bilinear sample at uv p would use.
void gather4(sampler2D t, vec2 p, out vec4 x, out vec4 y, out vec4 z, out vec4 w) {
    vec2 q = p * vec2(uSrcSize) - 0.5;
    ivec2 i0 = ivec2(floor(q));
    ivec2 i1 = i0 + ivec2(1);
    x = fetchC(t, ivec2(i0.x, i1.y));
    y = fetchC(t, ivec2(i1.x, i1.y));
    z = fetchC(t, ivec2(i1.x, i0.y));
    w = fetchC(t, ivec2(i0.x, i0.y));
}
float aRcpLo(float a) { return uintBitsToFloat(uint(0x7ef07ebb) - floatBitsToUint(a)); }
float aRsqLo(float a) { return uintBitsToFloat(uint(0x5f347d74) - (floatBitsToUint(a) >> uint(1))); }
float aRcpMed(float a) { float b = uintBitsToFloat(uint(0x7ef19fff) - floatBitsToUint(a)); return b * (-b * a + 2.0); }
float sat(float a) { return clamp(a, 0.0, 1.0); }
float min3(float a, float b, float c) { return min(a, min(b, c)); }
float max3(float a, float b, float c) { return max(a, max(b, c)); }
vec3 min3v(vec3 a, vec3 b, vec3 c) { return min(a, min(b, c)); }
vec3 max3v(vec3 a, vec3 b, vec3 c) { return max(a, max(b, c)); }

uniform sampler2D uSrc;
uniform float uSharpness;
uniform float uProtect; // "Protect noise": 0 = stock RCAS
out vec4 outColor;
#define FSR_RCAS_LIMIT (0.25 - (1.0 / 16.0))
void main() {
    ivec2 sp = ivec2(floor(gl_FragCoord.xy));
    vec3 b = fetchC(uSrc, sp + ivec2(0, -1)).rgb;
    vec3 d = fetchC(uSrc, sp + ivec2(-1, 0)).rgb;
    vec3 e = fetchC(uSrc, sp).rgb;
    vec3 f = fetchC(uSrc, sp + ivec2(1, 0)).rgb;
    vec3 h = fetchC(uSrc, sp + ivec2(0, 1)).rgb;
    vec3 mn4 = min(min3v(b, d, f), h);
    vec3 mx4 = max(max3v(b, d, f), h);
    vec2 peakC = vec2(1.0, -4.0);
    // Denominators kept off zero: flat white or black areas would give 0/0, which GPUs treat
    // differently (AMD's HLSL relies on max() dropping NaN).
    vec3 hitMin = min(mn4, e) / max(4.0 * mx4, vec3(1.0 / 65536.0));
    vec3 hitMax = (peakC.x - max(mx4, e)) / min(4.0 * mn4 + peakC.y, vec3(-1.0 / 65536.0));
    vec3 lobeRGB = max(-hitMin, hitMax);
    float lobe = max(-FSR_RCAS_LIMIT, min(max3(lobeRGB.r, lobeRGB.g, lobeRGB.b), 0.0)) * uSharpness;
    // Protect noise (the idea of AMD's optional RCAS denoise): a pixel that differs from the average of its four neighbours WITHOUT a real
    // edge around it is noise; it is sharpened less, so the sharpening does not make compression noise crawl. Thin lines lose a little too.
    if (uProtect > 0.0) {
        vec3 lw = vec3(0.299, 0.587, 0.114);
        float bL = dot(b, lw);
        float dL = dot(d, lw);
        float eL = dot(e, lw);
        float fL = dot(f, lw);
        float hL = dot(h, lw);
        float rng = max(max(max(bL, dL), max(eL, fL)), hL) - min(min(min(bL, dL), min(eL, fL)), hL);
        float nz = clamp(abs(0.25 * (bL + dL + fL + hL) - eL) / max(rng, 1.0 / 256.0), 0.0, 1.0);
        lobe *= 1.0 - 0.95 * uProtect * clamp(nz * 1.6, 0.0, 1.0);
    }
    float rcpL = aRcpMed(4.0 * lobe + 1.0);
    vec3 pix = (lobe * b + lobe * d + lobe * h + lobe * f + e) * rcpL;
    outColor = vec4(clamp(pix, 0.0, 1.0), 1.0);
}
"""

    const val SGSR1 = """#version 300 es

precision highp float;
precision highp int;
// Source size comes from a uniform: textureSize() returned 1x1 on the emulator's GLES translator.
uniform ivec2 uSrcSize;
vec4 fetchC(sampler2D t, ivec2 p) {
    return texelFetch(t, clamp(p, ivec2(0), uSrcSize - ivec2(1)), 0);
}
// textureGather emulation: the 2x2 footprint a bilinear sample at uv p would use.
void gather4(sampler2D t, vec2 p, out vec4 x, out vec4 y, out vec4 z, out vec4 w) {
    vec2 q = p * vec2(uSrcSize) - 0.5;
    ivec2 i0 = ivec2(floor(q));
    ivec2 i1 = i0 + ivec2(1);
    x = fetchC(t, ivec2(i0.x, i1.y));
    y = fetchC(t, ivec2(i1.x, i1.y));
    z = fetchC(t, ivec2(i1.x, i0.y));
    w = fetchC(t, ivec2(i0.x, i0.y));
}
float aRcpLo(float a) { return uintBitsToFloat(uint(0x7ef07ebb) - floatBitsToUint(a)); }
float aRsqLo(float a) { return uintBitsToFloat(uint(0x5f347d74) - (floatBitsToUint(a) >> uint(1))); }
float aRcpMed(float a) { float b = uintBitsToFloat(uint(0x7ef19fff) - floatBitsToUint(a)); return b * (-b * a + 2.0); }
float sat(float a) { return clamp(a, 0.0, 1.0); }
float min3(float a, float b, float c) { return min(a, min(b, c)); }
float max3(float a, float b, float c) { return max(a, max(b, c)); }
vec3 min3v(vec3 a, vec3 b, vec3 c) { return min(a, min(b, c)); }
vec3 max3v(vec3 a, vec3 b, vec3 c) { return max(a, max(b, c)); }

uniform sampler2D uSrc;
uniform highp vec4 uViewportInfo;
uniform float uEdgeSharpness;
in highp vec2 vUv;
out vec4 outColor;

float fastLanczos2(float x) {
    float wA = x - 4.0;
    float wB = x * wA - wA;
    wA *= wA;
    return wB * wA;
}
vec2 weightY(float dx, float dy, float c, float stdv) {
    float x = ((dx * dx) + (dy * dy)) * 0.55 + clamp(abs(c) * stdv, 0.0, 1.0);
    float w = fastLanczos2(x);
    return vec2(w, w * c);
}
vec4 gatherG(vec2 p) {
    vec4 x, y, z, w;
    gather4(uSrc, p, x, y, z, w);
    return vec4(x.g, y.g, z.g, w.g);
}
void main() {
    const float edgeThreshold = 8.0 / 255.0;
    vec4 color;
    color.xyz = textureLod(uSrc, vUv, 0.0).xyz;
    highp vec2 imgCoord = (vUv * uViewportInfo.zw) + vec2(-0.5, 0.5);
    highp vec2 imgCoordPixel = floor(imgCoord);
    highp vec2 coord = imgCoordPixel * uViewportInfo.xy;
    vec2 pl = imgCoord - imgCoordPixel;
    vec4 left = gatherG(coord);
    float edgeVote = abs(left.z - left.y) + abs(color.g - left.y) + abs(color.g - left.z);
    if (edgeVote > edgeThreshold) {
        coord.x += uViewportInfo.x;
        vec4 right = gatherG(coord + vec2(uViewportInfo.x, 0.0));
        vec4 upDown;
        upDown.xy = gatherG(coord + vec2(0.0, -uViewportInfo.y)).wz;
        upDown.zw = gatherG(coord + vec2(0.0, uViewportInfo.y)).yx;
        float mean = (left.y + left.z + right.x + right.w) * 0.25;
        left -= vec4(mean);
        right -= vec4(mean);
        upDown -= vec4(mean);
        color.w = color.g - mean;
        float sum = abs(left.x) + abs(left.y) + abs(left.z) + abs(left.w)
                  + abs(right.x) + abs(right.y) + abs(right.z) + abs(right.w)
                  + abs(upDown.x) + abs(upDown.y) + abs(upDown.z) + abs(upDown.w);
        float stdv = 2.181818 / sum;
        vec2 aWY = weightY(pl.x, pl.y + 1.0, upDown.x, stdv);
        aWY += weightY(pl.x - 1.0, pl.y + 1.0, upDown.y, stdv);
        aWY += weightY(pl.x - 1.0, pl.y - 2.0, upDown.z, stdv);
        aWY += weightY(pl.x, pl.y - 2.0, upDown.w, stdv);
        aWY += weightY(pl.x + 1.0, pl.y - 1.0, left.x, stdv);
        aWY += weightY(pl.x, pl.y - 1.0, left.y, stdv);
        aWY += weightY(pl.x, pl.y, left.z, stdv);
        aWY += weightY(pl.x + 1.0, pl.y, left.w, stdv);
        aWY += weightY(pl.x - 1.0, pl.y - 1.0, right.x, stdv);
        aWY += weightY(pl.x - 2.0, pl.y - 1.0, right.y, stdv);
        aWY += weightY(pl.x - 2.0, pl.y, right.z, stdv);
        aWY += weightY(pl.x - 1.0, pl.y, right.w, stdv);
        float finalY = aWY.y / aWY.x;
        float maxY = max(max(left.y, left.z), max(right.x, right.w));
        float minY = min(min(left.y, left.z), min(right.x, right.w));
        finalY = clamp(uEdgeSharpness * finalY, minY, maxY);
        float deltaY = clamp(finalY - color.w, -23.0 / 255.0, 23.0 / 255.0);
        color.xyz = clamp(color.xyz + deltaY, 0.0, 1.0);
    }
    outColor = vec4(color.xyz, 1.0);
}
"""

    /** Plain hardware-filtered upscale: zero extra math, relies on GL_LINEAR on the source texture.
     *  Used by "Fast" mode for GPUs too weak to afford EASU/SGSR1. */
    const val BILINEAR = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
in highp vec2 vUv;
out vec4 outColor;
void main() {
    outColor = vec4(texture(uSrc, vUv).rgb, 1.0);
}
"""

    /** Sharp bicubic (Catmull-Rom, 9 hardware-bilinear taps) with an anti-ringing clamp to the 4 nearest source pixels.
     *  The enlarger of Sharpen mode when a chosen output size makes it upscale (Fast stays plain bilinear). uSrcSize = source size in pixels. */
    const val BICUBIC = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform vec2 uSrcSize;
in highp vec2 vUv;
out vec4 outColor;
vec3 s(vec2 p) { return texture(uSrc, p / uSrcSize).rgb; }
void main() {
    vec2 pos = vUv * uSrcSize;
    vec2 tc = floor(pos - 0.5) + 0.5;
    vec2 f = pos - tc;
    vec2 w0 = f * (-0.5 + f * (1.0 - 0.5 * f));
    vec2 w1 = 1.0 + f * f * (-2.5 + 1.5 * f);
    vec2 w2 = f * (0.5 + f * (2.0 - 1.5 * f));
    vec2 w3 = f * f * (-0.5 + 0.5 * f);
    vec2 w12 = w1 + w2;
    vec2 t0 = tc - 1.0;
    vec2 t3 = tc + 2.0;
    vec2 t12 = tc + w2 / w12;
    vec3 c = s(vec2(t0.x, t0.y)) * (w0.x * w0.y) + s(vec2(t12.x, t0.y)) * (w12.x * w0.y) + s(vec2(t3.x, t0.y)) * (w3.x * w0.y)
           + s(vec2(t0.x, t12.y)) * (w0.x * w12.y) + s(vec2(t12.x, t12.y)) * (w12.x * w12.y) + s(vec2(t3.x, t12.y)) * (w3.x * w12.y)
           + s(vec2(t0.x, t3.y)) * (w0.x * w3.y) + s(vec2(t12.x, t3.y)) * (w12.x * w3.y) + s(vec2(t3.x, t3.y)) * (w3.x * w3.y);
    vec3 a = s(tc);
    vec3 b = s(tc + vec2(1.0, 0.0));
    vec3 d = s(tc + vec2(0.0, 1.0));
    vec3 e = s(tc + vec2(1.0, 1.0));
    vec3 lo = min(min(a, b), min(d, e));
    vec3 hi = max(max(a, b), max(d, e));
    outColor = vec4(clamp(c, lo - 0.03, hi + 0.03), 1.0);
}
"""

    /** Supersampling downscale: 4 hardware-bilinear taps at +-1/4 output pixel, averaged.
     *  Used when the render scale is above 100% to shrink the sharpened big frame back to the panel size.
     *  uStep = 0.25 / output size, in uv units. */
    const val DOWNSCALE = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform vec2 uStep;
in highp vec2 vUv;
out vec4 outColor;
void main() {
    vec3 c = texture(uSrc, vUv + vec2(-uStep.x, -uStep.y)).rgb
           + texture(uSrc, vUv + vec2( uStep.x, -uStep.y)).rgb
           + texture(uSrc, vUv + vec2(-uStep.x,  uStep.y)).rgb
           + texture(uSrc, vUv + vec2( uStep.x,  uStep.y)).rgb;
    outColor = vec4(c * 0.25, 1.0);
}
"""

    /** Saturation + mild contrast lift ("Vivid colors"), in the spirit of MX Player's enhance filter.
     *  uVivid is 0..1; 0 leaves the image untouched. */
    const val COLOR_ENHANCE = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform float uVivid;
uniform float uContrast;
uniform vec3 uFixGain;   // Smart fix: per-channel gain (white balance)
uniform vec3 uFixLvl;    // Smart fix: x = black point, y = 1 / (white - black), z = gamma; (0, 1, 1) = off
uniform float uFixSat;   // Smart fix: lift of weak colours for a dull picture (0 = off)
uniform vec4 uTone;      // x = shadows, y = highlights, z = saturation (-1..1), w = warmth (-1..1)
uniform vec2 uGrain;     // x = grain amount 0..1, y = per-frame seed
uniform vec2 uVF;        // x = vignette -1..1 (+ darker corners), y = fade 0..1 (matte blacks)
uniform vec3 uTone2;     // x = brightness (-1..1), y = vibrance (-1..1), z = tint (-1 green .. +1 magenta)
uniform float uRestore;  // Clean upscale: colour restore 0..1 (0 = off)
in highp vec2 vUv;
out vec4 outColor;
void main() {
    vec3 c = texture(uSrc, vUv).rgb;
    if (uRestore > 0.0) {
        // low-resolution / compressed pictures look hazy and a little grey. Everything here works on the brightness and ADDS the change to
        // all three channels, so no hue shifts and the blacks are never crushed: a soft black end (only the haze is removed), a gentle S-curve
        // around the mid-tones, then a vibrance-style colour lift (weak colours most; skin tones and strong colours are touched much less)
        float ry = dot(c, vec3(0.299, 0.587, 0.114));
        float ry2 = clamp((ry - 0.022 * uRestore) / (1.0 - 0.022 * uRestore), 0.0, 1.0);
        ry2 = mix(ry2, ry2 * ry2 * (3.0 - 2.0 * ry2), 0.12 * uRestore);
        c = clamp(c + (ry2 - ry), 0.0, 1.0);
        float rl = dot(c, vec3(0.299, 0.587, 0.114));
        float rs = clamp(max(c.r, max(c.g, c.b)) - min(c.r, min(c.g, c.b)), 0.0, 1.0);
        float skin = (c.r > c.g && c.g > c.b && rs < 0.55) ? 0.45 : 1.0;
        float lift = 0.26 * uRestore * (1.0 - smoothstep(0.0, 0.6, rs)) * skin;
        c = clamp(mix(vec3(rl), c, 1.0 + lift), 0.0, 1.0);
    }
    c = clamp((c * uFixGain - uFixLvl.x) * uFixLvl.y, 0.0, 1.0);
    {
        // gamma; when it LIFTS a dark picture (< 1) the bright end is kept, so highlights are not washed out
        vec3 gm = pow(c, vec3(uFixLvl.z));
        c = (uFixLvl.z < 1.0) ? mix(gm, c, smoothstep(vec3(0.55), vec3(1.0), c)) : gm;
        if (uFixSat > 0.0) {
            float fl = dot(c, vec3(0.299, 0.587, 0.114));
            float fs = clamp(max(c.r, max(c.g, c.b)) - min(c.r, min(c.g, c.b)), 0.0, 1.0);
            c = clamp(mix(vec3(fl), c, 1.0 + uFixSat * (1.0 - fs)), 0.0, 1.0);
        }
    }
    float luma = dot(c, vec3(0.299, 0.587, 0.114));
    vec3 sat = mix(vec3(luma), c, 1.0 + uVivid * 0.6);
    vec3 cst = (sat - 0.5) * (1.0 + uVivid * 0.15) * (1.0 + uContrast * 0.7) + 0.5;
    float l = clamp(dot(cst, vec3(0.299, 0.587, 0.114)), 0.0, 1.0);
    // shadows: lift (+) or crush (-) the dark end; highlights: boost (+) or pull back (-) the bright end
    float sw = (1.0 - l) * (1.0 - l);
    float hw = l * l;
    cst += uTone.x * 0.30 * sw * (1.0 - l) + uTone.y * 0.25 * hw * l;
    // independent saturation (does not touch contrast)
    float l2 = dot(cst, vec3(0.299, 0.587, 0.114));
    cst = mix(vec3(l2), cst, 1.0 + uTone.z);
    // vibrance: like saturation, but the colours that are already strong are changed less (skin and sky do not turn orange / neon)
    if (uTone2.y != 0.0) {
        float vmx = max(cst.r, max(cst.g, cst.b));
        float vmn = min(cst.r, min(cst.g, cst.b));
        float vs = clamp(vmx - vmn, 0.0, 1.0);
        float vl = dot(cst, vec3(0.299, 0.587, 0.114));
        cst = mix(vec3(vl), cst, 1.0 + uTone2.y * (1.0 - vs));
    }
    // warmth: + warm (less blue), - cool; green nudged so the grey axis stays neutral
    cst *= vec3(1.0 + 0.12 * uTone.w, 1.0 + 0.015 * uTone.w, 1.0 - 0.18 * uTone.w);
    // tint: + magenta (less green), - green
    cst *= vec3(1.0 + 0.04 * uTone2.z, 1.0 - 0.10 * uTone2.z, 1.0 + 0.04 * uTone2.z);
    // brightness: a plain lift / drop of the whole picture (mid-tones most, the ends half as much)
    cst += uTone2.x * 0.30 * (1.0 - abs(2.0 * clamp(l, 0.0, 1.0) - 1.0) * 0.5);
    // fade: matte, lifted blacks (the dark end is raised, the picture keeps its white)
    if (uVF.y > 0.0) {
        float fl = 0.14 * uVF.y;
        cst = cst * (1.0 - fl) + fl;
    }
    // vignette: + darkens the corners (smooth from about a third of the way out), - lightens them
    if (uVF.x != 0.0) {
        vec2 vq = (vUv - 0.5) * vec2(1.0, 0.85);
        float vr = smoothstep(0.30, 0.95, length(vq) * 1.414);
        if (uVF.x > 0.0) cst *= 1.0 - 0.6 * uVF.x * vr;
        else cst += (-uVF.x) * 0.30 * vr * (1.0 - cst);
    }
    // film grain: luminance noise, strongest in the mid-tones
    if (uGrain.x > 0.0) {
        vec2 q = gl_FragCoord.xy + vec2(uGrain.y * 37.0, uGrain.y * 17.0);
        float n = fract(sin(dot(q, vec2(12.9898, 78.233))) * 43758.5453) - 0.5;
        float m = 1.0 - abs(l - 0.5) * 1.4;
        cst += n * uGrain.x * 0.14 * clamp(m, 0.15, 1.0);
    }
    outColor = vec4(clamp(cst, 0.0, 1.0), 1.0);
}
"""

    const val EASU = """#version 300 es

precision highp float;
precision highp int;
// Source size comes from a uniform: textureSize() returned 1x1 on the emulator's GLES translator.
uniform ivec2 uSrcSize;
vec4 fetchC(sampler2D t, ivec2 p) {
    return texelFetch(t, clamp(p, ivec2(0), uSrcSize - ivec2(1)), 0);
}
// textureGather emulation: the 2x2 footprint a bilinear sample at uv p would use.
void gather4(sampler2D t, vec2 p, out vec4 x, out vec4 y, out vec4 z, out vec4 w) {
    vec2 q = p * vec2(uSrcSize) - 0.5;
    ivec2 i0 = ivec2(floor(q));
    ivec2 i1 = i0 + ivec2(1);
    x = fetchC(t, ivec2(i0.x, i1.y));
    y = fetchC(t, ivec2(i1.x, i1.y));
    z = fetchC(t, ivec2(i1.x, i0.y));
    w = fetchC(t, ivec2(i0.x, i0.y));
}
float aRcpLo(float a) { return uintBitsToFloat(uint(0x7ef07ebb) - floatBitsToUint(a)); }
float aRsqLo(float a) { return uintBitsToFloat(uint(0x5f347d74) - (floatBitsToUint(a) >> uint(1))); }
float aRcpMed(float a) { float b = uintBitsToFloat(uint(0x7ef19fff) - floatBitsToUint(a)); return b * (-b * a + 2.0); }
float sat(float a) { return clamp(a, 0.0, 1.0); }
float min3(float a, float b, float c) { return min(a, min(b, c)); }
float max3(float a, float b, float c) { return max(a, max(b, c)); }
vec3 min3v(vec3 a, vec3 b, vec3 c) { return min(a, min(b, c)); }
vec3 max3v(vec3 a, vec3 b, vec3 c) { return max(a, max(b, c)); }

uniform sampler2D uSrc;
uniform vec4 uCon0;
uniform vec4 uCon1;
uniform vec4 uCon2;
uniform vec4 uCon3;
out vec4 outColor;

void tap(inout vec3 aC, inout float aW, vec2 off, vec2 dir, vec2 len, float lob, float clp, vec3 c) {
    vec2 v;
    v.x = (off.x * dir.x) + (off.y * dir.y);
    v.y = (off.x * (-dir.y)) + (off.y * dir.x);
    v *= len;
    float d2 = min(v.x * v.x + v.y * v.y, clp);
    float wB = (2.0 / 5.0) * d2 - 1.0;
    float wA = lob * d2 - 1.0;
    wB *= wB;
    wA *= wA;
    wB = (25.0 / 16.0) * wB - (25.0 / 16.0 - 1.0);
    float w = wB * wA;
    aC += c * w;
    aW += w;
}

void setDir(inout vec2 dir, inout float len, vec2 pp, int corner, float lA, float lB, float lC, float lD, float lE) {
    float w = 0.0;
    if (corner == 0) w = (1.0 - pp.x) * (1.0 - pp.y);
    if (corner == 1) w = pp.x * (1.0 - pp.y);
    if (corner == 2) w = (1.0 - pp.x) * pp.y;
    if (corner == 3) w = pp.x * pp.y;
    float dc = lD - lC;
    float cb = lC - lB;
    float lenX = aRcpLo(max(abs(dc), abs(cb)));
    float dirX = lD - lB;
    dir.x += dirX * w;
    lenX = sat(abs(dirX) * lenX);
    len += lenX * lenX * w;
    float ec = lE - lC;
    float ca = lC - lA;
    float lenY = aRcpLo(max(abs(ec), abs(ca)));
    float dirY = lE - lA;
    dir.y += dirY * w;
    lenY = sat(abs(dirY) * lenY);
    len += lenY * lenY * w;
}

void main() {
    vec2 ip = floor(gl_FragCoord.xy);
    vec2 pp = ip * uCon0.xy + uCon0.zw;
    vec2 fp = floor(pp);
    pp -= fp;
    vec2 p0 = fp * uCon1.xy + uCon1.zw;
    vec2 p1 = p0 + uCon2.xy;
    vec2 p2 = p0 + uCon2.zw;
    vec2 p3 = p0 + uCon3.xy;
    vec4 b0, b1, b2, b3; gather4(uSrc, p0, b0, b1, b2, b3); // b c z z  (x y z w)
    vec4 i0, i1, i2, i3; gather4(uSrc, p1, i0, i1, i2, i3); // i j f e
    vec4 k0, k1, k2, k3; gather4(uSrc, p2, k0, k1, k2, k3); // k l h g
    vec4 z0, z1, z2, z3; gather4(uSrc, p3, z0, z1, z2, z3); // z z o n
    vec3 b = b0.rgb, c = b1.rgb;
    vec3 i = i0.rgb, j = i1.rgb, f = i2.rgb, e = i3.rgb;
    vec3 k = k0.rgb, l = k1.rgb, h = k2.rgb, g = k3.rgb;
    vec3 o = z2.rgb, n = z3.rgb;
    // Luma times 2.
    #define L(v) (v.b * 0.5 + (v.r * 0.5 + v.g))
    float bL = L(b), cL = L(c), iL = L(i), jL = L(j), fL = L(f), eL = L(e);
    float kL = L(k), lL = L(l), hL = L(h), gL = L(g), oL = L(o), nL = L(n);
    vec2 dir = vec2(0.0);
    float len = 0.0;
    setDir(dir, len, pp, 0, bL, eL, fL, gL, jL);
    setDir(dir, len, pp, 1, cL, fL, gL, hL, kL);
    setDir(dir, len, pp, 2, fL, iL, jL, kL, nL);
    setDir(dir, len, pp, 3, gL, jL, kL, lL, oL);
    vec2 dir2 = dir * dir;
    float dirR = dir2.x + dir2.y;
    bool zro = dirR < (1.0 / 32768.0);
    dirR = aRsqLo(dirR);
    dirR = zro ? 1.0 : dirR;
    dir.x = zro ? 1.0 : dir.x;
    dir *= vec2(dirR);
    len = len * 0.5;
    len *= len;
    float stretch = (dir.x * dir.x + dir.y * dir.y) * aRcpLo(max(abs(dir.x), abs(dir.y)));
    vec2 len2 = vec2(1.0 + (stretch - 1.0) * len, 1.0 - 0.5 * len);
    float lob = 0.5 + ((1.0 / 4.0 - 0.04) - 0.5) * len;
    float clp = aRcpLo(lob);
    vec3 min4 = min(min3v(f, g, j), k);
    vec3 max4 = max(max3v(f, g, j), k);
    vec3 aC = vec3(0.0);
    float aW = 0.0;
    tap(aC, aW, vec2( 0.0, -1.0) - pp, dir, len2, lob, clp, b);
    tap(aC, aW, vec2( 1.0, -1.0) - pp, dir, len2, lob, clp, c);
    tap(aC, aW, vec2(-1.0,  1.0) - pp, dir, len2, lob, clp, i);
    tap(aC, aW, vec2( 0.0,  1.0) - pp, dir, len2, lob, clp, j);
    tap(aC, aW, vec2( 0.0,  0.0) - pp, dir, len2, lob, clp, f);
    tap(aC, aW, vec2(-1.0,  0.0) - pp, dir, len2, lob, clp, e);
    tap(aC, aW, vec2( 1.0,  1.0) - pp, dir, len2, lob, clp, k);
    tap(aC, aW, vec2( 2.0,  1.0) - pp, dir, len2, lob, clp, l);
    tap(aC, aW, vec2( 2.0,  0.0) - pp, dir, len2, lob, clp, h);
    tap(aC, aW, vec2( 1.0,  0.0) - pp, dir, len2, lob, clp, g);
    tap(aC, aW, vec2( 1.0,  2.0) - pp, dir, len2, lob, clp, o);
    tap(aC, aW, vec2( 0.0,  2.0) - pp, dir, len2, lob, clp, n);
    vec3 pix = min(max4, max(min4, aC * (1.0 / aW)));
    outColor = vec4(max(pix, vec3(0.0)), 1.0);
}
"""

    /** FXAA "Fast": Lottes' compact 5-tap FXAA (console-style). Very cheap, mild smoothing.
     *  uInv = 1 / source size, uAmt = 0..1 blend with the original pixel. */
    const val FXAA_FAST = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform vec2 uInv;
uniform float uAmt;
in highp vec2 vUv;
out vec4 outColor;
float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
void main() {
    vec3 rgbM = texture(uSrc, vUv).rgb;
    vec3 rgbNW = textureOffset(uSrc, vUv, ivec2(-1,  1)).rgb;
    vec3 rgbNE = textureOffset(uSrc, vUv, ivec2( 1,  1)).rgb;
    vec3 rgbSW = textureOffset(uSrc, vUv, ivec2(-1, -1)).rgb;
    vec3 rgbSE = textureOffset(uSrc, vUv, ivec2( 1, -1)).rgb;
    float lM = luma(rgbM), lNW = luma(rgbNW), lNE = luma(rgbNE), lSW = luma(rgbSW), lSE = luma(rgbSE);
    float lMin = min(lM, min(min(lNW, lNE), min(lSW, lSE)));
    float lMax = max(lM, max(max(lNW, lNE), max(lSW, lSE)));
    vec2 dir;
    dir.x = -((lNW + lNE) - (lSW + lSE));
    dir.y =  ((lNE + lSE) - (lNW + lSW));
    float dirReduce = max((lNW + lNE + lSW + lSE) * (0.25 * (1.0 / 8.0)), 1.0 / 128.0);
    float rcpDirMin = 1.0 / (min(abs(dir.x), abs(dir.y)) + dirReduce);
    dir = clamp(dir * rcpDirMin, vec2(-8.0), vec2(8.0)) * uInv;
    vec3 rgbA = 0.5 * (texture(uSrc, vUv + dir * (1.0 / 3.0 - 0.5)).rgb
                     + texture(uSrc, vUv + dir * (2.0 / 3.0 - 0.5)).rgb);
    vec3 rgbB = rgbA * 0.5 + 0.25 * (texture(uSrc, vUv + dir * -0.5).rgb
                                   + texture(uSrc, vUv + dir *  0.5).rgb);
    float lB = luma(rgbB);
    vec3 res = (lB < lMin || lB > lMax) ? rgbA : rgbB;
    outColor = vec4(mix(rgbM, res, uAmt), 1.0);
}
"""

    /** FXAA "Quality": FXAA 3.11 style. Edge detection, end-of-edge search along the edge (up to ~12 steps
     *  each way) and sub-pixel blend. Better on long jaggy lines than the fast one, still one pass. */
    const val FXAA_QUALITY = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform vec2 uInv;
uniform float uAmt;
in highp vec2 vUv;
out vec4 outColor;
float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
float lumaAt(vec2 p) { return luma(texture(uSrc, p).rgb); }
void main() {
    vec3 cM = texture(uSrc, vUv).rgb;
    float lM = luma(cM);
    float lN = luma(textureOffset(uSrc, vUv, ivec2( 0,  1)).rgb);
    float lS = luma(textureOffset(uSrc, vUv, ivec2( 0, -1)).rgb);
    float lW = luma(textureOffset(uSrc, vUv, ivec2(-1,  0)).rgb);
    float lE = luma(textureOffset(uSrc, vUv, ivec2( 1,  0)).rgb);
    float rMin = min(lM, min(min(lS, lN), min(lW, lE)));
    float rMax = max(lM, max(max(lS, lN), max(lW, lE)));
    float range = rMax - rMin;
    if (range < max(0.08, rMax * 0.25)) { outColor = vec4(cM, 1.0); return; }
    float lNW = luma(textureOffset(uSrc, vUv, ivec2(-1,  1)).rgb);
    float lNE = luma(textureOffset(uSrc, vUv, ivec2( 1,  1)).rgb);
    float lSW = luma(textureOffset(uSrc, vUv, ivec2(-1, -1)).rgb);
    float lSE = luma(textureOffset(uSrc, vUv, ivec2( 1, -1)).rgb);
    float lNS = lN + lS, lWE = lW + lE;
    float lNWSW = lNW + lSW, lNESE = lNE + lSE, lNWNE = lNW + lNE, lSWSE = lSW + lSE;
    float edgeH = abs(-2.0 * lW + lNWSW) + abs(-2.0 * lM + lNS) * 2.0 + abs(-2.0 * lE + lNESE);
    float edgeV = abs(-2.0 * lN + lNWNE) + abs(-2.0 * lM + lWE) * 2.0 + abs(-2.0 * lS + lSWSE);
    bool horz = edgeH >= edgeV;
    // neighbours across the edge: +side / -side
    float lPos = horz ? lN : lE;
    float lNeg = horz ? lS : lW;
    float gPos = lPos - lM, gNeg = lNeg - lM;
    bool toPos = abs(gPos) >= abs(gNeg);
    float grad = max(abs(gPos), abs(gNeg)) * 0.25;
    float lAvgEdge = 0.5 * ((toPos ? lPos : lNeg) + lM);
    vec2 perp = horz ? vec2(0.0, uInv.y) : vec2(uInv.x, 0.0);
    vec2 along = horz ? vec2(uInv.x, 0.0) : vec2(0.0, uInv.y);
    float sgn = toPos ? 1.0 : -1.0;
    vec2 uvE = vUv + perp * sgn * 0.5;
    vec2 p1 = uvE - along;
    vec2 p2 = uvE + along;
    float e1 = lumaAt(p1) - lAvgEdge;
    float e2 = lumaAt(p2) - lAvgEdge;
    bool d1 = abs(e1) >= grad;
    bool d2 = abs(e2) >= grad;
    for (int i = 0; i < 12; i++) {
        if (d1 && d2) break;
        float stp = i < 4 ? 1.0 : (i < 8 ? 1.5 : 2.5);
        if (!d1) { p1 -= along * stp; e1 = lumaAt(p1) - lAvgEdge; d1 = abs(e1) >= grad; }
        if (!d2) { p2 += along * stp; e2 = lumaAt(p2) - lAvgEdge; d2 = abs(e2) >= grad; }
    }
    float dist1 = horz ? (vUv.x - p1.x) : (vUv.y - p1.y);
    float dist2 = horz ? (p2.x - vUv.x) : (p2.y - vUv.y);
    bool nearer1 = dist1 < dist2;
    float distFinal = min(dist1, dist2);
    float spanLen = max(dist1 + dist2, 1e-6);
    float pixOff = 0.5 - distFinal / spanLen;
    bool centerDark = lM < lAvgEdge;
    bool goodSpan = ((nearer1 ? e1 : e2) < 0.0) != centerDark;
    float pixOffGood = goodSpan ? pixOff : 0.0;
    float lL = (2.0 * (lNS + lWE) + lNWSW + lNESE) * (1.0 / 12.0);
    float sA = clamp(abs(lL - lM) / range, 0.0, 1.0);
    float sB = (-2.0 * sA + 3.0) * sA;
    float sub = sB * sB * 0.25;
    float off = max(pixOffGood, sub);
    vec3 res = texture(uSrc, vUv + perp * sgn * off).rgb;
    outColor = vec4(mix(cM, res, uAmt), 1.0);
}
"""

    /** "Edge Smooth": own edge-directed filter. Sobel finds the edge direction, then the pixel is blurred
     *  ALONG the edge (never across it), so lines get smoother while text and fine detail stay crisp.
     *  Flat areas are left untouched. */
    const val EDGE_SMOOTH = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform vec2 uInv;
uniform float uAmt;
in highp vec2 vUv;
out vec4 outColor;
float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
void main() {
    vec3 cM = texture(uSrc, vUv).rgb;
    float a = luma(textureOffset(uSrc, vUv, ivec2(-1,  1)).rgb);
    float b = luma(textureOffset(uSrc, vUv, ivec2( 0,  1)).rgb);
    float c = luma(textureOffset(uSrc, vUv, ivec2( 1,  1)).rgb);
    float d = luma(textureOffset(uSrc, vUv, ivec2(-1,  0)).rgb);
    float e = luma(cM);
    float f = luma(textureOffset(uSrc, vUv, ivec2( 1,  0)).rgb);
    float g = luma(textureOffset(uSrc, vUv, ivec2(-1, -1)).rgb);
    float h = luma(textureOffset(uSrc, vUv, ivec2( 0, -1)).rgb);
    float i = luma(textureOffset(uSrc, vUv, ivec2( 1, -1)).rgb);
    float gx = (c + 2.0 * f + i) - (a + 2.0 * d + g);
    float gy = (a + 2.0 * b + c) - (g + 2.0 * h + i);
    float mag = length(vec2(gx, gy));
    float mn = min(min(min(a, b), min(c, d)), min(min(e, f), min(g, min(h, i))));
    float mx = max(max(max(a, b), max(c, d)), max(max(e, f), max(g, max(h, i))));
    // ignore flat areas / very faint edges; fully active on strong contrast
    float k = smoothstep(0.06, 0.30, mag) * uAmt;
    if (k <= 0.0 || (mx - mn) < 0.04) { outColor = vec4(cM, 1.0); return; }
    vec2 t = normalize(vec2(-gy, gx)) * uInv;   // tangent = along the edge
    vec3 acc = cM * 3.0;
    acc += (texture(uSrc, vUv + t * 0.75).rgb + texture(uSrc, vUv - t * 0.75).rgb) * 2.0;
    acc += (texture(uSrc, vUv + t * 1.75).rgb + texture(uSrc, vUv - t * 1.75).rgb);
    vec3 smoothC = acc * (1.0 / 9.0);
    // cheap second tap set a little off-axis catches stair-steps on shallow slopes
    vec2 n = vec2(-t.y, t.x);
    vec3 side = 0.5 * (texture(uSrc, vUv + n * 0.35).rgb + texture(uSrc, vUv - n * 0.35).rgb);
    smoothC = mix(smoothC, side, 0.25);
    outColor = vec4(mix(cM, smoothC, k), 1.0);
}
"""

    /** "Smart Edge": edge-directed anti-aliasing that smooths only hard stair-step edges, along the edge (never across it).
     *  Soft detail, textures and photos are left untouched, so the picture stays sharp. */
    const val EDGE_SMART = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform vec2 uInv;
uniform float uAmt;
in highp vec2 vUv;
out vec4 outColor;
float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
void main() {
    vec3 cM = texture(uSrc, vUv).rgb;
    float a = luma(textureOffset(uSrc, vUv, ivec2(-1,  1)).rgb);
    float b = luma(textureOffset(uSrc, vUv, ivec2( 0,  1)).rgb);
    float c = luma(textureOffset(uSrc, vUv, ivec2( 1,  1)).rgb);
    float d = luma(textureOffset(uSrc, vUv, ivec2(-1,  0)).rgb);
    float e = luma(cM);
    float f = luma(textureOffset(uSrc, vUv, ivec2( 1,  0)).rgb);
    float g = luma(textureOffset(uSrc, vUv, ivec2(-1, -1)).rgb);
    float h = luma(textureOffset(uSrc, vUv, ivec2( 0, -1)).rgb);
    float i = luma(textureOffset(uSrc, vUv, ivec2( 1, -1)).rgb);
    float gx = (c + 2.0 * f + i) - (a + 2.0 * d + g);
    float gy = (a + 2.0 * b + c) - (g + 2.0 * h + i);
    float mag = length(vec2(gx, gy));
    float mn = min(min(min(a, b), min(c, d)), min(min(e, f), min(g, min(h, i))));
    float mx = max(max(max(a, b), max(c, d)), max(max(e, f), max(g, max(h, i))));
    float rng = mx - mn;
    // hardness: a clean 1-pixel stair edge has gradient ~ 4x the local range; soft ramps and texture score lower
    float hard = mag / (4.0 * rng + 1e-4);
    float k = smoothstep(0.04, 0.22, rng) * smoothstep(0.35, 0.75, hard) * uAmt;
    if (k <= 0.0) { outColor = vec4(cM, 1.0); return; }
    vec2 t = normalize(vec2(-gy, gx) + 1e-5) * uInv;
    vec3 sm = (2.0 * cM
        + 1.5 * (texture(uSrc, vUv + t * 0.6).rgb + texture(uSrc, vUv - t * 0.6).rgb)
        + 0.5 * (texture(uSrc, vUv + t * 1.6).rgb + texture(uSrc, vUv - t * 1.6).rgb)) * (1.0 / 6.0);
    outColor = vec4(mix(cM, sm, k), 1.0);
}
"""

    /** "Raw": shows the captured low-resolution frame exactly as it is, nearest-neighbour, no filtering at all.
     *  Every captured pixel becomes a visible block, so you can see what the chosen render resolution really looks like. */
    const val NEAREST = """#version 300 es
precision highp float;
precision highp int;
uniform sampler2D uSrc;
uniform ivec2 uSrcSize;
in highp vec2 vUv;
out vec4 outColor;
void main() {
    ivec2 p = clamp(ivec2(floor(vUv * vec2(uSrcSize))), ivec2(0), uSrcSize - ivec2(1));
    outColor = vec4(texelFetch(uSrc, p, 0).rgb, 1.0);
}
"""

    /** "Detail / deblur": wide, halo-limited unsharp mask on luma, aimed at soft sources that were already upscaled
     *  by a player (e.g. a 360p video stretched to the screen). RCAS only looks 1 px away, which is too small to
     *  undo a 3x bilinear blur; this looks 1..4 px away. Small differences are ignored (keeps noise and blocks calm)
     *  and the result is clamped to the local min/max so it cannot ring. */
    const val DETAIL = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform vec2 uInv;
uniform float uAmt;
uniform float uRadius;
uniform float uClar;    // clarity -1..1 (large-scale local contrast; negative softens)
uniform float uClarR;   // clarity radius in pixels
uniform float uRing;    // anti-ringing 0..1
in highp vec2 vUv;
out vec4 outColor;
float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
float lumaAt(vec2 o) { return luma(texture(uSrc, vUv + o * uInv).rgb); }
void main() {
    vec3 c = texture(uSrc, vUv).rgb;
    float l0 = luma(c);
    float lo = l0;
    if (uAmt > 0.0) {
        float r1 = uRadius, r2 = uRadius * 2.0;
        float a = lumaAt(vec2(-r1,  r1)), b = lumaAt(vec2(0.0,  r1)), d = lumaAt(vec2( r1,  r1));
        float e = lumaAt(vec2(-r1, 0.0)),                              f = lumaAt(vec2( r1, 0.0));
        float g = lumaAt(vec2(-r1, -r1)), h = lumaAt(vec2(0.0, -r1)), i = lumaAt(vec2( r1, -r1));
        float blur1 = (4.0 * l0 + 2.0 * (b + e + f + h) + (a + d + g + i)) * (1.0 / 16.0);
        float a2 = lumaAt(vec2(-r2,  r2)), b2 = lumaAt(vec2(0.0,  r2)), d2 = lumaAt(vec2( r2,  r2));
        float e2 = lumaAt(vec2(-r2, 0.0)),                               f2 = lumaAt(vec2( r2, 0.0));
        float g2 = lumaAt(vec2(-r2, -r2)), h2 = lumaAt(vec2(0.0, -r2)), i2 = lumaAt(vec2( r2, -r2));
        float blur2 = (4.0 * l0 + 2.0 * (b2 + e2 + f2 + h2) + (a2 + d2 + g2 + i2)) * (1.0 / 16.0);
        float blur = 0.6 * blur1 + 0.4 * blur2;
        float diff = l0 - blur;
        // coring: tiny differences (noise, compression blocks) get little gain, real edges full gain
        float gain = smoothstep(0.004, 0.035, abs(diff));
        float mn = min(min(min(a, b), min(d, e)), min(min(f, g), min(h, min(i, l0))));
        float mx = max(max(max(a, b), max(d, e)), max(max(f, g), max(h, max(i, l0))));
        lo = clamp(l0 + diff * uAmt * 3.0 * gain, mn - 0.02, mx + 0.02);
    }
    if (uClar != 0.0) {
        // Clarity: blur over a wide area (two rings of 8 taps), then push the difference; mid-tones get the most, so
        // deep shadows and bright highlights do not clip. Negative values pull towards the blur (a soft, dreamy look).
        float R = uClarR;
        float s1 = 0.0, s2 = 0.0;
        for (int k = 0; k < 8; k++) {
            float an = float(k) * 0.7853982;
            vec2 dir = vec2(cos(an), sin(an));
            s1 += lumaAt(dir * R);
            s2 += lumaAt(dir * R * 2.0);
        }
        float bl = (l0 * 2.0 + s1 + s2 * 0.75) * (1.0 / 14.0);
        float mw = 1.0 - 0.7 * abs(l0 * 2.0 - 1.0);
        if (uClar > 0.0) lo += (l0 - bl) * uClar * 1.4 * mw;
        else lo = mix(lo, bl, -uClar * 0.6);
    }
    if (uRing > 0.0) {
        // Anti-ringing: on a hard step edge, a pixel may not go beyond the two levels found 1.5 px away on both sides
        // along the gradient. Thin lines (both sides alike) and soft ramps are left alone.
        float a = lumaAt(vec2(-1.0,  1.0)), b = lumaAt(vec2(0.0,  1.0)), d = lumaAt(vec2( 1.0,  1.0));
        float e = lumaAt(vec2(-1.0,  0.0)),                              f = lumaAt(vec2( 1.0,  0.0));
        float g = lumaAt(vec2(-1.0, -1.0)), h = lumaAt(vec2(0.0, -1.0)), i = lumaAt(vec2( 1.0, -1.0));
        vec2 gr = vec2((d + 2.0 * f + i) - (a + 2.0 * e + g), (a + 2.0 * b + d) - (g + 2.0 * h + i));
        float gm = length(gr);
        if (gm > 0.06) {
            vec2 dv = gr / gm * 1.5;
            float lp = lumaAt(dv), ln = lumaAt(-dv);
            float hi = max(lp, ln), lw = min(lp, ln);
            if (hi - lw > 0.08) {
                float slack = (1.0 - uRing) * 0.08;
                float cl = clamp(lo, lw - slack, hi + slack);
                lo = mix(lo, cl, smoothstep(0.06, 0.16, gm));
            }
        }
    }
    outColor = vec4(clamp(c + (lo - l0), 0.0, 1.0), 1.0);
}
"""

    /**
     * "Game Light": a lighting and material touch for game pictures, in one pass (the nearest this app gets to what DLSS 5 does with a neural
     * network; there is no network, no depth and no motion here, only the picture itself). From two rings of 8 taps (near and about 3.5x
     * wider) it works out the local average at two scales and then:
     *  1. texture: the mid-size detail (grass, cloth, stone, skin) is pushed, with coring and with protection against hard edges (no halos);
     *  2. tone: dark areas get their detail pushed harder and a small lift, very bright areas are eased a little (local tone mapping);
     *  3. depth: a pixel darker than its wide surroundings (creases, contact shadows) is darkened a touch (a cheap stand-in for ambient occlusion);
     *  4. glow: very bright surroundings spill a soft neutral light onto fairly bright pixels (specular highlights, lamps, fire);
     *  5. colour: a light vibrance (the less saturated a colour is, the more it gains; the Game HQ colour touch comes on top of it, so it is kept small).
     * uAmt 0..1 scales everything; uRad is the near ring radius in pixels.
     */
    const val GAME_LIGHT = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform vec2 uInv;
uniform float uAmt;
uniform float uRad;
in highp vec2 vUv;
out vec4 outColor;
float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
const vec2 D[8] = vec2[8](vec2(1.0, 0.0), vec2(0.7071, 0.7071), vec2(0.0, 1.0), vec2(-0.7071, 0.7071),
                          vec2(-1.0, 0.0), vec2(-0.7071, -0.7071), vec2(0.0, -1.0), vec2(0.7071, -0.7071));
void main() {
    vec3 c = texture(uSrc, vUv).rgb;
    float l = luma(c);
    float s1 = 0.0, s2 = 0.0, glow = 0.0, mn = l, mx = l;
    for (int k = 0; k < 8; k++) {
        float a = luma(texture(uSrc, vUv + D[k] * uRad * uInv).rgb);
        float b = luma(texture(uSrc, vUv + D[k] * uRad * 3.5 * uInv).rgb);
        s1 += a;
        s2 += b;
        mn = min(mn, a);
        mx = max(mx, a);
        glow += max(b - 0.80, 0.0);
    }
    float m1 = (s1 + l) * (1.0 / 9.0);
    float m2 = (s2 + l) * (1.0 / 9.0);
    // 1) texture: mid detail, cored (noise gets nothing) and protected on hard edges (no halos), kept inside the local range
    float hp = l - m1;
    float ah = abs(hp);
    float tg = smoothstep(0.004, 0.030, ah) * (1.0 - smoothstep(0.10, 0.30, ah));
    float lt = clamp(l + hp * 1.3 * uAmt * tg, mn - 0.02, mx + 0.02);
    float dl = lt - l;
    // 2) tone: dark surroundings get more detail and a small lift; very bright ones are eased
    float dark = 1.0 - smoothstep(0.05, 0.55, m2);
    dl += hp * dark * 4.0 * uAmt * tg + dark * 0.05 * uAmt * (1.0 - l);
    dl -= smoothstep(0.70, 1.0, m2) * 0.10 * uAmt * max(l - 0.75, 0.0);
    // 3) depth: darker than the wide surroundings = a crease or a contact shadow
    float cre = clamp(m2 - l, 0.0, 1.0);
    dl -= smoothstep(0.03, 0.20, cre) * (1.0 - smoothstep(0.45, 0.80, l)) * 0.10 * uAmt;
    // 4) glow: light spilling from very bright surroundings onto pixels that are themselves fairly bright (neutral: no colour fringes on dark edges)
    vec3 o = c + vec3(dl) + vec3(glow * 0.125 * 0.45 * uAmt * smoothstep(0.30, 0.65, l) * (1.0 - l));
    // 5) vibrance: weakly coloured pixels gain more than strong ones
    o = clamp(o, 0.0, 1.0); // before the colour step: a channel below 0 made the saturation (and the gain) explode on dark edges
    float lo = luma(o);
    float mxc = max(o.r, max(o.g, o.b));
    float mnc = min(o.r, min(o.g, o.b));
    float sat = clamp((mxc - mnc) / max(mxc, 0.02), 0.0, 1.0);
    o = mix(vec3(lo), o, 1.0 + 0.15 * uAmt * (1.0 - sat));
    outColor = vec4(clamp(o, 0.0, 1.0), 1.0);
}
"""

    /** "Deinterlace": old interlaced videos show horizontal comb teeth where something moves. Where the picture is combed (the line
     *  differs from BOTH neighbour lines in the same direction, while the line two rows away - same field - does not) the line is rebuilt
     *  from the lines above and below, along the edge (5 directions, each judged on 3 pixels). The comb test is widened by one pixel to each
     *  side so no holes stay inside a moving area, and thin still lines (text, grid lines) are not mistaken for combing.
     *  Still parts keep every line. uOdd 1 = rebuild odd rows, 0 = even rows. */
    const val DEINT = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform vec2 uInv;
uniform float uOdd;
in highp vec2 vUv;
out vec4 outColor;
float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
float L(vec2 p) { return luma(texture(uSrc, p).rgb); }
// how strongly the line at p is a comb tooth (0..1): sticks out from both neighbours, but not from its own field (rows +-2)
float tooth(vec2 p, vec2 up) {
    float l = L(p), lu = L(p - up), ld = L(p + up);
    float comb = (l - lu) * (l - ld);
    float k = smoothstep(0.0008, 0.006, comb);
    if (k <= 0.0) return 0.0;
    float dn = min(abs(l - lu), abs(l - ld)) + 0.0001;
    float sf = min(abs(l - L(p - 2.0 * up)), abs(l - L(p + 2.0 * up)));
    return k * (1.0 - smoothstep(0.55, 1.0, sf / dn));
}
void main() {
    vec3 c = texture(uSrc, vUv).rgb;
    float row = floor(vUv.y / uInv.y);
    float par = mod(row, 2.0);
    if (abs(par - uOdd) > 0.5) { outColor = vec4(c, 1.0); return; }
    vec2 up = vec2(0.0, uInv.y), dx = vec2(uInv.x, 0.0);
    float k = max(tooth(vUv, up), max(tooth(vUv - dx, up), tooth(vUv + dx, up)));
    if (k <= 0.0) { outColor = vec4(c, 1.0); return; }
    // edge-directed interpolation: the direction (-2..+2 px) whose two ends, seen on 3 pixels each, agree best
    float U[7]; float D[7];
    for (int i = 0; i < 7; i++) {
        vec2 o = float(i - 3) * dx;
        U[i] = L(vUv - up + o);
        D[i] = L(vUv + up + o);
    }
    float best = 1e9; int bd = 0;
    for (int d = -2; d <= 2; d++) {
        float cost = 0.0;
        for (int t = -1; t <= 1; t++) cost += abs(U[3 + d + t] - D[3 - d + t]);
        cost += 0.03 * abs(float(d));                    // lean to straight up / down when it is a tie
        if (cost < best) { best = cost; bd = d; }
    }
    vec2 sh = float(bd) * dx;
    vec3 ip = 0.5 * (texture(uSrc, vUv - up + sh).rgb + texture(uSrc, vUv + up - sh).rgb);
    if (best > 0.35) ip = 0.5 * (texture(uSrc, vUv - up).rgb + texture(uSrc, vUv + up).rgb);   // nothing agrees: plain average
    outColor = vec4(mix(c, ip, k), 1.0);
}
"""

    /** "Denoise / deblock": edge-preserving bilateral filter (12 taps). Pixels are averaged only with neighbours of
     *  similar brightness, so flat areas lose their compression noise and the faint steps at block borders,
     *  while real edges stay. uAmt 0..1 widens the "similar enough" range. */
    /** "Fine pixels" upscaler: the picture is cut into square blocks on a grid that is [uGrid] times finer than the source pixels
     *  (1 = the source pixels themselves, like Raw; 2 = squares half the size, four times as many ...). Every block is filled with ONE colour:
     *  the Catmull-Rom sample of the source at the block centre (held inside the range of the 4 nearest pixels, so no halos). */
    const val PIXEL = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform ivec2 uSrcSize;
uniform float uGrid;
in highp vec2 vUv;
out vec4 outColor;
void main() {
    vec2 size = vec2(uSrcSize);
    if (uGrid < 0.999) {
        // squares BIGGER than a source pixel: every square is the average of taps x taps bilinear samples spread over it (a point sample would flicker)
        vec2 cells = max(floor(size * uGrid + 0.5), 1.0);
        vec2 cl = floor(vUv * cells);
        vec2 ctr = (cl + 0.5) / cells;
        float bs = 1.0 / uGrid;
        int n = int(clamp(ceil(bs * 0.5 - 0.25), 1.0, 4.0));
        vec3 s = vec3(0.0);
        for (int j = 0; j < n; j++) {
            for (int i = 0; i < n; i++) {
                vec2 o = ((vec2(float(i), float(j)) + 0.5) / float(n) - 0.5) / cells;
                s += texture(uSrc, ctr + o).rgb;
            }
        }
        outColor = vec4(s / float(n * n), 1.0);
        return;
    }
    vec2 cell = floor(vUv * size * uGrid);
    vec2 pos = (cell + 0.5) / uGrid;
    vec2 q = pos - 0.5;
    vec2 b = floor(q);
    vec2 f = q - b;
    vec2 f2 = f * f;
    vec2 f3 = f2 * f;
    vec2 w0 = -0.5 * f3 + f2 - 0.5 * f;
    vec2 w1 = 1.5 * f3 - 2.5 * f2 + 1.0;
    vec2 w2 = -1.5 * f3 + 2.0 * f2 + 0.5 * f;
    vec2 w3 = 0.5 * f3 - 0.5 * f2;
    vec4 wx = vec4(w0.x, w1.x, w2.x, w3.x);
    vec4 wy = vec4(w0.y, w1.y, w2.y, w3.y);
    ivec2 mx = uSrcSize - 1;
    ivec2 c0 = ivec2(b);
    vec3 acc = vec3(0.0);
    vec3 mn = vec3(1.0);
    vec3 mxv = vec3(0.0);
    for (int j = 0; j < 4; j++) {
        for (int i = 0; i < 4; i++) {
            vec3 c = texelFetch(uSrc, clamp(c0 + ivec2(i - 1, j - 1), ivec2(0), mx), 0).rgb;
            acc += c * (wx[i] * wy[j]);
            if (i >= 1 && i <= 2 && j >= 1 && j <= 2) {
                mn = min(mn, c);
                mxv = max(mxv, c);
            }
        }
    }
    outColor = vec4(clamp(acc, max(mn - 0.02, 0.0), min(mxv + 0.02, 1.0)), 1.0);
}
"""

    /** "Fine pixels" as a finishing step on top of ANY upscaler: the finished picture is cut into square blocks ([uCells] blocks across and
     *  down, the grid of the source pixels made [Cfg.pixelFactor] times finer) and every block gets ONE colour: the average of 4 samples
     *  of the finished picture inside the block. So the colours come from whatever upscaler / sharpening was chosen. */
    const val PIXEL_POST = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform vec2 uCells;
uniform float uTaps;   // 1..4: samples per side inside one block (one bilinear sample = 2 x 2 pixels, so about half the block width in pixels)
in highp vec2 vUv;
out vec4 outColor;
void main() {
    vec2 cell = floor(vUv * uCells);
    vec2 c = (cell + 0.5) / uCells;
    vec2 sz = 1.0 / uCells;
    int n = int(uTaps + 0.5);
    vec3 s = vec3(0.0);
    for (int j = 0; j < n; j++) {
        for (int i = 0; i < n; i++) {
            vec2 o = ((vec2(float(i), float(j)) + 0.5) / uTaps - 0.5) * sz;
            s += texture(uSrc, c + o).rgb;
        }
    }
    outColor = vec4(s / (uTaps * uTaps), 1.0);
}
"""

    /** "Fine pixels", second step: [uSrc] holds ONE pixel per block (the block colours, [PIXEL_POST] drew them small). Every block of the
     *  output is its colour, with its edges to the 4 neighbouring blocks made crisper (unsharp over the block grid, kept inside the range of
     *  the block and its neighbours, so no halos and no new colours). Averaging a block softens the picture; this gives the edges back. */
    const val PIXEL_CRISP = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform vec2 uCells;
uniform float uK;
in highp vec2 vUv;
out vec4 outColor;
void main() {
    ivec2 mx = ivec2(uCells) - 1;
    ivec2 c = clamp(ivec2(floor(vUv * uCells)), ivec2(0), mx);
    vec3 m = texelFetch(uSrc, c, 0).rgb;
    vec3 a = texelFetch(uSrc, clamp(c + ivec2(1, 0), ivec2(0), mx), 0).rgb;
    vec3 b = texelFetch(uSrc, clamp(c - ivec2(1, 0), ivec2(0), mx), 0).rgb;
    vec3 d = texelFetch(uSrc, clamp(c + ivec2(0, 1), ivec2(0), mx), 0).rgb;
    vec3 e = texelFetch(uSrc, clamp(c - ivec2(0, 1), ivec2(0), mx), 0).rgb;
    vec3 avg = (a + b + d + e) * 0.25;
    vec3 lo = min(m, min(min(a, b), min(d, e)));
    vec3 hi = max(m, max(max(a, b), max(d, e)));
    outColor = vec4(clamp(m + uK * (m - avg), lo, hi), 1.0);
}
"""

    /** "Clear" upscaler: one pass, 16 reads. An edge-directed kernel over the 4x4 pixels around the sample point:
     *  - the direction of the edge comes from a small structure tensor (so stair-steps are smoothed ALONG the edge and the edge stays sharp ACROSS it);
     *  - in flat areas that only hold compression noise (small range) the kernel is a little wider, so blocks / mosquito noise are not enlarged;
     *  - real detail (range above the noise level) keeps the full sharp kernel;
     *  - the result is held inside the range of the 4 nearest pixels (plus a small allowance), so there are no halos.
     *  The sharpening afterwards is the normal RCAS pass. uSharp 0..1 (the Sharpness slider). */
    const val CLEAR = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform ivec2 uSrcSize;
uniform float uSharp;
in highp vec2 vUv;
out vec4 outColor;
void main() {
    vec2 pos = vUv * vec2(uSrcSize) - 0.5;
    vec2 b = floor(pos);
    vec2 f = pos - b;
    ivec2 mx = uSrcSize - 1;
    ivec2 c0 = ivec2(b);
    vec3 C[16];
    float L[16];
    for (int j = 0; j < 4; j++) {
        for (int i = 0; i < 4; i++) {
            vec3 c = texelFetch(uSrc, clamp(c0 + ivec2(i - 1, j - 1), ivec2(0), mx), 0).rgb;
            C[j * 4 + i] = c;
            L[j * 4 + i] = dot(c, vec3(0.299, 0.587, 0.114));
        }
    }
    float lmn = L[0];
    float lmx = L[0];
    for (int k = 1; k < 16; k++) {
        lmn = min(lmn, L[k]);
        lmx = max(lmx, L[k]);
    }
    // structure tensor from the 4 pixels around the sample point, weighted by where the point lies between them
    float gxx = 0.0;
    float gyy = 0.0;
    float gxy = 0.0;
    for (int j = 1; j < 3; j++) {
        for (int i = 1; i < 3; i++) {
            float gx = (L[(j - 1) * 4 + i + 1] + 2.0 * L[j * 4 + i + 1] + L[(j + 1) * 4 + i + 1]
                      - L[(j - 1) * 4 + i - 1] - 2.0 * L[j * 4 + i - 1] - L[(j + 1) * 4 + i - 1]) * 0.125;
            float gy = (L[(j + 1) * 4 + i - 1] + 2.0 * L[(j + 1) * 4 + i] + L[(j + 1) * 4 + i + 1]
                      - L[(j - 1) * 4 + i - 1] - 2.0 * L[(j - 1) * 4 + i] - L[(j - 1) * 4 + i + 1]) * 0.125;
            float w = (i == 1 ? 1.0 - f.x : f.x) * (j == 1 ? 1.0 - f.y : f.y);
            gxx += w * gx * gx;
            gyy += w * gy * gy;
            gxy += w * gx * gy;
        }
    }
    float tr = gxx + gyy;
    float disc = sqrt(max((gxx - gyy) * (gxx - gyy) + 4.0 * gxy * gxy, 0.0));
    float l1 = 0.5 * (tr + disc);
    float l2 = 0.5 * (tr - disc);
    float coh = (l1 - l2) / (l1 + l2 + 1e-6) * smoothstep(0.0001, 0.015, l1);
    vec2 n1 = vec2(gxy, l1 - gxx);
    vec2 n2 = vec2(l1 - gyy, gxy);
    vec2 n = dot(n1, n1) > dot(n2, n2) ? n1 : n2;   // across the edge
    float nl = dot(n, n);
    n = nl > 1e-12 ? n * inversesqrt(nl) : vec2(1.0, 0.0);
    vec2 t = vec2(-n.y, n.x);                      // along the edge
    float flatness = 1.0 - smoothstep(0.012, 0.05, lmx - lmn);
    float soft = 1.0 - 0.03 * flatness;
    float ka = (1.0 + 0.06 * coh) * soft;                    // across the edge: almost unchanged (the RCAS pass after does the sharpening)
    float kl = (1.0 / (1.0 + 0.63 * coh)) * soft;           // wider along the edge = smoother stair-steps
    float lob = mix(0.35, 0.26, coh);                      // Lanczos-like in flat areas, a little longer along edges
    float clp = 1.0 / lob;
    vec3 acc = vec3(0.0);
    float ws = 0.0;
    for (int j = 0; j < 4; j++) {
        for (int i = 0; i < 4; i++) {
            vec2 d = vec2(float(i - 1), float(j - 1)) - f;
            float u = dot(d, n) * ka;
            float v = dot(d, t) * kl;
            float d2 = min(u * u + v * v, clp);
            float wB = 0.4 * d2 - 1.0;
            float wA = lob * d2 - 1.0;
            wB *= wB;
            wA *= wA;
            wB = 1.5625 * wB - 0.5625;
            float w = wB * wA;
            acc += C[j * 4 + i] * w;
            ws += w;
        }
    }
    acc /= max(ws, 1e-4);
    vec3 mn = min(min(C[5], C[6]), min(C[9], C[10]));
    vec3 mxx = max(max(C[5], C[6]), max(C[9], C[10]));
    float ov = 0.015;
    outColor = vec4(clamp(acc, max(mn - ov, 0.0), min(mxx + ov, 1.0)), 1.0);
}
"""

    /** "Clean upscale" pre-sharpen: a gentle edge-aware sharpen at capture size, after the denoise and before anti-aliasing.
     *  Works only where there is real detail (flat areas and strong edges get less), and the result is held inside the
     *  local min / max so it cannot make halos. uAmt 0..1. */
    const val PRESHARP = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform vec2 uInv;
uniform float uAmt;
in highp vec2 vUv;
out vec4 outColor;
float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
void main() {
    vec3 c = texture(uSrc, vUv).rgb;
    vec3 n = texture(uSrc, vUv + vec2(0.0, -uInv.y)).rgb;
    vec3 s = texture(uSrc, vUv + vec2(0.0,  uInv.y)).rgb;
    vec3 e = texture(uSrc, vUv + vec2( uInv.x, 0.0)).rgb;
    vec3 w = texture(uSrc, vUv + vec2(-uInv.x, 0.0)).rgb;
    vec3 mn = min(c, min(min(n, s), min(e, w)));
    vec3 mx = max(c, max(max(n, s), max(e, w)));
    float lmn = luma(mn);
    float lmx = luma(mx);
    // CAS-like weight: strong where the neighbourhood has headroom, weak where it is already contrasty
    float amp = sqrt(clamp(min(lmn, 1.0 - lmx) / max(lmx, 0.001), 0.0, 1.0));
    // weak texture (noise level) is not boosted
    float rng = lmx - lmn;
    float tex = smoothstep(0.02, 0.10, rng);
    vec3 blur = (n + s + e + w) * 0.25;
    vec3 o = c + (c - blur) * (uAmt * 1.6 * amp * tex);
    o = clamp(o, mn - 0.015, mx + 0.015);
    outColor = vec4(clamp(o, 0.0, 1.0), 1.0);
}
"""

    const val DENOISE = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform vec2 uInv;
uniform float uAmt;
in highp vec2 vUv;
out vec4 outColor;
float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
void main() {
    vec3 c = texture(uSrc, vUv).rgb;
    float l0 = luma(c);
    float sigma = 0.012 + 0.11 * uAmt;
    float inv2s = 1.0 / (2.0 * sigma * sigma);
    vec3 sum = c;
    float ws = 1.0;
    const vec2 OFF[12] = vec2[12](
        vec2(-1.0, -1.0), vec2(0.0, -1.0), vec2(1.0, -1.0),
        vec2(-1.0,  0.0),                  vec2(1.0,  0.0),
        vec2(-1.0,  1.0), vec2(0.0,  1.0), vec2(1.0,  1.0),
        vec2(-2.0,  0.0), vec2(2.0,  0.0), vec2(0.0, -2.0), vec2(0.0, 2.0));
    for (int i = 0; i < 12; i++) {
        vec3 s = texture(uSrc, vUv + OFF[i] * uInv).rgb;
        float d = luma(s) - l0;
        float sp = i < 8 ? 1.0 : 0.6;
        float w = sp * exp(-d * d * inv2s);
        sum += s * w;
        ws += w;
    }
    outColor = vec4(sum / ws, 1.0);
}
"""

    /** "Colour clean-up": low-bitrate video and JPEGs lose their colour first (blotches, colour bleeding, coloured noise) while the
     *  brightness keeps the detail. The picture is split into brightness and colour (what is left when the brightness is taken away);
     *  only the COLOUR is smoothed, over 16 samples up to about 6 px away, and each sample counts only if its brightness is close to the
     *  pixel's, so colours do not bleed across edges and no detail is lost. uAmt 0..1 = reach and strength. */
    const val CHROMA = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform vec2 uInv;
uniform float uAmt;
in highp vec2 vUv;
out vec4 outColor;
float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
void main() {
    vec3 c = texture(uSrc, vUv).rgb;
    float y0 = luma(c);
    vec3 col0 = c - vec3(y0);
    float r1 = 1.5 + 1.5 * uAmt;
    float r2 = 2.0 * r1;
    float sigma = 0.025 + 0.09 * uAmt;
    float inv2s = 1.0 / (2.0 * sigma * sigma);
    vec3 sum = col0;
    float ws = 1.0;
    const vec2 DIR[8] = vec2[8](
        vec2(1.0, 0.0), vec2(-1.0, 0.0), vec2(0.0, 1.0), vec2(0.0, -1.0),
        vec2(0.7071, 0.7071), vec2(-0.7071, 0.7071), vec2(0.7071, -0.7071), vec2(-0.7071, -0.7071));
    for (int i = 0; i < 8; i++) {
        for (int k = 0; k < 2; k++) {
            float r = (k == 0) ? r1 : r2;
            vec3 s = texture(uSrc, vUv + DIR[i] * r * uInv).rgb;
            float ys = luma(s);
            float d = ys - y0;
            float w = exp(-d * d * inv2s) * ((k == 0) ? 1.0 : 0.6);
            sum += (s - vec3(ys)) * w;
            ws += w;
        }
    }
    vec3 col = sum / ws;
    outColor = vec4(clamp(vec3(y0) + mix(col0, col, clamp(uAmt * 1.5, 0.0, 1.0)), 0.0, 1.0), 1.0);
}
"""

    /** "Deband": for each pixel, takes a few random pairs of far-away samples (up to uRange px) and averages
     *  only those that are almost the same colour, so gradients turn smooth but real edges are untouched.
     *  A 1-level dither hides the last steps of 8-bit output. uAmt 0..1 = how different samples may be. */
    const val DEBAND = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform vec2 uInv;
uniform float uAmt;
uniform float uRange;
in highp vec2 vUv;
out vec4 outColor;
float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
void main() {
    vec3 c = texture(uSrc, vUv).rgb;
    vec2 p = gl_FragCoord.xy;
    float thr = 0.004 + 0.03 * uAmt;
    vec3 acc = c;
    float n = 1.0;
    for (int i = 0; i < 4; i++) {
        float fi = float(i);
        float a = hash(p + fi * 17.0) * 6.2831853;
        float d = (0.25 + 0.75 * hash(p * 1.7 + fi * 31.0)) * uRange;
        vec2 o = vec2(cos(a), sin(a)) * d * uInv;
        vec3 s1 = texture(uSrc, vUv + o).rgb;
        vec3 s2 = texture(uSrc, vUv - o).rgb;
        vec3 d1 = abs(s1 - c);
        vec3 d2 = abs(s2 - c);
        if (max(max(d1.r, d1.g), d1.b) < thr && max(max(d2.r, d2.g), d2.b) < thr) {
            acc += s1 + s2;
            n += 2.0;
        }
    }
    vec3 res = acc / n;
    res += (hash(p * 3.1) - 0.5) * (1.0 / 255.0);
    outColor = vec4(clamp(res, 0.0, 1.0), 1.0);
}
"""


    /** Frame generation, step 1: block matching between two frames. One output texel = one 16x16 pixel block of the
     *  in-between picture; the result is the motion (prev -> cur, +-16 px) and the match error. */
    const val FG_MOTION = """#version 300 es
precision highp float;
uniform sampler2D uPrev;
uniform sampler2D uCur;
uniform vec2 uInv;
uniform float uStep;
uniform int uRange;
uniform float uBlock;
uniform int uRefine;
in highp vec2 vUv;
out vec4 outColor;
float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
float blockCost(vec2 d) {
    float cost = 0.0;
    for (int j = 0; j < 4; j++) {
        for (int i = 0; i < 4; i++) {
            vec2 s = (vec2(float(i), float(j)) + 0.5) * (uBlock * 0.25) - uBlock * 0.5;
            float a = luma(texture(uPrev, vUv + (s - d * 0.5) * uInv).rgb);
            float b = luma(texture(uCur, vUv + (s + d * 0.5) * uInv).rgb);
            cost += abs(a - b);
        }
    }
    return cost;
}
void main() {
    float best = 1e9;
    vec2 bestD = vec2(0.0);
    if (uRefine == 2) { // log search: 9 positions per round, the step halves each round (36 matches in all, reaches 1.9 x uStep)
        float stp = uStep;
        best = blockCost(vec2(0.0));
        for (int r = 0; r < 4; r++) {
            vec2 ctr = bestD;
            for (int dy = -1; dy <= 1; dy++) {
                for (int dx = -1; dx <= 1; dx++) {
                    if (dx == 0 && dy == 0) continue;
                    vec2 d = ctr + vec2(float(dx), float(dy)) * stp;
                    float cost = blockCost(d) + 0.004 * length(d);
                    if (cost < best) { best = cost; bestD = d; }
                }
            }
            stp *= 0.5;
        }
        float avg2 = best / 16.0;
        outColor = vec4(bestD / 40.0 + 0.50196, clamp(avg2 * 4.0, 0.0, 1.0), 1.0);
        return;
    }
    for (int dy = -uRange; dy <= uRange; dy++) {
        for (int dx = -uRange; dx <= uRange; dx++) {
            vec2 d = vec2(float(dx), float(dy)) * uStep;
            float cost = 0.0;
            for (int j = 0; j < 4; j++) {
                for (int i = 0; i < 4; i++) {
                    vec2 s = (vec2(float(i), float(j)) + 0.5) * (uBlock * 0.25) - uBlock * 0.5;
                    float a = luma(texture(uPrev, vUv + (s - d * 0.5) * uInv).rgb);
                    float b = luma(texture(uCur, vUv + (s + d * 0.5) * uInv).rgb);
                    cost += abs(a - b);
                }
            }
            cost += 0.004 * length(d); // prefer the smaller motion when two matches are equal
            if (cost < best) { best = cost; bestD = d; }
        }
    }
    if (uRefine > 0) { // finer search (1 px steps) around the best coarse match
        vec2 c0 = bestD;
        for (int ry = -2; ry <= 2; ry++) {
            for (int rx = -2; rx <= 2; rx++) {
                vec2 d = c0 + vec2(float(rx), float(ry));
                float cost = 0.0;
                for (int j = 0; j < 4; j++) {
                    for (int i = 0; i < 4; i++) {
                        vec2 s = (vec2(float(i), float(j)) + 0.5) * (uBlock * 0.25) - uBlock * 0.5;
                        float a = luma(texture(uPrev, vUv + (s - d * 0.5) * uInv).rgb);
                        float b = luma(texture(uCur, vUv + (s + d * 0.5) * uInv).rgb);
                        cost += abs(a - b);
                    }
                }
                cost += 0.004 * length(d);
                if (cost < best) { best = cost; bestD = d; }
            }
        }
    }
    float avg = best / 16.0;
    outColor = vec4(bestD / 40.0 + 0.50196, clamp(avg * 4.0, 0.0, 1.0), 1.0);
}
"""

    /** Frame generation, step 2: the picture at position uT between the two frames, built along the motion of each block
     *  (motion smoothed over the neighbouring blocks); where the two warped pictures disagree (hidden / uncovered areas)
     *  the nearest real frame is used instead of a blend of both, which would leave a ghost. */
    const val FG_INTERP = """#version 300 es
precision highp float;
uniform sampler2D uPrev;
uniform sampler2D uCur;
uniform sampler2D uMv;
uniform vec2 uInv;
uniform float uT;
uniform float uMvScale;
in highp vec2 vUv;
out vec4 outColor;
void main() {
    vec4 m = texture(uMv, vUv);
    vec3 pc = texture(uPrev, vUv).rgb;
    vec3 cc = texture(uCur, vUv).rgb;
    if (m.b > 0.8) { outColor = vec4(cc, 1.0); return; } // scene cut: nothing to blend
    vec2 g = 1.0 / vec2(textureSize(uMv, 0));
    vec4 m1 = texture(uMv, vUv + vec2(g.x, 0.0));
    vec4 m2 = texture(uMv, vUv - vec2(g.x, 0.0));
    vec4 m3 = texture(uMv, vUv + vec2(0.0, g.y));
    vec4 m4 = texture(uMv, vUv - vec2(0.0, g.y));
    float w0 = 1.2 - m.b;
    // neighbours only count when they move about the same way (keeps moving-object edges sharp)
    float w1 = (1.0 - m1.b) * exp(-dot(m1.rg - m.rg, m1.rg - m.rg) * 4000.0);
    float w2 = (1.0 - m2.b) * exp(-dot(m2.rg - m.rg, m2.rg - m.rg) * 4000.0);
    float w3 = (1.0 - m3.b) * exp(-dot(m3.rg - m.rg, m3.rg - m.rg) * 4000.0);
    float w4 = (1.0 - m4.b) * exp(-dot(m4.rg - m.rg, m4.rg - m.rg) * 4000.0);
    vec2 mv = (m.rg * w0 + m1.rg * w1 + m2.rg * w2 + m3.rg * w3 + m4.rg * w4) / (w0 + w1 + w2 + w3 + w4);
    vec2 d = (mv - 0.50196) * 40.0 * uMvScale;
    vec3 a = texture(uPrev, vUv - d * uT * uInv).rgb;
    vec3 b = texture(uCur, vUv + d * (1.0 - uT) * uInv).rgb;
    vec3 warped = mix(a, b, uT);
    vec3 nearest = mix(pc, cc, smoothstep(0.35, 0.65, uT));
    float err = length(a - b);
    float conf = 1.0 - smoothstep(0.12, 0.35, err);
    outColor = vec4(mix(nearest, warped, conf), 1.0);
}
"""

    /** Temporal clean-up, step 1: motion of every 16 x 16 block between the previous result (uPrev) and the new frame (uCur), with
     *  half-pixel precision: a log search (9 positions per round, the step halves every round: 8, 4, 2, 1, 0.5 px, reaches +-15 px),
     *  each match is 36 samples. Output rg = motion in pixels (/40 + 0.5), b = match error. Cheaper than the old 81 + 25 matches. */
    const val TEMPORAL_MOTION = """#version 300 es
precision highp float;
uniform sampler2D uPrev;uniform sampler2D uCur;uniform vec2 uInv;uniform float uStep;uniform float uBlock;uniform int uRounds;
in highp vec2 vUv;out vec4 outColor;
float luma(vec3 c){return dot(c,vec3(0.299,0.587,0.114));}
float blockCost(vec2 d){
 float cost=0.0;
 for(int j=0;j<6;j++)for(int i=0;i<6;i++){
  vec2 s=(vec2(float(i),float(j))+0.5)*(uBlock/6.0)-uBlock*0.5;
  float a=luma(texture(uPrev,vUv+(s-d*0.5)*uInv).rgb);
  float b=luma(texture(uCur,vUv+(s+d*0.5)*uInv).rgb);
  cost+=abs(a-b);}
 return cost;}
void main(){
 vec2 bestD=vec2(0.0);float best=blockCost(vec2(0.0));float stp=uStep;
 for(int r=0;r<uRounds;r++){
  vec2 ctr=bestD;
  for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++){
   if(dx==0&&dy==0)continue;
   vec2 d=ctr+vec2(float(dx),float(dy))*stp;
   float c=blockCost(d)+0.0015*length(d);
   if(c<best){best=c;bestD=d;}}
  stp*=0.5;}
 outColor=vec4(bestD/40.0+0.50196,clamp(best/36.0*4.0,0.0,1.0),1.0);}
"""

    /** Temporal clean-up, step 2: the previous result, moved along the motion of each block (half-pixel, sampled with a sharp
     *  Catmull-Rom filter so the old picture is not blurred by the shift), is blended into the new frame where the two agree.
     *  The old picture is clipped to what the 3x3 neighbourhood of the new frame allows (uClip x its spread, at least uSig), the
     *  blend is trusted less where the block match is poor, where things move (uMot), where the difference is large compared with the
     *  local texture (uTol) and where the 3x3 averages of old and new differ (uTolL: a fade, a flash or a cut is not noise, so the
     *  old picture is dropped at once). uSp: in still flat areas the grain that is left is smoothed spatially as well.
     *  uMv: rg = motion in pixels (/40 + 0.5), b = match error. */
    const val TEMPORAL = """#version 300 es
precision highp float;
uniform sampler2D uCur;uniform sampler2D uHist;uniform sampler2D uMv;uniform vec2 uInv;
uniform float uAmt;uniform float uTol;uniform float uSp;uniform float uMot;uniform float uClip;uniform float uSig;uniform float uTolL;
in highp vec2 vUv;out vec4 outColor;
vec3 hist(vec2 uv){
 vec2 pos=uv/uInv;vec2 c=floor(pos-0.5)+0.5;vec2 f=pos-c;vec2 f2=f*f;vec2 f3=f2*f;
 vec2 w0=-0.5*f3+f2-0.5*f;vec2 w1=1.5*f3-2.5*f2+1.0;vec2 w2=-1.5*f3+2.0*f2+0.5*f;vec2 w3=0.5*f3-0.5*f2;
 vec2 w12=w1+w2;vec2 t0=(c-1.0)*uInv;vec2 t3=(c+2.0)*uInv;vec2 t12=(c+w2/w12)*uInv;
 vec3 r=texture(uHist,vec2(t12.x,t0.y)).rgb*(w12.x*w0.y)+texture(uHist,vec2(t0.x,t12.y)).rgb*(w0.x*w12.y)+texture(uHist,t12).rgb*(w12.x*w12.y)+texture(uHist,vec2(t3.x,t12.y)).rgb*(w3.x*w12.y)+texture(uHist,vec2(t12.x,t3.y)).rgb*(w12.x*w3.y);
 float ws=w12.x*w0.y+w0.x*w12.y+w12.x*w12.y+w3.x*w12.y+w12.x*w3.y;
 return max(r/ws,vec3(0.0));
}
void main(){
 vec3 cc=texture(uCur,vUv).rgb;
 vec4 m=texture(uMv,vUv);
 if(m.b>0.8){outColor=vec4(cc,1.0);return;}
 vec2 d=(m.rg-0.50196)*40.0;
 float dl=length(d);
 if(dl>16.0){outColor=vec4(cc,1.0);return;}
 vec2 hb=vUv-d*uInv;
 vec3 h=hist(hb);
 vec3 s1=vec3(0.0),s2=vec3(0.0),hs=vec3(0.0);
 for(int j=-1;j<=1;j++)for(int i=-1;i<=1;i++){vec2 o=vec2(float(i),float(j))*uInv;vec3 v=texture(uCur,vUv+o).rgb;s1+=v;s2+=v*v;hs+=texture(uHist,hb+o).rgb;}
 vec3 mu=s1/9.0;vec3 sd=sqrt(max(s2/9.0-mu*mu,0.0));
 float lc=length(sd);
 vec3 sg=max(sd,vec3(uSig));
 vec3 hc=clamp(h,mu-uClip*sg,mu+uClip*sg);
 float diff=length(hc-cc);
 float dL=length(hs/9.0-mu);
 float tol=uTol*(1.0+2.0*lc);
 float conf=1.0-smoothstep(0.15,0.45,m.b);
 float still=1.0-uMot*smoothstep(0.25,1.5,dl);
 float w=uAmt*still*conf*exp(-(diff*diff)/(tol*tol))*exp(-(dL*dL)/(uTolL*uTolL));
 vec3 r=mix(cc,hc,w);
 float calm=(1.0-smoothstep(0.03,0.14,lc))*w;
 r=mix(r,mu,uSp*calm);
 outColor=vec4(r,1.0);}
"""

    /** Edge refinement after the Lanczos upscale: along every edge the picture is smoothed (removes stair-steps),
     *  across it nothing is touched; the sharpening that follows then makes the edge crisp. */
    const val EDGE_REFINE = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform vec2 uInv;
uniform float uR;
uniform float uSkipR;
in highp vec2 vUv;
out vec4 outColor;
float lum(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
void main() {
    vec4 c4 = texture(uSrc, vUv);
    // flat area (alpha from the back-projection pass): nothing to smooth, saves the 8 neighbour reads
    if (c4.a < uSkipR) { outColor = c4; return; }
    vec3 c = c4.rgb;
    float tl = lum(texture(uSrc, vUv + vec2(-1.0, -1.0) * uInv).rgb);
    float tc = lum(texture(uSrc, vUv + vec2(0.0, -1.0) * uInv).rgb);
    float tr = lum(texture(uSrc, vUv + vec2(1.0, -1.0) * uInv).rgb);
    float ml = lum(texture(uSrc, vUv + vec2(-1.0, 0.0) * uInv).rgb);
    float mr = lum(texture(uSrc, vUv + vec2(1.0, 0.0) * uInv).rgb);
    float bl = lum(texture(uSrc, vUv + vec2(-1.0, 1.0) * uInv).rgb);
    float bc = lum(texture(uSrc, vUv + vec2(0.0, 1.0) * uInv).rgb);
    float br = lum(texture(uSrc, vUv + vec2(1.0, 1.0) * uInv).rgb);
    float lcn = lum(c);
    float mxl = max(max(max(max(lcn, tl), max(tc, tr)), max(max(ml, mr), max(bl, bc))), br);
    float mnl = min(min(min(min(lcn, tl), min(tc, tr)), min(min(ml, mr), min(bl, bc))), br);
    float rng = clamp((mxl - mnl) * 8.0, 0.0, 1.0);
    float gx = (tr + 2.0 * mr + br) - (tl + 2.0 * ml + bl);
    float gy = (bl + 2.0 * bc + br) - (tl + 2.0 * tc + tr);
    float m = length(vec2(gx, gy));
    if (m < 0.04) { outColor = vec4(c, rng); return; }
    vec2 n = vec2(gx, gy) / m;
    vec2 t = vec2(-n.y, n.x) * uInv * uR;
    // 1) smooth along the edge: removes the stair-steps of the enlargement
    vec3 s = c * 3.0
        + (texture(uSrc, vUv + t * 0.5).rgb + texture(uSrc, vUv - t * 0.5).rgb) * 2.5
        + (texture(uSrc, vUv + t).rgb + texture(uSrc, vUv - t).rgb) * 1.5
        + (texture(uSrc, vUv + t * 1.5).rgb + texture(uSrc, vUv - t * 1.5).rgb) * 0.5;
    s /= 12.0;
    float k = smoothstep(0.15, 0.6, m) * 0.35; // only clear edges are smoothed: texture stays crisp
    vec3 r = mix(c, s, k);
    outColor = vec4(r, rng);
}
"""

    /** CRSC finishing sharpen: an unsharp mask whose radius follows the enlargement factor (an enlarged picture is blurred
     *  over about that many pixels, which RCAS's fixed 1-pixel reach cannot undo). It works on mid-contrast detail,
     *  leaves flat areas (noise) and already strong edges (halos) alone, and never overshoots the local range. */
    const val CRSC_SHARP = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform vec2 uInv;
uniform float uR;
uniform float uAmt;
uniform float uOver;
uniform float uSkip;
in highp vec2 vUv;
out vec4 outColor;
float lum(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
void main() {
    vec4 c4 = texture(uSrc, vUv);
    // flat area: the boost would be zero anyway, saves the 8 neighbour reads
    if (c4.a < uSkip) { outColor = c4; return; }
    vec3 c = c4.rgb;
    vec2 r = uInv * uR;
    vec3 n = texture(uSrc, vUv + vec2(0.0, -1.0) * r).rgb;
    vec3 s = texture(uSrc, vUv + vec2(0.0, 1.0) * r).rgb;
    vec3 w = texture(uSrc, vUv + vec2(-1.0, 0.0) * r).rgb;
    vec3 e = texture(uSrc, vUv + vec2(1.0, 0.0) * r).rgb;
    vec3 nw = texture(uSrc, vUv + vec2(-1.0, -1.0) * r).rgb;
    vec3 ne = texture(uSrc, vUv + vec2(1.0, -1.0) * r).rgb;
    vec3 sw = texture(uSrc, vUv + vec2(-1.0, 1.0) * r).rgb;
    vec3 se = texture(uSrc, vUv + vec2(1.0, 1.0) * r).rgb;
    vec3 blur = (c * 4.0 + (n + s + w + e) * 2.0 + nw + ne + sw + se) / 16.0;
    float d = lum(c) - lum(blur);
    float a = abs(d);
    float gain = uAmt * smoothstep(0.008, 0.05, a) * (1.0 - smoothstep(0.22, 0.5, a));
    vec3 o = c + (c - blur) * gain;
    vec3 lo = min(min(min(n, s), min(w, e)), c);
    vec3 hi = max(max(max(n, s), max(w, e)), c);
    outColor = vec4(clamp(o, lo - uOver, hi + uOver), c4.a);
}
"""

    /** CRSC back-projection: shrink the big picture back to the source size. */
    const val CRSC_DOWN = """#version 300 es
precision highp float;
uniform sampler2D uSrc;uniform vec2 uInv; // uInv = 1/low size
in highp vec2 vUv;out vec4 outColor;
void main(){vec2 o=uInv*0.25;
vec3 s=texture(uSrc,vUv+vec2(-o.x,-o.y)).rgb+texture(uSrc,vUv+vec2(o.x,-o.y)).rgb+texture(uSrc,vUv+vec2(-o.x,o.y)).rgb+texture(uSrc,vUv+vec2(o.x,o.y)).rgb;
outColor=vec4(s*0.25,1.0);}
"""

    /** CRSC back-projection: add (source - shrunk picture) back, limited to the source's local range (no ringing). */
    const val CRSC_BP = """#version 300 es
precision highp float;
uniform sampler2D uSrc;uniform sampler2D uLow;uniform sampler2D uD;uniform vec2 uInv;uniform float uG;
in highp vec2 vUv;out vec4 outColor;
void main(){vec3 u=texture(uSrc,vUv).rgb;
vec3 e=texture(uLow,vUv).rgb-texture(uD,vUv).rgb;
// local range of the low-res picture: the result may not leave it by much (no ringing)
vec3 lo=vec3(1.0),hi=vec3(0.0);
for(int j=-1;j<=1;j++)for(int i=-1;i<=1;i++){vec3 v=texture(uLow,vUv+vec2(float(i),float(j))*uInv).rgb;lo=min(lo,v);hi=max(hi,v);}
// small and medium errors are mostly compression noise (blocks, ringing): fade the correction out there, keep it for real edges
float tr=smoothstep(0.002,0.08,max(abs(e.r),max(abs(e.g),abs(e.b))));
vec3 r=u+e*uG*tr;
// alpha carries how flat the neighbourhood is (range x 8): the next passes skip flat pixels
float rg=max(hi.r-lo.r,max(hi.g-lo.g,hi.b-lo.b));
outColor=vec4(clamp(r,lo-0.03,hi+0.03),clamp(rg*8.0,0.0,1.0));}
"""

    /** CRSC Edge, the steepening step (a "shock filter"): across a soft edge, a pixel on the foot of the ramp takes the
     *  value of its darker neighbour, a pixel on the shoulder the brighter one. The ramp gets narrower, the edge crisp,
     *  and since only values that are already in the picture are used there is no overshoot and no halo. Flat areas
     *  and the middle of a ramp are left alone; the enlargement factor sets how far across the edge it looks. */
    const val EDGE_SHOCK = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform vec2 uInv;
uniform float uR;
uniform float uAmt;
uniform float uSkip;
in highp vec2 vUv;
out vec4 outColor;
float lum(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
void main() {
    vec4 c4 = texture(uSrc, vUv);
    // flat area: its gradient is below the threshold anyway, saves the 8 neighbour reads
    if (c4.a < uSkip) { outColor = vec4(c4.rgb, 1.0); return; }
    vec3 c = c4.rgb;
    float tl = lum(texture(uSrc, vUv + vec2(-1.0, -1.0) * uInv).rgb);
    float tc = lum(texture(uSrc, vUv + vec2(0.0, -1.0) * uInv).rgb);
    float tr = lum(texture(uSrc, vUv + vec2(1.0, -1.0) * uInv).rgb);
    float ml = lum(texture(uSrc, vUv + vec2(-1.0, 0.0) * uInv).rgb);
    float mr = lum(texture(uSrc, vUv + vec2(1.0, 0.0) * uInv).rgb);
    float bl = lum(texture(uSrc, vUv + vec2(-1.0, 1.0) * uInv).rgb);
    float bc = lum(texture(uSrc, vUv + vec2(0.0, 1.0) * uInv).rgb);
    float br = lum(texture(uSrc, vUv + vec2(1.0, 1.0) * uInv).rgb);
    float gx = (tr + 2.0 * mr + br) - (tl + 2.0 * ml + bl);
    float gy = (bl + 2.0 * bc + br) - (tl + 2.0 * tc + tr);
    float m = length(vec2(gx, gy));
    if (m < 0.1) { outColor = vec4(c, 1.0); return; }
    vec2 n = vec2(gx, gy) / m;
    vec2 st = n * uInv * clamp(0.5 * uR, 0.75, 2.0);
    vec3 a = texture(uSrc, vUv + st).rgb;
    vec3 b = texture(uSrc, vUv - st).rgb;
    float lc = lum(c);
    float la = lum(a);
    float lb = lum(b);
    float lap = la + lb - 2.0 * lc;
    vec3 t = (lap > 0.0) ? ((la < lb) ? a : b) : ((la > lb) ? a : b);
    float edge = smoothstep(0.2, 0.8, m);
    float conv = smoothstep(0.01, 0.06, abs(lap));
    outColor = vec4(mix(c, t, uAmt * edge * conv), 1.0);
}
"""

    /** NIS Lite (3.46.0): a light, cleaner and more natural take on NIS. NIS ideas kept (edge-directed filtering, contrast-adaptive
     *  sharpening with limits) plus FSR 1 style cleaning along edges and CRSC style fidelity (the sharpening never goes past the local
     *  range). 16 fetches + 1 bilinear tap per pixel (the original: 36 fetches, 4 edge tests and two 384-float tables). Designed and
     *  measured offline, see README 3.46.0. 3.99.46: the same picture for less work (no direction / extra cubics / Gaussian where they
     *  cannot change the result, 4 instead of 8 exp, rows and columns clamped once), see README 3.99.46. */
    const val NIS = """#version 300 es
precision highp float;
precision highp int;
uniform sampler2D uSrc;
uniform ivec2 uSrcSize;
uniform float uSharp; // 0..1 (the sharpness slider)
uniform float uFactor; // enlargement factor (output size / source size)
uniform float uGain; // 1.0 = normal push, lower = gentler (NIS Lite soft: dark / soft pictures)
uniform float uClean; // 0 = off; NIS Lite soft: pull flat, low-contrast areas toward their smooth value (removes dither / grain / compression noise)
in highp vec2 vUv;
out vec4 outColor;

float lumaOf(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
float fetchY(ivec2 p) { return lumaOf(texelFetch(uSrc, clamp(p, ivec2(0), uSrcSize - ivec2(1)), 0).rgb); }
// Keys cubic (a = -0.5, Catmull-Rom)
vec4 keys4(float u) {
    vec4 d = abs(vec4(u + 1.0, u, u - 1.0, u - 2.0));
    vec4 n = ((-0.5 * d + 2.5) * d - 4.0) * d + 2.0;
    vec4 m = (1.5 * d - 2.5) * d * d + 1.0;
    vec4 w = mix(m, n, step(1.0, d)) * (1.0 - step(2.0, d));
    return w / (w.x + w.y + w.z + w.w);
}
// the 4x4 window (rows r0..r3 = y-1..y+2, columns x-1..x+2), filled in main()
vec4 r0, r1, r2, r3;
// cubic value at u (cell coordinates: 0..1 is the middle cell; a little outside is fine, the weights are renormalised)
float cubicAt(vec2 u) {
    vec4 wx = keys4(u.x);
    vec4 wy = keys4(u.y);
    return dot(wy, vec4(dot(r0, wx), dot(r1, wx), dot(r2, wx), dot(r3, wx)));
}
// Gaussian-weighted mean of the window at cell position u (sigma given as 1 / (2 sigma^2))
float gaussAt(vec2 u, float k) {
    vec4 dx = vec4(u.x + 1.0, u.x, u.x - 1.0, u.x - 2.0);
    vec4 dy = vec4(u.y + 1.0, u.y, u.y - 1.0, u.y - 2.0);
    vec4 gx = exp(-dx * dx * k);
    vec4 gy = exp(-dy * dy * k);
    gx /= (gx.x + gx.y + gx.z + gx.w);
    gy /= (gy.x + gy.y + gy.z + gy.w);
    return dot(gy, vec4(dot(r0, gx), dot(r1, gx), dot(r2, gx), dot(r3, gx)));
}
void main() {
    vec2 srcP = vUv * vec2(uSrcSize) - 0.5;
    ivec2 i0 = ivec2(floor(srcP));
    vec2 fr = srcP - vec2(i0);
    r0 = vec4(fetchY(i0 + ivec2(-1, -1)), fetchY(i0 + ivec2(0, -1)), fetchY(i0 + ivec2(1, -1)), fetchY(i0 + ivec2(2, -1)));
    r1 = vec4(fetchY(i0 + ivec2(-1, 0)), fetchY(i0), fetchY(i0 + ivec2(1, 0)), fetchY(i0 + ivec2(2, 0)));
    r2 = vec4(fetchY(i0 + ivec2(-1, 1)), fetchY(i0 + ivec2(0, 1)), fetchY(i0 + ivec2(1, 1)), fetchY(i0 + ivec2(2, 1)));
    r3 = vec4(fetchY(i0 + ivec2(-1, 2)), fetchY(i0 + ivec2(0, 2)), fetchY(i0 + ivec2(1, 2)), fetchY(i0 + ivec2(2, 2)));

    // 1) edge direction: structure tensor at the four middle pixels, interpolated to this position
    vec2 g11 = vec2(r1.z - r1.x, r2.y - r0.y);
    vec2 g12 = vec2(r1.w - r1.y, r2.z - r0.z);
    vec2 g21 = vec2(r2.z - r2.x, r3.y - r1.y);
    vec2 g22 = vec2(r2.w - r2.y, r3.z - r1.z);
    vec3 t11 = vec3(g11 * g11, g11.x * g11.y);
    vec3 t12 = vec3(g12 * g12, g12.x * g12.y);
    vec3 t21 = vec3(g21 * g21, g21.x * g21.y);
    vec3 t22 = vec3(g22 * g22, g22.x * g22.y);
    vec3 J = mix(mix(t11, t12, fr.x), mix(t21, t22, fr.x), fr.y);
    float diffJ = J.x - J.y;
    float disc = sqrt(diffJ * diffJ + 4.0 * J.z * J.z);
    float l1 = 0.5 * (J.x + J.y + disc);
    float l2 = 0.5 * (J.x + J.y - disc);
    float coh = (l1 - l2) / (l1 + l2 + 1e-6);
    vec2 nrm = vec2(diffJ + disc, 2.0 * J.z);
    nrm /= (length(nrm) + 1e-9);
    vec2 tang = vec2(-nrm.y, nrm.x);
    float g = smoothstep(0.15, 0.6, coh) * smoothstep(0.02, 0.10, sqrt(max(l1, 0.0)));

    // 2) reconstruction: cubic, then cleaned along the edge (removes stair-steps, keeps the edge itself sharp)
    float yc = cubicAt(fr);
    float ya = cubicAt(fr + tang * 0.5);
    float yb = cubicAt(fr - tang * 0.5);
    // exactly horizontal / vertical edges (text, UI, HUD) have no stair-steps: no smoothing along them, so thin strokes stay crisp
    float diag = smoothstep(0.01, 0.12, 1.0 - abs(nrm.x * nrm.x - nrm.y * nrm.y));
    float ys = mix(yc, 0.5 * yc + 0.25 * (ya + yb), 0.7 * g * diag);

    float fct = clamp(uFactor, 1.25, 4.0);

    // 3) natural, limited sharpening: one unsharp mask against a Gaussian of the same window
    // the more the picture is enlarged, the wider the soft reference and the stronger the push (tuned at x2 on synthetic and x3 on real 360p frames)
    float sg = 0.288 + 0.144 * fct;
    float blur = gaussAt(fr, 1.0 / (2.0 * sg * sg));
    float lo = min(min(r1.y, r1.z), min(r2.y, r2.z));
    float hi = max(max(r1.y, r1.z), max(r2.y, r2.z));
    // local contrast for the gate / guard / overshoot: per-pixel plus-shaped range at the four middle pixels, interpolated, so it has no
    // jump at the borders of source pixels (a range taken from the 2x2 cell jumped there: up to ~20/255 of speckle at exact x3)
    float mn11 = min(min(min(r1.y, r0.y), min(r2.y, r1.x)), r1.z);
    float mx11 = max(max(max(r1.y, r0.y), max(r2.y, r1.x)), r1.z);
    float mn12 = min(min(min(r1.z, r0.z), min(r2.z, r1.y)), r1.w);
    float mx12 = max(max(max(r1.z, r0.z), max(r2.z, r1.y)), r1.w);
    float mn21 = min(min(min(r2.y, r1.y), min(r3.y, r2.x)), r2.z);
    float mx21 = max(max(max(r2.y, r1.y), max(r3.y, r2.x)), r2.z);
    float mn22 = min(min(min(r2.z, r1.z), min(r3.z, r2.y)), r2.w);
    float mx22 = max(max(max(r2.z, r1.z), max(r3.z, r2.y)), r2.w);
    float rng = mix(mix(mx11, mx12, fr.x), mix(mx21, mx22, fr.x), fr.y) - mix(mix(mn11, mn12, fr.x), mix(mn21, mn22, fr.x), fr.y);
    float det = ys - blur;
    det = det / (1.0 + abs(det) * 7.14);                        // soft limit: big details are not exaggerated
    float gate = smoothstep(0.01, 0.08, rng);                  // flat / noisy areas are left alone
    float guard = 1.0 - 0.25 * smoothstep(0.25, 0.6, rng);      // less push on edges that are already strong (no halos)
    float k = 0.15 + 0.85 * clamp(uSharp, 0.0, 1.0);
    float yo = ys + k * gate * guard * ((0.32 * fct + 1.76) * uGain * det);
    yo = mix(yo, blur, uClean * (1.0 - smoothstep(0.03, 0.15, rng)));   // soft mode only: calm flat areas (noise, dither), edges are untouched
    float ov = 0.35 * rng + 0.004;
    yo = clamp(yo, lo - ov, hi + ov);                           // never far past the local range (fidelity, no ringing)

    vec3 op = texture(uSrc, (srcP + 0.5) / vec2(uSrcSize)).rgb;
    outColor = vec4(clamp(op + (yo - lumaOf(op)), 0.0, 1.0), 1.0);
}
"""

    /**
     * NIS (original) sharpener for scale 1 only (the picture is already at its final size): gives the same result as [NIS_ORIG] with
     * uScale = 1, much lighter. At scale 1 every filter phase is 0, so the two 384-entry coefficient tables collapse to the constants
     * (0, 1, 0, ...) for the plain filter and (-0.6001, 1.2002, -0.6001) for the sharpening one, the 6x6 window array (dynamic indexing, slow on
     * phones) is not needed, and only the pixels of the edge direction that was detected are read. Pixels without an edge cost 9 reads.
     */
    const val NIS_SHARP1 = """#version 300 es
precision highp float;
precision highp int;
uniform sampler2D uSrc;
uniform ivec2 uSrcSize;
uniform float uSharp; // 0..1 (NIS "sharpness")
in highp vec2 vUv;
out vec4 outColor;
ivec2 gC;
float Y(int dx, int dy) {
    ivec2 q = clamp(gC + ivec2(dx, dy), ivec2(0), uSrcSize - ivec2(1));
    vec3 c = texelFetch(uSrc, q, 0).rgb;
    return 0.2126 * c.x + 0.7152 * c.y + 0.0722 * c.z;
}
float kSharpStartY, kSharpScaleY, kSharpStrengthMin, kSharpStrengthScale, kSharpLimitMin, kSharpLimitScale;
const float kMinContrastRatio = 2.0, kRatioNorm = 1.0 / 8.0, kEps = 1.0 / 255.0;
void setupCfg() {
    float sl = uSharp - 0.5;
    float MaxScale = sl >= 0.0 ? 1.25 : 1.75, MinScale = sl >= 0.0 ? 1.25 : 1.0, LimitScale = sl >= 0.0 ? 1.25 : 1.0;
    kSharpStartY = 0.45;
    kSharpScaleY = 1.0 / (0.9 - 0.45);
    kSharpStrengthMin = max(0.0, 0.4 + sl * MinScale * 1.2);
    float smax = 1.6 + sl * MaxScale * 1.8;
    kSharpStrengthScale = smax - kSharpStrengthMin;
    kSharpLimitMin = max(0.1, 0.14 + sl * LimitScale * 0.32);
    float lmax = 0.5 + sl * LimitScale * 0.6;
    kSharpLimitScale = lmax - kSharpLimitMin;
}
float calcLTI(float p0, float p1, float p2, float p3, float p4, float p5) {
    float amin = min(min(p1, p2), p0), amax = max(max(p1, p2), p0);
    float bmin = min(min(p3, p4), p2), bmax = max(max(p3, p4), p2);
    float ac = amax - amin, bc = bmax - bmin;
    float cr = max(ac, bc) / (min(ac, bc) + kEps);
    return 1.0 - clamp((cr - kMinContrastRatio) * kRatioNorm, 0.0, 1.0);
}
float poly(float x0, float x1, float x2, float x3, float x4, float x5) {
    float y = x2;
    float yu = -0.6001 * x1 + 1.2002 * x2 - 0.6001 * x3;
    float ys = 1.0 - clamp((y - kSharpStartY) * kSharpScaleY, 0.0, 1.0);
    yu *= ys * kSharpStrengthScale + kSharpStrengthMin;
    float lim = (ys * kSharpLimitScale + kSharpLimitMin) * y;
    yu = min(lim, max(-lim, yu));
    yu *= calcLTI(x0, x1, x2, x3, x4, x5);
    return y + yu;
}
void main() {
    gC = ivec2(vUv * vec2(uSrcSize));
    gC = clamp(gC, ivec2(0), uSrcSize - ivec2(1));
    vec3 op = texelFetch(uSrc, gC, 0).rgb;
    float ctr = 0.2126 * op.x + 0.7152 * op.y + 0.0722 * op.z;
    // edge direction from the 3x3 luma window
    float a00 = Y(-1, -1), a01 = Y(0, -1), a02 = Y(1, -1);
    float a10 = Y(-1, 0), a12 = Y(1, 0);
    float a20 = Y(-1, 1), a21 = Y(0, 1), a22 = Y(1, 1);
    float g0 = abs(a00 + a01 + a02 - a20 - a21 - a22);
    float g45 = abs(a10 + a00 + a01 - a21 - a22 - a12);
    float g90 = abs(a00 + a10 + a20 - a02 - a12 - a22);
    float g135 = abs(a10 + a20 + a21 - a01 - a02 - a12);
    float m1 = max(g0, g90), n1 = min(g0, g90), m2 = max(g45, g135), n2 = min(g45, g135);
    if (m1 + m2 == 0.0) { outColor = vec4(op, 1.0); return; }
    float e0 = min(m1 / (m1 + m2), 1.0);
    float e45 = 1.0 - e0;
    float kDetectRatio = 2.0 * 1127.0 / 1024.0, kDetectThres = 64.0 / 1024.0;
    bool c1 = (m1 > n1 * kDetectRatio) && (m1 > kDetectThres) && (m1 > n2);
    bool c2 = (m2 > n2 * kDetectRatio) && (m2 > kDetectThres) && (m2 > n1);
    bool cg0 = m1 == g0, cg45 = m2 == g45;
    float f0 = (c1 && c2) ? e0 : 1.0;
    float f45 = (c1 && c2) ? e45 : 1.0;
    vec4 w = vec4((c1 && cg0) ? f0 : 0.0, (c1 && !cg0) ? f0 : 0.0, (c2 && cg45) ? f45 : 0.0, (c2 && !cg45) ? f45 : 0.0);
    float wsum = w.x + w.y + w.z + w.w;
    if (wsum <= 0.0) { outColor = vec4(op, 1.0); return; }
    setupCfg();
    float opY = ctr * (1.0 - wsum);
    if (w.x > 0.0) { // 0 deg: the column
        opY += poly(Y(0, -2), Y(0, -1), ctr, Y(0, 1), Y(0, 2), Y(0, 3)) * w.x;
    }
    if (w.y > 0.0) { // 90 deg: the row
        opY += poly(Y(-2, 0), Y(-1, 0), ctr, Y(1, 0), Y(2, 0), Y(3, 0)) * w.y;
    }
    if (w.z > 0.0) { // 45 deg
        float t0 = a00;
        float t1 = 0.5 * (a10 + a01);
        float t3 = 0.5 * (a21 + a12);
        float t4 = a22;
        float t5 = 0.5 * (Y(1, 2) + Y(2, 1));
        opY += poly(t0, t1, ctr, t3, t4, t5) * w.z;
    }
    if (w.w > 0.0) { // 135 deg
        float t1 = a20;
        float t2 = 0.5 * (a21 + a10);
        float t3 = ctr;
        float t4 = 0.5 * (a12 + a01);
        float t5 = a02;
        float t6 = 0.5 * (Y(2, -1) + Y(1, -2));
        opY += poly(t1, t2, t3, t4, t5, t6) * w.w;
    }
    float corr = opY - ctr;
    outColor = vec4(clamp(op + corr, 0.0, 1.0), 1.0);
}
"""

    /**
     * "Crisp Fast": the same picture as [NIS_SHARP1] (the Standard NIS crispness sharpener), computed with less work:
     *  - the 8 neighbours are read once with only 3 + 3 coordinate clamps (Standard clamps every read) and the values already read are
     *    reused by the direction filters (Standard asks for 4 of them again);
     *  - the strength / limit constants come in as one uniform ([uCfg], worked out once on the CPU) instead of ~20 operations per pixel;
     *  - the filter maths in poly() (division, clamps, limits) runs in half precision (mediump: twice the ALU speed and fewer registers on
     *    Adreno / Mali). The edge detection and the pixel colour stay full precision, so the same pixels are sharpened as in Standard
     *    and the result differs by at most 1-2 / 255 (checked with half precision emulated, see README 3.89.6).
     * Same uniforms as NIS_SHARP1 except uCfg = vec4(strength min, strength scale, limit min, limit scale) instead of uSharp.
     */
    const val NIS_CRISP_FAST = """#version 300 es
precision highp float;
precision highp int;
uniform sampler2D uSrc;
uniform ivec2 uSrcSize;
uniform vec4 uCfg; // x strength min, y strength scale, z limit min, w limit scale
in highp vec2 vUv;
out vec4 outColor;
const float kEps = 1.0 / 255.0;
ivec2 gC, gMax;
// same formula as Standard (a built-in dot product rounds differently and flipped edge decisions on borderline pixels)
float lum(vec3 c) { return 0.2126 * c.x + 0.7152 * c.y + 0.0722 * c.z; }
float Y(int dx, int dy) {
    return lum(texelFetch(uSrc, clamp(gC + ivec2(dx, dy), ivec2(0), gMax), 0).rgb);
}
mediump float poly(mediump float x0, mediump float x1, mediump float x2, mediump float x3, mediump float x4, mediump float x5) {
    mediump float yu = -0.6001 * (x1 + x3) + 1.2002 * x2;
    mediump float ys = 1.0 - clamp((x2 - 0.45) * 2.2222222, 0.0, 1.0);
    yu *= ys * uCfg.y + uCfg.x;
    mediump float lim = (ys * uCfg.w + uCfg.z) * x2;
    yu = min(lim, max(-lim, yu));
    mediump float amin = min(min(x1, x2), x0), amax = max(max(x1, x2), x0);
    mediump float bmin = min(min(x3, x4), x2), bmax = max(max(x3, x4), x2);
    mediump float ac = amax - amin, bc = bmax - bmin;
    mediump float cr = max(ac, bc) / (min(ac, bc) + kEps);
    return x2 + yu * (1.0 - clamp((cr - 2.0) * 0.125, 0.0, 1.0));
}
void main() {
    gMax = uSrcSize - ivec2(1);
    gC = clamp(ivec2(vUv * vec2(uSrcSize)), ivec2(0), gMax);
    int xm = max(gC.x - 1, 0), xp = min(gC.x + 1, gMax.x);
    int ym = max(gC.y - 1, 0), yp = min(gC.y + 1, gMax.y);
    highp vec3 op = texelFetch(uSrc, gC, 0).rgb;
    float ctr = lum(op);
    float a00 = lum(texelFetch(uSrc, ivec2(xm, ym), 0).rgb);
    float a01 = lum(texelFetch(uSrc, ivec2(gC.x, ym), 0).rgb);
    float a02 = lum(texelFetch(uSrc, ivec2(xp, ym), 0).rgb);
    float a10 = lum(texelFetch(uSrc, ivec2(xm, gC.y), 0).rgb);
    float a12 = lum(texelFetch(uSrc, ivec2(xp, gC.y), 0).rgb);
    float a20 = lum(texelFetch(uSrc, ivec2(xm, yp), 0).rgb);
    float a21 = lum(texelFetch(uSrc, ivec2(gC.x, yp), 0).rgb);
    float a22 = lum(texelFetch(uSrc, ivec2(xp, yp), 0).rgb);
    float g0 = abs(a00 + a01 + a02 - a20 - a21 - a22);
    float g45 = abs(a10 + a00 + a01 - a21 - a22 - a12);
    float g90 = abs(a00 + a10 + a20 - a02 - a12 - a22);
    float g135 = abs(a10 + a20 + a21 - a01 - a02 - a12);
    float m1 = max(g0, g90), n1 = min(g0, g90), m2 = max(g45, g135), n2 = min(g45, g135);
    const float kDetectRatio = 2.0 * 1127.0 / 1024.0, kDetectThres = 64.0 / 1024.0;
    bool c1 = (m1 > n1 * kDetectRatio) && (m1 > kDetectThres) && (m1 > n2);
    bool c2 = (m2 > n2 * kDetectRatio) && (m2 > kDetectThres) && (m2 > n1);
    if (!(c1 || c2)) { outColor = vec4(op, 1.0); return; }
    float e0 = min(m1 / (m1 + m2), 1.0);
    float e45 = 1.0 - e0;
    bool cg0 = m1 == g0, cg45 = m2 == g45;
    float f0 = (c1 && c2) ? e0 : 1.0;
    float f45 = (c1 && c2) ? e45 : 1.0;
    vec4 w = vec4((c1 && cg0) ? f0 : 0.0, (c1 && !cg0) ? f0 : 0.0, (c2 && cg45) ? f45 : 0.0, (c2 && !cg45) ? f45 : 0.0);
    float wsum = w.x + w.y + w.z + w.w;
    float opY = ctr * (1.0 - wsum);
    if (w.x > 0.0) opY += poly(Y(0, -2), a01, ctr, a21, Y(0, 2), Y(0, 3)) * w.x;
    if (w.y > 0.0) opY += poly(Y(-2, 0), a10, ctr, a12, Y(2, 0), Y(3, 0)) * w.y;
    if (w.z > 0.0) opY += poly(a00, 0.5 * (a10 + a01), ctr, 0.5 * (a21 + a12), a22, 0.5 * (Y(1, 2) + Y(2, 1))) * w.z;
    if (w.w > 0.0) opY += poly(a20, 0.5 * (a21 + a10), ctr, 0.5 * (a12 + a01), a02, 0.5 * (Y(2, -1) + Y(1, -2))) * w.w;
    outColor = vec4(clamp(op + (opY - ctr), 0.0, 1.0), 1.0);
}
"""

    /** NIS (fast): the original NIS algorithm and nearly the same picture, computed with less work (README 3.66.0, 3.89.7, 3.89.8). NF_LEVEL 0 exact, 1 medium, 2 light; GlPipeline sets it by replacing the define below. */
    const val NIS_FAST = """#version 300 es
#ifndef NF_LEVEL
#define NF_LEVEL 0
#endif
precision highp float;
precision highp int;
uniform sampler2D uSrc;
uniform ivec2 uSrcSize;
uniform vec2 uScale; // source size / output size
uniform float uSharp; // 0..1 (NIS "sharpness")
in highp vec2 vUv;
out vec4 outColor;
// The two 64-phase coefficient tables of NIS (scaler and USM, 6 taps each) as degree-5 polynomials of the phase (fitted, rows still sum to
// exactly 1 and 0): no 384-float arrays indexed at run time. Largest weight error 0.0007 (scaler) / 0.0024 (USM).
const vec3 CSA0 = vec3(-0.0001070, -0.0001231, 1.0003307), CSB0 = vec3(-0.0000579, 0.0000137, -0.0000564);
const vec3 CSA1 = vec3(0.2111275, -0.8236856, -0.0136663), CSB1 = vec3(0.8321093, -0.2093058, 0.0034209);
const vec3 CSA2 = vec3(-0.3595321, 1.1152461, -1.6231426), CSB2 = vec3(1.0873953, -0.2941929, 0.0742261);
const vec3 CSA3 = vec3(-0.1033663, 0.4642154, -0.6315029), CSB3 = vec3(0.0786781, -0.0453782, 0.2373540);
const vec3 CSA4 = vec3(0.4454886, -1.1876582, 2.0164189), CSB4 = vec3(-1.7626354, 0.9873137, -0.4989276);
const vec3 CSA5 = vec3(-0.1937280, 0.4320092, -0.7484854), CSB5 = vec3(0.7650846, -0.4386654, 0.1837849);
const vec3 CUA0 = vec3(-0.0001272, -0.5989534, 1.1988379), CUB0 = vec3(-0.6002660, 0.0005047, 0.0000040);
const vec3 CUA1 = vec3(0.1820147, -0.6219288, 0.0567186), CUB1 = vec3(0.5823822, -0.2004738, 0.0012870);
const vec3 CUA2 = vec3(-0.5162245, 3.5456529, -5.4805106), CUB2 = vec3(3.1779529, -0.7503817, 0.0235110);
const vec3 CUA3 = vec3(0.4841098, -2.4269653, 3.5860341), CUB3 = vec3(-0.3295057, -1.4427130, 0.1290401);
const vec3 CUA4 = vec3(-0.1451612, -0.5082092, 0.6368236), CUB4 = vec3(-2.1383435, 2.3060874, -0.1511971);
const vec3 CUA5 = vec3(-0.0046256, 0.6114838, -0.5985218), CUB5 = vec3(0.5055495, -0.5110171, -0.0028687);
void csW(int ph, out vec3 a, out vec3 b) {
    float t = float(ph) * (1.0 / 64.0);
    a = CSA0 + t * (CSA1 + t * (CSA2 + t * (CSA3 + t * (CSA4 + t * CSA5))));
    b = CSB0 + t * (CSB1 + t * (CSB2 + t * (CSB3 + t * (CSB4 + t * CSB5))));
}
void cuW(int ph, out vec3 a, out vec3 b) {
    float t = float(ph) * (1.0 / 64.0);
    a = CUA0 + t * (CUA1 + t * (CUA2 + t * (CUA3 + t * (CUA4 + t * CUA5))));
    b = CUB0 + t * (CUB1 + t * (CUB2 + t * (CUB3 + t * (CUB4 + t * CUB5))));
}

float getY(vec3 c) { return 0.2126 * c.x + 0.7152 * c.y + 0.0722 * c.z; }
float P[36];
float pp(int i, int j) { return P[i * 6 + j]; }
vec4 edgeAt(int i, int j) {
    // 3x3 window centred on support pixel (2+i, 2+j)
    int r = 1 + i, c = 1 + j;
    float a00 = pp(r, c), a01 = pp(r, c + 1), a02 = pp(r, c + 2);
    float a10 = pp(r + 1, c), a12 = pp(r + 1, c + 2);
    float a11 = pp(r + 1, c + 1);
    float a20 = pp(r + 2, c), a21 = pp(r + 2, c + 1), a22 = pp(r + 2, c + 2);
    float g0 = abs(a00 + a01 + a02 - a20 - a21 - a22);
    float g45 = abs(a10 + a00 + a01 - a21 - a22 - a12);
    float g90 = abs(a00 + a10 + a20 - a02 - a12 - a22);
    float g135 = abs(a10 + a20 + a21 - a01 - a02 - a12);
    float m1 = max(g0, g90), n1 = min(g0, g90), m2 = max(g45, g135), n2 = min(g45, g135);
#ifdef NF_REFINE
    // "NIS fast (clean)": a little less eager than the original (2.0 / 64): on noisy low-quality video the original picks a direction in the noise and the lines turn wavy
    float kDetectRatio = 2.5 * 1127.0 / 1024.0, kDetectThres = 88.0 / 1024.0;
#else
    float kDetectRatio = 2.0 * 1127.0 / 1024.0, kDetectThres = 64.0 / 1024.0;
#endif
    bool c1 = (m1 > n1 * kDetectRatio) && (m1 > kDetectThres) && (m1 > n2);
    bool c2 = (m2 > n2 * kDetectRatio) && (m2 > kDetectThres) && (m2 > n1);
    if (!c1 && !c2) return vec4(0.0); // nothing fires (this includes m1 + m2 == 0): all four weights are 0, as before
    float e0 = min(m1 / (m1 + m2), 1.0);
    float e45 = 1.0 - e0;
    bool cg0 = m1 == g0, cg45 = m2 == g45;
    float f0 = (c1 && c2) ? e0 : 1.0;
    float f45 = (c1 && c2) ? e45 : 1.0;
    return vec4((c1 && cg0) ? f0 : 0.0, (c1 && !cg0) ? f0 : 0.0, (c2 && cg45) ? f45 : 0.0, (c2 && !cg45) ? f45 : 0.0);
}
// sharpening constants (SDR) from NVScalerUpdateConfig
float kSharpStartY, kSharpScaleY, kSharpStrengthMin, kSharpStrengthScale, kSharpLimitMin, kSharpLimitScale;
const float kMinContrastRatio = 2.0, kRatioNorm = 1.0 / 8.0, kEps = 1.0 / 255.0;
void setupCfg() {
    float sl = uSharp - 0.5;
    float MaxScale = sl >= 0.0 ? 1.25 : 1.75, MinScale = sl >= 0.0 ? 1.25 : 1.0, LimitScale = sl >= 0.0 ? 1.25 : 1.0;
    kSharpStartY = 0.45;
    kSharpScaleY = 1.0 / (0.9 - 0.45);
    kSharpStrengthMin = max(0.0, 0.4 + sl * MinScale * 1.2);
    float smax = 1.6 + sl * MaxScale * 1.8;
    kSharpStrengthScale = smax - kSharpStrengthMin;
    kSharpLimitMin = max(0.1, 0.14 + sl * LimitScale * 0.32);
    float lmax = 0.5 + sl * LimitScale * 0.6;
    kSharpLimitScale = lmax - kSharpLimitMin;
}
float calcLTI(float p0, float p1, float p2, float p3, float p4, float p5, int ph) {
    bool sel = ph <= 32;
    float s = sel ? p0 : p3;
    float amin = min(min(p1, p2), s), amax = max(max(p1, p2), s);
    s = sel ? p2 : p5;
    float bmin = min(min(p3, p4), s), bmax = max(max(p3, p4), s);
    float ac = amax - amin, bc = bmax - bmin;
    float cr = max(ac, bc) / (min(ac, bc) + kEps);
    return 1.0 - clamp((cr - kMinContrastRatio) * kRatioNorm, 0.0, 1.0);
}
float evalPoly6w(float x0, float x1, float x2, float x3, float x4, float x5, int ph, vec3 sa, vec3 sb) {
    vec3 ua, ub;
    cuW(ph, ua, ub);
    vec3 xa = vec3(x0, x1, x2), xb = vec3(x3, x4, x5);
    float y = dot(xa, sa) + dot(xb, sb);
    float yu = dot(xa, ua) + dot(xb, ub);
    float ys = 1.0 - clamp((y - kSharpStartY) * kSharpScaleY, 0.0, 1.0);
    yu *= ys * kSharpStrengthScale + kSharpStrengthMin;
    float lim = (ys * kSharpLimitScale + kSharpLimitMin) * y;
    yu = min(lim, max(-lim, yu));
    yu *= calcLTI(x0, x1, x2, x3, x4, x5, ph);
#ifdef NF_REFINE
    // noise gate: in a calm area the sharpening only makes the compression noise bigger ("oily" blotches), so it fades out there
    float rg = max(max(max(x0, x1), max(x2, x3)), max(x4, x5)) - min(min(min(x0, x1), min(x2, x3)), min(x4, x5));
    yu *= 0.85 * mix(0.2, 1.0, smoothstep(0.02, 0.09, rg));
#endif
    return y + yu;
}
float evalPoly6(float x0, float x1, float x2, float x3, float x4, float x5, int ph) {
    vec3 sa, sb;
    csW(ph, sa, sb);
    return evalPoly6w(x0, x1, x2, x3, x4, x5, ph, sa, sb);
}
void main() {
    setupCfg();
    vec2 dst = vUv * vec2(uSrcSize) / uScale; // output pixel coordinate (+0.5 at centres)
    vec2 srcP = dst * uScale - 0.5;
    ivec2 i0 = ivec2(floor(srcP));
    vec2 fr = srcP - vec2(i0);
    ivec2 fi = ivec2(fr * 64.0);
    ivec2 b0 = i0 - ivec2(2);
    bool inside = b0.x >= 0 && b0.y >= 0 && b0.x + 5 < uSrcSize.x && b0.y + 5 < uSrcSize.y;
#define FY(a, b) getY(texelFetchOffset(uSrc, b0, 0, ivec2(a, b)).rgb)
#define FB(a, b) getY(texelFetch(uSrc, clamp(i0 + ivec2(a - 2, b - 2), ivec2(0), uSrcSize - ivec2(1)), 0).rgb)
#if NF_LEVEL >= 1
    if (inside) {
        P[7] = FY(1, 1); P[8] = FY(2, 1); P[9] = FY(3, 1); P[10] = FY(4, 1);
        P[13] = FY(1, 2); P[14] = FY(2, 2); P[15] = FY(3, 2); P[16] = FY(4, 2);
        P[19] = FY(1, 3); P[20] = FY(2, 3); P[21] = FY(3, 3); P[22] = FY(4, 3);
        P[25] = FY(1, 4); P[26] = FY(2, 4); P[27] = FY(3, 4); P[28] = FY(4, 4);
    } else {
        P[7] = FB(1, 1); P[8] = FB(2, 1); P[9] = FB(3, 1); P[10] = FB(4, 1);
        P[13] = FB(1, 2); P[14] = FB(2, 2); P[15] = FB(3, 2); P[16] = FB(4, 2);
        P[19] = FB(1, 3); P[20] = FB(2, 3); P[21] = FB(3, 3); P[22] = FB(4, 3);
        P[25] = FB(1, 4); P[26] = FB(2, 4); P[27] = FB(3, 4); P[28] = FB(4, 4);
    }
    {
        float lo = P[7], hi = P[7];
        for (int r = 1; r < 5; r++)
            for (int c = 1; c < 5; c++) { float v = P[r * 6 + c]; lo = min(lo, v); hi = max(hi, v); }
        if (hi - lo <= 0.0208) {
            // flat: no edge is possible, so the 4x4 middle taps (weights made to add up to 1 again) are enough
            vec3 ya, yb, xa, xb;
            csW(fi.y, ya, yb);
            csW(fi.x, xa, xb);
            float sy = ya.y + ya.z + yb.x + yb.y, sx = xa.y + xa.z + xb.x + xb.y;
            float h = 0.0;
            for (int j = 1; j < 5; j++) {
                float v = pp(1, j) * ya.y + pp(2, j) * ya.z + pp(3, j) * yb.x + pp(4, j) * yb.y;
                float wj = j == 1 ? xa.y : j == 2 ? xa.z : j == 3 ? xb.x : xb.y;
                h += v * wj;
            }
            h /= sx * sy;
            vec3 op0 = texture(uSrc, (srcP + 0.5) / vec2(uSrcSize)).rgb;
            outColor = vec4(clamp(op0 + (h - getY(op0)), 0.0, 1.0), 1.0);
            return;
        }
    }
    if (inside) {
        P[0] = FY(0, 0); P[1] = FY(1, 0); P[2] = FY(2, 0); P[3] = FY(3, 0); P[4] = FY(4, 0); P[5] = FY(5, 0);
        P[6] = FY(0, 1); P[11] = FY(5, 1);
        P[12] = FY(0, 2); P[17] = FY(5, 2);
        P[18] = FY(0, 3); P[23] = FY(5, 3);
        P[24] = FY(0, 4); P[29] = FY(5, 4);
        P[30] = FY(0, 5); P[31] = FY(1, 5); P[32] = FY(2, 5); P[33] = FY(3, 5); P[34] = FY(4, 5); P[35] = FY(5, 5);
    } else {
        P[0] = FB(0, 0); P[1] = FB(1, 0); P[2] = FB(2, 0); P[3] = FB(3, 0); P[4] = FB(4, 0); P[5] = FB(5, 0);
        P[6] = FB(0, 1); P[11] = FB(5, 1);
        P[12] = FB(0, 2); P[17] = FB(5, 2);
        P[18] = FB(0, 3); P[23] = FB(5, 3);
        P[24] = FB(0, 4); P[29] = FB(5, 4);
        P[30] = FB(0, 5); P[31] = FB(1, 5); P[32] = FB(2, 5); P[33] = FB(3, 5); P[34] = FB(4, 5); P[35] = FB(5, 5);
    }
#else
    if (inside) {
        P[0] = FY(0, 0); P[1] = FY(1, 0); P[2] = FY(2, 0); P[3] = FY(3, 0); P[4] = FY(4, 0); P[5] = FY(5, 0);
        P[6] = FY(0, 1); P[7] = FY(1, 1); P[8] = FY(2, 1); P[9] = FY(3, 1); P[10] = FY(4, 1); P[11] = FY(5, 1);
        P[12] = FY(0, 2); P[13] = FY(1, 2); P[14] = FY(2, 2); P[15] = FY(3, 2); P[16] = FY(4, 2); P[17] = FY(5, 2);
        P[18] = FY(0, 3); P[19] = FY(1, 3); P[20] = FY(2, 3); P[21] = FY(3, 3); P[22] = FY(4, 3); P[23] = FY(5, 3);
        P[24] = FY(0, 4); P[25] = FY(1, 4); P[26] = FY(2, 4); P[27] = FY(3, 4); P[28] = FY(4, 4); P[29] = FY(5, 4);
        P[30] = FY(0, 5); P[31] = FY(1, 5); P[32] = FY(2, 5); P[33] = FY(3, 5); P[34] = FY(4, 5); P[35] = FY(5, 5);
    } else {
        P[0] = FB(0, 0); P[1] = FB(1, 0); P[2] = FB(2, 0); P[3] = FB(3, 0); P[4] = FB(4, 0); P[5] = FB(5, 0);
        P[6] = FB(0, 1); P[7] = FB(1, 1); P[8] = FB(2, 1); P[9] = FB(3, 1); P[10] = FB(4, 1); P[11] = FB(5, 1);
        P[12] = FB(0, 2); P[13] = FB(1, 2); P[14] = FB(2, 2); P[15] = FB(3, 2); P[16] = FB(4, 2); P[17] = FB(5, 2);
        P[18] = FB(0, 3); P[19] = FB(1, 3); P[20] = FB(2, 3); P[21] = FB(3, 3); P[22] = FB(4, 3); P[23] = FB(5, 3);
        P[24] = FB(0, 4); P[25] = FB(1, 4); P[26] = FB(2, 4); P[27] = FB(3, 4); P[28] = FB(4, 4); P[29] = FB(5, 4);
        P[30] = FB(0, 5); P[31] = FB(1, 5); P[32] = FB(2, 5); P[33] = FB(3, 5); P[34] = FB(4, 5); P[35] = FB(5, 5);
    }
#endif
#undef FY
#undef FB
    // note: pp(row, col): row = y index, col = x index
    // The detector needs a gradient sum over 3 pixels above 0.0625, which needs a range above 0.0208 in the middle 4x4: below that every
    // edge weight is exactly 0, so the four detector calls are skipped (same result).
    float lo4 = P[7], hi4 = P[7];
    for (int r = 1; r < 5; r++)
        for (int c = 1; c < 5; c++) { float v = P[r * 6 + c]; lo4 = min(lo4, v); hi4 = max(hi4, v); }
    vec4 w = vec4(0.0);
    if (hi4 - lo4 > 0.0208) {
#if NF_LEVEL >= 2
        // four calls with constant arguments (the support pixel is picked by branches): no run-time index into the private array P
        if (fr.y >= 0.5) { if (fr.x >= 0.5) w = edgeAt(1, 1); else w = edgeAt(1, 0); }
        else { if (fr.x >= 0.5) w = edgeAt(0, 1); else w = edgeAt(0, 0); }
#else
        vec4 e00 = edgeAt(0, 0), e01 = edgeAt(0, 1), e10 = edgeAt(1, 0), e11 = edgeAt(1, 1);
        w = mix(mix(e00, e01, fr.x), mix(e10, e11, fr.x), fr.y);
#endif
    }
    float base = 1.0 - w.x - w.y - w.z - w.w;
    float opY = 0.0;
    // normal separable filter (the 12 weights are computed once, and it is skipped when the edge weights already add up to 1)
    vec3 ya = vec3(0.0), yb = vec3(0.0), xa = vec3(0.0), xb = vec3(0.0);
    if (base > 0.0 || w.x > 0.0 || w.y > 0.0) { // the same two phase weight sets serve the plain filter and the 0 / 90 degree filters
        csW(fi.y, ya, yb);
        csW(fi.x, xa, xb);
    }
    if (base > 0.0) {
        float h = 0.0;
        for (int j = 0; j < 6; j++) {
            float v = pp(0, j) * ya.x + pp(1, j) * ya.y + pp(2, j) * ya.z + pp(3, j) * yb.x + pp(4, j) * yb.y + pp(5, j) * yb.z;
            float wj = j == 0 ? xa.x : j == 1 ? xa.y : j == 2 ? xa.z : j == 3 ? xb.x : j == 4 ? xb.y : xb.z;
            h += v * wj;
        }
        opY += h * base;
    }
    if (w.x > 0.0) { // 0 deg
        float a[6];
        for (int i = 0; i < 6; i++) a[i] = mix(pp(i, 2), pp(i, 3), fr.x);
        opY += evalPoly6w(a[0], a[1], a[2], a[3], a[4], a[5], fi.y, ya, yb) * w.x;
    }
    if (w.y > 0.0) { // 90 deg
        float a[6];
        for (int i = 0; i < 6; i++) a[i] = mix(pp(2, i), pp(3, i), fr.y);
        opY += evalPoly6w(a[0], a[1], a[2], a[3], a[4], a[5], fi.x, xa, xb) * w.y;
    }
    if (w.z > 0.0) { // 45 deg
        float pb = 0.5 + 0.5 * (fr.x - fr.y);
        float t[7];
        t[1] = mix(pp(2, 1), pp(1, 2), pb);
        t[3] = mix(pp(3, 2), pp(2, 3), pb);
        t[5] = mix(pp(4, 3), pp(3, 4), pb);
        pb -= 0.5;
        float a = pb >= 0.0 ? pp(0, 2) : pp(2, 0);
        float b = pb >= 0.0 ? pp(1, 3) : pp(3, 1);
        float c = pb >= 0.0 ? pp(2, 4) : pp(4, 2);
        float d = pb >= 0.0 ? pp(3, 5) : pp(5, 3);
        t[0] = mix(pp(1, 1), a, abs(pb));
        t[2] = mix(pp(2, 2), b, abs(pb));
        t[4] = mix(pp(3, 3), c, abs(pb));
        t[6] = mix(pp(4, 4), d, abs(pb));
        float pf = fr.x + fr.y;
        int o = 0;
        if (pf >= 1.0) { o = 1; pf -= 1.0; }
        opY += evalPoly6(o == 0 ? t[0] : t[1], o == 0 ? t[1] : t[2], o == 0 ? t[2] : t[3], o == 0 ? t[3] : t[4], o == 0 ? t[4] : t[5], o == 0 ? t[5] : t[6], int(pf * 64.0)) * w.z;
    }
    if (w.w > 0.0) { // 135 deg
        float pb = 0.5 * (fr.x + fr.y);
        float t[7];
        t[1] = mix(pp(3, 1), pp(4, 2), pb);
        t[3] = mix(pp(2, 2), pp(3, 3), pb);
        t[5] = mix(pp(1, 3), pp(2, 4), pb);
        pb -= 0.5;
        float a = pb >= 0.0 ? pp(5, 2) : pp(3, 0);
        float b = pb >= 0.0 ? pp(4, 3) : pp(2, 1);
        float c = pb >= 0.0 ? pp(3, 4) : pp(1, 2);
        float d = pb >= 0.0 ? pp(2, 5) : pp(0, 3);
        t[0] = mix(pp(4, 1), a, abs(pb));
        t[2] = mix(pp(3, 2), b, abs(pb));
        t[4] = mix(pp(2, 3), c, abs(pb));
        t[6] = mix(pp(1, 4), d, abs(pb));
        float pf = 1.0 + (fr.x - fr.y);
        int o = 0;
        if (pf >= 1.0) { o = 1; pf -= 1.0; }
        opY += evalPoly6(o == 0 ? t[0] : t[1], o == 0 ? t[1] : t[2], o == 0 ? t[2] : t[3], o == 0 ? t[3] : t[4], o == 0 ? t[4] : t[5], o == 0 ? t[5] : t[6], int(pf * 64.0)) * w.w;
    }
    vec3 op = texture(uSrc, (srcP + 0.5) / vec2(uSrcSize)).rgb;
    float corr = opY - getY(op);
    outColor = vec4(clamp(op + corr, 0.0, 1.0), 1.0);
}

"""

    /** Luma of every source pixel into an R32F texture (for the textureGather versions of NIS fast / NIS mid; needs OpenGL ES 3.1). */
    const val NIS_LUMA = """#version 300 es
precision highp float;
precision highp int;
uniform sampler2D uSrc;
out vec4 outColor;
// luma of every source pixel (the same formula as getY in the NIS shaders) into an R32F target of the source size: one pixel in, one pixel out
float getY(vec3 c) { return 0.2126 * c.x + 0.7152 * c.y + 0.0722 * c.z; }
void main() {
    outColor = vec4(getY(texelFetch(uSrc, ivec2(gl_FragCoord.xy), 0).rgb), 0.0, 0.0, 1.0);
}
"""

    /** NIS fast with the luma read by textureGather (OpenGL ES 3.1): the same picture, a quarter of the texture fetches. Same NF_LEVEL switch. */
    const val NIS_FAST_G = """#version 310 es
#ifndef NF_LEVEL
#define NF_LEVEL 0
#endif
precision highp float;
precision highp int;
uniform sampler2D uSrc;
uniform highp sampler2D uLuma; // luma of uSrc, R32F (NIS_LUMA)
uniform ivec2 uSrcSize;
uniform vec2 uScale; // source size / output size
uniform float uSharp; // 0..1 (NIS "sharpness")
in highp vec2 vUv;
out vec4 outColor;
// The two 64-phase coefficient tables of NIS (scaler and USM, 6 taps each) as degree-5 polynomials of the phase (fitted, rows still sum to
// exactly 1 and 0): no 384-float arrays indexed at run time. Largest weight error 0.0007 (scaler) / 0.0024 (USM).
const vec3 CSA0 = vec3(-0.0001070, -0.0001231, 1.0003307), CSB0 = vec3(-0.0000579, 0.0000137, -0.0000564);
const vec3 CSA1 = vec3(0.2111275, -0.8236856, -0.0136663), CSB1 = vec3(0.8321093, -0.2093058, 0.0034209);
const vec3 CSA2 = vec3(-0.3595321, 1.1152461, -1.6231426), CSB2 = vec3(1.0873953, -0.2941929, 0.0742261);
const vec3 CSA3 = vec3(-0.1033663, 0.4642154, -0.6315029), CSB3 = vec3(0.0786781, -0.0453782, 0.2373540);
const vec3 CSA4 = vec3(0.4454886, -1.1876582, 2.0164189), CSB4 = vec3(-1.7626354, 0.9873137, -0.4989276);
const vec3 CSA5 = vec3(-0.1937280, 0.4320092, -0.7484854), CSB5 = vec3(0.7650846, -0.4386654, 0.1837849);
const vec3 CUA0 = vec3(-0.0001272, -0.5989534, 1.1988379), CUB0 = vec3(-0.6002660, 0.0005047, 0.0000040);
const vec3 CUA1 = vec3(0.1820147, -0.6219288, 0.0567186), CUB1 = vec3(0.5823822, -0.2004738, 0.0012870);
const vec3 CUA2 = vec3(-0.5162245, 3.5456529, -5.4805106), CUB2 = vec3(3.1779529, -0.7503817, 0.0235110);
const vec3 CUA3 = vec3(0.4841098, -2.4269653, 3.5860341), CUB3 = vec3(-0.3295057, -1.4427130, 0.1290401);
const vec3 CUA4 = vec3(-0.1451612, -0.5082092, 0.6368236), CUB4 = vec3(-2.1383435, 2.3060874, -0.1511971);
const vec3 CUA5 = vec3(-0.0046256, 0.6114838, -0.5985218), CUB5 = vec3(0.5055495, -0.5110171, -0.0028687);
void csW(int ph, out vec3 a, out vec3 b) {
    float t = float(ph) * (1.0 / 64.0);
    a = CSA0 + t * (CSA1 + t * (CSA2 + t * (CSA3 + t * (CSA4 + t * CSA5))));
    b = CSB0 + t * (CSB1 + t * (CSB2 + t * (CSB3 + t * (CSB4 + t * CSB5))));
}
void cuW(int ph, out vec3 a, out vec3 b) {
    float t = float(ph) * (1.0 / 64.0);
    a = CUA0 + t * (CUA1 + t * (CUA2 + t * (CUA3 + t * (CUA4 + t * CUA5))));
    b = CUB0 + t * (CUB1 + t * (CUB2 + t * (CUB3 + t * (CUB4 + t * CUB5))));
}

float getY(vec3 c) { return 0.2126 * c.x + 0.7152 * c.y + 0.0722 * c.z; }
float P[36];
float pp(int i, int j) { return P[i * 6 + j]; }
vec4 edgeAt(int i, int j) {
    // 3x3 window centred on support pixel (2+i, 2+j)
    int r = 1 + i, c = 1 + j;
    float a00 = pp(r, c), a01 = pp(r, c + 1), a02 = pp(r, c + 2);
    float a10 = pp(r + 1, c), a12 = pp(r + 1, c + 2);
    float a11 = pp(r + 1, c + 1);
    float a20 = pp(r + 2, c), a21 = pp(r + 2, c + 1), a22 = pp(r + 2, c + 2);
    float g0 = abs(a00 + a01 + a02 - a20 - a21 - a22);
    float g45 = abs(a10 + a00 + a01 - a21 - a22 - a12);
    float g90 = abs(a00 + a10 + a20 - a02 - a12 - a22);
    float g135 = abs(a10 + a20 + a21 - a01 - a02 - a12);
    float m1 = max(g0, g90), n1 = min(g0, g90), m2 = max(g45, g135), n2 = min(g45, g135);
#ifdef NF_REFINE
    // "NIS fast (clean)": a little less eager than the original (2.0 / 64): on noisy low-quality video the original picks a direction in the noise and the lines turn wavy
    float kDetectRatio = 2.5 * 1127.0 / 1024.0, kDetectThres = 88.0 / 1024.0;
#else
    float kDetectRatio = 2.0 * 1127.0 / 1024.0, kDetectThres = 64.0 / 1024.0;
#endif
    bool c1 = (m1 > n1 * kDetectRatio) && (m1 > kDetectThres) && (m1 > n2);
    bool c2 = (m2 > n2 * kDetectRatio) && (m2 > kDetectThres) && (m2 > n1);
    if (!c1 && !c2) return vec4(0.0); // nothing fires (this includes m1 + m2 == 0): all four weights are 0, as before
    float e0 = min(m1 / (m1 + m2), 1.0);
    float e45 = 1.0 - e0;
    bool cg0 = m1 == g0, cg45 = m2 == g45;
    float f0 = (c1 && c2) ? e0 : 1.0;
    float f45 = (c1 && c2) ? e45 : 1.0;
    return vec4((c1 && cg0) ? f0 : 0.0, (c1 && !cg0) ? f0 : 0.0, (c2 && cg45) ? f45 : 0.0, (c2 && !cg45) ? f45 : 0.0);
}
// sharpening constants (SDR) from NVScalerUpdateConfig
float kSharpStartY, kSharpScaleY, kSharpStrengthMin, kSharpStrengthScale, kSharpLimitMin, kSharpLimitScale;
const float kMinContrastRatio = 2.0, kRatioNorm = 1.0 / 8.0, kEps = 1.0 / 255.0;
void setupCfg() {
    float sl = uSharp - 0.5;
    float MaxScale = sl >= 0.0 ? 1.25 : 1.75, MinScale = sl >= 0.0 ? 1.25 : 1.0, LimitScale = sl >= 0.0 ? 1.25 : 1.0;
    kSharpStartY = 0.45;
    kSharpScaleY = 1.0 / (0.9 - 0.45);
    kSharpStrengthMin = max(0.0, 0.4 + sl * MinScale * 1.2);
    float smax = 1.6 + sl * MaxScale * 1.8;
    kSharpStrengthScale = smax - kSharpStrengthMin;
    kSharpLimitMin = max(0.1, 0.14 + sl * LimitScale * 0.32);
    float lmax = 0.5 + sl * LimitScale * 0.6;
    kSharpLimitScale = lmax - kSharpLimitMin;
}
float calcLTI(float p0, float p1, float p2, float p3, float p4, float p5, int ph) {
    bool sel = ph <= 32;
    float s = sel ? p0 : p3;
    float amin = min(min(p1, p2), s), amax = max(max(p1, p2), s);
    s = sel ? p2 : p5;
    float bmin = min(min(p3, p4), s), bmax = max(max(p3, p4), s);
    float ac = amax - amin, bc = bmax - bmin;
    float cr = max(ac, bc) / (min(ac, bc) + kEps);
    return 1.0 - clamp((cr - kMinContrastRatio) * kRatioNorm, 0.0, 1.0);
}
float evalPoly6w(float x0, float x1, float x2, float x3, float x4, float x5, int ph, vec3 sa, vec3 sb) {
    vec3 ua, ub;
    cuW(ph, ua, ub);
    vec3 xa = vec3(x0, x1, x2), xb = vec3(x3, x4, x5);
    float y = dot(xa, sa) + dot(xb, sb);
    float yu = dot(xa, ua) + dot(xb, ub);
    float ys = 1.0 - clamp((y - kSharpStartY) * kSharpScaleY, 0.0, 1.0);
    yu *= ys * kSharpStrengthScale + kSharpStrengthMin;
    float lim = (ys * kSharpLimitScale + kSharpLimitMin) * y;
    yu = min(lim, max(-lim, yu));
    yu *= calcLTI(x0, x1, x2, x3, x4, x5, ph);
#ifdef NF_REFINE
    // noise gate: in a calm area the sharpening only makes the compression noise bigger ("oily" blotches), so it fades out there
    float rg = max(max(max(x0, x1), max(x2, x3)), max(x4, x5)) - min(min(min(x0, x1), min(x2, x3)), min(x4, x5));
    yu *= 0.85 * mix(0.2, 1.0, smoothstep(0.02, 0.09, rg));
#endif
    return y + yu;
}
float evalPoly6(float x0, float x1, float x2, float x3, float x4, float x5, int ph) {
    vec3 sa, sb;
    csW(ph, sa, sb);
    return evalPoly6w(x0, x1, x2, x3, x4, x5, ph, sa, sb);
}
void main() {
    setupCfg();
    vec2 dst = vUv * vec2(uSrcSize) / uScale; // output pixel coordinate (+0.5 at centres)
    vec2 srcP = dst * uScale - 0.5;
    ivec2 i0 = ivec2(floor(srcP));
    vec2 fr = srcP - vec2(i0);
    ivec2 fi = ivec2(fr * 64.0);
    // The luma of every source pixel is in uLuma (R32F, made by NIS_LUMA with the same formula): textureGather reads 4 of them in one fetch
    // (9 fetches for the 6x6 window instead of 36). The gather point is the corner between 4 texels, so it is far from any rounding edge, and the
    // clamp-to-edge wrap of the texture does the same as the clamp of the tap coordinates.
#define GA(ax, ay) textureGather(uLuma, (vec2(i0) + vec2(float(ax), float(ay))) / vec2(uSrcSize), 0)
    vec4 g;
#if NF_LEVEL >= 1
    {
        g = GA(0, 0); P[7] = g.w; P[8] = g.z; P[13] = g.x; P[14] = g.y; g = GA(2, 0); P[9] = g.w; P[10] = g.z; P[15] = g.x; P[16] = g.y;
        g = GA(0, 2); P[19] = g.w; P[20] = g.z; P[25] = g.x; P[26] = g.y; g = GA(2, 2); P[21] = g.w; P[22] = g.z; P[27] = g.x; P[28] = g.y;
    }
    {
        float lo = P[7], hi = P[7];
        for (int r = 1; r < 5; r++)
            for (int c = 1; c < 5; c++) { float v = P[r * 6 + c]; lo = min(lo, v); hi = max(hi, v); }
        if (hi - lo <= 0.0208) {
            // flat: no edge is possible, so the 4x4 middle taps (weights made to add up to 1 again) are enough
            vec3 ya, yb, xa, xb;
            csW(fi.y, ya, yb);
            csW(fi.x, xa, xb);
            float sy = ya.y + ya.z + yb.x + yb.y, sx = xa.y + xa.z + xb.x + xb.y;
            float h = 0.0;
            for (int j = 1; j < 5; j++) {
                float v = pp(1, j) * ya.y + pp(2, j) * ya.z + pp(3, j) * yb.x + pp(4, j) * yb.y;
                float wj = j == 1 ? xa.y : j == 2 ? xa.z : j == 3 ? xb.x : xb.y;
                h += v * wj;
            }
            h /= sx * sy;
            vec3 op0 = texture(uSrc, (srcP + 0.5) / vec2(uSrcSize)).rgb;
            outColor = vec4(clamp(op0 + (h - getY(op0)), 0.0, 1.0), 1.0);
            return;
        }
    }
#endif
    g = GA(-1, -1); P[0] = g.w; P[1] = g.z; P[6] = g.x; P[7] = g.y; g = GA(1, -1); P[2] = g.w; P[3] = g.z; P[8] = g.x; P[9] = g.y; g = GA(3, -1); P[4] = g.w; P[5] = g.z; P[10] = g.x; P[11] = g.y;
    g = GA(-1, 1); P[12] = g.w; P[13] = g.z; P[18] = g.x; P[19] = g.y; g = GA(1, 1); P[14] = g.w; P[15] = g.z; P[20] = g.x; P[21] = g.y; g = GA(3, 1); P[16] = g.w; P[17] = g.z; P[22] = g.x; P[23] = g.y;
    g = GA(-1, 3); P[24] = g.w; P[25] = g.z; P[30] = g.x; P[31] = g.y; g = GA(1, 3); P[26] = g.w; P[27] = g.z; P[32] = g.x; P[33] = g.y; g = GA(3, 3); P[28] = g.w; P[29] = g.z; P[34] = g.x; P[35] = g.y;
#undef GA
    // note: pp(row, col): row = y index, col = x index
    // The detector needs a gradient sum over 3 pixels above 0.0625, which needs a range above 0.0208 in the middle 4x4: below that every
    // edge weight is exactly 0, so the four detector calls are skipped (same result).
    float lo4 = P[7], hi4 = P[7];
    for (int r = 1; r < 5; r++)
        for (int c = 1; c < 5; c++) { float v = P[r * 6 + c]; lo4 = min(lo4, v); hi4 = max(hi4, v); }
    vec4 w = vec4(0.0);
    if (hi4 - lo4 > 0.0208) {
#if NF_LEVEL >= 2
        // four calls with constant arguments (the support pixel is picked by branches): no run-time index into the private array P
        if (fr.y >= 0.5) { if (fr.x >= 0.5) w = edgeAt(1, 1); else w = edgeAt(1, 0); }
        else { if (fr.x >= 0.5) w = edgeAt(0, 1); else w = edgeAt(0, 0); }
#else
        vec4 e00 = edgeAt(0, 0), e01 = edgeAt(0, 1), e10 = edgeAt(1, 0), e11 = edgeAt(1, 1);
        w = mix(mix(e00, e01, fr.x), mix(e10, e11, fr.x), fr.y);
#endif
    }
    float base = 1.0 - w.x - w.y - w.z - w.w;
    float opY = 0.0;
    // normal separable filter (the 12 weights are computed once, and it is skipped when the edge weights already add up to 1)
    vec3 ya = vec3(0.0), yb = vec3(0.0), xa = vec3(0.0), xb = vec3(0.0);
    if (base > 0.0 || w.x > 0.0 || w.y > 0.0) { // the same two phase weight sets serve the plain filter and the 0 / 90 degree filters
        csW(fi.y, ya, yb);
        csW(fi.x, xa, xb);
    }
    if (base > 0.0) {
        float h = 0.0;
        for (int j = 0; j < 6; j++) {
            float v = pp(0, j) * ya.x + pp(1, j) * ya.y + pp(2, j) * ya.z + pp(3, j) * yb.x + pp(4, j) * yb.y + pp(5, j) * yb.z;
            float wj = j == 0 ? xa.x : j == 1 ? xa.y : j == 2 ? xa.z : j == 3 ? xb.x : j == 4 ? xb.y : xb.z;
            h += v * wj;
        }
        opY += h * base;
    }
    if (w.x > 0.0) { // 0 deg
        float a[6];
        for (int i = 0; i < 6; i++) a[i] = mix(pp(i, 2), pp(i, 3), fr.x);
        opY += evalPoly6w(a[0], a[1], a[2], a[3], a[4], a[5], fi.y, ya, yb) * w.x;
    }
    if (w.y > 0.0) { // 90 deg
        float a[6];
        for (int i = 0; i < 6; i++) a[i] = mix(pp(2, i), pp(3, i), fr.y);
        opY += evalPoly6w(a[0], a[1], a[2], a[3], a[4], a[5], fi.x, xa, xb) * w.y;
    }
    if (w.z > 0.0) { // 45 deg
        float pb = 0.5 + 0.5 * (fr.x - fr.y);
        float t[7];
        t[1] = mix(pp(2, 1), pp(1, 2), pb);
        t[3] = mix(pp(3, 2), pp(2, 3), pb);
        t[5] = mix(pp(4, 3), pp(3, 4), pb);
        pb -= 0.5;
        float a = pb >= 0.0 ? pp(0, 2) : pp(2, 0);
        float b = pb >= 0.0 ? pp(1, 3) : pp(3, 1);
        float c = pb >= 0.0 ? pp(2, 4) : pp(4, 2);
        float d = pb >= 0.0 ? pp(3, 5) : pp(5, 3);
        t[0] = mix(pp(1, 1), a, abs(pb));
        t[2] = mix(pp(2, 2), b, abs(pb));
        t[4] = mix(pp(3, 3), c, abs(pb));
        t[6] = mix(pp(4, 4), d, abs(pb));
        float pf = fr.x + fr.y;
        int o = 0;
        if (pf >= 1.0) { o = 1; pf -= 1.0; }
        opY += evalPoly6(o == 0 ? t[0] : t[1], o == 0 ? t[1] : t[2], o == 0 ? t[2] : t[3], o == 0 ? t[3] : t[4], o == 0 ? t[4] : t[5], o == 0 ? t[5] : t[6], int(pf * 64.0)) * w.z;
    }
    if (w.w > 0.0) { // 135 deg
        float pb = 0.5 * (fr.x + fr.y);
        float t[7];
        t[1] = mix(pp(3, 1), pp(4, 2), pb);
        t[3] = mix(pp(2, 2), pp(3, 3), pb);
        t[5] = mix(pp(1, 3), pp(2, 4), pb);
        pb -= 0.5;
        float a = pb >= 0.0 ? pp(5, 2) : pp(3, 0);
        float b = pb >= 0.0 ? pp(4, 3) : pp(2, 1);
        float c = pb >= 0.0 ? pp(3, 4) : pp(1, 2);
        float d = pb >= 0.0 ? pp(2, 5) : pp(0, 3);
        t[0] = mix(pp(4, 1), a, abs(pb));
        t[2] = mix(pp(3, 2), b, abs(pb));
        t[4] = mix(pp(2, 3), c, abs(pb));
        t[6] = mix(pp(1, 4), d, abs(pb));
        float pf = 1.0 + (fr.x - fr.y);
        int o = 0;
        if (pf >= 1.0) { o = 1; pf -= 1.0; }
        opY += evalPoly6(o == 0 ? t[0] : t[1], o == 0 ? t[1] : t[2], o == 0 ? t[2] : t[3], o == 0 ? t[3] : t[4], o == 0 ? t[4] : t[5], o == 0 ? t[5] : t[6], int(pf * 64.0)) * w.w;
    }
    vec3 op = texture(uSrc, (srcP + 0.5) / vec2(uSrcSize)).rgb;
    float corr = opY - getY(op);
    outColor = vec4(clamp(op + corr, 0.0, 1.0), 1.0);
}

"""

    /** Luma for the Aura (NIS Lite) gather version: the same `dot` as the Aura shader's own lumaOf (the gather needs OpenGL ES 3.1). */
    const val NIS_LUMA_D = """#version 300 es
precision highp float;
precision highp int;
uniform sampler2D uSrc;
out vec4 outColor;
// luma of every source pixel into an R32F target of the source size, with the same expression as lumaOf in the Aura (NIS Lite) shader
float lumaOf(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
void main() {
    outColor = vec4(lumaOf(texelFetch(uSrc, ivec2(gl_FragCoord.xy), 0).rgb), 0.0, 0.0, 1.0);
}
"""

    /** "EASU" of 3.99.45 / 3.99.46 (fewer reads, the same picture on paper and in the software test): used by the upscaler setting "Lightest". */
    const val EASU_L = """#version 300 es

precision highp float;
precision highp int;
// Source size comes from a uniform: textureSize() returned 1x1 on the emulator's GLES translator.
uniform ivec2 uSrcSize;
vec4 fetchC(sampler2D t, ivec2 p) {
    return texelFetch(t, clamp(p, ivec2(0), uSrcSize - ivec2(1)), 0);
}
// textureGather emulation: the 2x2 footprint a bilinear sample at uv p would use.
void gather4(sampler2D t, vec2 p, out vec4 x, out vec4 y, out vec4 z, out vec4 w) {
    vec2 q = p * vec2(uSrcSize) - 0.5;
    ivec2 i0 = ivec2(floor(q));
    ivec2 i1 = i0 + ivec2(1);
    x = fetchC(t, ivec2(i0.x, i1.y));
    y = fetchC(t, ivec2(i1.x, i1.y));
    z = fetchC(t, ivec2(i1.x, i0.y));
    w = fetchC(t, ivec2(i0.x, i0.y));
}
float aRcpLo(float a) { return uintBitsToFloat(uint(0x7ef07ebb) - floatBitsToUint(a)); }
float aRsqLo(float a) { return uintBitsToFloat(uint(0x5f347d74) - (floatBitsToUint(a) >> uint(1))); }
float aRcpMed(float a) { float b = uintBitsToFloat(uint(0x7ef19fff) - floatBitsToUint(a)); return b * (-b * a + 2.0); }
float sat(float a) { return clamp(a, 0.0, 1.0); }
float min3(float a, float b, float c) { return min(a, min(b, c)); }
float max3(float a, float b, float c) { return max(a, max(b, c)); }
vec3 min3v(vec3 a, vec3 b, vec3 c) { return min(a, min(b, c)); }
vec3 max3v(vec3 a, vec3 b, vec3 c) { return max(a, max(b, c)); }

uniform sampler2D uSrc;
uniform vec4 uCon0;
uniform vec4 uCon1;
uniform vec4 uCon2;
uniform vec4 uCon3;
out vec4 outColor;

void tap(inout vec3 aC, inout float aW, vec2 off, vec2 dir, vec2 len, float lob, float clp, vec3 c) {
    vec2 v;
    v.x = (off.x * dir.x) + (off.y * dir.y);
    v.y = (off.x * (-dir.y)) + (off.y * dir.x);
    v *= len;
    float d2 = min(v.x * v.x + v.y * v.y, clp);
    float wB = (2.0 / 5.0) * d2 - 1.0;
    float wA = lob * d2 - 1.0;
    wB *= wB;
    wA *= wA;
    wB = (25.0 / 16.0) * wB - (25.0 / 16.0 - 1.0);
    float w = wB * wA;
    aC += c * w;
    aW += w;
}

void setDir(inout vec2 dir, inout float len, vec2 pp, int corner, float lA, float lB, float lC, float lD, float lE) {
    float w = 0.0;
    if (corner == 0) w = (1.0 - pp.x) * (1.0 - pp.y);
    if (corner == 1) w = pp.x * (1.0 - pp.y);
    if (corner == 2) w = (1.0 - pp.x) * pp.y;
    if (corner == 3) w = pp.x * pp.y;
    float dc = lD - lC;
    float cb = lC - lB;
    float lenX = aRcpLo(max(abs(dc), abs(cb)));
    float dirX = lD - lB;
    dir.x += dirX * w;
    lenX = sat(abs(dirX) * lenX);
    len += lenX * lenX * w;
    float ec = lE - lC;
    float ca = lC - lA;
    float lenY = aRcpLo(max(abs(ec), abs(ca)));
    float dirY = lE - lA;
    dir.y += dirY * w;
    lenY = sat(abs(dirY) * lenY);
    len += lenY * lenY * w;
}

void main() {
    vec2 ip = floor(gl_FragCoord.xy);
    vec2 pp = ip * uCon0.xy + uCon0.zw;
    vec2 fp = floor(pp);
    pp -= fp;
    // The 12 taps by integer position around f = fp (what the four gathers of the reference pick, without the position arithmetic):
    //        b c
    //      e f g h
    //      i j k l
    //        n o
    ivec2 q0 = ivec2(fp);
    vec3 b, c, e, f, g, h, i, j, k, l, n, o;
    if (q0.x >= 1 && q0.y >= 1 && q0.x + 2 < uSrcSize.x && q0.y + 2 < uSrcSize.y) {
        b = texelFetchOffset(uSrc, q0, 0, ivec2(0, -1)).rgb;
        c = texelFetchOffset(uSrc, q0, 0, ivec2(1, -1)).rgb;
        e = texelFetchOffset(uSrc, q0, 0, ivec2(-1, 0)).rgb;
        f = texelFetchOffset(uSrc, q0, 0, ivec2(0, 0)).rgb;
        g = texelFetchOffset(uSrc, q0, 0, ivec2(1, 0)).rgb;
        h = texelFetchOffset(uSrc, q0, 0, ivec2(2, 0)).rgb;
        i = texelFetchOffset(uSrc, q0, 0, ivec2(-1, 1)).rgb;
        j = texelFetchOffset(uSrc, q0, 0, ivec2(0, 1)).rgb;
        k = texelFetchOffset(uSrc, q0, 0, ivec2(1, 1)).rgb;
        l = texelFetchOffset(uSrc, q0, 0, ivec2(2, 1)).rgb;
        n = texelFetchOffset(uSrc, q0, 0, ivec2(0, 2)).rgb;
        o = texelFetchOffset(uSrc, q0, 0, ivec2(1, 2)).rgb;
    } else { // the border: the same texels, clamped to the picture
        b = fetchC(uSrc, q0 + ivec2(0, -1)).rgb;
        c = fetchC(uSrc, q0 + ivec2(1, -1)).rgb;
        e = fetchC(uSrc, q0 + ivec2(-1, 0)).rgb;
        f = fetchC(uSrc, q0).rgb;
        g = fetchC(uSrc, q0 + ivec2(1, 0)).rgb;
        h = fetchC(uSrc, q0 + ivec2(2, 0)).rgb;
        i = fetchC(uSrc, q0 + ivec2(-1, 1)).rgb;
        j = fetchC(uSrc, q0 + ivec2(0, 1)).rgb;
        k = fetchC(uSrc, q0 + ivec2(1, 1)).rgb;
        l = fetchC(uSrc, q0 + ivec2(2, 1)).rgb;
        n = fetchC(uSrc, q0 + ivec2(0, 2)).rgb;
        o = fetchC(uSrc, q0 + ivec2(1, 2)).rgb;
    }
    // Luma times 2.
    #define L(v) (v.b * 0.5 + (v.r * 0.5 + v.g))
    float bL = L(b), cL = L(c), iL = L(i), jL = L(j), fL = L(f), eL = L(e);
    float kL = L(k), lL = L(l), hL = L(h), gL = L(g), oL = L(o), nL = L(n);
    vec2 dir = vec2(0.0);
    float len = 0.0;
    setDir(dir, len, pp, 0, bL, eL, fL, gL, jL);
    setDir(dir, len, pp, 1, cL, fL, gL, hL, kL);
    setDir(dir, len, pp, 2, fL, iL, jL, kL, nL);
    setDir(dir, len, pp, 3, gL, jL, kL, lL, oL);
    vec2 dir2 = dir * dir;
    float dirR = dir2.x + dir2.y;
    bool zro = dirR < (1.0 / 32768.0);
    dirR = aRsqLo(dirR);
    dirR = zro ? 1.0 : dirR;
    dir.x = zro ? 1.0 : dir.x;
    dir *= vec2(dirR);
    len = len * 0.5;
    len *= len;
    float stretch = (dir.x * dir.x + dir.y * dir.y) * aRcpLo(max(abs(dir.x), abs(dir.y)));
    vec2 len2 = vec2(1.0 + (stretch - 1.0) * len, 1.0 - 0.5 * len);
    float lob = 0.5 + ((1.0 / 4.0 - 0.04) - 0.5) * len;
    float clp = aRcpLo(lob);
    vec3 min4 = min(min3v(f, g, j), k);
    vec3 max4 = max(max3v(f, g, j), k);
    vec3 aC = vec3(0.0);
    float aW = 0.0;
    tap(aC, aW, vec2( 0.0, -1.0) - pp, dir, len2, lob, clp, b);
    tap(aC, aW, vec2( 1.0, -1.0) - pp, dir, len2, lob, clp, c);
    tap(aC, aW, vec2(-1.0,  1.0) - pp, dir, len2, lob, clp, i);
    tap(aC, aW, vec2( 0.0,  1.0) - pp, dir, len2, lob, clp, j);
    tap(aC, aW, vec2( 0.0,  0.0) - pp, dir, len2, lob, clp, f);
    tap(aC, aW, vec2(-1.0,  0.0) - pp, dir, len2, lob, clp, e);
    tap(aC, aW, vec2( 1.0,  1.0) - pp, dir, len2, lob, clp, k);
    tap(aC, aW, vec2( 2.0,  1.0) - pp, dir, len2, lob, clp, l);
    tap(aC, aW, vec2( 2.0,  0.0) - pp, dir, len2, lob, clp, h);
    tap(aC, aW, vec2( 1.0,  0.0) - pp, dir, len2, lob, clp, g);
    tap(aC, aW, vec2( 1.0,  2.0) - pp, dir, len2, lob, clp, o);
    tap(aC, aW, vec2( 0.0,  2.0) - pp, dir, len2, lob, clp, n);
    vec3 pix = min(max4, max(min4, aC * (1.0 / aW)));
    outColor = vec4(max(pix, vec3(0.0)), 1.0);
}
"""

    /** "EDGE_REFINE" of 3.99.45 / 3.99.46 (fewer reads, the same picture on paper and in the software test): used by the upscaler setting "Lightest". */
    const val EDGE_REFINE_L = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform vec2 uInv;
uniform float uR;
uniform float uSkipR;
uniform ivec2 uSize; // size of uSrc (= the size of this target)
in highp vec2 vUv;
out vec4 outColor;
float lum(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
void main() {
    // this pixel and its 8 neighbours sit exactly on texel centres (same size as the target): read them as texels, not as filtered samples
    ivec2 p = ivec2(gl_FragCoord.xy);
    vec4 c4 = texelFetch(uSrc, p, 0);
    // flat area (alpha from the back-projection pass): nothing to smooth, saves the 8 neighbour reads
    if (c4.a < uSkipR) { outColor = c4; return; }
    vec3 c = c4.rgb;
    float tl, tc, tr, ml, mr, bl, bc, br;
    if (p.x >= 1 && p.y >= 1 && p.x < uSize.x - 1 && p.y < uSize.y - 1) {
        tl = lum(texelFetchOffset(uSrc, p, 0, ivec2(-1, -1)).rgb);
        tc = lum(texelFetchOffset(uSrc, p, 0, ivec2(0, -1)).rgb);
        tr = lum(texelFetchOffset(uSrc, p, 0, ivec2(1, -1)).rgb);
        ml = lum(texelFetchOffset(uSrc, p, 0, ivec2(-1, 0)).rgb);
        mr = lum(texelFetchOffset(uSrc, p, 0, ivec2(1, 0)).rgb);
        bl = lum(texelFetchOffset(uSrc, p, 0, ivec2(-1, 1)).rgb);
        bc = lum(texelFetchOffset(uSrc, p, 0, ivec2(0, 1)).rgb);
        br = lum(texelFetchOffset(uSrc, p, 0, ivec2(1, 1)).rgb);
    } else { // the border: the same texels, clamped to the picture
        ivec2 hi = uSize - ivec2(1);
        tl = lum(texelFetch(uSrc, clamp(p + ivec2(-1, -1), ivec2(0), hi), 0).rgb);
        tc = lum(texelFetch(uSrc, clamp(p + ivec2(0, -1), ivec2(0), hi), 0).rgb);
        tr = lum(texelFetch(uSrc, clamp(p + ivec2(1, -1), ivec2(0), hi), 0).rgb);
        ml = lum(texelFetch(uSrc, clamp(p + ivec2(-1, 0), ivec2(0), hi), 0).rgb);
        mr = lum(texelFetch(uSrc, clamp(p + ivec2(1, 0), ivec2(0), hi), 0).rgb);
        bl = lum(texelFetch(uSrc, clamp(p + ivec2(-1, 1), ivec2(0), hi), 0).rgb);
        bc = lum(texelFetch(uSrc, clamp(p + ivec2(0, 1), ivec2(0), hi), 0).rgb);
        br = lum(texelFetch(uSrc, clamp(p + ivec2(1, 1), ivec2(0), hi), 0).rgb);
    }
    float lcn = lum(c);
    float mxl = max(max(max(max(lcn, tl), max(tc, tr)), max(max(ml, mr), max(bl, bc))), br);
    float mnl = min(min(min(min(lcn, tl), min(tc, tr)), min(min(ml, mr), min(bl, bc))), br);
    float rng = clamp((mxl - mnl) * 8.0, 0.0, 1.0);
    float gx = (tr + 2.0 * mr + br) - (tl + 2.0 * ml + bl);
    float gy = (bl + 2.0 * bc + br) - (tl + 2.0 * tc + tr);
    float m = length(vec2(gx, gy));
    if (m < 0.04) { outColor = vec4(c, rng); return; }
    vec2 n = vec2(gx, gy) / m;
    vec2 t = vec2(-n.y, n.x) * uInv * uR;
    // 1) smooth along the edge: removes the stair-steps of the enlargement
    vec3 s = c * 3.0
        + (texture(uSrc, vUv + t * 0.5).rgb + texture(uSrc, vUv - t * 0.5).rgb) * 2.5
        + (texture(uSrc, vUv + t).rgb + texture(uSrc, vUv - t).rgb) * 1.5
        + (texture(uSrc, vUv + t * 1.5).rgb + texture(uSrc, vUv - t * 1.5).rgb) * 0.5;
    s /= 12.0;
    float k = smoothstep(0.15, 0.6, m) * 0.35; // only clear edges are smoothed: texture stays crisp
    vec3 r = mix(c, s, k);
    outColor = vec4(r, rng);
}
"""

    /** "EDGE_SHOCK" of 3.99.45 / 3.99.46 (fewer reads, the same picture on paper and in the software test): used by the upscaler setting "Lightest". */
    const val EDGE_SHOCK_L = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform vec2 uInv;
uniform float uR;
uniform float uAmt;
uniform float uSkip;
uniform ivec2 uSize; // size of uSrc (= the size of this target)
in highp vec2 vUv;
out vec4 outColor;
float lum(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
void main() {
    // this pixel and its 8 neighbours sit exactly on texel centres (same size as the target): read them as texels, not as filtered samples
    ivec2 p = ivec2(gl_FragCoord.xy);
    vec4 c4 = texelFetch(uSrc, p, 0);
    // flat area: its gradient is below the threshold anyway, saves the 8 neighbour reads
    if (c4.a < uSkip) { outColor = vec4(c4.rgb, 1.0); return; }
    vec3 c = c4.rgb;
    float tl, tc, tr, ml, mr, bl, bc, br;
    if (p.x >= 1 && p.y >= 1 && p.x < uSize.x - 1 && p.y < uSize.y - 1) {
        tl = lum(texelFetchOffset(uSrc, p, 0, ivec2(-1, -1)).rgb);
        tc = lum(texelFetchOffset(uSrc, p, 0, ivec2(0, -1)).rgb);
        tr = lum(texelFetchOffset(uSrc, p, 0, ivec2(1, -1)).rgb);
        ml = lum(texelFetchOffset(uSrc, p, 0, ivec2(-1, 0)).rgb);
        mr = lum(texelFetchOffset(uSrc, p, 0, ivec2(1, 0)).rgb);
        bl = lum(texelFetchOffset(uSrc, p, 0, ivec2(-1, 1)).rgb);
        bc = lum(texelFetchOffset(uSrc, p, 0, ivec2(0, 1)).rgb);
        br = lum(texelFetchOffset(uSrc, p, 0, ivec2(1, 1)).rgb);
    } else { // the border: the same texels, clamped to the picture
        ivec2 hi = uSize - ivec2(1);
        tl = lum(texelFetch(uSrc, clamp(p + ivec2(-1, -1), ivec2(0), hi), 0).rgb);
        tc = lum(texelFetch(uSrc, clamp(p + ivec2(0, -1), ivec2(0), hi), 0).rgb);
        tr = lum(texelFetch(uSrc, clamp(p + ivec2(1, -1), ivec2(0), hi), 0).rgb);
        ml = lum(texelFetch(uSrc, clamp(p + ivec2(-1, 0), ivec2(0), hi), 0).rgb);
        mr = lum(texelFetch(uSrc, clamp(p + ivec2(1, 0), ivec2(0), hi), 0).rgb);
        bl = lum(texelFetch(uSrc, clamp(p + ivec2(-1, 1), ivec2(0), hi), 0).rgb);
        bc = lum(texelFetch(uSrc, clamp(p + ivec2(0, 1), ivec2(0), hi), 0).rgb);
        br = lum(texelFetch(uSrc, clamp(p + ivec2(1, 1), ivec2(0), hi), 0).rgb);
    }
    float gx = (tr + 2.0 * mr + br) - (tl + 2.0 * ml + bl);
    float gy = (bl + 2.0 * bc + br) - (tl + 2.0 * tc + tr);
    float m = length(vec2(gx, gy));
    if (m < 0.1) { outColor = vec4(c, 1.0); return; }
    vec2 n = vec2(gx, gy) / m;
    vec2 st = n * uInv * clamp(0.5 * uR, 0.75, 2.0);
    vec3 a = texture(uSrc, vUv + st).rgb;
    vec3 b = texture(uSrc, vUv - st).rgb;
    float lc = lum(c);
    float la = lum(a);
    float lb = lum(b);
    float lap = la + lb - 2.0 * lc;
    vec3 t = (lap > 0.0) ? ((la < lb) ? a : b) : ((la > lb) ? a : b);
    float edge = smoothstep(0.2, 0.8, m);
    float conv = smoothstep(0.01, 0.06, abs(lap));
    outColor = vec4(mix(c, t, uAmt * edge * conv), 1.0);
}
"""

    /** "CRSC_BP" of 3.99.45 / 3.99.46 (fewer reads, the same picture on paper and in the software test): used by the upscaler setting "Lightest". */
    const val CRSC_BP_L = """#version 300 es
precision highp float;
uniform sampler2D uSrc;uniform sampler2D uLow;uniform sampler2D uD;uniform vec2 uInv;uniform float uG;
in highp vec2 vUv;out vec4 outColor;
void main(){vec3 u=texture(uSrc,vUv).rgb;
vec3 cl=texture(uLow,vUv).rgb; // also the centre of the 3x3 range below: one read, not two
vec3 e=cl-texture(uD,vUv).rgb;
// local range of the low-res picture: the result may not leave it by much (no ringing)
vec3 lo=cl,hi=cl;
{vec3 v=texture(uLow,vUv+vec2(-1.0,-1.0)*uInv).rgb;lo=min(lo,v);hi=max(hi,v);}
{vec3 v=texture(uLow,vUv+vec2(0.0,-1.0)*uInv).rgb;lo=min(lo,v);hi=max(hi,v);}
{vec3 v=texture(uLow,vUv+vec2(1.0,-1.0)*uInv).rgb;lo=min(lo,v);hi=max(hi,v);}
{vec3 v=texture(uLow,vUv+vec2(-1.0,0.0)*uInv).rgb;lo=min(lo,v);hi=max(hi,v);}
{vec3 v=texture(uLow,vUv+vec2(1.0,0.0)*uInv).rgb;lo=min(lo,v);hi=max(hi,v);}
{vec3 v=texture(uLow,vUv+vec2(-1.0,1.0)*uInv).rgb;lo=min(lo,v);hi=max(hi,v);}
{vec3 v=texture(uLow,vUv+vec2(0.0,1.0)*uInv).rgb;lo=min(lo,v);hi=max(hi,v);}
{vec3 v=texture(uLow,vUv+vec2(1.0,1.0)*uInv).rgb;lo=min(lo,v);hi=max(hi,v);}
// small and medium errors are mostly compression noise (blocks, ringing): fade the correction out there, keep it for real edges
float tr=smoothstep(0.002,0.08,max(abs(e.r),max(abs(e.g),abs(e.b))));
vec3 r=u+e*uG*tr;
// alpha carries how flat the neighbourhood is (range x 8): the next passes skip flat pixels
float rg=max(hi.r-lo.r,max(hi.g-lo.g,hi.b-lo.b));
outColor=vec4(clamp(r,lo-0.03,hi+0.03),clamp(rg*8.0,0.0,1.0));}
"""

    /** "NIS" of 3.99.45 / 3.99.46 (fewer reads, the same picture on paper and in the software test): used by the upscaler setting "Lightest". */
    const val NIS_L = """#version 300 es
precision highp float;
precision highp int;
uniform sampler2D uSrc;
uniform ivec2 uSrcSize;
uniform float uSharp; // 0..1 (the sharpness slider)
uniform float uFactor; // enlargement factor (output size / source size)
uniform float uGain; // 1.0 = normal push, lower = gentler (NIS Lite soft: dark / soft pictures)
uniform float uClean; // 0 = off; NIS Lite soft: pull flat, low-contrast areas toward their smooth value (removes dither / grain / compression noise)
in highp vec2 vUv;
out vec4 outColor;

float lumaOf(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
float fetchY(ivec2 p) { return lumaOf(texelFetch(uSrc, p, 0).rgb); } // p is inside the picture (the caller clamps rows and columns)
// Keys cubic (a = -0.5, Catmull-Rom)
vec4 keys4(float u) {
    vec4 d = abs(vec4(u + 1.0, u, u - 1.0, u - 2.0));
    vec4 n = ((-0.5 * d + 2.5) * d - 4.0) * d + 2.0;
    vec4 m = (1.5 * d - 2.5) * d * d + 1.0;
    vec4 w = mix(m, n, step(1.0, d)) * (1.0 - step(2.0, d));
    return w / (w.x + w.y + w.z + w.w);
}
// the same weights for u in [0,1) (the cell the pixel is in) as a plain polynomial: no abs / step / renormalisation needed
vec4 keysCell(float u) {
    float u2 = u * u;
    float u3 = u2 * u;
    return vec4(-0.5 * u3 + u2 - 0.5 * u, 1.5 * u3 - 2.5 * u2 + 1.0, -1.5 * u3 + 2.0 * u2 + 0.5 * u, 0.5 * u3 - 0.5 * u2);
}
// the 4x4 window (rows r0..r3 = y-1..y+2, columns x-1..x+2), filled in main()
vec4 r0, r1, r2, r3;
// cubic value at u (cell coordinates: 0..1 is the middle cell; a little outside is fine, the weights are renormalised)
float cubicAt(vec2 u) {
    vec4 wx = keys4(u.x);
    vec4 wy = keys4(u.y);
    return dot(wy, vec4(dot(r0, wx), dot(r1, wx), dot(r2, wx), dot(r3, wx)));
}
// Gaussian-weighted mean of the window at cell position u (sigma given as 1 / (2 sigma^2))
float gaussAt(vec2 u, float k) {
    float c = exp(-k);
    float c4 = c * c * c * c;
    vec2 a = exp(-u * u * k);       // exp(-k u^2)
    vec2 b = exp(2.0 * k * u);      // exp(2 k u)
    vec4 gx = vec4(a.x * c / b.x, a.x, a.x * c * b.x, a.x * c4 * b.x * b.x);
    vec4 gy = vec4(a.y * c / b.y, a.y, a.y * c * b.y, a.y * c4 * b.y * b.y);
    gx /= (gx.x + gx.y + gx.z + gx.w);
    gy /= (gy.x + gy.y + gy.z + gy.w);
    return dot(gy, vec4(dot(r0, gx), dot(r1, gx), dot(r2, gx), dot(r3, gx)));
}
void main() {
    vec2 srcP = vUv * vec2(uSrcSize) - 0.5;
    ivec2 i0 = ivec2(floor(srcP));
    vec2 fr = srcP - vec2(i0);
    vec3 op = texture(uSrc, (srcP + 0.5) / vec2(uSrcSize)).rgb; // (outside any branch: it needs derivatives)
    ivec4 xs = clamp(i0.x + ivec4(-1, 0, 1, 2), 0, uSrcSize.x - 1);
    ivec4 ys4 = clamp(i0.y + ivec4(-1, 0, 1, 2), 0, uSrcSize.y - 1);
    r0 = vec4(fetchY(ivec2(xs.x, ys4.x)), fetchY(ivec2(xs.y, ys4.x)), fetchY(ivec2(xs.z, ys4.x)), fetchY(ivec2(xs.w, ys4.x)));
    r1 = vec4(fetchY(ivec2(xs.x, ys4.y)), fetchY(ivec2(xs.y, ys4.y)), fetchY(ivec2(xs.z, ys4.y)), fetchY(ivec2(xs.w, ys4.y)));
    r2 = vec4(fetchY(ivec2(xs.x, ys4.z)), fetchY(ivec2(xs.y, ys4.z)), fetchY(ivec2(xs.z, ys4.z)), fetchY(ivec2(xs.w, ys4.z)));
    r3 = vec4(fetchY(ivec2(xs.x, ys4.w)), fetchY(ivec2(xs.y, ys4.w)), fetchY(ivec2(xs.z, ys4.w)), fetchY(ivec2(xs.w, ys4.w)));

    // 1) edge direction: structure tensor at the four middle pixels, interpolated to this position
    vec2 g11 = vec2(r1.z - r1.x, r2.y - r0.y);
    vec2 g12 = vec2(r1.w - r1.y, r2.z - r0.z);
    vec2 g21 = vec2(r2.z - r2.x, r3.y - r1.y);
    vec2 g22 = vec2(r2.w - r2.y, r3.z - r1.z);
    vec3 t11 = vec3(g11 * g11, g11.x * g11.y);
    vec3 t12 = vec3(g12 * g12, g12.x * g12.y);
    vec3 t21 = vec3(g21 * g21, g21.x * g21.y);
    vec3 t22 = vec3(g22 * g22, g22.x * g22.y);
    vec3 J = mix(mix(t11, t12, fr.x), mix(t21, t22, fr.x), fr.y);
    float diffJ = J.x - J.y;
    float disc = sqrt(diffJ * diffJ + 4.0 * J.z * J.z);
    float l1 = 0.5 * (J.x + J.y + disc);
    float l2 = 0.5 * (J.x + J.y - disc);
    float coh = (l1 - l2) / (l1 + l2 + 1e-6);
    float g = smoothstep(0.15, 0.6, coh) * smoothstep(0.02, 0.10, sqrt(max(l1, 0.0)));

    // 2) reconstruction: cubic, then cleaned along the edge (removes stair-steps, keeps the edge itself sharp)
    vec4 wxc = keysCell(fr.x);
    float yc = dot(keysCell(fr.y), vec4(dot(r0, wxc), dot(r1, wxc), dot(r2, wxc), dot(r3, wxc)));
    float ys = yc;
    // no edge (g = 0, flat or noisy areas) means the weight below is 0 and the result is the cubic itself: the direction and the two
    // extra cubics are only worked out where they count. Exactly horizontal / vertical edges (text, UI, HUD) have no stair-steps: no
    // smoothing along them (diag = 0), so thin strokes stay crisp
    if (g > 0.0) {
        vec2 nrm = vec2(diffJ + disc, 2.0 * J.z);
        nrm /= (length(nrm) + 1e-9);
        vec2 tang = vec2(-nrm.y, nrm.x);
        float diag = smoothstep(0.01, 0.12, 1.0 - abs(nrm.x * nrm.x - nrm.y * nrm.y));
        float wq = 0.7 * g * diag;
        if (wq > 0.0) {
            float ya = cubicAt(fr + tang * 0.5);
            float yb = cubicAt(fr - tang * 0.5);
            ys = mix(yc, 0.5 * yc + 0.25 * (ya + yb), wq);
        }
    }

    float fct = clamp(uFactor, 1.25, 4.0);

    // 3) natural, limited sharpening: one unsharp mask against a Gaussian of the same window
    // the more the picture is enlarged, the wider the soft reference and the stronger the push (tuned at x2 on synthetic and x3 on real 360p frames)
    float sg = 0.288 + 0.144 * fct;
    float lo = min(min(r1.y, r1.z), min(r2.y, r2.z));
    float hi = max(max(r1.y, r1.z), max(r2.y, r2.z));
    // local contrast for the gate / guard / overshoot: per-pixel plus-shaped range at the four middle pixels, interpolated, so it has no
    // jump at the borders of source pixels (a range taken from the 2x2 cell jumped there: up to ~20/255 of speckle at exact x3)
    float mn11 = min(min(min(r1.y, r0.y), min(r2.y, r1.x)), r1.z);
    float mx11 = max(max(max(r1.y, r0.y), max(r2.y, r1.x)), r1.z);
    float mn12 = min(min(min(r1.z, r0.z), min(r2.z, r1.y)), r1.w);
    float mx12 = max(max(max(r1.z, r0.z), max(r2.z, r1.y)), r1.w);
    float mn21 = min(min(min(r2.y, r1.y), min(r3.y, r2.x)), r2.z);
    float mx21 = max(max(max(r2.y, r1.y), max(r3.y, r2.x)), r2.z);
    float mn22 = min(min(min(r2.z, r1.z), min(r3.z, r2.y)), r2.w);
    float mx22 = max(max(max(r2.z, r1.z), max(r3.z, r2.y)), r2.w);
    float rng = mix(mix(mx11, mx12, fr.x), mix(mx21, mx22, fr.x), fr.y) - mix(mix(mn11, mn12, fr.x), mix(mn21, mn22, fr.x), fr.y);
    float gate = smoothstep(0.01, 0.08, rng);                  // flat / noisy areas are left alone
    float calm = uClean * (1.0 - smoothstep(0.03, 0.15, rng));  // soft mode only: calm flat areas (noise, dither), edges are untouched
    float yo = ys;
    // with no push (gate = 0) and no cleaning (calm = 0) the result is ys itself: the Gaussian is only worked out where it is used
    if (gate > 0.0 || calm > 0.0) {
        float blur = gaussAt(fr, 1.0 / (2.0 * sg * sg));
        float det = ys - blur;
        det = det / (1.0 + abs(det) * 7.14);                        // soft limit: big details are not exaggerated
        float guard = 1.0 - 0.25 * smoothstep(0.25, 0.6, rng);      // less push on edges that are already strong (no halos)
        float k = 0.15 + 0.85 * clamp(uSharp, 0.0, 1.0);
        yo = ys + k * gate * guard * ((0.32 * fct + 1.76) * uGain * det);
        yo = mix(yo, blur, calm);
    }
    float ov = 0.35 * rng + 0.004;
    yo = clamp(yo, lo - ov, hi + ov);                           // never far past the local range (fidelity, no ringing)

    outColor = vec4(clamp(op + (yo - lumaOf(op)), 0.0, 1.0), 1.0);
}
"""

    /** Aura (NIS Lite, Standard and Soft) with the 4x4 luma window read by textureGather (OpenGL ES 3.1): the same picture, a quarter of the reads. */
    const val NIS_G = """#version 310 es
precision highp float;
precision highp int;
uniform sampler2D uSrc;
uniform highp sampler2D uLuma; // luma of uSrc, R32F (NIS_LUMA_D)
uniform ivec2 uSrcSize;
uniform float uSharp; // 0..1 (the sharpness slider)
uniform float uFactor; // enlargement factor (output size / source size)
uniform float uGain; // 1.0 = normal push, lower = gentler (NIS Lite soft: dark / soft pictures)
uniform float uClean; // 0 = off; NIS Lite soft: pull flat, low-contrast areas toward their smooth value (removes dither / grain / compression noise)
in highp vec2 vUv;
out vec4 outColor;

float lumaOf(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
float fetchY(ivec2 p) { return lumaOf(texelFetch(uSrc, p, 0).rgb); } // p is inside the picture (the caller clamps rows and columns)
// Keys cubic (a = -0.5, Catmull-Rom)
vec4 keys4(float u) {
    vec4 d = abs(vec4(u + 1.0, u, u - 1.0, u - 2.0));
    vec4 n = ((-0.5 * d + 2.5) * d - 4.0) * d + 2.0;
    vec4 m = (1.5 * d - 2.5) * d * d + 1.0;
    vec4 w = mix(m, n, step(1.0, d)) * (1.0 - step(2.0, d));
    return w / (w.x + w.y + w.z + w.w);
}
// the same weights for u in [0,1) (the cell the pixel is in) as a plain polynomial: no abs / step / renormalisation needed
vec4 keysCell(float u) {
    float u2 = u * u;
    float u3 = u2 * u;
    return vec4(-0.5 * u3 + u2 - 0.5 * u, 1.5 * u3 - 2.5 * u2 + 1.0, -1.5 * u3 + 2.0 * u2 + 0.5 * u, 0.5 * u3 - 0.5 * u2);
}
// the 4x4 window (rows r0..r3 = y-1..y+2, columns x-1..x+2), filled in main()
vec4 r0, r1, r2, r3;
// cubic value at u (cell coordinates: 0..1 is the middle cell; a little outside is fine, the weights are renormalised)
float cubicAt(vec2 u) {
    vec4 wx = keys4(u.x);
    vec4 wy = keys4(u.y);
    return dot(wy, vec4(dot(r0, wx), dot(r1, wx), dot(r2, wx), dot(r3, wx)));
}
// Gaussian-weighted mean of the window at cell position u (sigma given as 1 / (2 sigma^2))
float gaussAt(vec2 u, float k) {
    float c = exp(-k);
    float c4 = c * c * c * c;
    vec2 a = exp(-u * u * k);       // exp(-k u^2)
    vec2 b = exp(2.0 * k * u);      // exp(2 k u)
    vec4 gx = vec4(a.x * c / b.x, a.x, a.x * c * b.x, a.x * c4 * b.x * b.x);
    vec4 gy = vec4(a.y * c / b.y, a.y, a.y * c * b.y, a.y * c4 * b.y * b.y);
    gx /= (gx.x + gx.y + gx.z + gx.w);
    gy /= (gy.x + gy.y + gy.z + gy.w);
    return dot(gy, vec4(dot(r0, gx), dot(r1, gx), dot(r2, gx), dot(r3, gx)));
}
void main() {
    vec2 srcP = vUv * vec2(uSrcSize) - 0.5;
    ivec2 i0 = ivec2(floor(srcP));
    vec2 fr = srcP - vec2(i0);
    vec3 op = texture(uSrc, (srcP + 0.5) / vec2(uSrcSize)).rgb; // (outside any branch: it needs derivatives)
    // The luma of every source pixel is in uLuma (R32F, NIS_LUMA_D, the same dot() as lumaOf): textureGather reads 4 of them in one fetch,
    // 4 fetches for the 4x4 window instead of 16 reads + 16 luma sums. The gather point is the corner between 4 texels (far from any rounding
    // edge) and the clamp-to-edge wrap of the texture does what the clamp of the coordinates did.
#define GA(ax, ay) textureGather(uLuma, (vec2(i0) + vec2(float(ax), float(ay))) / vec2(uSrcSize), 0)
    vec4 gq;
    gq = GA(0, 0); r0.xy = gq.wz; r1.xy = gq.xy;
    gq = GA(2, 0); r0.zw = gq.wz; r1.zw = gq.xy;
    gq = GA(0, 2); r2.xy = gq.wz; r3.xy = gq.xy;
    gq = GA(2, 2); r2.zw = gq.wz; r3.zw = gq.xy;
#undef GA

    // 1) edge direction: structure tensor at the four middle pixels, interpolated to this position
    vec2 g11 = vec2(r1.z - r1.x, r2.y - r0.y);
    vec2 g12 = vec2(r1.w - r1.y, r2.z - r0.z);
    vec2 g21 = vec2(r2.z - r2.x, r3.y - r1.y);
    vec2 g22 = vec2(r2.w - r2.y, r3.z - r1.z);
    vec3 t11 = vec3(g11 * g11, g11.x * g11.y);
    vec3 t12 = vec3(g12 * g12, g12.x * g12.y);
    vec3 t21 = vec3(g21 * g21, g21.x * g21.y);
    vec3 t22 = vec3(g22 * g22, g22.x * g22.y);
    vec3 J = mix(mix(t11, t12, fr.x), mix(t21, t22, fr.x), fr.y);
    float diffJ = J.x - J.y;
    float disc = sqrt(diffJ * diffJ + 4.0 * J.z * J.z);
    float l1 = 0.5 * (J.x + J.y + disc);
    float l2 = 0.5 * (J.x + J.y - disc);
    float coh = (l1 - l2) / (l1 + l2 + 1e-6);
    float g = smoothstep(0.15, 0.6, coh) * smoothstep(0.02, 0.10, sqrt(max(l1, 0.0)));

    // 2) reconstruction: cubic, then cleaned along the edge (removes stair-steps, keeps the edge itself sharp)
    vec4 wxc = keysCell(fr.x);
    float yc = dot(keysCell(fr.y), vec4(dot(r0, wxc), dot(r1, wxc), dot(r2, wxc), dot(r3, wxc)));
    float ys = yc;
    // no edge (g = 0, flat or noisy areas) means the weight below is 0 and the result is the cubic itself: the direction and the two
    // extra cubics are only worked out where they count. Exactly horizontal / vertical edges (text, UI, HUD) have no stair-steps: no
    // smoothing along them (diag = 0), so thin strokes stay crisp
    if (g > 0.0) {
        vec2 nrm = vec2(diffJ + disc, 2.0 * J.z);
        nrm /= (length(nrm) + 1e-9);
        vec2 tang = vec2(-nrm.y, nrm.x);
        float diag = smoothstep(0.01, 0.12, 1.0 - abs(nrm.x * nrm.x - nrm.y * nrm.y));
        float wq = 0.7 * g * diag;
        if (wq > 0.0) {
            float ya = cubicAt(fr + tang * 0.5);
            float yb = cubicAt(fr - tang * 0.5);
            ys = mix(yc, 0.5 * yc + 0.25 * (ya + yb), wq);
        }
    }

    float fct = clamp(uFactor, 1.25, 4.0);

    // 3) natural, limited sharpening: one unsharp mask against a Gaussian of the same window
    // the more the picture is enlarged, the wider the soft reference and the stronger the push (tuned at x2 on synthetic and x3 on real 360p frames)
    float sg = 0.288 + 0.144 * fct;
    float lo = min(min(r1.y, r1.z), min(r2.y, r2.z));
    float hi = max(max(r1.y, r1.z), max(r2.y, r2.z));
    // local contrast for the gate / guard / overshoot: per-pixel plus-shaped range at the four middle pixels, interpolated, so it has no
    // jump at the borders of source pixels (a range taken from the 2x2 cell jumped there: up to ~20/255 of speckle at exact x3)
    float mn11 = min(min(min(r1.y, r0.y), min(r2.y, r1.x)), r1.z);
    float mx11 = max(max(max(r1.y, r0.y), max(r2.y, r1.x)), r1.z);
    float mn12 = min(min(min(r1.z, r0.z), min(r2.z, r1.y)), r1.w);
    float mx12 = max(max(max(r1.z, r0.z), max(r2.z, r1.y)), r1.w);
    float mn21 = min(min(min(r2.y, r1.y), min(r3.y, r2.x)), r2.z);
    float mx21 = max(max(max(r2.y, r1.y), max(r3.y, r2.x)), r2.z);
    float mn22 = min(min(min(r2.z, r1.z), min(r3.z, r2.y)), r2.w);
    float mx22 = max(max(max(r2.z, r1.z), max(r3.z, r2.y)), r2.w);
    float rng = mix(mix(mx11, mx12, fr.x), mix(mx21, mx22, fr.x), fr.y) - mix(mix(mn11, mn12, fr.x), mix(mn21, mn22, fr.x), fr.y);
    float gate = smoothstep(0.01, 0.08, rng);                  // flat / noisy areas are left alone
    float calm = uClean * (1.0 - smoothstep(0.03, 0.15, rng));  // soft mode only: calm flat areas (noise, dither), edges are untouched
    float yo = ys;
    // with no push (gate = 0) and no cleaning (calm = 0) the result is ys itself: the Gaussian is only worked out where it is used
    if (gate > 0.0 || calm > 0.0) {
        float blur = gaussAt(fr, 1.0 / (2.0 * sg * sg));
        float det = ys - blur;
        det = det / (1.0 + abs(det) * 7.14);                        // soft limit: big details are not exaggerated
        float guard = 1.0 - 0.25 * smoothstep(0.25, 0.6, rng);      // less push on edges that are already strong (no halos)
        float k = 0.15 + 0.85 * clamp(uSharp, 0.0, 1.0);
        yo = ys + k * gate * guard * ((0.32 * fct + 1.76) * uGain * det);
        yo = mix(yo, blur, calm);
    }
    float ov = 0.35 * rng + 0.004;
    yo = clamp(yo, lo - ov, hi + ov);                           // never far past the local range (fidelity, no ringing)

    outColor = vec4(clamp(op + (yo - lumaOf(op)), 0.0, 1.0), 1.0);
}
"""



    /** The original, heavy NIS port (36 fetches + big coefficient tables per pixel). Selectable as "NIS (original)" (MODE_NIS_ORIG), next to NIS Lite. NVIDIA Image Scaling, MIT licence, (c) NVIDIA. */
    const val NIS_ORIG = """#version 300 es
precision highp float;
precision highp int;
uniform sampler2D uSrc;
uniform ivec2 uSrcSize;
uniform vec2 uScale; // source size / output size
uniform float uSharp; // 0..1 (NIS "sharpness")
in highp vec2 vUv;
out vec4 outColor;
const float cs[384] = float[384](0.0,0.0,1.0000,0.0,0.0,0.0,0.0029,-0.0127,1.0000,0.0132,-0.0034,0.0,0.0063,-0.0249,0.9985,0.0269,-0.0068,0.0,0.0088,-0.0361,0.9956,0.0415,-0.0103,0.0005,0.0117,-0.0474,0.9932,0.0562,-0.0142,0.0005,0.0142,-0.0576,0.9897,0.0713,-0.0181,0.0005,0.0166,-0.0674,0.9844,0.0874,-0.0220,0.0010,0.0186,-0.0762,0.9785,0.1040,-0.0264,0.0015,0.0205,-0.0850,0.9727,0.1206,-0.0308,0.0020,0.0225,-0.0928,0.9648,0.1382,-0.0352,0.0024,0.0239,-0.1006,0.9575,0.1558,-0.0396,0.0029,0.0254,-0.1074,0.9487,0.1738,-0.0439,0.0034,0.0264,-0.1138,0.9390,0.1929,-0.0488,0.0044,0.0278,-0.1191,0.9282,0.2119,-0.0537,0.0049,0.0288,-0.1245,0.9170,0.2310,-0.0581,0.0059,0.0293,-0.1294,0.9058,0.2510,-0.0630,0.0063,0.0303,-0.1333,0.8926,0.2710,-0.0679,0.0073,0.0308,-0.1367,0.8789,0.2915,-0.0728,0.0083,0.0308,-0.1401,0.8657,0.3120,-0.0776,0.0093,0.0313,-0.1426,0.8506,0.3330,-0.0825,0.0103,0.0313,-0.1445,0.8354,0.3540,-0.0874,0.0112,0.0313,-0.1460,0.8193,0.3755,-0.0923,0.0122,0.0313,-0.1470,0.8022,0.3965,-0.0967,0.0137,0.0308,-0.1479,0.7856,0.4185,-0.1016,0.0146,0.0303,-0.1479,0.7681,0.4399,-0.1060,0.0156,0.0298,-0.1479,0.7505,0.4614,-0.1104,0.0166,0.0293,-0.1470,0.7314,0.4829,-0.1147,0.0181,0.0288,-0.1460,0.7119,0.5049,-0.1187,0.0190,0.0278,-0.1445,0.6929,0.5264,-0.1226,0.0200,0.0273,-0.1431,0.6724,0.5479,-0.1260,0.0215,0.0264,-0.1411,0.6528,0.5693,-0.1299,0.0225,0.0254,-0.1387,0.6323,0.5903,-0.1328,0.0234,0.0244,-0.1357,0.6113,0.6113,-0.1357,0.0244,0.0234,-0.1328,0.5903,0.6323,-0.1387,0.0254,0.0225,-0.1299,0.5693,0.6528,-0.1411,0.0264,0.0215,-0.1260,0.5479,0.6724,-0.1431,0.0273,0.0200,-0.1226,0.5264,0.6929,-0.1445,0.0278,0.0190,-0.1187,0.5049,0.7119,-0.1460,0.0288,0.0181,-0.1147,0.4829,0.7314,-0.1470,0.0293,0.0166,-0.1104,0.4614,0.7505,-0.1479,0.0298,0.0156,-0.1060,0.4399,0.7681,-0.1479,0.0303,0.0146,-0.1016,0.4185,0.7856,-0.1479,0.0308,0.0137,-0.0967,0.3965,0.8022,-0.1470,0.0313,0.0122,-0.0923,0.3755,0.8193,-0.1460,0.0313,0.0112,-0.0874,0.3540,0.8354,-0.1445,0.0313,0.0103,-0.0825,0.3330,0.8506,-0.1426,0.0313,0.0093,-0.0776,0.3120,0.8657,-0.1401,0.0308,0.0083,-0.0728,0.2915,0.8789,-0.1367,0.0308,0.0073,-0.0679,0.2710,0.8926,-0.1333,0.0303,0.0063,-0.0630,0.2510,0.9058,-0.1294,0.0293,0.0059,-0.0581,0.2310,0.9170,-0.1245,0.0288,0.0049,-0.0537,0.2119,0.9282,-0.1191,0.0278,0.0044,-0.0488,0.1929,0.9390,-0.1138,0.0264,0.0034,-0.0439,0.1738,0.9487,-0.1074,0.0254,0.0029,-0.0396,0.1558,0.9575,-0.1006,0.0239,0.0024,-0.0352,0.1382,0.9648,-0.0928,0.0225,0.0020,-0.0308,0.1206,0.9727,-0.0850,0.0205,0.0015,-0.0264,0.1040,0.9785,-0.0762,0.0186,0.0010,-0.0220,0.0874,0.9844,-0.0674,0.0166,0.0005,-0.0181,0.0713,0.9897,-0.0576,0.0142,0.0005,-0.0142,0.0562,0.9932,-0.0474,0.0117,0.0005,-0.0103,0.0415,0.9956,-0.0361,0.0088,0.0,-0.0068,0.0269,0.9985,-0.0249,0.0063,0.0,-0.0034,0.0132,1.0000,-0.0127,0.0029);
const float cu[384] = float[384](0.0,-0.6001,1.2002,-0.6001,0.0,0.0,0.0029,-0.6084,1.1987,-0.5903,-0.0029,0.0,0.0049,-0.6147,1.1958,-0.5791,-0.0068,0.0005,0.0073,-0.6196,1.1890,-0.5659,-0.0103,0.0,0.0093,-0.6235,1.1802,-0.5513,-0.0151,0.0,0.0112,-0.6265,1.1699,-0.5352,-0.0195,0.0005,0.0122,-0.6270,1.1582,-0.5181,-0.0259,0.0005,0.0142,-0.6284,1.1455,-0.5005,-0.0317,0.0005,0.0156,-0.6265,1.1274,-0.4790,-0.0386,0.0005,0.0166,-0.6235,1.1089,-0.4570,-0.0454,0.0010,0.0176,-0.6187,1.0879,-0.4346,-0.0532,0.0010,0.0181,-0.6138,1.0659,-0.4102,-0.0615,0.0015,0.0190,-0.6069,1.0405,-0.3843,-0.0698,0.0015,0.0195,-0.6006,1.0161,-0.3574,-0.0796,0.0020,0.0200,-0.5928,0.9893,-0.3286,-0.0898,0.0024,0.0200,-0.5820,0.9580,-0.2988,-0.1001,0.0029,0.0200,-0.5728,0.9292,-0.2690,-0.1104,0.0034,0.0200,-0.5620,0.8975,-0.2368,-0.1226,0.0039,0.0205,-0.5498,0.8643,-0.2046,-0.1343,0.0044,0.0200,-0.5371,0.8301,-0.1709,-0.1465,0.0049,0.0195,-0.5239,0.7944,-0.1367,-0.1587,0.0054,0.0195,-0.5107,0.7598,-0.1021,-0.1724,0.0059,0.0190,-0.4966,0.7231,-0.0649,-0.1865,0.0063,0.0186,-0.4819,0.6846,-0.0288,-0.1997,0.0068,0.0186,-0.4668,0.6460,0.0093,-0.2144,0.0073,0.0176,-0.4507,0.6055,0.0479,-0.2290,0.0083,0.0171,-0.4370,0.5693,0.0859,-0.2446,0.0088,0.0161,-0.4199,0.5283,0.1255,-0.2598,0.0098,0.0161,-0.4048,0.4883,0.1655,-0.2754,0.0103,0.0151,-0.3887,0.4497,0.2041,-0.2910,0.0107,0.0142,-0.3711,0.4072,0.2446,-0.3066,0.0117,0.0137,-0.3555,0.3672,0.2852,-0.3228,0.0122,0.0132,-0.3394,0.3262,0.3262,-0.3394,0.0132,0.0122,-0.3228,0.2852,0.3672,-0.3555,0.0137,0.0117,-0.3066,0.2446,0.4072,-0.3711,0.0142,0.0107,-0.2910,0.2041,0.4497,-0.3887,0.0151,0.0103,-0.2754,0.1655,0.4883,-0.4048,0.0161,0.0098,-0.2598,0.1255,0.5283,-0.4199,0.0161,0.0088,-0.2446,0.0859,0.5693,-0.4370,0.0171,0.0083,-0.2290,0.0479,0.6055,-0.4507,0.0176,0.0073,-0.2144,0.0093,0.6460,-0.4668,0.0186,0.0068,-0.1997,-0.0288,0.6846,-0.4819,0.0186,0.0063,-0.1865,-0.0649,0.7231,-0.4966,0.0190,0.0059,-0.1724,-0.1021,0.7598,-0.5107,0.0195,0.0054,-0.1587,-0.1367,0.7944,-0.5239,0.0195,0.0049,-0.1465,-0.1709,0.8301,-0.5371,0.0200,0.0044,-0.1343,-0.2046,0.8643,-0.5498,0.0205,0.0039,-0.1226,-0.2368,0.8975,-0.5620,0.0200,0.0034,-0.1104,-0.2690,0.9292,-0.5728,0.0200,0.0029,-0.1001,-0.2988,0.9580,-0.5820,0.0200,0.0024,-0.0898,-0.3286,0.9893,-0.5928,0.0200,0.0020,-0.0796,-0.3574,1.0161,-0.6006,0.0195,0.0015,-0.0698,-0.3843,1.0405,-0.6069,0.0190,0.0015,-0.0615,-0.4102,1.0659,-0.6138,0.0181,0.0010,-0.0532,-0.4346,1.0879,-0.6187,0.0176,0.0010,-0.0454,-0.4570,1.1089,-0.6235,0.0166,0.0005,-0.0386,-0.4790,1.1274,-0.6265,0.0156,0.0005,-0.0317,-0.5005,1.1455,-0.6284,0.0142,0.0005,-0.0259,-0.5181,1.1582,-0.6270,0.0122,0.0005,-0.0195,-0.5352,1.1699,-0.6265,0.0112,0.0,-0.0151,-0.5513,1.1802,-0.6235,0.0093,0.0,-0.0103,-0.5659,1.1890,-0.6196,0.0073,0.0005,-0.0068,-0.5791,1.1958,-0.6147,0.0049,0.0,-0.0029,-0.5903,1.1987,-0.6084,0.0029);
float getY(vec3 c) { return 0.2126 * c.x + 0.7152 * c.y + 0.0722 * c.z; }
// Edge weights of one 3x3 window (its 8 outer pixels; the centre is not used). A window whose 8 pixels span 0.0208 or less cannot reach the
// detection threshold (a gradient sum is at most 3 x the span), so it returns the same 0 as the full computation, without doing it.
vec4 edgeFrom(float a00, float a01, float a02, float a10, float a12, float a20, float a21, float a22) {
    float lo = min(min(min(a00, a01), min(a02, a10)), min(min(a12, a20), min(a21, a22)));
    float hi = max(max(max(a00, a01), max(a02, a10)), max(max(a12, a20), max(a21, a22)));
    if (hi - lo <= 0.0208) return vec4(0.0);
    float g0 = abs(a00 + a01 + a02 - a20 - a21 - a22);
    float g45 = abs(a10 + a00 + a01 - a21 - a22 - a12);
    float g90 = abs(a00 + a10 + a20 - a02 - a12 - a22);
    float g135 = abs(a10 + a20 + a21 - a01 - a02 - a12);
    float m1 = max(g0, g90), n1 = min(g0, g90), m2 = max(g45, g135), n2 = min(g45, g135);
    if (m1 + m2 == 0.0) return vec4(0.0);
    float e0 = min(m1 / (m1 + m2), 1.0);
    float e45 = 1.0 - e0;
    float kDetectRatio = 2.0 * 1127.0 / 1024.0, kDetectThres = 64.0 / 1024.0;
    bool c1 = (m1 > n1 * kDetectRatio) && (m1 > kDetectThres) && (m1 > n2);
    bool c2 = (m2 > n2 * kDetectRatio) && (m2 > kDetectThres) && (m2 > n1);
    bool cg0 = m1 == g0, cg45 = m2 == g45;
    float f0 = (c1 && c2) ? e0 : 1.0;
    float f45 = (c1 && c2) ? e45 : 1.0;
    return vec4((c1 && cg0) ? f0 : 0.0, (c1 && !cg0) ? f0 : 0.0, (c2 && cg45) ? f45 : 0.0, (c2 && !cg45) ? f45 : 0.0);
}
// sharpening constants (SDR) from NVScalerUpdateConfig
float kSharpStartY, kSharpScaleY, kSharpStrengthMin, kSharpStrengthScale, kSharpLimitMin, kSharpLimitScale;
const float kMinContrastRatio = 2.0, kRatioNorm = 1.0 / 8.0, kEps = 1.0 / 255.0;
void setupCfg() {
    float sl = uSharp - 0.5;
    float MaxScale = sl >= 0.0 ? 1.25 : 1.75, MinScale = sl >= 0.0 ? 1.25 : 1.0, LimitScale = sl >= 0.0 ? 1.25 : 1.0;
    kSharpStartY = 0.45;
    kSharpScaleY = 1.0 / (0.9 - 0.45);
    kSharpStrengthMin = max(0.0, 0.4 + sl * MinScale * 1.2);
    float smax = 1.6 + sl * MaxScale * 1.8;
    kSharpStrengthScale = smax - kSharpStrengthMin;
    kSharpLimitMin = max(0.1, 0.14 + sl * LimitScale * 0.32);
    float lmax = 0.5 + sl * LimitScale * 0.6;
    kSharpLimitScale = lmax - kSharpLimitMin;
}
float calcLTI(float p0, float p1, float p2, float p3, float p4, float p5, int ph) {
    bool sel = ph <= 32;
    float s = sel ? p0 : p3;
    float amin = min(min(p1, p2), s), amax = max(max(p1, p2), s);
    s = sel ? p2 : p5;
    float bmin = min(min(p3, p4), s), bmax = max(max(p3, p4), s);
    float ac = amax - amin, bc = bmax - bmin;
    float cr = max(ac, bc) / (min(ac, bc) + kEps);
    return 1.0 - clamp((cr - kMinContrastRatio) * kRatioNorm, 0.0, 1.0);
}
float evalPoly6(float x0, float x1, float x2, float x3, float x4, float x5, int ph) {
    int o = ph * 6;
    float y = cs[o] * x0 + cs[o + 1] * x1 + cs[o + 2] * x2 + cs[o + 3] * x3 + cs[o + 4] * x4 + cs[o + 5] * x5;
    float yu = cu[o] * x0 + cu[o + 1] * x1 + cu[o + 2] * x2 + cu[o + 3] * x3 + cu[o + 4] * x4 + cu[o + 5] * x5;
    float ys = 1.0 - clamp((y - kSharpStartY) * kSharpScaleY, 0.0, 1.0);
    yu *= ys * kSharpStrengthScale + kSharpStrengthMin;
    float lim = (ys * kSharpLimitScale + kSharpLimitMin) * y;
    yu = min(lim, max(-lim, yu));
    yu *= calcLTI(x0, x1, x2, x3, x4, x5, ph);
    return y + yu;
}
void main() {
    setupCfg();
    vec2 dst = vUv * vec2(uSrcSize) / uScale; // output pixel coordinate (+0.5 at centres)
    vec2 srcP = dst * uScale - 0.5;
    ivec2 i0 = ivec2(floor(srcP));
    vec2 fr = srcP - vec2(i0);
    ivec2 fi = min(ivec2(fr * 64.0), ivec2(63)); // phase 0..63 (the 64-phase tables have no row 64: fr can round up to exactly 1.0)
    ivec2 mx = uSrcSize - ivec2(1);
    // the 6x6 luma window (row = y, column = x): every pixel in its own variable (no array indexed at run time: that goes to slow scratch memory on phone GPUs)
    float p00 = getY(texelFetch(uSrc, clamp(i0 + ivec2(-2, -2), ivec2(0), mx), 0).rgb);
    float p01 = getY(texelFetch(uSrc, clamp(i0 + ivec2(-1, -2), ivec2(0), mx), 0).rgb);
    float p02 = getY(texelFetch(uSrc, clamp(i0 + ivec2(0, -2), ivec2(0), mx), 0).rgb);
    float p03 = getY(texelFetch(uSrc, clamp(i0 + ivec2(1, -2), ivec2(0), mx), 0).rgb);
    float p04 = getY(texelFetch(uSrc, clamp(i0 + ivec2(2, -2), ivec2(0), mx), 0).rgb);
    float p05 = getY(texelFetch(uSrc, clamp(i0 + ivec2(3, -2), ivec2(0), mx), 0).rgb);
    float p10 = getY(texelFetch(uSrc, clamp(i0 + ivec2(-2, -1), ivec2(0), mx), 0).rgb);
    float p11 = getY(texelFetch(uSrc, clamp(i0 + ivec2(-1, -1), ivec2(0), mx), 0).rgb);
    float p12 = getY(texelFetch(uSrc, clamp(i0 + ivec2(0, -1), ivec2(0), mx), 0).rgb);
    float p13 = getY(texelFetch(uSrc, clamp(i0 + ivec2(1, -1), ivec2(0), mx), 0).rgb);
    float p14 = getY(texelFetch(uSrc, clamp(i0 + ivec2(2, -1), ivec2(0), mx), 0).rgb);
    float p15 = getY(texelFetch(uSrc, clamp(i0 + ivec2(3, -1), ivec2(0), mx), 0).rgb);
    float p20 = getY(texelFetch(uSrc, clamp(i0 + ivec2(-2, 0), ivec2(0), mx), 0).rgb);
    float p21 = getY(texelFetch(uSrc, clamp(i0 + ivec2(-1, 0), ivec2(0), mx), 0).rgb);
    float p22 = getY(texelFetch(uSrc, clamp(i0 + ivec2(0, 0), ivec2(0), mx), 0).rgb);
    float p23 = getY(texelFetch(uSrc, clamp(i0 + ivec2(1, 0), ivec2(0), mx), 0).rgb);
    float p24 = getY(texelFetch(uSrc, clamp(i0 + ivec2(2, 0), ivec2(0), mx), 0).rgb);
    float p25 = getY(texelFetch(uSrc, clamp(i0 + ivec2(3, 0), ivec2(0), mx), 0).rgb);
    float p30 = getY(texelFetch(uSrc, clamp(i0 + ivec2(-2, 1), ivec2(0), mx), 0).rgb);
    float p31 = getY(texelFetch(uSrc, clamp(i0 + ivec2(-1, 1), ivec2(0), mx), 0).rgb);
    float p32 = getY(texelFetch(uSrc, clamp(i0 + ivec2(0, 1), ivec2(0), mx), 0).rgb);
    float p33 = getY(texelFetch(uSrc, clamp(i0 + ivec2(1, 1), ivec2(0), mx), 0).rgb);
    float p34 = getY(texelFetch(uSrc, clamp(i0 + ivec2(2, 1), ivec2(0), mx), 0).rgb);
    float p35 = getY(texelFetch(uSrc, clamp(i0 + ivec2(3, 1), ivec2(0), mx), 0).rgb);
    float p40 = getY(texelFetch(uSrc, clamp(i0 + ivec2(-2, 2), ivec2(0), mx), 0).rgb);
    float p41 = getY(texelFetch(uSrc, clamp(i0 + ivec2(-1, 2), ivec2(0), mx), 0).rgb);
    float p42 = getY(texelFetch(uSrc, clamp(i0 + ivec2(0, 2), ivec2(0), mx), 0).rgb);
    float p43 = getY(texelFetch(uSrc, clamp(i0 + ivec2(1, 2), ivec2(0), mx), 0).rgb);
    float p44 = getY(texelFetch(uSrc, clamp(i0 + ivec2(2, 2), ivec2(0), mx), 0).rgb);
    float p45 = getY(texelFetch(uSrc, clamp(i0 + ivec2(3, 2), ivec2(0), mx), 0).rgb);
    float p50 = getY(texelFetch(uSrc, clamp(i0 + ivec2(-2, 3), ivec2(0), mx), 0).rgb);
    float p51 = getY(texelFetch(uSrc, clamp(i0 + ivec2(-1, 3), ivec2(0), mx), 0).rgb);
    float p52 = getY(texelFetch(uSrc, clamp(i0 + ivec2(0, 3), ivec2(0), mx), 0).rgb);
    float p53 = getY(texelFetch(uSrc, clamp(i0 + ivec2(1, 3), ivec2(0), mx), 0).rgb);
    float p54 = getY(texelFetch(uSrc, clamp(i0 + ivec2(2, 3), ivec2(0), mx), 0).rgb);
    float p55 = getY(texelFetch(uSrc, clamp(i0 + ivec2(3, 3), ivec2(0), mx), 0).rgb);
    // the detector needs a range above 0.0208 in the middle 4x4, else every edge weight is exactly 0
    float lo4 = p11, hi4 = p11;
    lo4 = min(lo4, p12); hi4 = max(hi4, p12);
    lo4 = min(lo4, p13); hi4 = max(hi4, p13);
    lo4 = min(lo4, p14); hi4 = max(hi4, p14);
    lo4 = min(lo4, p21); hi4 = max(hi4, p21);
    lo4 = min(lo4, p22); hi4 = max(hi4, p22);
    lo4 = min(lo4, p23); hi4 = max(hi4, p23);
    lo4 = min(lo4, p24); hi4 = max(hi4, p24);
    lo4 = min(lo4, p31); hi4 = max(hi4, p31);
    lo4 = min(lo4, p32); hi4 = max(hi4, p32);
    lo4 = min(lo4, p33); hi4 = max(hi4, p33);
    lo4 = min(lo4, p34); hi4 = max(hi4, p34);
    lo4 = min(lo4, p41); hi4 = max(hi4, p41);
    lo4 = min(lo4, p42); hi4 = max(hi4, p42);
    lo4 = min(lo4, p43); hi4 = max(hi4, p43);
    lo4 = min(lo4, p44); hi4 = max(hi4, p44);
    vec4 w = vec4(0.0);
    if (hi4 - lo4 > 0.0208) {
        vec4 e00 = edgeFrom(p11, p12, p13, p21, p23, p31, p32, p33), e01 = edgeFrom(p12, p13, p14, p22, p24, p32, p33, p34);
        vec4 e10 = edgeFrom(p21, p22, p23, p31, p33, p41, p42, p43), e11 = edgeFrom(p22, p23, p24, p32, p34, p42, p43, p44);
        w = mix(mix(e00, e01, fr.x), mix(e10, e11, fr.x), fr.y);
    }
    float base = 1.0 - w.x - w.y - w.z - w.w;
    float opY = 0.0;
    // normal separable filter (skipped when the edge weights already add up to 1)
    if (base > 0.0) {
        int oy = fi.y * 6, ox = fi.x * 6;
        float h = 0.0;
        h += (p00 * cs[oy + 0] + p10 * cs[oy + 1] + p20 * cs[oy + 2] + p30 * cs[oy + 3] + p40 * cs[oy + 4] + p50 * cs[oy + 5]) * cs[ox + 0];
        h += (p01 * cs[oy + 0] + p11 * cs[oy + 1] + p21 * cs[oy + 2] + p31 * cs[oy + 3] + p41 * cs[oy + 4] + p51 * cs[oy + 5]) * cs[ox + 1];
        h += (p02 * cs[oy + 0] + p12 * cs[oy + 1] + p22 * cs[oy + 2] + p32 * cs[oy + 3] + p42 * cs[oy + 4] + p52 * cs[oy + 5]) * cs[ox + 2];
        h += (p03 * cs[oy + 0] + p13 * cs[oy + 1] + p23 * cs[oy + 2] + p33 * cs[oy + 3] + p43 * cs[oy + 4] + p53 * cs[oy + 5]) * cs[ox + 3];
        h += (p04 * cs[oy + 0] + p14 * cs[oy + 1] + p24 * cs[oy + 2] + p34 * cs[oy + 3] + p44 * cs[oy + 4] + p54 * cs[oy + 5]) * cs[ox + 4];
        h += (p05 * cs[oy + 0] + p15 * cs[oy + 1] + p25 * cs[oy + 2] + p35 * cs[oy + 3] + p45 * cs[oy + 4] + p55 * cs[oy + 5]) * cs[ox + 5];
        opY += h * base;
    }
    if (w.x > 0.0) { // 0 deg
        opY += evalPoly6(mix(p02, p03, fr.x), mix(p12, p13, fr.x), mix(p22, p23, fr.x), mix(p32, p33, fr.x), mix(p42, p43, fr.x), mix(p52, p53, fr.x), fi.y) * w.x;
    }
    if (w.y > 0.0) { // 90 deg
        opY += evalPoly6(mix(p20, p30, fr.y), mix(p21, p31, fr.y), mix(p22, p32, fr.y), mix(p23, p33, fr.y), mix(p24, p34, fr.y), mix(p25, p35, fr.y), fi.x) * w.y;
    }
    if (w.z > 0.0) { // 45 deg
        float pb = 0.5 + 0.5 * (fr.x - fr.y);
        float t1 = mix(p21, p12, pb), t3 = mix(p32, p23, pb), t5 = mix(p43, p34, pb);
        pb -= 0.5;
        bool up = pb >= 0.0;
        float a = up ? p02 : p20;
        float b = up ? p13 : p31;
        float c = up ? p24 : p42;
        float d = up ? p35 : p53;
        float t0 = mix(p11, a, abs(pb)), t2 = mix(p22, b, abs(pb)), t4 = mix(p33, c, abs(pb)), t6 = mix(p44, d, abs(pb));
        float pf = fr.x + fr.y;
        if (pf >= 1.0) opY += evalPoly6(t1, t2, t3, t4, t5, t6, int((pf - 1.0) * 64.0)) * w.z;
        else opY += evalPoly6(t0, t1, t2, t3, t4, t5, min(int(pf * 64.0), 63)) * w.z;
    }
    if (w.w > 0.0) { // 135 deg
        float pb = 0.5 * (fr.x + fr.y);
        float t1 = mix(p31, p42, pb), t3 = mix(p22, p33, pb), t5 = mix(p13, p24, pb);
        pb -= 0.5;
        bool up = pb >= 0.0;
        float a = up ? p52 : p30;
        float b = up ? p43 : p21;
        float c = up ? p34 : p12;
        float d = up ? p25 : p03;
        float t0 = mix(p41, a, abs(pb)), t2 = mix(p32, b, abs(pb)), t4 = mix(p23, c, abs(pb)), t6 = mix(p14, d, abs(pb));
        float pf = 1.0 + (fr.x - fr.y);
        if (pf >= 1.0) opY += evalPoly6(t1, t2, t3, t4, t5, t6, int((pf - 1.0) * 64.0)) * w.w;
        else opY += evalPoly6(t0, t1, t2, t3, t4, t5, min(int(pf * 64.0), 63)) * w.w;
    }
    vec3 op = texture(uSrc, (srcP + 0.5) / vec2(uSrcSize)).rgb;
    float corr = opY - getY(op);
    outColor = vec4(clamp(op + corr, 0.0, 1.0), 1.0);
}
"""

    /** "Wow" upscaler, pass 1 (see README 3.99.123): edge-preserving, edge-directed 4x4 reconstruction.
     *  Like Clear it stretches the kernel along edges (no stair-steps), and in addition it weighs every tap by how close its
     *  brightness is to the sample point (a bilateral term): block / mosquito noise of a low-quality video is averaged away in
     *  flat and textured areas, while real edges keep a hard, clean line. uAmt 0..1 = how strongly it cleans and steepens. */
    const val ART_UP = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform ivec2 uSrcSize;
uniform float uAmt;
in highp vec2 vUv;
out vec4 outColor;
void main() {
    vec2 pos = vUv * vec2(uSrcSize) - 0.5;
    vec2 b = floor(pos);
    vec2 f = pos - b;
    ivec2 mx = uSrcSize - 1;
    ivec2 c0 = ivec2(b);
    vec3 C[16];
    float L[16];
    for (int j = 0; j < 4; j++) {
        for (int i = 0; i < 4; i++) {
            vec3 c = texelFetch(uSrc, clamp(c0 + ivec2(i - 1, j - 1), ivec2(0), mx), 0).rgb;
            C[j * 4 + i] = c;
            L[j * 4 + i] = dot(c, vec3(0.299, 0.587, 0.114));
        }
    }
    // brightness at the sample point (bilinear of the 4 middle pixels)
    float Lc = mix(mix(L[5], L[6], f.x), mix(L[9], L[10], f.x), f.y);
    float lmn = min(min(L[5], L[6]), min(L[9], L[10]));
    float lmx = max(max(L[5], L[6]), max(L[9], L[10]));
    float gmn = L[0];
    float gmx = L[0];
    for (int k = 1; k < 16; k++) {
        gmn = min(gmn, L[k]);
        gmx = max(gmx, L[k]);
    }
    // structure tensor around the sample point
    float gxx = 0.0;
    float gyy = 0.0;
    float gxy = 0.0;
    for (int j = 1; j < 3; j++) {
        for (int i = 1; i < 3; i++) {
            float gx = (L[(j - 1) * 4 + i + 1] + 2.0 * L[j * 4 + i + 1] + L[(j + 1) * 4 + i + 1]
                      - L[(j - 1) * 4 + i - 1] - 2.0 * L[j * 4 + i - 1] - L[(j + 1) * 4 + i - 1]) * 0.125;
            float gy = (L[(j + 1) * 4 + i - 1] + 2.0 * L[(j + 1) * 4 + i] + L[(j + 1) * 4 + i + 1]
                      - L[(j - 1) * 4 + i - 1] - 2.0 * L[(j - 1) * 4 + i] - L[(j - 1) * 4 + i + 1]) * 0.125;
            float w = (i == 1 ? 1.0 - f.x : f.x) * (j == 1 ? 1.0 - f.y : f.y);
            gxx += w * gx * gx;
            gyy += w * gy * gy;
            gxy += w * gx * gy;
        }
    }
    float tr = gxx + gyy;
    float disc = sqrt(max((gxx - gyy) * (gxx - gyy) + 4.0 * gxy * gxy, 0.0));
    float l1 = 0.5 * (tr + disc);
    float l2 = 0.5 * (tr - disc);
    float coh = (l1 - l2) / (l1 + l2 + 1e-6) * smoothstep(0.00005, 0.01, l1);
    vec2 n1 = vec2(gxy, l1 - gxx);
    vec2 n2 = vec2(l1 - gyy, gxy);
    vec2 n = dot(n1, n1) > dot(n2, n2) ? n1 : n2;
    float nl = dot(n, n);
    n = nl > 1e-12 ? n * inversesqrt(nl) : vec2(1.0, 0.0);
    vec2 t = vec2(-n.y, n.x);
    float a = clamp(uAmt, 0.0, 1.0);
    // long along the edge (smooth lines), a bit short across it (steeper edge)
    float ka = 1.0 + (0.18 + 0.30 * a) * coh;
    float kl = 1.0 / (1.0 + (0.9 + 1.2 * a) * coh);
    // brightness tolerance: wide where the picture is calm (noise gets averaged), narrow at real edges
    float calm = 1.0 - smoothstep(0.03, 0.18, gmx - gmn);
    float sig = mix(0.05, 0.11, calm) * (1.0 - 0.45 * coh);
    sig = max(sig * (1.0 - 0.35 * a), 0.02);
    float inv2s = 0.5 / (sig * sig);
    float lob = mix(0.30, 0.22, coh);
    float clp = 1.0 / lob;
    vec3 acc = vec3(0.0);
    float ws = 0.0;
    for (int j = 0; j < 4; j++) {
        for (int i = 0; i < 4; i++) {
            vec2 d = vec2(float(i - 1), float(j - 1)) - f;
            float u = dot(d, n) * ka;
            float v = dot(d, t) * kl;
            float d2 = min(u * u + v * v, clp);
            float wB = 0.4 * d2 - 1.0;
            float wA = lob * d2 - 1.0;
            wB *= wB;
            wA *= wA;
            wB = 1.5625 * wB - 0.5625;
            float w = max(wB * wA, 0.0) + 0.0001;      // no negative lobes: the clean-up does the work, the next pass sharpens
            float dl = L[j * 4 + i] - Lc;
            w *= exp(-dl * dl * inv2s);
            acc += C[j * 4 + i] * w;
            ws += w;
        }
    }
    vec3 bil = mix(mix(C[5], C[6], f.x), mix(C[9], C[10], f.x), f.y);
    vec3 o = ws > 1e-5 ? acc / ws : bil;
    vec3 mn = min(min(C[5], C[6]), min(C[9], C[10]));
    vec3 mxx = max(max(C[5], C[6]), max(C[9], C[10]));
    outColor = vec4(clamp(o, max(mn - 0.02, 0.0), min(mxx + 0.02, 1.0)), 1.0);
}
"""

    /** "Wow" upscaler, pass 2: makes the picture look finished. All at the output size.
     *  1) edge steepening (a shock filter): pixels on an edge move toward the darker or the brighter side, so lines get thin and
     *     hard with no halo; 2) clarity (a wide, soft sharpen); 3) fine detail: a small, fixed grain only where the picture has
     *     texture, which gives the eye the "HD" feeling that a smooth upscale lacks; 4) colour: vibrance + gentle S-curve.
     *  uAmt 0..1 = overall strength, uColor 0..1 = the colour part (0 = leave colours alone). */
    const val ART_STYLE = """#version 300 es
precision highp float;
uniform sampler2D uSrc;
uniform vec2 uInv;
uniform float uAmt;
uniform float uColor;
in highp vec2 vUv;
out vec4 outColor;
float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
float hash(vec2 p) {
    vec3 q = fract(vec3(p.xyx) * 0.1031);
    q += dot(q, q.yzx + 33.33);
    return fract((q.x + q.y) * q.z);
}
void main() {
    vec3 c = texture(uSrc, vUv).rgb;
    vec3 n  = texture(uSrc, vUv + vec2(0.0, -uInv.y)).rgb;
    vec3 s  = texture(uSrc, vUv + vec2(0.0,  uInv.y)).rgb;
    vec3 e  = texture(uSrc, vUv + vec2( uInv.x, 0.0)).rgb;
    vec3 w  = texture(uSrc, vUv + vec2(-uInv.x, 0.0)).rgb;
    vec3 nw = texture(uSrc, vUv + vec2(-uInv.x, -uInv.y)).rgb;
    vec3 ne = texture(uSrc, vUv + vec2( uInv.x, -uInv.y)).rgb;
    vec3 sw = texture(uSrc, vUv + vec2(-uInv.x,  uInv.y)).rgb;
    vec3 se = texture(uSrc, vUv + vec2( uInv.x,  uInv.y)).rgb;
    vec3 mn = min(c, min(min(min(n, s), min(e, w)), min(min(nw, ne), min(sw, se))));
    vec3 mx = max(c, max(max(max(n, s), max(e, w)), max(max(nw, ne), max(sw, se))));
    float lc = luma(c);
    float rng = luma(mx) - luma(mn);
    float a = clamp(uAmt, 0.0, 1.0);

    // 1) shock filter: pull toward the near extreme, in the direction the Laplacian points
    vec3 avg = (n + s + e + w + 0.5 * (nw + ne + sw + se)) / 6.0;
    float lap = luma(avg) - lc;                       // > 0: darker than its surroundings
    vec3 target = lap > 0.0 ? mn : mx;
    float edge = smoothstep(0.10, 0.30, rng) * smoothstep(0.004, 0.03, abs(lap));
    // the step toward the extreme is not stronger than the local contrast allows (no flat posterised patches)
    vec3 o = mix(c, target, edge * (0.02 + 0.06 * a));

    // 2) clarity: wide soft sharpen from 4 bilinear taps 2 px away
    vec3 w2 = 0.25 * (texture(uSrc, vUv + uInv * vec2( 2.0,  2.0)).rgb + texture(uSrc, vUv + uInv * vec2(-2.0,  2.0)).rgb
                    + texture(uSrc, vUv + uInv * vec2( 2.0, -2.0)).rgb + texture(uSrc, vUv + uInv * vec2(-2.0, -2.0)).rgb);
    float mid = 1.0 - abs(2.0 * lc - 1.0);            // more in the mid-tones, none in pure black / white
    o += (c - w2) * (0.22 * a) * (0.4 + 0.6 * mid);

    // 3) fine detail: grain only on textured, not-hard-edge areas
    float tex = smoothstep(0.012, 0.05, rng) * (1.0 - smoothstep(0.16, 0.40, rng));
    float g = hash(floor(gl_FragCoord.xy)) - 0.5;
    // (the fixed grain is off: a pattern that stays put on the screen looks like dirt on the glass while the picture moves)
    o += vec3(g) * (0.0 * a) * tex;

    // keep inside the local range with a little room (no halos)
    o = clamp(o, mn - 0.015, mx + 0.015);

    // 4) colour: vibrance and S-curve
    float k = clamp(uColor, 0.0, 1.0) * a;
    float l2 = luma(o);
    float sat = max(max(o.r, o.g), o.b) - min(min(o.r, o.g), o.b);
    o = mix(vec3(l2), o, 1.0 + 0.35 * k * (1.0 - clamp(sat * 1.6, 0.0, 1.0)));
    vec3 sc = o * o * (3.0 - 2.0 * o);
    o = mix(o, sc, 0.15 * k);
    outColor = vec4(clamp(o, 0.0, 1.0), 1.0);
}
"""
}
