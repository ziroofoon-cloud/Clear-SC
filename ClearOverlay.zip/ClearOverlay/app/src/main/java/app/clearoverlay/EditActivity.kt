package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

/**
 * "Edit video": cut a part (from - to), mute the sound and/or turn the picture. Nothing is re-encoded, so it is fast
 * and lossless; a cut starts at the nearest earlier keyframe. The result is saved to Movies/ClearOverlay.
 */
class EditActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var box: LinearLayout
    private var uri: Uri? = null
    private var name = ""
    private var durSec = 0L
    private var srcRot = 0
    private var from = ""
    private var to = ""
    private var mute = false
    private var rot = 0 // extra turn: 0, 90, 180, 270
    private var outMode = 0 // 0 video, 1 audio only, 2 frame
    private var speedIdx = 0
    private var splitMin = ""
    private var busy = false
    private val cancel = AtomicBoolean(false)

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Cfg.load(this)
        Ui.init(this)
        setTheme(Ui.theme())
        super.onCreate(savedInstanceState)
        Ui.styleBars(window)
        val root = ScrollView(this).apply { setBackgroundColor(Ui.BG) }
        box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(this@EditActivity, 18), dp(this@EditActivity, 22), dp(this@EditActivity, 18), dp(this@EditActivity, 28))
        }
        root.addView(box, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)
        intent?.data?.let { setSource(it, nameOf(it)) }
        build()
    }

    override fun onDestroy() {
        if (isFinishing) cancel.set(true)
        super.onDestroy()
    }

    private fun gap(v: Int) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@EditActivity, v) }

    private fun button(label: String, primary: Boolean, onClick: () -> Unit) = Ui.text(this, label, 16f, if (primary) Ui.BG else Ui.ACCENT, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(this@EditActivity, 14), dp(this@EditActivity, 13), dp(this@EditActivity, 14), dp(this@EditActivity, 13))
        background = if (primary) Ui.gradient(dp(this@EditActivity, 14).toFloat()) else Ui.round(Ui.CHIP, dp(this@EditActivity, 14).toFloat())
        setOnClickListener { onClick() }
    }

    private fun nameOf(u: Uri): String = runCatching {
        contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
    }.getOrNull() ?: (u.lastPathSegment ?: "video").substringAfterLast('/')

    private fun setSource(u: Uri, n: String) {
        uri = u
        name = n
        durSec = 0
        srcRot = 0
        runCatching {
            val r = MediaMetadataRetriever()
            r.setDataSource(this, u)
            durSec = (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) / 1000
            srcRot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            r.release()
        }
    }

    private fun parseTime(text: String): Long? {
        val t = text.trim()
        if (t.isEmpty()) return null
        return try {
            val p = t.split(':')
            when (p.size) {
                1 -> p[0].trim().toDouble().toLong()
                2 -> p[0].trim().toLong() * 60 + p[1].trim().toLong()
                3 -> p[0].trim().toLong() * 3600 + p[1].trim().toLong() * 60 + p[2].trim().toLong()
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun fmt(sec: Long): String {
        val s = sec.coerceAtLeast(0)
        return if (s >= 3600) String.format("%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60) else String.format("%d:%02d", s / 60, s % 60)
    }

    private fun chips(labels: List<String>, selected: Int, onPick: (Int) -> Unit): View {
        val row = LinearLayout(this)
        val views = ArrayList<TextView>()
        fun paint(sel: Int) {
            val r = dp(this, 10).toFloat()
            views.forEachIndexed { i, c ->
                if (i == sel) {
                    c.background = Ui.gradient(r)
                    c.setTextColor(Ui.BG)
                } else {
                    c.background = Ui.round(Ui.CHIP, r)
                    c.setTextColor(Ui.MUTED)
                }
            }
        }
        labels.forEachIndexed { i, l ->
            val c = TextView(this).apply {
                text = l
                textSize = 14f
                gravity = Gravity.CENTER
                maxLines = 1
                minWidth = dp(this@EditActivity, 60)
                setPadding(dp(this@EditActivity, 14), dp(this@EditActivity, 10), dp(this@EditActivity, 14), dp(this@EditActivity, 10))
                setOnClickListener { paint(i); onPick(i) }
            }
            views.add(c)
            row.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i > 0) marginStart = dp(this@EditActivity, 6) })
        }
        paint(selected)
        return ChipScroller(this, row)
    }

    private fun build() {
        box.removeAllViews()
        box.addView(Ui.text(this, getString(R.string.edit_title), 20f, Ui.TEXT, true))
        box.addView(Ui.text(this, getString(R.string.edit_hint), 12f, Ui.MUTED), gap(4))
        box.addView(button(getString(if (uri == null) R.string.export_pick else R.string.edit_change), false) { pick() }, gap(14))
        val u = uri ?: return
        box.addView(Ui.text(this, name + if (durSec > 0) "  ·  " + fmt(durSec) else "", 14f, Ui.TEXT, true), gap(10))

        box.addView(Ui.text(this, getString(R.string.edit_cut), 13f, Ui.ACCENT, true), gap(18))
        fun field(hint: String, value: String, onText: (String) -> Unit) = EditText(this).apply {
            setSingleLine()
            this.hint = hint
            setText(value)
            inputType = android.text.InputType.TYPE_CLASS_DATETIME or android.text.InputType.TYPE_DATETIME_VARIATION_TIME
            setTextColor(Ui.TEXT)
            setHintTextColor(Ui.MUTED)
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) { onText(s?.toString() ?: "") }
            })
        }
        val row = LinearLayout(this)
        row.addView(field(getString(R.string.export_range_from), from) { from = it }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(Ui.text(this, "  →  ", 16f, Ui.MUTED), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        row.addView(field(getString(R.string.export_range_to), to) { to = it }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        box.addView(row, gap(4))
        box.addView(Ui.text(this, getString(R.string.edit_cut_hint), 12f, Ui.MUTED), gap(2))

        box.addView(Ui.text(this, getString(R.string.edit_output), 13f, Ui.ACCENT, true), gap(18))
        box.addView(chips(listOf(getString(R.string.edit_out_video), getString(R.string.edit_out_audio), getString(R.string.edit_out_frame)), outMode) { outMode = it }, gap(6))
        box.addView(Ui.text(this, getString(R.string.edit_frame_hint), 12f, Ui.MUTED), gap(2))

        box.addView(Ui.text(this, getString(R.string.edit_speed), 13f, Ui.ACCENT, true), gap(18))
        box.addView(chips(SPEEDS.map { (if (it == 1f) "1" else it.toString().removeSuffix(".0")) + "×" }, speedIdx) { speedIdx = it }, gap(6))

        box.addView(Ui.text(this, getString(R.string.edit_split), 13f, Ui.ACCENT, true), gap(18))
        box.addView(field(getString(R.string.edit_split_min), splitMin) { splitMin = it }, gap(4))
        box.addView(Ui.text(this, getString(R.string.edit_split_hint), 12f, Ui.MUTED), gap(2))

        box.addView(Ui.text(this, getString(R.string.edit_sound), 13f, Ui.ACCENT, true), gap(18))
        box.addView(chips(listOf(getString(R.string.edit_keep), getString(R.string.edit_mute)), if (mute) 1 else 0) { mute = it == 1 }, gap(6))

        box.addView(Ui.text(this, getString(R.string.edit_rotate), 13f, Ui.ACCENT, true), gap(18))
        box.addView(chips(listOf("0°", "90°", "180°", "270°"), rot / 90) { rot = it * 90 }, gap(6))

        box.addView(button(getString(R.string.edit_save), true) { if (!busy) start(u) }, gap(24))
        box.addView(Ui.text(this, getString(R.string.edit_note), 12f, Ui.MUTED), gap(10))
    }

    private fun pick() {
        AlertDialog.Builder(this)
            .setItems(arrayOf(getString(R.string.export_pick_lib), getString(R.string.export_pick_files))) { _, w ->
                @Suppress("DEPRECATION")
                if (w == 0) {
                    startActivityForResult(Intent(this, LibraryActivity::class.java).putExtra(LibraryArgs.PICK, true).putExtra(LibraryArgs.PICK_TAB, 0), REQ_LIB)
                } else {
                    val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("video/*")
                    startActivityForResult(i, REQ_PICK)
                }
            }
            .show()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val u = data?.data
        if (res != RESULT_OK || u == null) return
        if (req == REQ_PICK) runCatching { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        if (req == REQ_LIB || req == REQ_PICK) {
            setSource(u, if (req == REQ_LIB) (data.getStringExtra(LibraryArgs.NAME) ?: nameOf(u)) else nameOf(u))
            from = ""
            to = ""
            build()
        }
    }

    private fun start(u: Uri) {
        val s = parseTime(from) ?: 0L
        val e = parseTime(to) ?: 0L
        if (e > 0 && e <= s) {
            Toast.makeText(this, R.string.export_range_need_end, Toast.LENGTH_SHORT).show()
            return
        }
        busy = true
        cancel.set(false)
        Toast.makeText(this, R.string.edit_working, Toast.LENGTH_SHORT).show()
        val baseName = name.substringBeforeLast('.')
        val m = mute
        val extra = rot
        val base = srcRot
        val mode = outMode
        val speed = SPEEDS[speedIdx]
        val splitSec = ((splitMin.trim().toDoubleOrNull() ?: 0.0) * 60).toLong()
        val totalSec = if (e > 0) e else durSec
        // list of (from, to) pieces in seconds; 0 as "to" means the end
        val pieces = ArrayList<Pair<Long, Long>>()
        if (mode == 0 && splitSec >= 5 && totalSec > splitSec) {
            var p = s
            while (p < totalSec) {
                val q = minOf(p + splitSec, totalSec)
                pieces.add(p to (if (q >= totalSec && e == 0L) 0L else q))
                p = q
            }
        } else pieces.add(s to e)
        Thread {
            var ok = true
            var tmpUri: Uri? = null
            try {
                for ((idx, pc) in pieces.withIndex()) {
                    val suffix = if (pieces.size > 1) " (Part ${idx + 1})" else " (Edited)"
                    when (mode) {
                        2 -> {
                            val r = MediaMetadataRetriever()
                            r.setDataSource(this, u)
                            val bmp = r.getFrameAtTime(pc.first * 1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST) ?: throw IllegalStateException("no frame")
                            r.release()
                            val cv = ContentValues().apply {
                                put(MediaStore.Images.Media.DISPLAY_NAME, baseName + " (Frame ${fmt(pc.first).replace(':', '-')}).jpg")
                                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/ClearOverlay")
                            }
                            val o = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: throw IllegalStateException("no output")
                            tmpUri = o
                            contentResolver.openOutputStream(o)!!.use { bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 95, it) }
                            tmpUri = null
                        }
                        else -> {
                            val audio = mode == 1
                            val coll = if (audio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                            val cv = ContentValues().apply {
                                if (audio) {
                                    put(MediaStore.Audio.Media.DISPLAY_NAME, baseName + suffix + ".m4a")
                                    put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
                                    put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/ClearOverlay")
                                    put(MediaStore.Audio.Media.IS_PENDING, 1)
                                } else {
                                    put(MediaStore.Video.Media.DISPLAY_NAME, baseName + suffix + ".mp4")
                                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/ClearOverlay")
                                    put(MediaStore.Video.Media.IS_PENDING, 1)
                                }
                            }
                            val o = contentResolver.insert(coll, cv) ?: throw IllegalStateException("no output")
                            tmpUri = o
                            contentResolver.openFileDescriptor(o, "rw")!!.use { pfd ->
                                remux(u, pc.first * 1_000_000L, pc.second * 1_000_000L, m || (!audio && speed != 1f), audio, speed, (base + extra) % 360, pfd.fileDescriptor)
                            }
                            contentResolver.update(o, ContentValues().apply { put("is_pending", 0) }, null, null)
                            tmpUri = null
                        }
                    }
                }
            } catch (t: Throwable) {
                ok = false
                tmpUri?.let { runCatching { contentResolver.delete(it, null, null) } }
            }
            ui.post {
                busy = false
                if (isDestroyed) return@post
                Toast.makeText(this, if (ok) getString(R.string.edit_done) else getString(R.string.edit_failed), Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    private fun remux(u: Uri, startUs: Long, endUs: Long, mute: Boolean, audioOnly: Boolean, speed: Float, rotation: Int, out: java.io.FileDescriptor) {
        val ex = MediaExtractor()
        ex.setDataSource(this, u, null)
        val mux = MediaMuxer(out, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var started = false
        try {
            val map = HashMap<Int, Int>()
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if ((mime.startsWith("video/") && !audioOnly) || (mime.startsWith("audio/") && !mute)) {
                    runCatching { map[i] = mux.addTrack(f); ex.selectTrack(i) }
                }
            }
            if (map.isEmpty()) throw IllegalStateException("no tracks")
            if (!audioOnly) mux.setOrientationHint(rotation)
            mux.start()
            started = true
            if (startUs > 0) ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            val buf = ByteBuffer.allocate(4 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()
            var base = -1L
            while (!cancel.get()) {
                buf.clear()
                val n = ex.readSampleData(buf, 0)
                if (n < 0) break
                val t = ex.sampleTime
                if (endUs > 0 && t > endUs) break
                if (base < 0) base = t
                val tr = map[ex.sampleTrackIndex]
                if (tr != null) {
                    info.set(0, n, ((t - base).coerceAtLeast(0) / speed).toLong(), if (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                    mux.writeSampleData(tr, buf, info)
                }
                ex.advance()
            }
            if (cancel.get()) throw IllegalStateException("cancelled")
        } finally {
            if (started) runCatching { mux.stop() }
            runCatching { mux.release() }
            ex.release()
        }
    }

    private companion object {
        val SPEEDS = floatArrayOf(1f, 0.5f, 2f, 4f, 8f)
        const val REQ_PICK = 41
        const val REQ_LIB = 43
    }
}
