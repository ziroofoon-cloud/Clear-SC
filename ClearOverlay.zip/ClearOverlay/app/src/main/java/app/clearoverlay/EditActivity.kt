package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

/**
 * "Edit video": cut a part (from - to), mute the sound and/or turn the picture. Nothing is re-encoded, so it is fast
 * and lossless; a cut starts at the nearest earlier keyframe. The result is saved to Movies/ClearOverlay.
 */
class EditActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var box: LinearLayout
    private lateinit var pg: EditUi.Page
    private var uri: Uri? = null
    private var name = ""
    private var durSec = 0L
    private var srcRot = 0
    private var from = ""
    private var to = ""
    private var mute = false
    private var rot = 0 // extra turn: 0, 90, 180, 270
    private var outMode = 0 // 0 video, 1 audio only, 2 frame
    private var speedIdx = 2
    private var container = 0 // 0 MP4, 1 WebM, 2 3GP
    private var audioFmt = 0 // 0 = original sound track, i = AudioFormats.ALL[i - 1]
    private var frameFmt = 0 // 0 JPG, 1 PNG, 2 WebP
    private var gifW = 1 // index in GIF_WIDTHS
    private var gifFps = 1 // index in GIF_FPS
    private var splitMin = ""
    private var exactCut = false // frame-accurate cut: the picture is decoded and encoded again
    private var cropIdx = 0 // 0 = none, then CROPS
    private var cropPos = 1 // 0 start (left / top), 1 centre, 2 end
    private var delayIdx = 3 // index in DELAYS_MS (3 = no change)
    private var cutOut = false // true = remove the selected part instead of keeping it
    private var joinUri: Uri? = null
    private var joinName = ""
    private var addUri: Uri? = null
    private var addName = ""
    private var addMode = 0 // 0 mix with the original sound, 1 replace it
    private var addVolIdx = 2
    private var imgUri: Uri? = null
    private var imgName = ""
    private var imgPos = 0 // 0 at the start, 1 at the end, 2 both
    private var imgSecIdx = 1
    private var fromBar: SeekBar? = null
    private var toBar: SeekBar? = null
    private var fromEt: EditText? = null
    private var toEt: EditText? = null
    private var thumbFrom: ImageView? = null
    private var thumbTo: ImageView? = null
    private val thumbRun = Runnable { loadThumbs() }
    private var busy = false
    private val cancel = AtomicBoolean(false)

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Cfg.ensureLoaded(this)
        Ui.init(this)
        setTheme(Ui.theme())
        super.onCreate(savedInstanceState)
        Ui.styleBars(window)
        pg = EditUi.page(this, getString(R.string.edit_title), getString(R.string.edit_hint))
        box = pg.body
        setContentView(pg.root)
        intent?.data?.let { setSource(it, nameOf(it)) }
        build()
    }

    override fun onDestroy() {
        if (isFinishing) cancel.set(true)
        super.onDestroy()
    }

    private fun gap(v: Int) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@EditActivity, v) }

    private fun button(label: String, primary: Boolean, onClick: () -> Unit) = Ui.text(this, label, 16f, if (primary) Ui.BG else Ui.ACCENT, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(this@EditActivity, 14), dp(this@EditActivity, 13), dp(this@EditActivity, 14), dp(this@EditActivity, 13))
        background = if (primary) Ui.gradient(dp(this@EditActivity, 14).toFloat()) else Ui.round(Ui.CHIP, dp(this@EditActivity, 14).toFloat())
        setOnClickListener { onClick() }
    }

    private fun nameOf(u: Uri): String = runCatching {
        contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
    }.getOrNull() ?: (u.lastPathSegment ?: "video").substringAfterLast('/')

    private fun setSource(u: Uri, n: String) {
        uri = u
        name = n
        durSec = 0
        srcRot = 0
        runCatching {
            val r = MediaMetadataRetriever()
            r.setDataSource(this, u)
            durSec = (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) / 1000
            srcRot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            r.release()
        }
    }

    private fun parseTime(text: String): Long? {
        val t = text.trim()
        if (t.isEmpty()) return null
        return try {
            val p = t.split(':')
            when (p.size) {
                1 -> p[0].trim().toDouble().toLong()
                2 -> p[0].trim().toLong() * 60 + p[1].trim().toLong()
                3 -> p[0].trim().toLong() * 3600 + p[1].trim().toLong() * 60 + p[2].trim().toLong()
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun fmt(sec: Long): String {
        val s = sec.coerceAtLeast(0)
        return if (s >= 3600) String.format(java.util.Locale.US, "%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60) else String.format(java.util.Locale.US, "%d:%02d", s / 60, s % 60)
    }

    private fun chips(labels: List<String>, selected: Int, onPick: (Int) -> Unit): View {
        val row = LinearLayout(this)
        val views = ArrayList<TextView>()
        fun paint(sel: Int) {
            val r = dp(this, 10).toFloat()
            views.forEachIndexed { i, c ->
                if (i == sel) {
                    c.background = Ui.gradient(r)
                    c.setTextColor(Ui.BG)
                } else {
                    c.background = Ui.round(Ui.CHIP, r)
                    c.setTextColor(Ui.MUTED)
                }
            }
        }
        labels.forEachIndexed { i, l ->
            val c = TextView(this).apply {
                text = l
                textSize = 14f
                gravity = Gravity.CENTER
                maxLines = 1
                minWidth = dp(this@EditActivity, 60)
                setPadding(dp(this@EditActivity, 14), dp(this@EditActivity, 10), dp(this@EditActivity, 14), dp(this@EditActivity, 10))
                setOnClickListener { paint(i); onPick(i) }
            }
            views.add(c)
            row.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i > 0) marginStart = dp(this@EditActivity, 6) })
        }
        paint(selected)
        return ChipScroller(this, row)
    }

    private fun speedLabels() = SPEEDS.map { (if (it == 1f) "1" else it.toString().removeSuffix(".0")) + "×" }

    private fun build() {
        box.removeAllViews()
        pg.bottom.removeAllViews()
        pg.bottom.visibility = View.GONE
        val u = uri
        if (u == null) {
            box.addView(EditUi.empty(this, Icons.FILM, getString(R.string.edit_hub_video), getString(R.string.export_pick)) { pick() }, EditUi.lp(this, 8))
            return
        }
        val a = this

        // ---- the video being edited
        val src = EditUi.card(a, null)
        src.addView(EditUi.picked(a, Icons.FILM, name, if (durSec > 0) fmt(durSec) else "", { pick() }), EditUi.lp(a, 0))
        box.addView(src, EditUi.lp(a, 4))

        // ---- trim: frames at both ends, the two time fields and their sliders
        val trim = EditUi.card(a, getString(R.string.edit_cut), getString(R.string.edit_cut_hint))
        if (durSec > 0) {
            val thumbs = LinearLayout(a)
            fun thumb() = ImageView(a).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                background = Ui.round(Ui.CHIP, dp(a, 12).toFloat())
                clipToOutline = true
            }
            thumbFrom = thumb()
            thumbTo = thumb()
            thumbs.addView(thumbFrom, LinearLayout.LayoutParams(0, dp(a, 84), 1f))
            thumbs.addView(View(a), LinearLayout.LayoutParams(dp(a, 8), 1))
            thumbs.addView(thumbTo, LinearLayout.LayoutParams(0, dp(a, 84), 1f))
            trim.addView(thumbs, EditUi.lp(a, 12))
        }
        val row = LinearLayout(a).apply { gravity = Gravity.CENTER_VERTICAL }
        val fEt = EditUi.timeField(a, getString(R.string.export_range_from), from) { from = it }
        val tEt = EditUi.timeField(a, getString(R.string.export_range_to), to) { to = it }
        fromEt = fEt
        toEt = tEt
        row.addView(fEt, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(ImageView(a).apply { setImageDrawable(LineIcon(Icons.NEXT, Ui.MUTED)); setPadding(dp(a, 6), 0, dp(a, 6), 0) }, LinearLayout.LayoutParams(dp(a, 36), dp(a, 22)))
        row.addView(tEt, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        trim.addView(row, EditUi.lp(a, 12))
        if (durSec > 0) {
            fun bar(init: Long, onChange: (Long) -> Unit) = SeekBar(a).apply {
                max = durSec.toInt().coerceAtLeast(1)
                progress = init.toInt().coerceIn(0, max)
                progressTintList = android.content.res.ColorStateList.valueOf(Ui.ACCENT)
                thumbTintList = android.content.res.ColorStateList.valueOf(Ui.ACCENT)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                        if (!fromUser) return
                        onChange(p.toLong())
                        ui.removeCallbacks(thumbRun)
                        ui.postDelayed(thumbRun, 180)
                    }
                    override fun onStartTrackingTouch(sb: SeekBar) {}
                    override fun onStopTrackingTouch(sb: SeekBar) {}
                })
            }
            fromBar = bar(parseTime(from) ?: 0L) { v -> from = fmt(v); fromEt?.setText(from) }
            toBar = bar(parseTime(to) ?: durSec) { v -> to = fmt(v); toEt?.setText(to) }
            trim.addView(EditUi.note(a, getString(R.string.export_range_from)), EditUi.lp(a, 8))
            trim.addView(fromBar, EditUi.lp(a, 0))
            trim.addView(EditUi.note(a, getString(R.string.export_range_to)), EditUi.lp(a, 2))
            trim.addView(toBar, EditUi.lp(a, 0))
            loadThumbs()
        }
        trim.addView(EditUi.divider(a))
        trim.addView(EditUi.label(a, getString(R.string.edit_cut_mode)), EditUi.lp(a, 10))
        trim.addView(EditUi.chips(a, listOf(getString(R.string.edit_keep_part), getString(R.string.edit_remove_part)), if (cutOut) 1 else 0) { cutOut = it == 1 }, EditUi.lp(a, 8))
        trim.addView(EditUi.note(a, getString(R.string.edit_cut_mode_hint)), EditUi.lp(a, 6))
        box.addView(trim, EditUi.lp(a, 12))

        // ---- everything below depends on what the result is (video / audio / picture / GIF)
        val dyn = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        box.addView(dyn)
        fun fillDyn() {
            dyn.removeAllViews()
            // result
            val res = EditUi.card(a, getString(R.string.edit_output))
            res.addView(EditUi.chips(a, listOf(getString(R.string.edit_out_video), getString(R.string.edit_out_audio), getString(R.string.edit_out_frame), getString(R.string.edit_out_gif)), outMode) { outMode = it; fillDyn() }, EditUi.lp(a, 10))
            when (outMode) {
                0 -> {
                    res.addView(EditUi.label(a, getString(R.string.edit_fmt_video)), EditUi.lp(a, 14))
                    res.addView(EditUi.chips(a, listOf(getString(R.string.edit_c_mp4), getString(R.string.edit_c_webm), getString(R.string.edit_c_3gp)), container) { container = it }, EditUi.lp(a, 8))
                    res.addView(EditUi.note(a, getString(R.string.edit_fmt_video_hint)), EditUi.lp(a, 6))
                }
                1 -> {
                    res.addView(EditUi.label(a, getString(R.string.edit_fmt_audio)), EditUi.lp(a, 14))
                    res.addView(EditUi.chips(a, listOf(getString(R.string.edit_a_orig)) + AudioFormats.ALL.map { getString(it.label) }, audioFmt) { audioFmt = it }, EditUi.lp(a, 8))
                    res.addView(EditUi.note(a, getString(R.string.edit_fmt_audio_hint)), EditUi.lp(a, 6))
                }
                3 -> {
                    res.addView(EditUi.label(a, getString(R.string.edit_gif_size)), EditUi.lp(a, 14))
                    res.addView(EditUi.chips(a, GIF_WIDTHS.mapIndexed { i, v -> v.toString() + " px" + if (i == 1) " ★" else "" }, gifW) { gifW = it }, EditUi.lp(a, 8))
                    res.addView(EditUi.label(a, getString(R.string.edit_gif_fps)), EditUi.lp(a, 14))
                    res.addView(EditUi.chips(a, GIF_FPS.mapIndexed { i, v -> v.toString() + " fps" + if (i == 1) " ★" else "" }, gifFps) { gifFps = it }, EditUi.lp(a, 8))
                    res.addView(EditUi.note(a, getString(R.string.edit_gif_hint)), EditUi.lp(a, 6))
                }
                else -> {
                    res.addView(EditUi.label(a, getString(R.string.edit_fmt_frame)), EditUi.lp(a, 14))
                    res.addView(EditUi.chips(a, listOf(getString(R.string.edit_f_jpg), getString(R.string.edit_f_png), getString(R.string.edit_f_webp)), frameFmt) { frameFmt = it }, EditUi.lp(a, 8))
                    res.addView(EditUi.note(a, getString(R.string.edit_frame_hint)), EditUi.lp(a, 6))
                }
            }
            dyn.addView(res, EditUi.lp(a, 12))

            // speed
            if (outMode != 2) {
                val sp = EditUi.card(a, getString(R.string.edit_speed))
                sp.addView(EditUi.chips(a, speedLabels(), speedIdx) { speedIdx = it }, EditUi.lp(a, 10))
                dyn.addView(sp, EditUi.lp(a, 12))
            }
            if (outMode == 0) {
                // sound: keep it or make a video without sound
                val snd = EditUi.card(a, getString(R.string.edit_sound))
                snd.addView(EditUi.chips(a, listOf(getString(R.string.edit_keep), getString(R.string.edit_mute)), if (mute) 1 else 0) { mute = it == 1 }, EditUi.lp(a, 10))
                snd.addView(EditUi.label(a, getString(R.string.edit_delay_title)), EditUi.lp(a, 12))
                snd.addView(EditUi.chips(a, DELAYS_MS.map { (if (it > 0) "+" else "") + it + " ms" }, delayIdx) { delayIdx = it }, EditUi.lp(a, 8))
                snd.addView(EditUi.note(a, getString(R.string.edit_delay_hint)), EditUi.lp(a, 6))
                dyn.addView(snd, EditUi.lp(a, 12))

                // exact cut and crop (these two decode and encode the picture again)
                val xc = EditUi.card(a, getString(R.string.edit_card_crop))
                xc.addView(EditUi.chips(a, listOf(getString(R.string.edit_exact_off), getString(R.string.edit_exact_on)), if (exactCut) 1 else 0) { exactCut = it == 1 }, EditUi.lp(a, 10))
                xc.addView(EditUi.label(a, getString(R.string.edit_crop_title)), EditUi.lp(a, 12))
                xc.addView(EditUi.chips(a, listOf(getString(R.string.edit_crop_none)) + CROPS.toList(), cropIdx) { cropIdx = it }, EditUi.lp(a, 8))
                xc.addView(EditUi.chips(a, listOf(getString(R.string.edit_pos_start), getString(R.string.edit_pos_mid), getString(R.string.edit_pos_end)), cropPos) { cropPos = it }, EditUi.lp(a, 8))
                xc.addView(EditUi.note(a, getString(R.string.edit_crop_hint)), EditUi.lp(a, 6))
                dyn.addView(xc, EditUi.lp(a, 12))

                // add: another clip, a picture, a sound
                val add = EditUi.card(a, getString(R.string.edit_card_add))
                add.addView(EditUi.label(a, getString(R.string.edit_join)), EditUi.lp(a, 10))
                if (joinUri == null) add.addView(EditUi.action(a, getString(R.string.edit_join_add), false, Icons.FILM) { pickJoin() }, EditUi.lp(a, 8))
                else add.addView(EditUi.picked(a, Icons.FILM, joinName, getString(R.string.edit_join_note), { pickJoin() }, { joinUri = null; joinName = ""; fillDyn() }), EditUi.lp(a, 8))

                add.addView(EditUi.divider(a))
                add.addView(EditUi.label(a, getString(R.string.edit_img_title)), EditUi.lp(a, 10))
                if (imgUri == null) add.addView(EditUi.action(a, getString(R.string.edit_img_pick), false, Icons.IMAGE) { pickImg() }, EditUi.lp(a, 8))
                else {
                    add.addView(EditUi.picked(a, Icons.IMAGE, imgName, getString(R.string.edit_img_note), { pickImg() }, { imgUri = null; imgName = ""; fillDyn() }), EditUi.lp(a, 8))
                    add.addView(EditUi.chips(a, listOf(getString(R.string.edit_img_start), getString(R.string.edit_img_end), getString(R.string.edit_img_both)), imgPos) { imgPos = it }, EditUi.lp(a, 10))
                    add.addView(EditUi.note(a, getString(R.string.edit_img_secs)), EditUi.lp(a, 10))
                    add.addView(EditUi.chips(a, IMG_SECS.mapIndexed { i, v -> v.toInt().toString() + " s" + if (i == 1) " ★" else "" }, imgSecIdx) { imgSecIdx = it }, EditUi.lp(a, 6))
                }
                add.addView(EditUi.note(a, getString(R.string.edit_img_hint)), EditUi.lp(a, 6))

                add.addView(EditUi.divider(a))
                add.addView(EditUi.label(a, getString(R.string.add_sound_title)), EditUi.lp(a, 10))
                if (addUri == null) add.addView(EditUi.action(a, getString(R.string.add_sound_pick), false, Icons.MUSIC) { pickAdd() }, EditUi.lp(a, 8))
                else {
                    add.addView(EditUi.picked(a, Icons.MUSIC, addName, getString(R.string.edit_snd_note), { pickAdd() }, { addUri = null; addName = ""; fillDyn() }), EditUi.lp(a, 8))
                    add.addView(EditUi.chips(a, listOf(getString(R.string.add_sound_mix), getString(R.string.add_sound_replace)), addMode) { addMode = it }, EditUi.lp(a, 10))
                    add.addView(EditUi.note(a, getString(R.string.add_sound_vol)), EditUi.lp(a, 10))
                    add.addView(EditUi.chips(a, ADD_VOLS.map { (if (it > 0) "+" else "") + it.toInt() + " dB" }, addVolIdx) { addVolIdx = it }, EditUi.lp(a, 6))
                }
                add.addView(EditUi.note(a, getString(R.string.add_sound_hint_video)), EditUi.lp(a, 6))
                dyn.addView(add, EditUi.lp(a, 12))
            }
            if (outMode == 0 || outMode == 3) {
                val rt = EditUi.card(a, getString(R.string.edit_rotate))
                rt.addView(EditUi.chips(a, listOf("0°", "90°", "180°", "270°"), rot / 90) { rot = it * 90 }, EditUi.lp(a, 10))
                dyn.addView(rt, EditUi.lp(a, 12))
            }
            if (outMode == 0) {
                val sp = EditUi.card(a, getString(R.string.edit_split), getString(R.string.edit_split_hint))
                sp.addView(EditUi.timeField(a, getString(R.string.edit_split_min), splitMin) { splitMin = it }, EditUi.lp(a, 10))
                dyn.addView(sp, EditUi.lp(a, 12))
            }
        }
        fillDyn()

        // ---- the main action stays at the bottom of the screen
        pg.bottom.addView(EditUi.action(a, getString(R.string.edit_save), true, Icons.SAVE) { if (!busy) start(u) }, EditUi.lp(a, 0))
        pg.bottom.addView(EditUi.note(a, getString(R.string.edit_note)).apply { gravity = Gravity.CENTER }, EditUi.lp(a, 6))
        pg.bottom.visibility = View.VISIBLE
    }

    private fun loadThumbs() {
        val u = uri ?: return
        val f = parseTime(from) ?: 0L
        val t = parseTime(to) ?: durSec
        val a = thumbFrom
        val b = thumbTo
        Thread {
            runCatching {
                val r = MediaMetadataRetriever()
                r.setDataSource(this, u)
                val x = r.getScaledFrameAtTime(f * 1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 320, 180)
                val y = r.getScaledFrameAtTime(t.coerceIn(0L, (durSec - 1).coerceAtLeast(0L)) * 1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 320, 180)
                r.release()
                ui.post { if (!isDestroyed) { a?.setImageBitmap(x); b?.setImageBitmap(y) } }
            }
        }.start()
    }

    /** The sound to add under / instead of the video's sound: from the music Library or from the phone's files. */
    private fun pickAdd() {
        AlertDialog.Builder(this)
            .setItems(arrayOf(getString(R.string.export_pick_lib), getString(R.string.export_pick_files))) { _, w ->
                @Suppress("DEPRECATION")
                if (w == 0) {
                    startActivityForResult(Intent(this, LibraryActivity::class.java).putExtra(LibraryArgs.PICK, true).putExtra(LibraryArgs.PICK_TAB, 4), REQ_ADD_LIB)
                } else {
                    startActivityForResult(
                        Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
                            .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("audio/*", "video/*")),
                        REQ_ADD
                    )
                }
            }
            .show()
    }

    /** The picture shown for a few seconds before / after the video: from the Library (photos) or the phone's files. */
    private fun pickImg() {
        AlertDialog.Builder(this)
            .setItems(arrayOf(getString(R.string.export_pick_lib), getString(R.string.export_pick_files))) { _, w ->
                @Suppress("DEPRECATION")
                if (w == 0) {
                    startActivityForResult(Intent(this, LibraryActivity::class.java).putExtra(LibraryArgs.PICK, true).putExtra(LibraryArgs.PICK_TAB, 1), REQ_IMG_LIB)
                } else {
                    startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"), REQ_IMG)
                }
            }
            .show()
    }

    private fun loadImage(u: Uri): android.graphics.Bitmap? = runCatching {
        val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(u)?.use { android.graphics.BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (maxOf(o.outWidth, o.outHeight) / s > 2048) s *= 2
        val o2 = android.graphics.BitmapFactory.Options().apply { inSampleSize = s }
        contentResolver.openInputStream(u)?.use { android.graphics.BitmapFactory.decodeStream(it, null, o2) }
    }.getOrNull()

    private fun hasAudioTrack(u: Uri): Boolean = runCatching {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(this, u, null)
            (0 until ex.trackCount).any { (ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/") }
        } finally {
            ex.release()
        }
    }.getOrDefault(false)

    /** The clip to add at the end: from the app's Library or from the phone's files. */
    private fun pickJoin() {
        AlertDialog.Builder(this)
            .setItems(arrayOf(getString(R.string.export_pick_lib), getString(R.string.export_pick_files))) { _, w ->
                @Suppress("DEPRECATION")
                if (w == 0) {
                    startActivityForResult(Intent(this, LibraryActivity::class.java).putExtra(LibraryArgs.PICK, true).putExtra(LibraryArgs.PICK_TAB, 0), REQ_JOIN_LIB)
                } else {
                    startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("video/*"), REQ_JOIN)
                }
            }
            .show()
    }

    private fun pick() {
        AlertDialog.Builder(this)
            .setItems(arrayOf(getString(R.string.export_pick_lib), getString(R.string.export_pick_files))) { _, w ->
                @Suppress("DEPRECATION")
                if (w == 0) {
                    startActivityForResult(Intent(this, LibraryActivity::class.java).putExtra(LibraryArgs.PICK, true).putExtra(LibraryArgs.PICK_TAB, 0), REQ_LIB)
                } else {
                    val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("video/*")
                    startActivityForResult(i, REQ_PICK)
                }
            }
            .show()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val u = data?.data
        if (res != RESULT_OK || u == null) return
        if (req == REQ_IMG || req == REQ_IMG_LIB) {
            if (req == REQ_IMG) runCatching { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            imgUri = u
            imgName = if (req == REQ_IMG_LIB) (data.getStringExtra(LibraryArgs.NAME) ?: nameOf(u)) else nameOf(u)
            build()
            return
        }
        if (req == REQ_ADD || req == REQ_ADD_LIB) {
            if (req == REQ_ADD) runCatching { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            addUri = u
            addName = if (req == REQ_ADD_LIB) (data.getStringExtra(LibraryArgs.NAME) ?: nameOf(u)) else nameOf(u)
            build()
            return
        }
        if (req == REQ_PICK || req == REQ_JOIN) runCatching { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        if (req == REQ_JOIN || req == REQ_JOIN_LIB) {
            joinUri = u
            joinName = if (req == REQ_JOIN_LIB) (data.getStringExtra(LibraryArgs.NAME) ?: nameOf(u)) else nameOf(u)
            build()
            return
        }
        if (req == REQ_LIB || req == REQ_PICK) {
            setSource(u, if (req == REQ_LIB) (data.getStringExtra(LibraryArgs.NAME) ?: nameOf(u)) else nameOf(u))
            from = ""
            to = ""
            cutOut = false
            build()
        }
    }

    private fun start(u: Uri) {
        val s = parseTime(from) ?: 0L
        val e = parseTime(to) ?: 0L
        if ((e > 0 && e <= s) || (cutOut && e <= s)) {
            Toast.makeText(this, R.string.edit_bad_range, Toast.LENGTH_SHORT).show()
            return
        }
        busy = true
        cancel.set(false)
        val prog = EditProgress(this, getString(R.string.edit_working), cancel)
        val baseName = name.substringBeforeLast('.')
        val m = mute
        val extra = rot
        val base = srcRot
        val mode = outMode
        val speed = SPEEDS[speedIdx]
        val addU = addUri
        val imgU = imgUri
        val cont = if (addU != null || imgU != null) 0 else container // an added sound / picture is written as MP4
        val afmt = audioFmt - 1
        val ffmt = frameFmt
        val cutO = cutOut
        val joined = joinUri
        val doCrop = cropIdx > 0
        val doExact = exactCut || doCrop
        val delayUs = DELAYS_MS[delayIdx] * 1000L
        val cropRatio = if (doCrop) CROP_R[cropIdx - 1] else 0f
        val posNow = cropPos
        val splitSec = ((splitMin.trim().toDoubleOrNull() ?: 0.0) * 60).toLong()
        val totalSec = if (e > 0) e else durSec
        // list of (from, to) pieces in seconds; 0 as "to" means the end
        val pieces = ArrayList<Pair<Long, Long>>()
        if (mode == 0 && splitSec >= 5 && totalSec > splitSec) {
            var p = s
            while (p < totalSec) {
                val q = minOf(p + splitSec, totalSec)
                pieces.add(p to (if (q >= totalSec && e == 0L) 0L else q))
                p = q
            }
        } else pieces.add(s to e)
        Thread {
            var ok = true
            var failMsg: String? = null
            var tmpUri: Uri? = null
            var tmpFile: java.io.File? = null
            try {
                for ((idx, pc) in pieces.withIndex()) {
                    val suffix = if (pieces.size > 1) " (Part ${idx + 1})" else " (Edited)"
                    when (mode) {
                        2 -> {
                            val r = MediaMetadataRetriever()
                            r.setDataSource(this, u)
                            val bmp = r.getFrameAtTime(pc.first * 1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST) ?: throw IllegalStateException("no frame")
                            r.release()
                            val cv = ContentValues().apply {
                                put(MediaStore.Images.Media.DISPLAY_NAME, Stamp.name(baseName, "frame_" + fmt(pc.first).replace(':', '-')) + "." + arrayOf("jpg", "png", "webp")[ffmt])
                                put(MediaStore.Images.Media.MIME_TYPE, arrayOf("image/jpeg", "image/png", "image/webp")[ffmt])
                                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/ClearOverlay")
                            }
                            val o = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: throw IllegalStateException("no output")
                            tmpUri = o
                            contentResolver.openOutputStream(o)!!.use { 
                                when (ffmt) {
                                    1 -> bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it)
                                    2 -> bmp.compress(android.graphics.Bitmap.CompressFormat.WEBP_LOSSLESS, 100, it)
                                    else -> bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 95, it)
                                }
                            }
                            tmpUri = null
                        }
                        3 -> {
                            gifProg = prog
                            val outG = makeGif(u, baseName, pc.first, if (pc.second > 0) pc.second else totalSec, GIF_WIDTHS[gifW], GIF_FPS[gifFps], speed, extra)
                            tmpUri = null
                            lastGifMb = outG
                        }
                        else -> {
                            val audio = mode == 1
                            if (audio && (afmt >= 0 || speed != 1f) && !cutO && joined == null) {
                                // converted sound (AAC / Opus / WAV): the audio exporter decodes the cut part and encodes it again
                                val r = AudioExport.run(
                                    applicationContext, u, baseName + "_" + suffix.trim().trim('(', ')').replace(' ', '_'), AudioCfg.snapshot(), cancel,
                                    AudioExport.Edit(pc.first * 1_000_000L, if (pc.second > 0) pc.second * 1_000_000L else -1L, enhance = false, fmt = maxOf(afmt, 0), speed = speed)
                                ) { prog.set((idx + it) / pieces.size) }
                                if (r.uri == null) throw IllegalStateException(r.error ?: "failed")
                                continue
                            }
                            val coll = if (audio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                            val cv = ContentValues().apply {
                                if (audio) {
                                    put(MediaStore.Audio.Media.DISPLAY_NAME, Stamp.name(baseName, suffix.trim().trim('(', ')').replace(' ', '_')) + ".m4a")
                                    put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
                                    put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/ClearOverlay")
                                    put(MediaStore.Audio.Media.IS_PENDING, 1)
                                } else {
                                    put(MediaStore.Video.Media.DISPLAY_NAME, Stamp.name(baseName, suffix.trim().trim('(', ')').replace(' ', '_')) + "." + arrayOf("mp4", "webm", "3gp")[cont])
                                    put(MediaStore.Video.Media.MIME_TYPE, arrayOf("video/mp4", "video/webm", "video/3gpp")[cont])
                                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/ClearOverlay")
                                    put(MediaStore.Video.Media.IS_PENDING, 1)
                                }
                            }
                            val o = contentResolver.insert(coll, cv) ?: throw IllegalStateException("no output")
                            tmpUri = o
                            val segs = ArrayList<Seg>()
                            if (cutOut && pieces.size == 1 && pc.second > pc.first) {
                                // remove the middle: keep [0, from) and (to, end]
                                if (pc.first > 0) segs.add(Seg(u, 0L, pc.first * 1_000_000L))
                                segs.add(Seg(u, pc.second * 1_000_000L, 0L))
                            } else segs.add(Seg(u, pc.first * 1_000_000L, pc.second * 1_000_000L))
                            val jn = joinUri
                            if (jn != null && pieces.size == 1) segs.add(Seg(jn, 0L, 0L))
                            var extraAudio: Uri? = null
                            if (doExact && !audio) {
                                // frame-accurate cut and / or crop: decode, (crop,) encode again; the sound is copied
                                if (cutO || jn != null || speed != 1f || addU != null || imgU != null) throw IllegalStateException("xcut")
                                val dm = displayShape(u, base)
                                var crop: FloatArray? = null
                                if (doCrop && dm != null) {
                                    val (dw0, dh0) = dm
                                    val cur = dw0.toFloat() / dh0
                                    var cw = 1f
                                    var ch = 1f
                                    if (cropRatio < cur) cw = cropRatio / cur else ch = cur / cropRatio
                                    val px = when (posNow) { 0 -> 0f; 2 -> 1f - cw; else -> (1f - cw) / 2f }
                                    val py = when (posNow) { 0 -> 0f; 2 -> 1f - ch; else -> (1f - ch) / 2f }
                                    crop = floatArrayOf(px, py, cw, ch)
                                }
                                contentResolver.openFileDescriptor(o, "rw")!!.use { pfd ->
                                    StillInsert(applicationContext).run(
                                        pfd.fileDescriptor,
                                        StillInsert.Opts(u, null, false, false, 0f, pc.first * 1_000_000L,
                                            if (pc.second > 0) pc.second * 1_000_000L else 0L, (base + extra) % 360, !m,
                                            crop, base, delayUs),
                                        cancel
                                    ) { prog.set((idx + it) / pieces.size) }
                                }
                                contentResolver.update(o, ContentValues().apply { put("is_pending", 0) }, null, null)
                                tmpUri = null
                                continue
                            }
                            if (imgU != null && !audio) {
                                if (pieces.size != 1 || cutO || jn != null || speed != 1f || addU != null) throw IllegalStateException("stillunsupported")
                                val bmp = loadImage(imgU) ?: throw IllegalStateException("image")
                                contentResolver.openFileDescriptor(o, "rw")!!.use { pfd ->
                                    StillInsert(applicationContext).run(
                                        pfd.fileDescriptor,
                                        StillInsert.Opts(u, bmp, imgPos != 1, imgPos != 0, IMG_SECS[imgSecIdx], pc.first * 1_000_000L,
                                            if (pc.second > 0) pc.second * 1_000_000L else 0L, (base + extra) % 360, !m),
                                        cancel
                                    ) { prog.set(it) }
                                }
                                contentResolver.update(o, ContentValues().apply { put("is_pending", 0) }, null, null)
                                tmpUri = null
                                continue
                            }
                            if (addU != null && !audio) {
                                if (pieces.size != 1 || cutO || jn != null) throw IllegalStateException("addsound")
                                val lenUs = (if (pc.second > 0) pc.second else totalSec) * 1_000_000L - pc.first * 1_000_000L
                                val replace = addMode == 1 || speed != 1f || m || !hasAudioTrack(u)
                                val tmp = java.io.File(cacheDir, "addsound_" + System.nanoTime() + ".m4a")
                                tmpFile = tmp
                                val vol = ADD_VOLS[addVolIdx]
                                val ar = if (replace) {
                                    val effLen = if (lenUs > 0) (lenUs / speed).toLong() else -1L
                                    AudioExport.run(applicationContext, addU, "x", AudioCfg.snapshot(), cancel,
                                        AudioExport.Edit(0L, effLen, gainDb = vol, enhance = false, fmt = 0, outFile = tmp)) { prog.set(it * 0.5f) }
                                } else {
                                    AudioExport.run(applicationContext, u, "x", AudioCfg.snapshot(), cancel,
                                        AudioExport.Edit(pc.first * 1_000_000L, if (pc.second > 0) pc.second * 1_000_000L else -1L, enhance = false, fmt = 0,
                                            mixUri = addU, mixGainDb = vol, outFile = tmp)) { prog.set(it * 0.5f) }
                                }
                                if (ar.uri == null) throw IllegalStateException(ar.error ?: "sound failed")
                                extraAudio = Uri.fromFile(tmp)
                            }
                            contentResolver.openFileDescriptor(o, "rw")!!.use { pfd ->
                                remux(segs, m || (!audio && speed != 1f) || extraAudio != null, audio, speed, (base + extra) % 360, pfd.fileDescriptor, if (audio) 0 else cont, extraAudio, if (audio || m) 0L else delayUs) { f ->
                                    val lo = if (extraAudio != null) 0.5f else 0f
                                    prog.set((idx + lo + f * (1f - lo)) / pieces.size)
                                }
                            }
                            contentResolver.update(o, ContentValues().apply { put("is_pending", 0) }, null, null)
                            tmpUri = null
                        }
                    }
                }
            } catch (t: Throwable) {
                ok = false
                if (t.message == "clips differ") failMsg = getString(R.string.edit_join_differ)
                if (t.message == "codec") failMsg = getString(R.string.edit_codec_fail)
                if (t.message == "xcut") failMsg = getString(R.string.edit_xcut_unsupported)
                if (t.message == "addsound") failMsg = getString(R.string.edit_add_unsupported)
                if (t.message == "stillunsupported") failMsg = getString(R.string.edit_img_unsupported)
                if (t.message == "image") failMsg = getString(R.string.edit_img_fail)
                if (t.message == "cancelled") failMsg = ""
                else if (failMsg == null) failMsg = getString(R.string.edit_failed) + (t.message?.takeIf { it.isNotBlank() }?.let { "\n$it" } ?: "")
                tmpUri?.let { runCatching { contentResolver.delete(it, null, null) } }
            }
            tmpFile?.let { runCatching { it.delete() } }
            prog.close()
            ui.post {
                busy = false
                if (isDestroyed) return@post
                val msg = if (ok && mode == 3 && lastGifMb > 0) getString(R.string.edit_gif_done_fmt, lastGifMb) else if (ok) getString(R.string.edit_done) else (failMsg ?: getString(R.string.edit_failed))
                if (msg.isNotEmpty()) Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    /** The size of the picture as it is shown (width, height) for a file turned by [rot]; null when it cannot be read. */
    private fun displayShape(u: Uri, rot: Int): Pair<Int, Int>? = runCatching {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(this, u)
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)!!.toInt()
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)!!.toInt()
            // the metadata width / height are the stored ones: turned by the file's rotation
            if (rot % 180 == 90) h to w else w to h
        } finally { r.release() }
    }.getOrNull()

    private var lastGifMb = 0.0
    private var gifProg: EditProgress? = null

    /**
     * Makes an animated GIF of [fromSec]..[toSec]: a frame is taken every 1/[fps] s, scaled to [width] px (the long side),
     * turned [extraRot] degrees and written with the app's own GIF writer. Saved to Pictures/ClearOverlay. Returns the size in MB.
     */
    private fun makeGif(u: Uri, baseName: String, fromSec: Long, toSec: Long, width: Int, fps: Int, speed: Float, extraRot: Int): Double {
        val r = MediaMetadataRetriever()
        r.setDataSource(this, u)
        val vw0 = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
        val vh0 = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
        val rot0 = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
        val swap = rot0 == 90 || rot0 == 270
        val sw = if (swap) vh0 else vw0
        val sh = if (swap) vw0 else vh0
        if (sw <= 0 || sh <= 0) { r.release(); throw IllegalStateException("no video") }
        val turned = extraRot == 90 || extraRot == 270
        val ow0 = if (turned) sh else sw
        val oh0 = if (turned) sw else sh
        val k = width.toFloat() / maxOf(ow0, oh0)
        val ow = maxOf(2, Math.round(ow0 * k))
        val oh = maxOf(2, Math.round(oh0 * k))
        val endSec = if (toSec > fromSec) toSec else durSec
        val spanUs = (endSec - fromSec).coerceAtLeast(1L) * 1_000_000L
        val frames = minOf(MAX_GIF_FRAMES, (spanUs / 1_000_000.0 * fps).toInt().coerceAtLeast(1))
        val delay = Math.round(100f / fps / speed).coerceAtLeast(2)
        val cv = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, Stamp.name(baseName, "gif") + ".gif")
            put(MediaStore.Images.Media.MIME_TYPE, "image/gif")
            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/ClearOverlay")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val o = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: run { r.release(); throw IllegalStateException("no output") }
        var done = false
        var bytes = 0L
        try {
            val os = java.io.BufferedOutputStream(contentResolver.openOutputStream(o)!!, 64 * 1024)
            val gw = GifWriter(os, ow, oh, true)
            val px = IntArray(ow * oh)
            for (i in 0 until frames) {
                if (cancel.get()) throw IllegalStateException("cancelled")
                val tUs = fromSec * 1_000_000L + spanUs * i / frames
                var b = r.getScaledFrameAtTime(tUs, MediaMetadataRetriever.OPTION_CLOSEST, if (turned) oh else ow, if (turned) ow else oh)
                    ?: r.getFrameAtTime(tUs, MediaMetadataRetriever.OPTION_CLOSEST) ?: continue
                if (extraRot != 0) {
                    val m = android.graphics.Matrix().apply { postRotate(extraRot.toFloat()) }
                    val t = android.graphics.Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
                    if (t !== b) b.recycle()
                    b = t
                }
                if (b.width != ow || b.height != oh) {
                    val t = android.graphics.Bitmap.createScaledBitmap(b, ow, oh, true)
                    if (t !== b) b.recycle()
                    b = t
                }
                b.getPixels(px, 0, ow, 0, 0, ow, oh)
                b.recycle()
                gw.add(px, delay, true)
                gifProg?.set((i + 1f) / frames)
            }
            gw.finish()
            os.close()
            done = true
        } finally {
            runCatching { r.release() }
            if (done) {
                runCatching { contentResolver.update(o, ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }, null, null) }
                bytes = runCatching { contentResolver.openFileDescriptor(o, "r")?.use { it.statSize } ?: 0L }.getOrDefault(0L)
            } else runCatching { contentResolver.delete(o, null, null) }
        }
        return bytes / 1048576.0
    }

    private class Seg(val uri: Uri, val startUs: Long, val endUs: Long)

    /** Writes the segments one after the other into one file (no re-encoding). Later segments must have the same tracks as the first. */
    private fun remux(segs: List<Seg>, mute: Boolean, audioOnly: Boolean, speed: Float, rotation: Int, out: java.io.FileDescriptor, container: Int = 0, extraAudio: Uri? = null, audioDelayUs: Long = 0L, progress: ((Float) -> Unit)? = null) {
        val mux = MediaMuxer(out, when (container) {
            1 -> MediaMuxer.OutputFormat.MUXER_OUTPUT_WEBM
            2 -> MediaMuxer.OutputFormat.MUXER_OUTPUT_3GPP
            else -> MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4
        })
        var started = false
        var extraEx: MediaExtractor? = null
        var extraTr = -1
        var sig: List<String> = emptyList()
        val muxTracks = ArrayList<Int>()
        val audioMux = HashSet<Int>() // muxer tracks that carry sound (they can be moved by audioDelayUs)
        var offset = 0L
        val buf = ByteBuffer.allocate(4 * 1024 * 1024)
        val info = MediaCodec.BufferInfo()
        try {
            for ((si, sg) in segs.withIndex()) {
                val ex = MediaExtractor()
                try {
                    ex.setDataSource(this, sg.uri, null)
                    val sel = ArrayList<Int>()
                    val now = ArrayList<String>()
                    for (i in 0 until ex.trackCount) {
                        val f = ex.getTrackFormat(i)
                        val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                        if ((mime.startsWith("video/") && !audioOnly) || (mime.startsWith("audio/") && !mute)) {
                            if (si == 0) {
                                val t = runCatching { mux.addTrack(f) }.getOrNull()
                                if (t == null) { if (container != 0) throw IllegalStateException("codec") else continue }
                                muxTracks.add(t)
                                if (mime.startsWith("audio/")) audioMux.add(t)
                            }
                            sel.add(i)
                            now.add(mime + if (mime.startsWith("video/") && f.containsKey(MediaFormat.KEY_WIDTH)) "@" + f.getInteger(MediaFormat.KEY_WIDTH) + "x" + f.getInteger(MediaFormat.KEY_HEIGHT) else "")
                        }
                    }
                    if (sel.isEmpty()) throw IllegalStateException("no tracks")
                    if (si == 0) {
                        sig = now
                        if (!audioOnly) runCatching { mux.setOrientationHint(rotation) }
                        if (extraAudio != null) {
                            val x = MediaExtractor()
                            extraEx = x
                            x.setDataSource(this, extraAudio, null)
                            for (i in 0 until x.trackCount) {
                                val tf = x.getTrackFormat(i)
                                if ((tf.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { extraTr = mux.addTrack(tf); x.selectTrack(i); break }
                            }
                        }
                        mux.start()
                        started = true
                    } else if (now != sig) throw IllegalStateException("clips differ")
                    val map = HashMap<Int, Int>()
                    sel.forEachIndexed { k, i -> map[i] = muxTracks[k]; ex.selectTrack(i) }
                    if (sg.startUs > 0) ex.seekTo(sg.startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
                    var base = -1L
                    var last = 0L
                    var srcDurUs = 0L
                    for (i in sel) srcDurUs = maxOf(srcDurUs, runCatching { ex.getTrackFormat(i).getLong(MediaFormat.KEY_DURATION) }.getOrDefault(0L))
                    val spanUs = ((if (sg.endUs > 0) sg.endUs else srcDurUs) - sg.startUs).coerceAtLeast(1L)
                    while (!cancel.get()) {
                        buf.clear()
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0) break
                        val t = ex.sampleTime
                        if (sg.endUs > 0 && t > sg.endUs) break
                        if (base < 0) base = t
                        val tr = map[ex.sampleTrackIndex]
                        if (tr != null) {
                            val ts = offset + ((t - base).coerceAtLeast(0) / speed).toLong()
                            if (ts > last) last = ts
                            val wts = if (audioDelayUs != 0L && tr in audioMux) ts + audioDelayUs else ts
                            if (wts >= 0L) {
                                info.set(0, n, wts, if (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                                mux.writeSampleData(tr, buf, info)
                            }
                            if (progress != null && base >= 0) progress((si + ((t - sg.startUs).coerceAtLeast(0L).toFloat() / spanUs).coerceIn(0f, 1f)) / segs.size)
                        }
                        ex.advance()
                    }
                    if (cancel.get()) throw IllegalStateException("cancelled")
                    offset = last + 40_000L
                } finally {
                    ex.release()
                }
            }
            // the added sound track, as long as the picture
            val xe = extraEx
            if (xe != null && extraTr >= 0 && started) {
                while (!cancel.get()) {
                    buf.clear()
                    val n = xe.readSampleData(buf, 0)
                    if (n < 0) break
                    val t = xe.sampleTime
                    if (t > offset) break
                    info.set(0, n, t, 0)
                    mux.writeSampleData(extraTr, buf, info)
                    xe.advance()
                }
            }
        } finally {
            runCatching { extraEx?.release() }
            if (started) runCatching { mux.stop() }
            runCatching { mux.release() }
        }
    }

    private companion object {
        val SPEEDS = floatArrayOf(0.25f, 0.5f, 1f, 2f, 4f, 8f)
        const val REQ_PICK = 41
        const val REQ_LIB = 43
        const val REQ_JOIN = 44
        const val REQ_JOIN_LIB = 45
        val GIF_WIDTHS = intArrayOf(240, 320, 480, 640)
        val GIF_FPS = intArrayOf(8, 10, 12, 15, 20)
        const val MAX_GIF_FRAMES = 300
        const val REQ_ADD = 46
        const val REQ_ADD_LIB = 47
        const val REQ_IMG = 48
        const val REQ_IMG_LIB = 49
        val IMG_SECS = floatArrayOf(2f, 3f, 5f, 8f)
        val CROPS = arrayOf("1:1", "4:3", "3:4", "16:9", "9:16", "21:9")
        val CROP_R = floatArrayOf(1f, 4f / 3f, 3f / 4f, 16f / 9f, 9f / 16f, 21f / 9f)
        val DELAYS_MS = intArrayOf(-500, -250, -100, 0, 100, 250, 500)
        val ADD_VOLS = floatArrayOf(-12f, -6f, 0f, 3f, 6f)
    }
}
