package app.clearoverlay

/**
 * The picture settings the GL pipeline reads. The live app uses [LiveFx] (the current [Cfg] values, so sliders apply at
 * once); a video export uses its own fixed [FxSet], so what is chosen in a settings panel meanwhile cannot change an
 * export that is running.
 */
interface FxView {
    val mode: Int
    val boost: Boolean
    val vivid: Float
    val contrast: Float
    val shadows: Float get() = 0f
    val highlights: Float get() = 0f
    val saturation: Float get() = 0f
    val warmth: Float get() = 0f
    val brightness: Float get() = 0f
    val vibrance: Float get() = 0f
    val tint: Float get() = 0f
    val grain: Float get() = 0f
    val clarity: Float get() = 0f
    val antiRing: Float get() = 0f
    val deint: Int get() = 0
    val detail: Float
    val detailSize: Float
    val denoise: Float
    val deband: Float
    val aaMode: Int
    val aaStrength: Float
    val sharp: Float
    val inRes: Int
    val outRes: Int
    /** Middle step of the resolution chain (short side, 0 = off): the cleaned picture is brought down to this size first. */
    val midRes: Int get() = 0
    /** Smart fix (measured white balance / levels / shadow lift). */
    val smartFix: Boolean get() = false
    /** Clean upscale chain (denoise -> sharpen -> anti-aliasing -> upscale -> colour restore). */
    val cleanUp: Boolean get() = false
    val cleanLevel: Float get() = 0.6f
    /** The four finishing effects, 0..1 (Game Light, Faint detail, Protect noise, Colour clean-up). The defaults are the live settings; [SmartOpt] tries lighter values. */
    val gameLight: Float get() = Cfg.gameLight
    val faintLift: Float get() = Cfg.faintLift
    val sharpProtect: Float get() = Cfg.sharpProtect
    val chromaClean: Float get() = Cfg.chromaClean
}

object LiveFx : FxView {
    override val mode: Int get() = Cfg.mode
    override val boost: Boolean get() = Cfg.boost
    override val vivid: Float get() = Cfg.vivid
    override val contrast: Float get() = (Cfg.contrast + Cfg.tContrast).coerceIn(-1f, 1f)
    override val shadows: Float get() = (Cfg.shadows + Cfg.tShadows).coerceIn(-1f, 1f)
    override val highlights: Float get() = (Cfg.highlights + Cfg.tHighlights).coerceIn(-1f, 1f)
    override val saturation: Float get() = (Cfg.saturation + Cfg.tSaturation).coerceIn(-1f, 1f)
    override val warmth: Float get() = Cfg.warmth
    override val brightness: Float get() = Cfg.brightness
    override val vibrance: Float get() = Cfg.vibrance
    override val tint: Float get() = Cfg.tint
    override val grain: Float get() = Cfg.grain
    override val clarity: Float get() = Cfg.clarity
    override val antiRing: Float get() = Cfg.antiRing
    override val deint: Int get() = Cfg.deint
    override val detail: Float get() = Cfg.detail
    override val detailSize: Float get() = Cfg.detailSize
    override val denoise: Float get() = (Cfg.denoise + Cfg.tDenoise).coerceIn(0f, 1f)
    override val deband: Float get() = Cfg.deband
    override val aaMode: Int get() = Cfg.aaMode
    override val aaStrength: Float get() = Cfg.aaStrength
    override val sharp: Float get() = (Cfg.sharp + Cfg.tSharp).coerceIn(0f, 1f)
    override val inRes: Int get() = Cfg.inRes
    override val outRes: Int get() = Cfg.outRes
    override val midRes: Int get() = Cfg.midRes
    override val smartFix: Boolean get() = Cfg.smartFix
    override val cleanUp: Boolean get() = Cfg.cleanUp
    override val cleanLevel: Float get() = Cfg.cleanLevel
}

class FxSet(
    override val mode: Int,
    override val sharp: Float,
    override val detail: Float,
    override val detailSize: Float,
    override val denoise: Float,
    override val deband: Float,
    override val aaMode: Int,
    override val aaStrength: Float,
    override val boost: Boolean = false,
    override val vivid: Float = 0f,
    override val contrast: Float = 0f,
    override val inRes: Int = 0,
    override val outRes: Int = 0,
    override val smartFix: Boolean = false,
    override val shadows: Float = 0f,
    override val highlights: Float = 0f,
    override val saturation: Float = 0f,
    override val warmth: Float = 0f,
    override val grain: Float = 0f,
    override val clarity: Float = 0f,
    override val antiRing: Float = 0f,
    override val deint: Int = 0,
    override val brightness: Float = 0f,
    override val vibrance: Float = 0f,
    override val tint: Float = 0f,
    override val cleanUp: Boolean = false,
    override val cleanLevel: Float = 0.6f
) : FxView

/**
 * The newer picture settings (shadows, highlights, saturation, warmth, film grain, clarity, anti-ringing, deinterlace, contrast and, for video, cutting the black bars) that a file export
 * ("Upscale a video to a new file", GIF) carries. Kept as one short text so it fits an intent extra, the saved unfinished job and the job id.
 */
class Look(
    var shadows: Float = 0f,
    var highlights: Float = 0f,
    var saturation: Float = 0f,
    var warmth: Float = 0f,
    var grain: Float = 0f,
    var clarity: Float = 0f,
    var antiRing: Float = 0f,
    var deint: Int = 0,
    var contrast: Float = 0f,
    /** Video export only: cut the black bars (measured once with [BarScan]). */
    var cutBars: Boolean = false,
    /** Video export only: "Auto" - the look is chosen by looking at the video when the job starts ([LookAuto]); the sliders are not used. */
    var auto: Boolean = false,
    /**
     * "Smooth live" (video export, streaming): the effects are the player's own settings, copied when the job is started - the same picture
     * as playing the video directly. When on, the fields below replace what the quality tier would give.
     */
    var live: Boolean = false,
    var lSharp: Float = 0f,
    var lDetail: Float = 0f,
    var lDetailSize: Float = 0f,
    var lDenoise: Float = 0f,
    var lDeband: Float = 0f,
    var lAaMode: Int = 0,
    var lAaStr: Float = 0f,
    var lBoost: Boolean = false,
    var lVivid: Float = 0f,
    var lClean: Boolean = false,
    var lCleanLevel: Float = 0.6f,
    /** "Same as the player": the four finishing effects of the live picture (Game Light, Faint detail, Sharp protect, Colour clean-up), 0..1. */
    var lLight: Float = 0f,
    var lFaint: Float = 0f,
    var lProtect: Float = 0f,
    var lChroma: Float = 0f,
    /** Newer tone settings: custom sliders of the export and, for "same as the player", copied from it. */
    var brightness: Float = 0f,
    var vibrance: Float = 0f,
    var tint: Float = 0f,
    var vignette: Float = 0f,
    var fade: Float = 0f,
    /** "Same as the player" only: the strength of Smart fix (the player's slider), 0..2; -1 = not copied (the export uses the setting it had). */
    var lFixLv: Float = -1f,
    /** "Same as the player" only: the AI upscaler 2x of the player (0 off, 1 the 8-channel network, 2 the 12-channel one) and its strength. */
    var lSr: Int = 0,
    var lSrGain: Float = 1f,
    /** The family of the network (see Cfg.srNet): 0 Standard, 1 Classic, 2 16-channel, 3 24-channel, 4 4-channel. */
    var lSrNet: Int = 0,
    /** AI 2x also when the doubled picture is bigger than the output (see Cfg.srBig); the export has its own choice. */
    var lSrBig: Boolean = true,
    /** The Neural upscaler's model (Cfg.neuralModel: 0 Lite, 1 Plus, 2 Medium); -1 = the player's current choice. */
    var lNeural: Int = -1
) {
    val neutral: Boolean
        get() = !auto && !live && shadows == 0f && highlights == 0f && saturation == 0f && warmth == 0f && grain == 0f && clarity == 0f && antiRing == 0f && deint == 0 && contrast == 0f && !cutBars &&
            brightness == 0f && vibrance == 0f && tint == 0f && vignette == 0f && fade == 0f && lSr == 0 && lNeural < 0 && lSrBig

    /** "" when everything is off (old jobs and their ids stay as they were), else ten numbers (percent, the deinterlace choice, contrast in percent, bars 0 / 1). */
    fun encode(): String {
        if (neutral) return ""
        fun pc(v: Float) = Math.round(v * 100f)
        return listOf(pc(shadows), pc(highlights), pc(saturation), pc(warmth), pc(grain), pc(clarity), pc(antiRing), deint.coerceIn(0, 2), pc(contrast), if (cutBars) 1 else 0, if (auto) 1 else 0) .plus(if (!live) emptyList<Int>() else listOf(1, pc(lSharp), pc(lDetail), pc(lDetailSize), pc(lDenoise), pc(lDeband), lAaMode, pc(lAaStr), if (lBoost) 1 else 0, pc(lVivid), if (lClean) 1 else 0, pc(lCleanLevel), pc(lLight), pc(lFaint), pc(lProtect), pc(lChroma)))
            // the newer ones come after (positions 27..32); a look that is not "live" is padded to position 26 with zeros (0 at position 11 = not live)
            .let { l -> if (brightness == 0f && vibrance == 0f && tint == 0f && vignette == 0f && fade == 0f && lFixLv < 0f && lSr == 0 && lSrNet == 0 && lSrBig && lNeural < 0) l else (if (live) l else l + List(16) { 0 }) + listOf(pc(brightness), pc(vibrance), pc(tint), pc(vignette), pc(fade), if (lFixLv < 0f) -1 else pc(lFixLv), lSr.coerceIn(0, 2), pc(lSrGain), lSrNet.coerceIn(0, 4), if (lSrBig) 1 else 0, lNeural.coerceIn(-1, 2)) }
            .joinToString(",")
    }

    companion object {
        fun decode(s: String?): Look {
            if (s.isNullOrBlank()) return Look()
            val p = s.split(',').map { it.trim().toIntOrNull() ?: 0 }
            fun g(i: Int) = p.getOrElse(i) { 0 }
            return Look(
                (g(0) / 100f).coerceIn(-1f, 1f), (g(1) / 100f).coerceIn(-1f, 1f), (g(2) / 100f).coerceIn(-1f, 1f), (g(3) / 100f).coerceIn(-1f, 1f),
                (g(4) / 100f).coerceIn(0f, 1f), (g(5) / 100f).coerceIn(-1f, 1f), (g(6) / 100f).coerceIn(0f, 1f), g(7).coerceIn(0, 2),
                (g(8) / 100f).coerceIn(-1f, 1f), g(9) == 1, g(10) == 1,
                live = g(11) == 1, lSharp = (g(12) / 100f).coerceIn(0f, 4f), lDetail = (g(13) / 100f).coerceIn(0f, 4f), lDetailSize = (g(14) / 100f).coerceIn(0f, 4f),
                lDenoise = (g(15) / 100f).coerceIn(0f, 4f), lDeband = (g(16) / 100f).coerceIn(0f, 4f), lAaMode = g(17).coerceIn(0, 8), lAaStr = (g(18) / 100f).coerceIn(0f, 4f),
                lBoost = g(19) == 1, lVivid = (g(20) / 100f).coerceIn(0f, 4f),
                lClean = g(21) == 1, lCleanLevel = if (p.size > 22) (g(22) / 100f).coerceIn(0f, 1f) else 0.6f,
                lLight = (g(23) / 100f).coerceIn(0f, 1f), lFaint = (g(24) / 100f).coerceIn(0f, 1f), lProtect = (g(25) / 100f).coerceIn(0f, 1f), lChroma = (g(26) / 100f).coerceIn(0f, 1f),
                brightness = (g(27) / 100f).coerceIn(-1f, 1f), vibrance = (g(28) / 100f).coerceIn(-1f, 1f), tint = (g(29) / 100f).coerceIn(-1f, 1f),
                vignette = (g(30) / 100f).coerceIn(-1f, 1f), fade = (g(31) / 100f).coerceIn(0f, 1f), lFixLv = if (p.size > 32 && g(32) >= 0) (g(32) / 100f).coerceIn(0f, 2f) else -1f,
                lSr = g(33).coerceIn(0, 2), lSrGain = if (p.size > 34 && g(34) > 0) (g(34) / 100f).coerceIn(0.5f, 1.6f) else 1f,
                lSrNet = g(35).coerceIn(0, 4), lSrBig = p.size <= 36 || g(36) == 1, lNeural = if (p.size > 37) p[37].coerceIn(-1, 2) else -1
            )
        }

        /** What the player / GIF viewer shows now (after [Cfg.bind] of the kind of file). */
        /** Copies the player's live picture settings into [lk] (call after [Cfg.bind] of the kind of file): the export then draws the same picture as playing. */
        fun copyLive(lk: Look) {
            lk.live = true
            lk.lSharp = Cfg.sharp; lk.lDetail = Cfg.detail; lk.lDetailSize = Cfg.detailSize
            lk.lDenoise = Cfg.denoise; lk.lDeband = Cfg.deband; lk.lAaMode = Cfg.aaMode; lk.lAaStr = Cfg.aaStrength
            lk.lBoost = Cfg.boost; lk.lVivid = Cfg.vivid; lk.lClean = Cfg.cleanUp; lk.lCleanLevel = Cfg.cleanLevel
            lk.lLight = Cfg.gameLight; lk.lFaint = Cfg.faintLift; lk.lProtect = Cfg.sharpProtect; lk.lChroma = Cfg.chromaClean
            lk.brightness = Cfg.brightness; lk.vibrance = Cfg.vibrance; lk.tint = Cfg.tint; lk.vignette = Cfg.vignette; lk.fade = Cfg.fade; lk.lFixLv = Cfg.fixLevel
            lk.lSr = if (!Cfg.srLive) 0 else if (Cfg.srWide) 2 else 1; lk.lSrGain = Cfg.srGain; lk.lSrNet = Cfg.srNet; lk.lSrBig = Cfg.srBig; lk.lNeural = Cfg.neuralModel.coerceIn(0, 2)
        }

        fun fromCfg() = Look(Cfg.shadows, Cfg.highlights, Cfg.saturation, Cfg.warmth, Cfg.grain, Cfg.clarity, Cfg.antiRing, Cfg.deint, Cfg.contrast, Cfg.autoCrop, brightness = Cfg.brightness, vibrance = Cfg.vibrance, tint = Cfg.tint, vignette = Cfg.vignette, fade = Cfg.fade)
    }
}

/**
 * "Smooth live": the settings the pipeline really uses while the phone cannot keep up. [level] 0 = as chosen; every step lightens the heaviest
 * parts first and never touches the saved settings (the pipeline wraps the live settings in this and drops the wrapper when it keeps up again):
 * 1 frame generation, temporal clean-up and the Boost pass off (done in [GlPipeline]); 2 Denoise, Deband, anti-aliasing and NIS crispness off, CRSC Edge one level lower;
 * 3 the upscaler one step lighter; 4 the lightest upscaler (FSR 1); 5 also Clarity / anti-ringing off and the output size at most 1080 p.
 */
class GovFx(private val b: FxView, private val level: Int) : FxView by b {
    private fun lighter(m: Int): Int = when (m) {
        Cfg.MODE_NIS_ORIG -> Cfg.MODE_NIS_FAST
        Cfg.MODE_NIS_FAST, Cfg.MODE_NIS_FINE -> Cfg.MODE_NIS_MID
        Cfg.MODE_LANCZOS, Cfg.MODE_CLEAR, Cfg.MODE_ART, Cfg.MODE_NEURAL, Cfg.MODE_NIS_MID, Cfg.MODE_NIS, Cfg.MODE_NIS_SOFT, Cfg.MODE_SGSR -> if (m == Cfg.MODE_LANCZOS) Cfg.MODE_NIS_MID else Cfg.MODE_FSR
        else -> m
    }

    override val mode: Int
        get() {
            val m = b.mode
            return when {
                level >= 4 -> if (m == Cfg.MODE_SHARP || m == Cfg.MODE_FAST || m == Cfg.MODE_RAW) m else Cfg.MODE_FSR
                level >= 3 -> lighter(m)
                else -> m
            }
        }
    override val boost: Boolean get() = b.boost && level < 1
    override val cleanUp: Boolean get() = b.cleanUp && level < 2
    override val denoise: Float get() = if (level >= 2) 0f else b.denoise
    override val deband: Float get() = if (level >= 2) 0f else b.deband
    override val aaMode: Int get() = if (level >= 2) Cfg.AA_OFF else b.aaMode
    override val clarity: Float get() = if (level >= 5) 0f else b.clarity
    override val antiRing: Float get() = if (level >= 5) 0f else b.antiRing
    override val outRes: Int get() = if (level >= 5 && b.outRes > 1080) 1080 else b.outRes
}
