package app.clearoverlay

/**
 * The picture settings the GL pipeline reads. The live app uses [LiveFx] (the current [Cfg] values, so sliders apply at
 * once); a video export uses its own fixed [FxSet], so what is chosen in a settings panel meanwhile cannot change an
 * export that is running.
 */
interface FxView {
    val mode: Int
    val boost: Boolean
    val vivid: Float
    val contrast: Float
    val detail: Float
    val detailSize: Float
    val denoise: Float
    val deband: Float
    val aaMode: Int
    val aaStrength: Float
    val sharp: Float
    val inRes: Int
    val outRes: Int
}

object LiveFx : FxView {
    override val mode: Int get() = Cfg.mode
    override val boost: Boolean get() = Cfg.boost
    override val vivid: Float get() = Cfg.vivid
    override val contrast: Float get() = Cfg.contrast
    override val detail: Float get() = Cfg.detail
    override val detailSize: Float get() = Cfg.detailSize
    override val denoise: Float get() = Cfg.denoise
    override val deband: Float get() = Cfg.deband
    override val aaMode: Int get() = Cfg.aaMode
    override val aaStrength: Float get() = Cfg.aaStrength
    override val sharp: Float get() = Cfg.sharp
    override val inRes: Int get() = Cfg.inRes
    override val outRes: Int get() = Cfg.outRes
}

class FxSet(
    override val mode: Int,
    override val sharp: Float,
    override val detail: Float,
    override val detailSize: Float,
    override val denoise: Float,
    override val deband: Float,
    override val aaMode: Int,
    override val aaStrength: Float,
    override val boost: Boolean = false,
    override val vivid: Float = 0f,
    override val contrast: Float = 0f,
    override val inRes: Int = 0,
    override val outRes: Int = 0
) : FxView
