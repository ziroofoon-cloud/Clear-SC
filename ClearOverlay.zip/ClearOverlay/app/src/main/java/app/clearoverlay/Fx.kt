package app.clearoverlay

/**
 * The picture settings the GL pipeline reads. The live app uses [LiveFx] (the current [Cfg] values, so sliders apply at
 * once); a video export uses its own fixed [FxSet], so what is chosen in a settings panel meanwhile cannot change an
 * export that is running.
 */
interface FxView {
    val mode: Int
    val boost: Boolean
    val vivid: Float
    val contrast: Float
    val shadows: Float get() = 0f
    val highlights: Float get() = 0f
    val saturation: Float get() = 0f
    val warmth: Float get() = 0f
    val brightness: Float get() = 0f
    val vibrance: Float get() = 0f
    val tint: Float get() = 0f
    val grain: Float get() = 0f
    val clarity: Float get() = 0f
    val antiRing: Float get() = 0f
    val deint: Int get() = 0
    val detail: Float
    val detailSize: Float
    val denoise: Float
    val deband: Float
    val aaMode: Int
    val aaStrength: Float
    val sharp: Float
    val inRes: Int
    val outRes: Int
    /** Middle step of the resolution chain (short side, 0 = off): the cleaned picture is brought down to this size first. */
    val midRes: Int get() = 0
    /** Smart fix (measured white balance / levels / shadow lift). */
    val smartFix: Boolean get() = false
    /** Clean upscale chain (denoise -> sharpen -> anti-aliasing -> upscale -> colour restore). */
    val cleanUp: Boolean get() = false
    val cleanLevel: Float get() = 0.6f
}

object LiveFx : FxView {
    override val mode: Int get() = Cfg.mode
    override val boost: Boolean get() = Cfg.boost
    override val vivid: Float get() = Cfg.vivid
    override val contrast: Float get() = (Cfg.contrast + Cfg.tContrast).coerceIn(-1f, 1f)
    override val shadows: Float get() = (Cfg.shadows + Cfg.tShadows).coerceIn(-1f, 1f)
    override val highlights: Float get() = (Cfg.highlights + Cfg.tHighlights).coerceIn(-1f, 1f)
    override val saturation: Float get() = (Cfg.saturation + Cfg.tSaturation).coerceIn(-1f, 1f)
    override val warmth: Float get() = Cfg.warmth
    override val brightness: Float get() = Cfg.brightness
    override val vibrance: Float get() = Cfg.vibrance
    override val tint: Float get() = Cfg.tint
    override val grain: Float get() = Cfg.grain
    override val clarity: Float get() = Cfg.clarity
    override val antiRing: Float get() = Cfg.antiRing
    override val deint: Int get() = Cfg.deint
    override val detail: Float get() = Cfg.detail
    override val detailSize: Float get() = Cfg.detailSize
    override val denoise: Float get() = (Cfg.denoise + Cfg.tDenoise).coerceIn(0f, 1f)
    override val deband: Float get() = Cfg.deband
    override val aaMode: Int get() = Cfg.aaMode
    override val aaStrength: Float get() = Cfg.aaStrength
    override val sharp: Float get() = (Cfg.sharp + Cfg.tSharp).coerceIn(0f, 1f)
    override val inRes: Int get() = Cfg.inRes
    override val outRes: Int get() = Cfg.outRes
    override val midRes: Int get() = Cfg.midRes
    override val smartFix: Boolean get() = Cfg.smartFix
    override val cleanUp: Boolean get() = Cfg.cleanUp
    override val cleanLevel: Float get() = Cfg.cleanLevel
}

class FxSet(
    override val mode: Int,
    override val sharp: Float,
    override val detail: Float,
    override val detailSize: Float,
    override val denoise: Float,
    override val deband: Float,
    override val aaMode: Int,
    override val aaStrength: Float,
    override val boost: Boolean = false,
    override val vivid: Float = 0f,
    override val contrast: Float = 0f,
    override val inRes: Int = 0,
    override val outRes: Int = 0,
    override val smartFix: Boolean = false,
    override val shadows: Float = 0f,
    override val highlights: Float = 0f,
    override val saturation: Float = 0f,
    override val warmth: Float = 0f,
    override val grain: Float = 0f,
    override val clarity: Float = 0f,
    override val antiRing: Float = 0f,
    override val deint: Int = 0,
    override val brightness: Float = 0f,
    override val vibrance: Float = 0f,
    override val tint: Float = 0f
) : FxView

/**
 * The newer picture settings (shadows, highlights, saturation, warmth, film grain, clarity, anti-ringing, deinterlace, contrast and, for video, cutting the black bars) that a file export
 * ("Upscale a video to a new file", GIF) carries. Kept as one short text so it fits an intent extra, the saved unfinished job and the job id.
 */
class Look(
    var shadows: Float = 0f,
    var highlights: Float = 0f,
    var saturation: Float = 0f,
    var warmth: Float = 0f,
    var grain: Float = 0f,
    var clarity: Float = 0f,
    var antiRing: Float = 0f,
    var deint: Int = 0,
    var contrast: Float = 0f,
    /** Video export only: cut the black bars (measured once with [BarScan]). */
    var cutBars: Boolean = false,
    /** Video export only: "Auto" - the look is chosen by looking at the video when the job starts ([LookAuto]); the sliders are not used. */
    var auto: Boolean = false,
    /**
     * "Smooth live" (video export, streaming): the effects are the player's own settings, copied when the job is started - the same picture
     * as playing the video directly. When on, the fields below replace what the quality tier would give.
     */
    var live: Boolean = false,
    var lSharp: Float = 0f,
    var lDetail: Float = 0f,
    var lDetailSize: Float = 0f,
    var lDenoise: Float = 0f,
    var lDeband: Float = 0f,
    var lAaMode: Int = 0,
    var lAaStr: Float = 0f,
    var lBoost: Boolean = false,
    var lVivid: Float = 0f
) {
    val neutral: Boolean
        get() = !auto && !live && shadows == 0f && highlights == 0f && saturation == 0f && warmth == 0f && grain == 0f && clarity == 0f && antiRing == 0f && deint == 0 && contrast == 0f && !cutBars

    /** "" when everything is off (old jobs and their ids stay as they were), else ten numbers (percent, the deinterlace choice, contrast in percent, bars 0 / 1). */
    fun encode(): String {
        if (neutral) return ""
        fun pc(v: Float) = Math.round(v * 100f)
        return listOf(pc(shadows), pc(highlights), pc(saturation), pc(warmth), pc(grain), pc(clarity), pc(antiRing), deint.coerceIn(0, 2), pc(contrast), if (cutBars) 1 else 0, if (auto) 1 else 0) .plus(if (!live) emptyList<Int>() else listOf(1, pc(lSharp), pc(lDetail), pc(lDetailSize), pc(lDenoise), pc(lDeband), lAaMode, pc(lAaStr), if (lBoost) 1 else 0, pc(lVivid))).joinToString(",")
    }

    companion object {
        fun decode(s: String?): Look {
            if (s.isNullOrBlank()) return Look()
            val p = s.split(',').map { it.trim().toIntOrNull() ?: 0 }
            fun g(i: Int) = p.getOrElse(i) { 0 }
            return Look(
                (g(0) / 100f).coerceIn(-1f, 1f), (g(1) / 100f).coerceIn(-1f, 1f), (g(2) / 100f).coerceIn(-1f, 1f), (g(3) / 100f).coerceIn(-1f, 1f),
                (g(4) / 100f).coerceIn(0f, 1f), (g(5) / 100f).coerceIn(-1f, 1f), (g(6) / 100f).coerceIn(0f, 1f), g(7).coerceIn(0, 2),
                (g(8) / 100f).coerceIn(-1f, 1f), g(9) == 1, g(10) == 1,
                live = g(11) == 1, lSharp = (g(12) / 100f).coerceIn(0f, 4f), lDetail = (g(13) / 100f).coerceIn(0f, 4f), lDetailSize = (g(14) / 100f).coerceIn(0f, 4f),
                lDenoise = (g(15) / 100f).coerceIn(0f, 4f), lDeband = (g(16) / 100f).coerceIn(0f, 4f), lAaMode = g(17).coerceIn(0, 8), lAaStr = (g(18) / 100f).coerceIn(0f, 4f),
                lBoost = g(19) == 1, lVivid = (g(20) / 100f).coerceIn(0f, 4f)
            )
        }

        /** What the player / GIF viewer shows now (after [Cfg.bind] of the kind of file). */
        fun fromCfg() = Look(Cfg.shadows, Cfg.highlights, Cfg.saturation, Cfg.warmth, Cfg.grain, Cfg.clarity, Cfg.antiRing, Cfg.deint, Cfg.contrast, Cfg.autoCrop)
    }
}

/**
 * "Smooth live": the settings the pipeline really uses while the phone cannot keep up. [level] 0 = as chosen; every step lightens the heaviest
 * parts first and never touches the saved settings (the pipeline wraps the live settings in this and drops the wrapper when it keeps up again):
 * 1 frame generation, temporal clean-up and the Boost pass off (done in [GlPipeline]); 2 Denoise, Deband, anti-aliasing and NIS crispness off, CRSC Edge one level lower;
 * 3 the upscaler one step lighter; 4 the lightest upscaler (FSR 1); 5 also Clarity / anti-ringing off and the output size at most 1080 p.
 */
class GovFx(private val b: FxView, private val level: Int) : FxView by b {
    private fun lighter(m: Int): Int = when (m) {
        Cfg.MODE_NIS_ORIG -> Cfg.MODE_NIS_FAST
        Cfg.MODE_NIS_FAST -> Cfg.MODE_NIS_MID
        Cfg.MODE_LANCZOS, Cfg.MODE_CLEAR, Cfg.MODE_NIS_MID, Cfg.MODE_NIS, Cfg.MODE_NIS_SOFT, Cfg.MODE_SGSR -> if (m == Cfg.MODE_LANCZOS) Cfg.MODE_NIS_MID else Cfg.MODE_FSR
        else -> m
    }

    override val mode: Int
        get() {
            val m = b.mode
            return when {
                level >= 4 -> if (m == Cfg.MODE_SHARP || m == Cfg.MODE_FAST || m == Cfg.MODE_RAW) m else Cfg.MODE_FSR
                level >= 3 -> lighter(m)
                else -> m
            }
        }
    override val boost: Boolean get() = b.boost && level < 1
    override val cleanUp: Boolean get() = b.cleanUp && level < 2
    override val denoise: Float get() = if (level >= 2) 0f else b.denoise
    override val deband: Float get() = if (level >= 2) 0f else b.deband
    override val aaMode: Int get() = if (level >= 2) Cfg.AA_OFF else b.aaMode
    override val clarity: Float get() = if (level >= 5) 0f else b.clarity
    override val antiRing: Float get() = if (level >= 5) 0f else b.antiRing
    override val outRes: Int get() = if (level >= 5 && b.outRes > 1080) 1080 else b.outRes
}
