package app.clearoverlay

/**
 * The picture settings the GL pipeline reads. The live app uses [LiveFx] (the current [Cfg] values, so sliders apply at
 * once); a video export uses its own fixed [FxSet], so what is chosen in a settings panel meanwhile cannot change an
 * export that is running.
 */
interface FxView {
    val mode: Int
    val boost: Boolean
    val vivid: Float
    val contrast: Float
    val shadows: Float get() = 0f
    val highlights: Float get() = 0f
    val saturation: Float get() = 0f
    val warmth: Float get() = 0f
    val grain: Float get() = 0f
    val clarity: Float get() = 0f
    val antiRing: Float get() = 0f
    val deint: Int get() = 0
    val detail: Float
    val detailSize: Float
    val denoise: Float
    val deband: Float
    val aaMode: Int
    val aaStrength: Float
    val sharp: Float
    val inRes: Int
    val outRes: Int
    /** Middle step of the resolution chain (short side, 0 = off): the cleaned picture is brought down to this size first. */
    val midRes: Int get() = 0
    /** Smart fix (measured white balance / levels / shadow lift). */
    val smartFix: Boolean get() = false
}

object LiveFx : FxView {
    override val mode: Int get() = Cfg.mode
    override val boost: Boolean get() = Cfg.boost
    override val vivid: Float get() = Cfg.vivid
    override val contrast: Float get() = Cfg.contrast
    override val shadows: Float get() = Cfg.shadows
    override val highlights: Float get() = Cfg.highlights
    override val saturation: Float get() = Cfg.saturation
    override val warmth: Float get() = Cfg.warmth
    override val grain: Float get() = Cfg.grain
    override val clarity: Float get() = Cfg.clarity
    override val antiRing: Float get() = Cfg.antiRing
    override val deint: Int get() = Cfg.deint
    override val detail: Float get() = Cfg.detail
    override val detailSize: Float get() = Cfg.detailSize
    override val denoise: Float get() = Cfg.denoise
    override val deband: Float get() = Cfg.deband
    override val aaMode: Int get() = Cfg.aaMode
    override val aaStrength: Float get() = Cfg.aaStrength
    override val sharp: Float get() = Cfg.sharp
    override val inRes: Int get() = Cfg.inRes
    override val outRes: Int get() = Cfg.outRes
    override val midRes: Int get() = Cfg.midRes
    override val smartFix: Boolean get() = Cfg.smartFix
}

class FxSet(
    override val mode: Int,
    override val sharp: Float,
    override val detail: Float,
    override val detailSize: Float,
    override val denoise: Float,
    override val deband: Float,
    override val aaMode: Int,
    override val aaStrength: Float,
    override val boost: Boolean = false,
    override val vivid: Float = 0f,
    override val contrast: Float = 0f,
    override val inRes: Int = 0,
    override val outRes: Int = 0,
    override val smartFix: Boolean = false,
    override val shadows: Float = 0f,
    override val highlights: Float = 0f,
    override val saturation: Float = 0f,
    override val warmth: Float = 0f,
    override val grain: Float = 0f,
    override val clarity: Float = 0f,
    override val antiRing: Float = 0f,
    override val deint: Int = 0
) : FxView

/**
 * The newer picture settings (shadows, highlights, saturation, warmth, film grain, clarity, anti-ringing, deinterlace, contrast and, for video, cutting the black bars) that a file export
 * ("Upscale a video to a new file", GIF) carries. Kept as one short text so it fits an intent extra, the saved unfinished job and the job id.
 */
class Look(
    var shadows: Float = 0f,
    var highlights: Float = 0f,
    var saturation: Float = 0f,
    var warmth: Float = 0f,
    var grain: Float = 0f,
    var clarity: Float = 0f,
    var antiRing: Float = 0f,
    var deint: Int = 0,
    var contrast: Float = 0f,
    /** Video export only: cut the black bars (measured once with [BarScan]). */
    var cutBars: Boolean = false
) {
    val neutral: Boolean
        get() = shadows == 0f && highlights == 0f && saturation == 0f && warmth == 0f && grain == 0f && clarity == 0f && antiRing == 0f && deint == 0 && contrast == 0f && !cutBars

    /** "" when everything is off (old jobs and their ids stay as they were), else ten numbers (percent, the deinterlace choice, contrast in percent, bars 0 / 1). */
    fun encode(): String {
        if (neutral) return ""
        fun pc(v: Float) = Math.round(v * 100f)
        return listOf(pc(shadows), pc(highlights), pc(saturation), pc(warmth), pc(grain), pc(clarity), pc(antiRing), deint.coerceIn(0, 2), pc(contrast), if (cutBars) 1 else 0).joinToString(",")
    }

    companion object {
        fun decode(s: String?): Look {
            if (s.isNullOrBlank()) return Look()
            val p = s.split(',').map { it.trim().toIntOrNull() ?: 0 }
            fun g(i: Int) = p.getOrElse(i) { 0 }
            return Look(
                (g(0) / 100f).coerceIn(-1f, 1f), (g(1) / 100f).coerceIn(-1f, 1f), (g(2) / 100f).coerceIn(-1f, 1f), (g(3) / 100f).coerceIn(-1f, 1f),
                (g(4) / 100f).coerceIn(0f, 1f), (g(5) / 100f).coerceIn(-1f, 1f), (g(6) / 100f).coerceIn(0f, 1f), g(7).coerceIn(0, 2),
                (g(8) / 100f).coerceIn(-1f, 1f), g(9) == 1
            )
        }

        /** What the player / GIF viewer shows now (after [Cfg.bind] of the kind of file). */
        fun fromCfg() = Look(Cfg.shadows, Cfg.highlights, Cfg.saturation, Cfg.warmth, Cfg.grain, Cfg.clarity, Cfg.antiRing, Cfg.deint, Cfg.contrast, Cfg.autoCrop)
    }
}
