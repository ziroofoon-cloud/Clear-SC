package app.clearoverlay

import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import kotlin.math.min
import kotlin.math.roundToInt

/** Everything the export screen chose, in one place (and passed to the service as intent extras). */
class ExportOpts(
    val target: Int = 1080,
    val tier: Int = 1,
    val anime: Boolean = false,
    val hevc: Boolean = false,
    val mode: Int = Cfg.MODE_FSR,
    /** -1 = the quality tier decides, otherwise 0..1. */
    val sharp: Float = -1f,
    val vivid: Float = 0f,
    /** 0 = max speed, 1 = balanced, 2 = gentle (rests between frames). */
    val pace: Int = 0,
    /** Only this part of the video (microseconds); an end of 0 means "to the end". 0 / 0 = the whole video. */
    val rangeStartUs: Long = 0L,
    val rangeEndUs: Long = 0L,
    /** Streaming: only a few minutes ahead of the viewer are made, old pieces are deleted, nothing is saved as a file. */
    val stream: Boolean = false,
    /** The newer picture settings (see [Look.encode]); "" = all off. */
    val look: String = ""
) {
    fun withRange(s: Long, e: Long) = ExportOpts(target, tier, anime, hevc, mode, sharp, vivid, pace, s, e, stream, look)
    fun withStream(on: Boolean) = ExportOpts(target, tier, anime, hevc, mode, sharp, vivid, pace, rangeStartUs, rangeEndUs, on, look)
    fun withLook(l: String) = ExportOpts(target, tier, anime, hevc, mode, sharp, vivid, pace, rangeStartUs, rangeEndUs, stream, l)
    fun withTarget(t: Int) = ExportOpts(t, tier, anime, hevc, mode, sharp, vivid, pace, rangeStartUs, rangeEndUs, stream, look)
}

/** What a video file is (read from its first video track). */
class SrcInfo(val w: Int, val h: Int, val fps: Float, val durUs: Long, val mime: String, val rot: Int) {
    val dispW get() = if (rot % 180 == 90) h else w
    val dispH get() = if (rot % 180 == 90) w else h
    val shortSide get() = min(dispW, dispH)
    val codec: String
        get() = when {
            mime.contains("avc") -> "H.264"
            mime.contains("hevc") -> "H.265"
            mime.contains("av01") -> "AV1"
            mime.contains("vp9") -> "VP9"
            mime.contains("vp8") -> "VP8"
            else -> mime.substringAfter('/')
        }
}

/** Result of really starting a small encoder of one type on this phone. */
class EncState(val mime: String, val label: String, val present: Boolean, val hardware: Boolean, val works: Boolean)

object ExportInfo {
    /** Index into [COST] for a quality tier: 0..3, and "Off" (4) costs like the light one. */
    fun tIdx(t: Int) = if (t >= 4) 0 else t.coerceIn(0, 3)

    /** Relative work of the quality tiers and of the load setting (see the estimate). */
    val COST = floatArrayOf(1.0f, 1.5f, 2.2f, 2.7f)
    val PACE = floatArrayOf(1.0f, 1.6f, 2.5f)

    fun probe(ctx: Context, uri: Uri): SrcInfo? {
        if (uri.scheme == Net.SCHEME) return null
        val ex = MediaExtractor()
        return try {
            ex.setDataSource(ctx, uri, null)
            var f: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val tf = ex.getTrackFormat(i)
                if ((tf.getString(MediaFormat.KEY_MIME) ?: "").startsWith("video/")) {
                    f = tf
                    break
                }
            }
            if (f == null) return null
            val fps = (runCatching { f.getInteger(MediaFormat.KEY_FRAME_RATE).toFloat() }.getOrNull()
                ?: runCatching { f.getFloat(MediaFormat.KEY_FRAME_RATE) }.getOrNull() ?: 30f).let { if (it < 5f) 30f else it }
            SrcInfo(
                f.getInteger(MediaFormat.KEY_WIDTH), f.getInteger(MediaFormat.KEY_HEIGHT), fps,
                if (f.containsKey(MediaFormat.KEY_DURATION)) f.getLong(MediaFormat.KEY_DURATION) else 0L,
                f.getString(MediaFormat.KEY_MIME) ?: "",
                if (f.containsKey(MediaFormat.KEY_ROTATION)) f.getInteger(MediaFormat.KEY_ROTATION) else 0
            )
        } catch (t: Throwable) {
            null
        } finally {
            runCatching { ex.release() }
        }
    }

    /** Result size for a target short side (same shape, even numbers; never more than the phone's encoder can do, see [fitOut]). */
    fun outSize(i: SrcInfo, target: Int, hevc: Boolean = false): Pair<Int, Int> = fitOut(i.dispW.toFloat(), i.dispH.toFloat(), target, hevc)

    private val sizeOk = HashMap<String, Boolean>()

    /** True when an encoder of this phone takes a picture of this size (software encoders count). Unknown = true up to 4096 px. */
    fun encoderFits(mime: String, w: Int, h: Int): Boolean = synchronized(sizeOk) {
        sizeOk.getOrPut("$mime/$w/$h") {
            runCatching {
                MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { ci ->
                    ci.isEncoder && ci.supportedTypes.any { it.equals(mime, true) } &&
                        ci.getCapabilitiesForType(mime).videoCapabilities?.isSizeSupported(w, h) == true
                }
            }.getOrDefault(w <= 4096 && h <= 4096)
        }
    }

    /**
     * The result size for a picture of [dw] x [dh] (after the black bars are cut) and a short side of [target]: same shape, even numbers.
     * 4K (2160) and 6K (3240) are possible when an encoder of the phone takes them; otherwise the whole picture shrinks a little at a time
     * (the shape is kept, nothing is squeezed) until it fits. 8192 px is the upper limit.
     */
    fun fitOut(dw: Float, dh: Float, target: Int, hevc: Boolean): Pair<Int, Int> {
        val mime = if (hevc) "video/hevc" else "video/avc"
        var k = target.toFloat() / min(dw, dh)
        val big = maxOf(dw, dh) * k
        if (big > 8192f) k *= 8192f / big
        var ow = 0
        var oh = 0
        for (n in 0 until 40) {
            ow = (((dw * k).roundToInt() + 1) / 2 * 2).coerceIn(64, 8192)
            oh = (((dh * k).roundToInt() + 1) / 2 * 2).coerceIn(64, 8192)
            if (encoderFits(mime, ow, oh) || (ow <= 1920 && oh <= 1920)) break
            k *= 0.93f
        }
        return Pair(ow, oh)
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("crsc", Context.MODE_PRIVATE)

    /** Measured speed of this phone in effective megapixels per second (0 = nothing measured yet). */
    fun measuredMpx(ctx: Context): Float = prefs(ctx).getFloat("export_mpx", 0f)
    fun saveMpx(ctx: Context, v: Float) = prefs(ctx).edit().putFloat("export_mpx", v).apply()

    /** Guess of how much heavier an upscaler is than FSR (the picture work per frame); CRSC Edge grows with its level (bits 21-23 of the mode). */
    fun modeCost(mode: Int): Double = when (mode and 0xFF) {
        Cfg.MODE_RAW -> 0.6   // no upscaling filter at all
        Cfg.MODE_SHARP -> 0.7 // sharpen only
        Cfg.MODE_FAST -> 0.8
        Cfg.MODE_NIS, Cfg.MODE_NIS_SOFT -> 1.2
        Cfg.MODE_NIS_MID -> 1.4
        Cfg.MODE_NIS_FAST, Cfg.MODE_NIS_FINE -> 1.8
        Cfg.MODE_NIS_ORIG -> 2.6
        Cfg.MODE_LANCZOS -> 1.8 + 0.35 * ((mode shr 21) and 7).coerceAtMost(5)
        Cfg.MODE_CLEAR -> 1.4
        Cfg.MODE_ART -> 2.6
        Cfg.MODE_NEURAL -> if (Cfg.neuralModel == 1) 5.0 else 3.0
        Cfg.MODE_PIXEL -> 1.2
        else -> 1.0
    }

    /**
     * The finishing passes that a look adds at the output size, in the units of [modeCost] (FSR 1 = 1.0; the same numbers as the Load view of the settings):
     * with "Same as the player" the four finishing effects of the live picture (Faint detail alone reads about 29 textures per pixel), and the custom sliders.
     */
    fun finishCost(look: String, noSr: Boolean = false): Double {
        val lk = Look.decode(look)
        var c = 0.0
        if (lk.live) {
            if (lk.lFaint > 0.004f) c += 0.7
            if (lk.lLight > 0.004f) c += 0.6
            if (lk.lChroma > 0.004f) c += 0.45 + 0.25 * lk.lChroma
            if (lk.lProtect > 0.004f) c += 0.06
            if (lk.lSr > 0 && !noSr) c += if (lk.lSr == 2) 0.3 else 0.15 // the network works at the (small) source size, so it is a fraction of an output-size pass
        }
        if (lk.grain > 0f) c += 0.15
        if (lk.clarity != 0f) c += 0.6
        if (lk.antiRing > 0f) c += 0.25
        if (lk.shadows != 0f || lk.highlights != 0f || lk.saturation != 0f || lk.warmth != 0f || lk.contrast != 0f || lk.brightness != 0f || lk.vibrance != 0f || lk.tint != 0f || lk.vignette != 0f || lk.fade > 0f) c += 0.2
        return c
    }

    /** The picture work of a job per frame: the upscaler plus the finishing passes (one number for the estimate and for the speed that is learned from a run). */
    fun workCost(mode: Int, look: String): Double = modeCost(mode) + finishCost(look, VideoAi.level(mode) > 0) // with an AI model in the job the live network is skipped

    /** The frame rate cap that applies to a job (0 = all frames): "Smooth live" has its own setting (Auto counts as all frames here). */
    fun fpsCapFor(ctx: Context, o: ExportOpts): Int {
        val p = ctx.getSharedPreferences("crsc", Context.MODE_PRIVATE)
        return if (o.stream && Look.decode(o.look).live) p.getInt("live_fps", 0).let { if (it == 30 || it == 24) it else 0 } else p.getInt("export_fps_cap", 0)
    }

    /** Rough guess of the work time in seconds. [measured] tells whether the speed comes from a real run on this phone. */
    fun estimateSec(ctx: Context, i: SrcInfo, o: ExportOpts): Long {
        val (ow, oh) = outSize(i, o.target, o.hevc)
        val mpx = measuredMpx(ctx).let { if (it > 0f) it else 50f }
        val cap = fpsCapFor(ctx, o)
        val frames = spanUs(i, o) / 1e6 * (if (cap > 0) minOf(i.fps, cap.toFloat()) else i.fps)
        val fgN = VideoExport.fgFactor(o.mode)
        val fgCost = if (fgN > 1) (when (VideoExport.fgQuality(o.mode)) { 3 -> 1.0; 0 -> 1.25; 2 -> 3.2; else -> 1.7 }) + 0.25 * (fgN - 2) else 1.0 // frame generation: motion search + extra frames
        val work = frames * (ow.toDouble() * oh / 1e6) * COST[tIdx(o.tier)] * PACE[o.pace.coerceIn(0, 2)] * fgCost * workCost(o.mode, o.look) / mpx
        val tmpCost = 1.0 + 0.3 * VideoExport.temporalLevel(o.mode)
        val aiL = VideoAi.level(o.mode)
        val ai = if (aiL > 0) frames * (if (VideoAi.half(o.mode)) 0.5 else 1.0) * VideoAi.secPerFrame(ctx, i.dispW, i.dispH, aiL) else 0.0 // the AI model (CPU) is the slow part
        return (work * tmpCost + ai).toLong()
    }

    /** Guess of the speed of a streaming job: seconds of video made per second of work (1.0 = exactly as fast as the video plays). */
    fun streamSpeed(ctx: Context, i: SrcInfo, o: ExportOpts): Float {
        val span = spanUs(i, o) / 1e6
        if (span <= 0.0) return 99f
        val (ow, oh) = outSize(i, o.target, o.hevc)
        val mpx = measuredMpx(ctx).let { if (it > 0f) it else 50f }
        // the same factors as the time estimate (upscaler weight, frame rate cap), because the speed learned from a run is divided by them
        val capFps = fpsCapFor(ctx, o)
        val fpsUsed = if (capFps > 0) minOf(i.fps, capFps.toFloat()) else i.fps
        val perSec = fpsUsed * VideoExport.fgFactor(o.mode) * (ow.toDouble() * oh / 1e6) * COST[tIdx(o.tier)] * PACE[o.pace.coerceIn(0, 2)] * workCost(o.mode, o.look) * (1.0 + 0.3 * VideoExport.temporalLevel(o.mode)) / mpx
        return if (perSec <= 0.0) 99f else (1.0 / perSec).toFloat()
    }

    fun sizeBytes(i: SrcInfo, o: ExportOpts): Long {
        val (ow, oh) = outSize(i, o.target, o.hevc)
        var br = VideoExport.bitrate(ow, oh, i.fps * VideoExport.fgFactor(o.mode), o.tier, o.mode).toLong()
        if (o.hevc) br = (br * 0.7).toLong()
        return br * (spanUs(i, o) / 1_000_000L) / 8
    }

    /** Length of what is going to be upscaled: the chosen part, or the whole video. */
    fun spanUs(i: SrcInfo, o: ExportOpts): Long {
        val s = o.rangeStartUs.coerceIn(0L, i.durUs)
        val e = if (o.rangeEndUs > 0L) o.rangeEndUs.coerceIn(0L, i.durUs) else i.durUs
        return (e - s).coerceAtLeast(0L)
    }

    /** The job that was started and not finished (paused, failed, app killed): the export screen offers to continue it. */
    fun saveUnfinished(ctx: Context, j: ExportJob) {
        val o = org.json.JSONObject().put("id", j.id).put("uri", j.uri).put("name", j.name).put("t", j.targetShort).put("tier", j.tier)
            .put("anime", j.anime).put("hevc", j.hevc).put("mode", j.mode).put("sharp", j.sharpOv.toDouble()).put("vivid", j.vividOv.toDouble()).put("pace", j.pace).put("rs", j.rangeStartUs).put("re", j.rangeEndUs).put("look", j.look)
        prefs(ctx).edit().putString("export_unfinished", o.toString()).apply()
    }

    fun clearUnfinished(ctx: Context) = prefs(ctx).edit().remove("export_unfinished").apply()

    fun unfinished(ctx: Context): ExportJob? = runCatching {
        val o = org.json.JSONObject(prefs(ctx).getString("export_unfinished", null) ?: return@runCatching null)
        ExportJob(
            o.getString("id"), o.getString("uri"), o.optString("name", "video"), o.getInt("t"), o.getInt("tier"), o.getBoolean("anime"),
            o.getBoolean("hevc"), o.getInt("mode"), o.getDouble("sharp").toFloat(), o.getDouble("vivid").toFloat(), o.optInt("pace", 0),
            o.optLong("rs", 0L), o.optLong("re", 0L), look = o.optString("look", "")
        )
    }.getOrNull()

    @Volatile var encoders: List<EncState>? = null

    /** Starts a tiny hardware / software encoder of each kind and reports what really works. Worker thread. */
    fun testEncoders(): List<EncState> {
        encoders?.let { return it }
        val list = ArrayList<EncState>()
        val infos = runCatching { MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.filter { it.isEncoder } }.getOrDefault(emptyList())
        for ((mime, label) in listOf("video/avc" to "H.264", "video/hevc" to "H.265", "video/av01" to "AV1", "video/x-vnd.on2.vp9" to "VP9")) {
            val have = infos.filter { ci -> ci.supportedTypes.any { it.equals(mime, true) } }
            val hw = have.any { it.isHardwareAccelerated }
            var works = false
            if (have.isNotEmpty()) works = runCatching { tryEncoder(mime) }.getOrDefault(false)
            list.add(EncState(mime, label, have.isNotEmpty(), hw, works))
        }
        encoders = list
        return list
    }

    private fun tryEncoder(mime: String): Boolean {
        var c: MediaCodec? = null
        return try {
            c = MediaCodec.createEncoderByType(mime)
            val f = MediaFormat.createVideoFormat(mime, 640, 360).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, 1_000_000)
                setInteger(MediaFormat.KEY_FRAME_RATE, 30)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }
            c.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val s = c.createInputSurface()
            c.start()
            s.release()
            true
        } catch (t: Throwable) {
            false
        } finally {
            runCatching { c?.stop() }
            runCatching { c?.release() }
        }
    }

    /** The "Auto" choices for a video: the best settings this phone can do in a sensible time. */
    fun autoPlan(ctx: Context, i: SrcInfo?, target: Int, anime: Boolean, pace: Int): ExportOpts {
        val hevcOk = encoders?.firstOrNull { it.mime == "video/hevc" }?.works == true
        // the upscaler follows the kind of picture: anime / cartoons -> CRSC Edge (clean lines), everything else -> NIS mid (sharp, light)
        // when the whole job stays within about 4 hours; otherwise plain FSR 1 (the cheapest); the quality tier is the strongest that fits 6 hours
        var mode = if (anime) Cfg.MODE_LANCZOS or (2 shl 21) else Cfg.MODE_NIS_MID
        var tier = 2
        if (i != null) {
            if (estimateSec(ctx, i, ExportOpts(target, 1, anime, false, mode, -1f, 0f, pace)) > 4 * 3600) mode = Cfg.MODE_FSR
            while (tier > 0 && estimateSec(ctx, i, ExportOpts(target, tier, anime, false, mode, -1f, 0f, pace)) > 6 * 3600) tier--
        }
        return ExportOpts(target, tier, anime, hevcOk, mode, -1f, 0f, pace)
    }
}
