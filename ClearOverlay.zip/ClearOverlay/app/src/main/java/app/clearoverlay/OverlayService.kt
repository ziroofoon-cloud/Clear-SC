package app.clearoverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.Region
import android.graphics.SurfaceTexture
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.Surface
import android.view.SurfaceControl
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.Toast

/**
 * Captures the screen (MediaProjection), processes every frame on the GPU and shows the
 * result in a full-screen overlay that is (a) excluded from the capture itself and
 * (b) transparent to touches, so the app underneath stays usable.
 */
class OverlayService : Service() {

    companion object {
        const val ACT_START = "app.clearoverlay.START"
        const val ACT_STOP = "app.clearoverlay.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val TAG = "ClearOverlay"

        @Volatile var instance: OverlayService? = null
        @Volatile var running = false
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var proj: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var root: FrameLayout? = null
    private var outSurface: Surface? = null
    private var gl: GlPipeline? = null
    private var screenW = 0
    private var screenH = 0
    private var dpi = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == ACT_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (running) return START_NOT_STICKY

        startForegroundCompat()

        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_DATA)
        }
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        Cfg.load(this)
        wm = getSystemService(WindowManager::class.java)
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val p = mpm.getMediaProjection(code, data)
        proj = p
        // Android 14+: a callback must be registered before creating the VirtualDisplay.
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                main.post { stopSelf() }
            }
        }, main)

        instance = this
        running = true
        showOverlay()
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("c", "Clear Overlay", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACT_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val icon = Icon.createWithResource(this, R.drawable.ic_stat)
        val n = Notification.Builder(this, "c")
            .setSmallIcon(icon)
            .setContentTitle("Clear Overlay is running")
            .setOngoing(true)
            .addAction(Notification.Action.Builder(icon, "Stop", stop).build())
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    // ---- overlay window ---------------------------------------------------------------

    private fun showOverlay() {
        val b = wm.maximumWindowMetrics.bounds
        screenW = b.width()
        screenH = b.height()
        dpi = resources.displayMetrics.densityDpi

        // No FLAG_NOT_TOUCHABLE on purpose: with an app overlay it makes Android 12+ clamp
        // the window to 80% alpha. Touch pass-through is done with an empty touchable region.
        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED

        var excluded = false
        val lp = WindowManager.LayoutParams(
            screenW, screenH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            // PRIVATE_FLAG_EXCLUDE_FROM_SCREEN_CAPTURE (0x00080000): keeps this window out of
            // the capture, otherwise we would capture our own output (infinite mirror).
            excluded = runCatching {
                val f = javaClass.getDeclaredField("privateFlags")
                f.isAccessible = true
                f.setInt(this, f.getInt(this) or 0x00080000)
            }.isSuccess
        }
        if (!excluded) {
            Toast.makeText(this, "Could not exclude overlay from capture on this ROM", Toast.LENGTH_LONG).show()
        }

        val tv = TextureView(this)
        // Must be false, otherwise the compositor may treat the layer as opaque black in captures.
        tv.isOpaque = false
        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, width: Int, height: Int) {
                root?.let { skipScreenshot(it) }
                startPipeline(st)
            }

            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, width: Int, height: Int) {}

            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                stopPipeline()
                return true
            }

            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }

        val layout = FrameLayout(this)
        layout.addView(
            tv,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        root = layout
        wm.addView(layout, lp)
        layout.post {
            skipScreenshot(layout)
            passTouchesThrough(layout)
        }
    }

    private fun startPipeline(st: SurfaceTexture) {
        if (gl != null) return
        val s = Surface(st)
        outSurface = s
        val g = GlPipeline(s)
        gl = g
        val (cw, ch) = captureSize()
        g.start(cw, ch) { input ->
            main.post { createVirtualDisplay(input, cw, ch) }
        }
    }

    private fun stopPipeline() {
        runCatching { vd?.release() }
        vd = null
        gl?.release()
        gl = null
        runCatching { outSurface?.release() }
        outSurface = null
    }

    private fun captureSize(): Pair<Int, Int> {
        val sc = Cfg.scalePct.coerceIn(50, 100) / 100f
        val w = ((screenW * sc).toInt() / 2 * 2).coerceAtLeast(2)
        val h = ((screenH * sc).toInt() / 2 * 2).coerceAtLeast(2)
        return Pair(w, h)
    }

    private fun createVirtualDisplay(input: Surface, w: Int, h: Int) {
        val p = proj ?: return
        if (vd != null) return
        vd = p.createVirtualDisplay(
            "clear", w, h, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            input, null, null
        )
    }

    /** Called by the UI when the render-scale slider changes. */
    fun applyScale() {
        if (!running) return
        val (cw, ch) = captureSize()
        gl?.setCaptureSize(cw, ch)
        runCatching { vd?.resize(cw, ch, dpi) }
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        if (!running) return
        val b = wm.maximumWindowMetrics.bounds
        if (b.width() == screenW && b.height() == screenH) return
        screenW = b.width()
        screenH = b.height()
        root?.let {
            val lp = it.layoutParams as WindowManager.LayoutParams
            lp.width = screenW
            lp.height = screenH
            wm.updateViewLayout(it, lp)
        }
        applyScale()
    }

    // ---- hidden-API helpers (all best effort) ------------------------------------------

    private fun skipScreenshot(view: View) {
        runCatching {
            val vri = view.javaClass.getMethod("getViewRootImpl").invoke(view) ?: return@runCatching
            val sc = vri.javaClass.getMethod("getSurfaceControl").invoke(vri) as SurfaceControl
            val tx = SurfaceControl.Transaction()
            SurfaceControl.Transaction::class.java
                .getMethod("setSkipScreenshot", SurfaceControl::class.java, Boolean::class.javaPrimitiveType)
                .invoke(tx, sc, true)
            tx.apply()
        }.onFailure { Log.d(TAG, "skipScreenshot unavailable: ${it.message}") }
    }

    private fun passTouchesThrough(view: View) {
        runCatching {
            val asc: Any? = if (Build.VERSION.SDK_INT >= 33) {
                view.rootSurfaceControl
            } else {
                view.javaClass.getMethod("getRootSurfaceControl").invoke(view)
            }
            if (asc != null) {
                val method = runCatching {
                    Class.forName("android.view.AttachedSurfaceControl")
                        .getMethod("setTouchableRegion", Region::class.java)
                }.getOrElse { asc.javaClass.getMethod("setTouchableRegion", Region::class.java) }
                method.invoke(asc, Region())
            }
        }.onFailure { Log.w(TAG, "touch pass-through unavailable: ${it.message}") }
    }

    override fun onDestroy() {
        running = false
        instance = null
        root?.let { runCatching { wm.removeView(it) } }
        root = null
        stopPipeline()
        runCatching { proj?.stop() }
        proj = null
        super.onDestroy()
    }
}
