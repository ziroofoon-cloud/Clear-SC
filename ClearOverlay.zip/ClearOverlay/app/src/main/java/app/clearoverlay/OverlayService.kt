package app.clearoverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.SurfaceTexture
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.Toast

/**
 * Captures the screen (MediaProjection), processes every frame on the GPU and shows the result in a
 * full-screen overlay that is excluded from the capture and transparent to touches.
 * The floating [Bubble] toggles the effect without stopping the capture session.
 */
class OverlayService : Service() {

    companion object {
        const val ACT_START = "app.clearoverlay.START"
        const val ACT_STOP = "app.clearoverlay.STOP"
        const val ACT_TOGGLE = "app.clearoverlay.TOGGLE"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"

        @Volatile var instance: OverlayService? = null
        @Volatile var running = false
    }

    val main = Handler(Looper.getMainLooper())

    /** True while the effect is shown (processing on). */
    @Volatile var active = false
        private set

    private lateinit var wm: WindowManager
    private var proj: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var root: FrameLayout? = null
    private var dimView: View? = null
    private var outSurface: Surface? = null
    private var gl: GlPipeline? = null
    private var bubble: Bubble? = null
    private var screenW = 0
    private var screenH = 0
    private var dpi = 0

    override fun attachBaseContext(newBase: android.content.Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        when (intent.action) {
            ACT_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACT_TOGGLE -> {
                if (running) main.post { toggle() }
                return START_NOT_STICKY
            }
        }
        if (running) return START_NOT_STICKY

        startForegroundCompat()

        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_DATA)
        }
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        Cfg.bind(this, "screen")
        Ui.init(this)
        wm = getSystemService(WindowManager::class.java)
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val p = mpm.getMediaProjection(code, data)
        proj = p
        // Android 14+: a callback must be registered before creating the VirtualDisplay.
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                main.post { stopSelf() }
            }
        }, main)

        instance = this
        running = true
        active = true
        main.removeCallbacks(autoTick)
        main.postDelayed(autoTick, 2000)
        refreshNotification() // startForegroundCompat() ran before `active` was set to true
        showOverlay()
        if (Cfg.bubble) {
            bubble = Bubble(this, wm).also { it.show() }
        }
        return START_NOT_STICKY
    }

    private fun modeLabel(): String = when (Cfg.mode) {
        Cfg.MODE_FSR -> getString(R.string.mode_fsr)
        Cfg.MODE_SGSR -> getString(R.string.mode_sgsr)
        Cfg.MODE_FAST -> getString(R.string.mode_fast)
        Cfg.MODE_RAW -> getString(R.string.mode_raw)
        Cfg.MODE_LANCZOS -> getString(R.string.mode_lanczos)
        Cfg.MODE_CLEAR -> getString(R.string.mode_clear)
        Cfg.MODE_ART -> getString(R.string.mode_art)
        Cfg.MODE_PIXEL -> getString(R.string.mode_pixel)
        Cfg.MODE_NIS -> getString(R.string.mode_nis)
        Cfg.MODE_NIS_SOFT -> getString(R.string.mode_nis_soft)
        Cfg.MODE_NIS_ORIG -> getString(R.string.mode_nis_orig)
        Cfg.MODE_NIS_FAST -> getString(R.string.mode_nis_fast)
        Cfg.MODE_NIS_MID -> getString(R.string.mode_nis_mid)
        else -> getString(R.string.mode_sharpen)
    }

    private fun buildNotification(): Notification {
        fun action(code: Int, act: String) = PendingIntent.getService(
            this, code,
            Intent(this, OverlayService::class.java).setAction(act),
            PendingIntent.FLAG_IMMUTABLE
        )
        val icon = Icon.createWithResource(this, R.drawable.ic_stat)
        val statusTxt = getString(if (active) R.string.status_running_on else R.string.status_running_off)
        return Notification.Builder(this, "c")
            .setSmallIcon(icon)
            .setContentTitle(getString(R.string.notif_running))
            .setContentText(getString(R.string.notif_status_fmt, statusTxt, modeLabel()))
            .setOngoing(true)
            .addAction(Notification.Action.Builder(icon, getString(R.string.notif_action_toggle), action(1, ACT_TOGGLE)).build())
            .addAction(Notification.Action.Builder(icon, getString(R.string.action_stop), action(0, ACT_STOP)).build())
            .build()
    }

    /** Refreshes the notification text (status / mode) after something changes. */
    private fun refreshNotification() {
        if (!running) return
        getSystemService(NotificationManager::class.java).notify(1, buildNotification())
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("c", "+CRSC", NotificationManager.IMPORTANCE_LOW)
        )
        startForeground(1, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    // ---- on / off -------------------------------------------------------------------------

    fun toggle() = turn(!active)

    fun shutdown() = stopSelf()

    /** Turns the effect on/off. The capture session stays alive, so turning it back on is instant. */
    fun turn(on: Boolean) {
        if (!running || on == active) return
        active = on
        if (on) {
            showOverlay()
        } else {
            runCatching { vd?.surface = null } // stop feeding frames
            root?.let { runCatching { wm.removeView(it) } }
            root = null
            stopPipeline()
        }
        bubble?.onActiveChanged()
        refreshNotification()
    }

    @Volatile private var pausedByPlayer = false

    /**
     * The built-in player processes the decoded frames itself. If the screen effect were also on, the player's
     * already-processed picture would be captured and processed a second time, so it is paused while the player
     * is in front and restored afterwards.
     */
    fun pauseForPlayer(pause: Boolean) {
        if (!running) return
        if (pause) {
            if (active) {
                pausedByPlayer = true
                turn(false)
            }
        } else if (pausedByPlayer) {
            pausedByPlayer = false
            turn(true)
        }
    }

    private var aiSnap: AiSnap? = null

    // ---- Auto (screen overlay): walks a ladder of settings from the measured time per frame ----------------
    private var autoStep = 2
    private var goodChecks = 0

    /** Auto was (re)started from the panel: begin at Balanced. */
    fun autoReset() {
        autoStep = 2
        goodChecks = 0
        gl?.avgDrawMs = 0f
    }

    private val autoTick = object : Runnable {
        override fun run() {
            if (running && Cfg.autoMode && active) autoCheck()
            if (running) main.postDelayed(this, 2000)
        }
    }

    private fun autoCheck() {
        val g = gl ?: return
        val ms = g.avgDrawMs
        if (ms <= 0f) return
        val hz = getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)?.refreshRate ?: 60f
        val frameMs = 1000f / hz.coerceAtLeast(30f)
        var changed = false
        if (ms > frameMs * 0.8f && autoStep > 0) {
            autoStep--
            goodChecks = 0
            changed = true
        } else if (ms < frameMs * 0.3f && autoStep < Auto.LADDER_TOP) {
            if (++goodChecks >= 3) {
                autoStep++
                goodChecks = 0
                changed = true
            }
        } else {
            goodChecks = 0
        }
        if (!changed) return
        Auto.applyOverlayStep(autoStep)
        Cfg.save(this)
        applyConfig()
        g.avgDrawMs = 0f
        ControlsBus.sync?.invoke()
        Toast.makeText(this, getString(R.string.auto_step_fmt, Auto.stepName(this, autoStep)), Toast.LENGTH_SHORT).show()
    }

    /**
     * "AI still frame": grabs the current screen exactly as it is, pauses the live effect and opens a viewer where the
     * user can enhance the whole frame or a dragged-over area with an offline AI model (see [AiSnap]).
     */
    fun startAiSnap() {
        if (!running || aiSnap != null) return
        val g = gl
        if (!active || g == null) {
            Toast.makeText(this, getString(R.string.aisnap_need_on), Toast.LENGTH_LONG).show()
            return
        }
        Thread {
            val f = runCatching { g.rawFrame() }.getOrNull()
            main.post {
                if (!running || aiSnap != null) return@post
                if (f == null) {
                    Toast.makeText(this, getString(R.string.aisnap_grab_fail), Toast.LENGTH_LONG).show()
                    return@post
                }
                pauseForPlayer(true) // no need to process live frames while the still frame is open
                aiSnap = AiSnap(this, wm) {
                    aiSnap = null
                    pauseForPlayer(false)
                }.also { it.show(f) }
            }
        }.start()
    }

    /** Called from the settings panel while the layer-opacity slider moves: blends the processed layer with the real screen. */
    fun applyLayerAlpha() {
        root?.alpha = 1f
        dimView?.alpha = Cfg.dim.coerceIn(0f, 1f)
    }

    /** Called from the settings panel when the bubble-size slider changes. */
    fun applyBubbleSize() = bubble?.applySize()

    /** Called from the settings panel when auto-hide is turned off, so a sleeping bubble wakes up. */
    fun wakeBubble() = bubble?.wakeNow()

    /** Called from the settings panel when auto-hide is turned back on. */
    fun refreshBubbleIdleTimer() = bubble?.refreshIdleTimer()

    /** Called from the app screen when the "floating bubble" switch changes. */
    fun updateBubble() {
        if (!running) return
        if (Cfg.bubble) {
            if (bubble == null) bubble = Bubble(this, wm).also { it.show() }
        } else {
            bubble?.hide()
            bubble = null
        }
    }

    // ---- overlay window -------------------------------------------------------------------

    private fun showOverlay() {
        val b = wm.maximumWindowMetrics.bounds
        screenW = b.width()
        screenH = b.height()
        dpi = resources.displayMetrics.densityDpi

        // No FLAG_NOT_TOUCHABLE on purpose: with an app overlay it makes Android 12+ clamp the window
        // to 80% alpha. Touch pass-through is done in Win.passTouchesThrough instead.
        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED

        val lp = WindowManager.LayoutParams(
            screenW, screenH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        if (!Win.excludeFromCapture(lp)) {
            Toast.makeText(this, getString(R.string.toast_rom_capture_fail), Toast.LENGTH_LONG).show()
        }

        val tv = TextureView(this)
        tv.isOpaque = false
        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, width: Int, height: Int) {
                startPipeline(st)
            }

            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, width: Int, height: Int) {}

            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                stopPipeline()
                return true
            }

            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }

        val layout = FrameLayout(this)
        layout.addView(
            tv,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        // black dimmer above the picture, below the bubble / panel (those are separate windows added later)
        val dv = View(this).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
            alpha = Cfg.dim.coerceIn(0f, 1f)
        }
        layout.addView(dv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        dimView = dv
        root = layout
        layout.alpha = 1f
        Win.passTouchesThrough(layout) // installs once the view is attached
        wm.addView(layout, lp)
        layout.post { Win.skipScreenshot(layout) }
        // Some ROMs only accept the touchable region after the first layout pass.
        layout.postDelayed({ if (root === layout) Win.passTouchesThrough(layout) }, 400)
        bubble?.reattach()
    }

    private fun startPipeline(st: SurfaceTexture) {
        if (gl != null) return
        val s = Surface(st)
        outSurface = s
        val g = GlPipeline(s)
        g.fixedOut = true // the capture scale (render resolution) already decides the size here
        g.onError = { msg ->
            main.post {
                Toast.makeText(this, "+CRSC: $msg".take(240), Toast.LENGTH_LONG).show()
                stopSelf()
            }
        }
        gl = g
        val (cw, ch) = captureSize()
        g.start(cw, ch) { input -> main.post { attachVirtualDisplay(input, cw, ch) } }
    }

    private fun stopPipeline() {
        gl?.release()
        gl = null
        runCatching { outSurface?.release() }
        outSurface = null
    }

    private fun captureSize(): Pair<Int, Int> {
        val pct = Cfg.scalePct.coerceIn(Cfg.SCALE_MIN, Cfg.SCALE_MAX) / 100f
        // Sharpen mode never goes below full resolution; above 100% it supersamples.
        val sc = if (Cfg.mode == Cfg.MODE_SHARP) maxOf(1f, pct) else pct
        val w = ((screenW * sc).toInt() / 2 * 2).coerceAtLeast(2)
        val h = ((screenH * sc).toInt() / 2 * 2).coerceAtLeast(2)
        return Pair(w, h)
    }

    private fun attachVirtualDisplay(input: Surface, w: Int, h: Int) {
        val p = proj ?: return
        if (gl == null || !active) return
        val d = vd
        if (d == null) {
            // Android 14+ allows only ONE VirtualDisplay per projection, so it is created once and
            // later only re-pointed to the new surface (setSurface) when the effect is turned back on.
            vd = p.createVirtualDisplay(
                "crsc", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                input, null, null
            )
        } else {
            runCatching {
                d.resize(w, h, dpi)
                d.surface = input
            }
        }
    }

    /** Re-applies mode / render scale (called from the UI). */
    fun applyConfig() {
        if (!running) return
        val (cw, ch) = captureSize()
        gl?.setCaptureSize(cw, ch)
        runCatching { vd?.resize(cw, ch, dpi) }
        refreshNotification()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (!running) return
        val b = wm.maximumWindowMetrics.bounds
        bubble?.onConfigChanged()
        if (b.width() == screenW && b.height() == screenH) return
        screenW = b.width()
        screenH = b.height()
        root?.let {
            val lp = it.layoutParams as WindowManager.LayoutParams
            lp.width = screenW
            lp.height = screenH
            wm.updateViewLayout(it, lp)
        }
        applyConfig()
    }

    override fun onDestroy() {
        running = false
        active = false
        instance = null
        main.removeCallbacks(autoTick)
        aiSnap?.dispose()
        aiSnap = null
        bubble?.hide()
        bubble = null
        root?.let { runCatching { wm.removeView(it) } }
        root = null
        dimView = null
        runCatching { vd?.release() }
        vd = null
        stopPipeline()
        runCatching { proj?.stop() }
        proj = null
        super.onDestroy()
    }
}
