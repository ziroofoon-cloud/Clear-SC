package app.clearoverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.SurfaceTexture
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.Toast

/**
 * Captures the screen (MediaProjection), processes every frame on the GPU and shows the result in a
 * full-screen overlay that is excluded from the capture and transparent to touches.
 * The floating [Bubble] toggles the effect without stopping the capture session.
 */
class OverlayService : Service() {

    companion object {
        const val ACT_START = "app.clearoverlay.START"
        const val ACT_STOP = "app.clearoverlay.STOP"
        const val ACT_TOGGLE = "app.clearoverlay.TOGGLE"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"

        @Volatile var instance: OverlayService? = null
        @Volatile var running = false
    }

    val main = Handler(Looper.getMainLooper())

    /** True while the effect is shown (processing on). */
    @Volatile var active = false
        private set

    private lateinit var wm: WindowManager
    private var proj: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var root: FrameLayout? = null
    private var outSurface: Surface? = null
    private var gl: GlPipeline? = null
    private var bubble: Bubble? = null
    private var screenW = 0
    private var screenH = 0
    private var dpi = 0

    override fun attachBaseContext(newBase: android.content.Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        when (intent.action) {
            ACT_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACT_TOGGLE -> {
                if (running) main.post { toggle() }
                return START_NOT_STICKY
            }
        }
        if (running) return START_NOT_STICKY

        startForegroundCompat()

        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_DATA)
        }
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        Cfg.load(this)
        wm = getSystemService(WindowManager::class.java)
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val p = mpm.getMediaProjection(code, data)
        proj = p
        // Android 14+: a callback must be registered before creating the VirtualDisplay.
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                main.post { stopSelf() }
            }
        }, main)

        instance = this
        running = true
        active = true
        showOverlay()
        if (Cfg.bubble) {
            bubble = Bubble(this, wm).also { it.show() }
        }
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("c", "+CRSC", NotificationManager.IMPORTANCE_LOW)
        )
        fun action(code: Int, act: String) = PendingIntent.getService(
            this, code,
            Intent(this, OverlayService::class.java).setAction(act),
            PendingIntent.FLAG_IMMUTABLE
        )
        val icon = Icon.createWithResource(this, R.drawable.ic_stat)
        val n = Notification.Builder(this, "c")
            .setSmallIcon(icon)
            .setContentTitle(getString(R.string.notif_running))
            .setOngoing(true)
            .addAction(Notification.Action.Builder(icon, getString(R.string.notif_action_toggle), action(1, ACT_TOGGLE)).build())
            .addAction(Notification.Action.Builder(icon, getString(R.string.action_stop), action(0, ACT_STOP)).build())
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    // ---- on / off -------------------------------------------------------------------------

    fun toggle() = turn(!active)

    fun shutdown() = stopSelf()

    /** Turns the effect on/off. The capture session stays alive, so turning it back on is instant. */
    fun turn(on: Boolean) {
        if (!running || on == active) return
        active = on
        if (on) {
            showOverlay()
        } else {
            runCatching { vd?.surface = null } // stop feeding frames
            root?.let { runCatching { wm.removeView(it) } }
            root = null
            stopPipeline()
        }
        bubble?.onActiveChanged()
    }

    /** Called from the settings panel when the bubble-size slider changes. */
    fun applyBubbleSize() = bubble?.applySize()

    /** Called from the settings panel when auto-hide is turned off, so a sleeping bubble wakes up. */
    fun wakeBubble() = bubble?.wakeNow()

    /** Called from the app screen when the "floating bubble" switch changes. */
    fun updateBubble() {
        if (!running) return
        if (Cfg.bubble) {
            if (bubble == null) bubble = Bubble(this, wm).also { it.show() }
        } else {
            bubble?.hide()
            bubble = null
        }
    }

    // ---- overlay window -------------------------------------------------------------------

    private fun showOverlay() {
        val b = wm.maximumWindowMetrics.bounds
        screenW = b.width()
        screenH = b.height()
        dpi = resources.displayMetrics.densityDpi

        // No FLAG_NOT_TOUCHABLE on purpose: with an app overlay it makes Android 12+ clamp the window
        // to 80% alpha. Touch pass-through is done in Win.passTouchesThrough instead.
        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED

        val lp = WindowManager.LayoutParams(
            screenW, screenH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        if (!Win.excludeFromCapture(lp)) {
            Toast.makeText(this, getString(R.string.toast_rom_capture_fail), Toast.LENGTH_LONG).show()
        }

        val tv = TextureView(this)
        tv.isOpaque = false
        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, width: Int, height: Int) {
                startPipeline(st)
            }

            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, width: Int, height: Int) {}

            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                stopPipeline()
                return true
            }

            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }

        val layout = FrameLayout(this)
        layout.addView(
            tv,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        root = layout
        Win.passTouchesThrough(layout) // installs once the view is attached
        wm.addView(layout, lp)
        layout.post { Win.skipScreenshot(layout) }
        // Some ROMs only accept the touchable region after the first layout pass.
        layout.postDelayed({ if (root === layout) Win.passTouchesThrough(layout) }, 400)
        bubble?.reattach()
    }

    private fun startPipeline(st: SurfaceTexture) {
        if (gl != null) return
        val s = Surface(st)
        outSurface = s
        val g = GlPipeline(s)
        g.onError = { msg ->
            main.post {
                Toast.makeText(this, "+CRSC: $msg".take(240), Toast.LENGTH_LONG).show()
                stopSelf()
            }
        }
        gl = g
        val (cw, ch) = captureSize()
        g.start(cw, ch) { input -> main.post { attachVirtualDisplay(input, cw, ch) } }
    }

    private fun stopPipeline() {
        gl?.release()
        gl = null
        runCatching { outSurface?.release() }
        outSurface = null
    }

    private fun captureSize(): Pair<Int, Int> {
        val sc = if (Cfg.mode == Cfg.MODE_SHARP) 1f else Cfg.scalePct.coerceIn(Cfg.SCALE_MIN, Cfg.SCALE_MAX) / 100f
        val w = ((screenW * sc).toInt() / 2 * 2).coerceAtLeast(2)
        val h = ((screenH * sc).toInt() / 2 * 2).coerceAtLeast(2)
        return Pair(w, h)
    }

    private fun attachVirtualDisplay(input: Surface, w: Int, h: Int) {
        val p = proj ?: return
        if (gl == null || !active) return
        val d = vd
        if (d == null) {
            // Android 14+ allows only ONE VirtualDisplay per projection, so it is created once and
            // later only re-pointed to the new surface (setSurface) when the effect is turned back on.
            vd = p.createVirtualDisplay(
                "crsc", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                input, null, null
            )
        } else {
            runCatching {
                d.resize(w, h, dpi)
                d.surface = input
            }
        }
    }

    /** Re-applies mode / render scale (called from the UI). */
    fun applyConfig() {
        if (!running) return
        val (cw, ch) = captureSize()
        gl?.setCaptureSize(cw, ch)
        runCatching { vd?.resize(cw, ch, dpi) }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (!running) return
        val b = wm.maximumWindowMetrics.bounds
        bubble?.onConfigChanged()
        if (b.width() == screenW && b.height() == screenH) return
        screenW = b.width()
        screenH = b.height()
        root?.let {
            val lp = it.layoutParams as WindowManager.LayoutParams
            lp.width = screenW
            lp.height = screenH
            wm.updateViewLayout(it, lp)
        }
        applyConfig()
    }

    override fun onDestroy() {
        running = false
        active = false
        instance = null
        bubble?.hide()
        bubble = null
        root?.let { runCatching { wm.removeView(it) } }
        root = null
        runCatching { vd?.release() }
        vd = null
        stopPipeline()
        runCatching { proj?.stop() }
        proj = null
        super.onDestroy()
    }
}
