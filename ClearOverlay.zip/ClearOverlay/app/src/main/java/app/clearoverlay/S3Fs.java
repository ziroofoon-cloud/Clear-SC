package app.clearoverlay;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.TreeMap;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * S3-compatible object storage: Amazon S3, Backblaze B2, Wasabi, Cloudflare R2, MinIO and others (AWS Signature Version 4, path-style
 * addresses). Object storage has no real folders: a folder is a common key prefix (and an empty "name/" object when it is created
 * here), renaming is a server-side copy followed by a delete. With an empty [bucket] the top level lists the buckets.
 */
public final class S3Fs implements FmFs {
    private final String scheme;
    private final String hostPart;
    private final String region;
    private final String bucket;      // "" = list the buckets at the top
    private final String access;
    private final String secret;
    private final boolean insecure;
    private final File tmpDir;

    public S3Fs(String endpoint, String region, String bucket, String access, String secret, boolean insecure, File tmpDir) throws IOException {
        String u = endpoint.trim();
        if (!u.contains("://")) u = "https://" + u;
        URL x = new URL(u);
        this.scheme = x.getProtocol().toLowerCase(Locale.US);
        this.hostPart = x.getPort() > 0 ? x.getHost() + ":" + x.getPort() : x.getHost();
        this.region = region == null || region.trim().isEmpty() ? "us-east-1" : region.trim();
        this.bucket = bucket == null ? "" : bucket.trim();
        this.access = access;
        this.secret = secret;
        this.insecure = insecure;
        this.tmpDir = tmpDir;
    }

    // ---- paths ------------------------------------------------------------------------------------

    @Override public String root() { return "/"; }

    @Override public String parent(String path) {
        String p = norm(path);
        if (p.equals("/")) return null;
        int i = p.lastIndexOf('/');
        return i <= 0 ? "/" : p.substring(0, i);
    }

    @Override public String join(String dir, String name) { return dir.endsWith("/") ? dir + name : dir + "/" + name; }

    private static String norm(String p) {
        if (p == null || p.isEmpty()) return "/";
        String r = p.startsWith("/") ? p : "/" + p;
        while (r.length() > 1 && r.endsWith("/")) r = r.substring(0, r.length() - 1);
        return r;
    }

    /** bucket + key of one of our paths ("" key = the bucket itself, "" bucket = the top level). */
    private String[] loc(String path) {
        String p = norm(path);
        String rest = p.equals("/") ? "" : p.substring(1);
        if (!bucket.isEmpty()) return new String[]{bucket, rest};
        if (rest.isEmpty()) return new String[]{"", ""};
        int i = rest.indexOf('/');
        return i < 0 ? new String[]{rest, ""} : new String[]{rest.substring(0, i), rest.substring(i + 1)};
    }

    private String pathOf(String bkt, String key) {
        String k = key.endsWith("/") ? key.substring(0, key.length() - 1) : key;
        if (!bucket.isEmpty()) return "/" + k;
        return k.isEmpty() ? "/" + bkt : "/" + bkt + "/" + k;
    }

    // ---- signing (AWS Signature Version 4) ----------------------------------------------------------

    static String uriEncode(String s, boolean keepSlash) {
        StringBuilder sb = new StringBuilder();
        for (byte b : s.getBytes(StandardCharsets.UTF_8)) {
            int c = b & 0xFF;
            if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '-' || c == '.' || c == '_' || c == '~'
                    || (c == '/' && keepSlash)) {
                sb.append((char) c);
            } else {
                sb.append('%').append(Character.toUpperCase(Character.forDigit(c >> 4, 16))).append(Character.toUpperCase(Character.forDigit(c & 15, 16)));
            }
        }
        return sb.toString();
    }

    static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02x", x & 0xFF));
        return sb.toString();
    }

    static byte[] hmac(byte[] key, String data) {
        try {
            Mac m = Mac.getInstance("HmacSHA256");
            m.init(new SecretKeySpec(key, "HmacSHA256"));
            return m.doFinal(data.getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    static String sha256Hex(byte[] data) {
        try {
            return hex(MessageDigest.getInstance("SHA-256").digest(data));
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    static final String EMPTY_SHA = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";

    /**
     * The Authorization header value. [headers] are the headers to sign (lower-case names -> values, must include host,
     * x-amz-content-sha256 and x-amz-date); [canonicalPath] and [canonicalQuery] are already URI-encoded.
     */
    static String authHeader(String method, String canonicalPath, String canonicalQuery, Map<String, String> headers, String payloadHash,
                             String amzDate, String region, String access, String secret) {
        TreeMap<String, String> h = new TreeMap<>(headers);
        StringBuilder ch = new StringBuilder();
        StringBuilder sh = new StringBuilder();
        for (Map.Entry<String, String> e : h.entrySet()) {
            ch.append(e.getKey()).append(':').append(e.getValue().trim()).append('\n');
            if (sh.length() > 0) sh.append(';');
            sh.append(e.getKey());
        }
        String canonical = method + "\n" + canonicalPath + "\n" + canonicalQuery + "\n" + ch + "\n" + sh + "\n" + payloadHash;
        String date = amzDate.substring(0, 8);
        String scope = date + "/" + region + "/s3/aws4_request";
        String toSign = "AWS4-HMAC-SHA256\n" + amzDate + "\n" + scope + "\n" + sha256Hex(canonical.getBytes(StandardCharsets.UTF_8));
        byte[] k = hmac(("AWS4" + secret).getBytes(StandardCharsets.UTF_8), date);
        k = hmac(k, region);
        k = hmac(k, "s3");
        k = hmac(k, "aws4_request");
        String sig = hex(hmac(k, toSign));
        return "AWS4-HMAC-SHA256 Credential=" + access + "/" + scope + ", SignedHeaders=" + sh + ", Signature=" + sig;
    }

    private static String nowStamp() {
        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return f.format(new Date());
    }

    /**
     * One signed request. [query] is the canonical (sorted, encoded) query string without "?"; [extra] are more headers to send and sign
     * (lower-case names).
     */
    private HttpRaw.Resp call(String method, String bkt, String key, String query, Map<String, String> extra, InputStream body, long bodyLen,
                              String payloadHash) throws IOException {
        String path = bkt.isEmpty() ? "/" : "/" + uriEncode(bkt, false) + (key.isEmpty() ? "" : "/" + uriEncode(key, true));
        String stamp = nowStamp();
        TreeMap<String, String> sign = new TreeMap<>();
        sign.put("host", hostPart);
        sign.put("x-amz-content-sha256", payloadHash);
        sign.put("x-amz-date", stamp);
        if (extra != null) sign.putAll(extra);
        String auth = authHeader(method, path, query == null ? "" : query, sign, payloadHash, stamp, region, access, secret);
        java.util.HashMap<String, String> send = new java.util.HashMap<>();
        for (Map.Entry<String, String> e : sign.entrySet()) if (!e.getKey().equals("host")) send.put(e.getKey(), e.getValue());
        send.put("Authorization", auth);
        URL url = new URL(scheme + "://" + hostPart + path + (query == null || query.isEmpty() ? "" : "?" + query));
        return HttpRaw.request(method, url, send, body, bodyLen, insecure);
    }

    private HttpRaw.Resp call(String method, String bkt, String key, String query) throws IOException {
        return call(method, bkt, key, query, null, null, 0, EMPTY_SHA);
    }

    private IOException fail(String what, HttpRaw.Resp r) {
        String detail = "";
        try {
            String t = r.text();
            int a = t.indexOf("<Message>"), b = t.indexOf("</Message>");
            if (a >= 0 && b > a) detail = " (" + t.substring(a + 9, b) + ")";
        } catch (Exception ignored) { }
        return new IOException(what + ": " + r.code + " " + r.message + detail);
    }

    // ---- reading ------------------------------------------------------------------------------------

    private static Document parse(byte[] xml) throws IOException {
        try {
            DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
            f.setNamespaceAware(true);
            try { f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true); } catch (Exception ignored) { }
            return f.newDocumentBuilder().parse(new ByteArrayInputStream(xml));
        } catch (Exception e) {
            throw new IOException("the server's answer could not be read: " + e.getMessage(), e);
        }
    }

    private static String text(Element parent, String local) {
        NodeList n = parent.getElementsByTagNameNS("*", local);
        if (n.getLength() == 0) return null;
        StringBuilder sb = new StringBuilder();
        for (Node c = n.item(0).getFirstChild(); c != null; c = c.getNextSibling()) {
            if (c.getNodeType() == Node.TEXT_NODE || c.getNodeType() == Node.CDATA_SECTION_NODE) sb.append(c.getNodeValue());
        }
        return sb.toString();
    }

    private static long parseDate(String s) {
        if (s == null) return 0;
        try {
            String t = s.trim();
            int dot = t.indexOf('.');
            if (dot > 0) t = t.substring(0, dot);
            else if (t.endsWith("Z")) t = t.substring(0, t.length() - 1);
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US);
            f.setTimeZone(TimeZone.getTimeZone("UTC"));
            return f.parse(t).getTime();
        } catch (Exception e) {
            return 0;
        }
    }

    private static final class Listing {
        final List<String> keys = new ArrayList<>();
        final List<Long> sizes = new ArrayList<>();
        final List<Long> mods = new ArrayList<>();
        final List<String> prefixes = new ArrayList<>();
    }

    /** ListObjectsV2 of one bucket, all pages. [delimiter] true = one level (folders as prefixes). */
    private Listing listBucket(String bkt, String prefix, boolean delimiter, int max) throws IOException {
        Listing out = new Listing();
        String token = null;
        do {
            TreeMap<String, String> q = new TreeMap<>();
            q.put("list-type", "2");
            if (delimiter) q.put("delimiter", "/");
            if (!prefix.isEmpty()) q.put("prefix", prefix);
            if (token != null) q.put("continuation-token", token);
            StringBuilder qs = new StringBuilder();
            for (Map.Entry<String, String> e : q.entrySet()) {
                if (qs.length() > 0) qs.append('&');
                qs.append(uriEncode(e.getKey(), false)).append('=').append(uriEncode(e.getValue(), false));
            }
            try (HttpRaw.Resp r = call("GET", bkt, "", qs.toString())) {
                if (r.code != 200) throw fail("cannot list", r);
                Document d = parse(r.bytes());
                NodeList cs = d.getElementsByTagNameNS("*", "Contents");
                for (int i = 0; i < cs.getLength(); i++) {
                    Element c = (Element) cs.item(i);
                    String key = text(c, "Key");
                    if (key == null) continue;
                    out.keys.add(key);
                    String sz = text(c, "Size");
                    long n = -1;
                    try { if (sz != null) n = Long.parseLong(sz.trim()); } catch (NumberFormatException ignored) { }
                    out.sizes.add(n);
                    out.mods.add(parseDate(text(c, "LastModified")));
                }
                NodeList ps = d.getElementsByTagNameNS("*", "CommonPrefixes");
                for (int i = 0; i < ps.getLength(); i++) {
                    String p = text((Element) ps.item(i), "Prefix");
                    if (p != null) out.prefixes.add(p);
                }
                String trunc = text(d.getDocumentElement(), "IsTruncated");
                token = "true".equalsIgnoreCase(trunc == null ? "" : trunc.trim()) ? text(d.getDocumentElement(), "NextContinuationToken") : null;
            }
            if (max > 0 && out.keys.size() + out.prefixes.size() >= max) break;
        } while (token != null);
        return out;
    }

    @Override public List<FmItem> list(String dir) throws IOException {
        String[] l = loc(dir);
        List<FmItem> out = new ArrayList<>();
        if (l[0].isEmpty()) { // the buckets
            try (HttpRaw.Resp r = call("GET", "", "", "")) {
                if (r.code != 200) throw fail("cannot list the buckets", r);
                Document d = parse(r.bytes());
                NodeList bs = d.getElementsByTagNameNS("*", "Bucket");
                for (int i = 0; i < bs.getLength(); i++) {
                    Element b = (Element) bs.item(i);
                    String n = text(b, "Name");
                    if (n != null) out.add(new FmItem(n, true, -1, parseDate(text(b, "CreationDate"))));
                }
            }
            return out;
        }
        String prefix = l[1].isEmpty() ? "" : l[1] + "/";
        Listing li = listBucket(l[0], prefix, true, 0);
        for (int i = 0; i < li.keys.size(); i++) {
            String k = li.keys.get(i);
            if (k.equals(prefix)) continue; // the folder's own marker object
            String name = k.substring(prefix.length());
            if (name.isEmpty() || name.indexOf('/') >= 0) continue;
            out.add(new FmItem(name, false, li.sizes.get(i), li.mods.get(i)));
        }
        for (String p : li.prefixes) {
            String name = p.substring(prefix.length());
            if (name.endsWith("/")) name = name.substring(0, name.length() - 1);
            if (!name.isEmpty()) out.add(new FmItem(name, true, -1, 0));
        }
        return out;
    }

    @Override public InputStream open(String path) throws IOException {
        String[] l = loc(path);
        final HttpRaw.Resp r = call("GET", l[0], l[1], "");
        if (r.code != 200) {
            IOException e = fail("cannot read " + path, r);
            r.close();
            throw e;
        }
        return new InputStream() {
            @Override public int read() throws IOException { return r.body.read(); }
            @Override public int read(byte[] b, int off, int len) throws IOException { return r.body.read(b, off, len); }
            @Override public void close() { r.close(); }
        };
    }

    @Override public boolean exists(String path) throws IOException {
        String[] l = loc(path);
        if (l[0].isEmpty()) return true;
        if (l[1].isEmpty()) {
            try (HttpRaw.Resp r = call("HEAD", l[0], "", "")) { return r.code == 200; }
        }
        try (HttpRaw.Resp r = call("HEAD", l[0], l[1], "")) { if (r.code == 200) return true; }
        Listing li = listBucket(l[0], l[1] + "/", true, 1);
        return !li.keys.isEmpty() || !li.prefixes.isEmpty();
    }

    // ---- writing ------------------------------------------------------------------------------------

    private final class Upload extends OutputStream implements FmAbortable {
        private final String bkt, key;
        private final File tmp;
        private final OutputStream out;
        private final MessageDigest md;
        private boolean finished;

        Upload(String bkt, String key) throws IOException {
            this.bkt = bkt;
            this.key = key;
            this.tmp = File.createTempFile("s3up", ".tmp", tmpDir);
            this.out = new FileOutputStream(tmp);
            try { this.md = MessageDigest.getInstance("SHA-256"); } catch (Exception e) { throw new IOException(e); }
        }

        @Override public void write(int b) throws IOException { out.write(b); md.update((byte) b); }
        @Override public void write(byte[] b, int off, int len) throws IOException { out.write(b, off, len); md.update(b, off, len); }

        @Override public void close() throws IOException {
            if (finished) return;
            finished = true;
            try {
                out.close();
                String sha = hex(md.digest());
                try (InputStream in = new FileInputStream(tmp); HttpRaw.Resp r = call("PUT", bkt, key, "", null, in, tmp.length(), sha)) {
                    if (r.code != 200 && r.code != 201 && r.code != 204) throw fail("cannot write " + key, r);
                }
            } finally {
                //noinspection ResultOfMethodCallIgnored
                tmp.delete();
            }
        }

        @Override public void abort() {
            if (finished) return;
            finished = true;
            try { out.close(); } catch (IOException ignored) { }
            //noinspection ResultOfMethodCallIgnored
            tmp.delete();
        }
    }

    @Override public OutputStream create(String path, long size) throws IOException {
        String[] l = loc(path);
        if (l[0].isEmpty() || l[1].isEmpty()) throw new IOException("a file needs a bucket and a name");
        return new Upload(l[0], l[1]);
    }

    @Override public void mkdir(String path) throws IOException {
        String[] l = loc(path);
        if (l[0].isEmpty()) throw new IOException("choose a bucket first");
        if (l[1].isEmpty()) { // a new bucket
            try (HttpRaw.Resp r = call("PUT", l[0], "", "")) {
                if (r.code != 200 && r.code != 409) throw fail("cannot create the bucket", r);
            }
            return;
        }
        try (HttpRaw.Resp r = call("PUT", l[0], l[1] + "/", "")) {
            if (r.code != 200 && r.code != 201 && r.code != 204) throw fail("cannot create " + path, r);
        }
    }

    private void deleteKey(String bkt, String key) throws IOException {
        try (HttpRaw.Resp r = call("DELETE", bkt, key, "")) {
            if (r.code != 200 && r.code != 204 && r.code != 404) throw fail("cannot delete " + key, r);
        }
    }

    @Override public void delete(String path) throws IOException {
        String[] l = loc(path);
        if (l[0].isEmpty()) return;
        if (l[1].isEmpty()) { // an empty bucket
            try (HttpRaw.Resp r = call("DELETE", l[0], "", "")) {
                if (r.code != 200 && r.code != 204 && r.code != 404) throw fail("cannot delete the bucket (is it empty?)", r);
            }
            return;
        }
        deleteKey(l[0], l[1]);
        Listing li = listBucket(l[0], l[1] + "/", false, 0);
        for (String k : li.keys) deleteKey(l[0], k);
    }

    @Override public void rename(String path, String newName) throws IOException {
        String p = parent(path);
        if (!moveWithin(path, join(p == null ? "/" : p, newName))) throw new IOException("cannot rename " + path);
    }

    private void copyKey(String fromBkt, String fromKey, String toBkt, String toKey) throws IOException {
        TreeMap<String, String> extra = new TreeMap<>();
        extra.put("x-amz-copy-source", "/" + uriEncode(fromBkt, false) + "/" + uriEncode(fromKey, true));
        try (HttpRaw.Resp r = call("PUT", toBkt, toKey, "", extra, null, 0, EMPTY_SHA)) {
            if (r.code != 200) throw fail("cannot copy " + fromKey, r);
            String t = r.text();
            if (t.contains("<Error>")) throw new IOException("cannot copy " + fromKey);
        }
    }

    @Override public boolean moveWithin(String from, String to) throws IOException {
        String[] a = loc(from), b = loc(to);
        if (a[0].isEmpty() || a[1].isEmpty() || b[0].isEmpty() || b[1].isEmpty()) return false;
        boolean isFile;
        try (HttpRaw.Resp r = call("HEAD", a[0], a[1], "")) { isFile = r.code == 200; }
        if (isFile) {
            copyKey(a[0], a[1], b[0], b[1]);
            deleteKey(a[0], a[1]);
            return true;
        }
        Listing li = listBucket(a[0], a[1] + "/", false, 0);
        if (li.keys.isEmpty()) return false;
        for (String k : li.keys) {
            copyKey(a[0], k, b[0], b[1] + "/" + k.substring(a[1].length() + 1));
        }
        for (String k : li.keys) deleteKey(a[0], k);
        return true;
    }

    @Override public File localFile(String path) { return null; }

    @Override public long freeSpace() { return -1; }

    @Override public void close() { }
}
