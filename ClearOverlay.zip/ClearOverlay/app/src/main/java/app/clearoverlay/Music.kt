package app.clearoverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

/** The one music player of the app (kept alive by [MusicService] so music goes on with the screen off). */
@Suppress("UnsafeOptInUsageError")
object MusicPlayer {
    class Track(val uri: Uri, val title: String, val artist: String, val durationMs: Long)

    @Volatile var player: ExoPlayer? = null
    @Volatile var queue: List<Track> = emptyList()
    /** Playing speed (pitch stays the same where the audio path allows it). */
    @Volatile var speed = 1f
    /** Time (elapsedRealtime) when the sleep timer pauses the music; 0 = off. */
    @Volatile var sleepAt = 0L
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private val sleepRun = Runnable { player?.pause(); sleepAt = 0L }

    fun setSleep(minutes: Int) {
        handler.removeCallbacks(sleepRun)
        if (minutes <= 0) { sleepAt = 0L; return }
        sleepAt = android.os.SystemClock.elapsedRealtime() + minutes * 60_000L
        handler.postDelayed(sleepRun, minutes * 60_000L)
    }

    fun sleepLeftMin(): Int = if (sleepAt <= 0L) 0 else (((sleepAt - android.os.SystemClock.elapsedRealtime()) / 60_000L).toInt() + 1).coerceAtLeast(1)

    fun setSpeed(f: Float) {
        speed = f
        player?.playbackParameters = androidx.media3.common.PlaybackParameters(f)
    }

    /** Puts [t] right after the song that is playing now. */
    fun playNext(ctx: Context, t: Track) {
        val p = player
        if (p == null || queue.isEmpty()) { play(ctx, listOf(t), 0); return }
        val at = (p.currentMediaItemIndex + 1).coerceAtMost(queue.size)
        queue = queue.toMutableList().apply { add(at, t) }
        p.addMediaItem(at, MediaItem.Builder().setUri(t.uri).setMediaId(t.uri.toString()).build())
    }

    fun get(ctx: Context): ExoPlayer {
        player?.let { return it }
        val app = ctx.applicationContext
        AudioCfg.load(app)
        // the sound enhancer sits in the audio sink, so everything this player plays goes through it
        val rf = audioFxRenderersFactory(app)
        val p = ExoPlayer.Builder(app, rf)
            .setAudioAttributes(
                androidx.media3.common.AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        player = p
        return p
    }

    fun play(ctx: Context, list: List<Track>, index: Int) {
        if (list.isEmpty()) return
        val p = get(ctx)
        queue = list
        val items = list.map { MediaItem.Builder().setUri(it.uri).setMediaId(it.uri.toString()).build() }
        p.setMediaItems(items, index.coerceIn(0, list.size - 1), 0L)
        if (speed != 1f) p.playbackParameters = androidx.media3.common.PlaybackParameters(speed)
        p.prepare()
        p.play()
        MusicService.start(ctx)
    }

    fun current(): Track? {
        val p = player ?: return null
        return queue.getOrNull(p.currentMediaItemIndex)
    }

    fun stop() {
        setSleep(0) // an old sleep timer must not pause the next song the user starts later
        player?.release()
        player = null
        queue = emptyList()
    }

    /** Every music file the phone's media index knows (needs the audio permission). */
    fun scan(ctx: Context): List<Track> {
        val out = ArrayList<Track>()
        val proj = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.DURATION
        )
        runCatching {
            ctx.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj,
                // music, podcasts, ASMR, audiobooks: everything except ringtones, notification and alarm sounds
                MediaStore.Audio.Media.IS_RINGTONE + " = 0 AND " + MediaStore.Audio.Media.IS_NOTIFICATION + " = 0 AND " +
                    MediaStore.Audio.Media.IS_ALARM + " = 0 AND " + MediaStore.Audio.Media.DURATION + " > 10000",
                null, MediaStore.Audio.Media.TITLE + " COLLATE LOCALIZED ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    val artist = c.getString(2) ?: ""
                    out.add(
                        Track(
                            ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id),
                            c.getString(1) ?: "?",
                            if (artist == "<unknown>") "" else artist,
                            c.getLong(3)
                        )
                    )
                }
            }
        }
        return out
    }
}

/** Foreground service with a small notification (play / pause, next, stop) so music is not stopped by the system. */
@Suppress("UnsafeOptInUsageError")
class MusicService : Service() {
    companion object {
        const val ACT_TOGGLE = "app.clearoverlay.MUSIC_TOGGLE"
        const val ACT_NEXT = "app.clearoverlay.MUSIC_NEXT"
        const val ACT_STOP = "app.clearoverlay.MUSIC_STOP"
        private const val CH = "crsc_music"
        private const val ID = 4107
        private const val IDLE_STOP_MS = 10 * 60 * 1000L

        fun start(ctx: Context) {
            ctx.startForegroundService(Intent(ctx, MusicService::class.java))
        }

        /** Stops the music and removes the notification. */
        fun stopAll(ctx: Context) {
            MusicPlayer.setSleep(0)
            MusicPlayer.stop()
            ctx.stopService(Intent(ctx, MusicService::class.java))
        }
    }

    private val ui = Handler(Looper.getMainLooper())
    private var attached: Player? = null
    private val stopIdle = Runnable { MusicPlayer.stop(); stopSelf() }

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            ui.removeCallbacks(stopIdle)
            if (!isPlaying) ui.postDelayed(stopIdle, IDLE_STOP_MS) // paused for a long time: let the service go
            refresh()
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            refresh()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, getString(R.string.aud_title), NotificationManager.IMPORTANCE_LOW))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val p = MusicPlayer.player
        if (p == null) {
            // started with nothing to play (for example after the process was recreated)
            startForeground(ID, build(null, false), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            stopSelf()
            return START_NOT_STICKY
        }
        if (attached !== p) {
            attached?.removeListener(listener)
            p.addListener(listener)
            attached = p
        }
        when (intent?.action) {
            ACT_TOGGLE -> if (p.isPlaying) p.pause() else p.play()
            ACT_NEXT -> p.seekToNextMediaItem()
            ACT_STOP -> {
                MusicPlayer.stop()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
        }
        startForeground(ID, build(MusicPlayer.current(), p.isPlaying), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        return START_NOT_STICKY
    }

    private fun refresh() {
        val p = MusicPlayer.player ?: return
        getSystemService(NotificationManager::class.java).notify(ID, build(MusicPlayer.current(), p.isPlaying))
    }

    private fun act(action: String, code: Int): PendingIntent = PendingIntent.getService(
        this, code, Intent(this, MusicService::class.java).setAction(action), PendingIntent.FLAG_IMMUTABLE
    )

    private fun build(t: MusicPlayer.Track?, playing: Boolean): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, AudioActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val toggle = Notification.Action.Builder(
            Icon.createWithResource(this, if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play),
            getString(if (playing) R.string.aud_pause else R.string.aud_play),
            act(ACT_TOGGLE, 1)
        ).build()
        val next = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_media_next), getString(R.string.aud_next), act(ACT_NEXT, 2)
        ).build()
        val stop = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), getString(R.string.aud_stop), act(ACT_STOP, 3)
        ).build()
        return Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(t?.title ?: getString(R.string.aud_title))
            .setContentText(t?.artist ?: "")
            .setContentIntent(open)
            .setOngoing(playing)
            .setOnlyAlertOnce(true)
            .addAction(toggle)
            .addAction(next)
            .addAction(stop)
            .setStyle(Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2))
            .build()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        attached?.removeListener(listener)
        attached = null
        super.onDestroy()
    }
}
