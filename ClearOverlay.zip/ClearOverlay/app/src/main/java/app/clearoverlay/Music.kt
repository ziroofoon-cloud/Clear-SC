package app.clearoverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

/** The one music player of the app (kept alive by [MusicService] so music goes on with the screen off). */
@Suppress("UnsafeOptInUsageError")
object MusicPlayer {
    class Track(val uri: Uri, val title: String, val artist: String, val durationMs: Long)

    @Volatile var player: ExoPlayer? = null
    @Volatile var queue: List<Track> = emptyList()
    /** The list the Library (or any screen) wants the music screen to use as its song list, so Next / Previous work without the audio permission. */
    @Volatile var handoff: List<Track> = emptyList()
    /** Playing speed (pitch stays the same where the audio path allows it). */
    @Volatile var speed = 1f
    /** Time (elapsedRealtime) when the sleep timer pauses the music; 0 = off. */
    @Volatile var sleepAt = 0L
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private val sleepRun = Runnable { player?.pause(); sleepAt = 0L }

    fun setSleep(minutes: Int) {
        handler.removeCallbacks(sleepRun)
        if (minutes <= 0) { sleepAt = 0L; return }
        sleepAt = android.os.SystemClock.elapsedRealtime() + minutes * 60_000L
        handler.postDelayed(sleepRun, minutes * 60_000L)
    }

    fun sleepLeftMin(): Int = if (sleepAt <= 0L) 0 else (((sleepAt - android.os.SystemClock.elapsedRealtime()) / 60_000L).toInt() + 1).coerceAtLeast(1)

    fun changeSpeed(f: Float) {
        speed = f
        player?.playbackParameters = androidx.media3.common.PlaybackParameters(f)
    }

    /** Puts [t] right after the song that is playing now. */
    fun playNext(ctx: Context, t: Track) {
        val p = player
        if (p == null || queue.isEmpty()) { play(ctx, listOf(t), 0); return }
        val at = (p.currentMediaItemIndex + 1).coerceAtMost(queue.size)
        queue = queue.toMutableList().apply { add(at, t) }
        p.addMediaItem(at, MediaItem.Builder().setUri(t.uri).setMediaId(t.uri.toString()).build())
    }

    /** Takes song number [i] out of the queue (the song that plays now cannot be removed this way). */
    fun removeAt(i: Int) {
        val p = player ?: return
        if (i !in queue.indices || i == p.currentMediaItemIndex) return
        queue = queue.toMutableList().apply { removeAt(i) }
        p.removeMediaItem(i)
    }

    /** Puts [t] at the end of the queue. */
    fun enqueue(ctx: Context, t: Track) {
        val p = player
        if (p == null || queue.isEmpty()) { play(ctx, listOf(t), 0); return }
        queue = queue.toMutableList().apply { add(t) }
        p.addMediaItem(MediaItem.Builder().setUri(t.uri).setMediaId(t.uri.toString()).build())
    }

    fun get(ctx: Context): ExoPlayer {
        player?.let { return it }
        val app = ctx.applicationContext
        AudioCfg.load(app)
        // the sound enhancer sits in the audio sink, so everything this player plays goes through it
        val rf = audioFxRenderersFactory(app)
        val p = ExoPlayer.Builder(app, rf)
            // also plays files from the Network browser (crnet://), not only local ones
            .setMediaSourceFactory(androidx.media3.exoplayer.source.DefaultMediaSourceFactory(RoutingDataSourceFactory(app)))
            .setAudioAttributes(
                androidx.media3.common.AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        player = p
        return p
    }

    fun play(ctx: Context, list: List<Track>, index: Int) {
        if (list.isEmpty()) return
        val p = get(ctx)
        queue = list
        val items = list.map { MediaItem.Builder().setUri(it.uri).setMediaId(it.uri.toString()).build() }
        p.setMediaItems(items, index.coerceIn(0, list.size - 1), 0L)
        if (speed != 1f) p.playbackParameters = androidx.media3.common.PlaybackParameters(speed)
        p.prepare()
        p.play()
        MusicService.start(ctx)
    }

    fun current(): Track? {
        val p = player ?: return null
        return queue.getOrNull(p.currentMediaItemIndex)
    }

    fun stop() {
        setSleep(0) // an old sleep timer must not pause the next song the user starts later
        player?.release()
        player = null
        queue = emptyList()
    }

    /**
     * Every song / podcast / ASMR file the phone's media index knows (needs the audio permission). The list is sorted here, not by the
     * query (some phones refuse a "COLLATE" sort order and then the whole query failed and the list stayed empty). When the
     * detailed query finds nothing, the same plain query the Library uses is tried, so the player never shows less than the Library.
     */
    fun scan(ctx: Context): List<Track> {
        val out = ArrayList<Track>()
        val proj = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.IS_RINGTONE,
            MediaStore.Audio.Media.IS_NOTIFICATION,
            MediaStore.Audio.Media.IS_ALARM,
            MediaStore.Audio.Media.BUCKET_ID
        )
        val hs = LibStore.hidden(ctx) // what the person hid in the Library is hidden here too
        // no WHERE clause: some phones store NULL in the flag columns and "= 0" then hides every song; the flags are checked here
        runCatching {
            ctx.contentResolver.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val dur = c.getLong(3)
                    if (dur in 1..9_999) continue // clicks and sound effects
                    if (c.getInt(5) != 0 || c.getInt(6) != 0 || c.getInt(7) != 0) continue // ringtones, notification and alarm sounds
                    val tu = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, c.getLong(0))
                    if (tu.toString() in hs || "f4:${c.getLong(8)}" in hs) continue
                    val artist = c.getString(2) ?: ""
                    var title = c.getString(1) ?: ""
                    if (title.isBlank() || title == "<unknown>") title = (c.getString(4) ?: "?").substringBeforeLast('.')
                    out.add(
                        Track(
                            ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, c.getLong(0)),
                            title.replace('\n', ' ').trim(),
                            if (artist == "<unknown>") "" else artist.replace('\n', ' ').trim(),
                            dur
                        )
                    )
                }
            }
        }
        if (out.isEmpty()) {
            for (it in Media.queryAudio(ctx)) if (it.uri.toString() !in hs && "f4:${it.bucketId}" !in hs) out.add(Track(it.uri, it.name.substringBeforeLast('.'), "", it.durationMs))
        }
        val col = java.text.Collator.getInstance()
        out.sortWith { a, b -> col.compare(a.title, b.title) }
        return out
    }
}

/** Foreground service with a small notification (play / pause, next, stop) so music is not stopped by the system. */
@Suppress("UnsafeOptInUsageError")
class MusicService : Service() {
    companion object {
        const val ACT_TOGGLE = "app.clearoverlay.MUSIC_TOGGLE"
        const val ACT_NEXT = "app.clearoverlay.MUSIC_NEXT"
        const val ACT_PREV = "app.clearoverlay.MUSIC_PREV"
        const val ACT_STOP = "app.clearoverlay.MUSIC_STOP"
        private const val CH = "crsc_music"
        private const val ID = 4107
        private const val IDLE_STOP_MS = 10 * 60 * 1000L

        fun start(ctx: Context) {
            ctx.startForegroundService(Intent(ctx, MusicService::class.java))
        }

        /** Stops the music and removes the notification. */
        fun stopAll(ctx: Context) {
            MusicPlayer.setSleep(0)
            MusicPlayer.stop()
            ctx.stopService(Intent(ctx, MusicService::class.java))
        }
    }

    private val ui = Handler(Looper.getMainLooper())
    private var attached: Player? = null
    private var session: android.media.session.MediaSession? = null
    private val stopIdle = Runnable { MusicPlayer.stop(); stopSelf() }

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            ui.removeCallbacks(stopIdle)
            if (!isPlaying) ui.postDelayed(stopIdle, IDLE_STOP_MS) // paused for a long time: let the service go
            refresh()
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            refresh()
        }

        // the notification's seek bar follows what the player does: seeks, buffering, speed changes
        override fun onPlaybackStateChanged(playbackState: Int) {
            updateSession()
        }

        override fun onPositionDiscontinuity(old: Player.PositionInfo, new: Player.PositionInfo, reason: Int) {
            updateSession()
        }

        override fun onPlaybackParametersChanged(playbackParameters: androidx.media3.common.PlaybackParameters) {
            updateSession()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, getString(R.string.aud_title), NotificationManager.IMPORTANCE_LOW))
        // a media session makes the notification show a seek bar you can drag (and gives lock-screen / Bluetooth buttons)
        val s = android.media.session.MediaSession(this, "crsc_music")
        s.setCallback(object : android.media.session.MediaSession.Callback() {
            override fun onPlay() { MusicPlayer.player?.play() }
            override fun onPause() { MusicPlayer.player?.pause() }
            override fun onSkipToNext() { MusicPlayer.player?.seekToNextMediaItem() }
            override fun onSkipToPrevious() { MusicPlayer.player?.seekToPreviousMediaItem() }
            override fun onSeekTo(pos: Long) {
                MusicPlayer.player?.seekTo(pos)
                updateSession()
            }
            override fun onStop() { MusicService.stopAll(this@MusicService) }
        })
        s.isActive = true
        session = s
    }

    /** Tells the media session what is playing, how long it is, and where it is now (the system moves the seek bar by itself while playing). */
    private fun updateSession() {
        val s = session ?: return
        val p = MusicPlayer.player ?: return
        val t = MusicPlayer.current()
        val dur = if (p.duration != C.TIME_UNSET && p.duration > 0) p.duration else (t?.durationMs ?: -1L)
        s.setMetadata(
            android.media.MediaMetadata.Builder()
                .putString(android.media.MediaMetadata.METADATA_KEY_TITLE, t?.title ?: "")
                .putString(android.media.MediaMetadata.METADATA_KEY_ARTIST, t?.artist ?: "")
                .putLong(android.media.MediaMetadata.METADATA_KEY_DURATION, dur)
                .build()
        )
        val state = when {
            p.playbackState == Player.STATE_BUFFERING && p.playWhenReady -> android.media.session.PlaybackState.STATE_BUFFERING
            p.isPlaying -> android.media.session.PlaybackState.STATE_PLAYING
            else -> android.media.session.PlaybackState.STATE_PAUSED
        }
        val actions = android.media.session.PlaybackState.ACTION_PLAY or android.media.session.PlaybackState.ACTION_PAUSE or
            android.media.session.PlaybackState.ACTION_PLAY_PAUSE or android.media.session.PlaybackState.ACTION_SKIP_TO_NEXT or
            android.media.session.PlaybackState.ACTION_SKIP_TO_PREVIOUS or android.media.session.PlaybackState.ACTION_SEEK_TO or
            android.media.session.PlaybackState.ACTION_STOP
        s.setPlaybackState(
            android.media.session.PlaybackState.Builder()
                .setActions(actions)
                .setState(state, p.currentPosition.coerceAtLeast(0L), if (p.isPlaying) p.playbackParameters.speed else 0f)
                .build()
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val p = MusicPlayer.player
        if (p == null) {
            // started with nothing to play (for example after the process was recreated)
            startForeground(ID, build(null, false), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            stopSelf()
            return START_NOT_STICKY
        }
        if (attached !== p) {
            attached?.removeListener(listener)
            p.addListener(listener)
            attached = p
        }
        when (intent?.action) {
            ACT_TOGGLE -> if (p.isPlaying) p.pause() else p.play()
            ACT_NEXT -> p.seekToNextMediaItem()
            ACT_PREV -> p.seekToPreviousMediaItem()
            ACT_STOP -> {
                MusicPlayer.stop()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
        }
        updateSession()
        startForeground(ID, build(MusicPlayer.current(), p.isPlaying), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        return START_NOT_STICKY
    }

    private fun refresh() {
        val p = MusicPlayer.player ?: return
        updateSession()
        getSystemService(NotificationManager::class.java).notify(ID, build(MusicPlayer.current(), p.isPlaying))
    }

    private fun act(action: String, code: Int): PendingIntent = PendingIntent.getService(
        this, code, Intent(this, MusicService::class.java).setAction(action), PendingIntent.FLAG_IMMUTABLE
    )

    private fun build(t: MusicPlayer.Track?, playing: Boolean): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, AudioActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val toggle = Notification.Action.Builder(
            Icon.createWithResource(this, if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play),
            getString(if (playing) R.string.aud_pause else R.string.aud_play),
            act(ACT_TOGGLE, 1)
        ).build()
        val next = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_media_next), getString(R.string.aud_next), act(ACT_NEXT, 2)
        ).build()
        val prev = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_media_previous), getString(R.string.aud_prev), act(ACT_PREV, 4)
        ).build()
        val stop = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), getString(R.string.aud_stop), act(ACT_STOP, 3)
        ).build()
        return Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(t?.title ?: getString(R.string.aud_title))
            .setContentText(t?.artist ?: "")
            .setContentIntent(open)
            .setOngoing(playing)
            .setOnlyAlertOnce(true)
            .addAction(prev)
            .addAction(toggle)
            .addAction(next)
            .addAction(stop)
            .setStyle(Notification.MediaStyle().setMediaSession(session?.sessionToken).setShowActionsInCompactView(0, 1, 2))
            .build()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        attached?.removeListener(listener)
        attached = null
        runCatching { session?.release() }
        session = null
        super.onDestroy()
    }
}
