package app.clearoverlay

import java.io.File
import java.io.RandomAccessFile
import java.security.MessageDigest

/** Finds identical files below a phone folder: same size first, then the first / last 64 KB, then the whole content (SHA-256). */
object FmDupes {
    private const val MIN_SIZE = 4096L
    private const val EDGE = 65536

    class Group(val size: Long, val files: List<File>)

    fun sha256(f: File, cancel: () -> Boolean = { false }): String? {
        val md = MessageDigest.getInstance("SHA-256")
        val buf = ByteArray(256 * 1024)
        return runCatching {
            f.inputStream().use { ins ->
                while (true) {
                    if (cancel()) return null
                    val n = ins.read(buf)
                    if (n < 0) break
                    md.update(buf, 0, n)
                }
            }
            md.digest().joinToString("") { "%02x".format(it) }
        }.getOrNull()
    }

    /** Cheap fingerprint: the size and the first and last 64 KB. */
    private fun edges(f: File): String? = runCatching {
        val md = MessageDigest.getInstance("SHA-256")
        RandomAccessFile(f, "r").use { r ->
            val len = r.length()
            val b = ByteArray(EDGE)
            val n1 = r.read(b)
            if (n1 > 0) md.update(b, 0, n1)
            if (len > EDGE) {
                r.seek(maxOf(0L, len - EDGE))
                val n2 = r.read(b)
                if (n2 > 0) md.update(b, 0, n2)
            }
        }
        md.digest().joinToString("") { "%02x".format(it) }
    }.getOrNull()

    fun find(
        root: File,
        hidden: Boolean,
        cancel: () -> Boolean,
        skip: (File) -> Boolean = { false },
        progress: (String) -> Unit
    ): List<Group> {
        val bySize = HashMap<Long, MutableList<File>>()
        var seen = 0
        fun walk(d: File, depth: Int) {
            if (cancel() || depth > 40) return
            val kids = d.listFiles() ?: return
            for (k in kids) {
                if (cancel()) return
                if (!hidden && k.name.startsWith(".")) continue
                if (skip(k)) continue
                // a symbolic link is never followed (a link back to a parent would never end)
                if (runCatching { k.canonicalFile != k.absoluteFile && java.nio.file.Files.isSymbolicLink(k.toPath()) }.getOrDefault(false)) continue
                if (k.isDirectory) walk(k, depth + 1)
                else if (k.isFile) {
                    val s = k.length()
                    if (s >= MIN_SIZE) bySize.getOrPut(s) { ArrayList() }.add(k)
                    if (++seen % 200 == 0) progress(k.parent ?: "")
                }
            }
        }
        walk(root, 0)
        return groups(bySize, cancel, progress)
    }

    /** Second half of [find], so a caller that already walked the storage (the cleanup scan) does not walk it again. */
    fun groups(bySize: Map<Long, List<File>>, cancel: () -> Boolean, progress: (String) -> Unit): List<Group> {
        val out = ArrayList<Group>()
        for ((size, list) in bySize) {
            if (list.size < 2) continue
            if (cancel()) break
            val byEdge = HashMap<String, MutableList<File>>()
            for (f in list) edges(f)?.let { byEdge.getOrPut(it) { ArrayList() }.add(f) }
            for (e in byEdge.values) {
                if (e.size < 2) continue
                val byHash = HashMap<String, MutableList<File>>()
                for (f in e) {
                    if (cancel()) return out
                    progress(f.name)
                    sha256(f, cancel)?.let { byHash.getOrPut(it) { ArrayList() }.add(f) }
                }
                for (g in byHash.values) if (g.size >= 2) out.add(Group(size, g.sortedBy { it.absolutePath }))
            }
        }
        // the biggest waste first
        out.sortByDescending { it.size * (it.files.size - 1) }
        return out
    }
}
