package app.clearoverlay

import android.content.ContentValues
import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.provider.MediaStore
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Saves an enhanced copy of an audio file (or the sound track of a video): decode -> [AudioFxCore] -> AAC -> .m4a
 * in Music/ClearOverlay. Same sound enhancer as the live player, but the result is a normal file you can use anywhere.
 */
object AudioExport {
    class Res(val uri: Uri?, val error: String?)

    fun run(
        ctx: Context,
        src: Uri,
        baseName: String,
        p: AudioParams,
        cancel: AtomicBoolean,
        progress: (Float) -> Unit
    ): Res {
        val ext = MediaExtractor()
        var dec: MediaCodec? = null
        var enc: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var pfd: android.os.ParcelFileDescriptor? = null
        var outUri: Uri? = null
        var ok = false
        try {
            ext.setDataSource(ctx, src, null)
            var track = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ext.trackCount) {
                val f = ext.getTrackFormat(i)
                if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { track = i; fmt = f; break }
            }
            if (track < 0 || fmt == null) return Res(null, "no audio track")
            ext.selectTrack(track)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: return Res(null, "no audio track")
            val durUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L

            val d = MediaCodec.createDecoderByType(mime)
            dec = d
            d.configure(fmt, null, null, 0)
            d.start()

            val values = ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, "$baseName.m4a")
                put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
                put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/ClearOverlay")
                put(MediaStore.Audio.Media.IS_PENDING, 1)
            }
            val uri = ctx.contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
                ?: return Res(null, "cannot create the file")
            outUri = uri
            val fd = ctx.contentResolver.openFileDescriptor(uri, "w") ?: return Res(null, "cannot open the file")
            pfd = fd
            val mux = MediaMuxer(fd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = mux

            val core = AudioFxCore()
            var sampleRate = 0
            var channels = 0
            var pcmFloat = false
            var outTrack = -1
            var muxStarted = false
            val eInfo = MediaCodec.BufferInfo()
            val dInfo = MediaCodec.BufferInfo()
            var fedFrames = 0L
            var floats = FloatArray(0)
            var bytes = ByteArray(0)

            fun drainEncoder(wait: Boolean): Boolean { // returns true when the encoder reached its end
                val e = enc ?: return false
                while (true) {
                    val o = e.dequeueOutputBuffer(eInfo, if (wait) 10000L else 0L)
                    when {
                        o == MediaCodec.INFO_TRY_AGAIN_LATER -> return false
                        o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            outTrack = mux.addTrack(e.outputFormat)
                            mux.start()
                            muxStarted = true
                        }
                        o >= 0 -> {
                            val b = e.getOutputBuffer(o)
                            if ((eInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) eInfo.size = 0
                            if (b != null && eInfo.size > 0 && muxStarted) {
                                b.position(eInfo.offset)
                                b.limit(eInfo.offset + eInfo.size)
                                mux.writeSampleData(outTrack, b, eInfo)
                            }
                            e.releaseOutputBuffer(o, false)
                            if ((eInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return true
                        }
                    }
                }
            }

            fun startEncoder() {
                val ef = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, channels)
                ef.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                ef.setInteger(MediaFormat.KEY_BIT_RATE, if (channels == 1) 160_000 else 256_000)
                ef.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 65536)
                val e = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
                e.configure(ef, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                e.start()
                enc = e
                core.configure(sampleRate, channels)
            }

            fun feed(len: Int) {
                val e = enc ?: return
                var off = 0
                while (off < len) {
                    if (cancel.get()) return
                    val idx = e.dequeueInputBuffer(10000L)
                    if (idx >= 0) {
                        val b = e.getInputBuffer(idx) ?: continue
                        val n = minOf(b.capacity(), len - off)
                        b.clear()
                        b.put(bytes, off, n)
                        val pts = fedFrames * 1_000_000L / sampleRate
                        e.queueInputBuffer(idx, 0, n, pts, 0)
                        fedFrames += (n / (2 * channels)).toLong()
                        off += n
                    }
                    drainEncoder(false)
                }
            }

            var inputDone = false
            var decDone = false
            while (!decDone && !cancel.get()) {
                if (!inputDone) {
                    val i = d.dequeueInputBuffer(10000L)
                    if (i >= 0) {
                        val b = d.getInputBuffer(i)
                        val n = if (b != null) ext.readSampleData(b, 0) else -1
                        if (n < 0) {
                            d.queueInputBuffer(i, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            d.queueInputBuffer(i, 0, n, ext.sampleTime, 0)
                            ext.advance()
                        }
                    }
                }
                val o = d.dequeueOutputBuffer(dInfo, 10000L)
                if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val of = d.outputFormat
                    sampleRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    channels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    pcmFloat = of.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                        of.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                    if (channels > 2) return Res(null, "more than 2 channels is not supported")
                    if (enc == null) startEncoder()
                } else if (o >= 0) {
                    if (enc == null) { // the format-change message did not come first: read it now
                        val of = d.outputFormat
                        sampleRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        channels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        if (channels > 2) return Res(null, "more than 2 channels is not supported")
                        startEncoder()
                    }
                    val ob = d.getOutputBuffer(o)
                    if (ob != null && dInfo.size > 0) {
                        ob.position(dInfo.offset)
                        ob.limit(dInfo.offset + dInfo.size)
                        ob.order(ByteOrder.nativeOrder())
                        val n = if (pcmFloat) dInfo.size / 4 else dInfo.size / 2
                        if (floats.size < n) floats = FloatArray(n)
                        if (pcmFloat) { for (k in 0 until n) floats[k] = ob.getFloat() }
                        else { for (k in 0 until n) floats[k] = ob.getShort() / 32768f }
                        core.process(floats, n / channels, p)
                        if (bytes.size < n * 2) bytes = ByteArray(n * 2)
                        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
                        for (k in 0 until n) bb.putShort((floats[k].coerceIn(-1f, 1f) * 32767f).toInt().toShort())
                        feed(n * 2)
                        if (durUs > 0) progress((dInfo.presentationTimeUs.toFloat() / durUs).coerceIn(0f, 1f))
                    }
                    d.releaseOutputBuffer(o, false)
                    if ((dInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) decDone = true
                }
            }
            if (cancel.get()) return Res(null, "cancelled")
            val e = enc ?: return Res(null, "no sound was decoded")
            // tell the encoder it is over, then drain it
            while (true) {
                val idx = e.dequeueInputBuffer(10000L)
                if (idx >= 0) {
                    e.queueInputBuffer(idx, 0, 0, fedFrames * 1_000_000L / sampleRate, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    break
                }
                drainEncoder(false)
            }
            while (!drainEncoder(true)) { if (cancel.get()) return Res(null, "cancelled") }
            ok = true
            progress(1f)
            return Res(uri, null)
        } catch (t: Throwable) {
            return Res(null, t.message ?: t.javaClass.simpleName)
        } finally {
            runCatching { dec?.stop() }; runCatching { dec?.release() }
            runCatching { enc?.stop() }; runCatching { enc?.release() }
            runCatching { if (ok) muxer?.stop() }; runCatching { muxer?.release() }
            runCatching { pfd?.close() }
            runCatching { ext.release() }
            val u = outUri
            if (u != null) {
                if (ok) {
                    runCatching {
                        val v = ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }
                        ctx.contentResolver.update(u, v, null, null)
                    }
                } else runCatching { ctx.contentResolver.delete(u, null, null) }
            }
        }
    }
}
