package app.clearoverlay

import android.content.ContentValues
import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.provider.MediaStore
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Saves an enhanced copy of an audio file (or the sound track of a video): decode -> [AudioFxCore] -> AAC -> .m4a
 * in Music/ClearOverlay. Same sound enhancer as the live player, but the result is a normal file you can use anywhere.
 */
/** Output formats of the sound export. [kind]: 0 = AAC in .m4a, 1 = Opus in .ogg, 2 = WAV (16-bit PCM, no compression). */
class AudioFormatSpec(val id: Int, val label: Int, val ext: String, val mime: String, val kind: Int, val kbps: Int)

object AudioFormats {
    /** The first one is the recommended one: plays everywhere, small, no audible loss. */
    val ALL = listOf(
        AudioFormatSpec(0, R.string.afmt_aac256, "m4a", "audio/mp4", 0, 256),
        AudioFormatSpec(1, R.string.afmt_aac320, "m4a", "audio/mp4", 0, 320),
        AudioFormatSpec(2, R.string.afmt_aac128, "m4a", "audio/mp4", 0, 128),
        AudioFormatSpec(3, R.string.afmt_opus160, "ogg", "audio/ogg", 1, 160),
        AudioFormatSpec(4, R.string.afmt_opus96, "ogg", "audio/ogg", 1, 96),
        AudioFormatSpec(5, R.string.afmt_wav, "wav", "audio/x-wav", 2, 0)
    )
    const val RECOMMENDED = 0
    fun get(id: Int): AudioFormatSpec = ALL.firstOrNull { it.id == id } ?: ALL[0]
}

object AudioExport {
    class Res(val uri: Uri?, val error: String?, val ext: String = "m4a")

    /** Editing on top of the enhancement: a part (microseconds), fades (seconds), gain (dB), and whether the sound enhancer runs. */
    class Edit(
        val startUs: Long = 0L,
        val endUs: Long = -1L,
        val fadeInSec: Float = 0f,
        val fadeOutSec: Float = 0f,
        val gainDb: Float = 0f,
        val enhance: Boolean = true,
        /** Output format ([AudioFormats]); -1 = the one chosen in the sound settings. */
        val fmt: Int = -1,
        /** Playing speed of the result (0.25 .. 4). The pitch changes with it, like a tape or a record. */
        val speed: Float = 1f,
        /** Another sound added to this one (background music, a voice-over ...); null = none. It is played from the start of the kept part. */
        val mixUri: Uri? = null,
        /** Volume of the added sound in dB (0 = as it is). */
        val mixGainDb: Float = 0f,
        /** true = the added sound replaces the original one; false = both are heard. */
        val mixReplace: Boolean = false,
        /** Repeat the added sound when it is shorter than the kept part. */
        val mixLoop: Boolean = true,
        /** Write to this file (in the app's cache) instead of the Music folder; used by Edit video to get a sound track. */
        val outFile: java.io.File? = null
    )

    fun run(
        ctx: Context,
        src: Uri,
        baseName: String,
        p: AudioParams,
        cancel: AtomicBoolean,
        ed: Edit = Edit(),
        progress: (Float) -> Unit
    ): Res {
        val ext = MediaExtractor()
        var dec: MediaCodec? = null
        var enc: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var pfd: android.os.ParcelFileDescriptor? = null
        var outUri: Uri? = null
        var ok = false
        val spec = AudioFormats.get(if (ed.fmt >= 0) ed.fmt else AudioCfg.exportFmt)
        var wavCh: java.nio.channels.FileChannel? = null
        var wavBytes = 0L
        var outRate = 0
        var started = false
        var mixSrc: PcmSource? = null
        var mixTmp = FloatArray(0)
        val mixGain = Math.pow(10.0, ed.mixGainDb / 20.0).toFloat()
        try {
            ext.setDataSource(ctx, src, null)
            var track = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ext.trackCount) {
                val f = ext.getTrackFormat(i)
                if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { track = i; fmt = f; break }
            }
            if (track < 0 || fmt == null) return Res(null, "no audio track")
            ext.selectTrack(track)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: return Res(null, "no audio track")
            val durUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
            val startUs = ed.startUs.coerceAtLeast(0L)
            val endUs = if (ed.endUs > startUs) ed.endUs else if (durUs > 0) durUs else Long.MAX_VALUE
            val spanUs = if (endUs == Long.MAX_VALUE) 0L else endUs - startUs
            val gainLin = Math.pow(10.0, ed.gainDb / 20.0).toFloat()
            var written = 0L // frames written so far (for the fades)
            if (startUs > 0L) ext.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)

            val d = MediaCodec.createDecoderByType(mime)
            dec = d
            d.configure(fmt, null, null, 0)
            d.start()

            val uri: Uri
            val fd: android.os.ParcelFileDescriptor
            if (ed.outFile != null) {
                uri = Uri.fromFile(ed.outFile)
                fd = android.os.ParcelFileDescriptor.open(
                    ed.outFile,
                    android.os.ParcelFileDescriptor.MODE_READ_WRITE or android.os.ParcelFileDescriptor.MODE_CREATE or android.os.ParcelFileDescriptor.MODE_TRUNCATE
                )
            } else {
                val values = ContentValues().apply {
                    put(MediaStore.Audio.Media.DISPLAY_NAME, Stamp.name(baseName) + "." + spec.ext)
                    put(MediaStore.Audio.Media.MIME_TYPE, spec.mime)
                    put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/ClearOverlay")
                    put(MediaStore.Audio.Media.IS_PENDING, 1)
                }
                uri = ctx.contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
                    ?: return Res(null, "cannot create the file")
                outUri = uri
                fd = ctx.contentResolver.openFileDescriptor(uri, "w") ?: return Res(null, "cannot open the file")
            }
            pfd = fd
            val mux = MediaMuxer(
                fd.fileDescriptor,
                if (spec.kind == 1) MediaMuxer.OutputFormat.MUXER_OUTPUT_OGG else MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4
            )
            if (spec.kind != 2) muxer = mux
            if (spec.kind == 2) wavCh = java.io.FileOutputStream(fd.fileDescriptor).channel

            val core = AudioFxCore()
            var sampleRate = 0
            var channels = 0
            var pcmFloat = false
            var outTrack = -1
            var muxStarted = false
            val eInfo = MediaCodec.BufferInfo()
            val dInfo = MediaCodec.BufferInfo()
            var fedFrames = 0L
            var floats = FloatArray(0)
            var bytes = ByteArray(0)

            fun drainEncoder(wait: Boolean): Boolean { // returns true when the encoder reached its end
                val e = enc ?: return false
                while (true) {
                    val o = e.dequeueOutputBuffer(eInfo, if (wait) 10000L else 0L)
                    when {
                        o == MediaCodec.INFO_TRY_AGAIN_LATER -> return false
                        o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            outTrack = mux.addTrack(e.outputFormat)
                            mux.start()
                            muxStarted = true
                        }
                        o >= 0 -> {
                            val b = e.getOutputBuffer(o)
                            if ((eInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) eInfo.size = 0
                            if (b != null && eInfo.size > 0 && muxStarted) {
                                b.position(eInfo.offset)
                                b.limit(eInfo.offset + eInfo.size)
                                mux.writeSampleData(outTrack, b, eInfo)
                            }
                            e.releaseOutputBuffer(o, false)
                            if ((eInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return true
                        }
                    }
                }
            }

            fun wavHeader(dataLen: Long): ByteBuffer {
                val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
                h.put("RIFF".toByteArray()); h.putInt((36 + dataLen).coerceAtMost(0xFFFFFFFFL).toInt()); h.put("WAVE".toByteArray())
                h.put("fmt ".toByteArray()); h.putInt(16); h.putShort(1); h.putShort(channels.toShort())
                h.putInt(outRate); h.putInt(outRate * channels * 2); h.putShort((channels * 2).toShort()); h.putShort(16)
                h.put("data".toByteArray()); h.putInt(dataLen.coerceAtMost(0xFFFFFFFFL).toInt())
                h.flip()
                return h
            }

            fun startEncoder() {
                // Opus only accepts these rates; other rates (44.1 kHz ...) are converted to 48 kHz below
                outRate = if (spec.kind == 1 && sampleRate !in intArrayOf(8000, 12000, 16000, 24000, 48000)) 48000 else sampleRate
                core.configure(sampleRate, channels)
                if (ed.mixUri != null) mixSrc = PcmSource(ctx, ed.mixUri, sampleRate, channels, ed.mixLoop)
                started = true
                if (spec.kind == 2) {
                    wavCh?.write(wavHeader(0L))
                    return
                }
                val ef = MediaFormat.createAudioFormat(if (spec.kind == 1) MediaFormat.MIMETYPE_AUDIO_OPUS else MediaFormat.MIMETYPE_AUDIO_AAC, outRate, channels)
                if (spec.kind == 0) ef.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                ef.setInteger(MediaFormat.KEY_BIT_RATE, if (channels == 1) spec.kbps * 1000 * 5 / 8 else spec.kbps * 1000)
                ef.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 65536)
                val e = MediaCodec.createEncoderByType(if (spec.kind == 1) MediaFormat.MIMETYPE_AUDIO_OPUS else MediaFormat.MIMETYPE_AUDIO_AAC)
                e.configure(ef, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                e.start()
                enc = e
            }

            // linear resampler (only used for Opus when the file's rate is not one Opus accepts)
            var rpos = 0.0
            val lastFr = ShortArray(2)
            var rbytes = ByteArray(0)
            var feedBuf = ByteArray(0)
            fun resample(src: ByteArray, cnt: Int): Int {
                feedBuf = src
                if (outRate == sampleRate && ed.speed == 1f) return cnt * channels * 2
                val inb = ByteBuffer.wrap(src).order(ByteOrder.LITTLE_ENDIAN)
                fun smp(i: Int, k: Int): Int = if (i < 0) lastFr[k].toInt() else inb.getShort((i * channels + k) * 2).toInt()
                val step = ed.speed * sampleRate.toDouble() / outRate
                val maxOut = (cnt / step).toInt() + 4
                if (rbytes.size < maxOut * channels * 2) rbytes = ByteArray(maxOut * channels * 2)
                val ob = ByteBuffer.wrap(rbytes).order(ByteOrder.LITTLE_ENDIAN)
                var nOut = 0
                while (true) {
                    val i0 = Math.floor(rpos).toInt()
                    if (i0 + 1 > cnt - 1) break
                    val fr = (rpos - i0).toFloat()
                    for (k in 0 until channels) ob.putShort((smp(i0, k) * (1f - fr) + smp(i0 + 1, k) * fr).toInt().toShort())
                    nOut++
                    rpos += step
                }
                rpos -= cnt
                for (k in 0 until channels) lastFr[k] = smp(cnt - 1, k).toShort()
                feedBuf = rbytes
                return nOut * channels * 2
            }

            fun feed(len0: Int) {
                val len = resample(bytes, len0 / (2 * channels))
                if (spec.kind == 2) {
                    wavCh?.write(ByteBuffer.wrap(feedBuf, 0, len))
                    wavBytes += len
                    return
                }
                val e = enc ?: return
                var off = 0
                while (off < len) {
                    if (cancel.get()) return
                    val idx = e.dequeueInputBuffer(10000L)
                    if (idx >= 0) {
                        val b = e.getInputBuffer(idx) ?: continue
                        val n = minOf(b.capacity(), len - off)
                        b.clear()
                        b.put(feedBuf, off, n)
                        val pts = fedFrames * 1_000_000L / outRate
                        e.queueInputBuffer(idx, 0, n, pts, 0)
                        fedFrames += (n / (2 * channels)).toLong()
                        off += n
                    }
                    drainEncoder(false)
                }
            }

            var inputDone = false
            var decDone = false
            while (!decDone && !cancel.get()) {
                if (!inputDone) {
                    val i = d.dequeueInputBuffer(10000L)
                    if (i >= 0) {
                        val b = d.getInputBuffer(i)
                        val n = if (b != null) ext.readSampleData(b, 0) else -1
                        if (n < 0) {
                            d.queueInputBuffer(i, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            d.queueInputBuffer(i, 0, n, ext.sampleTime, 0)
                            ext.advance()
                        }
                    }
                }
                val o = d.dequeueOutputBuffer(dInfo, 10000L)
                if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val of = d.outputFormat
                    sampleRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    channels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    pcmFloat = of.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                        of.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                    if (channels > 2) return Res(null, "more than 2 channels is not supported")
                    if (!started) startEncoder()
                } else if (o >= 0) {
                    if (!started) { // the format-change message did not come first: read it now
                        val of = d.outputFormat
                        sampleRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        channels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        if (channels > 2) return Res(null, "more than 2 channels is not supported")
                        startEncoder()
                    }
                    val ob = d.getOutputBuffer(o)
                    var pastEnd = false
                    if (ob != null && dInfo.size > 0) {
                        ob.position(dInfo.offset)
                        ob.limit(dInfo.offset + dInfo.size)
                        ob.order(ByteOrder.nativeOrder())
                        val n = if (pcmFloat) dInfo.size / 4 else dInfo.size / 2
                        val frames = n / channels
                        val bufStart = dInfo.presentationTimeUs
                        val bufEnd = bufStart + frames * 1_000_000L / sampleRate
                        if (bufStart >= endUs) {
                            pastEnd = true
                        } else if (bufEnd > startUs) {
                            if (floats.size < n) floats = FloatArray(n)
                            if (pcmFloat) { for (k in 0 until n) floats[k] = ob.getFloat() }
                            else { for (k in 0 until n) floats[k] = ob.getShort() / 32768f }
                            if (ed.enhance) core.process(floats, frames, p) // the whole block, so the filters stay in step
                            val skip = if (bufStart < startUs) ((startUs - bufStart) * sampleRate / 1_000_000L).toInt().coerceIn(0, frames) else 0
                            var keep = frames
                            if (bufEnd > endUs) { keep = frames - ((bufEnd - endUs) * sampleRate / 1_000_000L).toInt().coerceIn(0, frames); pastEnd = true }
                            val cnt = (keep - skip).coerceAtLeast(0)
                            if (cnt > 0) {
                                val ms = mixSrc
                                if (ms != null) {
                                    if (mixTmp.size < cnt * channels) mixTmp = FloatArray(cnt * channels)
                                    ms.read(mixTmp, cnt)
                                    val o0 = skip * channels
                                    if (ed.mixReplace) for (j in 0 until cnt * channels) floats[o0 + j] = mixTmp[j] * mixGain
                                    else for (j in 0 until cnt * channels) floats[o0 + j] += mixTmp[j] * mixGain
                                }
                                if (bytes.size < cnt * channels * 2) bytes = ByteArray(cnt * channels * 2)
                                val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
                                val spanSec = if (spanUs > 0) spanUs / 1e6f / ed.speed else 0f
                                for (f in 0 until cnt) {
                                    var g = gainLin
                                    val t = (written + f).toFloat() / sampleRate / ed.speed
                                    if (ed.fadeInSec > 0f && t < ed.fadeInSec) { val x = t / ed.fadeInSec; g *= x * x * (3f - 2f * x) }
                                    if (ed.fadeOutSec > 0f && spanSec > 0f && t > spanSec - ed.fadeOutSec) { val x = ((spanSec - t) / ed.fadeOutSec).coerceIn(0f, 1f); g *= x * x * (3f - 2f * x) }
                                    for (k in 0 until channels) {
                                        val v = floats[(skip + f) * channels + k] * g
                                        bb.putShort((v.coerceIn(-1f, 1f) * 32767f).toInt().toShort())
                                    }
                                }
                                feed(cnt * channels * 2)
                                written += cnt
                            }
                            val den = if (spanUs > 0) spanUs else durUs
                            if (den > 0) progress(((bufStart - startUs).toFloat() / den).coerceIn(0f, 1f))
                        }
                    }
                    d.releaseOutputBuffer(o, false)
                    if ((dInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0 || pastEnd) decDone = true
                }
            }
            if (cancel.get()) return Res(null, "cancelled")
            if (!started) return Res(null, "no sound was decoded")
            if (spec.kind == 2) {
                wavCh?.position(0)
                wavCh?.write(wavHeader(wavBytes))
                ok = true
                progress(1f)
                return Res(uri, null, spec.ext)
            }
            val e = enc ?: return Res(null, "no sound was decoded")
            // tell the encoder it is over, then drain it
            while (true) {
                val idx = e.dequeueInputBuffer(10000L)
                if (idx >= 0) {
                    e.queueInputBuffer(idx, 0, 0, fedFrames * 1_000_000L / outRate, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    break
                }
                drainEncoder(false)
            }
            while (!drainEncoder(true)) { if (cancel.get()) return Res(null, "cancelled") }
            ok = true
            progress(1f)
            return Res(uri, null, spec.ext)
        } catch (t: Throwable) {
            return Res(null, t.message ?: t.javaClass.simpleName)
        } finally {
            runCatching { dec?.stop() }; runCatching { dec?.release() }
            runCatching { enc?.stop() }; runCatching { enc?.release() }
            runCatching { if (ok) muxer?.stop() }; runCatching { muxer?.release() }
            runCatching { wavCh?.close() }; runCatching { pfd?.close() }
            runCatching { ext.release() }
            runCatching { mixSrc?.close() }
            if (!ok && ed.outFile != null) runCatching { ed.outFile.delete() }
            val u = outUri
            if (u != null) {
                if (ok) {
                    runCatching {
                        val v = ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }
                        ctx.contentResolver.update(u, v, null, null)
                    }
                } else runCatching { ctx.contentResolver.delete(u, null, null) }
            }
        }
    }
}

/**
 * Reads a sound file as interleaved float frames at a chosen sample rate and channel count (mono / stereo are converted, the
 * rate is changed with linear interpolation). Decoding happens on demand while [read] is called, so a long song is never held
 * in memory. When [loop] is on it starts over when it ends; otherwise (or on any error) it continues with silence.
 */
class PcmSource(private val ctx: Context, private val uri: Uri, private val rate: Int, private val ch: Int, private val loop: Boolean) {
    private var ext: MediaExtractor? = null
    private var dec: MediaCodec? = null
    private val info = MediaCodec.BufferInfo()
    private var inDone = false
    private var outDone = false
    private var failed = false
    private var srcRate = 0
    private var srcCh = 0
    private var pcmFloat = false
    private var q = FloatArray(0)      // decoded frames waiting (interleaved, srcCh channels)
    private var qFrames = 0
    private var rpos = 0.0             // read position inside q, in source frames

    private fun open(): Boolean {
        close()
        return try {
            val e = MediaExtractor()
            ext = e
            e.setDataSource(ctx, uri, null)
            var tr = -1
            var f: MediaFormat? = null
            for (i in 0 until e.trackCount) {
                val tf = e.getTrackFormat(i)
                if ((tf.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { tr = i; f = tf; break }
            }
            if (tr < 0 || f == null) { failed = true; return false }
            e.selectTrack(tr)
            val d = MediaCodec.createDecoderByType(f.getString(MediaFormat.KEY_MIME)!!)
            d.configure(f, null, null, 0)
            d.start()
            dec = d
            inDone = false
            outDone = false
            srcRate = 0
            true
        } catch (t: Throwable) {
            failed = true
            false
        }
    }

    fun close() {
        runCatching { dec?.stop() }; runCatching { dec?.release() }; dec = null
        runCatching { ext?.release() }; ext = null
    }

    /** Decodes one more buffer into the queue. Returns false when there is nothing more (and no loop). */
    private fun more(): Boolean {
        if (failed) return false
        if (dec == null && !open()) return false
        var guard = 0
        while (guard++ < 400) {
            val d = dec ?: return false
            val e = ext ?: return false
            if (!inDone) {
                val i = d.dequeueInputBuffer(0)
                if (i >= 0) {
                    val b = d.getInputBuffer(i)
                    val n = if (b != null) e.readSampleData(b, 0) else -1
                    if (n < 0) { d.queueInputBuffer(i, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                    else { d.queueInputBuffer(i, 0, n, e.sampleTime, 0); e.advance() }
                }
            }
            val o = d.dequeueOutputBuffer(info, 5000L)
            if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) continue
            if (o >= 0) {
                if (srcRate == 0) {
                    val of = d.outputFormat
                    srcRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    srcCh = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1)
                    pcmFloat = of.containsKey(MediaFormat.KEY_PCM_ENCODING) && of.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                }
                val ob = d.getOutputBuffer(o)
                if (ob != null && info.size > 0) {
                    ob.position(info.offset)
                    ob.limit(info.offset + info.size)
                    ob.order(ByteOrder.nativeOrder())
                    val n = if (pcmFloat) info.size / 4 else info.size / 2
                    val fr = n / srcCh
                    if (q.size < (qFrames + fr) * srcCh) q = q.copyOf(((qFrames + fr) * srcCh * 3 / 2).coerceAtLeast(8192))
                    var w = qFrames * srcCh
                    for (k in 0 until fr * srcCh) q[w++] = if (pcmFloat) ob.getFloat() else ob.getShort() / 32768f
                    qFrames += fr
                }
                d.releaseOutputBuffer(o, false)
                if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true
                return true
            }
            if (outDone || (o == MediaCodec.INFO_TRY_AGAIN_LATER && inDone && guard > 50)) {
                if (loop && !failed) { if (!open()) return false } else return false
            }
        }
        return false
    }

    private fun frame(i: Int, c: Int): Float {
        // converts the channel layout: mono -> both sides, stereo -> mono (average)
        val base = i * srcCh
        return if (ch == srcCh) q[base + c] else if (srcCh == 1) q[base] else (q[base] + q[base + 1]) * 0.5f
    }

    /** Fills [out] with [frames] frames (frames * ch values). Silence where the source has ended. */
    fun read(out: FloatArray, frames: Int) {
        var f = 0
        while (f < frames) {
            if (srcRate == 0 || rpos.toInt() + 1 >= qFrames) {
                // drop what was used, then decode more
                val used = rpos.toInt().coerceAtMost(qFrames)
                if (used > 0 && srcRate != 0) {
                    System.arraycopy(q, used * srcCh, q, 0, (qFrames - used) * srcCh)
                    qFrames -= used
                    rpos -= used
                }
                if (!more()) break
                continue
            }
            val step = srcRate.toDouble() / rate
            val i0 = rpos.toInt()
            val fr = (rpos - i0).toFloat()
            for (c in 0 until ch) out[f * ch + c] = frame(i0, c) * (1f - fr) + frame(i0 + 1, c) * fr
            rpos += step
            f++
        }
        while (f < frames) { for (c in 0 until ch) out[f * ch + c] = 0f; f++ }
    }
}
