package app.clearoverlay

import android.content.ContentValues
import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.provider.MediaStore
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Saves an enhanced copy of an audio file (or the sound track of a video): decode -> [AudioFxCore] -> AAC -> .m4a
 * in Music/ClearOverlay. Same sound enhancer as the live player, but the result is a normal file you can use anywhere.
 */
/** Output formats of the sound export. [kind]: 0 = AAC in .m4a, 1 = Opus in .ogg, 2 = WAV (16-bit PCM, no compression). */
class AudioFormatSpec(val id: Int, val label: Int, val ext: String, val mime: String, val kind: Int, val kbps: Int)

object AudioFormats {
    /** The first one is the recommended one: plays everywhere, small, no audible loss. */
    val ALL = listOf(
        AudioFormatSpec(0, R.string.afmt_aac256, "m4a", "audio/mp4", 0, 256),
        AudioFormatSpec(1, R.string.afmt_aac320, "m4a", "audio/mp4", 0, 320),
        AudioFormatSpec(2, R.string.afmt_aac128, "m4a", "audio/mp4", 0, 128),
        AudioFormatSpec(3, R.string.afmt_opus160, "ogg", "audio/ogg", 1, 160),
        AudioFormatSpec(4, R.string.afmt_opus96, "ogg", "audio/ogg", 1, 96),
        AudioFormatSpec(5, R.string.afmt_wav, "wav", "audio/x-wav", 2, 0)
    )
    const val RECOMMENDED = 0
    fun get(id: Int): AudioFormatSpec = ALL.firstOrNull { it.id == id } ?: ALL[0]
}

object AudioExport {
    class Res(val uri: Uri?, val error: String?, val ext: String = "m4a")

    /** Editing on top of the enhancement: a part (microseconds), fades (seconds), gain (dB), and whether the sound enhancer runs. */
    class Edit(
        val startUs: Long = 0L,
        val endUs: Long = -1L,
        val fadeInSec: Float = 0f,
        val fadeOutSec: Float = 0f,
        val gainDb: Float = 0f,
        val enhance: Boolean = true,
        /** Output format ([AudioFormats]); -1 = the one chosen in the sound settings. */
        val fmt: Int = -1
    )

    fun run(
        ctx: Context,
        src: Uri,
        baseName: String,
        p: AudioParams,
        cancel: AtomicBoolean,
        ed: Edit = Edit(),
        progress: (Float) -> Unit
    ): Res {
        val ext = MediaExtractor()
        var dec: MediaCodec? = null
        var enc: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var pfd: android.os.ParcelFileDescriptor? = null
        var outUri: Uri? = null
        var ok = false
        val spec = AudioFormats.get(if (ed.fmt >= 0) ed.fmt else AudioCfg.exportFmt)
        var wavCh: java.nio.channels.FileChannel? = null
        var wavBytes = 0L
        var outRate = 0
        var started = false
        try {
            ext.setDataSource(ctx, src, null)
            var track = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ext.trackCount) {
                val f = ext.getTrackFormat(i)
                if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { track = i; fmt = f; break }
            }
            if (track < 0 || fmt == null) return Res(null, "no audio track")
            ext.selectTrack(track)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: return Res(null, "no audio track")
            val durUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
            val startUs = ed.startUs.coerceAtLeast(0L)
            val endUs = if (ed.endUs > startUs) ed.endUs else if (durUs > 0) durUs else Long.MAX_VALUE
            val spanUs = if (endUs == Long.MAX_VALUE) 0L else endUs - startUs
            val gainLin = Math.pow(10.0, ed.gainDb / 20.0).toFloat()
            var written = 0L // frames written so far (for the fades)
            if (startUs > 0L) ext.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)

            val d = MediaCodec.createDecoderByType(mime)
            dec = d
            d.configure(fmt, null, null, 0)
            d.start()

            val values = ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, Stamp.name(baseName) + "." + spec.ext)
                put(MediaStore.Audio.Media.MIME_TYPE, spec.mime)
                put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/ClearOverlay")
                put(MediaStore.Audio.Media.IS_PENDING, 1)
            }
            val uri = ctx.contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
                ?: return Res(null, "cannot create the file")
            outUri = uri
            val fd = ctx.contentResolver.openFileDescriptor(uri, "w") ?: return Res(null, "cannot open the file")
            pfd = fd
            val mux = MediaMuxer(
                fd.fileDescriptor,
                if (spec.kind == 1) MediaMuxer.OutputFormat.MUXER_OUTPUT_OGG else MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4
            )
            if (spec.kind != 2) muxer = mux
            if (spec.kind == 2) wavCh = java.io.FileOutputStream(fd.fileDescriptor).channel

            val core = AudioFxCore()
            var sampleRate = 0
            var channels = 0
            var pcmFloat = false
            var outTrack = -1
            var muxStarted = false
            val eInfo = MediaCodec.BufferInfo()
            val dInfo = MediaCodec.BufferInfo()
            var fedFrames = 0L
            var floats = FloatArray(0)
            var bytes = ByteArray(0)

            fun drainEncoder(wait: Boolean): Boolean { // returns true when the encoder reached its end
                val e = enc ?: return false
                while (true) {
                    val o = e.dequeueOutputBuffer(eInfo, if (wait) 10000L else 0L)
                    when {
                        o == MediaCodec.INFO_TRY_AGAIN_LATER -> return false
                        o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            outTrack = mux.addTrack(e.outputFormat)
                            mux.start()
                            muxStarted = true
                        }
                        o >= 0 -> {
                            val b = e.getOutputBuffer(o)
                            if ((eInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) eInfo.size = 0
                            if (b != null && eInfo.size > 0 && muxStarted) {
                                b.position(eInfo.offset)
                                b.limit(eInfo.offset + eInfo.size)
                                mux.writeSampleData(outTrack, b, eInfo)
                            }
                            e.releaseOutputBuffer(o, false)
                            if ((eInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return true
                        }
                    }
                }
            }

            fun wavHeader(dataLen: Long): ByteBuffer {
                val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
                h.put("RIFF".toByteArray()); h.putInt((36 + dataLen).coerceAtMost(0xFFFFFFFFL).toInt()); h.put("WAVE".toByteArray())
                h.put("fmt ".toByteArray()); h.putInt(16); h.putShort(1); h.putShort(channels.toShort())
                h.putInt(outRate); h.putInt(outRate * channels * 2); h.putShort((channels * 2).toShort()); h.putShort(16)
                h.put("data".toByteArray()); h.putInt(dataLen.coerceAtMost(0xFFFFFFFFL).toInt())
                h.flip()
                return h
            }

            fun startEncoder() {
                // Opus only accepts these rates; other rates (44.1 kHz ...) are converted to 48 kHz below
                outRate = if (spec.kind == 1 && sampleRate !in intArrayOf(8000, 12000, 16000, 24000, 48000)) 48000 else sampleRate
                core.configure(sampleRate, channels)
                started = true
                if (spec.kind == 2) {
                    wavCh?.write(wavHeader(0L))
                    return
                }
                val ef = MediaFormat.createAudioFormat(if (spec.kind == 1) MediaFormat.MIMETYPE_AUDIO_OPUS else MediaFormat.MIMETYPE_AUDIO_AAC, outRate, channels)
                if (spec.kind == 0) ef.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                ef.setInteger(MediaFormat.KEY_BIT_RATE, if (channels == 1) spec.kbps * 1000 * 5 / 8 else spec.kbps * 1000)
                ef.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 65536)
                val e = MediaCodec.createEncoderByType(if (spec.kind == 1) MediaFormat.MIMETYPE_AUDIO_OPUS else MediaFormat.MIMETYPE_AUDIO_AAC)
                e.configure(ef, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                e.start()
                enc = e
            }

            // linear resampler (only used for Opus when the file's rate is not one Opus accepts)
            var rpos = 0.0
            val lastFr = ShortArray(2)
            var rbytes = ByteArray(0)
            var feedBuf = ByteArray(0)
            fun resample(src: ByteArray, cnt: Int): Int {
                feedBuf = src
                if (outRate == sampleRate) return cnt * channels * 2
                val inb = ByteBuffer.wrap(src).order(ByteOrder.LITTLE_ENDIAN)
                fun smp(i: Int, k: Int): Int = if (i < 0) lastFr[k].toInt() else inb.getShort((i * channels + k) * 2).toInt()
                val step = sampleRate.toDouble() / outRate
                val maxOut = (cnt / step).toInt() + 4
                if (rbytes.size < maxOut * channels * 2) rbytes = ByteArray(maxOut * channels * 2)
                val ob = ByteBuffer.wrap(rbytes).order(ByteOrder.LITTLE_ENDIAN)
                var nOut = 0
                while (true) {
                    val i0 = Math.floor(rpos).toInt()
                    if (i0 + 1 > cnt - 1) break
                    val fr = (rpos - i0).toFloat()
                    for (k in 0 until channels) ob.putShort((smp(i0, k) * (1f - fr) + smp(i0 + 1, k) * fr).toInt().toShort())
                    nOut++
                    rpos += step
                }
                rpos -= cnt
                for (k in 0 until channels) lastFr[k] = smp(cnt - 1, k).toShort()
                feedBuf = rbytes
                return nOut * channels * 2
            }

            fun feed(len0: Int) {
                val len = resample(bytes, len0 / (2 * channels))
                if (spec.kind == 2) {
                    wavCh?.write(ByteBuffer.wrap(feedBuf, 0, len))
                    wavBytes += len
                    return
                }
                val e = enc ?: return
                var off = 0
                while (off < len) {
                    if (cancel.get()) return
                    val idx = e.dequeueInputBuffer(10000L)
                    if (idx >= 0) {
                        val b = e.getInputBuffer(idx) ?: continue
                        val n = minOf(b.capacity(), len - off)
                        b.clear()
                        b.put(feedBuf, off, n)
                        val pts = fedFrames * 1_000_000L / outRate
                        e.queueInputBuffer(idx, 0, n, pts, 0)
                        fedFrames += (n / (2 * channels)).toLong()
                        off += n
                    }
                    drainEncoder(false)
                }
            }

            var inputDone = false
            var decDone = false
            while (!decDone && !cancel.get()) {
                if (!inputDone) {
                    val i = d.dequeueInputBuffer(10000L)
                    if (i >= 0) {
                        val b = d.getInputBuffer(i)
                        val n = if (b != null) ext.readSampleData(b, 0) else -1
                        if (n < 0) {
                            d.queueInputBuffer(i, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            d.queueInputBuffer(i, 0, n, ext.sampleTime, 0)
                            ext.advance()
                        }
                    }
                }
                val o = d.dequeueOutputBuffer(dInfo, 10000L)
                if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val of = d.outputFormat
                    sampleRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    channels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    pcmFloat = of.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                        of.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                    if (channels > 2) return Res(null, "more than 2 channels is not supported")
                    if (!started) startEncoder()
                } else if (o >= 0) {
                    if (!started) { // the format-change message did not come first: read it now
                        val of = d.outputFormat
                        sampleRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        channels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        if (channels > 2) return Res(null, "more than 2 channels is not supported")
                        startEncoder()
                    }
                    val ob = d.getOutputBuffer(o)
                    var pastEnd = false
                    if (ob != null && dInfo.size > 0) {
                        ob.position(dInfo.offset)
                        ob.limit(dInfo.offset + dInfo.size)
                        ob.order(ByteOrder.nativeOrder())
                        val n = if (pcmFloat) dInfo.size / 4 else dInfo.size / 2
                        val frames = n / channels
                        val bufStart = dInfo.presentationTimeUs
                        val bufEnd = bufStart + frames * 1_000_000L / sampleRate
                        if (bufStart >= endUs) {
                            pastEnd = true
                        } else if (bufEnd > startUs) {
                            if (floats.size < n) floats = FloatArray(n)
                            if (pcmFloat) { for (k in 0 until n) floats[k] = ob.getFloat() }
                            else { for (k in 0 until n) floats[k] = ob.getShort() / 32768f }
                            if (ed.enhance) core.process(floats, frames, p) // the whole block, so the filters stay in step
                            val skip = if (bufStart < startUs) ((startUs - bufStart) * sampleRate / 1_000_000L).toInt().coerceIn(0, frames) else 0
                            var keep = frames
                            if (bufEnd > endUs) { keep = frames - ((bufEnd - endUs) * sampleRate / 1_000_000L).toInt().coerceIn(0, frames); pastEnd = true }
                            val cnt = (keep - skip).coerceAtLeast(0)
                            if (cnt > 0) {
                                if (bytes.size < cnt * channels * 2) bytes = ByteArray(cnt * channels * 2)
                                val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
                                val spanSec = if (spanUs > 0) spanUs / 1e6f else 0f
                                for (f in 0 until cnt) {
                                    var g = gainLin
                                    val t = (written + f).toFloat() / sampleRate
                                    if (ed.fadeInSec > 0f && t < ed.fadeInSec) { val x = t / ed.fadeInSec; g *= x * x * (3f - 2f * x) }
                                    if (ed.fadeOutSec > 0f && spanSec > 0f && t > spanSec - ed.fadeOutSec) { val x = ((spanSec - t) / ed.fadeOutSec).coerceIn(0f, 1f); g *= x * x * (3f - 2f * x) }
                                    for (k in 0 until channels) {
                                        val v = floats[(skip + f) * channels + k] * g
                                        bb.putShort((v.coerceIn(-1f, 1f) * 32767f).toInt().toShort())
                                    }
                                }
                                feed(cnt * channels * 2)
                                written += cnt
                            }
                            val den = if (spanUs > 0) spanUs else durUs
                            if (den > 0) progress(((bufStart - startUs).toFloat() / den).coerceIn(0f, 1f))
                        }
                    }
                    d.releaseOutputBuffer(o, false)
                    if ((dInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0 || pastEnd) decDone = true
                }
            }
            if (cancel.get()) return Res(null, "cancelled")
            if (!started) return Res(null, "no sound was decoded")
            if (spec.kind == 2) {
                wavCh?.position(0)
                wavCh?.write(wavHeader(wavBytes))
                ok = true
                progress(1f)
                return Res(uri, null, spec.ext)
            }
            val e = enc ?: return Res(null, "no sound was decoded")
            // tell the encoder it is over, then drain it
            while (true) {
                val idx = e.dequeueInputBuffer(10000L)
                if (idx >= 0) {
                    e.queueInputBuffer(idx, 0, 0, fedFrames * 1_000_000L / outRate, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    break
                }
                drainEncoder(false)
            }
            while (!drainEncoder(true)) { if (cancel.get()) return Res(null, "cancelled") }
            ok = true
            progress(1f)
            return Res(uri, null, spec.ext)
        } catch (t: Throwable) {
            return Res(null, t.message ?: t.javaClass.simpleName)
        } finally {
            runCatching { dec?.stop() }; runCatching { dec?.release() }
            runCatching { enc?.stop() }; runCatching { enc?.release() }
            runCatching { if (ok) muxer?.stop() }; runCatching { muxer?.release() }
            runCatching { wavCh?.close() }; runCatching { pfd?.close() }
            runCatching { ext.release() }
            val u = outUri
            if (u != null) {
                if (ok) {
                    runCatching {
                        val v = ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }
                        ctx.contentResolver.update(u, v, null, null)
                    }
                } else runCatching { ctx.contentResolver.delete(u, null, null) }
            }
        }
    }
}
