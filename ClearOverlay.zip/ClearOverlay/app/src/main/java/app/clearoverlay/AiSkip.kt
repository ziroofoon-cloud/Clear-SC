package app.clearoverlay

import android.content.Context
import android.net.Uri

/**
 * Photos whose automatic AI upscale the person cancelled. They are not started again (opening the same photo again, coming back to it,
 * rotating the phone), and after two cancelled automatic runs in a row the automatic start is switched off, with a message.
 * (Before this, every time a small photo opened the AI started again, and there was no switch to stop it.)
 */
object AiSkip {
    private const val PREF = "crsc_aiskip"
    private const val MAX = 300

    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    private fun key(u: Uri): String = Integer.toHexString(u.toString().hashCode())

    fun skipped(ctx: Context, u: Uri): Boolean = sp(ctx).getStringSet("skip", emptySet())?.contains(key(u)) == true

    /** Remembers that the automatic run was cancelled for [u]; returns how many automatic runs were cancelled in a row. */
    fun cancelled(ctx: Context, u: Uri): Int {
        val p = sp(ctx)
        val l = LinkedHashSet<String>(p.getStringSet("skip", emptySet()) ?: emptySet())
        l.add(key(u))
        while (l.size > MAX) l.remove(l.first())
        val n = p.getInt("n", 0) + 1
        p.edit().putStringSet("skip", l).putInt("n", n).apply()
        return n
    }

    /** An automatic run that finished: the cancels in a row start again from zero. */
    fun finished(ctx: Context) {
        val p = sp(ctx)
        if (p.getInt("n", 0) != 0) p.edit().putInt("n", 0).apply()
    }

    /** Turning the automatic start back on forgets every photo that was skipped. */
    fun reset(ctx: Context) {
        sp(ctx).edit().remove("skip").putInt("n", 0).apply()
    }
}
