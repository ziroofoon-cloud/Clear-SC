package app.clearoverlay

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * File names of everything the app saves: the original name, what was done (size, upscaler, quality ...) and the date and time,
 * so two results of the same file can always be told apart, e.g. "Holiday_1080p_FSR1_Best_H265_2026-10-23_0316.mp4".
 */
object Stamp {
    fun date(): String = SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US).format(Date())

    /** A file name part without characters that Android does not allow. */
    fun clean(s: String): String = s.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_").replace(Regex("\\s+"), " ").trim().trim('.').take(70)

    /** "[base]_[spec]_[spec]_[date]" (no extension). Empty specs are left out. */
    fun name(base: String, vararg specs: String?): String {
        val b = clean(base).ifEmpty { "CRSC" }
        val sb = StringBuilder(b)
        for (s in specs) if (!s.isNullOrBlank()) sb.append('_').append(clean(s))
        sb.append('_').append(date())
        return sb.toString()
    }

    /** The same specs as readable text, kept in the file's description (MediaStore) as well. */
    fun description(vararg specs: String?): String = "CRSC · " + specs.filter { !it.isNullOrBlank() }.joinToString(" · ") + " · " + date().replace('_', ' ')

    fun modeName(mode: Int): String = when (mode and 0xFF) {
        Cfg.MODE_FSR -> "FSR1"
        Cfg.MODE_SGSR -> "SGSR1"
        Cfg.MODE_LANCZOS -> "CRSC"
        Cfg.MODE_CLEAR -> "Clear"
        Cfg.MODE_ART -> "Wow"
        Cfg.MODE_NEURAL -> "Neural"
        Cfg.MODE_AI2X -> "AI2x"
        Cfg.MODE_LUMEN -> "Lumen2x"
        Cfg.MODE_AI3X -> "AI3x"
        Cfg.MODE_NOVA3 -> "Nova3x"
        Cfg.MODE_TEMPORAL -> "Temporal"
        Cfg.MODE_PIXEL -> "Pixel"
        Cfg.MODE_NIS -> "Aura"
        Cfg.MODE_NIS_SOFT -> "AuraSoft"
        Cfg.MODE_NIS_SHARP -> "AuraSharp"
        Cfg.MODE_NIS_ORIG -> "NIS"
        Cfg.MODE_NIS_FAST -> "NISFast"
        Cfg.MODE_NIS_FINE -> "NISFastClean"
        Cfg.MODE_NIS_MID -> "NISFastMid"
        Cfg.MODE_FAST -> "Fast"
        Cfg.MODE_SHARP -> "Sharp"
        else -> "Raw"
    }

    fun tierName(tier: Int): String = when (tier) {
        0 -> "Fast"
        1 -> "Balanced"
        3 -> "Max"
        4 -> "NoFx"
        else -> "Best"
    }

    /** Settings of the live picture as short specs: upscaler and sharpness. */
    fun liveSpecs(): List<String> {
        val l = ArrayList<String>()
        l.add(modeName(Cfg.mode))
        if (Cfg.sharp > 0f) l.add("s" + Math.round(Cfg.sharp * 100))
        if (Cfg.vivid > 0f) l.add("vivid")
        return l
    }
}
