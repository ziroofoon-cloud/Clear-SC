package app.clearoverlay;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

/** The phone's own files (needs "all files access" for the whole storage). */
public final class LocalFs implements FmFs {
    private final String root;

    public LocalFs(String root) {
        String r = root.length() > 1 && root.endsWith("/") ? root.substring(0, root.length() - 1) : root;
        this.root = r;
    }

    @Override public String root() { return root; }

    @Override public String parent(String path) {
        if (path.equals(root) || path.equals("/")) return null;
        String p = new File(path).getParent();
        if (p == null) return null;
        // never go above the root this storage was opened with
        if (!p.equals(root) && !p.startsWith(root + "/") && !root.equals("/")) return null;
        return p;
    }

    @Override public String join(String dir, String name) { return dir.endsWith("/") ? dir + name : dir + "/" + name; }

    @Override public List<FmItem> list(String dir) throws IOException {
        File[] a = new File(dir).listFiles();
        if (a == null) throw new IOException("cannot read " + dir);
        List<FmItem> r = new ArrayList<>(a.length);
        for (File f : a) {
            boolean d = f.isDirectory();
            r.add(new FmItem(f.getName(), d, d ? -1 : f.length(), f.lastModified()));
        }
        return r;
    }

    @Override public InputStream open(String path) throws IOException { return new FileInputStream(path); }

    @Override public OutputStream create(String path, long size) throws IOException {
        return new FileOutputStream(path);
    }

    @Override public void mkdir(String path) throws IOException {
        File f = new File(path);
        if (f.isDirectory()) return;
        if (!f.mkdirs()) throw new IOException("cannot create " + path);
    }

    @Override public void delete(String path) throws IOException {
        File f = new File(path);
        if (!f.exists() && !Files.isSymbolicLink(f.toPath())) return;
        deleteTree(f);
    }

    private static void deleteTree(File f) throws IOException {
        // a link to a folder is removed as a link, its target is left alone
        if (f.isDirectory() && !Files.isSymbolicLink(f.toPath())) {
            File[] a = f.listFiles();
            if (a != null) for (File c : a) deleteTree(c);
        }
        if (!f.delete() && (f.exists() || Files.isSymbolicLink(f.toPath()))) throw new IOException("cannot delete " + f.getPath());
    }

    @Override public void rename(String path, String newName) throws IOException {
        File f = new File(path);
        File t = new File(f.getParentFile(), newName);
        if (t.exists()) throw new IOException("already exists: " + newName);
        if (!f.renameTo(t)) throw new IOException("cannot rename " + f.getName());
    }

    @Override public boolean moveWithin(String from, String to) throws IOException {
        File t = new File(to);
        if (t.exists()) return false;
        return new File(from).renameTo(t);
    }

    @Override public boolean exists(String path) { File f = new File(path); return f.exists() || Files.isSymbolicLink(f.toPath()); }

    @Override public File localFile(String path) { return new File(path); }

    @Override public long freeSpace() { return new File(root).getUsableSpace(); }

    @Override public void close() { }
}
