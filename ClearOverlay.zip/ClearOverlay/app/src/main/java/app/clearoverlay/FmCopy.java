package app.clearoverlay;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

/** Copies, moves and deletes files and folders between any two storages, with progress and cancel. */
public final class FmCopy {
    public static final int RENAME = 0;     // keep both: the new one gets "name (1)"
    public static final int OVERWRITE = 1;  // replace files with the same name (folders are merged)
    public static final int SKIP = 2;       // leave the existing ones alone

    public interface Listener {
        /** [done] bytes copied so far in this job; [name] the file being copied. */
        void progress(long done, String name);

        boolean cancelled();
    }

    public static final class Cancelled extends IOException {
        public Cancelled() { super("cancelled"); }
    }

    private final Listener l;
    private final int policy;
    private long done;
    private final byte[] buf = new byte[64 * 1024];

    public FmCopy(Listener l, int policy) {
        this.l = l;
        this.policy = policy;
    }

    public long done() { return done; }

    public static String baseName(String path) {
        String p = path;
        while (p.length() > 1 && p.endsWith("/")) p = p.substring(0, p.length() - 1);
        return p.substring(p.lastIndexOf('/') + 1);
    }

    /** "name.ext" -> "name (1).ext", "name (2).ext", ... the first one that is free in [dir]. */
    public static String uniqueName(FmFs fs, String dir, String name) throws IOException {
        if (!fs.exists(fs.join(dir, name))) return name;
        int dot = name.lastIndexOf('.');
        String stem = dot > 0 ? name.substring(0, dot) : name;
        String ext = dot > 0 ? name.substring(dot) : "";
        for (int i = 1; i < 10000; i++) {
            String n = stem + " (" + i + ")" + ext;
            if (!fs.exists(fs.join(dir, n))) return n;
        }
        throw new IOException("no free name for " + name);
    }

    /** Total bytes of a file or folder tree (for the progress bar). Unknown sizes count as 0. */
    public static long totalSize(FmFs fs, String path, boolean dir, long known) {
        if (!dir) return Math.max(0, known);
        long t = 0;
        try {
            for (FmItem it : fs.list(path)) {
                if (it.dir && it.link) continue; // a linked folder is not walked into (a link back to a parent would never end)
                t += totalSize(fs, fs.join(path, it.name), it.dir, it.size);
            }
        } catch (IOException ignored) { }
        return t;
    }

    private void check() throws IOException {
        if (l != null && l.cancelled()) throw new Cancelled();
    }

    /** True when [dst] (a folder path) is [src] itself or inside it, on the same storage. */
    public static boolean intoItself(FmFs src, String srcPath, FmFs dst, String dstDir) {
        if (src != dst) return false;
        String a = srcPath.endsWith("/") ? srcPath : srcPath + "/";
        String b = dstDir.endsWith("/") ? dstDir : dstDir + "/";
        return b.equals(a) || b.startsWith(a);
    }

    /** Copies [srcPath] into the folder [dstDir]. */
    public void copy(FmFs src, String srcPath, boolean dir, long size, FmFs dst, String dstDir) throws IOException {
        check();
        if (intoItself(src, srcPath, dst, dstDir)) throw new IOException("a folder cannot be copied into itself");
        String name = baseName(srcPath);
        String target = dst.join(dstDir, name);
        boolean exists = dst.exists(target);
        if (exists) {
            if (policy == SKIP && !dir) return;
            if (policy == RENAME) {
                name = uniqueName(dst, dstDir, name);
                target = dst.join(dstDir, name);
                exists = false;
            }
        }
        if (dir) {
            if (!exists) dst.mkdir(target);
            List<FmItem> kids = src.list(srcPath);
            for (FmItem it : kids) {
                if (it.dir && it.link) continue; // a linked folder is left out, not followed
                copy(src, src.join(srcPath, it.name), it.dir, it.size, dst, target);
            }
        } else {
            copyFile(src, srcPath, size, dst, target);
        }
    }

    private void copyFile(FmFs src, String from, long size, FmFs dst, String to) throws IOException {
        InputStream in = src.open(from);
        OutputStream out = null;
        boolean ok = false;
        try {
            out = dst.create(to, size);
            String nm = baseName(from);
            int n;
            while ((n = in.read(buf)) > 0) {
                check();
                out.write(buf, 0, n);
                done += n;
                if (l != null) l.progress(done, nm);
            }
            out.close(); // for storages that upload at this point it can still fail
            ok = true;
        } finally {
            try { in.close(); } catch (IOException ignored) { }
            if (!ok && out != null) {
                if (out instanceof FmAbortable) ((FmAbortable) out).abort();
                else {
                    try { out.close(); } catch (IOException ignored) { }
                    try { dst.delete(to); } catch (IOException ignored) { } // no half file left behind
                }
            }
        }
    }

    /** Moves [srcPath] into the folder [dstDir]: a rename where the storage can do that, otherwise copy and then delete. */
    public void move(FmFs src, String srcPath, boolean dir, long size, FmFs dst, String dstDir) throws IOException {
        check();
        if (intoItself(src, srcPath, dst, dstDir)) throw new IOException("a folder cannot be moved into itself");
        String name = baseName(srcPath);
        String target = dst.join(dstDir, name);
        if (src == dst) {
            if (src.parent(srcPath) != null && src.parent(srcPath).equals(dstDir)) return; // already there
            boolean exists = dst.exists(target);
            if (exists && policy == SKIP) return;
            if (exists && policy == RENAME) {
                name = uniqueName(dst, dstDir, name);
                target = dst.join(dstDir, name);
                exists = false;
            }
            if (!exists || (policy == OVERWRITE && !dir)) {
                if (exists) dst.delete(target);
                if (src.moveWithin(srcPath, target)) return;
            }
        }
        copy(src, srcPath, dir, size, dst, dstDir);
        check();
        src.delete(srcPath);
    }
}
