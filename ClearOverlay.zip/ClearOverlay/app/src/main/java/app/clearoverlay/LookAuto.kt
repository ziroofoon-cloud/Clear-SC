package app.clearoverlay

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever

/**
 * "Auto" for the Picture look of a file export: looks at a few frames spread over the video and picks the look settings that this picture needs
 * (dark -> lift the shadows, flat -> contrast, pale -> saturation, soft -> clarity, torn lines of an old interlaced video -> deinterlace, black bars -> cut).
 * The answer is kept in the job folder (look.txt), so a continued job gets the same look. Only the middle of the picture is measured (bars and
 * subtitles do not count). The choices are mild on purpose: Auto should never make a good picture worse.
 */
object LookAuto {
    private const val W = 640
    private const val H = 360
    private const val SAMPLES = 7

    private class Stat(val mean: Float, val p5: Float, val p95: Float, val clip: Float, val sat: Float, val sharp: Float, val comb: Float)

    /** [setup] points the retriever at the video. Blocking (a few seconds): call it from a worker thread. */
    fun analyze(startUs: Long, endUs: Long, setup: (MediaMetadataRetriever) -> Unit): Look {
        val out = Look(cutBars = true)
        if (endUs <= startUs) return out
        val mr = MediaMetadataRetriever()
        try {
            setup(mr)
            val srcH = runCatching { mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toInt() }.getOrNull() ?: 0
            val srcW = runCatching { mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toInt() }.getOrNull() ?: 0
            val stats = ArrayList<Stat>()
            for (i in 0 until SAMPLES) {
                val t = startUs + (endUs - startUs) * (2 * i + 1) / (2L * SAMPLES)
                val raw = runCatching { mr.getScaledFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, W, H) }.getOrNull() ?: continue
                val bmp = if (raw.width != W || raw.height != H) Bitmap.createScaledBitmap(raw, W, H, true) else raw
                val s = measure(bmp)
                if (bmp !== raw) bmp.recycle()
                raw.recycle()
                if (s != null) stats.add(s)
            }
            if (stats.size < 3) return out
            fun med(f: (Stat) -> Float): Float = stats.map(f).sorted()[stats.size / 2]
            val mean = med { it.mean }
            val range = med { it.p95 } - med { it.p5 }
            val clip = med { it.clip }
            val sat = med { it.sat }
            val sharp = med { it.sharp }
            val comb = med { it.comb }
            fun r2(v: Float) = Math.round(v * 100f) / 100f
            if (mean < 0.30f) out.shadows = r2(((0.34f - mean) * 2.2f).coerceIn(0f, 0.55f))
            if (clip > 0.03f) out.highlights = r2(-(clip * 6f).coerceIn(0f, 0.4f))
            if (range < 0.55f) out.contrast = r2(((0.62f - range)).coerceIn(0f, 0.35f))
            if (sat < 0.22f) out.saturation = r2(((0.26f - sat) * 1.6f).coerceIn(0f, 0.3f))
            else if (sat > 0.55f) out.saturation = -0.1f
            // the scaled copy only keeps the lines of a picture that is not much taller than it: judge the comb teeth of an SD picture only
            if (comb > 0.05f && srcH in 1..600 && srcW > 0) out.deint = 1
            out.clarity = if (sharp < 0.025f) 0.25f else if (sharp < 0.04f) 0.12f else 0f
            out.antiRing = if (out.clarity > 0f) 0.3f else 0f
        } catch (t: Throwable) {
            // nothing measured: only the black bars are cut
        } finally {
            runCatching { mr.release() }
        }
        return out
    }

    /** Numbers of the middle part of one frame; null for a (nearly) black frame, which says nothing. */
    private fun measure(bmp: Bitmap): Stat? {
        val px = IntArray(W * H)
        bmp.getPixels(px, 0, W, 0, 0, W, H)
        val x0 = W / 10
        val x1 = W - W / 10
        val y0 = H * 15 / 100
        val y1 = H - H * 15 / 100
        val luma = FloatArray(W * H)
        for (i in px.indices) {
            val c = px[i]
            luma[i] = (((c shr 16) and 0xFF) * 0.299f + ((c shr 8) and 0xFF) * 0.587f + (c and 0xFF) * 0.114f) / 255f
        }
        val hist = IntArray(256)
        var n = 0
        var sum = 0.0
        var clip = 0
        var satSum = 0.0
        var satN = 0
        var grad = 0.0
        var comb = 0
        var combN = 0
        for (y in y0 until y1) {
            for (x in x0 until x1) {
                val l = luma[y * W + x]
                hist[(l * 255f).toInt().coerceIn(0, 255)]++
                n++
                sum += l
                if (l > 0.98f) clip++
                val c = px[y * W + x]
                val r = (c shr 16) and 0xFF
                val g = (c shr 8) and 0xFF
                val b = c and 0xFF
                val mx = maxOf(r, maxOf(g, b))
                val mn = minOf(r, minOf(g, b))
                if (l in 0.1f..0.9f) {
                    satSum += (mx - mn).toDouble() / maxOf(mx, 1)
                    satN++
                }
                grad += Math.abs(luma[y * W + x + 1] - l).toDouble()
                // comb: this row differs from both neighbours in the same direction and the neighbours are alike
                val up = luma[(y - 1) * W + x]
                val dn = luma[(y + 1) * W + x]
                combN++
                if ((l - up) * (l - dn) > 0.0016f && Math.abs(up - dn) < 0.04f) comb++
            }
        }
        if (n == 0 || sum / n < 0.02) return null
        fun pct(p: Float): Float {
            val target = (n * p).toInt()
            var acc = 0
            for (i in 0 until 256) {
                acc += hist[i]
                if (acc >= target) return i / 255f
            }
            return 1f
        }
        return Stat((sum / n).toFloat(), pct(0.05f), pct(0.95f), clip.toFloat() / n, if (satN > 0) (satSum / satN).toFloat() else 0.3f, (grad / n).toFloat(), if (combN > 0) comb.toFloat() / combN else 0f)
    }
}
