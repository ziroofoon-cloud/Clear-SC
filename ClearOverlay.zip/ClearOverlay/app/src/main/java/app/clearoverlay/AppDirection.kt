package app.clearoverlay

import android.app.Activity
import android.app.Application
import android.content.Context
import android.content.pm.ActivityInfo
import android.os.Bundle

/**
 * The screen direction of the whole app (Library, file manager, settings, editors ... everything except the player and the manga reader,
 * which have their own direction choice): [Cfg.appDir] 0 = follow the phone, 1 = portrait, 2 = landscape. It is set on every screen when it
 * opens and again when it comes back, so a direction left over from another screen (the player's) can never stay.
 */
object AppDirection {
    private var installed = false

    /** Starts watching the screens of the app (once). */
    fun install(ctx: Context) {
        if (installed) return
        val app = ctx.applicationContext as? Application ?: return
        installed = true
        app.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
            override fun onActivityCreated(a: Activity, b: Bundle?) { apply(a) }
            override fun onActivityStarted(a: Activity) {}
            override fun onActivityResumed(a: Activity) { apply(a) }
            override fun onActivityPaused(a: Activity) {}
            override fun onActivityStopped(a: Activity) {}
            override fun onActivitySaveInstanceState(a: Activity, b: Bundle) {}
            override fun onActivityDestroyed(a: Activity) {}
        })
    }

    /** Asks [a] for the chosen direction (only screens of this app; the player and the manga reader decide for themselves). */
    fun apply(a: Activity) {
        if (!a.javaClass.name.startsWith("app.clearoverlay.")) return
        if (a is PlayerActivity || a is MangaActivity) return
        val want = when (Cfg.appDir) {
            1 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            2 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        if (a.requestedOrientation != want) a.requestedOrientation = want
    }
}
