package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.IOException
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Network browser: add a server (SMB share or FTP), browse its folders, and open videos (streamed), photos, GIFs and
 * manga (.cbz / .zip / .pdf, or a whole image folder) with the app's own player / reader.
 */
class NetActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var titleTv: TextView
    private lateinit var msg: TextView
    private lateinit var list: ListView
    private lateinit var readBtn: View
    private lateinit var refreshBtn: View
    private lateinit var scanBtn: View

    private var server: Net.Server? = null
    private var path = "/"
    private var entries: List<Net.Entry> = emptyList()
    private var servers: List<Net.Server> = emptyList()
    private var gen = 0
    private var loading = false

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Cfg.bind(this, "screen")
        Ui.init(this)
        setTheme(Ui.theme())
        super.onCreate(savedInstanceState)
        Ui.styleBars(window)
        Thread { Net.cleanCache(this) }.start()

        val pad = dp(this, 12)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
        }
        val head = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(pad, dp(this@NetActivity, 10), pad, dp(this@NetActivity, 6))
        }
        titleTv = Ui.text(this, getString(R.string.net_title), 22f, Ui.TEXT, true).apply {
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.START
            setOnClickListener { goBack() }
        }
        head.addView(titleTv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        readBtn = Icons.button(this, Icons.BOOK) { readFolderAsManga() }
        head.addView(readBtn)
        refreshBtn = Icons.button(this, Icons.REFRESH) { reload() }
        head.addView(refreshBtn)
        scanBtn = Icons.button(this, Icons.SEARCH) { scanNetwork() }
        head.addView(scanBtn)
        head.addView(Icons.button(this, Icons.FOLDER_PLUS) { editServer(null) })
        root.addView(head)

        msg = Ui.text(this, "", 14f, Ui.MUTED).apply {
            gravity = Gravity.CENTER
            setPadding(pad * 2, pad, pad * 2, pad)
            visibility = View.GONE
        }
        root.addView(msg)

        list = ListView(this).apply {
            divider = android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT)
            dividerHeight = dp(this@NetActivity, 8)
            setPadding(pad, 0, pad, pad)
            clipToPadding = false
            selector = Ui.round(android.graphics.Color.TRANSPARENT, 0f)
            isVerticalScrollBarEnabled = false
        }
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ -> onRow(pos) }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            if (server == null) servers.getOrNull(pos)?.let { serverMenu(it) }
            true
        }
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        showServers()
    }

    // ---- screens --------------------------------------------------------------------------------

    private fun showServers() {
        gen++
        server = null
        loading = false
        servers = Net.servers(this)
        titleTv.text = getString(R.string.net_title)
        readBtn.visibility = View.GONE
        refreshBtn.visibility = View.GONE
        scanBtn.visibility = View.VISIBLE
        msg.text = getString(R.string.net_empty)
        msg.visibility = if (servers.isEmpty()) View.VISIBLE else View.GONE
        adapter.notifyDataSetChanged()
        list.setSelection(0)
    }

    private fun openServer(s: Net.Server) {
        server = s
        path = Net.lastPath(this, s.id) ?: s.path.ifEmpty { "/" }
        reload()
    }

    private fun reload() {
        val s = server ?: return
        val mine = ++gen
        loading = true
        titleTv.text = s.name + "  " + path
        readBtn.visibility = View.GONE
        refreshBtn.visibility = View.VISIBLE
        scanBtn.visibility = View.GONE
        entries = emptyList()
        adapter.notifyDataSetChanged()
        msg.text = getString(R.string.net_connecting)
        msg.visibility = View.VISIBLE
        val p = path
        Thread {
            var err: String? = null
            var res: List<Net.Entry> = emptyList()
            try {
                val c = Net.connect(s)
                try {
                    res = c.list(p)
                } finally {
                    runCatching { c.close() }
                }
            } catch (t: Throwable) {
                err = t.message ?: t.javaClass.simpleName
            }
            val sorted = res.sortedWith { a, b ->
                if (a.isDir != b.isDir) (if (a.isDir) -1 else 1) else Media.natural(a.name, b.name)
            }
            ui.post {
                if (isDestroyed || mine != gen) return@post
                loading = false
                if (err != null) {
                    val start = s.path.ifEmpty { "/" }
                    if (p != start) Net.setLastPath(this, s.id, start) // do not come back to a folder that fails
                    msg.text = getString(R.string.net_error_fmt, err)
                    msg.visibility = View.VISIBLE
                    return@post
                }
                entries = sorted
                Net.setLastPath(this, s.id, p)
                msg.text = getString(R.string.net_folder_empty)
                msg.visibility = if (sorted.isEmpty()) View.VISIBLE else View.GONE
                readBtn.visibility = if (sorted.any { !it.isDir && Net.isImage(it.name) }) View.VISIBLE else View.GONE
                adapter.notifyDataSetChanged()
                list.setSelection(0)
            }
        }.start()
    }

    private fun goBack(): Boolean {
        val s = server ?: return false
        val root = s.path.ifEmpty { "/" }.trimEnd('/')
        if (path.trimEnd('/') == root || path == "/") {
            showServers()
        } else {
            path = Net.parent(path)
            reload()
        }
        return true
    }

    override fun onBackPressed() {
        if (!goBack()) {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        gen++
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    // ---- taps -----------------------------------------------------------------------------------

    private fun onRow(pos: Int) {
        val s = server
        if (s == null) {
            servers.getOrNull(pos)?.let { openServer(it) }
            return
        }
        if (loading) return
        val e = entries.getOrNull(pos) ?: return
        val full = Net.join(path, e.name)
        when {
            e.isDir -> {
                path = full
                reload()
            }
            Net.isVideo(e.name) -> playList(s, e) { Net.isVideo(it.name) }
            Net.isImage(e.name) -> playList(s, e) { Net.isImage(it.name) }
            Net.isGif(e.name) -> openGif(s, full)
            Net.isAudio(e.name) -> playAudio(s, e)
            Net.isManga(e.name) -> {
                // the reader recognises zip / rar / 7z / pdf by the start of the file, so every comic type opens the same way
                startActivity(
                    Intent(this, MangaActivity::class.java)
                        .setData(Net.uriOf(s, full))
                        .putExtra(MangaActivity.EXTRA_NAME, e.name.substringBeforeLast('.'))
                )
            }
            else -> Toast.makeText(this, R.string.net_unsupported, Toast.LENGTH_SHORT).show()
        }
    }

    /** Opens [e] in the player with the other files of the same kind in this folder as the playlist. */
    private fun playList(s: Net.Server, e: Net.Entry, same: (Net.Entry) -> Boolean) {
        val items = entries.filter { !it.isDir && same(it) }
        val uris = items.map { Net.uriOf(s, Net.join(path, it.name)) }
        val idx = items.indexOfFirst { it.name == e.name }.coerceAtLeast(0)
        val i = Intent(this, PlayerActivity::class.java).setData(uris[idx]).putExtra(PlayerArgs.FROM_LIB, true)
        if (uris.size > 1) {
            i.putExtra(PlayerArgs.INDEX, idx)
            i.putStringArrayListExtra(PlayerArgs.LIST, ArrayList(uris.map { it.toString() }))
        }
        startActivity(i)
    }

    /** Plays [e] in the music player with the other songs of this folder as the queue (streamed, nothing is saved). */
    private fun playAudio(s: Net.Server, e: Net.Entry) {
        val items = entries.filter { !it.isDir && Net.isAudio(it.name) }
        val tracks = items.map { MusicPlayer.Track(Net.uriOf(s, Net.join(path, it.name)), it.name.substringBeforeLast('.'), s.name, 0L) }
        val idx = items.indexOfFirst { it.name == e.name }.coerceAtLeast(0)
        if (tracks.isEmpty()) return
        MusicPlayer.handoff = tracks
        MusicPlayer.play(this, tracks, idx)
        startActivity(Intent(this, AudioActivity::class.java))
    }

    private fun openGif(s: Net.Server, full: String) {
        val u = Net.uriOf(s, full)
        runWithProgress(getString(R.string.net_downloading)) { setText, cancel ->
            val f = Net.download(this, u, { done, total -> setText(sizeText(done, total)) }, { !cancel.get() })
            ui.post { startActivity(Intent(this, GifActivity::class.java).setData(Uri.fromFile(f))) }
        }
    }

    /** All images of this folder, packed into one .cbz in the cache, then opened in the manga reader. */
    private fun readFolderAsManga() {
        val s = server ?: return
        val imgs = entries.filter { !it.isDir && Net.isImage(it.name) }.take(600)
        if (imgs.isEmpty()) {
            Toast.makeText(this, R.string.net_no_images, Toast.LENGTH_SHORT).show()
            return
        }
        val dir = path
        val title = dir.trimEnd('/').substringAfterLast('/').ifEmpty { s.name }
        runWithProgress(getString(R.string.net_downloading)) { setText, cancel ->
            val out = File(Net.cacheDir(this), "folder_" + Integer.toHexString((s.id + dir).hashCode()) + ".cbz")
            val c = Net.connect(s)
            try {
                ZipOutputStream(out.outputStream().buffered()).use { zos ->
                    zos.setLevel(Deflater.NO_COMPRESSION) // images are already compressed
                    imgs.forEachIndexed { i, e ->
                        if (cancel.get()) throw IOException("cancelled")
                        setText("${i + 1} / ${imgs.size}")
                        zos.putNextEntry(ZipEntry(String.format("%04d_%s", i, e.name)))
                        c.open(Net.join(dir, e.name), 0).use { it.copyTo(zos) }
                        zos.closeEntry()
                    }
                }
            } catch (t: Throwable) {
                out.delete()
                throw t
            } finally {
                runCatching { c.close() }
            }
            ui.post {
                startActivity(
                    Intent(this, MangaActivity::class.java)
                        .setData(Uri.fromFile(out))
                        .putExtra(MangaActivity.EXTRA_NAME, title)
                )
            }
        }
    }

    /** Runs [work] on a background thread under a small "downloading" dialog with a cancel button. */
    private fun runWithProgress(title: String, work: (setText: (String) -> Unit, cancel: AtomicBoolean) -> Unit) {
        val cancel = AtomicBoolean(false)
        val tv = Ui.text(this, "…", 14f, Ui.TEXT).apply { setPadding(dp(this@NetActivity, 22), dp(this@NetActivity, 8), dp(this@NetActivity, 22), 0) }
        val dlg = AlertDialog.Builder(this)
            .setTitle(title)
            .setView(tv)
            .setCancelable(false)
            .setNegativeButton(android.R.string.cancel) { _, _ -> cancel.set(true) }
            .create()
        dlg.show()
        Thread {
            var err: String? = null
            try {
                work({ t -> ui.post { tv.text = t } }, cancel)
            } catch (t: Throwable) {
                err = if (cancel.get()) null else (t.message ?: t.javaClass.simpleName)
            }
            ui.post {
                if (!isDestroyed) runCatching { dlg.dismiss() }
                if (err != null && !isDestroyed) {
                    AlertDialog.Builder(this).setMessage(getString(R.string.net_error_fmt, err)).setPositiveButton(android.R.string.ok, null).show()
                }
            }
        }.start()
    }

    private fun sizeText(done: Long, total: Long): String =
        if (total > 0) "${fmtSize(done)} / ${fmtSize(total)}  (${(done * 100 / total).toInt()}%)" else fmtSize(done)

    private fun fmtSize(b: Long): String = when {
        b >= 1L shl 30 -> String.format("%.2f GB", b / 1073741824.0)
        b >= 1L shl 20 -> String.format("%.1f MB", b / 1048576.0)
        b >= 1L shl 10 -> String.format("%d KB", b shr 10)
        else -> "$b B"
    }

    // ---- server editor --------------------------------------------------------------------------

    private fun serverMenu(s: Net.Server) {
        AlertDialog.Builder(this)
            .setTitle(s.name)
            .setItems(arrayOf(getString(R.string.net_edit), getString(R.string.net_delete))) { _, w ->
                if (w == 0) editServer(s) else {
                    Net.remove(this, s.id)
                    showServers()
                }
            }
            .show()
    }

    /** Finds SMB / FTP servers on the phone's network; picking one opens the add-server form with its address filled in. */
    private fun scanNetwork() {
        runWithProgress(getString(R.string.net_scanning)) { setText, cancel ->
            val res = Net.scan({ cancel.get() }) { d, t -> setText("$d / $t") }
            if (cancel.get()) return@runWithProgress
            ui.post {
                if (isDestroyed) return@post
                if (res.isEmpty()) {
                    AlertDialog.Builder(this).setMessage(R.string.net_scan_none).setPositiveButton(android.R.string.ok, null).show()
                } else {
                    val saved = Net.servers(this).map { it.host }.toSet()
                    val labels = res.map { f ->
                        val who = if (f.name.isNotEmpty()) f.name + " · " + f.host else f.host
                        (if (f.host in saved) "✓ " else "") +
                            getString(R.string.net_found_fmt, who, listOfNotNull(if (f.smb) "SMB" else null, if (f.ftp) "FTP" else null).joinToString(" + "))
                    }.toTypedArray()
                    AlertDialog.Builder(this)
                        .setTitle(R.string.net_scan)
                        .setItems(labels) { _, w -> res.getOrNull(w)?.let { editServer(null, it.host, if (it.smb) Net.SMB else Net.FTP, it.name) } }
                        .setNegativeButton(android.R.string.cancel, null)
                        .show()
                }
            }
        }
    }

    private fun editServer(old: Net.Server?, preHost: String = "", preProto: String = Net.SMB, preName: String = "") {
        val pad = dp(this, 20)
        fun field(hint: String, value: String, pw: Boolean = false, number: Boolean = false) = EditText(this).apply {
            setSingleLine()
            this.hint = hint
            setText(value)
            if (pw) inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            if (number) inputType = android.text.InputType.TYPE_CLASS_NUMBER
            if (!pw && !number) inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, dp(this@NetActivity, 8), pad, 0)
        }
        val name = field(getString(R.string.net_name), old?.name ?: preName)
        val group = RadioGroup(this).apply { orientation = LinearLayout.HORIZONTAL }
        val rSmb = RadioButton(this).apply { text = getString(R.string.net_proto_smb); id = View.generateViewId() }
        val rFtp = RadioButton(this).apply { text = getString(R.string.net_proto_ftp); id = View.generateViewId() }
        group.addView(rSmb)
        group.addView(rFtp)
        if ((old?.proto ?: preProto) == Net.FTP) rFtp.isChecked = true else rSmb.isChecked = true
        val host = field(getString(R.string.net_host), old?.host ?: preHost)
        val port = field(getString(R.string.net_port), if (old != null && old.port > 0) old.port.toString() else "", number = true)
        val user = field(getString(R.string.net_user), old?.user ?: "")
        val pass = field(getString(R.string.net_pass), old?.pass ?: "", pw = true)
        val share = field(getString(R.string.net_share), old?.share ?: "")
        val startPath = field(getString(R.string.net_path), if (old != null) old.path else "/")
        val listBtn = Ui.text(this, getString(R.string.net_list_shares), 14f, Ui.ACCENT, true).apply {
            setPadding(0, dp(this@NetActivity, 8), 0, dp(this@NetActivity, 8))
        }
        for (v in listOf(name, group, host, port, user, pass, share, listBtn, startPath)) box.addView(v)
        rFtp.setOnCheckedChangeListener { _, on ->
            share.visibility = if (on) View.GONE else View.VISIBLE
            listBtn.visibility = share.visibility
        }
        share.visibility = if (rFtp.isChecked) View.GONE else View.VISIBLE
        listBtn.visibility = share.visibility
        listBtn.setOnClickListener {
            val h = host.text.toString().trim()
            if (h.isEmpty()) { toast(R.string.net_need_host); return@setOnClickListener }
            val tmp = Net.Server("", "", Net.SMB, h, port.text.toString().toIntOrNull() ?: 0, user.text.toString().trim(), pass.text.toString(), "", "/")
            listBtn.isEnabled = false
            Thread {
                var err: String? = null
                var names: List<String> = emptyList()
                try {
                    names = Net.listShares(tmp)
                } catch (t: Throwable) {
                    err = (t.cause ?: t).message ?: t.javaClass.simpleName
                }
                val e = err
                val found = names
                ui.post {
                    listBtn.isEnabled = true
                    if (isDestroyed) return@post
                    if (e != null || found.isEmpty()) {
                        AlertDialog.Builder(this).setMessage(getString(R.string.net_shares_fail, e ?: "")).setPositiveButton(android.R.string.ok, null).show()
                    } else {
                        AlertDialog.Builder(this).setTitle(R.string.net_list_shares)
                            .setItems(found.toTypedArray()) { _, w -> share.setText(found[w]) }
                            .setNegativeButton(android.R.string.cancel, null).show()
                    }
                }
            }.start()
        }
        val sv = ScrollView(this).apply { addView(box) }

        val dlg = AlertDialog.Builder(this)
            .setTitle(getString(if (old == null) R.string.net_add else R.string.net_edit))
            .setView(sv)
            .setPositiveButton(R.string.net_save, null)
            .setNegativeButton(android.R.string.cancel, null)
            .create()
        dlg.show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val proto = if (rFtp.isChecked) Net.FTP else Net.SMB
            val h = host.text.toString().trim()
            val sh = share.text.toString().trim().trim('/', '\\')
            if (h.isEmpty()) { toast(R.string.net_need_host); return@setOnClickListener }
            if (proto == Net.SMB && sh.isEmpty()) { toast(R.string.net_need_share); return@setOnClickListener }
            var sp = startPath.text.toString().trim().replace('\\', '/')
            if (!sp.startsWith("/")) sp = "/$sp"
            val n = name.text.toString().trim().ifEmpty { h }
            val s = Net.Server(
                old?.id ?: Net.newId(), n, proto, h, port.text.toString().toIntOrNull() ?: 0,
                user.text.toString().trim(), pass.text.toString(), sh, sp
            )
            Net.put(this, s)
            dlg.dismiss()
            showServers()
        }
    }

    private fun toast(r: Int) = Toast.makeText(this, r, Toast.LENGTH_SHORT).show()

    // ---- list adapter ---------------------------------------------------------------------------

    private val adapter = object : BaseAdapter() {
        override fun getCount(): Int = if (server == null) servers.size else entries.size
        override fun getItem(position: Int): Any = position
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = (convertView as? LinearLayout) ?: LinearLayout(this@NetActivity).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(this@NetActivity, 12), dp(this@NetActivity, 12), dp(this@NetActivity, 12), dp(this@NetActivity, 12))
                background = Ui.round(Ui.CARD, dp(this@NetActivity, 12).toFloat())
                layoutParams = AbsListViewParams()
                val ic = Ui.text(this@NetActivity, "", 22f, Ui.TEXT).apply { gravity = Gravity.CENTER }
                addView(ic, LinearLayout.LayoutParams(dp(this@NetActivity, 36), ViewGroup.LayoutParams.WRAP_CONTENT))
                val col = LinearLayout(this@NetActivity).apply { orientation = LinearLayout.VERTICAL }
                col.addView(Ui.text(this@NetActivity, "", 15f, Ui.TEXT).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE })
                col.addView(Ui.text(this@NetActivity, "", 12f, Ui.MUTED))
                addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            }
            val ic = row.getChildAt(0) as TextView
            val col = row.getChildAt(1) as LinearLayout
            val t1 = col.getChildAt(0) as TextView
            val t2 = col.getChildAt(1) as TextView
            val s = server
            if (s == null) {
                val v = servers[position]
                Icons.glyph(ic, if (v.proto == Net.SMB) Icons.SERVER else Icons.GLOBE, Ui.ACCENT, 26)
                t1.text = v.name
                t2.text = (if (v.proto == Net.SMB) "SMB  " else "FTP  ") + v.host + (if (v.proto == Net.SMB && v.share.isNotEmpty()) "/" + v.share else "")
                t2.visibility = View.VISIBLE
                t1.setTextColor(Ui.TEXT)
            } else {
                val e = entries[position]
                Icons.glyph(ic, when {
                    e.isDir -> Icons.FOLDER
                    Net.isVideo(e.name) -> Icons.FILM
                    Net.isImage(e.name) || Net.isGif(e.name) -> Icons.IMAGE
                    Net.isManga(e.name) -> Icons.BOOK
                    Net.isAudio(e.name) -> Icons.MUSIC
                    else -> Icons.FILE
                }, Ui.ACCENT, 26)
                t1.text = e.name
                val playable = e.isDir || Net.isVideo(e.name) || Net.isImage(e.name) || Net.isGif(e.name) || Net.isManga(e.name) || Net.isAudio(e.name)
                t1.setTextColor(if (playable) Ui.TEXT else Ui.MUTED)
                t2.text = if (e.isDir) "" else fmtSize(e.size)
                t2.visibility = if (e.isDir) View.GONE else View.VISIBLE
            }
            return row
        }
    }

    @Suppress("FunctionName")
    private fun AbsListViewParams() = android.widget.AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
}
