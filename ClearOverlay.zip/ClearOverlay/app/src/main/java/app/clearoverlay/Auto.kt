package app.clearoverlay

import android.content.Context
import kotlin.math.abs
import kotlin.math.ceil

/**
 * "Auto": the app chooses the quick profile, strength, GPU budget, anti-aliasing, upscale mode, render scale and AI
 * model by itself, from what is on screen and from how hard the phone is working. The decisions are simple rules, not
 * machine learning, and are meant as good starting points: touching any control switches Auto off.
 *
 *  - Video (player): resolution, frame rate, bitrate and whether it is a stream pick the content type; the strength
 *    follows the enlargement; the budget starts from the pixel rate and drops when frames are dropped.
 *  - Photo (player): small or soft photos get stronger cleanup; photos always use the Quality budget (a single frame
 *    costs nothing); the AI model is chosen from the photo's size (small = best model, big = fastest one).
 *  - Screen overlay: the app underneath is unknown, so a light all-round profile is used and a "ladder" of settings is
 *    walked up and down from the measured time each frame takes: Fast 80% > Performance > Balanced > Quality.
 */
object Auto {
    /** [temporal]: 0 / 1 / 2 = the temporal clean-up Auto asks for (a heavily compressed video gets the light one when the GPU budget allows). */
    class Pick(val type: Int, val level: Int, val budget: Int, val why: String, val temporal: Int = 0, val canCrop: Boolean = false, val deint: Int = 0, val clean: Float = -1f)

    /** Video: [fps] and [bitrate] may be 0 / unknown. [ratio] = shown size / source size. */
    fun forVideo(srcW: Int, srcH: Int, fps: Float, bitrate: Int, isStream: Boolean, ratio: Float, codecMime: String = "", containerMime: String = ""): Pick {
        val h = minOf(srcW, srcH).coerceAtLeast(1)
        val longSide = maxOf(srcW, srcH)
        val type = when {
            isStream -> Profiles.STREAM
            h <= 576 || longSide <= 1024 -> Profiles.VIDEO
            else -> Profiles.MOVIE
        }
        // pixels per second the GPU must process: 1080p30 = 62 MP/s, 1080p60 = 124 MP/s, 4K30 = 249 MP/s
        val rate = srcW.toDouble() * srcH * (if (fps > 1f) fps else 30f)
        val budget = when {
            rate > 150e6 -> Profiles.PERF
            rate > 70e6 -> Profiles.BALANCED
            else -> Profiles.QUALITY // up to about 1080p30: the GPU can afford the best upscaler (CRSC Edge)
        }
        // bits per pixel: a video squeezed into very few bits shows blocks and shimmer that move from frame to frame; the light temporal
        // clean-up (the previous frame, moved along the motion, is blended in) calms it. Unknown bit rate (streams) = not asked for.
        val bpp = if (bitrate > 0) bitrate.toDouble() / rate else 1.0
        val temporal = if (bpp < 0.07 && budget >= Profiles.BALANCED && rate <= 150e6) 1 else 0
        // Clean upscale (denoise -> sharpen -> upscale): measured offline (4 pictures x 6 qualities, ground truth known) it clearly helps pictures that
        // are compressed hard or noisy (SSIM +0.03 .. +0.14) and slightly hurts clean ones (-0.005 .. -0.04: the denoise takes fine detail). So Auto
        // switches it on only for a video squeezed into few bits, stronger the fewer bits it has. HEVC / VP9 / AV1 need about 1.6x fewer bits for the same quality.
        val codec = codecMime.lowercase()
        val eff = bpp * (if (codec.contains("hevc") || codec.contains("av01") || codec.contains("vp9") || codec.contains("av1")) 1.6 else 1.0)
        // (negative = Auto does not decide: a stream or an unknown bit rate keeps the person's own choice; too little GPU budget turns it off)
        val clean = when {
            isStream || bitrate <= 0 -> -1f
            budget < Profiles.BALANCED || rate > 150e6 -> 0f
            eff < 0.035 -> 0.7f
            eff < 0.06 -> 0.5f
            eff < 0.09 -> 0.3f
            else -> 0f
        }
        // black bars are only cut on films and clips, not on game streams or recorded games
        return Pick(type, 3, budget, "", temporal, type == Profiles.VIDEO || type == Profiles.MOVIE, if (!isStream && likelyInterlaced(h, fps, codecMime, containerMime)) 1 else 0, clean)
    }

    /**
     * Interlaced sources (old TV recordings, DVD / broadcast .ts / .mpg files): MPEG-2 video, or a TV container with a TV size (480 / 576 / 1080 lines)
     * at about 25 / 30 frames per second. A guess: the deinterlacer only changes the lines where combing really shows, so a wrong guess costs a little GPU time.
     */
    fun likelyInterlaced(h: Int, fps: Float, codecMime: String, containerMime: String): Boolean {
        val codec = codecMime.lowercase()
        val box = containerMime.lowercase()
        if (codec.contains("mpeg2")) return true
        val tvBox = box.contains("mp2t") || box == "video/mpeg" || box.contains("mpeg-ps") || box.contains("mp2p")
        val tvSize = h == 480 || h == 576 || h == 1080
        val tvRate = fps <= 0f || (fps in 24.9f..30.1f)
        return tvBox && tvSize && tvRate
    }

    // ---- live content analysis (what kind of picture is it right now?) ---------------------------------------
    const val C_NORMAL = 0
    const val C_DARK = 1
    const val C_ANIME = 2
    const val C_SOFT = 3
    const val C_BUSY = 4

    /**
     * Simple statistics of the same tiny copy, for the live auto-tuning: [0] mean brightness, [1] brightness range (5 % .. 95 %),
     * [2] share of nearly white pixels, [3] colourfulness, [4] edge amount. All 0..1.
     */
    fun stats(px: IntArray, w: Int = 96, h: Int = 54): FloatArray {
        val n = w * h
        if (px.size < n) return floatArrayOf(0.4f, 0.6f, 0f, 0.2f, 0.05f)
        val lum = FloatArray(n)
        val hist = IntArray(64)
        var sum = 0.0
        var sat = 0.0
        var clipped = 0
        for (i in 0 until n) {
            val c = px[i]
            val r = (c shr 16) and 255
            val g = (c shr 8) and 255
            val b = c and 255
            val l = (0.299f * r + 0.587f * g + 0.114f * b) / 255f
            lum[i] = l
            sum += l
            if (l > 0.97f) clipped++
            sat += (maxOf(r, g, b) - minOf(r, g, b)) / 255.0
            hist[(l * 63f).toInt().coerceIn(0, 63)]++
        }
        var acc = 0
        var p5 = 0
        var p95 = 63
        var got5 = false
        for (i in 0 until 64) {
            acc += hist[i]
            if (!got5 && acc >= n * 0.05f) { p5 = i; got5 = true }
            if (acc >= n * 0.95f) { p95 = i; break }
        }
        var edge = 0f
        var cnt = 0
        for (y in 0 until h - 1) for (x in 0 until w - 1) {
            val i = y * w + x
            edge += abs(lum[i + 1] - lum[i]) + abs(lum[i + w] - lum[i])
            cnt++
        }
        return floatArrayOf((sum / n).toFloat(), (p95 - p5) / 63f, clipped.toFloat() / n, (sat / n).toFloat(), edge / cnt)
    }

    /**
     * Looks at a tiny (96 x 54, RGB packed) copy of the frame and says what it is: dark, animation / flat colours, soft
     * (low contrast, few edges), busy (a lot of detail or noise) or normal. Plain rules on simple statistics (brightness,
     * contrast, edge amount, how few colours cover the picture); a heuristic, meant as a good guess.
     */
    fun classify(px: IntArray, w: Int = 96, h: Int = 54): Int {
        if (px.size < w * h) return C_NORMAL
        val lum = FloatArray(w * h)
        val hist = IntArray(64)
        val colors = IntArray(512)
        var sum = 0.0
        for (i in 0 until w * h) {
            val c = px[i]
            val r = (c shr 16) and 255
            val g = (c shr 8) and 255
            val b = c and 255
            val l = (0.299f * r + 0.587f * g + 0.114f * b) / 255f
            lum[i] = l
            sum += l
            hist[(l * 63f).toInt().coerceIn(0, 63)]++
            colors[((r shr 5) shl 6) or ((g shr 5) shl 3) or (b shr 5)]++
        }
        val n = w * h
        val mean = (sum / n).toFloat()
        var acc = 0
        var p5 = 0
        var p95 = 63
        var got5 = false
        for (i in 0 until 64) {
            acc += hist[i]
            if (!got5 && acc >= n * 0.05f) { p5 = i; got5 = true }
            if (acc >= n * 0.95f) { p95 = i; break }
        }
        val contrast = (p95 - p5) / 63f
        val high = p95 / 63f
        var edge = 0f
        var flat = 0
        var strong = 0
        var cnt = 0
        for (y in 0 until h - 1) for (x in 0 until w - 1) {
            val i = y * w + x
            val d = abs(lum[i + 1] - lum[i]) + abs(lum[i + w] - lum[i])
            edge += d
            if (d < 0.012f) flat++
            if (d > 0.15f) strong++
            cnt++
        }
        edge /= cnt
        val flatFrac = flat.toFloat() / cnt
        val strongFrac = strong.toFloat() / cnt
        colors.sort()
        var top = 0
        for (i in 511 downTo 504) top += colors[i]
        val topShare = top.toFloat() / n
        return when {
            mean < 0.20f && high < 0.60f -> C_DARK
            flatFrac > 0.55f && topShare > 0.45f && strongFrac > 0.02f -> C_ANIME
            edge < 0.025f && contrast < 0.50f -> C_SOFT
            edge > 0.10f -> C_BUSY
            else -> C_NORMAL
        }
    }

    /**
     * The upscaler for a kind of picture. Dark / soft: NIS Lite soft (the normal push would amplify noise); animation: NIS Lite
     * (clean edges); a busy single photo with the Quality budget: original NIS (very sharp, heavy); everything else: the
     * usual choice of [Profiles.upscaleMode]. Never heavier than the budget allows.
     */
    fun upscaleFor(cls: Int, ratio: Float, budget: Int, type: Int, isPhoto: Boolean): Int {
        val base = Profiles.upscaleMode(true, ratio, budget, type)
        if (base == Cfg.MODE_SHARP || base == Cfg.MODE_FAST) return base
        return when (cls) {
            C_DARK, C_SOFT -> Cfg.MODE_NIS_SOFT
            C_ANIME -> Cfg.MODE_NIS_SOFT   // measured: Aura (NIS Lite) was the worst of the NIS family on animation, soft equals FSR 1 there
            C_BUSY -> if (budget == Profiles.QUALITY) Cfg.MODE_NIS_SOFT else base   // measured: NIS original was the worst on busy pictures, soft the best
            else -> base
        }
    }

    fun className(ctx: Context, cls: Int): String = ctx.getString(
        when (cls) {
            C_DARK -> R.string.auto_c_dark
            C_ANIME -> R.string.auto_c_anime
            C_SOFT -> R.string.auto_c_soft
            C_BUSY -> R.string.auto_c_busy
            else -> R.string.auto_c_normal
        }
    )

    fun forPhoto(w: Int, h: Int): Pick {
        val longSide = maxOf(w, h)
        val type = Profiles.PHOTO
        val level = when {
            longSide < 1000 -> 2
            longSide < 2000 -> 1
            else -> 0
        }
        return Pick(type, level, Profiles.QUALITY, "")
    }

    /**
     * A manga page: always the manga profile with the Quality budget (a page costs nothing); the strength follows how much the
     * page is enlarged on this screen (level 3 = from the ratio when it is applied).
     */
    fun forManga(): Pick = Pick(Profiles.MANGA, 3, Profiles.QUALITY, "")

    /**
     * A GIF: low resolution, few colours (dither and banding), so the video profile (clean-up before the enlargement, light deband).
     * A small GIF costs almost nothing, so it gets the Quality budget; a big one the Balanced budget (it runs continuously).
     */
    fun forGif(w: Int, h: Int): Pick {
        val small = w.toLong() * h <= 400L * 400L
        return Pick(Profiles.VIDEO, 3, if (small) Profiles.QUALITY else Profiles.BALANCED, "")
    }

    /**
     * The newer options that a quick profile does not set, so that Auto decides them too (it used to leave them as they were):
     *  - the three size choices (input / middle / output) go back to "automatic";
     *  - CRSC Edge: exact mode off (the lighter flat-area shortcuts), no extra NIS crispness pass;
     *  - black bars are cut by themselves on films and clips (nothing happens when there are none);
     *  - anti-ringing is turned on when the sharpening is strong (high sharpness, original NIS, CRSC Edge Crisp or Ultra);
     *  - Smart fix (photos, films, clips), clarity (a touch, when the GPU budget allows) and deinterlace (MPEG-2 / TV-container sources) are chosen too.
     * Must be called after [Profiles.applyPick] (it reads the upscaler and sharpness that were just chosen).
     */
    fun applyExtras(pick: Pick, type: Int = pick.type) {
        Cfg.inRes = 0
        Cfg.midRes = 0
        Cfg.outRes = 0
        Cfg.crscExact = false
        Cfg.crscNis = 0
        Cfg.crscNisFast = false
        Cfg.autoCrop = pick.canCrop
        val strong = Cfg.sharp >= 0.55f || Cfg.mode == Cfg.MODE_NIS_ORIG || Cfg.mode == Cfg.MODE_NIS ||
            (Cfg.mode == Cfg.MODE_LANCZOS && Cfg.crscLevel >= 3)
        Cfg.antiRing = if (strong) 0.35f else 0f
        // Everything else Auto can decide:
        val film = pick.type == Profiles.PHOTO || pick.canCrop        // photos, films and clips (not games, streams, manga)
        val flat = type == Profiles.ANIME                               // flat colours: measured white balance / local contrast would only add noise
        val heavy = Cfg.profileBudget >= Profiles.BALANCED
        // Smart fix (measured white balance, levels, shadow lift): Auto never turns it on (the user asked for it to stay a manual choice)
        Cfg.smartFix = false
        // Clarity (local contrast): a touch for photos and HD films when the GPU can afford it; none on dark, busy or flat pictures
        Cfg.clarity = if (film && heavy && !flat && type != Profiles.DARK && type != Profiles.BUSY) {
            when (pick.type) { Profiles.PHOTO -> 0.20f; Profiles.MOVIE -> 0.12f; else -> 0.08f }
        } else 0f
        // Deinterlace for sources that look interlaced (it only touches combed lines)
        Cfg.deint = pick.deint
        // Clean upscale: only for videos (a photo or a stream keeps the person's own choice); on when the video is squeezed into few bits
        if (pick.clean >= 0f && pick.type != Profiles.PHOTO) {
            Cfg.cleanUp = pick.clean > 0f
            if (pick.clean > 0f) Cfg.cleanLevel = pick.clean
        }
    }

    /** Screen overlay baseline: light, cheap, safe for any app. */
    fun forOverlay(budget: Int = Profiles.BALANCED) = Pick(Profiles.STREAM, 1, budget, "")

    /** Tiles the AI needs for a photo (each tile is ~112 px of the photo). */
    fun tiles(w: Int, h: Int): Int = ceil(w / 112.0).toInt() * ceil(h / 112.0).toInt()

    /**
     * Picks the installed model that suits the photo: few tiles = the best (slowest) model is affordable; many tiles =
     * the fastest one. Falls back to the active model when none of the preferred ones is installed.
     */
    fun aiModel(ctx: Context, w: Int, h: Int): String {
        val have = AiSr.list(ctx).map { it.id }.toSet()
        val t = tiles(w, h)
        val order = when {
            t <= 30 -> listOf("Real_ESRGAN_x4v3", "SESR_M5", "QuickSRNet_Large", "QuickSRNet_Medium", "XLSR", "QuickSRNet_Small")
            t <= 90 -> listOf("SESR_M5", "QuickSRNet_Large", "QuickSRNet_Medium", "XLSR", "QuickSRNet_Small", "Real_ESRGAN_x4v3")
            else -> listOf("QuickSRNet_Small", "XLSR", "QuickSRNet_Medium", "QuickSRNet_Large", "SESR_M5", "Real_ESRGAN_x4v3")
        }
        return order.firstOrNull { it in have } ?: AiSr.activeId(ctx)
    }

    /** True when a photo is small enough to be AI-upscaled automatically within a minute or so. */
    fun smallEnoughForAuto(w: Int, h: Int) = tiles(w, h) <= 30

    // ---- overlay ladder: 0 = Fast @80%, 1 = Performance, 2 = Balanced, 3 = Quality ----------------------------
    const val LADDER_TOP = 3

    fun applyOverlayStep(step: Int) {
        val s = step.coerceIn(0, LADDER_TOP)
        val budget = when (s) {
            0, 1 -> Profiles.PERF
            2 -> Profiles.BALANCED
            else -> Profiles.QUALITY
        }
        Profiles.applyPick(Profiles.STREAM, 1, budget, false, 1f)
        // the screen layer never crops bars or changes sizes; the newer options go back to plain
        Cfg.inRes = 0; Cfg.midRes = 0; Cfg.outRes = 0
        Cfg.crscExact = false; Cfg.crscNis = 0; Cfg.crscNisFast = false
        Cfg.autoCrop = false; Cfg.antiRing = 0f
        Cfg.smartFix = false; Cfg.clarity = 0f; Cfg.deint = 0 // the app underneath is unknown: no measured colour changes
        if (s == 0) {
            Cfg.mode = Cfg.MODE_FAST
            Cfg.scalePct = 80
        }
    }

    fun stepName(ctx: Context, step: Int): String = ctx.getString(
        when (step.coerceIn(0, LADDER_TOP)) {
            0 -> R.string.auto_step_fast
            1 -> R.string.budget_perf
            2 -> R.string.budget_balanced
            else -> R.string.budget_quality
        }
    )
}
