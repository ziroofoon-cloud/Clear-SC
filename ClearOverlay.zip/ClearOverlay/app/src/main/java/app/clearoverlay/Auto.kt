package app.clearoverlay

import android.content.Context
import kotlin.math.ceil

/**
 * "Auto": the app chooses the quick profile, strength, GPU budget, anti-aliasing, upscale mode, render scale and AI
 * model by itself, from what is on screen and from how hard the phone is working. The decisions are simple rules, not
 * machine learning, and are meant as good starting points: touching any control switches Auto off.
 *
 *  - Video (player): resolution, frame rate, bitrate and whether it is a stream pick the content type; the strength
 *    follows the enlargement; the budget starts from the pixel rate and drops when frames are dropped.
 *  - Photo (player): small or soft photos get stronger cleanup; photos always use the Quality budget (a single frame
 *    costs nothing); the AI model is chosen from the photo's size (small = best model, big = fastest one).
 *  - Screen overlay: the app underneath is unknown, so a light all-round profile is used and a "ladder" of settings is
 *    walked up and down from the measured time each frame takes: Fast 80% > Performance > Balanced > Quality.
 */
object Auto {
    class Pick(val type: Int, val level: Int, val budget: Int, val why: String)

    /** Video: [fps] and [bitrate] may be 0 / unknown. [ratio] = shown size / source size. */
    fun forVideo(srcW: Int, srcH: Int, fps: Float, bitrate: Int, isStream: Boolean, ratio: Float): Pick {
        val h = minOf(srcW, srcH).coerceAtLeast(1)
        val longSide = maxOf(srcW, srcH)
        val type = when {
            isStream -> Profiles.STREAM
            h <= 576 || longSide <= 1024 -> Profiles.VIDEO
            else -> Profiles.MOVIE
        }
        // pixels per second the GPU must process: 1080p30 = 62 MP/s, 1080p60 = 124 MP/s, 4K30 = 249 MP/s
        val rate = srcW.toDouble() * srcH * (if (fps > 1f) fps else 30f)
        val budget = when {
            rate > 150e6 -> Profiles.PERF
            rate > 70e6 -> Profiles.BALANCED
            ratio > 1.5f -> Profiles.QUALITY // small source, big enlargement: spend the GPU where it helps
            else -> Profiles.BALANCED
        }
        return Pick(type, 3, budget, "")
    }

    fun forPhoto(w: Int, h: Int): Pick {
        val longSide = maxOf(w, h)
        val type = Profiles.PHOTO
        val level = when {
            longSide < 1000 -> 2
            longSide < 2000 -> 1
            else -> 0
        }
        return Pick(type, level, Profiles.QUALITY, "")
    }

    /** Screen overlay baseline: light, cheap, safe for any app. */
    fun forOverlay(budget: Int = Profiles.BALANCED) = Pick(Profiles.STREAM, 1, budget, "")

    /** Tiles the AI needs for a photo (each tile is ~112 px of the photo). */
    fun tiles(w: Int, h: Int): Int = ceil(w / 112.0).toInt() * ceil(h / 112.0).toInt()

    /**
     * Picks the installed model that suits the photo: few tiles = the best (slowest) model is affordable; many tiles =
     * the fastest one. Falls back to the active model when none of the preferred ones is installed.
     */
    fun aiModel(ctx: Context, w: Int, h: Int): String {
        val have = AiSr.list(ctx).map { it.id }.toSet()
        val t = tiles(w, h)
        val order = when {
            t <= 30 -> listOf("Real_ESRGAN_x4v3", "SESR_M5", "QuickSRNet_Large", "QuickSRNet_Medium", "XLSR", "QuickSRNet_Small")
            t <= 90 -> listOf("SESR_M5", "QuickSRNet_Large", "QuickSRNet_Medium", "XLSR", "QuickSRNet_Small", "Real_ESRGAN_x4v3")
            else -> listOf("QuickSRNet_Small", "XLSR", "QuickSRNet_Medium", "QuickSRNet_Large", "SESR_M5", "Real_ESRGAN_x4v3")
        }
        return order.firstOrNull { it in have } ?: AiSr.activeId(ctx)
    }

    /** True when a photo is small enough to be AI-upscaled automatically within a minute or so. */
    fun smallEnoughForAuto(w: Int, h: Int) = tiles(w, h) <= 30

    // ---- overlay ladder: 0 = Fast @80%, 1 = Performance, 2 = Balanced, 3 = Quality ----------------------------
    const val LADDER_TOP = 3

    fun applyOverlayStep(step: Int) {
        val s = step.coerceIn(0, LADDER_TOP)
        val budget = when (s) {
            0, 1 -> Profiles.PERF
            2 -> Profiles.BALANCED
            else -> Profiles.QUALITY
        }
        Profiles.applyPick(Profiles.STREAM, 1, budget, false, 1f)
        if (s == 0) {
            Cfg.mode = Cfg.MODE_FAST
            Cfg.scalePct = 80
        }
    }

    fun stepName(ctx: Context, step: Int): String = ctx.getString(
        when (step.coerceIn(0, LADDER_TOP)) {
            0 -> R.string.auto_step_fast
            1 -> R.string.budget_perf
            2 -> R.string.budget_balanced
            else -> R.string.budget_quality
        }
    )
}
