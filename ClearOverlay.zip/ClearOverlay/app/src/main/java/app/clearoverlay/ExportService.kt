package app.clearoverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.IBinder
import android.os.PowerManager
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean

/** What the export screen shows: progress of the running (or last) video export. */
object ExportState {
    @Volatile var running = false
    @Volatile var finished = false
    @Volatile var cancelled = false
    @Volatile var job: ExportJob? = null
    @Volatile var doneUs = 0L
    @Volatile var totalUs = 0L
    @Volatile var speed = 0f
    @Volatile var startedAt = 0L
    @Volatile var result: Uri? = null
    @Volatile var error: String? = null
    val segs = CopyOnWriteArrayList<ExportSeg>()

    fun reset(j: ExportJob) {
        job = j
        running = true
        finished = false
        cancelled = false
        doneUs = 0L
        totalUs = 0L
        speed = 0f
        startedAt = System.currentTimeMillis()
        result = null
        error = null
        segs.clear()
        AudioNote.skipped = false
    }
}

/**
 * Runs a video export in the background (foreground service with a progress notification, so Android does not stop
 * it while the screen is off).
 */
class ExportService : Service() {
    private val cancel = AtomicBoolean(false)
    private var wl: PowerManager.WakeLock? = null

    companion object {
        const val ACT_START = "app.clearoverlay.EXPORT_START"
        const val ACT_CANCEL = "app.clearoverlay.EXPORT_CANCEL"
        const val X_NAME = "name"
        const val X_TARGET = "target"
        const val X_TIER = "tier"
        const val X_ANIME = "anime"
        const val X_HEVC = "hevc"
        const val X_MODE = "mode"
        private const val CH = "crsc_export"
        private const val ID = 77

        fun start(ctx: Context, uri: Uri, name: String, target: Int, tier: Int, anime: Boolean, hevc: Boolean = false, mode: Int = Cfg.MODE_FSR) {
            val i = Intent(ctx, ExportService::class.java).setAction(ACT_START).setData(uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                .putExtra(X_NAME, name).putExtra(X_TARGET, target).putExtra(X_TIER, tier).putExtra(X_ANIME, anime).putExtra(X_HEVC, hevc).putExtra(X_MODE, mode)
            ctx.startForegroundService(i)
        }

        fun cancel(ctx: Context) {
            ctx.startService(Intent(ctx, ExportService::class.java).setAction(ACT_CANCEL))
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun nm() = getSystemService(NotificationManager::class.java)

    private fun notif(title: String, text: String, pct: Int, ongoing: Boolean): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, ExportActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val b = Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .setOngoing(ongoing)
        if (ongoing) {
            b.setProgress(100, pct, pct <= 0)
            val c = PendingIntent.getService(
                this, 1, Intent(this, ExportService::class.java).setAction(ACT_CANCEL), PendingIntent.FLAG_IMMUTABLE
            )
            b.addAction(Notification.Action.Builder(null, getString(R.string.export_cancel), c).build())
        }
        return b.build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACT_CANCEL) {
            cancel.set(true)
            return START_NOT_STICKY
        }
        val u = intent?.data
        if (intent?.action != ACT_START || u == null || ExportState.running) {
            if (ExportState.running.not()) stopSelf()
            return START_NOT_STICKY
        }
        nm().createNotificationChannel(NotificationChannel(CH, getString(R.string.export_title), NotificationManager.IMPORTANCE_LOW))
        val job = ExportJob(
            // same file + same settings = same id, so a job that was cut short continues where it stopped
            Integer.toHexString((u.toString() + "|" + intent!!.getIntExtra(X_TARGET, 1080) + "|" + intent.getIntExtra(X_TIER, 1) + "|" + intent.getBooleanExtra(X_ANIME, false) + "|" + intent.getBooleanExtra(X_HEVC, false) + "|" + intent.getIntExtra(X_MODE, Cfg.MODE_FSR)).hashCode()), u.toString(),
            intent.getStringExtra(X_NAME) ?: "video",
            intent.getIntExtra(X_TARGET, 1080), intent.getIntExtra(X_TIER, 1), intent.getBooleanExtra(X_ANIME, false),
            intent.getBooleanExtra(X_HEVC, false), intent.getIntExtra(X_MODE, Cfg.MODE_FSR)
        )
        // unfinished leftovers older than a week are removed
        runCatching {
            File(filesDir, "export").listFiles()?.forEach { d -> if (System.currentTimeMillis() - d.lastModified() > 7L * 24 * 3600 * 1000) d.deleteRecursively() }
        }
        ExportState.reset(job)
        cancel.set(false)
        startForeground(ID, notif(getString(R.string.export_notif_title), job.name, 0, true), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        wl = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "crsc:export").also { it.acquire(8L * 3600 * 1000) }

        Thread {
            var err: String? = null
            var out: Uri? = null
            try {
                out = VideoExport(this, job).run(cancel, object : VideoExport.Listener {
                    override fun onProgress(doneUs: Long, totalUs: Long, speed: Float) {
                        ExportState.doneUs = doneUs
                        ExportState.totalUs = totalUs
                        ExportState.speed = speed
                        val pct = if (totalUs > 0) (doneUs * 100 / totalUs).toInt().coerceIn(0, 100) else 0
                        nm().notify(ID, notif(getString(R.string.export_notif_title), job.name + "  " + pct + "%", pct, true))
                    }

                    override fun onSegment(seg: ExportSeg) {
                        ExportState.segs.add(seg)
                    }
                })
            } catch (t: Throwable) {
                err = t.message ?: t.javaClass.simpleName
            }
            val dir = VideoExport.dir(this, job.id)
            if (cancel.get()) {
                ExportState.cancelled = true
                dir.deleteRecursively()
            } else if (out != null) {
                dir.deleteRecursively()
            }
            ExportState.result = out
            ExportState.error = if (cancel.get()) null else err
            ExportState.running = false
            ExportState.finished = true
            runCatching { wl?.release() }
            stopForeground(STOP_FOREGROUND_REMOVE)
            val ok = out != null && err == null
            if (!cancel.get()) {
                nm().notify(
                    ID + 1,
                    notif(
                        getString(if (ok) R.string.export_notif_done else R.string.export_notif_failed),
                        if (ok) job.name else (err ?: ""), 100, false
                    )
                )
            }
            stopSelf()
        }.start()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        runCatching { wl?.release() }
        super.onDestroy()
    }
}
