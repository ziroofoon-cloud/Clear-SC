package app.clearoverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.IBinder
import android.os.PowerManager
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean

/** What the export screen shows: progress of the running (or last) video export. */
object ExportState {
    @Volatile var running = false
    @Volatile var finished = false
    @Volatile var cancelled = false
    @Volatile var job: ExportJob? = null
    @Volatile var doneUs = 0L
    @Volatile var totalUs = 0L
    @Volatile var speed = 0f
    @Volatile var startedAt = 0L
    @Volatile var result: Uri? = null
    @Volatile var error: String? = null
    /** The last export was stopped on purpose and only its finished part was saved. */
    @Volatile var partial = false
    /** The last export was paused: its finished pieces are kept so it can be continued later. */
    @Volatile var paused = false
    /** Streaming upscale: the spot (microseconds of the whole video) the viewer is at, -1 = not watching yet. */
    @Volatile var playUs = -1L
    val segs = CopyOnWriteArrayList<ExportSeg>()

    fun reset(j: ExportJob) {
        job = j
        running = true
        finished = false
        cancelled = false
        doneUs = 0L
        totalUs = 0L
        speed = 0f
        startedAt = System.currentTimeMillis()
        result = null
        error = null
        partial = false
        paused = false
        playUs = -1L
        segs.clear()
        AudioNote.skipped = false
    }
}

/**
 * Runs a video export in the background (foreground service with a progress notification, so Android does not stop
 * it while the screen is off).
 */
class ExportService : Service() {
    private val cancel = AtomicBoolean(false)
    private val savePart = AtomicBoolean(false)
    private val pauseReq = AtomicBoolean(false)
    private var wl: PowerManager.WakeLock? = null

    companion object {
        const val ACT_START = "app.clearoverlay.EXPORT_START"
        const val ACT_CANCEL = "app.clearoverlay.EXPORT_CANCEL"
        const val ACT_SAVE = "app.clearoverlay.EXPORT_SAVE_PART"
        const val ACT_PAUSE = "app.clearoverlay.EXPORT_PAUSE"
        const val X_NAME = "name"
        const val X_TARGET = "target"
        const val X_TIER = "tier"
        const val X_ANIME = "anime"
        const val X_HEVC = "hevc"
        const val X_MODE = "mode"
        const val X_SHARP = "sharp"
        const val X_VIVID = "vivid"
        const val X_PACE = "pace"
        const val X_RS = "range_start"
        const val X_RE = "range_end"
        const val X_STREAM = "stream"
        private const val CH = "crsc_export"
        private const val ID = 77

        fun start(ctx: Context, uri: Uri, name: String, o: ExportOpts) {
            val i = Intent(ctx, ExportService::class.java).setAction(ACT_START).setData(uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                .putExtra(X_NAME, name).putExtra(X_TARGET, o.target).putExtra(X_TIER, o.tier).putExtra(X_ANIME, o.anime).putExtra(X_HEVC, o.hevc).putExtra(X_MODE, o.mode)
                .putExtra(X_SHARP, o.sharp).putExtra(X_VIVID, o.vivid).putExtra(X_PACE, o.pace)
                .putExtra(X_RS, o.rangeStartUs).putExtra(X_RE, o.rangeEndUs).putExtra(X_STREAM, o.stream)
            ctx.startForegroundService(i)
        }

        /** Same file + same settings = same id, so a job that was cut short continues where it stopped. */
        fun jobId(u: Uri, o: ExportOpts): String =
            Integer.toHexString(
                (u.toString() + "|" + o.target + "|" + o.tier + "|" + o.anime + "|" + o.hevc + "|" + o.mode + "|" + o.sharp + "|" + o.vivid +
                    (if (o.rangeStartUs > 0L || o.rangeEndUs > 0L) "|r" + o.rangeStartUs + "-" + o.rangeEndUs else "") + (if (o.stream) "|stream" else "")).hashCode()
            )

        /** Stop now, but keep and save what is finished (the rest can be done later). */
        fun saveAndStop(ctx: Context) {
            ctx.startService(Intent(ctx, ExportService::class.java).setAction(ACT_SAVE))
        }

        /** Stop now and keep everything done; nothing is written to the gallery. Continue later from the export screen. */
        fun pause(ctx: Context) {
            ctx.startService(Intent(ctx, ExportService::class.java).setAction(ACT_PAUSE))
        }

        /** Starts a job again from its saved settings (the finished pieces are reused). */
        fun resume(ctx: Context, j: ExportJob) {
            start(ctx, Uri.parse(j.uri), j.name, ExportOpts(j.targetShort, j.tier, j.anime, j.hevc, j.mode, j.sharpOv, j.vividOv, j.pace, j.rangeStartUs, j.rangeEndUs))
        }

        fun cancel(ctx: Context) {
            ctx.startService(Intent(ctx, ExportService::class.java).setAction(ACT_CANCEL))
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun nm() = getSystemService(NotificationManager::class.java)

    private fun notif(title: String, text: String, pct: Int, ongoing: Boolean): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, ExportActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val b = Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .setOngoing(ongoing)
        if (ongoing) {
            b.setProgress(100, pct, pct <= 0)
            val c = PendingIntent.getService(
                this, 1, Intent(this, ExportService::class.java).setAction(ACT_CANCEL), PendingIntent.FLAG_IMMUTABLE
            )
            b.addAction(Notification.Action.Builder(null, getString(R.string.export_cancel), c).build())
        }
        return b.build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACT_CANCEL) {
            cancel.set(true)
            return START_NOT_STICKY
        }
        if (intent?.action == ACT_PAUSE) {
            pauseReq.set(true)
            return START_NOT_STICKY
        }
        if (intent?.action == ACT_SAVE) {
            savePart.set(true)
            return START_NOT_STICKY
        }
        val u = intent?.data
        if (intent?.action != ACT_START || u == null || ExportState.running) {
            if (ExportState.running.not()) stopSelf()
            return START_NOT_STICKY
        }
        nm().createNotificationChannel(NotificationChannel(CH, getString(R.string.export_title), NotificationManager.IMPORTANCE_LOW))
        val job = ExportJob(
            ExportService.jobId(u, ExportOpts(
                intent!!.getIntExtra(X_TARGET, 1080), intent.getIntExtra(X_TIER, 1), intent.getBooleanExtra(X_ANIME, false),
                intent.getBooleanExtra(X_HEVC, false), intent.getIntExtra(X_MODE, Cfg.MODE_FSR),
                intent.getFloatExtra(X_SHARP, -1f), intent.getFloatExtra(X_VIVID, 0f), intent.getIntExtra(X_PACE, 0),
                intent.getLongExtra(X_RS, 0L), intent.getLongExtra(X_RE, 0L), intent.getBooleanExtra(X_STREAM, false)
            )), u.toString(),
            intent.getStringExtra(X_NAME) ?: "video",
            intent.getIntExtra(X_TARGET, 1080), intent.getIntExtra(X_TIER, 1), intent.getBooleanExtra(X_ANIME, false),
            intent.getBooleanExtra(X_HEVC, false), intent.getIntExtra(X_MODE, Cfg.MODE_FSR),
            intent.getFloatExtra(X_SHARP, -1f), intent.getFloatExtra(X_VIVID, 0f), intent.getIntExtra(X_PACE, 0),
            intent.getLongExtra(X_RS, 0L), intent.getLongExtra(X_RE, 0L), intent.getBooleanExtra(X_STREAM, false)
        )
        // unfinished leftovers older than a week are removed
        runCatching {
            File(filesDir, "export").listFiles()?.forEach { d -> if (System.currentTimeMillis() - d.lastModified() > 7L * 24 * 3600 * 1000) d.deleteRecursively() }
        }
        ExportState.reset(job)
        cancel.set(false)
        savePart.set(false)
        pauseReq.set(false)
        if (!job.stream) ExportInfo.saveUnfinished(this, job)
        startForeground(ID, notif(getString(R.string.export_notif_title), job.name, 0, true), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        wl = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "crsc:export").also { it.acquire(8L * 3600 * 1000) }

        Thread {
            var err: String? = null
            var out: Uri? = null
            val ve = VideoExport(this, job)
            try {
                out = ve.run(cancel, object : VideoExport.Listener {
                    override fun onProgress(doneUs: Long, totalUs: Long, speed: Float) {
                        ExportState.doneUs = doneUs
                        ExportState.totalUs = totalUs
                        ExportState.speed = speed
                        val pct = if (totalUs > 0) (doneUs * 100 / totalUs).toInt().coerceIn(0, 100) else 0
                        nm().notify(ID, notif(getString(R.string.export_notif_title), job.name + "  " + pct + "%", pct, true))
                    }

                    override fun onSegment(seg: ExportSeg) {
                        ExportState.segs.add(seg)
                    }
                }, savePart, pauseReq)
                ExportState.partial = ve.partial
                ExportState.paused = ve.paused
            } catch (t: Throwable) {
                err = t.message ?: t.javaClass.simpleName
            }
            val dir = VideoExport.dir(this, job.id)
            if (cancel.get()) {
                ExportState.cancelled = true
                dir.deleteRecursively()
                ExportInfo.clearUnfinished(this)
            } else if (job.stream) {
                // the pieces stay until the player is closed (it deletes them); a streaming job is never continued
                ExportInfo.clearUnfinished(this)
            } else if (out != null && !ExportState.partial) {
                ExportInfo.clearUnfinished(this)
                dir.deleteRecursively()
            } // a part that was saved on purpose or a paused job keeps its pieces, so it can be continued

            ExportState.result = out
            ExportState.error = if (cancel.get()) null else err
            ExportState.running = false
            ExportState.finished = true
            runCatching { wl?.release() }
            stopForeground(STOP_FOREGROUND_REMOVE)
            val ok = (out != null || job.stream) && err == null
            if (!cancel.get()) {
                val paused = ExportState.paused
                nm().notify(
                    ID + 1,
                    notif(
                        getString(if (paused) R.string.export_notif_paused else if (ok) R.string.export_notif_done else R.string.export_notif_failed),
                        if (paused) getString(R.string.export_notif_paused_text, job.name) else if (ok) job.name else (err ?: ""), 100, false
                    )
                )
            }
            stopSelf()
        }.start()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        runCatching { wl?.release() }
        super.onDestroy()
    }
}
