package app.clearoverlay

import android.graphics.Region
import android.os.Build
import android.util.Log
import android.view.SurfaceControl
import android.view.View
import android.view.WindowManager
import java.lang.reflect.Proxy

/** Best-effort helpers around hidden window APIs (every call is wrapped; failures are only logged). */
object Win {
    private const val TAG = "CRSC"
    private const val EXCLUDE_FROM_CAPTURE = 0x00080000 // PRIVATE_FLAG_EXCLUDE_FROM_SCREEN_CAPTURE

    /** Keeps the window out of screen capture (otherwise we would capture our own output). */
    fun excludeFromCapture(lp: WindowManager.LayoutParams): Boolean = runCatching {
        val f = lp.javaClass.getDeclaredField("privateFlags")
        f.isAccessible = true
        f.setInt(lp, f.getInt(lp) or EXCLUDE_FROM_CAPTURE)
    }.isSuccess

    /** Second way to exclude the window's surface from screenshots / capture. */
    fun skipScreenshot(view: View) {
        runCatching {
            val vri = view.javaClass.getMethod("getViewRootImpl").invoke(view) ?: return@runCatching
            val sc = vri.javaClass.getMethod("getSurfaceControl").invoke(vri) as SurfaceControl
            val tx = SurfaceControl.Transaction()
            SurfaceControl.Transaction::class.java
                .getMethod("setSkipScreenshot", SurfaceControl::class.java, Boolean::class.javaPrimitiveType)
                .invoke(tx, sc, true)
            tx.apply()
        }.onFailure { Log.d(TAG, "skipScreenshot unavailable: ${it.message}") }
    }

    /**
     * Makes the window transparent to touches so the app underneath keeps working.
     * Two independent mechanisms are installed because different ROMs honour different ones.
     * FLAG_NOT_TOUCHABLE is NOT used (on Android 12+ it clamps an app overlay to 80% alpha).
     */
    fun passTouchesThrough(view: View) {
        val install = {
            applyEmptyTouchableRegion(view)
            installEmptyInsets(view)
        }
        if (view.isAttachedToWindow) {
            install()
        } else {
            view.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
                override fun onViewAttachedToWindow(v: View) {
                    install()
                }

                override fun onViewDetachedFromWindow(v: View) {}
            })
        }
    }

    private fun applyEmptyTouchableRegion(view: View) {
        runCatching {
            val sc: Any? = if (Build.VERSION.SDK_INT >= 33) {
                view.rootSurfaceControl
            } else {
                view.javaClass.getMethod("getRootSurfaceControl").invoke(view)
            }
            if (sc == null) {
                Log.w(TAG, "rootSurfaceControl is null (not attached yet?)")
            } else {
                sc.javaClass.getMethod("setTouchableRegion", Region::class.java).invoke(sc, Region())
                Log.i(TAG, "empty touchable region applied")
            }
        }.onFailure { Log.w(TAG, "setTouchableRegion failed: ${it.message}") }
    }

    /** SystemUI-style: ViewTreeObserver.OnComputeInternalInsetsListener with an empty touchable region. */
    private fun installEmptyInsets(host: View) {
        runCatching {
            val infoCls = Class.forName("android.view.ViewTreeObserver\$InternalInsetsInfo")
            val listenerCls = Class.forName("android.view.ViewTreeObserver\$OnComputeInternalInsetsListener")
            val regionMode = infoCls.getField("TOUCHABLE_INSETS_REGION").getInt(null)
            val setInsets = infoCls.getMethod("setTouchableInsets", Int::class.javaPrimitiveType)
            val regionField = infoCls.getField("touchableRegion")

            val proxy = Proxy.newProxyInstance(listenerCls.classLoader, arrayOf(listenerCls)) { p, m, args ->
                when (m.name) {
                    "onComputeInternalInsets" -> {
                        val info = args[0]
                        runCatching {
                            setInsets.invoke(info, regionMode)
                            (regionField.get(info) as? Region)?.setEmpty()
                        }
                        null
                    }
                    "hashCode" -> System.identityHashCode(p)
                    "equals" -> p === args?.getOrNull(0)
                    "toString" -> "CrscInsets"
                    else -> null
                }
            }
            val vto = host.viewTreeObserver
            vto.javaClass.getMethod("addOnComputeInternalInsetsListener", listenerCls).invoke(vto, proxy)
            Log.i(TAG, "internal-insets pass-through installed")
        }.onFailure { Log.w(TAG, "internal insets pass-through failed: ${it.message}") }
    }
}
