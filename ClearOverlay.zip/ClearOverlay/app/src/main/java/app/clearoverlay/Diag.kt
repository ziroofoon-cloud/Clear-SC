package app.clearoverlay

import android.app.Activity
import android.content.Context
import android.content.Intent
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * A small picture log for problems that are hard to see from outside (a garbled picture while playing, an effect that quietly turned itself off):
 * the last [MAX] events are kept in memory and in the file `diag.txt` of the app, and the home screen can share them as text.
 * What is written: the state of the picture pipeline whenever it changes (upscaler, level, strength, precision, lightening, sizes), GL errors,
 * refused shaders, failed frames and low-memory warnings. No picture, no file name, nothing about the video itself.
 */
object Diag {
    private const val MAX = 160
    private val lines = ArrayDeque<String>()
    private var file: File? = null
    private var dirty = false
    private var lastSave = 0L
    private var last = ""
    private var repeat = 0
    private val fmt by lazy { SimpleDateFormat("MM-dd HH:mm:ss", Locale.US) }

    /** Called once (from [Cfg.load]) with any context: opens the file and reads the lines of the last run. */
    @Synchronized
    fun init(c: Context) {
        if (file != null) return
        val f = File(c.applicationContext.filesDir, "diag.txt")
        file = f
        runCatching { if (f.exists()) f.readLines().takeLast(MAX).forEach { lines.addLast(it) } }
        add("app", "start, Android " + android.os.Build.VERSION.RELEASE + ", " + android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL)
    }

    @Synchronized
    fun add(tag: String, msg: String) {
        val key = "$tag $msg"
        if (key == last) { repeat++; return }
        if (repeat > 0) lines.addLast("   (the same line again $repeat times)")
        last = key
        repeat = 0
        lines.addLast(fmt.format(Date()) + " [" + tag + "] " + msg.take(400))
        while (lines.size > MAX) lines.removeFirst()
        dirty = true
        val now = System.currentTimeMillis()
        if (now - lastSave > 3000L) save(now)
    }

    @Synchronized
    private fun save(now: Long) {
        lastSave = now
        if (!dirty) return
        dirty = false
        val f = file ?: return
        runCatching { f.writeText(lines.joinToString("\n")) }
    }

    @Synchronized
    fun flush() = save(System.currentTimeMillis())

    @Synchronized
    fun text(): String = lines.joinToString("\n") + (if (repeat > 0) "\n   (the same line again $repeat times)" else "")

    @Synchronized
    fun clear() {
        lines.clear(); last = ""; repeat = 0; dirty = true; save(System.currentTimeMillis())
    }

    fun share(a: Activity) {
        flush()
        val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_SUBJECT, "ClearOverlay picture log").putExtra(Intent.EXTRA_TEXT, text())
        a.startActivity(Intent.createChooser(i, a.getString(R.string.diag_share)))
    }
}
