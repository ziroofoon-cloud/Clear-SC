package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONObject
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

/**
 * Online enhancement through Replicate (replicate.com): the picture is uploaded, a cloud upscaler runs on it and the
 * result is downloaded. It needs the user's own API token and costs a little per picture (billed by Replicate).
 *
 * Models are chosen by their "owner/name" slug in the Online settings; the newest version of the model is looked up
 * on the fly, so no version hash is stored here. Default: nightmareai/real-esrgan (input: image, scale).
 */
object Online {
    const val PHOTO = 0
    const val TEXT = 1

    private const val API = "https://api.replicate.com/v1"
    private const val DEFAULT_MODEL = "nightmareai/real-esrgan"
    /** Longest side sent to the cloud: keeps the upload small and the price low. */
    private const val MAX_SEND = 1600

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("crsc", Context.MODE_PRIVATE)

    fun key(ctx: Context): String = prefs(ctx).getString("online_key", "")?.trim().orEmpty()
    fun hasKey(ctx: Context) = key(ctx).isNotEmpty()
    fun setKey(ctx: Context, k: String) = prefs(ctx).edit().putString("online_key", k.trim()).apply()

    fun model(ctx: Context, kind: Int): String =
        prefs(ctx).getString("online_model_$kind", null)?.trim()?.takeIf { it.contains('/') } ?: DEFAULT_MODEL

    fun setModel(ctx: Context, kind: Int, slug: String) =
        prefs(ctx).edit().putString("online_model_$kind", slug.trim()).apply()

    /** Upscale factor sent to the model: photos x4 (best), writing x2 (cheaper, and enough to open up thin strokes). */
    fun scale(kind: Int) = if (kind == TEXT) 2 else 4

    private val versionCache = HashMap<String, String>()

    private class Resp(val code: Int, val body: String)

    private fun call(method: String, url: String, token: String, json: String? = null, extra: Map<String, String> = emptyMap()): Resp {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 20000
        c.readTimeout = 60000
        c.setRequestProperty("Authorization", "Bearer $token")
        for ((k, v) in extra) c.setRequestProperty(k, v)
        if (json != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(json.toByteArray()) }
        }
        val code = c.responseCode
        val body = (if (code in 200..299) c.inputStream else c.errorStream)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
        c.disconnect()
        return Resp(code, body)
    }

    private fun fail(r: Resp): Nothing {
        val hint = when (r.code) {
            401 -> " (the API token is wrong)"
            402 -> " (no credit on the Replicate account)"
            404 -> " (model not found: check the model name in Online settings)"
            429 -> " (too many requests, wait a moment)"
            else -> ""
        }
        throw IllegalStateException("HTTP ${r.code}$hint ${r.body.take(160)}")
    }

    /** Uploads the picture to Replicate's file store and returns a URL the model can read. */
    private fun upload(token: String, jpeg: ByteArray): String {
        val boundary = "----crsc" + System.nanoTime()
        val c = URL("$API/files").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 20000
        c.readTimeout = 120000
        c.doOutput = true
        c.setRequestProperty("Authorization", "Bearer $token")
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        c.outputStream.use { o ->
            o.write(("--$boundary\r\nContent-Disposition: form-data; name=\"content\"; filename=\"in.jpg\"\r\nContent-Type: image/jpeg\r\n\r\n").toByteArray())
            o.write(jpeg)
            o.write("\r\n--$boundary--\r\n".toByteArray())
        }
        val code = c.responseCode
        val body = (if (code in 200..299) c.inputStream else c.errorStream)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
        c.disconnect()
        if (code !in 200..299) fail(Resp(code, body))
        return JSONObject(body).getJSONObject("urls").getString("get")
    }

    private fun latestVersion(token: String, slug: String): String {
        versionCache[slug]?.let { return it }
        val r = call("GET", "$API/models/$slug", token)
        if (r.code !in 200..299) fail(r)
        val id = JSONObject(r.body).getJSONObject("latest_version").getString("id")
        versionCache[slug] = id
        return id
    }

    /**
     * Sends [src] to the cloud model and returns the enhanced picture. Worker thread only.
     * [status] gets short progress words; [cancel] stops waiting (and asks Replicate to cancel the job).
     */
    fun enhance(ctx: Context, src: Bitmap, kind: Int, cancel: AtomicBoolean, status: (String) -> Unit): Bitmap? {
        val token = key(ctx)
        if (token.isEmpty()) throw IllegalStateException("no API token")
        val slug = model(ctx, kind)

        // 1. shrink + encode
        val k = MAX_SEND.toFloat() / max(src.width, src.height)
        val send = if (k < 1f) Bitmap.createScaledBitmap(src, (src.width * k).toInt().coerceAtLeast(2), (src.height * k).toInt().coerceAtLeast(2), true) else src
        val bos = ByteArrayOutputStream()
        send.compress(Bitmap.CompressFormat.JPEG, 95, bos)
        if (send !== src) send.recycle()

        // 2. upload
        status("upload")
        val url = upload(token, bos.toByteArray())
        if (cancel.get()) return null

        // 3. start the job
        status("start")
        val version = latestVersion(token, slug)
        val input = JSONObject().put("image", url).put("scale", scale(kind)).put("face_enhance", false)
        val start = call("POST", "$API/predictions", token, JSONObject().put("version", version).put("input", input).toString())
        if (start.code !in 200..299) fail(start)
        val job = JSONObject(start.body)
        val getUrl = job.getJSONObject("urls").getString("get")
        val cancelUrl = job.getJSONObject("urls").optString("cancel")

        // 4. wait
        status("wait")
        val t0 = System.currentTimeMillis()
        var out: String? = null
        while (true) {
            if (cancel.get()) {
                if (cancelUrl.isNotEmpty()) runCatching { call("POST", cancelUrl, token) }
                return null
            }
            if (System.currentTimeMillis() - t0 > 6 * 60_000L) throw IllegalStateException("timeout")
            Thread.sleep(1800)
            val r = call("GET", getUrl, token)
            if (r.code !in 200..299) fail(r)
            val j = JSONObject(r.body)
            when (j.optString("status")) {
                "succeeded" -> {
                    val o = j.opt("output")
                    out = when (o) {
                        is String -> o
                        is org.json.JSONArray -> if (o.length() > 0) o.getString(0) else null
                        else -> null
                    }
                    break
                }
                "failed", "canceled" -> throw IllegalStateException(j.optString("error").ifEmpty { j.optString("status") }.take(200))
            }
        }
        val outUrl = out ?: throw IllegalStateException("empty result")

        // 5. download
        status("download")
        val c = URL(outUrl).openConnection() as HttpURLConnection
        c.connectTimeout = 20000
        c.readTimeout = 120000
        val bytes = try {
            c.inputStream.use { it.readBytes() }
        } finally {
            c.disconnect()
        }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > 4096) sample *= 2
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    /** The Online settings dialog (API token + model names), shared by the player and the manga reader. */
    fun showSettings(act: Activity) {
        val pad = dp(act, 18)
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, dp(act, 8), pad, 0)
        }
        val note = TextView(act).apply {
            text = act.getString(R.string.online_note)
            textSize = 13f
        }
        val keyEt = EditText(act).apply {
            hint = act.getString(R.string.online_key_hint)
            setText(key(act))
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine()
        }
        val photoEt = EditText(act).apply {
            hint = act.getString(R.string.online_model_photo_hint)
            setText(model(act, PHOTO))
            setSingleLine()
        }
        val textEt = EditText(act).apply {
            hint = act.getString(R.string.online_model_text_hint)
            setText(model(act, TEXT))
            setSingleLine()
        }
        box.addView(note)
        box.addView(keyEt)
        box.addView(photoEt)
        box.addView(textEt)
        AlertDialog.Builder(act)
            .setTitle(act.getString(R.string.online_settings))
            .setView(ScrollView(act).apply { addView(box) })
            .setPositiveButton(android.R.string.ok) { _, _ ->
                setKey(act, keyEt.text.toString())
                setModel(act, PHOTO, photoEt.text.toString())
                setModel(act, TEXT, textEt.text.toString())
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }
}
