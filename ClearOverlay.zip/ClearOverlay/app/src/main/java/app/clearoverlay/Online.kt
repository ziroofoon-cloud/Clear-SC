package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONObject
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

/**
 * Online enhancement through Replicate (replicate.com): the picture is uploaded, a cloud upscaler runs on it and the
 * result is downloaded. It needs the user's own API token and costs a little per picture (billed by Replicate).
 *
 * Models are chosen by their "owner/name" slug in the Online settings; the newest version of the model is looked up
 * on the fly, so no version hash is stored here. Default: nightmareai/real-esrgan (input: image, scale).
 */
object Online {
    const val PHOTO = 0
    const val TEXT = 1

    private const val API = "https://api.replicate.com/v1"
    private const val DEFAULT_MODEL = "nightmareai/real-esrgan"
    /** Longest side sent to the cloud (x4 photos stay within 4096 px): keeps the upload small, the price low and the GPU job from running out of memory. */
    private fun maxSend(ctx: Context, kind: Int) =
        if (lowData(ctx)) (if (kind == TEXT) 800 else 640) else (if (kind == TEXT) 1280 else 1024)

    /** Low-data mode: a smaller, more compressed picture is sent (and so a smaller one comes back). Saves roughly 60-70% of the traffic. */
    fun lowData(ctx: Context): Boolean = ctx.getSharedPreferences("crsc", Context.MODE_PRIVATE).getBoolean("online_low", false)
    fun setLowData(ctx: Context, on: Boolean) = ctx.getSharedPreferences("crsc", Context.MODE_PRIVATE).edit().putBoolean("online_low", on).apply()

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("crsc", Context.MODE_PRIVATE)

    fun key(ctx: Context): String = prefs(ctx).getString("online_key", "")?.trim().orEmpty()
    fun hasKey(ctx: Context) = key(ctx).isNotEmpty()
    fun setKey(ctx: Context, k: String) = prefs(ctx).edit().putString("online_key", k.trim()).apply()

    fun model(ctx: Context, kind: Int): String =
        prefs(ctx).getString("online_model_$kind", null)?.trim()?.takeIf { it.contains('/') } ?: DEFAULT_MODEL

    fun setModel(ctx: Context, kind: Int, slug: String) =
        prefs(ctx).edit().putString("online_model_$kind", slug.trim()).apply()

    /** Upscale factor sent to the model: photos x4 (best), writing x2 (cheaper, and enough to open up thin strokes). */
    fun scale(kind: Int) = if (kind == TEXT) 2 else 4

    private val versionCache = HashMap<String, String>()

    private class Resp(val code: Int, val body: String)

    private fun call(method: String, url: String, token: String, json: String? = null, extra: Map<String, String> = emptyMap()): Resp {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 20000
        c.readTimeout = 60000
        c.setRequestProperty("Authorization", "Bearer $token")
        for ((k, v) in extra) c.setRequestProperty(k, v)
        if (json != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(json.toByteArray()) }
        }
        val code = c.responseCode
        val body = (if (code in 200..299) c.inputStream else c.errorStream)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
        c.disconnect()
        return Resp(code, body)
    }

    private fun fail(r: Resp): Nothing {
        val hint = when (r.code) {
            401 -> " (the API token is wrong or was revoked)"
            402 -> " (no credit on the Replicate account: add credit at replicate.com/account/billing. This is not an app bug; Replicate has no free quota.)\n(اعتبار حساب Replicate تمام شده یا هرگز شارژ نشده؛ باگ برنامه نیست. از replicate.com/account/billing شارژ کن، یا به‌جاش از AI آفلاین / FX استفاده کن.)"
            403 -> " (the token is not allowed to do this)"
            404 -> " (model not found: check the model name in Online settings)"
            422 -> " (the model did not accept the input)"
            429 -> " (too many requests; accounts with little credit are limited to a few per minute)"
            else -> ""
        }
        throw IllegalStateException("HTTP ${r.code}$hint\n${r.body.take(500)}")
    }

    /** Uploads the picture to Replicate's file store and returns a URL the model can read. */
    private fun upload(token: String, jpeg: ByteArray): String {
        val boundary = "----crsc" + System.nanoTime()
        val c = URL("$API/files").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 20000
        c.readTimeout = 120000
        c.doOutput = true
        c.setRequestProperty("Authorization", "Bearer $token")
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        c.outputStream.use { o ->
            o.write(("--$boundary\r\nContent-Disposition: form-data; name=\"content\"; filename=\"in.jpg\"\r\nContent-Type: image/jpeg\r\n\r\n").toByteArray())
            o.write(jpeg)
            o.write("\r\n--$boundary--\r\n".toByteArray())
        }
        val code = c.responseCode
        val body = (if (code in 200..299) c.inputStream else c.errorStream)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
        c.disconnect()
        if (code !in 200..299) fail(Resp(code, body))
        return JSONObject(body).getJSONObject("urls").getString("get")
    }

    private fun latestVersion(token: String, slug: String): String {
        versionCache[slug]?.let { return it }
        val r = call("GET", "$API/models/$slug", token)
        if (r.code !in 200..299) fail(r)
        var id = JSONObject(r.body).optJSONObject("latest_version")?.optString("id").orEmpty()
        if (id.isEmpty()) {
            // some models do not list a latest version in the model page: ask for the version list instead
            val v = call("GET", "$API/models/$slug/versions", token)
            if (v.code in 200..299) {
                val arr = JSONObject(v.body).optJSONArray("results")
                if (arr != null && arr.length() > 0) id = arr.getJSONObject(0).optString("id")
            }
        }
        if (id.isEmpty()) throw IllegalStateException("no version found for model $slug (check the model name)")
        versionCache[slug] = id
        return id
    }

    /** Checks the token (and the account) without running a model. Worker thread only. Returns a short message. */
    fun test(token: String): String {
        if (token.isBlank()) return "no API token"
        return try {
            val r = call("GET", "$API/account", token.trim())
            when {
                r.code in 200..299 -> "OK: " + (runCatching { JSONObject(r.body).optString("username") }.getOrNull() ?: "")
                else -> "HTTP ${r.code}\n${r.body.take(300)}"
            }
        } catch (t: Throwable) {
            t.javaClass.simpleName + ": " + (t.message ?: "")
        }
    }

    /** Shows an error with the full text (selectable), plus a button for the Online settings. */
    fun showError(act: Activity, msg: String) {
        val tv = TextView(act).apply {
            text = msg
            textSize = 13f
            setTextIsSelectable(true)
            setPadding(dp(act, 20), dp(act, 12), dp(act, 20), dp(act, 4))
        }
        AlertDialog.Builder(act)
            .setTitle(act.getString(R.string.online_error_title))
            .setView(ScrollView(act).apply { addView(tv) })
            .setPositiveButton(android.R.string.ok, null)
            .setNeutralButton(act.getString(R.string.online_settings)) { _, _ -> showSettings(act) }
            .setNegativeButton(act.getString(R.string.online_copy)) { _, _ ->
                (act.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager)
                    .setPrimaryClip(android.content.ClipData.newPlainText("error", msg))
            }
            .show()
    }

    /**
     * Sends [src] to the cloud model and returns the enhanced picture. Worker thread only.
     * [status] gets short progress words; [cancel] stops waiting (and asks Replicate to cancel the job).
     */
    fun enhance(ctx: Context, src: Bitmap, kind: Int, cancel: AtomicBoolean, status: (String) -> Unit): Bitmap? {
        val token = key(ctx)
        if (token.isEmpty()) throw IllegalStateException("no API token")
        val slug = model(ctx, kind)

        // 1. shrink + encode
        val k = maxSend(ctx, kind).toFloat() / max(src.width, src.height)
        val send = if (k < 1f) Bitmap.createScaledBitmap(src, (src.width * k).toInt().coerceAtLeast(2), (src.height * k).toInt().coerceAtLeast(2), true) else src
        val bos = ByteArrayOutputStream()
        send.compress(Bitmap.CompressFormat.JPEG, if (lowData(ctx)) 72 else 92, bos)
        if (send !== src) send.recycle()

        // 2. upload (if the file store refuses, the picture goes inside the request itself as a data: URI)
        status("upload")
        val bytes0 = bos.toByteArray()
        val url = try {
            upload(token, bytes0)
        } catch (t: Throwable) {
            if (cancel.get()) return null
            "data:image/jpeg;base64," + android.util.Base64.encodeToString(bytes0, android.util.Base64.NO_WRAP)
        }
        if (cancel.get()) return null

        // 3. start the job
        status("start")
        val version = latestVersion(token, slug)
        val input = JSONObject().put("image", url).put("scale", scale(kind)).put("face_enhance", false)
        val body = JSONObject().put("version", version).put("input", input).toString()
        var start = call("POST", "$API/predictions", token, body)
        var tries = 0
        while (start.code == 429 && tries < 4) {
            // low-credit accounts are rate limited: wait the time Replicate asks for, then try again
            tries++
            val wait = runCatching { JSONObject(start.body).optDouble("retry_after", 8.0) }.getOrDefault(8.0).coerceIn(2.0, 30.0)
            status("wait ${wait.toInt()}s")
            Thread.sleep((wait * 1000).toLong())
            if (cancel.get()) return null
            start = call("POST", "$API/predictions", token, body)
        }
        if (start.code !in 200..299) fail(start)
        val job = JSONObject(start.body)
        val getUrl = job.getJSONObject("urls").getString("get")
        val cancelUrl = job.getJSONObject("urls").optString("cancel")

        // 4. wait
        status("wait")
        val t0 = System.currentTimeMillis()
        var out: String? = null
        while (true) {
            if (cancel.get()) {
                if (cancelUrl.isNotEmpty()) runCatching { call("POST", cancelUrl, token) }
                return null
            }
            if (System.currentTimeMillis() - t0 > 6 * 60_000L) throw IllegalStateException("timeout")
            Thread.sleep(1800)
            val r = call("GET", getUrl, token)
            if (r.code !in 200..299) fail(r)
            val j = JSONObject(r.body)
            when (j.optString("status")) {
                "succeeded" -> {
                    val o = j.opt("output")
                    out = when (o) {
                        is String -> o
                        is org.json.JSONArray -> if (o.length() > 0) o.getString(0) else null
                        else -> null
                    }
                    break
                }
                "failed", "canceled" -> throw IllegalStateException(j.optString("error").ifEmpty { j.optString("status") }.take(200))
            }
        }
        val outUrl = out ?: throw IllegalStateException("empty result")

        // 5. download
        status("download")
        val c = URL(outUrl).openConnection() as HttpURLConnection
        c.connectTimeout = 20000
        c.readTimeout = 120000
        val bytes = try {
            c.inputStream.use { it.readBytes() }
        } finally {
            c.disconnect()
        }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > 4096) sample *= 2
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    /** The Online settings dialog (API token + model names), shared by the player and the manga reader. */
    fun showSettings(act: Activity) {
        val pad = dp(act, 18)
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, dp(act, 8), pad, 0)
        }
        val note = TextView(act).apply {
            text = act.getString(R.string.online_note)
            textSize = 13f
        }
        val keyEt = EditText(act).apply {
            hint = act.getString(R.string.online_key_hint)
            setText(key(act))
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine()
        }
        val photoEt = EditText(act).apply {
            hint = act.getString(R.string.online_model_photo_hint)
            setText(model(act, PHOTO))
            setSingleLine()
        }
        val textEt = EditText(act).apply {
            hint = act.getString(R.string.online_model_text_hint)
            setText(model(act, TEXT))
            setSingleLine()
        }
        val testTv = TextView(act).apply {
            text = act.getString(R.string.online_test)
            textSize = 14f
            setTextColor(Ui.ACCENT)
            setPadding(0, dp(act, 10), 0, dp(act, 6))
        }
        testTv.setOnClickListener {
            testTv.text = "…"
            val k = keyEt.text.toString()
            Thread {
                val r = test(k)
                act.runOnUiThread { testTv.text = act.getString(R.string.online_test) + "  →  " + r }
            }.start()
        }
        val lowCb = android.widget.CheckBox(act).apply {
            text = act.getString(R.string.online_low_data)
            isChecked = lowData(act)
        }
        box.addView(note)
        box.addView(keyEt)
        box.addView(testTv)
        box.addView(photoEt)
        box.addView(textEt)
        box.addView(lowCb)
        box.addView(TextView(act).apply {
            text = act.getString(R.string.online_low_data_hint)
            textSize = 12f
        })
        AlertDialog.Builder(act)
            .setTitle(act.getString(R.string.online_settings))
            .setView(ScrollView(act).apply { addView(box) })
            .setPositiveButton(android.R.string.ok) { _, _ ->
                setKey(act, keyEt.text.toString())
                setModel(act, PHOTO, photoEt.text.toString())
                setModel(act, TEXT, textEt.text.toString())
                setLowData(act, lowCb.isChecked)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }
}
