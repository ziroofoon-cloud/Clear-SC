package app.clearoverlay

import android.content.Context
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

/**
 * The sound-enhancer settings (on/off, quick presets, five sliders). Used by the music screen and by the video
 * player's dialog. Everything applies live because the audio processor reads [AudioCfg] on every block.
 * Call [AudioCfg.load] before building it.
 */
fun buildAudioPanel(ctx: Context): View {
    val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    fun gap(v: Int) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(ctx, v) }

    var syncing = false
    var syncBarsHook: (() -> Unit)? = null
    val bars = ArrayList<SeekBar>()
    val labels = ArrayList<TextView>()
    val chips = ArrayList<TextView>()

    val sw: Switch = panelSwitch(ctx, ctx.getString(R.string.aud_enhance), AudioCfg.on) { on ->
        if (!syncing) {
            AudioCfg.on = on
            AudioCfg.save(ctx)
        }
    }
    sw.textSize = 15f
    col.addView(sw)
    col.addView(Ui.text(ctx, ctx.getString(R.string.aud_hint), 12f, Ui.MUTED), gap(4))

    // ---- volume boost (works even with the enhancer off)
    val volLabel = Ui.text(ctx, "", 14f)
    fun volText() = ctx.getString(R.string.aud_volume) + "   +" + Math.round(AudioCfg.volume * 12f) + " dB"
    volLabel.text = volText()
    val volBar = SeekBar(ctx).apply {
        max = 24
        progress = Math.round(AudioCfg.volume * 24f)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                AudioCfg.volume = p / 24f
                volLabel.text = volText()
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) { AudioCfg.save(ctx) }
        })
    }
    col.addView(volLabel, gap(14))
    col.addView(volBar, gap(2))
    col.addView(Ui.text(ctx, ctx.getString(R.string.aud_volume_hint), 12f, Ui.MUTED), gap(2))

    // ---- automatic mode
    val autoSw: Switch = panelSwitch(ctx, ctx.getString(R.string.aud_auto), AudioCfg.auto) { on ->
        if (!syncing) {
            AudioCfg.auto = on
            if (on) AudioCfg.on = true
            AudioCfg.save(ctx)
            syncBarsHook?.invoke()
        }
    }
    autoSw.textSize = 15f
    col.addView(autoSw, gap(14))
    col.addView(Ui.text(ctx, ctx.getString(R.string.aud_auto_hint), 12f, Ui.MUTED), gap(4))

    // ---- speech mode: for talking that is hard to follow (a layer on top of the presets and sliders)
    val speechSw: Switch = panelSwitch(ctx, ctx.getString(R.string.aud_speech), AudioCfg.speech > 0.001f) { on ->
        if (!syncing) {
            AudioCfg.speech = if (on) 0.7f else 0f
            if (on) AudioCfg.on = true
            AudioCfg.save(ctx)
            syncBarsHook?.invoke()
        }
    }
    speechSw.textSize = 15f
    col.addView(speechSw, gap(14))
    col.addView(Ui.text(ctx, ctx.getString(R.string.aud_speech_hint), 12f, Ui.MUTED), gap(4))
    val speechLabel = Ui.text(ctx, "", 14f)
    fun speechText() = ctx.getString(R.string.aud_speech_amount) + "  " + Math.round(AudioCfg.speech * 100f) + "%"
    speechLabel.text = speechText()
    val speechBar = SeekBar(ctx).apply {
        max = 100
        progress = Math.round(AudioCfg.speech * 100f)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (syncing || !fromUser) return
                AudioCfg.speech = p / 100f
                if (p > 0) AudioCfg.on = true
                speechLabel.text = speechText()
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {
                AudioCfg.save(ctx)
                syncBarsHook?.invoke()
            }
        })
    }
    col.addView(speechLabel, gap(8))
    col.addView(speechBar, gap(2))

    // ---- presets
    col.addView(Ui.text(ctx, ctx.getString(R.string.aud_presets), 12f, Ui.MUTED), gap(12))
    val presetRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
    val presetNames = listOf(R.string.aud_p_music, R.string.aud_p_video, R.string.aud_p_podcast, R.string.aud_p_asmr, R.string.aud_p_custom)

    fun paintChips() {
        val r = dp(ctx, 10).toFloat()
        chips.forEachIndexed { i, c ->
            if (i == AudioCfg.preset) {
                c.background = Ui.gradient(r)
                c.setTextColor(Ui.BG)
            } else {
                c.background = Ui.round(Ui.CHIP, r)
                c.setTextColor(Ui.MUTED)
            }
        }
    }

    // ---- sliders
    class Row(val label: Int, val get: () -> Float, val set: (Float) -> Unit)
    val rows = listOf(
        Row(R.string.aud_clarity, { AudioCfg.clarity }, { AudioCfg.clarity = it }),
        Row(R.string.aud_bass, { AudioCfg.bass }, { AudioCfg.bass = it }),
        Row(R.string.aud_width, { AudioCfg.width }, { AudioCfg.width = it }),
        Row(R.string.aud_loud, { AudioCfg.loud }, { AudioCfg.loud = it }),
        Row(R.string.aud_voice, { AudioCfg.voice }, { AudioCfg.voice = it }),
        Row(R.string.aud_dialog, { AudioCfg.dialog }, { AudioCfg.dialog = it })
    )
    val eqBars = ArrayList<SeekBar>()
    val eqLabels = ArrayList<TextView>()
    val bandNames = listOf("60 Hz", "250 Hz", "1 kHz", "4 kHz", "12 kHz")
    fun eqText(i: Int) = bandNames[i] + "   " + String.format(java.util.Locale.US, "%+.0f dB", AudioCfg.eq[i] * 12f)

    fun syncBars() {
        syncing = true
        rows.forEachIndexed { i, row ->
            val pct = (row.get() * 100).toInt().coerceIn(0, 100)
            bars[i].progress = pct
            labels[i].text = ctx.getString(row.label) + "  " + pct + "%"
        }
        eqBars.forEachIndexed { i, b ->
            b.progress = (AudioCfg.eq[i] * 12f).toInt().coerceIn(-12, 12) + 12
            eqLabels[i].text = eqText(i)
        }
        if (sw.isChecked != AudioCfg.on) sw.isChecked = AudioCfg.on
        if (autoSw.isChecked != AudioCfg.auto) autoSw.isChecked = AudioCfg.auto
        val spOn = AudioCfg.speech > 0.001f
        if (speechSw.isChecked != spOn) speechSw.isChecked = spOn
        speechBar.progress = Math.round(AudioCfg.speech * 100f)
        speechLabel.text = speechText()
        val dim = if (AudioCfg.auto) 0.4f else 1f
        for (b in bars) { b.alpha = dim; b.isEnabled = !AudioCfg.auto }
        for (b in eqBars) { b.alpha = dim; b.isEnabled = !AudioCfg.auto }
        paintChips()
        syncing = false
    }

    presetNames.forEachIndexed { i, res ->
        val c = TextView(ctx).apply {
            text = ctx.getString(res)
            textSize = 12f
            gravity = Gravity.CENTER
            maxLines = 1
            setPadding(dp(ctx, 4), dp(ctx, 9), dp(ctx, 4), dp(ctx, 9))
            setOnClickListener {
                if (i == AudioCfg.CUSTOM) {
                    AudioCfg.preset = AudioCfg.CUSTOM
                } else {
                    AudioCfg.applyPreset(i)
                    AudioCfg.on = true
                }
                AudioCfg.save(ctx)
                syncBars()
            }
        }
        chips.add(c)
        presetRow.addView(c, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            if (i > 0) marginStart = dp(ctx, 5)
        })
    }
    col.addView(presetRow, gap(6))

    rows.forEachIndexed { i, row ->
        val label = Ui.text(ctx, "", 14f)
        val bar = SeekBar(ctx).apply {
            max = 100
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    if (syncing || !fromUser) return
                    row.set(p / 100f)
                    AudioCfg.preset = AudioCfg.CUSTOM
                    labels[i].text = ctx.getString(row.label) + "  " + p + "%"
                    paintChips()
                }

                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {
                    AudioCfg.save(ctx)
                }
            })
        }
        labels.add(label)
        bars.add(bar)
        col.addView(label, gap(if (i == 0) 14 else 8))
        col.addView(bar, gap(2))
    }
    // ---- equaliser: five bands, -12..+12 dB, with quick shapes
    col.addView(Ui.text(ctx, ctx.getString(R.string.aud_eq), 13f, Ui.ACCENT, true), gap(18))
    val shapeRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
    val shapeNames = listOf(R.string.aud_eq_flat, R.string.aud_eq_bass, R.string.aud_eq_vocal, R.string.aud_eq_treble, R.string.aud_eq_v)
    shapeNames.forEachIndexed { i, res ->
        val c = TextView(ctx).apply {
            text = ctx.getString(res)
            textSize = 12f
            gravity = Gravity.CENTER
            maxLines = 1
            setTextColor(Ui.ACCENT)
            background = Ui.round(Ui.CHIP, dp(ctx, 10).toFloat())
            setPadding(dp(ctx, 4), dp(ctx, 9), dp(ctx, 4), dp(ctx, 9))
            setOnClickListener {
                AudioCfg.eq = AudioCfg.EQ_SHAPES[i].copyOf()
                AudioCfg.preset = AudioCfg.CUSTOM
                AudioCfg.on = true
                AudioCfg.save(ctx)
                syncBars()
            }
        }
        shapeRow.addView(c, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i > 0) marginStart = dp(ctx, 5) })
    }
    col.addView(shapeRow, gap(8))
    for (i in 0 until 5) {
        val l = Ui.text(ctx, "", 13f)
        val b = SeekBar(ctx).apply {
            max = 24
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                    if (syncing || !fromUser) return
                    val n = AudioCfg.eq.copyOf()
                    n[i] = (p - 12) / 12f
                    AudioCfg.eq = n
                    AudioCfg.preset = AudioCfg.CUSTOM
                    eqLabels[i].text = eqText(i)
                    paintChips()
                }

                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {
                    AudioCfg.save(ctx)
                }
            })
        }
        eqLabels.add(l)
        eqBars.add(b)
        col.addView(l, gap(if (i == 0) 12 else 6))
        col.addView(b, gap(0))
    }
    syncBarsHook = { syncBars() }
    syncBars()
    return col
}


/** A button that shows the chosen export format and opens a list of all formats (the recommended one is marked in its name). */
fun audioFormatButton(ctx: Context): TextView {
    val b = TextView(ctx)
    fun paint() {
        b.text = ctx.getString(R.string.aud_format) + ":  " + ctx.getString(AudioFormats.get(AudioCfg.exportFmt).label)
    }
    b.apply {
        textSize = 13f
        gravity = Gravity.CENTER
        setTextColor(Ui.TEXT)
        background = Ui.round(Ui.CHIP, dp(ctx, 12).toFloat())
        setPadding(dp(ctx, 12), dp(ctx, 12), dp(ctx, 12), dp(ctx, 12))
        setOnClickListener {
            val names = AudioFormats.ALL.map { ctx.getString(it.label) }.toTypedArray()
            android.app.AlertDialog.Builder(ctx)
                .setTitle(R.string.aud_format)
                .setSingleChoiceItems(names, AudioCfg.exportFmt) { d, i ->
                    AudioCfg.exportFmt = i
                    AudioCfg.save(ctx)
                    paint()
                    d.dismiss()
                }
                .show()
        }
    }
    paint()
    return b
}
