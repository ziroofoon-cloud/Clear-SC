package app.clearoverlay

import android.content.Context
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

/**
 * The sound-enhancer settings (on/off, quick presets, five sliders). Used by the music screen and by the video
 * player's dialog. Everything applies live because the audio processor reads [AudioCfg] on every block.
 * Call [AudioCfg.load] before building it.
 */
fun buildAudioPanel(ctx: Context): View {
    val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    fun gap(v: Int) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(ctx, v) }

    var syncing = false
    val bars = ArrayList<SeekBar>()
    val labels = ArrayList<TextView>()
    val chips = ArrayList<TextView>()

    val sw: Switch = panelSwitch(ctx, ctx.getString(R.string.aud_enhance), AudioCfg.on) { on ->
        if (!syncing) {
            AudioCfg.on = on
            AudioCfg.save(ctx)
        }
    }
    sw.textSize = 15f
    col.addView(sw)
    col.addView(Ui.text(ctx, ctx.getString(R.string.aud_hint), 12f, Ui.MUTED), gap(4))

    // ---- presets
    col.addView(Ui.text(ctx, ctx.getString(R.string.aud_presets), 12f, Ui.MUTED), gap(12))
    val presetRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
    val presetNames = listOf(R.string.aud_p_music, R.string.aud_p_video, R.string.aud_p_podcast, R.string.aud_p_asmr, R.string.aud_p_custom)

    fun paintChips() {
        val r = dp(ctx, 10).toFloat()
        chips.forEachIndexed { i, c ->
            if (i == AudioCfg.preset) {
                c.background = Ui.gradient(r)
                c.setTextColor(Ui.BG)
            } else {
                c.background = Ui.round(Ui.CHIP, r)
                c.setTextColor(Ui.MUTED)
            }
        }
    }

    // ---- sliders
    class Row(val label: Int, val get: () -> Float, val set: (Float) -> Unit)
    val rows = listOf(
        Row(R.string.aud_clarity, { AudioCfg.clarity }, { AudioCfg.clarity = it }),
        Row(R.string.aud_bass, { AudioCfg.bass }, { AudioCfg.bass = it }),
        Row(R.string.aud_width, { AudioCfg.width }, { AudioCfg.width = it }),
        Row(R.string.aud_loud, { AudioCfg.loud }, { AudioCfg.loud = it }),
        Row(R.string.aud_voice, { AudioCfg.voice }, { AudioCfg.voice = it })
    )

    fun syncBars() {
        syncing = true
        rows.forEachIndexed { i, row ->
            val pct = (row.get() * 100).toInt().coerceIn(0, 100)
            bars[i].progress = pct
            labels[i].text = ctx.getString(row.label) + "  " + pct + "%"
        }
        if (sw.isChecked != AudioCfg.on) sw.isChecked = AudioCfg.on
        paintChips()
        syncing = false
    }

    presetNames.forEachIndexed { i, res ->
        val c = TextView(ctx).apply {
            text = ctx.getString(res)
            textSize = 12f
            gravity = Gravity.CENTER
            maxLines = 1
            setPadding(dp(ctx, 4), dp(ctx, 9), dp(ctx, 4), dp(ctx, 9))
            setOnClickListener {
                if (i == AudioCfg.CUSTOM) {
                    AudioCfg.preset = AudioCfg.CUSTOM
                } else {
                    AudioCfg.applyPreset(i)
                    AudioCfg.on = true
                }
                AudioCfg.save(ctx)
                syncBars()
            }
        }
        chips.add(c)
        presetRow.addView(c, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            if (i > 0) marginStart = dp(ctx, 5)
        })
    }
    col.addView(presetRow, gap(6))

    rows.forEachIndexed { i, row ->
        val label = Ui.text(ctx, "", 14f)
        val bar = SeekBar(ctx).apply {
            max = 100
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    if (syncing || !fromUser) return
                    row.set(p / 100f)
                    AudioCfg.preset = AudioCfg.CUSTOM
                    labels[i].text = ctx.getString(row.label) + "  " + p + "%"
                    paintChips()
                }

                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {
                    AudioCfg.save(ctx)
                }
            })
        }
        labels.add(label)
        bars.add(bar)
        col.addView(label, gap(if (i == 0) 14 else 8))
        col.addView(bar, gap(2))
    }
    syncBars()
    return col
}
