package app.clearoverlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.view.View

/**
 * The +CRSC logo: a bold plus (sharpening "+") over a dark gradient, with a few pixel squares
 * that shrink toward the corner (pixels getting finer = resolution). Drawn in code so the same
 * artwork serves the app header and the floating bubble.
 */
class LogoView(ctx: Context) : View(ctx) {
    var circle = false
    var active = true
        set(v) {
            field = v
            invalidate()
        }

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val r = RectF()
    private val sheen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val clip = android.graphics.Path()
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat()
        if (s <= 0f) return

        // body: dark gradient, a soft light from the top-left and a thin bright edge
        bg.shader = LinearGradient(0f, 0f, s, s, intArrayOf(0xFF070B18.toInt(), 0xFF1E1B5C.toInt(), 0xFF4C3AB0.toInt()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        glow.shader = android.graphics.RadialGradient(s * 0.3f, s * 0.22f, s * 0.75f, 0x40FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        if (circle) {
            val rad = s / 2f - s * 0.03f
            c.drawCircle(s / 2f, s / 2f, rad, bg)
            c.drawCircle(s / 2f, s / 2f, rad, glow)
            ring.strokeWidth = s * 0.06f
            ring.color = if (active) 0xFF22D3EE.toInt() else 0xFF64748B.toInt()
            c.drawCircle(s / 2f, s / 2f, rad, ring)
        } else {
            val inset = s * 0.02f
            r.set(inset, inset, s - inset, s - inset)
            c.drawRoundRect(r, s * 0.24f, s * 0.24f, bg)
            c.drawRoundRect(r, s * 0.24f, s * 0.24f, glow)
            edge.strokeWidth = s * 0.02f
            edge.color = if (active) 0x6622D3EE else 0x3394A3B8
            c.drawRoundRect(r, s * 0.24f, s * 0.24f, edge)
        }

        // glossy sheen over the upper half (clipped to the body shape)
        sheen.shader = LinearGradient(0f, 0f, 0f, s * 0.55f, 0x33FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        c.save()
        if (circle) {
            c.clipPath(clip.also { it.reset(); it.addCircle(s / 2f, s / 2f, s / 2f - s * 0.03f, android.graphics.Path.Direction.CW) })
        } else {
            val inset2 = s * 0.02f
            r.set(inset2, inset2, s - inset2, s - inset2)
            c.clipPath(clip.also { it.reset(); it.addRoundRect(r, s * 0.24f, s * 0.24f, android.graphics.Path.Direction.CW) })
        }
        c.drawRect(0f, 0f, s, s * 0.55f, sheen)
        c.restore()

        // same mark as the launcher icon: gradient ring + rounded white plus with a soft shadow
        val on = active
        ringP.style = Paint.Style.STROKE
        ringP.strokeWidth = s * 0.034f
        ringP.shader = if (on) LinearGradient(s * 0.2f, s * 0.2f, s * 0.8f, s * 0.8f, 0xFF67E8F9.toInt(), 0xFFA78BFA.toInt(), Shader.TileMode.CLAMP)
        else LinearGradient(s * 0.2f, s * 0.2f, s * 0.8f, s * 0.8f, 0xFF94A3B8.toInt(), 0xFF64748B.toInt(), Shader.TileMode.CLAMP)
        c.drawCircle(s / 2f, s / 2f, s * 0.31f, ringP)
        plusP.style = Paint.Style.STROKE
        plusP.strokeCap = Paint.Cap.ROUND
        plusP.strokeWidth = s * 0.07f
        val h = s * 0.125f
        plusP.color = 0x44000000
        c.drawLine(s / 2f, s / 2f - h + s * 0.012f, s / 2f, s / 2f + h + s * 0.012f, plusP)
        c.drawLine(s / 2f - h, s / 2f + s * 0.012f, s / 2f + h, s / 2f + s * 0.012f, plusP)
        plusP.color = if (on) 0xFFFFFFFF.toInt() else 0xFFE2E8F0.toInt()
        c.drawLine(s / 2f, s / 2f - h, s / 2f, s / 2f + h, plusP)
        c.drawLine(s / 2f - h, s / 2f, s / 2f + h, s / 2f, plusP)
    }

    private val ringP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val plusP = Paint(Paint.ANTI_ALIAS_FLAG)

    private companion object {
        const val D = 0.235f
    }

}
