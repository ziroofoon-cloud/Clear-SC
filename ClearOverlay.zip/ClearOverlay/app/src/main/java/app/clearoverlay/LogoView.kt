package app.clearoverlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.view.View

/**
 * The +CRSC logo: a bold plus (sharpening "+") over a dark gradient, with a few pixel squares
 * that shrink toward the corner (pixels getting finer = resolution). Drawn in code so the same
 * artwork serves the app header and the floating bubble.
 */
class LogoView(ctx: Context) : View(ctx) {
    var circle = false
    var active = true
        set(v) {
            field = v
            invalidate()
        }

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val plus = Paint(Paint.ANTI_ALIAS_FLAG)
    private val px = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
    private val r = RectF()

    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat()
        if (s <= 0f) return

        // body: dark gradient, a soft light from the top-left and a thin bright edge
        bg.shader = LinearGradient(0f, 0f, s, s, 0xFF0B1020.toInt(), 0xFF3B2F8F.toInt(), Shader.TileMode.CLAMP)
        glow.shader = android.graphics.RadialGradient(s * 0.3f, s * 0.22f, s * 0.75f, 0x40FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        if (circle) {
            val rad = s / 2f - s * 0.03f
            c.drawCircle(s / 2f, s / 2f, rad, bg)
            c.drawCircle(s / 2f, s / 2f, rad, glow)
            ring.strokeWidth = s * 0.06f
            ring.color = if (active) 0xFF22D3EE.toInt() else 0xFF64748B.toInt()
            c.drawCircle(s / 2f, s / 2f, rad, ring)
        } else {
            val inset = s * 0.02f
            r.set(inset, inset, s - inset, s - inset)
            c.drawRoundRect(r, s * 0.24f, s * 0.24f, bg)
            c.drawRoundRect(r, s * 0.24f, s * 0.24f, glow)
            edge.strokeWidth = s * 0.02f
            edge.color = if (active) 0x6622D3EE else 0x3394A3B8
            c.drawRoundRect(r, s * 0.24f, s * 0.24f, edge)
        }

        // the sharpening "+", centred
        plus.shader = if (active) {
            LinearGradient(0f, 0f, s, s, 0xFF67E8F9.toInt(), 0xFFA78BFA.toInt(), Shader.TileMode.CLAMP)
        } else {
            LinearGradient(0f, 0f, s, s, 0xFF94A3B8.toInt(), 0xFF64748B.toInt(), Shader.TileMode.CLAMP)
        }
        val t = s * 0.15f
        val l = s * 0.25f
        val cr = t * 0.34f
        r.set(s / 2f - t / 2f, s / 2f - l, s / 2f + t / 2f, s / 2f + l)
        c.drawRoundRect(r, cr, cr, plus)
        r.set(s / 2f - l, s / 2f - t / 2f, s / 2f + l, s / 2f + t / 2f)
        c.drawRoundRect(r, cr, cr, plus)

        // resolution motif: one pixel in each corner around the plus, getting finer, all inside the safe circle
        // (so the round bubble and its ring never cut them)
        val a = if (active) 1f else 0.45f
        sq(c, s, 0.210f, 0.210f, 0.135f, (215 * a).toInt())
        sq(c, s, 0.696f, 0.210f, 0.094f, (185 * a).toInt())
        sq(c, s, 0.210f, 0.696f, 0.094f, (185 * a).toInt())
        sq(c, s, 0.729f, 0.729f, 0.061f, (150 * a).toInt())
    }

    private fun sq(c: Canvas, s: Float, x: Float, y: Float, size: Float, alpha: Int) {
        px.alpha = alpha.coerceIn(0, 255)
        r.set(s * x, s * y, s * (x + size), s * (y + size))
        c.drawRoundRect(r, s * size * 0.18f, s * size * 0.18f, px)
    }
}
