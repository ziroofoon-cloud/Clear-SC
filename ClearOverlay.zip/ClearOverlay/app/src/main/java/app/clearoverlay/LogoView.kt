package app.clearoverlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.view.View

/**
 * The +CRSC logo: a bold plus (sharpening "+") over a dark gradient, with a few pixel squares
 * that shrink toward the corner (pixels getting finer = resolution). Drawn in code so the same
 * artwork serves the app header and the floating bubble.
 */
class LogoView(ctx: Context) : View(ctx) {
    var circle = false
    var active = true
        set(v) {
            field = v
            invalidate()
        }

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val r = RectF()
    private val sheen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val clip = android.graphics.Path()
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat()
        if (s <= 0f) return

        // body: dark gradient, a soft light from the top-left and a thin bright edge
        bg.shader = LinearGradient(0f, 0f, s, s, intArrayOf(0xFF070B18.toInt(), 0xFF1E1B5C.toInt(), 0xFF4C3AB0.toInt()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        glow.shader = android.graphics.RadialGradient(s * 0.3f, s * 0.22f, s * 0.75f, 0x40FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        if (circle) {
            val rad = s / 2f - s * 0.03f
            c.drawCircle(s / 2f, s / 2f, rad, bg)
            c.drawCircle(s / 2f, s / 2f, rad, glow)
            ring.strokeWidth = s * 0.06f
            ring.color = if (active) 0xFF22D3EE.toInt() else 0xFF64748B.toInt()
            c.drawCircle(s / 2f, s / 2f, rad, ring)
        } else {
            val inset = s * 0.02f
            r.set(inset, inset, s - inset, s - inset)
            c.drawRoundRect(r, s * 0.24f, s * 0.24f, bg)
            c.drawRoundRect(r, s * 0.24f, s * 0.24f, glow)
            edge.strokeWidth = s * 0.02f
            edge.color = if (active) 0x6622D3EE else 0x3394A3B8
            c.drawRoundRect(r, s * 0.24f, s * 0.24f, edge)
        }

        // glossy sheen over the upper half (clipped to the body shape)
        sheen.shader = LinearGradient(0f, 0f, 0f, s * 0.55f, 0x33FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        c.save()
        if (circle) {
            c.clipPath(clip.also { it.reset(); it.addCircle(s / 2f, s / 2f, s / 2f - s * 0.03f, android.graphics.Path.Direction.CW) })
        } else {
            val inset2 = s * 0.02f
            r.set(inset2, inset2, s - inset2, s - inset2)
            c.clipPath(clip.also { it.reset(); it.addRoundRect(r, s * 0.24f, s * 0.24f, android.graphics.Path.Direction.CW) })
        }
        c.drawRect(0f, 0f, s, s * 0.55f, sheen)
        c.restore()

        // same mark as the launcher icon: a glass orb (bevel ring, dome, rim light, gloss) with a raised plus that has a thickness.
        // The numbers are the ones of ic_launcher_fg.xml (a 108 grid), scaled by k around the middle.
        val on = active
        val k = s / 108f * 1.2f
        fun x(v: Float) = s / 2f + (v - 54f) * k
        fun y(v: Float) = s / 2f + (v - 54f) * k
        // soft shadow under the orb (a flattened circle)
        c.save()
        c.scale(1f, 0.28f, x(54f), y(80f))
        orbP.shader = android.graphics.RadialGradient(x(54f), y(80f), 20f * k, 0x8C000000.toInt(), 0x00000000, Shader.TileMode.CLAMP)
        c.drawCircle(x(54f), y(80f), 20f * k, orbP)
        c.restore()
        // bevel ring: light from the top-left, cyan to violet to deep violet (grey when the app is off)
        orbP.shader = if (on) LinearGradient(x(34f), y(30f), x(74f), y(80f), intArrayOf(0xFFE6FBFF.toInt(), 0xFF67E8F9.toInt(), 0xFFA78BFA.toInt(), 0xFF4C3AB0.toInt()), floatArrayOf(0f, 0.35f, 0.7f, 1f), Shader.TileMode.CLAMP)
        else LinearGradient(x(34f), y(30f), x(74f), y(80f), intArrayOf(0xFFF1F5F9.toInt(), 0xFFCBD5E1.toInt(), 0xFF94A3B8.toInt(), 0xFF475569.toInt()), floatArrayOf(0f, 0.35f, 0.7f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(x(54f), y(52f), 27f * k, orbP)
        // dome
        orbP.shader = android.graphics.RadialGradient(x(46f), y(44f), 34f * k,
            if (on) intArrayOf(0xFF7C6CF0.toInt(), 0xFF3A2F9E.toInt(), 0xFF0E0B3A.toInt()) else intArrayOf(0xFF64748B.toInt(), 0xFF334155.toInt(), 0xFF0F172A.toInt()),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(x(54f), y(52f), 23.6f * k, orbP)
        // rim light at the lower edge
        if (on) {
            orbP.shader = android.graphics.RadialGradient(x(54f), y(52f), 24f * k, intArrayOf(0x0022D3EE, 0x0022D3EE, 0x8C22D3EE.toInt()), floatArrayOf(0f, 0.78f, 1f), Shader.TileMode.CLAMP)
            c.drawCircle(x(54f), y(52f), 23.6f * k, orbP)
        }
        // gloss spot
        c.save()
        c.rotate(-28f, x(45f), y(38f))
        orbP.shader = LinearGradient(0f, y(31.5f), 0f, y(44.5f), 0xBFFFFFFF.toInt(), 0x00FFFFFF, Shader.TileMode.CLAMP)
        r.set(x(33f), y(31.5f), x(57f), y(44.5f))
        c.drawOval(r, orbP)
        c.restore()
        // the plus: shadow, thickness, face
        plusP.style = Paint.Style.STROKE
        plusP.strokeCap = Paint.Cap.ROUND
        plusP.strokeWidth = 8f * k
        plusP.shader = null
        plusP.color = 0x8C06051F.toInt()
        c.drawLine(x(54.5f), y(43f), x(54.5f), y(64f), plusP)
        c.drawLine(x(44f), y(53.5f), x(65f), y(53.5f), plusP)
        plusP.color = if (on) 0xFF8E9BEF.toInt() else 0xFF94A3B8.toInt()
        c.drawLine(x(54f), y(40.5f), x(54f), y(62.5f), plusP)
        c.drawLine(x(43f), y(51.5f), x(65f), y(51.5f), plusP)
        plusP.shader = LinearGradient(0f, y(40f), 0f, y(68f), 0xFFFFFFFF.toInt(), if (on) 0xFFBCC8FF.toInt() else 0xFFCBD5E1.toInt(), Shader.TileMode.CLAMP)
        c.drawLine(x(54f), y(39.5f), x(54f), y(60.5f), plusP)
        c.drawLine(x(43f), y(50.5f), x(65f), y(50.5f), plusP)
    }

    private val orbP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val plusP = Paint(Paint.ANTI_ALIAS_FLAG)

    private companion object {
        const val D = 0.235f
    }

}
