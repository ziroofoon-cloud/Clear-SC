package app.clearoverlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

/**
 * The +CRSC logo, flat and matte (no gloss, shadow or gradient): a dark body with a thin accent edge, a bold plus (sharpening) and three pixel
 * squares that get smaller toward the corner (pixels getting finer = resolution). The numbers are the ones of ic_launcher_fg.xml (a 108 grid).
 * Drawn in code so the same artwork serves the app header and the floating bubble ([active] = false: the grey version).
 */
class LogoView(ctx: Context) : View(ctx) {
    var circle = false
    var active = true
        set(v) {
            field = v
            invalidate()
        }

    private val body = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val ink = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat()
        if (s <= 0f) return
        val on = active

        // body: one flat colour and a thin solid edge
        body.color = 0xFF0B0F26.toInt()
        edge.color = if (on) 0xFF22D3EE.toInt() else 0xFF64748B.toInt()
        if (circle) {
            val rad = s / 2f - s * 0.03f
            c.drawCircle(s / 2f, s / 2f, rad, body)
            edge.strokeWidth = s * 0.05f
            c.drawCircle(s / 2f, s / 2f, rad - edge.strokeWidth / 2f, edge)
        } else {
            val inset = s * 0.02f
            r.set(inset, inset, s - inset, s - inset)
            c.drawRoundRect(r, s * 0.22f, s * 0.22f, body)
            edge.strokeWidth = s * 0.025f
            val h = edge.strokeWidth / 2f
            r.set(inset + h, inset + h, s - inset - h, s - inset - h)
            c.drawRoundRect(r, s * 0.22f - h, s * 0.22f - h, edge)
        }

        // the mark: a plus and three squares, flat
        val k = s / 108f * 1.25f
        fun x(v: Float) = s / 2f + (v - 54f) * k
        fun y(v: Float) = s / 2f + (v - 54f) * k
        ink.color = if (on) 0xFFF3F5FA.toInt() else 0xFFCBD5E1.toInt()
        r.set(x(31f), y(42f), x(63f), y(52f)); c.drawRect(r, ink) // the bar across
        r.set(x(42f), y(31f), x(52f), y(63f)); c.drawRect(r, ink) // the bar down
        ink.color = if (on) 0xFF22D3EE.toInt() else 0xFF64748B.toInt()
        r.set(x(59f), y(59f), x(66f), y(66f)); c.drawRect(r, ink)
        r.set(x(68f), y(68f), x(72.5f), y(72.5f)); c.drawRect(r, ink)
        r.set(x(74.5f), y(74.5f), x(77f), y(77f)); c.drawRect(r, ink)
    }
}
