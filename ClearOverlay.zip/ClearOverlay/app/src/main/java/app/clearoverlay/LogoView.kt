package app.clearoverlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.view.View

/**
 * The +CRSC logo: a bold plus (sharpening "+") over a dark gradient, with a few pixel squares
 * that shrink toward the corner (pixels getting finer = resolution). Drawn in code so the same
 * artwork serves the app header and the floating bubble.
 */
class LogoView(ctx: Context) : View(ctx) {
    var circle = false
    var active = true
        set(v) {
            field = v
            invalidate()
        }

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val plus = Paint(Paint.ANTI_ALIAS_FLAG)
    private val px = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
    private val r = RectF()
    private val shade = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sheen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val clip = android.graphics.Path()
    private val side = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hi = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat()
        if (s <= 0f) return

        // body: dark gradient, a soft light from the top-left and a thin bright edge
        bg.shader = LinearGradient(0f, 0f, s, s, intArrayOf(0xFF070B18.toInt(), 0xFF1E1B5C.toInt(), 0xFF4C3AB0.toInt()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        glow.shader = android.graphics.RadialGradient(s * 0.3f, s * 0.22f, s * 0.75f, 0x40FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        if (circle) {
            val rad = s / 2f - s * 0.03f
            c.drawCircle(s / 2f, s / 2f, rad, bg)
            c.drawCircle(s / 2f, s / 2f, rad, glow)
            ring.strokeWidth = s * 0.06f
            ring.color = if (active) 0xFF22D3EE.toInt() else 0xFF64748B.toInt()
            c.drawCircle(s / 2f, s / 2f, rad, ring)
        } else {
            val inset = s * 0.02f
            r.set(inset, inset, s - inset, s - inset)
            c.drawRoundRect(r, s * 0.24f, s * 0.24f, bg)
            c.drawRoundRect(r, s * 0.24f, s * 0.24f, glow)
            edge.strokeWidth = s * 0.02f
            edge.color = if (active) 0x6622D3EE else 0x3394A3B8
            c.drawRoundRect(r, s * 0.24f, s * 0.24f, edge)
        }

        // glossy sheen over the upper half (clipped to the body shape)
        sheen.shader = LinearGradient(0f, 0f, 0f, s * 0.55f, 0x33FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        c.save()
        if (circle) {
            c.clipPath(clip.also { it.reset(); it.addCircle(s / 2f, s / 2f, s / 2f - s * 0.03f, android.graphics.Path.Direction.CW) })
        } else {
            val inset2 = s * 0.02f
            r.set(inset2, inset2, s - inset2, s - inset2)
            c.clipPath(clip.also { it.reset(); it.addRoundRect(r, s * 0.24f, s * 0.24f, android.graphics.Path.Direction.CW) })
        }
        c.drawRect(0f, 0f, s, s * 0.55f, sheen)
        c.restore()

        // the sharpening "+", centred
        plus.shader = if (active) {
            LinearGradient(0f, 0f, s, s, 0xFF67E8F9.toInt(), 0xFFA78BFA.toInt(), Shader.TileMode.CLAMP)
        } else {
            LinearGradient(0f, 0f, s, s, 0xFF94A3B8.toInt(), 0xFF64748B.toInt(), Shader.TileMode.CLAMP)
        }
        val t = s * 0.15f
        val l = s * 0.25f
        val cr = t * 0.34f
        val dx = s * 0.012f // depth of the 3D "+": a darker copy behind, shifted down-right, plus a soft shadow under it
        val dy = s * 0.016f
        fun drawPlus(p: Paint, ox: Float, oy: Float) {
            r.set(s / 2f - t / 2f + ox, s / 2f - l + oy, s / 2f + t / 2f + ox, s / 2f + l + oy)
            c.drawRoundRect(r, cr, cr, p)
            r.set(s / 2f - l + ox, s / 2f - t / 2f + oy, s / 2f + l + ox, s / 2f + t / 2f + oy)
            c.drawRoundRect(r, cr, cr, p)
        }
        shade.color = 0xFF000000.toInt()
        shade.alpha = if (active) 90 else 50
        shade.setShadowLayer(s * 0.035f, 0f, s * 0.02f, 0x99000000.toInt())
        drawPlus(shade, dx * 1.6f, dy * 1.6f)
        side.color = if (active) 0xFF5B3FC4.toInt() else 0xFF475569.toInt()
        drawPlus(side, dx, dy)
        drawPlus(plus, 0f, 0f)
        // a thin light edge on the top-left of the face
        hi.strokeWidth = s * 0.006f
        hi.color = 0x66FFFFFF
        r.set(s / 2f - t / 2f, s / 2f - l, s / 2f + t / 2f, s / 2f + l)
        c.drawRoundRect(r, cr, cr, hi)
        r.set(s / 2f - l, s / 2f - t / 2f, s / 2f + l, s / 2f + t / 2f)
        c.drawRoundRect(r, cr, cr, hi)

        // resolution motif: one pure white pixel in each corner around the plus, getting finer, all inside the safe circle
        // (so the round bubble and its ring never cut them); each has a soft shadow so it floats above the body
        val a = if (active) 1f else 0.55f
        px.setShadowLayer(s * 0.02f, s * 0.006f, s * 0.012f, 0x80000000.toInt())
        // the four squares keep their sizes; their centres sit on two horizontal and two vertical lines (equal distance from the plus)
        sqc(c, s, 0.5f - D, 0.5f - D, 0.135f, (255 * a).toInt())
        sqc(c, s, 0.5f + D, 0.5f - D, 0.094f, (255 * a).toInt())
        sqc(c, s, 0.5f - D, 0.5f + D, 0.094f, (255 * a).toInt())
        sqc(c, s, 0.5f + D, 0.5f + D, 0.061f, (255 * a).toInt())
    }

    private fun sqc(c: Canvas, s: Float, cx: Float, cy: Float, size: Float, alpha: Int) = sq(c, s, cx - size / 2f, cy - size / 2f, size, alpha)

    private companion object {
        const val D = 0.235f
    }

    private fun sq(c: Canvas, s: Float, x: Float, y: Float, size: Float, alpha: Int) {
        px.alpha = alpha.coerceIn(0, 255)
        r.set(s * x, s * y, s * (x + size), s * (y + size))
        c.drawRoundRect(r, s * size * 0.18f, s * size * 0.18f, px)
    }
}
