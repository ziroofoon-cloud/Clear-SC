package app.clearoverlay

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.view.View

/**
 * The +CRSC logo, in the four looks the person can choose in "App and data" ([Cfg.logoStyle]; 0 = automatic):
 *  1 classic        flat navy body with a thin cyan edge, white plus, cyan squares (the logo before 3.99.297)
 *  2 classic light  the same, flat light body, navy plus
 *  3 soft dark      matte with a very soft depth (diffuse light only: no gloss, no hard shadow): navy body, white plus
 *  4 soft light     the same on a light body, navy plus
 * Automatic = soft dark in dark mode, soft light in light mode ([Ui.light]: the phone's mode, or the choice in the settings).
 * The soft looks are two pictures (res/drawable-nodpi/logo_mark_dark.png / logo_mark_light.png, the ones the launcher icon uses) on a body drawn in code.
 * Used by the app header, the floating bubble, the panel title ([active] = false: grey) and the picker ([style] >= 0 draws that look whatever is chosen).
 */
class LogoView(ctx: Context) : View(ctx) {
    var circle = false
    var active = true
        set(v) {
            field = v
            invalidate()
        }
    /** -1 = the look chosen in the settings; 0..4 = that look (the picker's tiles). */
    var style = -1
        set(v) {
            field = v
            invalidate()
        }

    private val body = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val ink = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pic = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG)
    private val grey = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0f) })
    private val r = RectF()
    private val from = Rect()
    private var shaderFor = 0 // size + look the body gradient was made for (0 = none)

    private companion object {
        // the two pictures are decoded once and shared by every LogoView
        @Volatile var lightBmp: Bitmap? = null
        @Volatile var darkBmp: Bitmap? = null
    }

    private fun mark(light: Boolean): Bitmap? {
        val have = if (light) lightBmp else darkBmp
        if (have != null) return have
        val b = BitmapFactory.decodeResource(resources, if (light) R.drawable.logo_mark_light else R.drawable.logo_mark_dark)
        if (light) lightBmp = b else darkBmp = b
        return b
    }

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat()
        if (s <= 0f) return
        val want = if (style >= 0) style else Cfg.logoStyle
        val look = if (want == 0) (if (Ui.light) 4 else 3) else want // 1 classic, 2 classic light, 3 soft dark, 4 soft light
        if (look <= 2) drawClassic(c, s, look == 2) else drawSoft(c, s, look == 4)
    }

    /** The flat logo: one colour body with a thin solid edge, the plus and three squares, no depth at all. */
    private fun drawClassic(c: Canvas, s: Float, light: Boolean) {
        val on = active
        body.shader = null
        body.alpha = 255
        body.color = if (light) 0xFFEEF1F8.toInt() else 0xFF0B0F26.toInt()
        val cyan = if (light) 0xFF0EA5C4.toInt() else 0xFF22D3EE.toInt()
        edge.color = if (on) cyan else 0xFF64748B.toInt()
        if (circle) {
            val rad = s / 2f - s * 0.03f
            c.drawCircle(s / 2f, s / 2f, rad, body)
            edge.strokeWidth = s * 0.05f
            c.drawCircle(s / 2f, s / 2f, rad - edge.strokeWidth / 2f, edge)
        } else {
            val inset = s * 0.02f
            r.set(inset, inset, s - inset, s - inset)
            c.drawRoundRect(r, s * 0.22f, s * 0.22f, body)
            edge.strokeWidth = s * 0.025f
            val h = edge.strokeWidth / 2f
            r.set(inset + h, inset + h, s - inset - h, s - inset - h)
            c.drawRoundRect(r, s * 0.22f - h, s * 0.22f - h, edge)
        }
        val k = s / 108f * 1.25f
        fun x(v: Float) = s / 2f + (v - 54f) * k
        fun y(v: Float) = s / 2f + (v - 54f) * k
        ink.color = if (on) (if (light) 0xFF0B0F26.toInt() else 0xFFF3F5FA.toInt()) else (if (light) 0xFF64748B.toInt() else 0xFFCBD5E1.toInt())
        r.set(x(31f), y(42f), x(63f), y(52f)); c.drawRect(r, ink) // the bar across
        r.set(x(42f), y(31f), x(52f), y(63f)); c.drawRect(r, ink) // the bar down
        ink.color = if (on) cyan else 0xFF64748B.toInt()
        r.set(x(59f), y(59f), x(66f), y(66f)); c.drawRect(r, ink)
        r.set(x(68f), y(68f), x(72.5f), y(72.5f)); c.drawRect(r, ink)
        r.set(x(74.5f), y(74.5f), x(77f), y(77f)); c.drawRect(r, ink)
    }

    /** The soft look: a body with a faint diagonal tone (no edge line, no bevel) and the mark picture on it. */
    private fun drawSoft(c: Canvas, s: Float, light: Boolean) {
        val key = (s.toInt() shl 1) or (if (light) 1 else 0)
        if (key != shaderFor || body.shader == null) {
            shaderFor = key
            val a = if (light) 0xFFEEF1F8.toInt() else 0xFF121842.toInt()
            val b = if (light) 0xFFDDE2EE.toInt() else 0xFF0A0E27.toInt()
            body.shader = LinearGradient(0f, 0f, s, s, a, b, Shader.TileMode.CLAMP)
        }
        body.alpha = if (active) 255 else 200
        if (circle) {
            c.drawCircle(s / 2f, s / 2f, s / 2f - s * 0.03f, body)
        } else {
            val inset = s * 0.02f
            r.set(inset, inset, s - inset, s - inset)
            c.drawRoundRect(r, s * 0.24f, s * 0.24f, body)
        }
        // the picture covers the 108 grid; drawn 1.25 times as wide as the grid so the mark keeps the size it always had
        val bmp = mark(light) ?: return
        val side = s * 1.25f
        r.set((s - side) / 2f, (s - side) / 2f, (s + side) / 2f, (s + side) / 2f)
        from.set(0, 0, bmp.width, bmp.height)
        pic.colorFilter = if (active) null else grey
        pic.alpha = if (active) 255 else 150
        c.drawBitmap(bmp, from, r, pic)
    }
}
