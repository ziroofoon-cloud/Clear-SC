package app.clearoverlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.view.View

/**
 * The +CRSC logo: a bold plus (sharpening "+") over a dark gradient, with a few pixel squares
 * that shrink toward the corner (pixels getting finer = resolution). Drawn in code so the same
 * artwork serves the app header and the floating bubble.
 */
class LogoView(ctx: Context) : View(ctx) {
    var circle = false
    var active = true
        set(v) {
            field = v
            invalidate()
        }

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val plus = Paint(Paint.ANTI_ALIAS_FLAG)
    private val px = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
    private val r = RectF()

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat()
        if (s <= 0f) return

        bg.shader = LinearGradient(0f, 0f, s, s, 0xFF0B1020.toInt(), 0xFF3B2F8F.toInt(), Shader.TileMode.CLAMP)
        if (circle) {
            val rad = s / 2f - s * 0.03f
            c.drawCircle(s / 2f, s / 2f, rad, bg)
            ring.strokeWidth = s * 0.06f
            ring.color = if (active) 0xFF22D3EE.toInt() else 0xFF64748B.toInt()
            c.drawCircle(s / 2f, s / 2f, rad, ring)
        } else {
            r.set(0f, 0f, s, s)
            c.drawRoundRect(r, s * 0.24f, s * 0.24f, bg)
        }

        plus.shader = if (active) {
            LinearGradient(0f, 0f, s, s, 0xFF67E8F9.toInt(), 0xFFA78BFA.toInt(), Shader.TileMode.CLAMP)
        } else {
            LinearGradient(0f, 0f, s, s, 0xFF94A3B8.toInt(), 0xFF64748B.toInt(), Shader.TileMode.CLAMP)
        }
        val t = s * 0.15f
        val l = s * 0.27f
        val cr = t * 0.3f
        r.set(s / 2f - t / 2f, s / 2f - l, s / 2f + t / 2f, s / 2f + l)
        c.drawRoundRect(r, cr, cr, plus)
        r.set(s / 2f - l, s / 2f - t / 2f, s / 2f + l, s / 2f + t / 2f)
        c.drawRoundRect(r, cr, cr, plus)

        px.alpha = if (active) 190 else 90
        sq(c, s, 0.17f, 0.17f, 0.10f)
        sq(c, s, 0.73f, 0.17f, 0.07f)
        sq(c, s, 0.17f, 0.73f, 0.07f)
        sq(c, s, 0.78f, 0.78f, 0.045f)
    }

    private fun sq(c: Canvas, s: Float, x: Float, y: Float, size: Float) {
        r.set(s * x, s * y, s * (x + size), s * (y + size))
        c.drawRect(r, px)
    }
}
