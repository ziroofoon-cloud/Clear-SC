package app.clearoverlay

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.view.View

/**
 * The +CRSC logo, matte with a very soft depth (no gloss, no hard shadow): a flat body with a faint diagonal tone, the plus and the three squares
 * as one picture (res/drawable-nodpi/logo_mark_light.png / logo_mark_dark.png, the same two pictures the launcher icon uses in light / dark mode).
 * It follows the screen's theme ([Ui.light], which already follows the system, or the choice in the settings): light body + dark plus, or dark body + white plus.
 * Drawn in code so the same artwork serves the app header and the floating bubble ([active] = false: the grey version).
 */
class LogoView(ctx: Context) : View(ctx) {
    var circle = false
    var active = true
        set(v) {
            field = v
            invalidate()
        }

    private val body = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pic = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG)
    private val grey = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0f) })
    private val r = RectF()
    private val from = Rect()
    private var shaderFor = 0 // size + theme the body gradient was made for (0 = none)

    private companion object {
        // the two pictures are decoded once and shared by every LogoView
        @Volatile var lightBmp: Bitmap? = null
        @Volatile var darkBmp: Bitmap? = null
    }

    private fun mark(light: Boolean): Bitmap? {
        val have = if (light) lightBmp else darkBmp
        if (have != null) return have
        val b = BitmapFactory.decodeResource(resources, if (light) R.drawable.logo_mark_light else R.drawable.logo_mark_dark)
        if (light) lightBmp = b else darkBmp = b
        return b
    }

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat()
        if (s <= 0f) return
        val light = Ui.light

        // body: one matte colour with a faint diagonal tone, no edge line, no bevel
        val key = (s.toInt() shl 1) or (if (light) 1 else 0)
        if (key != shaderFor) {
            shaderFor = key
            val a = if (light) 0xFFEEF1F8.toInt() else 0xFF121842.toInt()
            val b = if (light) 0xFFDDE2EE.toInt() else 0xFF0A0E27.toInt()
            body.shader = LinearGradient(0f, 0f, s, s, a, b, Shader.TileMode.CLAMP)
        }
        body.alpha = if (active) 255 else 200
        if (circle) {
            c.drawCircle(s / 2f, s / 2f, s / 2f - s * 0.03f, body)
        } else {
            val inset = s * 0.02f
            r.set(inset, inset, s - inset, s - inset)
            c.drawRoundRect(r, s * 0.24f, s * 0.24f, body)
        }

        // the mark: the picture covers the 108 grid, drawn 1.25 times as big as the grid is wide so it keeps the size the old flat mark had
        val bmp = mark(light) ?: return
        val side = s * 1.25f
        r.set((s - side) / 2f, (s - side) / 2f, (s + side) / 2f, (s + side) / 2f)
        from.set(0, 0, bmp.width, bmp.height)
        pic.colorFilter = if (active) null else grey
        pic.alpha = if (active) 255 else 150
        c.drawBitmap(bmp, from, r, pic)
    }
}
