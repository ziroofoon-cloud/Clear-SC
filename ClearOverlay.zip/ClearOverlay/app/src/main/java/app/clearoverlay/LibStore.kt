package app.clearoverlay

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Persistent library data: folders the user added by hand (SAF tree URIs) and user categories
 * ("Favorites", or any name) holding videos or photos. Stored as one small JSON string in SharedPreferences.
 */
object LibStore {
    class CustomFolder(val uri: String, val name: String) {
        val id: Long get() = Media.customId(uri)
    }

    class Category(val id: String, var name: String, val kind: Int, val items: LinkedHashSet<String> = LinkedHashSet()) {
        /** The built-in "Favorites" category has an empty stored name; the UI shows a translated one. */
        val builtin: Boolean get() = id == FAV_V || id == FAV_P
    }

    const val FAV_V = "fav_v" // kind 0 = videos
    const val FAV_P = "fav_p" // kind 1 = photos

    private const val PREF = "crsc_library"
    private const val KEY = "data"

    private var folders: MutableList<CustomFolder>? = null
    private var cats: MutableList<Category>? = null
    private var hidden: MutableSet<String>? = null

    @Synchronized
    private fun load(ctx: Context) {
        if (folders != null && cats != null) return
        val f = ArrayList<CustomFolder>()
        val c = ArrayList<Category>()
        val h = LinkedHashSet<String>()
        runCatching {
            val s = ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, null)
            if (s != null) {
                val o = JSONObject(s)
                o.optJSONArray("folders")?.let { a ->
                    for (i in 0 until a.length()) a.getJSONObject(i).let { f.add(CustomFolder(it.getString("uri"), it.optString("name", "?"))) }
                }
                o.optJSONArray("hidden")?.let { a -> for (i in 0 until a.length()) h.add(a.getString(i)) }
                o.optJSONArray("cats")?.let { a ->
                    for (i in 0 until a.length()) {
                        val j = a.getJSONObject(i)
                        val cat = Category(j.getString("id"), j.optString("name"), j.optInt("kind"))
                        j.optJSONArray("items")?.let { it2 -> for (k in 0 until it2.length()) cat.items.add(it2.getString(k)) }
                        c.add(cat)
                    }
                }
            }
        }
        if (c.none { it.id == FAV_V }) c.add(0, Category(FAV_V, "", 0))
        if (c.none { it.id == FAV_P }) c.add(1.coerceAtMost(c.size), Category(FAV_P, "", 1))
        folders = f
        cats = c
        hidden = h
    }

    @Synchronized
    private fun save(ctx: Context) {
        val o = JSONObject()
        o.put("folders", JSONArray().also { a -> folders?.forEach { a.put(JSONObject().put("uri", it.uri).put("name", it.name)) } })
        o.put("hidden", JSONArray(hidden?.toList() ?: emptyList<String>()))
        o.put("cats", JSONArray().also { a ->
            cats?.forEach { c ->
                a.put(JSONObject().put("id", c.id).put("name", c.name).put("kind", c.kind).put("items", JSONArray(c.items.toList())))
            }
        })
        ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, o.toString()).apply()
    }

    // ---- folders ------------------------------------------------------------------------------

    @Synchronized fun folders(ctx: Context): List<CustomFolder> { load(ctx); return folders!!.toList() }

    /** @return false when this folder is already in the list. */
    @Synchronized fun addFolder(ctx: Context, uri: String, name: String): Boolean {
        load(ctx)
        if (folders!!.any { it.uri == uri }) return false
        folders!!.add(CustomFolder(uri, name))
        save(ctx)
        return true
    }

    @Synchronized fun removeFolder(ctx: Context, uri: String) {
        load(ctx)
        folders!!.removeAll { it.uri == uri }
        save(ctx)
    }

    // ---- hidden items / folders ---------------------------------------------------------------
    // keys: an item's uri, or "f<tab>:<bucketId>" for a folder (tab 0 videos, 1 photos, 2 manga, 3 gif)

    @Synchronized fun hidden(ctx: Context): Set<String> { load(ctx); return hidden!!.toHashSet() }

    @Synchronized fun hide(ctx: Context, keys: Collection<String>): Int {
        load(ctx)
        val before = hidden!!.size
        hidden!!.addAll(keys)
        save(ctx)
        return hidden!!.size - before
    }

    @Synchronized fun unhide(ctx: Context, keys: Collection<String>): Int {
        load(ctx)
        val before = hidden!!.size
        hidden!!.removeAll(keys.toSet())
        save(ctx)
        return before - hidden!!.size
    }

    // ---- categories ---------------------------------------------------------------------------

    /** Categories of one kind (0 = videos, 1 = photos); the built-in Favorites is always first. */
    @Synchronized fun cats(ctx: Context, kind: Int): List<Category> { load(ctx); return cats!!.filter { it.kind == kind } }

    @Synchronized fun cat(ctx: Context, id: String): Category? { load(ctx); return cats!!.firstOrNull { it.id == id } }

    @Synchronized fun createCat(ctx: Context, kind: Int, name: String): Category {
        load(ctx)
        val c = Category("c" + System.currentTimeMillis() + "_" + (cats!!.size), name.trim(), kind)
        cats!!.add(c)
        save(ctx)
        return c
    }

    @Synchronized fun rename(ctx: Context, id: String, name: String) {
        load(ctx)
        cats!!.firstOrNull { it.id == id && !it.builtin }?.name = name.trim()
        save(ctx)
    }

    @Synchronized fun delete(ctx: Context, id: String) {
        load(ctx)
        cats!!.removeAll { it.id == id && !it.builtin }
        save(ctx)
    }

    @Synchronized fun addTo(ctx: Context, id: String, uris: Collection<String>): Int {
        load(ctx)
        val c = cats!!.firstOrNull { it.id == id } ?: return 0
        val before = c.items.size
        c.items.addAll(uris)
        save(ctx)
        return c.items.size - before
    }

    @Synchronized fun removeFrom(ctx: Context, id: String, uris: Collection<String>) {
        load(ctx)
        cats!!.firstOrNull { it.id == id }?.items?.removeAll(uris.toSet())
        save(ctx)
    }
}
