package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.widget.Toast
import java.io.File

/**
 * What the app keeps on the phone, and cleaning it up:
 *  - unfinished upscales (kept on purpose so they can be continued)  -> filesDir/export
 *  - temporary copies: the last manga archive, unpacked RAR pages, network downloads, subtitles -> cacheDir
 *  - AI models (yours; never deleted here)
 * [autoClean] runs when the app opens, so nothing grows forever by itself.
 */
object Storage {
    private const val DAY = 24L * 3600 * 1000

    fun dirSize(f: File): Long {
        if (!f.exists()) return 0L
        if (f.isFile) return f.length()
        var n = 0L
        f.listFiles()?.forEach { n += dirSize(it) }
        return n
    }

    private fun exportDir(ctx: Context) = File(ctx.filesDir, "export")

    class Usage(val export: Long, val cache: Long, val models: Long) {
        val total get() = export + cache + models
    }

    fun usage(ctx: Context) = Usage(
        dirSize(exportDir(ctx)),
        dirSize(ctx.cacheDir),
        dirSize(File(ctx.filesDir, "models")) + dirSize(File(ctx.filesDir, "builtin_sr.tflite"))
    )

    fun clearExport(ctx: Context) {
        exportDir(ctx).deleteRecursively()
        ExportInfo.clearUnfinished(ctx)
    }

    fun clearCache(ctx: Context) {
        ctx.cacheDir.listFiles()?.forEach { it.deleteRecursively() }
    }

    /** Quietly removes what is old or can be made again. Worker thread; never touches something used a moment ago. */
    fun autoClean(ctx: Context) {
        runCatching {
            val now = System.currentTimeMillis()
            // network downloads: two days, and never more than about 600 MB
            val net = Net.cacheDir(ctx)
            net.listFiles()?.forEach { if (now - it.lastModified() > 2 * DAY) it.delete() }
            var left = net.listFiles()?.sortedBy { it.lastModified() }?.toMutableList() ?: mutableListOf()
            var sum = left.sumOf { it.length() }
            while (sum > 600L * 1024 * 1024 && left.isNotEmpty()) {
                val f = left.removeAt(0)
                sum -= f.length()
                f.delete()
            }
            // the last opened manga archive is kept for a few days so reopening is instant
            File(ctx.cacheDir, "manga_src.bin").let { if (it.exists() && now - it.lastModified() > 3 * DAY) it.delete() }
            // unpacked RAR pages are made again on opening; keep them only if they were used within the last hour
            File(ctx.cacheDir, "manga_rar").let { if (it.exists() && now - it.lastModified() > 3600_000L) it.deleteRecursively() }
            ctx.cacheDir.listFiles()?.forEach { if (it.name.startsWith("sub_") && now - it.lastModified() > DAY) it.delete() }
            // unfinished upscales older than a week
            if (!ExportState.running) {
                VideoExport.cleanStreamLeftovers(ctx) // temporary pieces of a "Watch now" job that was cut short
                exportDir(ctx).listFiles()?.forEach { if (now - it.lastModified() > 7 * DAY) it.deleteRecursively() }
            }
        }
    }

    private fun fmt(b: Long): String = when {
        b >= 1L shl 30 -> String.format(java.util.Locale.US, "%.2f GB", b / 1073741824.0)
        b >= 1L shl 20 -> String.format(java.util.Locale.US, "%.1f MB", b / 1048576.0)
        b >= 1L shl 10 -> String.format(java.util.Locale.US, "%d KB", b shr 10)
        else -> "$b B"
    }

    /** The "Storage & cleanup" dialog: what is used, and a tap on a line clears it. */
    fun show(act: Activity) {
        Thread {
            val u = usage(act)
            act.runOnUiThread {
                if (act.isDestroyed || act.isFinishing) return@runOnUiThread
                val labels = arrayOf(
                    act.getString(R.string.storage_export) + "\n" + fmt(u.export),
                    act.getString(R.string.storage_cache) + "\n" + fmt(u.cache),
                    act.getString(R.string.storage_models) + "\n" + fmt(u.models),
                    act.getString(R.string.storage_clear_all)
                )
                AlertDialog.Builder(act)
                    .setTitle(act.getString(R.string.storage_total_fmt, fmt(u.total)))
                    .setItems(labels) { _, w ->
                        when (w) {
                            0 -> confirm(act, labels[0].substringBefore('\n'), u.export) { clearExport(act) }
                            1 -> confirm(act, labels[1].substringBefore('\n'), u.cache) { clearCache(act) }
                            2 -> Toast.makeText(act, R.string.storage_models_note, Toast.LENGTH_LONG).show()
                            else -> confirm(act, act.getString(R.string.storage_clear_all), u.export + u.cache) {
                                clearExport(act)
                                clearCache(act)
                            }
                        }
                    }
                    .setNegativeButton(android.R.string.cancel, null)
                    .show()
            }
        }.start()
    }

    private fun confirm(act: Activity, what: String, bytes: Long, doIt: () -> Unit) {
        if (ExportState.running) {
            Toast.makeText(act, R.string.storage_busy, Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(act)
            .setMessage(act.getString(R.string.storage_confirm_fmt, what, fmt(bytes)))
            .setPositiveButton(android.R.string.ok) { _, _ ->
                Thread {
                    runCatching { doIt() }
                    act.runOnUiThread {
                        Toast.makeText(act, R.string.storage_cleared, Toast.LENGTH_SHORT).show()
                        if (!act.isDestroyed) show(act)
                    }
                }.start()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }
}
