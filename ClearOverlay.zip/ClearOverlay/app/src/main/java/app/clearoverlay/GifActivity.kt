package app.clearoverlay

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.max

/** Plays animated GIFs (and other animated images) full screen. Swipe sideways or tap the edges for the previous / next one. */
class GifActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private val list = ArrayList<Uri>()
    private var idx = 0
    private var gen = 0
    private var closed = false
    private lateinit var iv: ImageView
    private lateinit var bar: LinearLayout
    private lateinit var titleTv: TextView

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Cfg.load(this)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        intent?.getStringArrayListExtra(PlayerArgs.LIST)?.forEach { list.add(Uri.parse(it)) }
        intent?.data?.let { if (list.isEmpty()) list.add(it) }
        if (list.isEmpty()) {
            finish()
            return
        }
        idx = intent.getIntExtra(PlayerArgs.INDEX, 0).coerceIn(0, list.size - 1)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        iv = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        root.addView(iv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#CC0B1020"))
            setPadding(dp(this@GifActivity, 12), dp(this@GifActivity, 6), dp(this@GifActivity, 8), dp(this@GifActivity, 6))
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        titleTv = Ui.text(this, "", 14f, Ui.TEXT, true).apply {
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        bar.addView(titleTv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(Ui.text(this, "✕", 18f, Ui.ACCENT, true).apply {
            setPadding(dp(this@GifActivity, 12), dp(this@GifActivity, 8), dp(this@GifActivity, 12), dp(this@GifActivity, 8))
            setOnClickListener { finish() }
        })
        root.addView(bar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))
        setContentView(root)
        root.setOnApplyWindowInsetsListener { _, ins ->
            val i = ins.getInsetsIgnoringVisibility(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            bar.setPadding(dp(this, 12) + i.left, dp(this, 6) + i.top, dp(this, 8) + i.right, dp(this, 6))
            ins
        }

        var downX = 0f
        var downY = 0f
        var swiped = false
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                val x = e.x / root.width.coerceAtLeast(1)
                when {
                    x < 0.25f -> step(-1)
                    x > 0.75f -> step(1)
                    else -> bar.visibility = if (bar.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                }
                return true
            }
        })
        root.setOnTouchListener { _, ev ->
            gd.onTouchEvent(ev)
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.x; downY = ev.y; swiped = false
                }
                MotionEvent.ACTION_UP -> {
                    val dx = ev.x - downX
                    val dy = ev.y - downY
                    if (!swiped && abs(dx) > dp(this, 48) && abs(dx) > abs(dy) * 1.2f) {
                        swiped = true
                        step(if (dx < 0) 1 else -1)
                    }
                }
            }
            true
        }
        show()
    }

    private fun step(d: Int) {
        val n = idx + d
        if (n !in 0 until list.size) {
            Toast.makeText(this, getString(if (d > 0) R.string.list_last else R.string.list_first), Toast.LENGTH_SHORT).show()
            return
        }
        idx = n
        show()
    }

    private fun nameOf(u: Uri): String = runCatching {
        contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
    }.getOrNull() ?: (u.lastPathSegment ?: "").substringAfterLast('/')

    private fun show() {
        val mine = ++gen
        val u = list[idx]
        titleTv.text = (if (list.size > 1) "${idx + 1}/${list.size}  " else "") + nameOf(u)
        (iv.drawable as? AnimatedImageDrawable)?.stop()
        Thread {
            val d: Drawable? = runCatching {
                ImageDecoder.decodeDrawable(ImageDecoder.createSource(contentResolver, u)) { dec, info, _ ->
                    val m = max(info.size.width, info.size.height)
                    if (m > 1800) dec.setTargetSampleSize(m / 1800 + 1)
                }
            }.getOrNull()
            ui.post {
                if (closed || mine != gen) return@post
                if (d == null) {
                    Toast.makeText(this, getString(R.string.manga_empty), Toast.LENGTH_SHORT).show()
                    return@post
                }
                iv.setImageDrawable(d)
                if (d is AnimatedImageDrawable) {
                    d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                    d.start()
                }
            }
        }.start()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }
    }

    override fun onDestroy() {
        closed = true
        if (::iv.isInitialized) (iv.drawable as? AnimatedImageDrawable)?.stop()
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
