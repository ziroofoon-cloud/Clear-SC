package app.clearoverlay

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.SurfaceTexture
import android.graphics.ImageDecoder
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Plays animated GIFs (and other animated images) full screen. Swipe sideways or tap the edges for the previous / next one. */
class GifActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private val list = ArrayList<Uri>()
    private var idx = 0
    private var gen = 0
    private var closed = false
    private lateinit var iv: ImageView
    private lateinit var bar: LinearLayout
    private lateinit var titleTv: TextView
    private lateinit var rootView: FrameLayout
    private lateinit var fxBtn: TextView
    private lateinit var fxPanel: ScrollView
    private var fxPanelBuilt = false
    private var tv: TextureView? = null
    private var gl: GlPipeline? = null
    private var outSurface: Surface? = null
    private var inSurface: Surface? = null
    private var curDrawable: Drawable? = null
    private var fxCb: Drawable.Callback? = null

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Cfg.load(this)
        Ui.init(this, forceDark = true)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        intent?.getStringArrayListExtra(PlayerArgs.LIST)?.forEach { list.add(Uri.parse(it)) }
        intent?.data?.let { if (list.isEmpty()) list.add(it) }
        if (list.isEmpty()) {
            finish()
            return
        }
        idx = intent.getIntExtra(PlayerArgs.INDEX, 0).coerceIn(0, list.size - 1)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        rootView = root
        iv = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        root.addView(iv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#CC0B1020"))
            setPadding(dp(this@GifActivity, 12), dp(this@GifActivity, 6), dp(this@GifActivity, 8), dp(this@GifActivity, 6))
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        titleTv = Ui.text(this, "", 14f, Ui.TEXT, true).apply {
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        bar.addView(titleTv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        fxBtn = Ui.text(this, "FX", 16f, Ui.ACCENT, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(this@GifActivity, 12), dp(this@GifActivity, 8), dp(this@GifActivity, 12), dp(this@GifActivity, 8))
            setOnClickListener { setGifFx(!Cfg.gifFx) }
        }
        bar.addView(fxBtn)
        bar.addView(Icons.button(this, Icons.GEAR, sizeDp = 38) { toggleFxPanel() })
        bar.addView(Icons.button(this, Icons.CLOSE, sizeDp = 38) { finish() })
        paintFx()
        fxPanel = ScrollView(this).apply {
            visibility = View.GONE
            isClickable = true
            background = Ui.round(Color.parseColor("#F5101522"), dp(this@GifActivity, 22).toFloat(), Ui.STROKE, dp(this@GifActivity, 1))
            setPadding(dp(this@GifActivity, 14), dp(this@GifActivity, 12), dp(this@GifActivity, 14), dp(this@GifActivity, 12))
        }
        val sh = windowManager.currentWindowMetrics.bounds.height()
        root.addView(
            fxPanel,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (sh * 0.58f).toInt(), Gravity.BOTTOM).apply {
                setMargins(dp(this@GifActivity, 8), 0, dp(this@GifActivity, 8), dp(this@GifActivity, 8))
            }
        )
        root.addView(bar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))
        setContentView(root)
        root.setOnApplyWindowInsetsListener { _, ins ->
            val i = ins.getInsetsIgnoringVisibility(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            bar.setPadding(dp(this, 12) + i.left, dp(this, 6) + i.top, dp(this, 8) + i.right, dp(this, 6))
            ins
        }

        var downX = 0f
        var downY = 0f
        var swiped = false
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                val x = e.x / root.width.coerceAtLeast(1)
                when {
                    x < 0.25f -> step(-1)
                    x > 0.75f -> step(1)
                    else -> bar.visibility = if (bar.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                }
                return true
            }
        })
        root.setOnTouchListener { _, ev ->
            gd.onTouchEvent(ev)
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.x; downY = ev.y; swiped = false
                }
                MotionEvent.ACTION_UP -> {
                    val dx = ev.x - downX
                    val dy = ev.y - downY
                    if (!swiped && abs(dx) > dp(this, 48) && abs(dx) > abs(dy) * 1.2f) {
                        swiped = true
                        step(if (dx < 0) 1 else -1)
                    }
                }
            }
            true
        }
        show()
    }

    private fun step(d: Int) {
        val n = idx + d
        if (n !in 0 until list.size) {
            Toast.makeText(this, getString(if (d > 0) R.string.list_last else R.string.list_first), Toast.LENGTH_SHORT).show()
            return
        }
        idx = n
        show()
    }

    private fun nameOf(u: Uri): String = runCatching {
        contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
    }.getOrNull() ?: (u.lastPathSegment ?: "").substringAfterLast('/')

    private fun show() {
        val mine = ++gen
        val u = list[idx]
        titleTv.text = (if (list.size > 1) "${idx + 1}/${list.size}  " else "") + nameOf(u)
        (iv.drawable as? AnimatedImageDrawable)?.stop()
        Thread {
            val d: Drawable? = runCatching {
                ImageDecoder.decodeDrawable(ImageDecoder.createSource(contentResolver, u)) { dec, info, _ ->
                    val m = max(info.size.width, info.size.height)
                    if (m > 1800) dec.setTargetSampleSize(m / 1800 + 1)
                }
            }.getOrNull()
            ui.post {
                if (closed || mine != gen) return@post
                if (d == null) {
                    Toast.makeText(this, getString(R.string.manga_empty), Toast.LENGTH_SHORT).show()
                    return@post
                }
                present(d)
            }
        }.start()
    }

    private fun startAnim(d: Drawable) {
        if (d is AnimatedImageDrawable) {
            d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
            d.start()
        }
    }

    // ---- picture effects on the GIF (local, free): every frame goes through the player's GL pipeline ----

    private fun paintFx() {
        fxBtn.alpha = if (Cfg.gifFx) 1f else 0.45f
        fxBtn.paintFlags = if (Cfg.gifFx) fxBtn.paintFlags or android.graphics.Paint.UNDERLINE_TEXT_FLAG
        else fxBtn.paintFlags and android.graphics.Paint.UNDERLINE_TEXT_FLAG.inv()
    }

    private fun setGifFx(on: Boolean) {
        Cfg.gifFx = on
        Cfg.save(this)
        paintFx()
        curDrawable?.let { present(it) }
    }

    private fun toggleFxPanel() {
        if (fxPanel.visibility == View.VISIBLE) {
            fxPanel.visibility = View.GONE
            return
        }
        if (!fxPanelBuilt) {
            fxPanelBuilt = true
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            box.addView(
                buildControls(
                    this,
                    onAdjust = { active -> fxPanel.animate().alpha(if (active) 0.35f else 1f).setDuration(120).start() },
                    inPlayer = true,
                    sourceScale = { 2f }
                ) { gl?.redraw() },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )
            fxPanel.addView(box, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        fxPanel.visibility = View.VISIBLE
        if (!Cfg.gifFx) setGifFx(true)
    }

    private fun present(d: Drawable) {
        teardownFx()
        curDrawable = d
        val w = d.intrinsicWidth
        val h = d.intrinsicHeight
        if (!Cfg.gifFx || w <= 0 || h <= 0) {
            iv.visibility = View.VISIBLE
            iv.setImageDrawable(d)
            startAnim(d)
            return
        }
        iv.visibility = View.INVISIBLE
        iv.setImageDrawable(null)
        val b = windowManager.currentWindowMetrics.bounds
        val s = min(b.width().toFloat() / w, b.height().toFloat() / h)
        val fw = (w * s).toInt().coerceIn(2, 8192)
        val fh = (h * s).toInt().coerceIn(2, 8192)
        val view = TextureView(this).apply { isOpaque = true }
        view.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, width: Int, height: Int) {
                if (tv === view) startFx(st, d, w, h)
            }

            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, width: Int, height: Int) {}

            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean = true

            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        tv = view
        rootView.addView(view, 1, FrameLayout.LayoutParams(fw, fh, Gravity.CENTER))
    }

    private fun startFx(st: SurfaceTexture, d: Drawable, w: Int, h: Int) {
        if (gl != null) return
        val out = Surface(st)
        outSurface = out
        val g = GlPipeline(out)
        g.onError = { msg -> ui.post { Toast.makeText(this, "+CRSC: $msg".take(240), Toast.LENGTH_LONG).show() } }
        gl = g
        g.start(w, h) { input ->
            ui.post {
                if (gl !== g || closed) return@post
                inSurface = input
                d.setBounds(0, 0, w, h)
                val cb = object : Drawable.Callback {
                    override fun invalidateDrawable(who: Drawable) = drawFx()
                    override fun scheduleDrawable(who: Drawable, what: Runnable, `when`: Long) {
                        ui.postAtTime(what, who, `when`)
                    }
                    override fun unscheduleDrawable(who: Drawable, what: Runnable) {
                        ui.removeCallbacks(what, who)
                    }
                }
                fxCb = cb // a Drawable only keeps its callback weakly
                d.callback = cb
                drawFx()
                startAnim(d)
            }
        }
    }

    private fun drawFx() {
        val s = inSurface ?: return
        val d = curDrawable ?: return
        if (closed || !s.isValid) return
        try {
            val c = s.lockCanvas(null)
            try {
                c.drawColor(0, PorterDuff.Mode.CLEAR)
                d.draw(c)
            } finally {
                s.unlockCanvasAndPost(c)
            }
        } catch (t: Throwable) {
            // surface gone or busy: the next frame tries again
        }
    }

    private fun teardownFx() {
        (curDrawable as? AnimatedImageDrawable)?.stop()
        curDrawable?.callback = null
        fxCb = null
        inSurface = null
        gl?.release()
        gl = null
        runCatching { outSurface?.release() }
        outSurface = null
        tv?.let { v ->
            tv = null
            runCatching { rootView.removeView(v) }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }
    }

    override fun onDestroy() {
        Ui.init(this)
        closed = true
        if (::iv.isInitialized) (iv.drawable as? AnimatedImageDrawable)?.stop()
        teardownFx()
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
