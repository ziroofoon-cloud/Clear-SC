package app.clearoverlay

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * The music player's own lists: "Favorites" and any number of named playlists. A song is remembered by its uri, so a list keeps
 * working after the library is rescanned. Stored as one small JSON string in SharedPreferences.
 */
object MusicLists {
    private const val PREF = "music_lists"
    private const val KEY = "v1"
    private var loaded = false
    private val fav = LinkedHashSet<String>()
    private val lists = LinkedHashMap<String, MutableList<String>>()

    @Synchronized
    private fun ensure(ctx: Context) {
        if (loaded) return
        loaded = true
        runCatching {
            val s = ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, null) ?: return
            val o = JSONObject(s)
            o.optJSONArray("fav")?.let { a -> for (i in 0 until a.length()) fav.add(a.getString(i)) }
            o.optJSONObject("lists")?.let { l ->
                val it = l.keys()
                while (it.hasNext()) {
                    val n = it.next()
                    val a = l.getJSONArray(n)
                    lists[n] = MutableList(a.length()) { i -> a.getString(i) }
                }
            }
        }
    }

    private fun save(ctx: Context) {
        val o = JSONObject()
        o.put("fav", JSONArray(fav.toList()))
        val l = JSONObject()
        for ((n, v) in lists) l.put(n, JSONArray(v))
        o.put("lists", l)
        ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, o.toString()).apply()
    }

    @Synchronized fun isFav(ctx: Context, uri: String): Boolean { ensure(ctx); return uri in fav }

    @Synchronized fun toggleFav(ctx: Context, uri: String): Boolean {
        ensure(ctx)
        val now = if (uri in fav) { fav.remove(uri); false } else { fav.add(uri); true }
        save(ctx)
        return now
    }

    @Synchronized fun favs(ctx: Context): List<String> { ensure(ctx); return fav.toList() }

    @Synchronized fun names(ctx: Context): List<String> { ensure(ctx); return lists.keys.toList() }

    @Synchronized fun items(ctx: Context, name: String): List<String> { ensure(ctx); return lists[name]?.toList() ?: emptyList() }

    /** False when the name is empty or already used. */
    @Synchronized fun create(ctx: Context, name: String): Boolean {
        ensure(ctx)
        val n = name.trim()
        if (n.isEmpty() || lists.containsKey(n)) return false
        lists[n] = ArrayList()
        save(ctx)
        return true
    }

    @Synchronized fun delete(ctx: Context, name: String) { ensure(ctx); lists.remove(name); save(ctx) }

    @Synchronized fun add(ctx: Context, name: String, uri: String) {
        ensure(ctx)
        val l = lists[name] ?: return
        if (uri !in l) { l.add(uri); save(ctx) }
    }

    @Synchronized fun remove(ctx: Context, name: String, uri: String) {
        ensure(ctx)
        if (lists[name]?.remove(uri) == true) save(ctx)
    }
}
