package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.widget.EditText
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

/**
 * The music player's own lists: "Favorites" and any number of named playlists. A song is remembered by its uri, so a list keeps
 * working after the library is rescanned. Stored as one small JSON string in SharedPreferences.
 */
object MusicLists {
    private const val PREF = "music_lists"
    private const val KEY = "v1"
    private var loaded = false
    private val fav = LinkedHashSet<String>()
    private val lists = LinkedHashMap<String, MutableList<String>>()

    @Synchronized
    private fun ensure(ctx: Context) {
        if (loaded) return
        loaded = true
        runCatching {
            val s = ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, null) ?: return
            val o = JSONObject(s)
            o.optJSONArray("fav")?.let { a -> for (i in 0 until a.length()) fav.add(a.getString(i)) }
            o.optJSONObject("lists")?.let { l ->
                val it = l.keys()
                while (it.hasNext()) {
                    val n = it.next()
                    val a = l.getJSONArray(n)
                    lists[n] = MutableList(a.length()) { i -> a.getString(i) }
                }
            }
        }
    }

    private fun save(ctx: Context) {
        val o = JSONObject()
        o.put("fav", JSONArray(fav.toList()))
        val l = JSONObject()
        for ((n, v) in lists) l.put(n, JSONArray(v))
        o.put("lists", l)
        ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, o.toString()).apply()
    }

    @Synchronized fun isFav(ctx: Context, uri: String): Boolean { ensure(ctx); return uri in fav }

    @Synchronized fun toggleFav(ctx: Context, uri: String): Boolean {
        ensure(ctx)
        val now = if (uri in fav) { fav.remove(uri); false } else { fav.add(uri); true }
        save(ctx)
        return now
    }

    @Synchronized fun favs(ctx: Context): List<String> { ensure(ctx); return fav.toList() }

    @Synchronized fun names(ctx: Context): List<String> { ensure(ctx); return lists.keys.toList() }

    @Synchronized fun items(ctx: Context, name: String): List<String> { ensure(ctx); return lists[name]?.toList() ?: emptyList() }

    /** False when the name is empty or already used. */
    @Synchronized fun create(ctx: Context, name: String): Boolean {
        ensure(ctx)
        val n = name.trim()
        if (n.isEmpty() || lists.containsKey(n)) return false
        lists[n] = ArrayList()
        save(ctx)
        return true
    }

    @Synchronized fun delete(ctx: Context, name: String) { ensure(ctx); lists.remove(name); save(ctx) }

    @Synchronized fun add(ctx: Context, name: String, uri: String) {
        ensure(ctx)
        val l = lists[name] ?: return
        if (uri !in l) { l.add(uri); save(ctx) }
    }

    /** Several songs at once (the multi-select picker): the ones already in the list are skipped, the order of the new ones is kept. */
    @Synchronized fun addAll(ctx: Context, name: String, uris: List<String>) {
        ensure(ctx)
        val l = lists[name] ?: return
        var changed = false
        for (u in uris) if (u !in l) { l.add(u); changed = true }
        if (changed) save(ctx)
    }

    @Synchronized fun removeAll(ctx: Context, name: String, uris: Set<String>) {
        ensure(ctx)
        val l = lists[name] ?: return
        if (l.removeAll(uris)) save(ctx)
    }

    @Synchronized fun remove(ctx: Context, name: String, uri: String) {
        ensure(ctx)
        if (lists[name]?.remove(uri) == true) save(ctx)
    }
}

/** The quick menu of the song that is playing (the music bar and the full-screen player): favorite, playlists, share. */
object MusicQuick {
    fun show(act: Activity, t: MusicPlayer.Track, onChange: () -> Unit = {}) {
        val key = t.uri.toString()
        val isFav = MusicLists.isFav(act, key)
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        labels.add(act.getString(if (isFav) R.string.aud_menu_fav_remove else R.string.aud_menu_fav_add)); acts.add { toggleFav(act, t); onChange() }
        labels.add(act.getString(R.string.aud_menu_to_list)); acts.add { addToList(act, t, onChange) }
        labels.add(act.getString(R.string.share)); acts.add { Share.share(act, listOf(t.uri)) }
        AlertDialog.Builder(act)
            .setTitle(t.title)
            .setItems(labels.toTypedArray()) { _, w -> acts[w]() }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    /** Adds the song to the favorites, or takes it out; says which. */
    fun toggleFav(act: Activity, t: MusicPlayer.Track) {
        val on = MusicLists.toggleFav(act, t.uri.toString())
        Toast.makeText(act, act.getString(if (on) R.string.aud_fav_added else R.string.aud_fav_removed), Toast.LENGTH_SHORT).show()
    }

    /** Pick the playlist the song goes into, or make a new one. */
    fun addToList(act: Activity, t: MusicPlayer.Track, onChange: () -> Unit = {}) {
        val names = MusicLists.names(act)
        val items = (names + act.getString(R.string.aud_new_list)).toTypedArray()
        AlertDialog.Builder(act)
            .setTitle(R.string.aud_menu_to_list)
            .setItems(items) { _, i ->
                if (i < names.size) {
                    MusicLists.add(act, names[i], t.uri.toString())
                    Toast.makeText(act, act.getString(R.string.aud_added_fmt, names[i]), Toast.LENGTH_SHORT).show()
                    onChange()
                } else {
                    val et = EditText(act).apply {
                        hint = act.getString(R.string.aud_list_name_hint)
                        setSingleLine()
                        setPadding(dp(act, 20), dp(act, 14), dp(act, 20), dp(act, 14))
                    }
                    AlertDialog.Builder(act)
                        .setTitle(R.string.aud_new_list)
                        .setView(et)
                        .setPositiveButton(android.R.string.ok) { _, _ ->
                            val n = et.text.toString().trim()
                            if (n.isNotEmpty() && MusicLists.create(act, n)) {
                                MusicLists.add(act, n, t.uri.toString())
                                Toast.makeText(act, act.getString(R.string.aud_added_fmt, n), Toast.LENGTH_SHORT).show()
                                onChange()
                            } else Toast.makeText(act, R.string.aud_list_bad_name, Toast.LENGTH_SHORT).show()
                        }
                        .setNegativeButton(android.R.string.cancel, null)
                        .show()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }
}
