package app.clearoverlay

import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.InputStream
import java.util.concurrent.Executors
import java.util.zip.ZipFile
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Manga / comic reader for an image folder (opened from the library) or a .cbz / .zip file.
 *  - Scroll: pages one under the other (webtoon style), position remembered.
 *  - Pages: one page at a time with pinch zoom; swipe or tap the screen edges to turn; right-to-left switch for manga.
 * Center tap shows / hides the top bar. Pages are decoded at screen size, so even large scans stay light.
 */
class MangaActivity : Activity() {

    private class Page(val uri: Uri?, val entry: String?)

    private val ui = Handler(Looper.getMainLooper())
    private val pool = Executors.newFixedThreadPool(2)
    private val prefs by lazy { getSharedPreferences("crsc_player", Context.MODE_PRIVATE) }

    private lateinit var content: FrameLayout
    private lateinit var top: LinearLayout
    private lateinit var titleTv: TextView
    private lateinit var progressTv: TextView
    private lateinit var modeBtn: TextView
    private lateinit var rtlBtn: TextView
    private lateinit var list: ListView
    private lateinit var zoom: ZoomView

    private var pages: List<Page> = emptyList()
    private var zip: ZipFile? = null
    private var key = ""
    private var scrollMode = true
    private var rtl = true
    private var current = 0
    private var screenW = 1080
    private var screenH = 1920
    private var closed = false
    private var sliding = false

    private val cache = object : LruCache<Int, Bitmap>(48 * 1024 * 1024) {
        override fun sizeOf(key: Int, value: Bitmap): Int = value.byteCount
    }
    private val ratios = HashMap<Int, Float>()

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Cfg.load(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        scrollMode = prefs.getBoolean("manga_scroll", true)
        rtl = prefs.getBoolean("manga_rtl", true)
        val b = windowManager.currentWindowMetrics.bounds
        screenW = b.width()
        screenH = b.height()

        content = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        list = ListView(this).apply {
            divider = null
            setBackgroundColor(Color.BLACK)
            isVerticalScrollBarEnabled = false
            visibility = View.GONE
            setOnItemClickListener { _, _, _, _ -> toggleBar() }
            setOnScrollListener(object : AbsListView.OnScrollListener {
                override fun onScrollStateChanged(v: AbsListView, state: Int) {}
                override fun onScroll(v: AbsListView, first: Int, visible: Int, total: Int) {
                    if (scrollMode && pages.isNotEmpty()) {
                        current = first.coerceIn(0, pages.size - 1)
                        paintProgress()
                    }
                }
            })
        }
        content.addView(list, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        zoom = ZoomView(this).apply {
            visibility = View.GONE
            onSwipe = { dir -> turn(if (rtl) dir else -dir) }
            onTap = { x ->
                when {
                    x < 0.3f -> turn(if (rtl) 1 else -1)
                    x > 0.7f -> turn(if (rtl) -1 else 1)
                    else -> toggleBar()
                }
            }
        }
        content.addView(zoom, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        top = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#CC0B1020"))
            setPadding(dp(this@MangaActivity, 12), dp(this@MangaActivity, 6), dp(this@MangaActivity, 8), dp(this@MangaActivity, 6))
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleTv = Ui.text(this, "", 14f, Ui.TEXT, true).apply {
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        progressTv = Ui.text(this, "", 12f, Ui.MUTED)
        titles.addView(titleTv)
        titles.addView(progressTv)
        top.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        modeBtn = barBtn("") { setScrollMode(!scrollMode) }
        rtlBtn = barBtn("") { setRtl(!rtl) }
        top.addView(modeBtn)
        top.addView(rtlBtn)
        top.addView(barBtn("✕") { finish() })
        content.addView(top, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))
        setContentView(content)
        content.setOnApplyWindowInsetsListener { _, ins ->
            val i = ins.getInsetsIgnoringVisibility(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            top.setPadding(dp(this, 12) + i.left, dp(this, 6) + i.top, dp(this, 8) + i.right, dp(this, 6))
            ins
        }
        paintButtons()
        load()
    }

    private fun barBtn(label: String, onClick: () -> Unit) = Ui.text(this, label, 16f, Ui.ACCENT, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(this@MangaActivity, 12), dp(this@MangaActivity, 8), dp(this@MangaActivity, 12), dp(this@MangaActivity, 8))
        setOnClickListener { onClick() }
    }

    private fun paintButtons() {
        modeBtn.text = if (scrollMode) "≡ " + getString(R.string.manga_scroll) else "▭ " + getString(R.string.manga_pages)
        rtlBtn.text = if (rtl) "⇠ " + getString(R.string.manga_dir_rtl) else "⇢ " + getString(R.string.manga_dir_ltr)
        rtlBtn.alpha = if (scrollMode) 0.4f else 1f
    }

    private fun toggleBar() {
        top.visibility = if (top.visibility == View.VISIBLE) View.GONE else View.VISIBLE
    }

    // ---- loading the page list -------------------------------------------------------------------

    private fun load() {
        val u = intent?.data
        val bucket = intent?.getLongExtra(EXTRA_BUCKET, Long.MIN_VALUE) ?: Long.MIN_VALUE
        val tree = intent?.getStringExtra(EXTRA_TREE)
        titleTv.text = intent?.getStringExtra(EXTRA_NAME) ?: ""
        Thread {
            var err: String? = null
            var out: List<Page> = emptyList()
            var k = ""
            try {
                if (u != null) {
                    val f = File(cacheDir, "manga.cbz")
                    (contentResolver.openInputStream(u) ?: error("cannot open")).use { ins -> f.outputStream().use { ins.copyTo(it) } }
                    val z = ZipFile(f)
                    zip = z
                    val names = ArrayList<String>()
                    val en = z.entries()
                    while (en.hasMoreElements()) {
                        val e = en.nextElement()
                        val n = e.name
                        val l = n.lowercase()
                        if (e.isDirectory || n.contains("__MACOSX") || n.substringAfterLast('/').startsWith(".")) continue
                        if (l.endsWith(".jpg") || l.endsWith(".jpeg") || l.endsWith(".png") || l.endsWith(".webp") || l.endsWith(".gif") || l.endsWith(".bmp")) names.add(n)
                    }
                    names.sortWith { a, b -> Media.natural(a, b) }
                    out = names.map { Page(null, it) }
                    k = "cbz_" + u.toString().hashCode()
                    if (titleTv.text.isEmpty()) ui.post { titleTv.text = (u.lastPathSegment ?: "").substringAfterLast('/').substringAfterLast(':') }
                } else if (tree != null) {
                    out = Media.mangaPagesTree(this, Uri.parse(tree)).map { Page(it, null) }
                    k = "bt_" + tree.hashCode()
                } else if (bucket != Long.MIN_VALUE) {
                    out = Media.mangaPages(this, bucket).map { Page(it, null) }
                    k = "bk_$bucket"
                }
            } catch (t: Throwable) {
                err = t.message ?: t.javaClass.simpleName
            }
            val e = err
            val result = out
            val kk = k
            ui.post {
                if (closed) return@post
                if (e != null || result.isEmpty()) {
                    Toast.makeText(this, getString(R.string.manga_empty) + (if (e != null) "\n$e" else ""), Toast.LENGTH_LONG).show()
                    finish()
                    return@post
                }
                pages = result
                key = kk
                current = prefs.getInt("manga_pos_$key", 0).coerceIn(0, pages.size - 1)
                showMode()
            }
        }.start()
    }

    // ---- decoding --------------------------------------------------------------------------------

    private fun open(p: Page): InputStream? =
        if (p.entry != null) zip?.let { z -> z.getEntry(p.entry)?.let { e -> z.getInputStream(e) } }
        else p.uri?.let { contentResolver.openInputStream(it) }

    /** [fitW]: wanted width in pixels (scroll mode) or 0 for "long side up to about 3000 px" (page mode). */
    private fun decode(p: Page, fitW: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        open(p)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        val w = bounds.outWidth
        val h = bounds.outHeight
        var sample = 1
        if (fitW > 0) {
            while (w / (sample * 2) >= fitW) sample *= 2
        } else {
            while (max(w, h) / sample > 3000) sample *= 2
        }
        // very long strips: keep the decoded size within about 8 megapixels
        val px = w.toDouble() * h
        val need = ceil(sqrt(px / 8_000_000.0)).toInt().coerceAtLeast(1)
        while (sample < need) sample *= 2
        val o = BitmapFactory.Options().apply { inSampleSize = sample }
        return open(p)?.use { BitmapFactory.decodeStream(it, null, o) }
    }

    // ---- modes -----------------------------------------------------------------------------------

    private fun setScrollMode(on: Boolean) {
        scrollMode = on
        prefs.edit().putBoolean("manga_scroll", on).apply()
        cache.evictAll()
        ratios.clear()
        paintButtons()
        showMode()
    }

    private fun setRtl(on: Boolean) {
        rtl = on
        prefs.edit().putBoolean("manga_rtl", on).apply()
        paintButtons()
    }

    private fun showMode() {
        if (pages.isEmpty()) return
        sliding = false
        zoom.animate().cancel()
        zoom.translationX = 0f
        if (scrollMode) {
            zoom.visibility = View.GONE
            list.visibility = View.VISIBLE
            list.adapter = adapter
            list.setSelection(current)
        } else {
            list.visibility = View.GONE
            zoom.visibility = View.VISIBLE
            showPage(current)
        }
        paintProgress()
    }

    private fun paintProgress() {
        progressTv.text = getString(R.string.manga_progress_fmt, current + 1, pages.size)
    }

    // ---- page mode -------------------------------------------------------------------------------

    private fun turn(d: Int) {
        if (sliding) return
        val n = current + d
        if (n < 0 || n >= pages.size) {
            Toast.makeText(this, getString(if (d > 0) R.string.list_last else R.string.list_first), Toast.LENGTH_SHORT).show()
            return
        }
        slideTo(n, d)
    }

    /** Horizontal slide: the old page leaves in the reading direction, the new one comes in from the other side. */
    private fun slideTo(n: Int, d: Int) {
        val w = zoom.width.toFloat().coerceAtLeast(1f)
        // exit side: next page with right-to-left reading slides the old page off to the right, and so on
        val s = if (d > 0) (if (rtl) 1f else -1f) else (if (rtl) -1f else 1f)
        zoom.animate().cancel()
        sliding = true
        zoom.animate().translationX(s * w).setDuration(120).withEndAction {
            if (closed) return@withEndAction
            if (cache.get(n) == null) zoom.setBitmap(null)
            showPage(n)
            zoom.translationX = -s * w
            zoom.animate().translationX(0f).setDuration(160).withEndAction { sliding = false }.start()
        }.start()
    }

    private fun showPage(i: Int) {
        current = i
        paintProgress()
        prefs.edit().putInt("manga_pos_$key", i).apply()
        val c = cache.get(i)
        if (c != null) {
            zoom.setBitmap(c)
        } else {
            pool.execute {
                val b = decode(pages[i], 0)
                ui.post {
                    if (closed || b == null) return@post
                    cache.put(i, b)
                    if (current == i && !scrollMode) zoom.setBitmap(b)
                }
            }
        }
        // preload the neighbours so turning either way is instant
        for (nx in intArrayOf(i + 1, i - 1)) {
            if (nx in 0 until pages.size && cache.get(nx) == null) {
                pool.execute {
                    val b = decode(pages[nx], 0)
                    if (b != null && !closed) cache.put(nx, b)
                }
            }
        }
    }

    // ---- scroll mode -----------------------------------------------------------------------------

    private val adapter = object : BaseAdapter() {
        override fun getCount() = pages.size
        override fun getItem(position: Int): Any = pages[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val iv = (convertView as? ImageView) ?: ImageView(this@MangaActivity).apply {
                scaleType = ImageView.ScaleType.FIT_XY
                setBackgroundColor(Color.parseColor("#101018"))
            }
            iv.tag = position
            val r = ratios[position]
            val h = if (r != null) (screenW * r).toInt() else screenW * 3 / 2
            iv.layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h)
            val hit = cache.get(position)
            if (hit != null) {
                iv.setImageBitmap(hit)
            } else {
                iv.setImageDrawable(null)
                val page = pages[position]
                pool.execute {
                    val b = decode(page, screenW) ?: return@execute
                    cache.put(position, b)
                    val ratio = b.height.toFloat() / b.width
                    ui.post {
                        if (closed) return@post
                        val changed = ratios[position] != ratio
                        ratios[position] = ratio
                        if (iv.tag == position) {
                            iv.setImageBitmap(b)
                            iv.layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (screenW * ratio).toInt())
                            if (changed) iv.requestLayout()
                        }
                    }
                }
            }
            return iv
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }
    }

    override fun onPause() {
        if (pages.isNotEmpty() && key.isNotEmpty()) prefs.edit().putInt("manga_pos_$key", current).apply()
        super.onPause()
    }

    override fun onDestroy() {
        closed = true
        pool.shutdownNow()
        ui.removeCallbacksAndMessages(null)
        runCatching { zip?.close() }
        super.onDestroy()
    }

    companion object {
        const val EXTRA_BUCKET = "app.clearoverlay.BUCKET"
        const val EXTRA_NAME = "app.clearoverlay.NAME"
        const val EXTRA_TREE = "app.clearoverlay.TREE"
    }
}
