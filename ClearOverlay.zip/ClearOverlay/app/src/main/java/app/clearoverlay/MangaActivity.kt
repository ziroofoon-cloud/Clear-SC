package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.InputStream
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipFile
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Manga / comic reader for an image folder (opened from the library) or a .cbz / .zip file.
 *  - Scroll: pages one under the other (webtoon style), position remembered.
 *  - Pages: one page at a time with pinch zoom; swipe or tap the screen edges to turn; right-to-left switch for manga.
 * Center tap shows / hides the top bar. Pages are decoded at screen size, so even large scans stay light.
 */
class MangaActivity : Activity() {

    private class Page(val uri: Uri?, val entry: String?)

    private val ui = Handler(Looper.getMainLooper())
    private val pool = Executors.newFixedThreadPool(2)
    private val prefs by lazy { getSharedPreferences("crsc_player", Context.MODE_PRIVATE) }

    private lateinit var content: FrameLayout
    private lateinit var top: LinearLayout
    private lateinit var titleTv: TextView
    private lateinit var progressTv: TextView
    private lateinit var modeBtn: TextView
    private lateinit var rtlBtn: TextView
    private lateinit var list: ListView
    private lateinit var zoom: ZoomView
    private lateinit var fxBtn: TextView
    private lateinit var fxPanel: ScrollView
    private var fxPanelBuilt = false
    private val fx = MangaFx()
    private val onlineCancel = AtomicBoolean(false)
    @Volatile private var onlineBusy = false
    @Volatile private var fxGen = 0
    private val fxApply = Runnable { reloadPages() }

    private var pages: List<Page> = emptyList()
    private var zip: ZipFile? = null
    private var key = ""
    private var scrollMode = true
    private var rtl = true
    private var current = 0
    private var screenW = 1080
    private var screenH = 1920
    private var closed = false
    private var sliding = false

    private val cache = object : LruCache<Int, Bitmap>(96 * 1024 * 1024) {
        override fun sizeOf(key: Int, value: Bitmap): Int = value.byteCount
    }
    private val ratios = HashMap<Int, Float>()

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Cfg.load(this)
        Ui.init(this, forceDark = true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        scrollMode = prefs.getBoolean("manga_scroll", true)
        rtl = prefs.getBoolean("manga_rtl", true)
        val b = windowManager.currentWindowMetrics.bounds
        screenW = b.width()
        screenH = b.height()

        content = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        list = ListView(this).apply {
            divider = null
            setBackgroundColor(Color.BLACK)
            isVerticalScrollBarEnabled = false
            visibility = View.GONE
            setOnItemClickListener { _, _, _, _ -> toggleBar() }
            setOnScrollListener(object : AbsListView.OnScrollListener {
                override fun onScrollStateChanged(v: AbsListView, state: Int) {}
                override fun onScroll(v: AbsListView, first: Int, visible: Int, total: Int) {
                    if (scrollMode && pages.isNotEmpty()) {
                        current = first.coerceIn(0, pages.size - 1)
                        paintProgress()
                    }
                }
            })
        }
        content.addView(list, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        zoom = ZoomView(this).apply {
            visibility = View.GONE
            onSwipe = { dir -> turn(if (rtl) dir else -dir) }
            onTap = { x ->
                when {
                    x < 0.3f -> turn(if (rtl) 1 else -1)
                    x > 0.7f -> turn(if (rtl) -1 else 1)
                    else -> toggleBar()
                }
            }
        }
        content.addView(zoom, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        top = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#CC0B1020"))
            setPadding(dp(this@MangaActivity, 12), dp(this@MangaActivity, 6), dp(this@MangaActivity, 8), dp(this@MangaActivity, 6))
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleTv = Ui.text(this, "", 14f, Ui.TEXT, true).apply {
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        progressTv = Ui.text(this, "", 12f, Ui.MUTED)
        titles.addView(titleTv)
        titles.addView(progressTv)
        top.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        modeBtn = barBtn("") { setScrollMode(!scrollMode) }
        rtlBtn = barBtn("") { setRtl(!rtl) }
        fxBtn = barBtn("FX") { setMangaFx(!Cfg.mangaFx) }
        top.addView(fxBtn)
        top.addView(Icons.button(this, Icons.GEAR, sizeDp = 38) { toggleFxPanel() })
        top.addView(Icons.button(this, Icons.CLOUD, sizeDp = 38) { showOnlineMenu() })
        top.addView(modeBtn)
        top.addView(rtlBtn)
        top.addView(Icons.button(this, Icons.CLOSE, sizeDp = 38) { finish() })
        content.addView(top, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))
        fxPanel = ScrollView(this).apply {
            visibility = View.GONE
            isClickable = true
            background = Ui.round(Color.parseColor("#F5101522"), dp(this@MangaActivity, 22).toFloat(), Ui.STROKE, dp(this@MangaActivity, 1))
            setPadding(dp(this@MangaActivity, 14), dp(this@MangaActivity, 12), dp(this@MangaActivity, 14), dp(this@MangaActivity, 12))
        }
        content.addView(
            fxPanel,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (screenH * 0.58f).toInt(), Gravity.BOTTOM).apply {
                setMargins(dp(this@MangaActivity, 8), 0, dp(this@MangaActivity, 8), dp(this@MangaActivity, 8))
            }
        )
        setContentView(content)
        content.setOnApplyWindowInsetsListener { _, ins ->
            val i = ins.getInsetsIgnoringVisibility(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            top.setPadding(dp(this, 12) + i.left, dp(this, 6) + i.top, dp(this, 8) + i.right, dp(this, 6))
            ins
        }
        paintButtons()
        paintFx()
        load()
    }

    private fun barBtn(label: String, onClick: () -> Unit) = Ui.text(this, label, 16f, Ui.ACCENT, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(this@MangaActivity, 12), dp(this@MangaActivity, 8), dp(this@MangaActivity, 12), dp(this@MangaActivity, 8))
        setOnClickListener { onClick() }
    }

    private fun paintButtons() {
        modeBtn.text = if (scrollMode) "≡ " + getString(R.string.manga_scroll) else "▭ " + getString(R.string.manga_pages)
        rtlBtn.text = if (rtl) "⇠ " + getString(R.string.manga_dir_rtl) else "⇢ " + getString(R.string.manga_dir_ltr)
        rtlBtn.alpha = if (scrollMode) 0.4f else 1f
    }

    private fun paintFx() {
        fxBtn.alpha = if (Cfg.mangaFx) 1f else 0.45f
        fxBtn.paintFlags = if (Cfg.mangaFx) fxBtn.paintFlags or android.graphics.Paint.UNDERLINE_TEXT_FLAG
        else fxBtn.paintFlags and android.graphics.Paint.UNDERLINE_TEXT_FLAG.inv()
    }

    private fun setMangaFx(on: Boolean) {
        Cfg.mangaFx = on
        Cfg.save(this)
        paintFx()
        scheduleReload(0)
    }

    private fun toggleFxPanel() {
        if (fxPanel.visibility == View.VISIBLE) {
            fxPanel.visibility = View.GONE
            return
        }
        if (!fxPanelBuilt) {
            fxPanelBuilt = true
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            box.addView(
                buildControls(
                    this,
                    onAdjust = { active -> fxPanel.animate().alpha(if (active) 0.35f else 1f).setDuration(120).start() },
                    inPlayer = true,
                    sourceScale = { 1.5f }
                ) { if (Cfg.mangaFx) scheduleReload(350) },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )
            fxPanel.addView(box, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        fxPanel.visibility = View.VISIBLE
        if (!Cfg.mangaFx) setMangaFx(true)
    }

    /** Effects settings changed: pages are decoded and processed again (a short delay while a slider is moving). */
    private fun scheduleReload(delayMs: Long) {
        fxGen++
        ui.removeCallbacks(fxApply)
        ui.postDelayed(fxApply, delayMs)
    }

    private fun reloadPages() {
        if (closed || pages.isEmpty()) return
        cache.evictAll()
        if (scrollMode) {
            adapter.notifyDataSetChanged()
        } else {
            zoom.setBitmap(null)
            showPage(current)
        }
    }

    /** A decoded page, run through the picture effects when they are on for the reader. */
    private fun fetch(p: Page, fitW: Int): Bitmap? {
        val g0 = fxGen
        val b = decode(p, fitW) ?: return null
        if (!Cfg.mangaFx) return b
        val out = runCatching { fx.process(b) }.getOrNull() ?: return b
        if (g0 != fxGen) return null // settings changed meanwhile: this result is stale, the page is rebuilt anyway
        return out
    }

    // ---- online enhance of the current page (cloud, paid) ------------------------------------------

    private fun showOnlineMenu() {
        if (onlineBusy) {
            onlineCancel.set(true)
            return
        }
        val items = arrayOf(
            getString(R.string.online_photo),
            getString(R.string.online_text),
            getString(R.string.manga_save_page),
            getString(R.string.online_settings)
        )
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.online_menu) + "  (" + getString(R.string.manga_progress_fmt, current + 1, pages.size) + ")")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> onlineCurrent(Online.PHOTO)
                    1 -> onlineCurrent(Online.TEXT)
                    2 -> savePage()
                    else -> Online.showSettings(this)
                }
            }
            .show()
    }

    private fun onlineCurrent(kind: Int) {
        if (!Online.hasKey(this)) {
            Toast.makeText(this, getString(R.string.online_need_key), Toast.LENGTH_LONG).show()
            Online.showSettings(this)
            return
        }
        if (onlineBusy || pages.isEmpty()) return
        val idx = current
        val page = pages[idx]
        onlineBusy = true
        onlineCancel.set(false)
        progressTv.text = "☁ " + getString(R.string.online_working_fmt, "")
        Thread {
            var err: String? = null
            var out: Bitmap? = null
            try {
                val src = decode(page, 0)
                if (src != null) {
                    out = Online.enhance(this, src, kind, onlineCancel) { st ->
                        ui.post { if (!closed && onlineBusy) progressTv.text = "☁ " + getString(R.string.online_working_fmt, st) }
                    }
                }
            } catch (t: Throwable) {
                err = t.message ?: t.javaClass.simpleName
            }
            val e = err
            val o = out
            ui.post {
                onlineBusy = false
                if (closed) return@post
                paintProgress()
                when {
                    e != null -> Toast.makeText(this, getString(R.string.online_error_fmt, e), Toast.LENGTH_LONG).show()
                    o == null -> Toast.makeText(this, getString(R.string.ai_cancelled), Toast.LENGTH_SHORT).show()
                    else -> {
                        cache.put(idx, o)
                        ratios[idx] = o.height.toFloat() / o.width
                        if (scrollMode) adapter.notifyDataSetChanged() else if (current == idx) zoom.setBitmap(o)
                        Toast.makeText(this, getString(R.string.online_done), Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }.start()
    }

    /** Writes the page as it is shown now (with FX / online result) to Pictures/ClearOverlay. */
    private fun savePage() {
        val idx = current
        val b = cache.get(idx)
        if (b == null) {
            Toast.makeText(this, getString(R.string.save_fail), Toast.LENGTH_SHORT).show()
            return
        }
        Thread {
            var ok = false
            runCatching {
                val name = "CRSC_manga_" + java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date()) + "_" + (idx + 1) + ".jpg"
                val values = android.content.ContentValues().apply {
                    put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ClearOverlay")
                    put(android.provider.MediaStore.Images.Media.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: error("insert")
                try {
                    contentResolver.openOutputStream(uri)!!.use { b.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                    values.clear()
                    values.put(android.provider.MediaStore.Images.Media.IS_PENDING, 0)
                    contentResolver.update(uri, values, null, null)
                    ok = true
                } catch (t: Throwable) {
                    runCatching { contentResolver.delete(uri, null, null) }
                }
            }
            ui.post { if (!closed) Toast.makeText(this, getString(if (ok) R.string.save_ok else R.string.save_fail), Toast.LENGTH_SHORT).show() }
        }.start()
    }

    private fun toggleBar() {
        top.visibility = if (top.visibility == View.VISIBLE) View.GONE else View.VISIBLE
    }

    // ---- loading the page list -------------------------------------------------------------------

    private fun load() {
        val u = intent?.data
        val bucket = intent?.getLongExtra(EXTRA_BUCKET, Long.MIN_VALUE) ?: Long.MIN_VALUE
        val tree = intent?.getStringExtra(EXTRA_TREE)
        titleTv.text = intent?.getStringExtra(EXTRA_NAME) ?: ""
        Thread {
            var err: String? = null
            var out: List<Page> = emptyList()
            var k = ""
            try {
                if (u != null) {
                    val f = File(cacheDir, "manga.cbz")
                    (contentResolver.openInputStream(u) ?: error("cannot open")).use { ins -> f.outputStream().use { ins.copyTo(it) } }
                    val z = ZipFile(f)
                    zip = z
                    val names = ArrayList<String>()
                    val en = z.entries()
                    while (en.hasMoreElements()) {
                        val e = en.nextElement()
                        val n = e.name
                        val l = n.lowercase()
                        if (e.isDirectory || n.contains("__MACOSX") || n.substringAfterLast('/').startsWith(".")) continue
                        if (l.endsWith(".jpg") || l.endsWith(".jpeg") || l.endsWith(".png") || l.endsWith(".webp") || l.endsWith(".gif") || l.endsWith(".bmp")) names.add(n)
                    }
                    names.sortWith { a, b -> Media.natural(a, b) }
                    out = names.map { Page(null, it) }
                    k = "cbz_" + u.toString().hashCode()
                    if (titleTv.text.isEmpty()) ui.post { titleTv.text = (u.lastPathSegment ?: "").substringAfterLast('/').substringAfterLast(':') }
                } else if (tree != null) {
                    out = Media.mangaPagesTree(this, Uri.parse(tree)).map { Page(it, null) }
                    k = "bt_" + tree.hashCode()
                } else if (bucket != Long.MIN_VALUE) {
                    out = Media.mangaPages(this, bucket).map { Page(it, null) }
                    k = "bk_$bucket"
                }
            } catch (t: Throwable) {
                err = t.message ?: t.javaClass.simpleName
            }
            val e = err
            val result = out
            val kk = k
            ui.post {
                if (closed) return@post
                if (e != null || result.isEmpty()) {
                    Toast.makeText(this, getString(R.string.manga_empty) + (if (e != null) "\n$e" else ""), Toast.LENGTH_LONG).show()
                    finish()
                    return@post
                }
                pages = result
                key = kk
                current = prefs.getInt("manga_pos_$key", 0).coerceIn(0, pages.size - 1)
                showMode()
            }
        }.start()
    }

    // ---- decoding --------------------------------------------------------------------------------

    private fun open(p: Page): InputStream? =
        if (p.entry != null) zip?.let { z -> z.getEntry(p.entry)?.let { e -> z.getInputStream(e) } }
        else p.uri?.let { contentResolver.openInputStream(it) }

    /** [fitW]: wanted width in pixels (scroll mode) or 0 for "long side up to about 3000 px" (page mode). */
    private fun decode(p: Page, fitW: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        open(p)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        val w = bounds.outWidth
        val h = bounds.outHeight
        var sample = 1
        if (fitW > 0) {
            while (w / (sample * 2) >= fitW) sample *= 2
        } else {
            while (max(w, h) / sample > 3000) sample *= 2
        }
        // very long strips: keep the decoded size within about 8 megapixels
        val px = w.toDouble() * h
        val need = ceil(sqrt(px / 8_000_000.0)).toInt().coerceAtLeast(1)
        while (sample < need) sample *= 2
        val o = BitmapFactory.Options().apply { inSampleSize = sample }
        return open(p)?.use { BitmapFactory.decodeStream(it, null, o) }
    }

    // ---- modes -----------------------------------------------------------------------------------

    private fun setScrollMode(on: Boolean) {
        scrollMode = on
        prefs.edit().putBoolean("manga_scroll", on).apply()
        cache.evictAll()
        ratios.clear()
        paintButtons()
        showMode()
    }

    private fun setRtl(on: Boolean) {
        rtl = on
        prefs.edit().putBoolean("manga_rtl", on).apply()
        paintButtons()
    }

    private fun showMode() {
        if (pages.isEmpty()) return
        sliding = false
        zoom.animate().cancel()
        zoom.translationX = 0f
        if (scrollMode) {
            zoom.visibility = View.GONE
            list.visibility = View.VISIBLE
            list.adapter = adapter
            list.setSelection(current)
        } else {
            list.visibility = View.GONE
            zoom.visibility = View.VISIBLE
            showPage(current)
        }
        paintProgress()
    }

    private fun paintProgress() {
        progressTv.text = getString(R.string.manga_progress_fmt, current + 1, pages.size)
    }

    // ---- page mode -------------------------------------------------------------------------------

    private fun turn(d: Int) {
        if (sliding) return
        val n = current + d
        if (n < 0 || n >= pages.size) {
            Toast.makeText(this, getString(if (d > 0) R.string.list_last else R.string.list_first), Toast.LENGTH_SHORT).show()
            return
        }
        slideTo(n, d)
    }

    /** Horizontal slide: the old page leaves in the reading direction, the new one comes in from the other side. */
    private fun slideTo(n: Int, d: Int) {
        val w = zoom.width.toFloat().coerceAtLeast(1f)
        // exit side: next page with right-to-left reading slides the old page off to the right, and so on
        val s = if (d > 0) (if (rtl) 1f else -1f) else (if (rtl) -1f else 1f)
        zoom.animate().cancel()
        sliding = true
        zoom.animate().translationX(s * w).setDuration(120).withEndAction {
            if (closed) return@withEndAction
            if (cache.get(n) == null) zoom.setBitmap(null)
            showPage(n)
            zoom.translationX = -s * w
            zoom.animate().translationX(0f).setDuration(160).withEndAction { sliding = false }.start()
        }.start()
    }

    private fun showPage(i: Int) {
        current = i
        paintProgress()
        prefs.edit().putInt("manga_pos_$key", i).apply()
        val c = cache.get(i)
        if (c != null) {
            zoom.setBitmap(c)
        } else {
            pool.execute {
                val b = fetch(pages[i], 0)
                ui.post {
                    if (closed || b == null) return@post
                    cache.put(i, b)
                    if (current == i && !scrollMode) zoom.setBitmap(b)
                }
            }
        }
        // preload the neighbours so turning either way is instant
        for (nx in intArrayOf(i + 1, i - 1)) {
            if (nx in 0 until pages.size && cache.get(nx) == null) {
                pool.execute {
                    val b = fetch(pages[nx], 0)
                    if (b != null && !closed) cache.put(nx, b)
                }
            }
        }
    }

    // ---- scroll mode -----------------------------------------------------------------------------

    private val adapter = object : BaseAdapter() {
        override fun getCount() = pages.size
        override fun getItem(position: Int): Any = pages[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val iv = (convertView as? ImageView) ?: ImageView(this@MangaActivity).apply {
                scaleType = ImageView.ScaleType.FIT_XY
                setBackgroundColor(Color.parseColor("#101018"))
            }
            iv.tag = position
            val r = ratios[position]
            val h = if (r != null) (screenW * r).toInt() else screenW * 3 / 2
            iv.layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h)
            val hit = cache.get(position)
            if (hit != null) {
                iv.setImageBitmap(hit)
            } else {
                iv.setImageDrawable(null)
                val page = pages[position]
                pool.execute {
                    val b = fetch(page, screenW) ?: return@execute
                    cache.put(position, b)
                    val ratio = b.height.toFloat() / b.width
                    ui.post {
                        if (closed) return@post
                        val changed = ratios[position] != ratio
                        ratios[position] = ratio
                        if (iv.tag == position) {
                            iv.setImageBitmap(b)
                            iv.layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (screenW * ratio).toInt())
                            if (changed) iv.requestLayout()
                        }
                    }
                }
            }
            return iv
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }
    }

    override fun onPause() {
        if (pages.isNotEmpty() && key.isNotEmpty()) prefs.edit().putInt("manga_pos_$key", current).apply()
        super.onPause()
    }

    override fun onDestroy() {
        Ui.init(this)
        closed = true
        pool.shutdownNow()
        ui.removeCallbacks(fxApply)
        fx.release()
        ui.removeCallbacksAndMessages(null)
        runCatching { zip?.close() }
        super.onDestroy()
    }

    companion object {
        const val EXTRA_BUCKET = "app.clearoverlay.BUCKET"
        const val EXTRA_NAME = "app.clearoverlay.NAME"
        const val EXTRA_TREE = "app.clearoverlay.TREE"
    }
}
