package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.InputStream
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipFile
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Manga / comic reader for an image folder (opened from the library) or a .cbz / .zip file.
 *  - Scroll: pages one under the other (webtoon style), position remembered.
 *  - Pages: one page at a time with pinch zoom; swipe or tap the screen edges to turn; right-to-left switch for manga.
 * Center tap shows / hides the top bar. Pages are decoded at screen size, so even large scans stay light.
 */
class MangaActivity : Activity() {

    /** One page: a picture file ([uri]), an entry of a .cbz / .zip ([entry]) or a page of a PDF ([pdf] >= 0). */
    private class Page(val uri: Uri?, val entry: String?, val pdf: Int = -1) {
        /** Position in [pages] (set once the list is built); used to find a page's enhanced version. */
        var idx = 0
    }

    private val ui = Handler(Looper.getMainLooper())
    private val pool = Executors.newFixedThreadPool(2)
    private val prefs by lazy { getSharedPreferences("crsc_player", Context.MODE_PRIVATE) }

    private lateinit var content: FrameLayout
    private lateinit var top: LinearLayout
    private lateinit var titleTv: TextView
    private lateinit var progressTv: TextView
    private lateinit var titlesBox: LinearLayout
    private lateinit var bottomBar: LinearLayout
    private lateinit var pageSeek: SeekBar
    private lateinit var seekLeft: TextView
    private lateinit var seekRight: TextView
    private var seekGuard = false
    private var seekDragging = false
    private var barsOn = true
    private lateinit var modeBtn: TextView
    private lateinit var rtlBtn: TextView
    private lateinit var list: ListView
    private lateinit var zoom: ZoomView
    private lateinit var fxBtn: TextView
    private lateinit var fxPanel: ScrollView
    private var fxPanelBuilt = false
    private var mangaFxSwitch: android.widget.Switch? = null
    private val fx = MangaFx()
    private val onlineCancel = AtomicBoolean(false)
    @Volatile private var onlineBusy = false
    @Volatile private var fxGen = 0
    private val fxApply = Runnable { reloadPages() }

    private var pages: List<Page> = emptyList()
    private var zip: ZipFile? = null
    private var pdf: PdfRenderer? = null
    private val pdfLock = Any()
    private var histSrc = ""
    private var histRef = ""
    private var key = ""
    private var scrollMode = true
    private var rtl = true
    private var current = 0
    private var screenW = 1080
    private var screenH = 1920
    private var closed = false
    private var sliding = false

    private val cache = object : LruCache<Int, Bitmap>(96 * 1024 * 1024) {
        override fun sizeOf(key: Int, value: Bitmap): Int = value.byteCount
    }
    private val ratios = HashMap<Int, Float>()

    /** Pages the reader enhanced by hand (smart fix / AI / online): shown instead of the plain page until "Original". */
    private val enhanced = object : LruCache<Int, Bitmap>(128 * 1024 * 1024) {
        override fun sizeOf(key: Int, value: Bitmap): Int = value.byteCount
    }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Cfg.bind(this, "manga")
        Ui.init(this, forceDark = true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        scrollMode = prefs.getBoolean("manga_scroll", true)
        rtl = prefs.getBoolean("manga_rtl", true)
        val b = windowManager.currentWindowMetrics.bounds
        screenW = b.width()
        screenH = b.height()

        content = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        list = ListView(this).apply {
            divider = null
            setBackgroundColor(Color.BLACK)
            isVerticalScrollBarEnabled = false
            visibility = View.GONE
            setOnItemClickListener { _, _, _, _ -> toggleBar() }
            setOnScrollListener(object : AbsListView.OnScrollListener {
                override fun onScrollStateChanged(v: AbsListView, state: Int) {}
                override fun onScroll(v: AbsListView, first: Int, visible: Int, total: Int) {
                    if (scrollMode && pages.isNotEmpty()) {
                        current = first.coerceIn(0, pages.size - 1)
                        paintProgress()
                    }
                }
            })
        }
        content.addView(list, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        zoom = ZoomView(this).apply {
            visibility = View.GONE
            onSwipe = { dir -> turn(if (rtl) dir else -dir) }
            onTap = { x ->
                when {
                    x < 0.3f -> turn(if (rtl) 1 else -1)
                    x > 0.7f -> turn(if (rtl) -1 else 1)
                    else -> toggleBar()
                }
            }
        }
        content.addView(zoom, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        top = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#CC0B1020"))
            setPadding(dp(this@MangaActivity, 12), dp(this@MangaActivity, 6), dp(this@MangaActivity, 8), dp(this@MangaActivity, 6))
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titlesBox = titles
        titleTv = Ui.text(this, "", 14f, Ui.TEXT, true).apply {
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        progressTv = Ui.text(this, "", 12f, Ui.MUTED)
        titles.addView(titleTv)
        titles.addView(progressTv)
        top.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        modeBtn = barBtn("") { setScrollMode(!scrollMode) }
        rtlBtn = barBtn("") { setRtl(!rtl) }
        fxBtn = barBtn("FX") { setMangaFx(!Cfg.mangaFx) }
        top.addView(fxBtn)
        top.addView(Icons.button(this, Icons.GEAR, sizeDp = 38) { toggleFxPanel() })
        top.addView(Icons.button(this, Icons.CLOUD, sizeDp = 38) { showOnlineMenu() })
        top.addView(modeBtn)
        top.addView(rtlBtn)
        top.addView(Icons.button(this, Icons.CLOSE, sizeDp = 38) { finish() })
        content.addView(top, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))
        // page slider (like a comic app's page bar): drag or tap the track to jump far; flipped for right-to-left reading
        bottomBar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#CC0B1020"))
            setPadding(dp(this@MangaActivity, 14), dp(this@MangaActivity, 6), dp(this@MangaActivity, 14), dp(this@MangaActivity, 8))
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        seekLeft = Ui.text(this, "1", 13f, Ui.TEXT, true).apply {
            gravity = Gravity.CENTER
            minWidth = dp(this@MangaActivity, 38)
        }
        seekRight = Ui.text(this, "1", 13f, Ui.MUTED, true).apply {
            gravity = Gravity.CENTER
            minWidth = dp(this@MangaActivity, 38)
        }
        pageSeek = SeekBar(this).apply {
            max = 0
            progressTintList = android.content.res.ColorStateList.valueOf(Ui.ACCENT)
            thumbTintList = android.content.res.ColorStateList.valueOf(Ui.ACCENT)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    if (fromUser && !seekGuard) setSeekLabels(p)
                }

                override fun onStartTrackingTouch(s: SeekBar) {
                    seekDragging = true
                }

                override fun onStopTrackingTouch(s: SeekBar) {
                    seekDragging = false
                    jumpTo(s.progress)
                }
            })
        }
        bottomBar.addView(seekLeft)
        bottomBar.addView(pageSeek, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bottomBar.addView(seekRight)
        content.addView(bottomBar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        fxPanel = ScrollView(this).apply {
            visibility = View.GONE
            isClickable = true
            background = Ui.round(Color.parseColor("#F5101522"), dp(this@MangaActivity, 22).toFloat(), Ui.STROKE, dp(this@MangaActivity, 1))
            setPadding(dp(this@MangaActivity, 14), dp(this@MangaActivity, 12), dp(this@MangaActivity, 14), dp(this@MangaActivity, 12))
        }
        content.addView(
            fxPanel,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (screenH * 0.58f).toInt(), Gravity.BOTTOM).apply {
                setMargins(dp(this@MangaActivity, 8), 0, dp(this@MangaActivity, 8), dp(this@MangaActivity, 8))
            }
        )
        layoutFxPanel()
        setContentView(content)
        content.setOnApplyWindowInsetsListener { _, ins ->
            val i = ins.getInsetsIgnoringVisibility(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            top.setPadding(dp(this, 12) + i.left, dp(this, 6) + i.top, dp(this, 8) + i.right, dp(this, 6))
            bottomBar.setPadding(dp(this, 14) + i.left, dp(this, 6), dp(this, 14) + i.right, dp(this, 8) + i.bottom)
            ins
        }
        paintButtons()
        paintFx()
        load()
    }

    private fun barBtn(label: String, onClick: () -> Unit) = Ui.text(this, label, 16f, Ui.ACCENT, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(this@MangaActivity, 12), dp(this@MangaActivity, 8), dp(this@MangaActivity, 12), dp(this@MangaActivity, 8))
        setOnClickListener { onClick() }
    }

    private fun paintButtons() {
        modeBtn.text = if (scrollMode) "≡ " + getString(R.string.manga_scroll) else "▭ " + getString(R.string.manga_pages)
        rtlBtn.text = if (rtl) "⇠ " + getString(R.string.manga_dir_rtl) else "⇢ " + getString(R.string.manga_dir_ltr)
        rtlBtn.alpha = if (scrollMode) 0.4f else 1f
        if (::pageSeek.isInitialized) paintSlider()
    }

    private fun paintFx() {
        mangaFxSwitch?.let { if (it.isChecked != Cfg.mangaFx) it.isChecked = Cfg.mangaFx }
        fxBtn.alpha = if (Cfg.mangaFx) 1f else 0.45f
        fxBtn.paintFlags = if (Cfg.mangaFx) fxBtn.paintFlags or android.graphics.Paint.UNDERLINE_TEXT_FLAG
        else fxBtn.paintFlags and android.graphics.Paint.UNDERLINE_TEXT_FLAG.inv()
    }

    private fun setMangaFx(on: Boolean) {
        if (Cfg.mangaFx == on) return
        Cfg.mangaFx = on
        Cfg.save(this)
        paintFx()
        scheduleReload(0)
    }

    /** Panel size (Settings chips at the top of the panel): small / medium / large. */
    private fun layoutFxPanel() {
        val sz = Cfg.panelSize.coerceIn(0, 2)
        val lp = fxPanel.layoutParams as FrameLayout.LayoutParams
        lp.height = (screenH * floatArrayOf(0.38f, 0.58f, 0.80f)[sz]).toInt()
        lp.width = if (sz == 0) (screenW * 0.84f).toInt() else ViewGroup.LayoutParams.MATCH_PARENT
        lp.gravity = if (sz == 0) Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL else Gravity.BOTTOM
        fxPanel.layoutParams = lp
    }

    /** Keeps a dragged settings panel inside the window. */
    private fun clampFxPanel() {
        val par = fxPanel.parent as? View ?: return
        if (fxPanel.width <= 0) return
        val l = fxPanel.left.toFloat()
        val t = fxPanel.top.toFloat()
        fxPanel.translationX = fxPanel.translationX.coerceIn(-l, (par.width - fxPanel.right).toFloat().coerceAtLeast(-l))
        fxPanel.translationY = fxPanel.translationY.coerceIn(-t, (par.height - fxPanel.bottom).toFloat().coerceAtLeast(-t))
    }

    /** Top of the reader's settings panel, grouped like the player's: effect / screen effect / panel. */
    private fun buildMangaHeader(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(
            panelHeader(this, getString(R.string.manga_panel_title) + " · " + Cfg.sectionLabel(this), fxPanel, { clampFxPanel() }, { fxPanel.visibility = View.GONE }) {
                Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
            }
        )
        fun gap(v: Int) = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(this@MangaActivity, v) }

        col.addView(panelSection(this, getString(R.string.panel_sec_effect)), gap(14))
        val fxSw = panelSwitch(this, getString(R.string.manga_fx_switch), Cfg.mangaFx) { setMangaFx(it) }
        mangaFxSwitch = fxSw
        col.addView(fxSw, gap(10))
        col.addView(
            panelSwitch(this, getString(R.string.player_fx_pin_switch), Cfg.fxPinned) {
                Cfg.fxPinned = it
                Cfg.save(this)
                setBars(barsOn)
            },
            gap(10)
        )

        col.addView(panelSection(this, getString(R.string.panel_sec_overlay)), gap(16))
        col.addView(
            panelSwitch(this, getString(R.string.player_pause_overlay_switch), Cfg.pauseOverlayInPlayer) {
                Cfg.pauseOverlayInPlayer = it
                Cfg.save(this)
                OverlayService.instance?.pauseForPlayer(it)
            },
            gap(10)
        )
        col.addView(Ui.text(this, getString(R.string.player_pause_overlay_hint), 12f, Ui.MUTED), gap(2))

        col.addView(panelSection(this, getString(R.string.panel_sec_panel)), gap(16))
        col.addView(panelSizeRow(this) {
            layoutFxPanel()
            fxPanel.post { clampFxPanel() }
        }, gap(10))
        col.addView(Ui.text(this, getString(R.string.panel_lock_hint), 12f, Ui.MUTED), gap(6))
        col.addView(panelSection(this, getString(R.string.player_effects_label)), gap(16))
        return col
    }

    private fun toggleFxPanel() {
        if (fxPanel.visibility == View.VISIBLE) {
            fxPanel.visibility = View.GONE
            return
        }
        if (!fxPanelBuilt) {
            fxPanelBuilt = true
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            box.addView(buildMangaHeader())
            box.addView(
                buildControls(
                    this,
                    onAdjust = { active -> fxPanel.animate().alpha(if (active) 0.35f else 1f).setDuration(120).start() },
                    inPlayer = true,
                    sourceScale = { 1.5f }
                ) { if (Cfg.mangaFx) scheduleReload(350) },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )
            fxPanel.addView(box, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        fxPanel.visibility = View.VISIBLE
        if (!Cfg.mangaFx) setMangaFx(true)
    }

    /** Effects settings changed: pages are decoded and processed again (a short delay while a slider is moving). */
    private fun scheduleReload(delayMs: Long) {
        fxGen++
        ui.removeCallbacks(fxApply)
        ui.postDelayed(fxApply, delayMs)
    }

    private fun reloadPages() {
        if (closed || pages.isEmpty()) return
        cache.evictAll()
        if (scrollMode) {
            adapter.notifyDataSetChanged()
        } else {
            zoom.setBitmap(null)
            showPage(current)
        }
    }

    /** A decoded page, run through the picture effects when they are on for the reader. */
    private fun fetch(p: Page, fitW: Int): Bitmap? {
        enhanced.get(p.idx)?.let { if (!it.isRecycled) return it }
        val g0 = fxGen
        val b = decode(p, fitW) ?: return null
        if (!Cfg.mangaFx) return b
        val out = runCatching { fx.process(b) }.getOrNull() ?: return b
        if (g0 != fxGen) return null // settings changed meanwhile: this result is stale, the page is rebuilt anyway
        return out
    }

    // ---- online enhance of the current page (cloud, paid) ------------------------------------------

    /** Everything the photo viewer's Enhance button offers, for the current page. */
    private fun showOnlineMenu() {
        if (onlineBusy) {
            onlineCancel.set(true)
            return
        }
        val items = arrayOf(
            getString(R.string.enh_auto),
            getString(R.string.enh_ai_fmt, if (Cfg.autoMode) getString(R.string.auto_word) else AiSr.activeLabel(this)),
            getString(R.string.enh_models),
            getString(R.string.online_photo),
            getString(R.string.online_text),
            getString(R.string.enh_original),
            getString(R.string.manga_save_page),
            getString(R.string.online_settings)
        )
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.manga_enhance_title) + "  (" + getString(R.string.manga_progress_fmt, current + 1, pages.size) + ")")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> enhanceCurrent(0)
                    1 -> if (AiSr.hasModel(this)) enhanceCurrent(1) else showCatalogDialog()
                    2 -> showModelsDialog()
                    3 -> enhanceCurrent(2)
                    4 -> enhanceCurrent(3)
                    5 -> restoreOriginalPage()
                    6 -> savePage()
                    else -> Online.showSettings(this)
                }
            }
            .show()
    }

    /** Back to the plain (decoded + FX) version of the current page. */
    private fun restoreOriginalPage() {
        val idx = current
        if (enhanced.get(idx) == null) {
            Toast.makeText(this, R.string.enh_is_original, Toast.LENGTH_SHORT).show()
            return
        }
        enhanced.remove(idx)
        cache.remove(idx)
        ratios.remove(idx)
        if (scrollMode) {
            adapter.notifyDataSetChanged()
        } else {
            zoom.setBitmap(null)
            showPage(idx)
        }
    }

    /**
     * [what]: 0 = smart fix, 1 = offline AI upscale, 2 = online photo x4, 3 = online clearer writing x2.
     * Runs on a worker thread; the top bar shows the progress, the cloud button cancels.
     */
    private fun enhanceCurrent(what: Int) {
        if (what >= 2 && !Online.hasKey(this)) {
            Toast.makeText(this, getString(R.string.online_need_key), Toast.LENGTH_LONG).show()
            Online.showSettings(this)
            return
        }
        if (onlineBusy || pages.isEmpty()) return
        val idx = current
        val page = pages[idx]
        onlineBusy = true
        onlineCancel.set(false)
        progressTv.text = "☁ " + getString(R.string.online_working_fmt, "")
        Thread {
            var err: String? = null
            var out: Bitmap? = null
            var same = false
            try {
                val src = enhanced.get(idx)?.takeIf { !it.isRecycled } ?: decode(page, 0)
                if (src != null) {
                    when (what) {
                        0 -> {
                            val r = Enhance.auto(src)
                            if (r === src) same = true else out = r
                        }
                        1 -> {
                            if (Cfg.autoMode) AiSr.setActive(this, Auto.aiModel(this, src.width, src.height))
                            out = AiSr.upscale(
                                this, src,
                                { pr -> ui.post { if (!closed && onlineBusy) progressTv.text = getString(R.string.ai_progress_fmt, pr) } },
                                onlineCancel, maxOutPx = 16_000_000L
                            )
                        }
                        else -> {
                            out = Online.enhance(this, src, if (what == 3) Online.TEXT else Online.PHOTO, onlineCancel) { st ->
                                ui.post { if (!closed && onlineBusy) progressTv.text = "☁ " + getString(R.string.online_working_fmt, st) }
                            }
                        }
                    }
                }
            } catch (t: Throwable) {
                err = t.message ?: t.javaClass.simpleName
            }
            val e = err
            val o = out
            ui.post {
                onlineBusy = false
                if (closed) return@post
                paintProgress()
                when {
                    e != null -> if (what == 1) Toast.makeText(this, getString(R.string.ai_error_fmt, e), Toast.LENGTH_LONG).show() else Online.showError(this, e)
                    same -> Toast.makeText(this, R.string.enh_nochange, Toast.LENGTH_SHORT).show()
                    o == null -> Toast.makeText(this, getString(R.string.ai_cancelled), Toast.LENGTH_SHORT).show()
                    else -> {
                        enhanced.put(idx, o)
                        cache.put(idx, o)
                        ratios[idx] = o.height.toFloat() / o.width
                        if (scrollMode) adapter.notifyDataSetChanged() else if (current == idx) zoom.setBitmap(o)
                        Toast.makeText(this, getString(if (what == 1) R.string.ai_done else if (what == 0) R.string.enh_auto_done else R.string.online_done), Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }.start()
    }

    // ---- AI models (offline upscaler) --------------------------------------------------------------

    private fun showModelsDialog() {
        if (onlineBusy) { Toast.makeText(this, R.string.manga_model_busy, Toast.LENGTH_SHORT).show(); return }
        val list = AiSr.list(this)
        val active = AiSr.activeId(this)
        val labels = ArrayList<String>()
        for (m in list) labels.add((if (m.id == active) "✓  " else "     ") + m.label)
        labels.add("⬇  " + getString(R.string.model_catalog))
        labels.add("➕  " + getString(R.string.model_add_file))
        labels.add("🌐  " + getString(R.string.model_add_link))
        if (list.any { !it.builtin }) labels.add("🗑  " + getString(R.string.model_remove))
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.model_title))
            .setItems(labels.toTypedArray()) { _, which ->
                when {
                    which < list.size -> {
                        AiSr.setActive(this, list[which].id)
                        Toast.makeText(this, getString(R.string.model_selected_fmt, list[which].label), Toast.LENGTH_SHORT).show()
                    }
                    which == list.size -> showCatalogDialog()
                    which == list.size + 1 -> {
                        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
                        @Suppress("DEPRECATION")
                        startActivityForResult(i, REQ_MODEL)
                    }
                    which == list.size + 2 -> showModelLinkDialog()
                    else -> showRemoveModel()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showCatalogDialog() {
        if (onlineBusy) { Toast.makeText(this, R.string.manga_model_busy, Toast.LENGTH_SHORT).show(); return }
        val cat = AiSr.CATALOG
        val labels = cat.map { c ->
            val state = if (AiSr.isInstalled(this, c)) "✓ " else "⬇ "
            val size = if (c.sizeKb >= 1000) "%.1f MB".format(c.sizeKb / 1000f) else "${c.sizeKb} KB"
            state + c.label + "  (" + size + ")\n    " + getString(c.descRes)
        }
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.model_catalog))
            .setItems(labels.toTypedArray()) { _, which ->
                val c = cat[which]
                runModelJob({ pr -> AiSr.installCatalog(this, c, pr) }, c.label)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showRemoveModel() {
        val removable = AiSr.list(this).filter { !it.builtin }
        if (removable.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.model_remove))
            .setItems(removable.map { it.label }.toTypedArray()) { _, which ->
                AiSr.remove(this, removable[which].id)
                Toast.makeText(this, getString(R.string.model_removed_fmt, removable[which].label), Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showModelLinkDialog() {
        val input = android.widget.EditText(this).apply {
            hint = "https://…/model.tflite"
            setSingleLine()
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val pad = dp(this, 20)
        val box = FrameLayout(this).apply { setPadding(pad, dp(this@MangaActivity, 8), pad, 0) }
        box.addView(input, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.model_add_link))
            .setView(box)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val t = input.text.toString().trim()
                if (t.startsWith("http://") || t.startsWith("https://")) runModelJob({ pr -> AiSr.download(this, t, null, pr) }, "")
                else Toast.makeText(this, R.string.player_error, Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val u = data?.data
        if (req == REQ_MODEL && res == RESULT_OK && u != null) {
            val name = (u.lastPathSegment ?: "model").substringAfterLast('/').substringAfterLast(':')
            runModelJob({ _ -> AiSr.importModel(this, u, name) }, "")
        }
    }

    /** Installs a model on a worker thread; [job] returns the new model's id. [label] is shown in the "added" toast (empty = use the id). */
    private fun runModelJob(job: ((Int) -> Unit) -> String, label: String) {
        // job gets a progress callback taking 0..100
        onlineBusy = true
        onlineCancel.set(false)
        progressTv.text = getString(R.string.ai_downloading_fmt, 0)
        Thread {
            var err: String? = null
            var id: String? = null
            try {
                id = job { pr -> ui.post { if (!closed && onlineBusy) progressTv.text = getString(R.string.ai_downloading_fmt, pr) } }
            } catch (t: Throwable) {
                err = t.message ?: t.javaClass.simpleName
            }
            val e = err
            val added = id
            ui.post {
                onlineBusy = false
                if (closed) return@post
                paintProgress()
                if (e != null || added == null) {
                    Toast.makeText(this, getString(R.string.ai_download_fail_fmt, e ?: "?"), Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, getString(R.string.model_added_fmt, label.ifEmpty { added }), Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    /** Writes the page as it is shown now (with FX / online result) to Pictures/ClearOverlay. */
    private fun savePage() {
        val idx = current
        val b = cache.get(idx)
        if (b == null) {
            Toast.makeText(this, getString(R.string.save_fail), Toast.LENGTH_SHORT).show()
            return
        }
        Thread {
            var ok = false
            runCatching {
                val name = "CRSC_manga_" + java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date()) + "_" + (idx + 1) + ".jpg"
                val values = android.content.ContentValues().apply {
                    put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ClearOverlay")
                    put(android.provider.MediaStore.Images.Media.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: error("insert")
                try {
                    contentResolver.openOutputStream(uri)!!.use { b.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                    values.clear()
                    values.put(android.provider.MediaStore.Images.Media.IS_PENDING, 0)
                    contentResolver.update(uri, values, null, null)
                    ok = true
                } catch (t: Throwable) {
                    runCatching { contentResolver.delete(uri, null, null) }
                }
            }
            ui.post { if (!closed) Toast.makeText(this, getString(if (ok) R.string.save_ok else R.string.save_fail), Toast.LENGTH_SHORT).show() }
        }.start()
    }

    private fun toggleBar() = setBars(!barsOn)

    /** Shows / hides the bars. With "keep the FX button on screen" on, only the FX button stays when they hide. */
    private fun setBars(on: Boolean) {
        barsOn = on
        val pin = Cfg.fxPinned
        bottomBar.visibility = if (on) View.VISIBLE else View.GONE
        top.visibility = if (on || pin) View.VISIBLE else View.GONE
        for (i in 0 until top.childCount) {
            val ch = top.getChildAt(i)
            ch.visibility = when {
                on || ch === fxBtn -> View.VISIBLE
                !pin -> View.VISIBLE
                ch === titlesBox -> View.INVISIBLE
                else -> View.GONE
            }
        }
        top.setBackgroundColor(if (on) Color.parseColor("#CC0B1020") else Color.TRANSPARENT)
        fxBtn.setBackgroundColor(if (!on && pin) Color.parseColor("#99000000") else Color.TRANSPARENT)
    }

    // ---- loading the page list -------------------------------------------------------------------

    private fun load() {
        val u = intent?.data
        val bucket = intent?.getLongExtra(EXTRA_BUCKET, Long.MIN_VALUE) ?: Long.MIN_VALUE
        val tree = intent?.getStringExtra(EXTRA_TREE)
        titleTv.text = intent?.getStringExtra(EXTRA_NAME) ?: ""
        Thread {
            var err: String? = null
            var out: List<Page> = emptyList()
            var k = ""
            try {
                if (u != null) {
                    val f: File
                    if (u.scheme == Net.SCHEME) {
                        // network file: downloaded once into the cache (with progress), so opening it again is instant
                        var lastT = 0L
                        f = Net.download(this, u, { done, total ->
                            val now = System.currentTimeMillis()
                            if (now - lastT > 300) {
                                lastT = now
                                val t = if (total > 0) "${done shr 20} / ${total shr 20} MB" else "${done shr 20} MB"
                                ui.post { if (!closed) progressTv.text = getString(R.string.manga_dl_fmt, t) }
                            }
                        }, { !closed })
                    } else {
                        f = File(cacheDir, "manga_src.bin")
                        // the archive is copied to the cache once; opening the same file again reuses that copy
                        val size = runCatching { contentResolver.openAssetFileDescriptor(u, "r")?.use { it.length } }.getOrNull() ?: -1L
                        val stamp = u.toString() + "|" + size
                        if (!(f.exists() && size > 0 && f.length() == size && prefs.getString("manga_src_stamp", "") == stamp)) {
                            runCatching { prefs.edit().remove("manga_src_stamp").apply() }
                            ui.post { if (!closed) progressTv.text = getString(R.string.manga_preparing) }
                            (contentResolver.openInputStream(u) ?: error("cannot open")).use { ins -> f.outputStream().use { ins.copyTo(it) } }
                            if (size > 0) prefs.edit().putString("manga_src_stamp", stamp).apply()
                        }
                    }
                    val head = ByteArray(8)
                    f.inputStream().use { it.read(head) }
                    val isPdf = head[0] == 0x25.toByte() && head[1] == 0x50.toByte() && head[2] == 0x44.toByte() && head[3] == 0x46.toByte()
                    val isZip = head[0] == 0x50.toByte() && head[1] == 0x4B.toByte()
                    val isRar = head[0] == 0x52.toByte() && head[1] == 0x61.toByte() && head[2] == 0x72.toByte()
                    val is7z = head[0] == 0x37.toByte() && head[1] == 0x7A.toByte()
                    when {
                        isPdf -> {
                            val r = PdfRenderer(ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY))
                            pdf = r
                            out = List(r.pageCount) { Page(null, null, it) }
                            k = "pdf_" + u.toString().hashCode()
                        }
                        isZip -> {
                            val z = try {
                                ZipFile(f)
                            } catch (e: Exception) {
                                ZipFile(f, java.nio.charset.Charset.forName("ISO-8859-1")) // names that are not UTF-8
                            }
                            zip = z
                            val names = ArrayList<String>()
                            val others = ArrayList<String>()
                            var total = 0
                            val en = z.entries()
                            while (en.hasMoreElements()) {
                                val e = en.nextElement()
                                val n = e.name
                                val l = n.lowercase()
                                if (e.isDirectory || n.contains("__MACOSX")) continue
                                total++
                                val base = l.substringAfterLast('/').substringAfterLast('\\')
                                if (base.startsWith(".") || base == "thumbs.db") continue
                                // pictures in any sub-folder count (chapter folders inside the archive are fine)
                                if (base.endsWith(".jpg") || base.endsWith(".jpeg") || base.endsWith(".jfif") || base.endsWith(".png") ||
                                    base.endsWith(".webp") || base.endsWith(".gif") || base.endsWith(".bmp") ||
                                    base.endsWith(".avif") || base.endsWith(".heic") || base.endsWith(".heif")
                                ) names.add(n) else if (others.size < 3) others.add(n.substringAfterLast('/'))
                            }
                            if (names.isEmpty()) {
                                error(getString(R.string.manga_zip_noimages_fmt, total, others.joinToString(", ")))
                            }
                            names.sortWith { a, b -> Media.natural(a.replace('\\', '/'), b.replace('\\', '/')) }
                            out = names.map { Page(null, it) }
                            k = "cbz_" + u.toString().hashCode()
                        }
                        isRar -> {
                            // a .cbr (or a RAR renamed to .cbz): the pictures are unpacked once into the cache
                            if (head[6] == 1.toByte()) error(getString(R.string.manga_rar5_unsupported))
                            val dir = File(cacheDir, "manga_rar")
                            dir.deleteRecursively()
                            dir.mkdirs()
                            val files = ArrayList<Pair<String, File>>()
                            val arc = try { com.github.junrar.Archive(f) } catch (t: Throwable) { error(getString(R.string.manga_rar5_unsupported) + "\n" + (t.message ?: "")) }
                            arc.use { a ->
                                var n = 0
                                for (fh in a.fileHeaders) {
                                    if (closed) break
                                    if (fh.isDirectory) continue
                                    val nm = fh.fileName.replace('\\', '/')
                                    val base = nm.substringAfterLast('/').lowercase()
                                    if (base.startsWith(".") || !(base.endsWith(".jpg") || base.endsWith(".jpeg") || base.endsWith(".jfif") || base.endsWith(".png") ||
                                            base.endsWith(".webp") || base.endsWith(".gif") || base.endsWith(".bmp"))) continue
                                    val target = File(dir, "p" + (n++) + "." + base.substringAfterLast('.'))
                                    target.outputStream().use { o -> a.extractFile(fh, o) }
                                    files.add(Pair(nm, target))
                                    if (n % 10 == 0) ui.post { if (!closed) progressTv.text = getString(R.string.manga_preparing) + " " + n }
                                }
                            }
                            files.sortWith { x, y -> Media.natural(x.first, y.first) }
                            out = files.map { Page(Uri.fromFile(it.second), null) }
                            k = "cbz_" + u.toString().hashCode()
                        }
                        is7z -> error(getString(R.string.manga_rar_unsupported))
                        else -> error(getString(R.string.manga_unknown_file))
                    }
                    histSrc = "file"
                    histRef = u.toString()
                    if (titleTv.text.isEmpty()) ui.post { titleTv.text = (u.lastPathSegment ?: "").substringAfterLast('/').substringAfterLast(':') }
                } else if (tree != null) {
                    out = Media.mangaPagesTree(this, Uri.parse(tree)).map { Page(it, null) }
                    k = "bt_" + tree.hashCode()
                    histSrc = "tree"
                    histRef = tree
                } else if (bucket != Long.MIN_VALUE) {
                    out = Media.mangaPages(this, bucket).map { Page(it, null) }
                    k = "bk_$bucket"
                    histSrc = "bucket"
                    histRef = bucket.toString()
                }
            } catch (t: Throwable) {
                err = t.message ?: t.javaClass.simpleName
            }
            val e = err
            val result = out
            val kk = k
            ui.post {
                if (closed) return@post
                if (e != null || result.isEmpty()) {
                    Toast.makeText(this, getString(R.string.manga_empty) + (if (e != null) "\n$e" else ""), Toast.LENGTH_LONG).show()
                    finish()
                    return@post
                }
                result.forEachIndexed { i, pg -> pg.idx = i }
                pages = result
                key = kk
                current = prefs.getInt("manga_pos_$key", 0).coerceIn(0, pages.size - 1)
                showMode()
            }
        }.start()
    }

    // ---- decoding --------------------------------------------------------------------------------

    private fun open(p: Page): InputStream? =
        if (p.entry != null) zip?.let { z -> z.getEntry(p.entry)?.let { e -> z.getInputStream(e) } }
        else p.uri?.let { contentResolver.openInputStream(it) }

    /** [fitW]: wanted width in pixels (scroll mode) or 0 for "long side up to about 3000 px" (page mode). */
    /** A PDF page rendered on white, at [fitW] pixels wide (or about 2x the screen width when 0). */
    private fun decodePdf(i: Int, fitW: Int): Bitmap? {
        val r = pdf ?: return null
        synchronized(pdfLock) {
            val pg = r.openPage(i)
            try {
                var w = if (fitW > 0) fitW else minOf(maxOf(screenW * 2, 1400), 2400)
                var h = (w.toFloat() * pg.height / pg.width.coerceAtLeast(1)).toInt().coerceAtLeast(1)
                while (w.toLong() * h > 9_000_000L) {
                    w = w * 4 / 5
                    h = h * 4 / 5
                }
                val bmp = Bitmap.createBitmap(w.coerceAtLeast(1), h.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
                bmp.eraseColor(Color.WHITE)
                pg.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                return bmp
            } finally {
                pg.close()
            }
        }
    }

    private fun decode(p: Page, fitW: Int): Bitmap? {
        if (p.pdf >= 0) return decodePdf(p.pdf, fitW)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        open(p)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        val w = bounds.outWidth
        val h = bounds.outHeight
        var sample = 1
        if (fitW > 0) {
            while (w / (sample * 2) >= fitW) sample *= 2
        } else {
            while (max(w, h) / sample > 3000) sample *= 2
        }
        // very long strips: keep the decoded size within about 8 megapixels
        val px = w.toDouble() * h
        val need = ceil(sqrt(px / 8_000_000.0)).toInt().coerceAtLeast(1)
        while (sample < need) sample *= 2
        val o = BitmapFactory.Options().apply { inSampleSize = sample }
        return open(p)?.use { BitmapFactory.decodeStream(it, null, o) }
    }

    // ---- modes -----------------------------------------------------------------------------------

    private fun setScrollMode(on: Boolean) {
        scrollMode = on
        prefs.edit().putBoolean("manga_scroll", on).apply()
        cache.evictAll()
        ratios.clear()
        paintButtons()
        showMode()
    }

    private fun setRtl(on: Boolean) {
        rtl = on
        prefs.edit().putBoolean("manga_rtl", on).apply()
        paintButtons()
    }

    private fun showMode() {
        if (pages.isEmpty()) return
        sliding = false
        zoom.animate().cancel()
        zoom.translationX = 0f
        if (scrollMode) {
            zoom.visibility = View.GONE
            list.visibility = View.VISIBLE
            list.adapter = adapter
            list.setSelection(current)
        } else {
            list.visibility = View.GONE
            zoom.visibility = View.VISIBLE
            showPage(current)
        }
        paintProgress()
    }

    private fun paintProgress() {
        progressTv.text = getString(R.string.manga_progress_fmt, current + 1, pages.size)
        if (::pageSeek.isInitialized && !seekDragging) paintSlider()
    }

    private fun paintSlider() {
        val n = pages.size
        val flip = !scrollMode && rtl
        pageSeek.scaleX = if (flip) -1f else 1f
        seekGuard = true
        pageSeek.max = (n - 1).coerceAtLeast(0)
        pageSeek.progress = current.coerceIn(0, pageSeek.max)
        seekGuard = false
        setSeekLabels(current)
    }

    private fun setSeekLabels(cur: Int) {
        val flip = !scrollMode && rtl
        val c = (cur + 1).toString()
        val t = pages.size.toString()
        seekLeft.text = if (flip) t else c
        seekRight.text = if (flip) c else t
        seekLeft.setTextColor(if (flip) Ui.MUTED else Ui.TEXT)
        seekRight.setTextColor(if (flip) Ui.TEXT else Ui.MUTED)
    }

    /** Jump straight to page [i] (0-based) from the slider. */
    private fun jumpTo(i: Int) {
        if (pages.isEmpty()) return
        val n = i.coerceIn(0, pages.size - 1)
        if (scrollMode) {
            list.setSelection(n)
        } else {
            sliding = false
            zoom.animate().cancel()
            zoom.translationX = 0f
            if (cache.get(n) == null) zoom.setBitmap(null)
            showPage(n)
        }
    }

    // ---- page mode -------------------------------------------------------------------------------

    private fun turn(d: Int) {
        if (sliding) return
        val n = current + d
        if (n < 0 || n >= pages.size) {
            Toast.makeText(this, getString(if (d > 0) R.string.list_last else R.string.list_first), Toast.LENGTH_SHORT).show()
            return
        }
        slideTo(n, d)
    }

    /** Horizontal slide: the old page leaves in the reading direction, the new one comes in from the other side. */
    private fun slideTo(n: Int, d: Int) {
        val w = zoom.width.toFloat().coerceAtLeast(1f)
        // exit side: next page with right-to-left reading slides the old page off to the right, and so on
        val s = if (d > 0) (if (rtl) 1f else -1f) else (if (rtl) -1f else 1f)
        zoom.animate().cancel()
        sliding = true
        zoom.animate().translationX(s * w).setDuration(120).withEndAction {
            if (closed) return@withEndAction
            if (cache.get(n) == null) zoom.setBitmap(null)
            showPage(n)
            zoom.translationX = -s * w
            zoom.animate().translationX(0f).setDuration(160).withEndAction { sliding = false }.start()
        }.start()
    }

    private fun showPage(i: Int) {
        current = i
        paintProgress()
        prefs.edit().putInt("manga_pos_$key", i).apply()
        val c = cache.get(i)
        if (c != null) {
            zoom.setBitmap(c)
        } else {
            pool.execute {
                val b = fetch(pages[i], 0)
                ui.post {
                    if (closed || b == null) return@post
                    cache.put(i, b)
                    if (current == i && !scrollMode) zoom.setBitmap(b)
                }
            }
        }
        // preload the neighbours so turning either way is instant
        for (nx in intArrayOf(i + 1, i - 1)) {
            if (nx in 0 until pages.size && cache.get(nx) == null) {
                pool.execute {
                    val b = fetch(pages[nx], 0)
                    if (b != null && !closed) cache.put(nx, b)
                }
            }
        }
    }

    // ---- scroll mode -----------------------------------------------------------------------------

    private val adapter = object : BaseAdapter() {
        override fun getCount() = pages.size
        override fun getItem(position: Int): Any = pages[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val iv = (convertView as? ImageView) ?: ImageView(this@MangaActivity).apply {
                scaleType = ImageView.ScaleType.FIT_XY
                setBackgroundColor(Color.parseColor("#101018"))
            }
            iv.tag = position
            val r = ratios[position]
            val h = if (r != null) (screenW * r).toInt() else screenW * 3 / 2
            iv.layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h)
            val hit = cache.get(position)
            if (hit != null) {
                iv.setImageBitmap(hit)
            } else {
                iv.setImageDrawable(null)
                val page = pages[position]
                pool.execute {
                    val b = fetch(page, screenW) ?: return@execute
                    cache.put(position, b)
                    val ratio = b.height.toFloat() / b.width
                    ui.post {
                        if (closed) return@post
                        val changed = ratios[position] != ratio
                        ratios[position] = ratio
                        if (iv.tag == position) {
                            iv.setImageBitmap(b)
                            iv.layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (screenW * ratio).toInt())
                            if (changed) iv.requestLayout()
                        }
                    }
                }
            }
            return iv
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }
    }

    override fun onResume() {
        super.onResume()
        Cfg.bind(this, "manga")
        if (Cfg.pauseOverlayInPlayer) OverlayService.instance?.pauseForPlayer(true)
    }

    override fun onPause() {
        OverlayService.instance?.pauseForPlayer(false)
        Cfg.bind(this, "screen")
        if (pages.isNotEmpty() && key.isNotEmpty()) {
            prefs.edit().putInt("manga_pos_$key", current).apply()
            // History: left half way = listed so it can be continued; read to the last page = removed
            if (current >= pages.size - 1) History.remove(this, 1, key)
            else History.put(this, History.Entry(1, key, titleTv.text.toString(), current.toLong(), pages.size.toLong(), System.currentTimeMillis(), histSrc, histRef))
        }
        super.onPause()
    }

    override fun onDestroy() {
        Ui.init(this)
        closed = true
        pool.shutdownNow()
        ui.removeCallbacks(fxApply)
        fx.release()
        ui.removeCallbacksAndMessages(null)
        runCatching { zip?.close() }
        runCatching { pdf?.close() }
        super.onDestroy()
    }

    companion object {
        const val EXTRA_BUCKET = "app.clearoverlay.BUCKET"
        const val EXTRA_NAME = "app.clearoverlay.NAME"
        const val EXTRA_TREE = "app.clearoverlay.TREE"
        private const val REQ_MODEL = 24
    }
}
