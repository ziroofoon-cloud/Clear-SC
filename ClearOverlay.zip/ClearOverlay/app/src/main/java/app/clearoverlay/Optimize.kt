package app.clearoverlay

/**
 * "Make it lighter": goes through the chosen picture settings and removes only the work that gives the same picture (or one nobody can tell
 * apart): the heavy original NIS is the same picture as NIS fast (largest difference 1/255, see README 3.88.0), and a setting with a tiny strength
 * costs a whole GPU pass for nothing visible. Everything else is left alone; the heavy-but-visible settings are what "Auto-lighten" is for.
 */
object Optimize {
    /** The resource ids of the lines that describe what was changed (empty = nothing to lighten). */
    fun run(): List<Int> {
        val out = ArrayList<Int>()
        if (Cfg.mode == Cfg.MODE_NIS_ORIG) {
            Cfg.mode = Cfg.MODE_NIS_FAST
            out.add(R.string.opt_nis)
        }
        if (Cfg.denoise > 0f && Cfg.denoise < 0.06f) { Cfg.denoise = 0f; out.add(R.string.opt_denoise) }
        if (Cfg.deband > 0f && Cfg.deband < 0.06f) { Cfg.deband = 0f; out.add(R.string.opt_deband) }
        if (Cfg.detail > 0f && Cfg.detail < 0.04f) { Cfg.detail = 0f; out.add(R.string.opt_detail) }
        if (Cfg.clarity != 0f && Math.abs(Cfg.clarity) < 0.04f) { Cfg.clarity = 0f; out.add(R.string.opt_clarity) }
        if (Cfg.antiRing > 0f && Cfg.antiRing < 0.05f) { Cfg.antiRing = 0f; out.add(R.string.opt_antiring) }
        if (Cfg.crscExact && Cfg.crscLevel < 5 && Cfg.mode == Cfg.MODE_LANCZOS) { Cfg.crscExact = false; out.add(R.string.opt_exact) }
        return out
    }
}
