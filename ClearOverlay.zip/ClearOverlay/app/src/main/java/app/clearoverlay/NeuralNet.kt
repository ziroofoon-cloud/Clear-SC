package app.clearoverlay

import android.content.Context

/**
 * The "Neural" upscaler: a tiny convolutional network (luma only, 4 layers, 8 / 12 / 16 channels, about 1.5k / 3k / 5k numbers) that runs as plain
 * OpenGL shaders in the live picture. It predicts the difference between the real picture and a plain bilinear enlargement; the colours are
 * the bilinear ones. A model is a text pack (`assets/neural/lite.nsr`, `medium.nsr`, `plus.nsr`) written by `tools/neural/gen_pack.py` from the weights of
 * `tools/neural/train.py`: the shaders of every pass, with the weights inlined as constants.
 *
 *   @l1        the luma of the picture -> N feature maps (N = channels / 4 targets of 4 channels each, drawn at once)
 *   @hid1..    one pass per hidden layer, N maps -> N maps (ReLU)
 *   @head      the last convolution: N maps -> 4 numbers per pixel (the 4 sub-pixels of a 2x2 block)
 *   @compose   draws the 2x picture: bilinear colours + the number of the sub-pixel
 */
object NeuralNet {
    @Volatile private var appCtx: Context? = null

    /** The application context given to [attach] (null before it), for reading the other shader assets. */
    fun context(): Context? = appCtx

    fun attach(c: Context) {
        if (appCtx == null) appCtx = c.applicationContext
    }

    class Pack(val channels: Int, val layers: Int, val sources: Map<String, String>)

    private val cache = HashMap<Int, Pack?>()

    /** The model [idx] (0 = Lite, 1 = Plus, 2 = Medium), or null when it cannot be read. */
    @Synchronized
    fun pack(idx: Int): Pack? {
        if (cache.containsKey(idx)) return cache[idx]
        val p = load(idx)
        cache[idx] = p
        return p
    }

    private fun load(idx: Int): Pack? {
        val c = appCtx ?: return null
        return runCatching {
            val name = when (idx) { 1 -> "plus"; 2 -> "medium"; else -> "lite" }
            val text = c.assets.open("neural/$name.nsr").use { String(it.readBytes(), Charsets.UTF_8) }
            parse(text)
        }.getOrNull()
    }

    fun parse(text: String): Pack? {
        val lines = text.split('\n')
        if (lines.isEmpty() || lines[0].trim() != "NSR2") return null
        var channels = 0
        var layers = 0
        val sources = HashMap<String, StringBuilder>()
        var cur: StringBuilder? = null
        for (i in 1 until lines.size) {
            val ln = lines[i]
            if (ln.startsWith("@")) {
                val n = ln.substring(1).trim()
                cur = if (n == "end") null else StringBuilder().also { sources[n] = it }
            } else if (cur != null) {
                cur.append(ln).append('\n')
            } else if (ln.startsWith("channels ")) {
                channels = ln.substring(9).trim().toIntOrNull() ?: 0
            } else if (ln.startsWith("layers ")) {
                layers = ln.substring(7).trim().toIntOrNull() ?: 0
            }
        }
        if (channels < 4 || channels % 4 != 0 || channels > 16 || layers < 3) return null
        val need = ArrayList<String>()
        need.add("l1")
        for (i in 1..layers - 2) need.add("hid$i")
        need.add("head")
        need.add("compose")
        for (n in need) if (sources[n] == null) return null
        return Pack(channels, layers, sources.mapValues { it.value.toString() })
    }
}
