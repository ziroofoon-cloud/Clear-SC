package app.clearoverlay

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Profiles saved by the user ("My profiles"): a snapshot of every PICTURE setting (mode, sharpness, detail, denoise,
 * deband, anti-aliasing, render scale, vivid, boost). Bubble settings are not included, same as the quick profiles.
 * They live in SharedPreferences as one JSON array, so they survive updates and are never touched by the quick
 * profiles: load one at any time to get your exact values back.
 *
 * [AUTO] is a reserved slot filled by the app itself: right before a quick profile replaces hand-made settings, they
 * are copied here, so "undo" is always one tap away.
 */
object UserProfiles {
    const val AUTO = "@auto"
    const val MAX_NAME = 24

    private fun prefs(c: Context) = c.getSharedPreferences("crsc", Context.MODE_PRIVATE)

    private fun read(c: Context): JSONArray =
        runCatching { JSONArray(prefs(c).getString("uprofiles", "[]")) }.getOrDefault(JSONArray())

    private fun write(c: Context, a: JSONArray) {
        prefs(c).edit().putString("uprofiles", a.toString()).apply()
    }

    /** Names in saved order, with the automatic slot last. */
    fun names(c: Context): List<String> {
        val a = read(c)
        val out = ArrayList<String>()
        for (i in 0 until a.length()) a.optJSONObject(i)?.optString("name")?.takeIf { it.isNotEmpty() && it != AUTO }?.let { out.add(it) }
        if (has(c, AUTO)) out.add(AUTO)
        return out
    }

    fun has(c: Context, name: String): Boolean {
        val a = read(c)
        for (i in 0 until a.length()) if (a.optJSONObject(i)?.optString("name").equals(name, true)) return true
        return false
    }

    fun clean(name: String): String = name.trim().replace(Regex("\\s+"), " ").take(MAX_NAME)

    private fun snapshot(c: Context, name: String): JSONObject = JSONObject().apply {
        put("name", name)
        put("mode", Cfg.mode)
        put("crsclv", Cfg.crscLevel)
        put("crscnis", Cfg.crscNis)
        put("crscnisfast", Cfg.crscNisFast)
        put("crscexact", Cfg.crscExact)
        put("nisfastlv", Cfg.nisFastLevel)
        put("nismidq", Cfg.nisMidLevel)
        put("sharp", Cfg.sharp.toDouble())
        put("scale", Cfg.scalePct)
        put("preset", Cfg.renderPreset)
        put("boost", Cfg.boost)
        put("vivid", Cfg.vivid.toDouble())
        put("contrast", Cfg.contrast.toDouble())
        put("shadows", Cfg.shadows.toDouble())
        put("highlights", Cfg.highlights.toDouble())
        put("saturation", Cfg.saturation.toDouble())
        put("warmth", Cfg.warmth.toDouble())
        put("grain", Cfg.grain.toDouble())
        put("vig", Cfg.vignette.toDouble())
        put("fade", Cfg.fade.toDouble())
        put("fixspd", Cfg.fixSpeed.toDouble())
        put("clarity", Cfg.clarity.toDouble())
        put("antiring", Cfg.antiRing.toDouble())
        put("deint", Cfg.deint)
        put("detail", Cfg.detail.toDouble())
        put("detailsz", Cfg.detailSize.toDouble())
        put("denoise", Cfg.denoise.toDouble())
        put("chroma", Cfg.chromaClean.toDouble())
        put("sprot", Cfg.sharpProtect.toDouble())
        put("deband", Cfg.deband.toDouble())
        put("glight", Cfg.gameLight.toDouble())
        put("aa", Cfg.aaMode)
        put("aastr", Cfg.aaStrength.toDouble())
        put("lalpha", Cfg.layerAlpha.toDouble())
        put("plevel", Cfg.profileLevel)
        put("pbudget", Cfg.profileBudget)
        put("pbudgetauto", Cfg.budgetAuto)
        // every other picture (FX) setting too
        put("bright", Cfg.brightness.toDouble())
        put("vibr", Cfg.vibrance.toDouble())
        put("tint", Cfg.tint.toDouble())
        put("smartfix", Cfg.smartFix)
        put("fixlv", Cfg.fixLevel.toDouble())
        put("cleanup", Cfg.cleanUp)
        put("cleanlv", Cfg.cleanLevel.toDouble())
        put("pixfac", Cfg.pixelFactor.toDouble())
        put("finepix", Cfg.finePixels)
        put("autocrop", Cfg.autoCrop)
        put("cleanauto", Cfg.cleanAuto)
        put("smoothlive", Cfg.smoothLive)
        put("inres", Cfg.inRes)
        put("midres", Cfg.midRes)
        put("outres", Cfg.outRes)
        put("pfg", Cfg.playerFg)
        put("pfgn", Cfg.playerFgN)
        put("pfgq", Cfg.playerFgQ)
        put("ptemporal", Cfg.playerTemporal)
        put("dim", Cfg.dim.toDouble())
        // and, as a safety net, every picture setting that exists (see Cfg.pictureDump): a setting added later needs no edit in this file
        runCatching { Cfg.save(c); put("x", Cfg.pictureDump(c)) }
    }

    /** Saves the current picture settings under [name]; an existing profile with that name is replaced. */
    fun save(c: Context, name: String) {
        val n = if (name == AUTO) AUTO else clean(name)
        if (n.isEmpty()) return
        val old = read(c)
        val out = JSONArray()
        var replaced = false
        for (i in 0 until old.length()) {
            val o = old.optJSONObject(i) ?: continue
            if (o.optString("name").equals(n, true)) {
                out.put(snapshot(c, n))
                replaced = true
            } else out.put(o)
        }
        if (!replaced) out.put(snapshot(c, n))
        write(c, out)
    }

    fun saveAuto(c: Context) = save(c, AUTO)

    /** Gives a saved profile a new name. False when the name is empty, taken by another profile, or the profile is the automatic slot. */
    fun rename(c: Context, old: String, newName: String): Boolean {
        if (old == AUTO) return false
        val n = clean(newName)
        if (n.isEmpty() || n == AUTO) return false
        if (!n.equals(old, true) && has(c, n)) return false
        val a = read(c)
        var done = false
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            if (o.optString("name").equals(old, true)) {
                o.put("name", n)
                done = true
            }
        }
        if (done) write(c, a)
        return done
    }

    fun delete(c: Context, name: String) {
        val old = read(c)
        val out = JSONArray()
        for (i in 0 until old.length()) {
            val o = old.optJSONObject(i) ?: continue
            if (!o.optString("name").equals(name, true)) out.put(o)
        }
        write(c, out)
    }

    /** Copies a saved profile into [Cfg] (and saves it). The caller refreshes the UI and re-applies the capture size. */
    fun apply(c: Context, name: String): Boolean {
        val a = read(c)
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            if (!o.optString("name").equals(name, true)) continue
            Cfg.mode = o.optInt("mode", Cfg.mode).coerceIn(0, 14)
            Cfg.crscLevel = o.optInt("crsclv", Cfg.crscLevel).coerceIn(0, 5)
            Cfg.crscNis = o.optInt("crscnis", Cfg.crscNis).coerceIn(0, 4)
            Cfg.crscNisFast = o.optBoolean("crscnisfast", Cfg.crscNisFast)
            Cfg.crscExact = o.optBoolean("crscexact", Cfg.crscExact)
            Cfg.nisFastLevel = o.optInt("nisfastlv", Cfg.nisFastLevel).coerceIn(0, 2)
            if (o.has("nismidq")) Cfg.nisMidLevel = o.optInt("nismidq", Cfg.nisMidLevel).coerceIn(0, 2)
            else if (o.has("nismidlv")) Cfg.nisMidLevel = o.optInt("nismidlv", 0).coerceIn(0, 1) + 1 // saved by an older version
            Cfg.sharp = o.optDouble("sharp", Cfg.sharp.toDouble()).toFloat().coerceIn(0f, 1f)
            Cfg.scalePct = o.optInt("scale", Cfg.scalePct).coerceIn(Cfg.SCALE_MIN, Cfg.SCALE_MAX)
            Cfg.renderPreset = o.optInt("preset", Cfg.renderPreset)
            Cfg.boost = o.optBoolean("boost", Cfg.boost)
            Cfg.vivid = o.optDouble("vivid", Cfg.vivid.toDouble()).toFloat().coerceIn(0f, 1f)
            Cfg.contrast = o.optDouble("contrast", Cfg.contrast.toDouble()).toFloat().coerceIn(-1f, 1f)
            Cfg.shadows = o.optDouble("shadows", 0.0).toFloat().coerceIn(-1f, 1f)
            Cfg.highlights = o.optDouble("highlights", 0.0).toFloat().coerceIn(-1f, 1f)
            Cfg.saturation = o.optDouble("saturation", 0.0).toFloat().coerceIn(-1f, 1f)
            Cfg.warmth = o.optDouble("warmth", 0.0).toFloat().coerceIn(-1f, 1f)
            Cfg.grain = o.optDouble("grain", 0.0).toFloat().coerceIn(0f, 1f)
            Cfg.vignette = o.optDouble("vig", 0.0).toFloat().coerceIn(-1f, 1f)
            Cfg.fade = o.optDouble("fade", 0.0).toFloat().coerceIn(0f, 1f)
            Cfg.fixSpeed = o.optDouble("fixspd", 0.3).toFloat().coerceIn(0f, 1f)
            Cfg.clarity = o.optDouble("clarity", 0.0).toFloat().coerceIn(-1f, 1f)
            Cfg.antiRing = o.optDouble("antiring", 0.0).toFloat().coerceIn(0f, 1f)
            Cfg.deint = o.optInt("deint", 0).coerceIn(0, 2)
            Cfg.detail = o.optDouble("detail", Cfg.detail.toDouble()).toFloat().coerceIn(0f, 1f)
            Cfg.detailSize = o.optDouble("detailsz", Cfg.detailSize.toDouble()).toFloat().coerceIn(0f, 1f)
            Cfg.denoise = o.optDouble("denoise", Cfg.denoise.toDouble()).toFloat().coerceIn(0f, 1f)
            // a profile saved before these two existed keeps what is set now
            if (o.has("chroma")) Cfg.chromaClean = o.optDouble("chroma", Cfg.chromaClean.toDouble()).toFloat().coerceIn(0f, 1f)
            if (o.has("sprot")) Cfg.sharpProtect = o.optDouble("sprot", Cfg.sharpProtect.toDouble()).toFloat().coerceIn(0f, 1f)
            Cfg.deband = o.optDouble("deband", Cfg.deband.toDouble()).toFloat().coerceIn(0f, 1f)
            Cfg.gameLight = o.optDouble("glight", 0.0).toFloat().coerceIn(0f, 1f)
            Cfg.aaMode = o.optInt("aa", Cfg.aaMode).coerceIn(0, 4)
            Cfg.aaStrength = o.optDouble("aastr", Cfg.aaStrength.toDouble()).toFloat().coerceIn(0f, 1f)
            Cfg.layerAlpha = o.optDouble("lalpha", Cfg.layerAlpha.toDouble()).toFloat().coerceIn(0.1f, 1f)
            Cfg.profileLevel = o.optInt("plevel", Cfg.profileLevel).coerceIn(0, 3)
            Cfg.profileBudget = o.optInt("pbudget", Cfg.profileBudget).coerceIn(0, 2)
            Cfg.budgetAuto = o.optBoolean("pbudgetauto", false)
            Cfg.brightness = o.optDouble("bright", 0.0).toFloat().coerceIn(-1f, 1f)
            Cfg.vibrance = o.optDouble("vibr", 0.0).toFloat().coerceIn(-1f, 1f)
            Cfg.tint = o.optDouble("tint", 0.0).toFloat().coerceIn(-1f, 1f)
            // (settings that older saved profiles do not have keep their current value)
            if (o.has("smartfix")) Cfg.smartFix = o.optBoolean("smartfix", Cfg.smartFix)
            if (o.has("fixlv")) Cfg.fixLevel = o.optDouble("fixlv", Cfg.fixLevel.toDouble()).toFloat().coerceIn(0f, 1f)
            if (o.has("cleanup")) Cfg.cleanUp = o.optBoolean("cleanup", Cfg.cleanUp)
            if (o.has("pixfac")) Cfg.pixelFactor = o.optDouble("pixfac", Cfg.pixelFactor.toDouble()).toFloat().coerceIn(Cfg.PIXEL_MIN, Cfg.PIXEL_MAX)
            if (o.has("finepix")) Cfg.finePixels = o.optBoolean("finepix", Cfg.finePixels)
            // a profile saved when Fine pixels was an upscaler of its own
            if (Cfg.mode == Cfg.MODE_PIXEL) { Cfg.mode = Cfg.MODE_FSR; Cfg.finePixels = true }
            if (o.has("cleanlv")) Cfg.cleanLevel = o.optDouble("cleanlv", Cfg.cleanLevel.toDouble()).toFloat().coerceIn(0f, 1f)
            if (o.has("autocrop")) Cfg.autoCrop = o.optBoolean("autocrop", Cfg.autoCrop)
            if (o.has("cleanauto")) Cfg.cleanAuto = o.optBoolean("cleanauto", Cfg.cleanAuto)
            if (o.has("smoothlive")) Cfg.smoothLive = o.optBoolean("smoothlive", Cfg.smoothLive)
            if (o.has("inres")) Cfg.inRes = o.optInt("inres", 0).coerceAtLeast(0)
            if (o.has("midres")) Cfg.midRes = o.optInt("midres", 0).coerceAtLeast(0)
            if (o.has("outres")) Cfg.outRes = o.optInt("outres", 0).coerceAtLeast(0)
            if (o.has("pfg")) Cfg.playerFg = o.optBoolean("pfg", Cfg.playerFg)
            if (o.has("pfgn")) Cfg.playerFgN = o.optInt("pfgn", Cfg.playerFgN).coerceIn(2, 4)
            if (o.has("pfgq")) Cfg.playerFgQ = o.optInt("pfgq", Cfg.playerFgQ).coerceIn(0, 3)
            if (o.has("ptemporal")) Cfg.playerTemporal = o.optInt("ptemporal", Cfg.playerTemporal).coerceIn(0, 2)
            if (o.has("dim")) Cfg.dim = o.optDouble("dim", Cfg.dim.toDouble()).toFloat().coerceIn(0f, 1f)
            Cfg.save(c)
            // every other picture setting the profile holds (a setting added after this list was written is still loaded)
            Cfg.pictureRestore(c, o.optJSONObject("x"))
            Cfg.profileType = -1 // the exact saved values are in force: no quick profile is "active"
            Cfg.userProfile = o.optString("name")
            Cfg.save(c)
            return true
        }
        return false
    }
}
