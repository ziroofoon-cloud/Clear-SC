package app.clearoverlay

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Profiles saved by the user ("My profiles"): a snapshot of every PICTURE setting (mode, sharpness, detail, denoise,
 * deband, anti-aliasing, render scale, vivid, boost). Bubble settings are not included, same as the quick profiles.
 * They live in SharedPreferences as one JSON array, so they survive updates and are never touched by the quick
 * profiles: load one at any time to get your exact values back.
 *
 * [AUTO] is a reserved slot filled by the app itself: right before a quick profile replaces hand-made settings, they
 * are copied here, so "undo" is always one tap away.
 */
object UserProfiles {
    const val AUTO = "@auto"
    const val MAX_NAME = 24

    private fun prefs(c: Context) = c.getSharedPreferences("crsc", Context.MODE_PRIVATE)

    private fun read(c: Context): JSONArray =
        runCatching { JSONArray(prefs(c).getString("uprofiles", "[]")) }.getOrDefault(JSONArray())

    private fun write(c: Context, a: JSONArray) {
        prefs(c).edit().putString("uprofiles", a.toString()).apply()
    }

    /** Names in saved order, with the automatic slot last. */
    fun names(c: Context): List<String> {
        val a = read(c)
        val out = ArrayList<String>()
        for (i in 0 until a.length()) a.optJSONObject(i)?.optString("name")?.takeIf { it.isNotEmpty() && it != AUTO }?.let { out.add(it) }
        if (has(c, AUTO)) out.add(AUTO)
        return out
    }

    fun has(c: Context, name: String): Boolean {
        val a = read(c)
        for (i in 0 until a.length()) if (a.optJSONObject(i)?.optString("name").equals(name, true)) return true
        return false
    }

    fun clean(name: String): String = name.trim().replace(Regex("\\s+"), " ").take(MAX_NAME)

    private fun snapshot(name: String): JSONObject = JSONObject().apply {
        put("name", name)
        put("mode", Cfg.mode)
        put("sharp", Cfg.sharp.toDouble())
        put("scale", Cfg.scalePct)
        put("preset", Cfg.renderPreset)
        put("boost", Cfg.boost)
        put("vivid", Cfg.vivid.toDouble())
        put("detail", Cfg.detail.toDouble())
        put("detailsz", Cfg.detailSize.toDouble())
        put("denoise", Cfg.denoise.toDouble())
        put("deband", Cfg.deband.toDouble())
        put("aa", Cfg.aaMode)
        put("aastr", Cfg.aaStrength.toDouble())
        put("plevel", Cfg.profileLevel)
        put("pbudget", Cfg.profileBudget)
    }

    /** Saves the current picture settings under [name]; an existing profile with that name is replaced. */
    fun save(c: Context, name: String) {
        val n = if (name == AUTO) AUTO else clean(name)
        if (n.isEmpty()) return
        val old = read(c)
        val out = JSONArray()
        var replaced = false
        for (i in 0 until old.length()) {
            val o = old.optJSONObject(i) ?: continue
            if (o.optString("name").equals(n, true)) {
                out.put(snapshot(n))
                replaced = true
            } else out.put(o)
        }
        if (!replaced) out.put(snapshot(n))
        write(c, out)
    }

    fun saveAuto(c: Context) = save(c, AUTO)

    fun delete(c: Context, name: String) {
        val old = read(c)
        val out = JSONArray()
        for (i in 0 until old.length()) {
            val o = old.optJSONObject(i) ?: continue
            if (!o.optString("name").equals(name, true)) out.put(o)
        }
        write(c, out)
    }

    /** Copies a saved profile into [Cfg] (and saves it). The caller refreshes the UI and re-applies the capture size. */
    fun apply(c: Context, name: String): Boolean {
        val a = read(c)
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            if (!o.optString("name").equals(name, true)) continue
            Cfg.mode = o.optInt("mode", Cfg.mode).coerceIn(0, 4)
            Cfg.sharp = o.optDouble("sharp", Cfg.sharp.toDouble()).toFloat().coerceIn(0f, 1f)
            Cfg.scalePct = o.optInt("scale", Cfg.scalePct).coerceIn(Cfg.SCALE_MIN, Cfg.SCALE_MAX)
            Cfg.renderPreset = o.optInt("preset", Cfg.renderPreset)
            Cfg.boost = o.optBoolean("boost", Cfg.boost)
            Cfg.vivid = o.optDouble("vivid", Cfg.vivid.toDouble()).toFloat().coerceIn(0f, 1f)
            Cfg.detail = o.optDouble("detail", Cfg.detail.toDouble()).toFloat().coerceIn(0f, 1f)
            Cfg.detailSize = o.optDouble("detailsz", Cfg.detailSize.toDouble()).toFloat().coerceIn(0f, 1f)
            Cfg.denoise = o.optDouble("denoise", Cfg.denoise.toDouble()).toFloat().coerceIn(0f, 1f)
            Cfg.deband = o.optDouble("deband", Cfg.deband.toDouble()).toFloat().coerceIn(0f, 1f)
            Cfg.aaMode = o.optInt("aa", Cfg.aaMode).coerceIn(0, 3)
            Cfg.aaStrength = o.optDouble("aastr", Cfg.aaStrength.toDouble()).toFloat().coerceIn(0f, 1f)
            Cfg.profileLevel = o.optInt("plevel", Cfg.profileLevel).coerceIn(0, 3)
            Cfg.profileBudget = o.optInt("pbudget", Cfg.profileBudget).coerceIn(0, 2)
            Cfg.profileType = -1 // the exact saved values are in force: no quick profile is "active"
            Cfg.userProfile = o.optString("name")
            Cfg.save(c)
            return true
        }
        return false
    }
}
