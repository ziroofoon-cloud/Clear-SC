package app.clearoverlay;

/** One entry of a folder in the file manager (any kind of storage). */
public final class FmItem {
    public final String name;
    public final boolean dir;
    public final long size;      // bytes, -1 when unknown (folders usually)
    public final long modified;  // ms since 1970, 0 when unknown

    public FmItem(String name, boolean dir, long size, long modified) {
        this.name = name;
        this.dir = dir;
        this.size = size;
        this.modified = modified;
    }
}
