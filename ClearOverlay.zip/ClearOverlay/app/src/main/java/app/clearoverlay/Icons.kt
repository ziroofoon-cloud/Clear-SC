package app.clearoverlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.widget.ImageView
import android.widget.TextView

/**
 * Thin rounded line icons drawn in code (24 x 24 grid), so the whole app shares one clean look
 * and no emoji (which look different on every phone) is needed for buttons.
 */
object Icons {
    const val FOLDER = 0
    const val REFRESH = 1
    const val FOLDER_PLUS = 2
    const val TAG_PLUS = 3
    const val EYE = 4
    const val EYE_OFF = 5
    const val OPEN = 6
    const val STAR = 7
    const val TAG = 8
    const val BOOK = 9
    const val GEAR = 10
    const val CLOUD = 11
    const val CLOSE = 12
    const val SAVE = 13
    const val LOCK = 14
    const val HISTORY = 15
    const val SEARCH = 16
    const val PLAY = 17
    const val PAUSE = 18
    const val NEXT = 19
    const val PREV = 20
    const val SHUFFLE = 21
    const val REPEAT = 22
    const val REPEAT_ONE = 23
    const val MUSIC = 24
    const val TRASH = 25
    const val CHEV_LEFT = 26
    const val MORE = 27
    const val EDIT = 28
    const val CAMERA = 29
    const val FILM = 30
    const val IMAGE = 31
    const val FILE = 32
    const val SERVER = 33
    const val GLOBE = 34
    const val CHECK = 35
    const val STAR_FILL = 36

    /** Maps the emoji the library cells used to carry to the new icons (-1 = none). */
    fun fromEmoji(s: String): Int = when (s) {
        "📁" -> FOLDER
        "⭐" -> STAR
        "🏷" -> TAG
        "📚" -> BOOK
        "🕘" -> HISTORY
        "🌐" -> GLOBE
        "🖥" -> SERVER
        "🎬" -> FILM
        "🖼" -> IMAGE
        "📄" -> FILE
        "📷" -> CAMERA
        else -> -1
    }

    /** Turns a TextView into an icon-only button face: no text, the line icon centred (use instead of an emoji / glyph). */
    fun glyph(tv: TextView, kind: Int, color: Int = Ui.TEXT, sizeDp: Int = 20) {
        tv.text = ""
        val d = LineIcon(kind, color)
        val s = dp(tv.context, sizeDp)
        d.setBounds(0, 0, s, s)
        tv.setCompoundDrawables(null, d, null, null)
        tv.compoundDrawablePadding = 0
    }

    /**
     * Like [glyph], for a button of a fixed height ([boxDp]): the icon sits exactly in the middle and the empty text line
     * adds no height (a plain [glyph] button is as tall as the icon plus one text line, so icon buttons got taller than the text buttons).
     */
    fun glyphCentered(tv: TextView, kind: Int, color: Int = Ui.TEXT, sizeDp: Int = 20, boxDp: Int = 38) {
        glyph(tv, kind, color, sizeDp)
        tv.textSize = 1f
        tv.includeFontPadding = false
        tv.setPadding(tv.paddingLeft, ((dp(tv.context, boxDp) - dp(tv.context, sizeDp)) / 2).coerceAtLeast(0), tv.paddingRight, 0)
    }

    /** Puts a small line icon in front of the text of a TextView (instead of an emoji in the text). */
    fun leading(tv: TextView, kind: Int, color: Int = Ui.ACCENT, sizeDp: Int = 16, gapDp: Int = 6) {
        val d = LineIcon(kind, color)
        val s = dp(tv.context, sizeDp)
        d.setBounds(0, 0, s, s)
        tv.setCompoundDrawables(d, null, null, null)
        tv.compoundDrawablePadding = dp(tv.context, gapDp)
    }

    /** Removes an icon put by [glyph] or [leading]. */
    fun clear(tv: TextView) {
        tv.setCompoundDrawables(null, null, null, null)
    }

    /** A square tappable icon button (no text), [sizeDp] wide. */
    fun button(ctx: Context, kind: Int, color: Int = Ui.ACCENT, sizeDp: Int = 40, onClick: () -> Unit): ImageView =
        ImageView(ctx).apply {
            setImageDrawable(LineIcon(kind, color))
            val p = dp(ctx, 9)
            setPadding(p, p, p, p)
            layoutParams = android.widget.LinearLayout.LayoutParams(dp(ctx, sizeDp), dp(ctx, sizeDp))
            setOnClickListener { onClick() }
        }
}

class LineIcon(private val kind: Int, color: Int) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        this.color = color
        strokeWidth = 1.8f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    // solid shapes (play, pause, dots) use the same colour as the lines
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        this.color = color
    }

    private fun arrow(c: Canvas, x1: Float, y1: Float, x: Float, y: Float, x2: Float, y2: Float) {
        c.drawPath(Path().apply { moveTo(x1, y1); lineTo(x, y); lineTo(x2, y2) }, paint)
    }

    private fun folder(): Path = Path().apply {
        moveTo(3f, 18f); lineTo(3f, 6f); quadTo(3f, 5f, 4f, 5f); lineTo(9f, 5f); lineTo(11f, 7.5f)
        lineTo(20f, 7.5f); quadTo(21f, 7.5f, 21f, 8.5f); lineTo(21f, 18f); quadTo(21f, 19f, 20f, 19f)
        lineTo(4f, 19f); quadTo(3f, 19f, 3f, 18f); close()
    }

    private fun eye(): Path = Path().apply {
        moveTo(2f, 12f); quadTo(12f, 3f, 22f, 12f); quadTo(12f, 21f, 2f, 12f); close()
    }

    override fun draw(c: Canvas) {
        val b = bounds
        if (b.width() <= 0) return
        c.save()
        c.translate(b.left.toFloat(), b.top.toFloat())
        c.scale(b.width() / 24f, b.height() / 24f)
        when (kind) {
            Icons.FOLDER -> c.drawPath(folder(), paint)
            Icons.FOLDER_PLUS -> {
                c.drawPath(folder(), paint)
                c.drawLine(12f, 10.8f, 12f, 16f, paint)
                c.drawLine(9.4f, 13.4f, 14.6f, 13.4f, paint)
            }
            Icons.REFRESH -> {
                c.drawArc(RectF(4.5f, 4.5f, 19.5f, 19.5f), 40f, 280f, false, paint)
                val p = Path().apply { moveTo(18.2f, 3.4f); lineTo(17.75f, 7.2f); lineTo(14.2f, 6.4f) }
                c.drawPath(p, paint)
            }
            Icons.TAG, Icons.TAG_PLUS -> {
                val big = kind == Icons.TAG
                c.save()
                if (big) c.scale(1.12f, 1.12f, 12f, 12f) else c.translate(0f, 0f)
                val o = if (big) 3f else 0f
                val p = Path().apply {
                    moveTo(3f + o, 3f + o); lineTo(10f + o, 3f + o); lineTo(17f + o, 10f + o)
                    lineTo(10f + o, 17f + o); lineTo(3f + o, 10f + o); close()
                }
                c.drawPath(p, paint)
                c.drawCircle(6.6f + o, 6.6f + o, 1f, paint)
                c.restore()
                if (!big) {
                    c.drawLine(18.5f, 15.5f, 18.5f, 21.5f, paint)
                    c.drawLine(15.5f, 18.5f, 21.5f, 18.5f, paint)
                }
            }
            Icons.EYE, Icons.EYE_OFF -> {
                c.drawPath(eye(), paint)
                c.drawCircle(12f, 12f, 3f, paint)
                if (kind == Icons.EYE_OFF) c.drawLine(4f, 4f, 20f, 20f, paint)
            }
            Icons.OPEN -> {
                c.drawPath(folder(), paint)
                val p = Path().apply { moveTo(10f, 10.6f); lineTo(10f, 16.2f); lineTo(14.6f, 13.4f); close() }
                c.drawPath(p, paint)
            }
            Icons.STAR -> {
                val p = Path()
                for (i in 0 until 10) {
                    val r = if (i % 2 == 0) 9f else 4.2f
                    val a = Math.toRadians(-90.0 + i * 36.0)
                    val x = (12 + r * Math.cos(a)).toFloat()
                    val y = (12.8 + r * Math.sin(a)).toFloat()
                    if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                p.close()
                c.drawPath(p, paint)
            }
            Icons.GEAR -> {
                c.drawCircle(12f, 12f, 3.2f, paint)
                c.drawCircle(12f, 12f, 7f, paint)
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0)
                    val x1 = (12 + 7 * Math.cos(a)).toFloat()
                    val y1 = (12 + 7 * Math.sin(a)).toFloat()
                    val x2 = (12 + 9.6 * Math.cos(a)).toFloat()
                    val y2 = (12 + 9.6 * Math.sin(a)).toFloat()
                    c.drawLine(x1, y1, x2, y2, paint)
                }
            }
            Icons.CLOUD -> {
                val p = Path().apply {
                    moveTo(7f, 18f); quadTo(2.5f, 18f, 2.5f, 13.6f); quadTo(2.5f, 10.4f, 6f, 9.8f)
                    quadTo(7f, 5.5f, 11.5f, 5.5f); quadTo(15.8f, 5.5f, 16.8f, 9.4f)
                    quadTo(21.5f, 9.6f, 21.5f, 13.8f); quadTo(21.5f, 18f, 17f, 18f); close()
                }
                c.drawPath(p, paint)
            }
            Icons.CLOSE -> {
                c.drawLine(6f, 6f, 18f, 18f, paint)
                c.drawLine(18f, 6f, 6f, 18f, paint)
            }
            Icons.SAVE -> {
                c.drawLine(12f, 4f, 12f, 15f, paint)
                val p = Path().apply { moveTo(7.5f, 10.8f); lineTo(12f, 15.2f); lineTo(16.5f, 10.8f) }
                c.drawPath(p, paint)
                val t = Path().apply { moveTo(4.5f, 15f); lineTo(4.5f, 19.5f); lineTo(19.5f, 19.5f); lineTo(19.5f, 15f) }
                c.drawPath(t, paint)
            }
            Icons.LOCK -> {
                c.drawRoundRect(RectF(5f, 10.5f, 19f, 20f), 2.5f, 2.5f, paint)
                c.drawArc(RectF(8f, 4f, 16f, 15f), 180f, 180f, false, paint)
                c.drawCircle(12f, 15f, 1.1f, paint)
            }
            Icons.HISTORY -> {
                c.drawCircle(12f, 12f, 8.5f, paint)
                c.drawLine(12f, 7.2f, 12f, 12f, paint)
                c.drawLine(12f, 12f, 15.4f, 14f, paint)
            }
            Icons.BOOK -> {
                val p = Path().apply {
                    moveTo(12f, 6.5f); quadTo(8f, 4f, 3.5f, 5f); lineTo(3.5f, 18f); quadTo(8f, 17f, 12f, 19.5f)
                    quadTo(16f, 17f, 20.5f, 18f); lineTo(20.5f, 5f); quadTo(16f, 4f, 12f, 6.5f)
                    moveTo(12f, 6.5f); lineTo(12f, 19.5f)
                }
                c.drawPath(p, paint)
            }
            Icons.SEARCH -> {
                c.drawCircle(10.5f, 10.5f, 5.8f, paint)
                c.drawLine(14.8f, 14.8f, 19.8f, 19.8f, paint)
            }
            Icons.PLAY -> c.drawPath(Path().apply { moveTo(8f, 5.5f); lineTo(8f, 18.5f); lineTo(19f, 12f); close() }, fill)
            Icons.PAUSE -> {
                c.drawRoundRect(RectF(6.5f, 5f, 10.5f, 19f), 1.2f, 1.2f, fill)
                c.drawRoundRect(RectF(13.5f, 5f, 17.5f, 19f), 1.2f, 1.2f, fill)
            }
            Icons.NEXT -> {
                c.drawPath(Path().apply { moveTo(6f, 6f); lineTo(6f, 18f); lineTo(15f, 12f); close() }, fill)
                c.drawLine(18f, 6f, 18f, 18f, paint)
            }
            Icons.PREV -> {
                c.drawPath(Path().apply { moveTo(18f, 6f); lineTo(18f, 18f); lineTo(9f, 12f); close() }, fill)
                c.drawLine(6f, 6f, 6f, 18f, paint)
            }
            Icons.SHUFFLE -> {
                c.drawPath(Path().apply { moveTo(3f, 7f); lineTo(7f, 7f); quadTo(11f, 7f, 13f, 12f); quadTo(15f, 17f, 19f, 17f); lineTo(20.5f, 17f) }, paint)
                arrow(c, 18f, 14.5f, 20.8f, 17f, 18f, 19.5f)
                c.drawPath(Path().apply { moveTo(3f, 17f); lineTo(7f, 17f); quadTo(9f, 17f, 10.3f, 15.2f); moveTo(13.7f, 8.8f); quadTo(15f, 7f, 19f, 7f); lineTo(20.5f, 7f) }, paint)
                arrow(c, 18f, 4.5f, 20.8f, 7f, 18f, 9.5f)
            }
            Icons.REPEAT, Icons.REPEAT_ONE -> {
                c.drawPath(Path().apply { moveTo(4f, 11f); lineTo(4f, 9.5f); quadTo(4f, 7f, 6.5f, 7f); lineTo(19f, 7f) }, paint)
                arrow(c, 16.2f, 4.4f, 19.2f, 7f, 16.2f, 9.6f)
                c.drawPath(Path().apply { moveTo(20f, 13f); lineTo(20f, 14.5f); quadTo(20f, 17f, 17.5f, 17f); lineTo(5f, 17f) }, paint)
                arrow(c, 7.8f, 14.4f, 4.8f, 17f, 7.8f, 19.6f)
                if (kind == Icons.REPEAT_ONE) c.drawPath(Path().apply { moveTo(10.6f, 10.8f); lineTo(12.4f, 9.6f); lineTo(12.4f, 14.6f) }, paint)
            }
            Icons.MUSIC -> {
                c.drawCircle(7.5f, 17.5f, 2.6f, paint)
                c.drawCircle(16.5f, 15.5f, 2.6f, paint)
                c.drawPath(Path().apply { moveTo(10.1f, 17.5f); lineTo(10.1f, 6f); lineTo(19.1f, 4f); lineTo(19.1f, 15.5f) }, paint)
            }
            Icons.TRASH -> {
                c.drawLine(4.5f, 7f, 19.5f, 7f, paint)
                c.drawPath(Path().apply { moveTo(9.5f, 7f); lineTo(9.5f, 4.5f); lineTo(14.5f, 4.5f); lineTo(14.5f, 7f) }, paint)
                c.drawPath(Path().apply { moveTo(6.5f, 7f); lineTo(7.5f, 19.5f); lineTo(16.5f, 19.5f); lineTo(17.5f, 7f) }, paint)
                c.drawLine(10.6f, 10.5f, 10.6f, 16f, paint)
                c.drawLine(13.4f, 10.5f, 13.4f, 16f, paint)
            }
            Icons.CHEV_LEFT -> c.drawPath(Path().apply { moveTo(14.5f, 5.5f); lineTo(8f, 12f); lineTo(14.5f, 18.5f) }, paint)
            Icons.MORE -> {
                c.drawCircle(12f, 5.5f, 1.7f, fill)
                c.drawCircle(12f, 12f, 1.7f, fill)
                c.drawCircle(12f, 18.5f, 1.7f, fill)
            }
            Icons.EDIT -> {
                c.drawPath(Path().apply { moveTo(4f, 20f); lineTo(4.8f, 15.8f); lineTo(16.5f, 4.1f); lineTo(19.9f, 7.5f); lineTo(8.2f, 19.2f); close() }, paint)
                c.drawLine(14.4f, 6.2f, 17.8f, 9.6f, paint)
            }
            Icons.CHECK -> c.drawPath(Path().apply { moveTo(5f, 12.5f); lineTo(10f, 17.5f); lineTo(19f, 7f) }, paint.apply { strokeWidth = 2.6f })
            Icons.STAR_FILL -> {
                val p = Path()
                for (i in 0 until 10) {
                    val r = if (i % 2 == 0) 9.5f else 4.4f
                    val a = Math.toRadians(-90.0 + i * 36.0)
                    val x = (12 + r * Math.cos(a)).toFloat()
                    val y = (12.8 + r * Math.sin(a)).toFloat()
                    if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                p.close()
                c.drawPath(p, fill)
                c.drawPath(p, paint)
            }
            Icons.CAMERA -> {
                c.drawPath(Path().apply { moveTo(3.5f, 9.5f); quadTo(3.5f, 7.5f, 5.5f, 7.5f); lineTo(8.5f, 7.5f); lineTo(10f, 5f); lineTo(14f, 5f); lineTo(15.5f, 7.5f); lineTo(18.5f, 7.5f); quadTo(20.5f, 7.5f, 20.5f, 9.5f); lineTo(20.5f, 17.5f); quadTo(20.5f, 19.5f, 18.5f, 19.5f); lineTo(5.5f, 19.5f); quadTo(3.5f, 19.5f, 3.5f, 17.5f); close() }, paint)
                c.drawCircle(12f, 13.5f, 3.4f, paint)
            }
            Icons.FILM -> {
                c.drawRoundRect(RectF(4f, 4.5f, 20f, 19.5f), 2f, 2f, paint)
                c.drawLine(8f, 4.5f, 8f, 19.5f, paint)
                c.drawLine(16f, 4.5f, 16f, 19.5f, paint)
                for (y in floatArrayOf(9f, 12f, 15f)) {
                    c.drawLine(4f, y, 8f, y, paint)
                    c.drawLine(16f, y, 20f, y, paint)
                }
            }
            Icons.IMAGE -> {
                c.drawRoundRect(RectF(4f, 5f, 20f, 19f), 2f, 2f, paint)
                c.drawCircle(9f, 10f, 1.6f, paint)
                c.drawPath(Path().apply { moveTo(4f, 17f); lineTo(9.5f, 12f); lineTo(13f, 15f); lineTo(16f, 12f); lineTo(20f, 16f) }, paint)
            }
            Icons.FILE -> {
                c.drawPath(Path().apply { moveTo(6f, 3.5f); lineTo(14f, 3.5f); lineTo(18.5f, 8f); lineTo(18.5f, 20.5f); lineTo(6f, 20.5f); close() }, paint)
                c.drawPath(Path().apply { moveTo(14f, 3.5f); lineTo(14f, 8f); lineTo(18.5f, 8f) }, paint)
                c.drawLine(9f, 13f, 15.5f, 13f, paint)
                c.drawLine(9f, 16.5f, 15.5f, 16.5f, paint)
            }
            Icons.SERVER -> {
                c.drawRoundRect(RectF(4f, 4.5f, 20f, 10.5f), 2f, 2f, paint)
                c.drawRoundRect(RectF(4f, 13.5f, 20f, 19.5f), 2f, 2f, paint)
                c.drawCircle(7.8f, 7.5f, 1f, fill)
                c.drawCircle(7.8f, 16.5f, 1f, fill)
            }
            Icons.GLOBE -> {
                c.drawCircle(12f, 12f, 8.5f, paint)
                c.drawOval(RectF(8f, 3.5f, 16f, 20.5f), paint)
                c.drawLine(3.5f, 12f, 20.5f, 12f, paint)
            }
        }
        c.restore()
    }

    override fun setAlpha(alpha: Int) {
        paint.alpha = alpha
        fill.alpha = alpha
    }

    override fun setColorFilter(cf: ColorFilter?) {
        paint.colorFilter = cf
        fill.colorFilter = cf
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
