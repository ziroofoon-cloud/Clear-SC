package app.clearoverlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.widget.ImageView

/**
 * Thin rounded line icons drawn in code (24 x 24 grid), so the whole app shares one clean look
 * and no emoji (which look different on every phone) is needed for buttons.
 */
object Icons {
    const val FOLDER = 0
    const val REFRESH = 1
    const val FOLDER_PLUS = 2
    const val TAG_PLUS = 3
    const val EYE = 4
    const val EYE_OFF = 5
    const val OPEN = 6
    const val STAR = 7
    const val TAG = 8
    const val BOOK = 9

    /** Maps the emoji the library cells used to carry to the new icons (-1 = none). */
    fun fromEmoji(s: String): Int = when (s) {
        "📁" -> FOLDER
        "⭐" -> STAR
        "🏷" -> TAG
        "📚" -> BOOK
        else -> -1
    }

    /** A square tappable icon button (no text), [sizeDp] wide. */
    fun button(ctx: Context, kind: Int, color: Int = Ui.ACCENT, sizeDp: Int = 40, onClick: () -> Unit): ImageView =
        ImageView(ctx).apply {
            setImageDrawable(LineIcon(kind, color))
            val p = dp(ctx, 9)
            setPadding(p, p, p, p)
            layoutParams = android.widget.LinearLayout.LayoutParams(dp(ctx, sizeDp), dp(ctx, sizeDp))
            setOnClickListener { onClick() }
        }
}

class LineIcon(private val kind: Int, color: Int) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        this.color = color
        strokeWidth = 1.8f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private fun folder(): Path = Path().apply {
        moveTo(3f, 18f); lineTo(3f, 6f); quadTo(3f, 5f, 4f, 5f); lineTo(9f, 5f); lineTo(11f, 7.5f)
        lineTo(20f, 7.5f); quadTo(21f, 7.5f, 21f, 8.5f); lineTo(21f, 18f); quadTo(21f, 19f, 20f, 19f)
        lineTo(4f, 19f); quadTo(3f, 19f, 3f, 18f); close()
    }

    private fun eye(): Path = Path().apply {
        moveTo(2f, 12f); quadTo(12f, 3f, 22f, 12f); quadTo(12f, 21f, 2f, 12f); close()
    }

    override fun draw(c: Canvas) {
        val b = bounds
        if (b.width() <= 0) return
        c.save()
        c.translate(b.left.toFloat(), b.top.toFloat())
        c.scale(b.width() / 24f, b.height() / 24f)
        when (kind) {
            Icons.FOLDER -> c.drawPath(folder(), paint)
            Icons.FOLDER_PLUS -> {
                c.drawPath(folder(), paint)
                c.drawLine(12f, 10.8f, 12f, 16f, paint)
                c.drawLine(9.4f, 13.4f, 14.6f, 13.4f, paint)
            }
            Icons.REFRESH -> {
                c.drawArc(RectF(4.5f, 4.5f, 19.5f, 19.5f), 40f, 280f, false, paint)
                val p = Path().apply { moveTo(18.2f, 3.4f); lineTo(17.75f, 7.2f); lineTo(14.2f, 6.4f) }
                c.drawPath(p, paint)
            }
            Icons.TAG, Icons.TAG_PLUS -> {
                val big = kind == Icons.TAG
                c.save()
                if (big) c.scale(1.12f, 1.12f, 12f, 12f) else c.translate(0f, 0f)
                val o = if (big) 3f else 0f
                val p = Path().apply {
                    moveTo(3f + o, 3f + o); lineTo(10f + o, 3f + o); lineTo(17f + o, 10f + o)
                    lineTo(10f + o, 17f + o); lineTo(3f + o, 10f + o); close()
                }
                c.drawPath(p, paint)
                c.drawCircle(6.6f + o, 6.6f + o, 1f, paint)
                c.restore()
                if (!big) {
                    c.drawLine(18.5f, 15.5f, 18.5f, 21.5f, paint)
                    c.drawLine(15.5f, 18.5f, 21.5f, 18.5f, paint)
                }
            }
            Icons.EYE, Icons.EYE_OFF -> {
                c.drawPath(eye(), paint)
                c.drawCircle(12f, 12f, 3f, paint)
                if (kind == Icons.EYE_OFF) c.drawLine(4f, 4f, 20f, 20f, paint)
            }
            Icons.OPEN -> {
                c.drawPath(folder(), paint)
                val p = Path().apply { moveTo(10f, 10.6f); lineTo(10f, 16.2f); lineTo(14.6f, 13.4f); close() }
                c.drawPath(p, paint)
            }
            Icons.STAR -> {
                val p = Path()
                for (i in 0 until 10) {
                    val r = if (i % 2 == 0) 9f else 4.2f
                    val a = Math.toRadians(-90.0 + i * 36.0)
                    val x = (12 + r * Math.cos(a)).toFloat()
                    val y = (12.8 + r * Math.sin(a)).toFloat()
                    if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                p.close()
                c.drawPath(p, paint)
            }
            Icons.BOOK -> {
                val p = Path().apply {
                    moveTo(12f, 6.5f); quadTo(8f, 4f, 3.5f, 5f); lineTo(3.5f, 18f); quadTo(8f, 17f, 12f, 19.5f)
                    quadTo(16f, 17f, 20.5f, 18f); lineTo(20.5f, 5f); quadTo(16f, 4f, 12f, 6.5f)
                    moveTo(12f, 6.5f); lineTo(12f, 19.5f)
                }
                c.drawPath(p, paint)
            }
        }
        c.restore()
    }

    override fun setAlpha(alpha: Int) {
        paint.alpha = alpha
    }

    override fun setColorFilter(cf: ColorFilter?) {
        paint.colorFilter = cf
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
