package app.clearoverlay;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Looks for files and folders by name, in a folder and everything below it, on any storage. */
public final class FmSearch {
    private FmSearch() { }

    public interface Cancel {
        boolean cancelled();
    }

    public static final class Hit {
        public final String path;    // full path of the found item
        public final String dir;     // the folder it is in
        public final FmItem item;

        Hit(String path, String dir, FmItem item) {
            this.path = path;
            this.dir = dir;
            this.item = item;
        }
    }

    /** Up to [max] items whose name contains [query] (ignoring case). Folders that cannot be read are skipped. */
    public static List<Hit> find(FmFs fs, String start, String query, int max, Cancel c) {
        List<Hit> out = new ArrayList<>();
        String q = query.toLowerCase(Locale.ROOT);
        walk(fs, start, q, max, c, out);
        return out;
    }

    private static void walk(FmFs fs, String dir, String q, int max, Cancel c, List<Hit> out) {
        if (out.size() >= max || (c != null && c.cancelled())) return;
        List<FmItem> kids;
        try {
            kids = fs.list(dir);
        } catch (Exception e) {
            return;
        }
        List<FmItem> folders = new ArrayList<>();
        for (FmItem it : kids) {
            if (it.name.toLowerCase(Locale.ROOT).contains(q)) {
                out.add(new Hit(fs.join(dir, it.name), dir, it));
                if (out.size() >= max) return;
            }
            if (it.dir && !it.link) folders.add(it); // a linked folder can lead back to a folder above it
        }
        for (FmItem f : folders) {
            if (c != null && c.cancelled()) return;
            walk(fs, fs.join(dir, f.name), q, max, c, out);
        }
    }
}
