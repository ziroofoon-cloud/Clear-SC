package app.clearoverlay

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * One page, fitted to the view: pinch to zoom, drag to pan, double-tap = zoom 2.5x / back to fit.
 * At fit size a horizontal swipe reports [onSwipe] (-1 = to the left, +1 = to the right) and a tap reports its
 * horizontal position (0..1) through [onTap], so a reader can turn pages from the screen edges.
 */
class ZoomView(c: Context) : View(c) {
    var onSwipe: ((Int) -> Unit)? = null
    var onTap: ((Float) -> Unit)? = null

    private var bmp: Bitmap? = null
    private val m = Matrix()
    private var scale = 1f
    private var fitScale = 1f
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private var lastX = 0f
    private var downX = 0f
    private var downY = 0f
    private var swiped = false
    private var multi = false
    private var lastY = 0f

    private val sgd = ScaleGestureDetector(c, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            val target = (scale * d.scaleFactor).coerceIn(fitScale, fitScale * 8f)
            val f = target / scale
            m.postScale(f, f, d.focusX, d.focusY)
            scale = target
            clamp()
            invalidate()
            return true
        }
    })

    private val gd = GestureDetector(c, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true

        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            onTap?.invoke(e.x / width.coerceAtLeast(1))
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (scale > fitScale * 1.05f) {
                fit()
            } else {
                val f = 2.5f
                m.postScale(f, f, e.x, e.y)
                scale *= f
                clamp()
            }
            invalidate()
            return true
        }

        override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
            if (e1 == null || scale > fitScale * 1.05f) return false
            if (abs(vx) > 350f && abs(vx) > abs(vy) * 1.2f && abs(e2.x - e1.x) > width * 0.08f) {
                swiped = true
                onSwipe?.invoke(if (e2.x < e1.x) -1 else 1)
                return true
            }
            return false
        }
    })

    fun setBitmap(b: Bitmap?) {
        bmp = b
        fit()
        invalidate()
    }

    fun fit() {
        val b = bmp ?: return
        if (width == 0 || height == 0) return
        val s = min(width.toFloat() / b.width, height.toFloat() / b.height)
        fitScale = s
        scale = s
        m.reset()
        m.postScale(s, s)
        m.postTranslate((width - b.width * s) / 2f, (height - b.height * s) / 2f)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        fit()
    }

    /** Keeps the picture from being dragged away: it stays centred when smaller than the view, else edge to edge. */
    private fun clamp() {
        val b = bmp ?: return
        val v = FloatArray(9)
        m.getValues(v)
        val w = b.width * v[Matrix.MSCALE_X]
        val h = b.height * v[Matrix.MSCALE_Y]
        var tx = v[Matrix.MTRANS_X]
        var ty = v[Matrix.MTRANS_Y]
        tx = if (w <= width) (width - w) / 2f else tx.coerceIn(width - w, 0f)
        ty = if (h <= height) (height - h) / 2f else ty.coerceIn(height - h, 0f)
        m.postTranslate(tx - v[Matrix.MTRANS_X], ty - v[Matrix.MTRANS_Y])
    }

    override fun onDraw(canvas: Canvas) {
        val b = bmp ?: return
        canvas.drawBitmap(b, m, paint)
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (bmp == null) return true
        sgd.onTouchEvent(ev)
        gd.onTouchEvent(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = ev.x; lastY = ev.y
                downX = ev.x; downY = ev.y; swiped = false; multi = false
            }
            MotionEvent.ACTION_UP -> {
                // a slow drag counts too, not only a fast fling
                val dx = ev.x - downX
                val dy = ev.y - downY
                if (!swiped && !multi && scale <= fitScale * 1.05f && abs(dx) > width * 0.15f && abs(dx) > abs(dy) * 1.2f) {
                    swiped = true
                    onSwipe?.invoke(if (dx < 0) -1 else 1)
                }
            }
            MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_POINTER_UP -> {
                multi = true
                val i = if (ev.actionMasked == MotionEvent.ACTION_POINTER_UP && ev.actionIndex == 0) 1 else 0
                if (i < ev.pointerCount) {
                    lastX = ev.getX(i); lastY = ev.getY(i)
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (ev.pointerCount == 1 && !sgd.isInProgress && scale > fitScale * 1.02f) {
                    m.postTranslate(ev.x - lastX, ev.y - lastY)
                    clamp()
                    invalidate()
                }
                lastX = ev.x; lastY = ev.y
            }
        }
        return true
    }

    /** Largest side of the picture currently shown (for choosing a decode size). */
    fun maxSide(): Int = max(width, height)
}
