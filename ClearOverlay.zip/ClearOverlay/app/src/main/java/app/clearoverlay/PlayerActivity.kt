package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.media.AudioManager
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewConfiguration
import android.view.ScaleGestureDetector
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.webkit.MimeTypeMap
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.text.CueGroup
import androidx.media3.exoplayer.ExoPlayer
import java.io.File
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Built-in video / photo player. The file or stream is decoded directly (no screen capture), then goes
 * through the same GPU pipeline as the overlay (denoise / deband / anti-aliasing -> FSR 1 / SGSR 1 /
 * bilinear upscale -> sharpen -> vivid colors), so a low-resolution source is upscaled from its real pixels.
 *
 *  - Engine: Media3 ExoPlayer (local files, direct links, HLS, DASH, mkv/mp4/webm ...), output surface =
 *    [GlPipeline] input, shown in a TextureView.
 *  - Subtitles: embedded tracks or an external .srt / .vtt / .ass file (re-encoded to UTF-8 when needed),
 *    drawn by a TextView on top of the processed picture.
 *  - Gestures: tap, double tap, horizontal drag (seek), vertical drag (left = brightness, right = volume),
 *    long press (2x speed while held).
 *  - Photos: decoded with BitmapFactory (EXIF-rotated, long side capped) and drawn once into the pipeline.
 */
class PlayerActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())

    private lateinit var root: FrameLayout
    private lateinit var stage: FrameLayout
    private lateinit var titleView: TextView
    private lateinit var topBar: LinearLayout
    private lateinit var fxBtn: TextView
    private lateinit var bar: LinearLayout
    private lateinit var seekRow: LinearLayout
    private lateinit var playBtn: TextView
    private lateinit var seek: SeekBar
    private lateinit var curText: TextView
    private lateinit var durText: TextView
    private lateinit var speedBtn: TextView
    private lateinit var subtitleView: TextView
    private lateinit var hud: TextView
    private lateinit var spinner: ProgressBar
    private lateinit var panel: FadePanel
    private val videoOnly = ArrayList<View>()

    private var tv: TextureView? = null
    private var gl: GlPipeline? = null
    private var outSurface: Surface? = null
    private var player: ExoPlayer? = null

    private var currentUri: Uri? = null
    private val subs = ArrayList<MediaItem.SubtitleConfiguration>()
    private var pendingSubLabel: String? = null

    private var isImage = false
    private var bitmap: Bitmap? = null
    private var vw = 0
    private var vh = 0
    private var vpar = 1f
    private var hasMedia = false
    private var panelBuilt = false
    private var dragging = false
    private var controlsOn = true
    private var fxSwitch: Switch? = null
    private var tapSwitch: Switch? = null
    private var rotMode = ROT_AUTO
    private lateinit var zoomBtn: TextView
    private var zoom = 1f
    private var zoomCx = 0.5f
    private var zoomCy = 0.5f
    private var pinching = false
    // safe-area insets (camera cutout, status / navigation bars): controls are kept clear of them
    private var insL = 0
    private var insT = 0
    private var insR = 0
    private var insB = 0

    // player settings (saved)
    private var tapPlays = true
    private var aspectFill = false
    private var subSize = 18
    private var speed = 1f

    // gesture state
    private var gestureMode = 0 // 0 none, 1 seek, 2 brightness, 3 volume
    private var seekStartPos = 0L
    private var seekTarget = 0L
    private var brightStart = 0.5f
    private var volStart = 0
    private var holding = false
    private var holdPrevSpeed = 1f

    private val prefs by lazy { getSharedPreferences("crsc_player", Context.MODE_PRIVATE) }
    private val audio by lazy { getSystemService(AudioManager::class.java) }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    private val ticker = object : Runnable {
        override fun run() {
            tick()
            ui.postDelayed(this, 200)
        }
    }

    private val hideRunnable = Runnable {
        if (panel.visibility != View.VISIBLE && isPlaying() && vw > 0) setControlsVisible(false)
    }

    /** Settings panel: back to full opacity shortly after a slider is released. */
    private val panelRestore = Runnable {
        panel.animate().alpha(1f).setDuration(200).start()
        schedulePanelIdle()
    }

    /** Settings panel: fades out and closes itself after a few idle seconds (when fading is enabled). */
    private val panelIdleHide = Runnable {
        if (panel.visibility == View.VISIBLE && Cfg.panelFade) {
            panel.animate().alpha(0f).setDuration(250).withEndAction { hidePanel() }.start()
        }
    }

    /** The decoder may not report a size until it has a surface, so if nothing created the picture view yet, make it anyway. */
    private val sizeFallback = Runnable { ensureViewFallback() }

    private val hudHide = Runnable { hud.visibility = View.GONE }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            setPlayIcon(isPlaying)
            if (isPlaying) scheduleHide() else ui.removeCallbacks(hideRunnable)
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            spinner.visibility = if (playbackState == Player.STATE_BUFFERING) View.VISIBLE else View.GONE
            if (playbackState == Player.STATE_READY) ensureViewFallback()
            if (playbackState == Player.STATE_ENDED) {
                setPlayIcon(false)
                setControlsVisible(true)
            }
        }

        override fun onVideoSizeChanged(videoSize: VideoSize) {
            val par = if (videoSize.pixelWidthHeightRatio > 0f) videoSize.pixelWidthHeightRatio else 1f
            applyMediaSize(videoSize.width, videoSize.height, par)
        }

        override fun onCues(cueGroup: CueGroup) {
            val sb = StringBuilder()
            for (c in cueGroup.cues) {
                val t = c.text ?: continue
                if (sb.isNotEmpty()) sb.append('\n')
                sb.append(t.toString())
            }
            subtitleView.text = sb.toString()
            subtitleView.visibility = if (sb.isEmpty()) View.GONE else View.VISIBLE
        }

        override fun onTracksChanged(tracks: Tracks) {
            if (!isImage && tv == null) sizeFromTracks(tracks)
            val label = pendingSubLabel ?: return
            val p = player ?: return
            for (g in tracks.groups) {
                if (g.type != C.TRACK_TYPE_TEXT) continue
                for (i in 0 until g.length) {
                    if (g.getTrackFormat(i).label == label) {
                        pendingSubLabel = null
                        selectTextTrack(p, g, i)
                        return
                    }
                }
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            Toast.makeText(
                this@PlayerActivity,
                getString(R.string.player_error) + "\n" + (error.message ?: error.errorCodeName),
                Toast.LENGTH_LONG
            ).show()
            spinner.visibility = View.GONE
            setControlsVisible(true)
        }
    }

    private val scaleDetector by lazy {
        ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                setZoom(zoom * d.scaleFactor, true)
                return true
            }
        })
    }

    private val gesture by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                onSingleTap()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (isImage) return true
                val w = root.width.toFloat()
                when {
                    e.x < w / 3f -> seekBy(-10_000L)
                    e.x > w * 2f / 3f -> seekBy(10_000L)
                    else -> togglePlay()
                }
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                val p = player ?: return
                if (isImage || !p.isPlaying) return
                holding = true
                holdPrevSpeed = speed
                p.setPlaybackSpeed(2f)
                showHud("2×", sticky = true)
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
                if (zoom > 1.01f) {
                    // zoomed in: one finger pans instead of seeking / brightness / volume
                    val v = tv
                    val vwPx = (v?.width ?: root.width).toFloat().coerceAtLeast(1f)
                    val vhPx = (v?.height ?: root.height).toFloat().coerceAtLeast(1f)
                    zoomCx += distanceX / (vwPx * zoom)
                    zoomCy -= distanceY / (vhPx * zoom)
                    applyZoom()
                    return true
                }
                if (e1 == null || isImage) return false
                val p = player ?: return false
                val w = root.width.toFloat().coerceAtLeast(1f)
                val h = root.height.toFloat().coerceAtLeast(1f)
                val totalX = e2.x - e1.x
                val totalY = e2.y - e1.y
                if (gestureMode == 0) {
                    val slop = ViewConfiguration.get(this@PlayerActivity).scaledTouchSlop
                    if (abs(totalX) < slop && abs(totalY) < slop) return true
                    gestureMode = when {
                        abs(totalX) > abs(totalY) -> 1
                        e1.x < w / 2f -> 2
                        else -> 3
                    }
                    when (gestureMode) {
                        1 -> {
                            seekStartPos = p.currentPosition
                            seekTarget = seekStartPos
                        }
                        2 -> brightStart = currentBrightness()
                        3 -> volStart = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
                    }
                }
                when (gestureMode) {
                    1 -> {
                        val dur = p.duration
                        val upper = if (dur > 0) dur else Long.MAX_VALUE
                        seekTarget = (seekStartPos + (totalX / w * 120_000f).toLong()).coerceIn(0L, upper)
                        val diff = (seekTarget - seekStartPos) / 1000L
                        showHud(fmt(seekTarget) + "  (" + String.format(Locale.US, "%+d", diff) + " s)")
                    }
                    2 -> {
                        val v = (brightStart - totalY / (h * 0.8f)).coerceIn(0.02f, 1f)
                        setBrightness(v)
                        showHud(getString(R.string.player_brightness_fmt, (v * 100).roundToInt()))
                    }
                    3 -> {
                        val maxV = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        val v = (volStart + (-totalY / (h * 0.8f)) * maxV).roundToInt().coerceIn(0, maxV)
                        audio.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0)
                        showHud(getString(R.string.player_volume_fmt, if (maxV > 0) v * 100 / maxV else 0))
                    }
                }
                return true
            }
        })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Cfg.load(this)
        tapPlays = prefs.getBoolean("tapPlays", true)
        aspectFill = prefs.getBoolean("aspectFill", false)
        subSize = prefs.getInt("subSize", 18).coerceIn(12, 36)
        rotMode = prefs.getInt("rot", ROT_AUTO).coerceIn(0, 3)
        if (rotMode != ROT_AUTO) applyRotation()
        volumeControlStream = AudioManager.STREAM_MUSIC

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.setDecorFitsSystemWindows(false)
        window.attributes = window.attributes.also {
            it.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        stage = FrameLayout(this)
        root.addView(stage, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.setOnTouchListener { _, ev ->
            scaleDetector.onTouchEvent(ev)
            if ((ev.pointerCount > 1 || scaleDetector.isInProgress) && !pinching) {
                // second finger: switch from the one-finger gestures to pinch zoom
                pinching = true
                val c = MotionEvent.obtain(ev)
                c.action = MotionEvent.ACTION_CANCEL
                gesture.onTouchEvent(c)
                c.recycle()
                gestureMode = 0
                endGesture()
            }
            if (!pinching) gesture.onTouchEvent(ev)
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                endGesture()
                pinching = false
            }
            true
        }

        // ---- subtitles
        subtitleView = TextView(this).apply {
            visibility = View.GONE
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            setTextColor(Color.WHITE)
            setShadowLayer(6f, 0f, 0f, Color.BLACK)
            setBackgroundColor(Color.parseColor("#66000000"))
            setPadding(dp(this@PlayerActivity, 8), dp(this@PlayerActivity, 2), dp(this@PlayerActivity, 8), dp(this@PlayerActivity, 2))
            textSize = subSize.toFloat()
        }
        root.addView(
            subtitleView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
                bottomMargin = dp(this@PlayerActivity, 36)
                leftMargin = dp(this@PlayerActivity, 24)
                rightMargin = dp(this@PlayerActivity, 24)
            }
        )

        // ---- top bar: title + FX on/off + rotation + settings + menu
        titleView = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setShadowLayer(6f, 0f, 0f, Color.BLACK)
        }
        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        topBar.addView(
            titleView,
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(this@PlayerActivity, 8) }
        )
        fxBtn = topButton("FX") { setFx(!Cfg.playerFx) }
        topBar.addView(fxBtn)
        zoomBtn = topButton("1×") { cycleZoom() }
        zoomBtn.textSize = 13f
        topBar.addView(zoomBtn)
        topBar.addView(topButton("⟳") { cycleRotation() })
        topBar.addView(topButton("⚙") { togglePanel() })
        topBar.addView(topButton("⋮") { showMoreMenu() })
        root.addView(
            topBar,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP).apply {
                val m = dp(this@PlayerActivity, 12)
                setMargins(m, dp(this@PlayerActivity, 10), m, 0)
            }
        )
        paintFx()

        // ---- centre HUD + buffering spinner
        hud = TextView(this).apply {
            visibility = View.GONE
            setTextColor(Color.WHITE)
            textSize = 20f
            gravity = Gravity.CENTER
            background = Ui.round(Color.parseColor("#B30B1020"), dp(this@PlayerActivity, 14).toFloat())
            setPadding(dp(this@PlayerActivity, 18), dp(this@PlayerActivity, 10), dp(this@PlayerActivity, 18), dp(this@PlayerActivity, 10))
        }
        root.addView(hud, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        spinner = ProgressBar(this).apply {
            visibility = View.GONE
            indeterminateTintList = ColorStateList.valueOf(Ui.ACCENT)
        }
        root.addView(spinner, FrameLayout.LayoutParams(dp(this, 48), dp(this, 48), Gravity.CENTER))

        // ---- bottom bar: seek row + button row
        bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            isClickable = true
            background = Ui.round(Color.parseColor("#D90B1020"), dp(this@PlayerActivity, 14).toFloat())
            setPadding(dp(this@PlayerActivity, 10), dp(this@PlayerActivity, 6), dp(this@PlayerActivity, 10), dp(this@PlayerActivity, 6))
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        curText = Ui.text(this, "0:00", 12f, Ui.MUTED)
        durText = Ui.text(this, "0:00", 12f, Ui.MUTED)
        seek = SeekBar(this).apply {
            max = 1000
            val tint = ColorStateList.valueOf(Ui.ACCENT)
            progressTintList = tint
            thumbTintList = tint
            progressBackgroundTintList = ColorStateList.valueOf(Ui.STROKE)
            secondaryProgressTintList = ColorStateList.valueOf(Ui.MUTED)
        }
        seekRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        seekRow.addView(curText)
        seekRow.addView(seek, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = dp(this@PlayerActivity, 4)
            marginEnd = dp(this@PlayerActivity, 4)
        })
        seekRow.addView(durText)
        bar.addView(seekRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        videoOnly.add(seekRow)

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val b1 = barButton("−10") { seekBy(-10_000L) }
        playBtn = barButton("▶") { togglePlay() }
        playBtn.textSize = 18f
        val b3 = barButton("+10") { seekBy(10_000L) }
        speedBtn = barButton("1×") { showSpeedMenu() }
        val b5 = barButton("CC") { showTrackMenu(C.TRACK_TYPE_TEXT) }
        val b6 = barButton("♪") { showTrackMenu(C.TRACK_TYPE_AUDIO) }
        for (b in listOf(b1, playBtn, b3, speedBtn, b5, b6)) {
            buttons.addView(b)
            videoOnly.add(b)
        }
        bar.addView(buttons, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(this@PlayerActivity, 4)
        })
        root.addView(
            bar,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply {
                val m = dp(this@PlayerActivity, 12)
                setMargins(m, m, m, m)
            }
        )

        // ---- settings panel (built on first open)
        panel = FadePanel(this).apply {
            visibility = View.GONE
            isClickable = true
            background = Ui.round(Color.parseColor("#F5101522"), dp(this@PlayerActivity, 22).toFloat(), Ui.STROKE, dp(this@PlayerActivity, 1))
            setPadding(dp(this@PlayerActivity, 16), dp(this@PlayerActivity, 14), dp(this@PlayerActivity, 16), dp(this@PlayerActivity, 14))
        }
        panel.onTouch = { schedulePanelIdle() }
        root.addView(panel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    val d = player?.duration ?: 0L
                    if (d > 0) curText.text = fmt(p.toLong() * d / 1000L)
                }
            }

            override fun onStartTrackingTouch(s: SeekBar) {
                dragging = true
                ui.removeCallbacks(hideRunnable)
            }

            override fun onStopTrackingTouch(s: SeekBar) {
                val d = player?.duration ?: 0L
                if (d > 0) player?.seekTo(s.progress.toLong() * d / 1000L)
                dragging = false
                gl?.redraw()
                scheduleHide()
            }
        })

        setContentView(root)
        root.post { applyInsets() }

        val p = ExoPlayer.Builder(this).build()
        p.addListener(playerListener)
        player = p

        val d = intent?.data
        if (d != null) open(d) else showSourceDialog(cancelFinishes = true)
    }

    private fun barButton(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 14f
        gravity = Gravity.CENTER
        setTextColor(Ui.TEXT)
        background = Ui.round(Ui.CHIP, dp(this@PlayerActivity, 10).toFloat())
        setPadding(dp(this@PlayerActivity, 4), dp(this@PlayerActivity, 9), dp(this@PlayerActivity, 4), dp(this@PlayerActivity, 9))
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = dp(this@PlayerActivity, 3)
            marginEnd = dp(this@PlayerActivity, 3)
        }
        setOnClickListener {
            onClick()
            if (this !== playBtn) scheduleHide()
        }
    }

    private fun topButton(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 15f
        gravity = Gravity.CENTER
        setTextColor(Ui.TEXT)
        background = Ui.round(Color.parseColor("#B30B1020"), dp(this@PlayerActivity, 10).toFloat())
        layoutParams = LinearLayout.LayoutParams(dp(this@PlayerActivity, 42), dp(this@PlayerActivity, 38)).apply {
            marginStart = dp(this@PlayerActivity, 6)
        }
        setOnClickListener {
            onClick()
            scheduleHide()
        }
    }

    // ---- choosing what to play ----------------------------------------------------------------

    private fun showSourceDialog(cancelFinishes: Boolean) {
        val items = arrayOf(getString(R.string.player_open_file), getString(R.string.player_open_link))
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.player_button))
            .setItems(items) { _, which -> if (which == 0) pickFile() else showLinkDialog(cancelFinishes) }
            .setOnCancelListener { if (cancelFinishes && !hasMedia) finish() }
            .show()
    }

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*")
            .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("video/*", "audio/*", "image/*"))
        @Suppress("DEPRECATION")
        startActivityForResult(i, REQ_PICK)
    }

    private fun pickSubtitle() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*")
        @Suppress("DEPRECATION")
        startActivityForResult(i, REQ_SUB)
    }

    private fun showLinkDialog(cancelFinishes: Boolean) {
        val input = EditText(this).apply {
            hint = "https://…"
            setSingleLine()
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            val clip = runCatching {
                getSystemService(ClipboardManager::class.java).primaryClip?.getItemAt(0)?.text?.toString()
            }.getOrNull()
            if (clip != null && (clip.startsWith("http://") || clip.startsWith("https://"))) setText(clip.trim())
        }
        val pad = dp(this, 20)
        val box = FrameLayout(this).apply { setPadding(pad, dp(this@PlayerActivity, 8), pad, 0) }
        box.addView(input, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.player_open_link))
            .setView(box)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val t = input.text.toString().trim()
                if (t.startsWith("http://") || t.startsWith("https://")) {
                    open(Uri.parse(t))
                } else {
                    Toast.makeText(this, getString(R.string.player_error), Toast.LENGTH_SHORT).show()
                    if (cancelFinishes && !hasMedia) finish()
                }
            }
            .setNegativeButton(android.R.string.cancel) { _, _ -> if (cancelFinishes && !hasMedia) finish() }
            .setOnCancelListener { if (cancelFinishes && !hasMedia) finish() }
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val u = data?.data
        when (req) {
            REQ_PICK -> if (res == RESULT_OK && u != null) open(u) else if (!hasMedia) finish()
            REQ_SUB -> if (res == RESULT_OK && u != null) addSubtitle(u)
        }
    }

    // ---- opening media ------------------------------------------------------------------------

    private fun mimeOf(u: Uri): String {
        val t = runCatching { contentResolver.getType(u) }.getOrNull()
        if (!t.isNullOrEmpty()) return t
        val ext = MimeTypeMap.getFileExtensionFromUrl(u.toString()).lowercase(Locale.US)
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: ""
    }

    private fun displayName(u: Uri): String {
        if (u.scheme == "content") {
            runCatching {
                contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val n = c.getString(0)
                        if (!n.isNullOrEmpty()) return n
                    }
                }
            }
        }
        return u.lastPathSegment ?: u.toString()
    }

    private fun open(u: Uri) {
        closeMedia()
        hasMedia = true
        currentUri = u
        isImage = mimeOf(u).startsWith("image/")
        titleView.text = displayName(u)
        for (v in videoOnly) v.visibility = if (isImage) View.GONE else View.VISIBLE
        setControlsVisible(true)
        if (isImage) openImage(u) else startPlayback(u)
    }

    private fun startPlayback(u: Uri) {
        val p = player ?: return
        val item = MediaItem.Builder().setUri(u).setSubtitleConfigurations(subs.toList()).build()
        val start = prefs.getLong(posKey(u), 0L)
        p.setMediaItem(item, start)
        p.setPlaybackSpeed(speed)
        p.prepare()
        p.playWhenReady = true
        spinner.visibility = View.VISIBLE
        ui.removeCallbacks(sizeFallback)
        ui.postDelayed(sizeFallback, 1500)
    }

    private fun closeMedia() {
        savePosition()
        ui.removeCallbacks(hideRunnable)
        ui.removeCallbacks(sizeFallback)
        teardownView()
        player?.let {
            it.stop()
            it.clearMediaItems()
        }
        subs.clear()
        pendingSubLabel = null
        bitmap = null
        zoom = 1f
        zoomCx = 0.5f
        zoomCy = 0.5f
        if (::zoomBtn.isInitialized) zoomBtn.text = "1×"
        vw = 0
        vh = 0
        vpar = 1f
        seek.progress = 0
        seek.secondaryProgress = 0
        curText.text = "0:00"
        durText.text = "0:00"
        subtitleView.text = ""
        subtitleView.visibility = View.GONE
        spinner.visibility = View.GONE
    }

    private fun posKey(u: Uri) = "pos_" + u.toString().hashCode()

    private fun savePosition() {
        val u = currentUri ?: return
        val p = player ?: return
        if (isImage || !hasMedia) return
        val dur = p.duration
        val pos = p.currentPosition
        val e = prefs.edit()
        if (dur > 0 && pos > 5_000L && pos < dur - 5_000L) e.putLong(posKey(u), pos) else e.remove(posKey(u))
        e.apply()
    }

    // ---- photos -------------------------------------------------------------------------------

    private fun openImage(u: Uri) {
        Thread {
            val bmp = runCatching { decodeImage(u) }.getOrNull()
            ui.post {
                if (isDestroyed || !isImage || currentUri != u) return@post
                if (bmp == null) {
                    fail()
                } else {
                    bitmap = bmp
                    vw = bmp.width
                    vh = bmp.height
                    vpar = 1f
                    applyRotation()
                    rebuildView()
                }
            }
        }.start()
    }

    /** Decodes with a power-of-two sample size so the long side stays near [MAX_SIDE], then applies EXIF rotation. */
    private fun decodeImage(u: Uri): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        openStream(u)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > MAX_SIDE) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val raw = openStream(u)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
        val orientation = runCatching {
            openStream(u)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) }
        }.getOrNull() ?: 1
        val mtx = Matrix()
        // EXIF orientation values: 2 flip-H, 3 rot180, 4 flip-V, 5 transpose, 6 rot90, 7 transverse, 8 rot270
        when (orientation) {
            2 -> mtx.postScale(-1f, 1f)
            3 -> mtx.postRotate(180f)
            4 -> mtx.postScale(1f, -1f)
            5 -> { mtx.postRotate(90f); mtx.postScale(-1f, 1f) }
            6 -> mtx.postRotate(90f)
            7 -> { mtx.postRotate(270f); mtx.postScale(-1f, 1f) }
            8 -> mtx.postRotate(270f)
            else -> return raw
        }
        return Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, mtx, true)
    }

    private fun openStream(u: Uri) =
        if (u.scheme == "http" || u.scheme == "https") {
            java.net.URL(u.toString()).openStream()
        } else {
            contentResolver.openInputStream(u)
        }

    private fun drawImage(g: GlPipeline, input: Surface) {
        val bmp = bitmap ?: return
        g.setCaptureSize(bmp.width, bmp.height)
        runCatching {
            val c = input.lockCanvas(null)
            try {
                c.drawBitmap(bmp, null, Rect(0, 0, c.width, c.height), Paint(Paint.FILTER_BITMAP_FLAG))
            } finally {
                input.unlockCanvasAndPost(c)
            }
        }.onFailure {
            Toast.makeText(this, getString(R.string.player_error), Toast.LENGTH_LONG).show()
        }
    }

    private fun fail() {
        Toast.makeText(this, getString(R.string.player_error), Toast.LENGTH_LONG).show()
        closeMedia()
        hasMedia = false
        setControlsVisible(true)
    }

    // ---- view + pipeline ----------------------------------------------------------------------

    /** (Re)creates the TextureView at the media's aspect ratio, fitted (or filled) inside the window, and its GL pipeline. */
    private fun rebuildView() {
        teardownView()
        if (vw <= 0 || vh <= 0) return
        val b = windowManager.currentWindowMetrics.bounds
        val aw = vw * vpar
        val ah = vh.toFloat()
        val sx = b.width().toFloat() / aw
        val sy = b.height().toFloat() / ah
        val s = if (aspectFill && !isImage) max(sx, sy) else min(sx, sy)
        val fw = (aw * s).toInt().coerceIn(2, 8192)
        val fh = (ah * s).toInt().coerceIn(2, 8192)
        val view = TextureView(this).apply { isOpaque = true }
        view.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, width: Int, height: Int) {
                if (tv === view) startPipeline(st)
            }

            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, width: Int, height: Int) {}

            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                if (tv === view) stopPipeline()
                return true
            }

            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        tv = view
        stage.addView(view, FrameLayout.LayoutParams(fw, fh, Gravity.CENTER))
    }

    private fun startPipeline(st: SurfaceTexture) {
        if (gl != null) return
        val out = Surface(st)
        outSurface = out
        val g = GlPipeline(out)
        g.onError = { msg ->
            ui.post { Toast.makeText(this, "+CRSC: $msg".take(240), Toast.LENGTH_LONG).show() }
        }
        g.bypass = !Cfg.playerFx
        g.zoom = zoom
        g.zoomX = zoomCx
        g.zoomY = zoomCy
        gl = g
        g.start(vw, vh) { input -> ui.post { if (gl === g) onInputReady(g, input) } }
    }

    private fun onInputReady(g: GlPipeline, input: Surface) {
        if (isImage) {
            drawImage(g, input)
        } else {
            player?.setVideoSurface(input)
        }
    }

    private fun stopPipeline() {
        if (!isImage) runCatching { player?.clearVideoSurface() }
        gl?.release()
        gl = null
        runCatching { outSurface?.release() }
        outSurface = null
    }

    private fun teardownView() {
        stopPipeline()
        tv?.let { v ->
            tv = null
            runCatching { stage.removeView(v) }
        }
    }

    // ---- gestures -----------------------------------------------------------------------------

    private fun onSingleTap() {
        if (panel.visibility == View.VISIBLE) {
            hidePanel()
            return
        }
        // Tap = play/pause can be switched off (Settings): then a tap only shows / hides the controls.
        if (isImage || !tapPlays) {
            setControlsVisible(!controlsOn)
            return
        }
        togglePlay()
        setControlsVisible(true)
    }

    private fun endGesture() {
        val p = player
        if (gestureMode == 1 && p != null) {
            p.seekTo(seekTarget)
            gl?.redraw()
        }
        gestureMode = 0
        if (holding) {
            holding = false
            p?.setPlaybackSpeed(holdPrevSpeed)
            hud.visibility = View.GONE
        }
    }

    private fun showHud(text: String, sticky: Boolean = false) {
        hud.text = text
        hud.visibility = View.VISIBLE
        ui.removeCallbacks(hudHide)
        if (!sticky) ui.postDelayed(hudHide, 900)
    }

    private fun currentBrightness(): Float {
        val b = window.attributes.screenBrightness
        return if (b < 0f) 0.5f else b
    }

    private fun setBrightness(v: Float) {
        window.attributes = window.attributes.also { it.screenBrightness = v }
    }

    private fun seekBy(deltaMs: Long) {
        val p = player ?: return
        val dur = p.duration
        val upper = if (dur > 0) dur else Long.MAX_VALUE
        p.seekTo((p.currentPosition + deltaMs).coerceIn(0L, upper))
        showHud(String.format(Locale.US, "%+d s", deltaMs / 1000L))
        gl?.redraw()
    }

    // ---- controls -----------------------------------------------------------------------------

    private fun isPlaying(): Boolean = player?.isPlaying == true

    private fun setPlayIcon(playing: Boolean) {
        playBtn.text = if (playing) "❚❚" else "▶"
    }

    private fun togglePlay() {
        val p = player ?: return
        when {
            p.playbackState == Player.STATE_ENDED -> {
                p.seekTo(0L)
                p.play()
            }
            p.isPlaying || p.playWhenReady -> p.pause()
            else -> p.play()
        }
    }

    private fun setControlsVisible(on: Boolean) {
        controlsOn = on
        bar.visibility = if (on && !isImage) View.VISIBLE else View.GONE
        topBar.visibility = if (on) View.VISIBLE else View.GONE
        val lp = subtitleView.layoutParams as FrameLayout.LayoutParams
        lp.bottomMargin = dp(this, if (on) 120 else 36)
        subtitleView.layoutParams = lp
        if (on) scheduleHide()
    }

    private fun scheduleHide() {
        ui.removeCallbacks(hideRunnable)
        if (isPlaying()) ui.postDelayed(hideRunnable, 3500)
    }

    private fun togglePanel() {
        if (panel.visibility == View.VISIBLE) {
            hidePanel()
            return
        }
        if (!panelBuilt) {
            panelBuilt = true
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            box.addView(buildPlayerHeader())
            box.addView(
                buildControls(
                    this,
                    onAdjust = { onPanelAdjust(it) },
                    inPlayer = true,
                    sourceScale = {
                        val v = tv
                        val srcW = vw * vpar
                        if (v == null || srcW <= 0f) 1f else v.width / srcW
                    }
                ) { gl?.redraw() },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )
            panel.addView(box, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        layoutPanel()
        panel.animate().cancel()
        panel.alpha = 1f
        panel.visibility = View.VISIBLE
        ui.removeCallbacks(hideRunnable)
        schedulePanelIdle()
    }

    /**
     * Portrait: a sheet over the lower half. Landscape: a narrow column on the right, so most of the picture
     * stays free to judge the effect.
     */
    private fun layoutPanel() {
        val b = windowManager.currentWindowMetrics.bounds
        val land = b.width() > b.height()
        val lp = panel.layoutParams as FrameLayout.LayoutParams
        val m = dp(this, 12)
        if (land) {
            lp.width = (b.width() * 0.40f).toInt()
            lp.height = ((b.height() - insT - insB) * 0.86f).toInt()
            lp.gravity = Gravity.END or Gravity.CENTER_VERTICAL
            lp.setMargins(m, m + insT, m + insR, m + insB)
        } else {
            lp.width = ViewGroup.LayoutParams.MATCH_PARENT
            lp.height = (b.height() * 0.5f).toInt()
            lp.gravity = Gravity.BOTTOM
            lp.setMargins(m + insL, 0, m + insR, dp(this, if (bar.visibility == View.VISIBLE) 110 else 24) + insB)
        }
        panel.layoutParams = lp
    }

    /** Keeps the top bar, bottom bar and panel out of the camera cutout and system-bar areas. */
    private fun applyInsets() {
        val ins = windowManager.currentWindowMetrics.windowInsets
            .getInsetsIgnoringVisibility(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
        insL = ins.left
        insT = ins.top
        insR = ins.right
        insB = ins.bottom
        val m = dp(this, 12)
        val tlp = topBar.layoutParams as FrameLayout.LayoutParams
        tlp.setMargins(m + insL, dp(this, 10) + insT, m + insR, 0)
        topBar.layoutParams = tlp
        val blp = bar.layoutParams as FrameLayout.LayoutParams
        blp.setMargins(m + insL, m, m + insR, m + insB)
        bar.layoutParams = blp
        if (panel.visibility == View.VISIBLE) layoutPanel()
    }

    private fun hidePanel() {
        ui.removeCallbacks(panelRestore)
        ui.removeCallbacks(panelIdleHide)
        panel.animate().cancel()
        panel.alpha = 1f
        panel.visibility = View.GONE
        scheduleHide()
    }

    private fun schedulePanelIdle() {
        ui.removeCallbacks(panelIdleHide)
        if (Cfg.panelFade && panel.visibility == View.VISIBLE) ui.postDelayed(panelIdleHide, 7000)
    }

    /** A slider is held: panel nearly transparent so the picture can be judged; restored a moment after release. */
    private fun onPanelAdjust(active: Boolean) {
        if (!Cfg.panelFade) return
        ui.removeCallbacks(panelRestore)
        ui.removeCallbacks(panelIdleHide)
        if (active) {
            panel.animate().cancel()
            panel.animate().alpha(0.12f).setDuration(120).start()
        } else {
            ui.postDelayed(panelRestore, 1500)
        }
    }

    /** Top of the player's settings panel: options that only exist inside the player. */
    private fun buildPlayerHeader(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(
            Ui.text(this, getString(R.string.player_panel_title), 18f, Ui.TEXT, true),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        head.addView(Ui.text(this, "✕", 20f, Ui.ACCENT, true).apply {
            setPadding(dp(this@PlayerActivity, 12), dp(this@PlayerActivity, 4), dp(this@PlayerActivity, 4), dp(this@PlayerActivity, 4))
            setOnClickListener { hidePanel() }
        })
        col.addView(head)

        fun sw(label: String, checked: Boolean, onChange: (Boolean) -> Unit) = Switch(this).apply {
            text = label
            setTextColor(Ui.TEXT)
            isChecked = checked
            setOnCheckedChangeListener { _, c -> onChange(c) }
        }
        fun gap(v: Int) = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(this@PlayerActivity, v) }

        val fx = sw(getString(R.string.player_fx_switch), Cfg.playerFx) { setFx(it) }
        fxSwitch = fx
        col.addView(fx, gap(12))

        val tap = sw(getString(R.string.player_tap_switch), tapPlays) {
            tapPlays = it
            prefs.edit().putBoolean("tapPlays", it).apply()
        }
        tapSwitch = tap
        col.addView(tap, gap(10))
        col.addView(Ui.text(this, getString(R.string.player_tap_hint), 12f, Ui.MUTED), gap(2))

        col.addView(
            sw(getString(R.string.player_pause_overlay_switch), Cfg.pauseOverlayInPlayer) {
                Cfg.pauseOverlayInPlayer = it
                Cfg.save(this)
                OverlayService.instance?.pauseForPlayer(it)
            },
            gap(10)
        )
        col.addView(Ui.text(this, getString(R.string.player_pause_overlay_hint), 12f, Ui.MUTED), gap(2))

        col.addView(Ui.text(this, getString(R.string.player_effects_label), 12f, Ui.MUTED), gap(16))
        return col
    }

    // ---- effect on/off (A/B compare) ------------------------------------------------------------

    private fun paintFx() {
        val on = Cfg.playerFx
        fxBtn.background = if (on) Ui.gradient(dp(this, 10).toFloat()) else Ui.round(Color.parseColor("#B30B1020"), dp(this, 10).toFloat(), Ui.STROKE, dp(this, 1))
        fxBtn.setTextColor(if (on) Ui.BG else Ui.MUTED)
    }

    private fun setFx(on: Boolean) {
        if (Cfg.playerFx == on) {
            paintFx()
            return
        }
        Cfg.playerFx = on
        Cfg.save(this)
        gl?.let {
            it.bypass = !on
            it.redraw()
        }
        paintFx()
        fxSwitch?.let { if (it.isChecked != on) it.isChecked = on }
        showHud(getString(if (on) R.string.player_fx_on else R.string.player_fx_off))
    }

    // ---- zoom (inspect how much the picture changed) ---------------------------------------------

    /** Pinch = free zoom; the button steps 1x / 2x / 4x / 8x. Zoomed in, one finger pans. The zoom is
     *  done on the real source pixels inside the pipeline, so FX on/off can be compared at pixel level. */
    private fun setZoom(z: Float, fromPinch: Boolean = false) {
        zoom = z.coerceIn(1f, MAX_ZOOM)
        if (zoom <= 1.01f) {
            zoom = 1f
            zoomCx = 0.5f
            zoomCy = 0.5f
        }
        applyZoom()
        if (!fromPinch || zoom > 1f) showHud(getString(R.string.player_zoom_fmt, zoom))
    }

    private fun cycleZoom() {
        val steps = floatArrayOf(1f, 2f, 4f, 8f)
        val next = steps.firstOrNull { it > zoom + 0.01f } ?: 1f
        setZoom(next)
    }

    private fun applyZoom() {
        val half = 0.5f / zoom
        zoomCx = zoomCx.coerceIn(half, 1f - half)
        zoomCy = zoomCy.coerceIn(half, 1f - half)
        gl?.setZoom(zoom, zoomCx, zoomCy)
        if (::zoomBtn.isInitialized) {
            zoomBtn.text = if (zoom == zoom.toInt().toFloat()) zoom.toInt().toString() + "×" else String.format(Locale.US, "%.1f×", zoom)
            zoomBtn.setTextColor(if (zoom > 1f) Ui.ACCENT else Ui.TEXT)
        }
    }

    // ---- rotation -------------------------------------------------------------------------------

    private fun applyRotation() {
        requestedOrientation = when (rotMode) {
            ROT_LAND -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            ROT_PORT -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            ROT_FREE -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
            else -> when {
                isImage || vw <= 0 -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
                vw * vpar >= vh -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                else -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            }
        }
    }

    /** Auto (by the video's shape) -> landscape -> portrait -> free (follows the phone) -> auto ... */
    private fun cycleRotation() {
        rotMode = (rotMode + 1) % 4
        prefs.edit().putInt("rot", rotMode).apply()
        applyRotation()
        showHud(
            getString(
                when (rotMode) {
                    ROT_LAND -> R.string.rot_landscape
                    ROT_PORT -> R.string.rot_portrait
                    ROT_FREE -> R.string.rot_free
                    else -> R.string.rot_auto
                }
            )
        )
    }

    // ---- media size / picture view --------------------------------------------------------------

    /**
     * Creates (or resizes) the picture view for a media size. The decoder only reports its video size once it
     * is rendering into a surface, and that surface only exists after this view does, so the size is also taken
     * from the track format (see [sizeFromTracks]) and from a timeout fallback ([ensureViewFallback]).
     */
    private fun applyMediaSize(w: Int, h: Int, par: Float) {
        if (w <= 0 || h <= 0 || isImage) return
        val first = vw == 0
        if (first || w != vw || h != vh || par != vpar || tv == null) {
            vw = w
            vh = h
            vpar = par
            if (first) applyRotation()
            rebuildView()
        }
    }

    private fun sizeFromTracks(tracks: Tracks) {
        for (g in tracks.groups) {
            if (g.type != C.TRACK_TYPE_VIDEO) continue
            for (i in 0 until g.length) {
                if (!g.isTrackSelected(i)) continue
                if (sizeFromFormat(g.getTrackFormat(i))) return
            }
        }
    }

    private fun sizeFromFormat(f: Format): Boolean {
        if (f.width <= 0 || f.height <= 0) return false
        val swap = f.rotationDegrees == 90 || f.rotationDegrees == 270
        val par = if (f.pixelWidthHeightRatio > 0f) f.pixelWidthHeightRatio else 1f
        applyMediaSize(if (swap) f.height else f.width, if (swap) f.width else f.height, par)
        return true
    }

    private fun ensureViewFallback() {
        if (isImage || !hasMedia || tv != null) return
        val f = player?.videoFormat
        if (f != null && sizeFromFormat(f)) return
        val b = windowManager.currentWindowMetrics.bounds
        applyMediaSize(b.width(), b.height(), 1f)
    }

    private fun tick() {
        val p = player ?: return
        if (!isImage && hasMedia) {
            val dur = p.duration
            if (!dragging) {
                val pos = p.currentPosition
                curText.text = fmt(pos)
                if (dur > 0) {
                    seek.progress = (pos * 1000L / dur).toInt().coerceIn(0, 1000)
                    seek.secondaryProgress = (p.bufferedPosition * 1000L / dur).toInt().coerceIn(0, 1000)
                }
            }
            durText.text = if (dur > 0) fmt(dur) else "LIVE"
            // keep a paused video responding to live setting changes
            if (!p.isPlaying && panel.visibility == View.VISIBLE) gl?.redraw()
        } else if (isImage && panel.visibility == View.VISIBLE) {
            gl?.redraw()
        }
    }

    private fun fmt(ms: Long): String {
        val t = (ms / 1000L).coerceAtLeast(0L)
        val h = t / 3600
        val m = (t % 3600) / 60
        val s = t % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s) else String.format(Locale.US, "%d:%02d", m, s)
    }

    // ---- menus: speed, tracks, more -----------------------------------------------------------

    private fun showSpeedMenu() {
        val values = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
        val labels = values.map { speedLabel(it) }.toTypedArray()
        var checked = values.indexOfFirst { it == speed }
        if (checked < 0) checked = 2
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.player_speed))
            .setSingleChoiceItems(labels, checked) { d, which ->
                speed = values[which]
                player?.setPlaybackSpeed(speed)
                speedBtn.text = speedLabel(speed)
                d.dismiss()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun speedLabel(v: Float): String =
        if (v == v.toInt().toFloat()) v.toInt().toString() + "×" else v.toString() + "×"

    private fun trackName(f: Format, n: Int): String {
        val lang = f.language
        val langName = if (!lang.isNullOrEmpty() && lang != "und") Locale.forLanguageTag(lang).getDisplayLanguage(Locale.getDefault()) else ""
        val base = when {
            !f.label.isNullOrEmpty() -> f.label.toString()
            langName.isNotEmpty() -> langName
            else -> getString(R.string.player_track_fmt, n)
        }
        return if (f.channelCount > 0) "$base  (${f.channelCount}ch)" else base
    }

    private fun selectTextTrack(p: Player, g: Tracks.Group, i: Int) {
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i))
            .build()
    }

    private fun showTrackMenu(type: Int) {
        val p = player ?: return
        val isText = type == C.TRACK_TYPE_TEXT
        val labels = ArrayList<String>()
        val entries = ArrayList<Pair<Tracks.Group, Int>>()
        var checked = -1
        if (isText) labels.add(getString(R.string.player_off))
        for (g in p.currentTracks.groups) {
            if (g.type != type) continue
            for (i in 0 until g.length) {
                if (!g.isTrackSupported(i)) continue
                entries.add(Pair(g, i))
                labels.add(trackName(g.getTrackFormat(i), entries.size))
                if (g.isTrackSelected(i)) checked = labels.size - 1
            }
        }
        if (entries.isEmpty()) {
            Toast.makeText(this, getString(R.string.player_no_tracks), Toast.LENGTH_SHORT).show()
            if (!isText) return
        }
        if (isText && (checked < 0 || p.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT))) checked = 0
        AlertDialog.Builder(this)
            .setTitle(getString(if (isText) R.string.player_subs else R.string.player_audio))
            .setSingleChoiceItems(labels.toTypedArray(), checked) { d, which ->
                if (isText && which == 0) {
                    p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                        .build()
                    subtitleView.text = ""
                    subtitleView.visibility = View.GONE
                } else {
                    val (g, i) = entries[if (isText) which - 1 else which]
                    if (isText) {
                        selectTextTrack(p, g, i)
                    } else {
                        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                            .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i))
                            .build()
                    }
                }
                d.dismiss()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showMoreMenu() {
        val labels = ArrayList<String>()
        labels.add(getString(R.string.player_open_file))
        labels.add(getString(R.string.player_open_link))
        if (!isImage) labels.add(getString(R.string.player_add_sub))
        if (!isImage) labels.add(getString(R.string.player_sub_size_fmt, subSize))
        labels.add(getString(if (aspectFill) R.string.player_aspect_fill else R.string.player_aspect_fit))
        if (!isImage) labels.add(getString(if (tapPlays) R.string.player_tap_play else R.string.player_tap_controls))
        val keys = ArrayList<String>()
        keys.add("file"); keys.add("link")
        if (!isImage) { keys.add("sub"); keys.add("subsize") }
        keys.add("aspect")
        if (!isImage) keys.add("tap")
        AlertDialog.Builder(this)
            .setItems(labels.toTypedArray()) { _, which ->
                when (keys[which]) {
                    "file" -> pickFile()
                    "link" -> showLinkDialog(false)
                    "sub" -> pickSubtitle()
                    "subsize" -> {
                        subSize = if (subSize >= 32) 14 else subSize + 4
                        subtitleView.textSize = subSize.toFloat()
                        prefs.edit().putInt("subSize", subSize).apply()
                        Toast.makeText(this, getString(R.string.player_sub_size_fmt, subSize), Toast.LENGTH_SHORT).show()
                    }
                    "aspect" -> {
                        aspectFill = !aspectFill
                        prefs.edit().putBoolean("aspectFill", aspectFill).apply()
                        if (vw > 0) rebuildView()
                    }
                    "tap" -> {
                        tapPlays = !tapPlays
                        prefs.edit().putBoolean("tapPlays", tapPlays).apply()
                        tapSwitch?.let { if (it.isChecked != tapPlays) it.isChecked = tapPlays }
                        Toast.makeText(this, getString(if (tapPlays) R.string.player_tap_play else R.string.player_tap_controls), Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .show()
    }

    // ---- external subtitles -------------------------------------------------------------------

    private fun addSubtitle(u: Uri) {
        val name = displayName(u)
        Thread {
            val f = runCatching { normalizeSubtitle(u, name) }.getOrNull()
            ui.post {
                if (isDestroyed) return@post
                if (f == null) {
                    Toast.makeText(this, getString(R.string.player_error), Toast.LENGTH_LONG).show()
                } else {
                    val cfg = MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(f))
                        .setMimeType(subtitleMime(name))
                        .setLabel(name)
                        .build()
                    subs.add(cfg)
                    pendingSubLabel = name
                    reloadMedia()
                    Toast.makeText(this, getString(R.string.player_sub_added), Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    /** Re-prepares the current item (with the external subtitle list) and keeps position and play state. */
    private fun reloadMedia() {
        val p = player ?: return
        val u = currentUri ?: return
        val pos = p.currentPosition
        val play = p.playWhenReady
        val item = MediaItem.Builder().setUri(u).setSubtitleConfigurations(subs.toList()).build()
        p.setMediaItem(item, pos)
        p.prepare()
        p.playWhenReady = play
    }

    private fun subtitleMime(name: String): String {
        val n = name.lowercase(Locale.US)
        return when {
            n.endsWith(".vtt") -> "text/vtt"
            n.endsWith(".ass") || n.endsWith(".ssa") -> "text/x-ssa"
            n.endsWith(".ttml") || n.endsWith(".xml") || n.endsWith(".dfxp") -> "application/ttml+xml"
            else -> "application/x-subrip"
        }
    }

    /**
     * Subtitle files from the web are often not UTF-8 (Windows-1256 for Persian / Arabic, Windows-1252 for
     * Western languages). The player expects UTF-8, so the file is decoded here and rewritten to cache.
     */
    private fun normalizeSubtitle(u: Uri, name: String): File {
        val raw = (openStream(u) ?: error("cannot open")).use { it.readBytes() }
        var data = raw
        val text: String = when {
            data.size >= 3 && data[0] == 0xEF.toByte() && data[1] == 0xBB.toByte() && data[2] == 0xBF.toByte() -> {
                data = data.copyOfRange(3, data.size)
                String(data, Charsets.UTF_8)
            }
            data.size >= 2 && data[0] == 0xFF.toByte() && data[1] == 0xFE.toByte() -> String(data, 2, data.size - 2, Charsets.UTF_16LE)
            data.size >= 2 && data[0] == 0xFE.toByte() && data[1] == 0xFF.toByte() -> String(data, 2, data.size - 2, Charsets.UTF_16BE)
            else -> try {
                Charsets.UTF_8.newDecoder()
                    .onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT)
                    .decode(ByteBuffer.wrap(data))
                    .toString()
            } catch (e: CharacterCodingException) {
                val lang = resources.configuration.locales[0].language
                val cs = if (lang == "fa" || lang == "ar") "windows-1256" else "windows-1252"
                String(data, Charset.forName(cs))
            }
        }
        val ext = when {
            name.lowercase(Locale.US).endsWith(".vtt") -> "vtt"
            name.lowercase(Locale.US).endsWith(".ass") -> "ass"
            name.lowercase(Locale.US).endsWith(".ssa") -> "ssa"
            name.lowercase(Locale.US).endsWith(".ttml") -> "ttml"
            else -> "srt"
        }
        val f = File(cacheDir, "sub_" + System.nanoTime() + "." + ext)
        f.writeText(text, Charsets.UTF_8)
        return f
    }

    // ---- lifecycle ----------------------------------------------------------------------------

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            if (::topBar.isInitialized) applyInsets()
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        root.post {
            applyInsets()
            if (vw > 0 && vh > 0) rebuildView()
        }
    }

    override fun onResume() {
        super.onResume()
        ui.post(ticker)
        if (Cfg.pauseOverlayInPlayer) OverlayService.instance?.pauseForPlayer(true)
    }

    override fun onPause() {
        ui.removeCallbacks(ticker)
        ui.removeCallbacks(hideRunnable)
        savePosition()
        player?.pause()
        OverlayService.instance?.pauseForPlayer(false)
        super.onPause()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        OverlayService.instance?.pauseForPlayer(false)
        teardownView()
        player?.release()
        player = null
        bitmap = null
        runCatching { cacheDir.listFiles()?.forEach { if (it.name.startsWith("sub_")) it.delete() } }
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (panel.visibility == View.VISIBLE) {
            hidePanel()
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }

    private companion object {
        const val REQ_PICK = 21
        const val REQ_SUB = 22
        const val MAX_ZOOM = 12f
        const val ROT_AUTO = 0
        const val ROT_LAND = 1
        const val ROT_PORT = 2
        const val ROT_FREE = 3
        /** Long-side cap for decoded photos (keeps GPU textures within every device's limit). */
        const val MAX_SIDE = 4096
    }
}

/** Scroll container for the player's settings; reports every finger-down so the idle auto-hide timer restarts. */
class FadePanel(ctx: Context) : ScrollView(ctx) {
    var onTouch: (() -> Unit)? = null

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN || ev.actionMasked == MotionEvent.ACTION_UP) onTouch?.invoke()
        return super.dispatchTouchEvent(ev)
    }
}
