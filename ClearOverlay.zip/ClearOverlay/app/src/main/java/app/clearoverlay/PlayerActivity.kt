package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.app.PendingIntent
import android.app.PictureInPictureParams
import android.app.RemoteAction
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.graphics.drawable.Icon
import android.util.Rational
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.media.AudioManager
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewConfiguration
import android.view.ScaleGestureDetector
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.webkit.MimeTypeMap
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.text.CueGroup
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import java.io.File
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.util.concurrent.atomic.AtomicBoolean
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Built-in video / photo player. The file or stream is decoded directly (no screen capture), then goes
 * through the same GPU pipeline as the overlay (denoise / deband / anti-aliasing -> FSR 1 / SGSR 1 /
 * bilinear upscale -> sharpen -> vivid colors), so a low-resolution source is upscaled from its real pixels.
 *
 *  - Engine: Media3 ExoPlayer (local files, direct links, HLS, DASH, mkv/mp4/webm ...), output surface =
 *    [GlPipeline] input, shown in a TextureView.
 *  - Subtitles: embedded tracks or an external .srt / .vtt / .ass file (re-encoded to UTF-8 when needed),
 *    drawn by a TextView on top of the processed picture.
 *  - Gestures: tap, double tap, horizontal drag (seek), vertical drag (left = brightness, right = volume),
 *    long press (2x speed while held).
 *  - Photos: decoded with BitmapFactory (EXIF-rotated, long side capped) and drawn once into the pipeline.
 */
class PlayerActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    /** Sleep timer of the player (set in the speed dialog): pauses the video when it runs out. */
    private var sleepEndMs = 0L
    private val sleepStop = Runnable {
        sleepEndMs = 0L
        player?.pause()
        Toast.makeText(this, R.string.pl_sleep_done, Toast.LENGTH_LONG).show()
    }

    private lateinit var root: FrameLayout
    private lateinit var stage: FrameLayout
    private lateinit var titleView: TextView
    private lateinit var topBar: LinearLayout
    private lateinit var barWatch: Edge.TransientBars
    private lateinit var volBtn: ImageView
    private lateinit var volPanel: LinearLayout
    private var volIcon: ImageView? = null
    private var volBar: SeekBar? = null
    private var volText: TextView? = null
    private lateinit var fxBtn: TextView
    private lateinit var bar: LinearLayout
    private lateinit var seekRow: LinearLayout
    private lateinit var playBtn: TextView
    private lateinit var seek: SeekBar
    private lateinit var curText: TextView
    private lateinit var durText: TextView
    private lateinit var speedBtn: TextView
    private lateinit var subtitleView: TextView
    private lateinit var hud: TextView
    private lateinit var spinner: ProgressBar
    private lateinit var panel: FadePanel
    private val videoOnly = ArrayList<View>()
    private lateinit var shotBtn: TextView

    private var tv: TextureView? = null
    private var gl: GlPipeline? = null
    private var outSurface: Surface? = null
    private var player: ExoPlayer? = null

    private var currentUri: Uri? = null
    private val subs = ArrayList<MediaItem.SubtitleConfiguration>()
    private var pendingSubLabel: String? = null

    private var isImage = false
    private var bitmap: Bitmap? = null
    /** The photo as decoded from the file (before Smart fix / AI); [bitmap] is what is shown and saved. */
    private var baseBitmap: Bitmap? = null
    private var busy = false
    private val aiCancel = AtomicBoolean(false)
    @Volatile private var aiUserCancel = false // the person cancelled (Back / a tap), as opposed to leaving the photo meanwhile
    private val imageOnly = ArrayList<View>()
    /** Previous / next buttons: only useful when a playlist exists. */
    private val navViews = ArrayList<View>()
    private lateinit var rotBtn: TextView
    private var vw = 0
    private var vh = 0
    private var vpar = 1f
    /** Black bars cut off by Auto crop (fractions of the frame: left, bottom, right, top). */
    private var bars = FloatArray(4)
    private var hasMedia = false
    // playlist (always one type: only videos or only photos) + Auto state
    private val playlist = ArrayList<Uri>()
    private var playIndex = -1
    private var slideshow = 0 // seconds per photo while a slideshow runs, 0 = off
    private val slideTick = object : Runnable {
        override fun run() {
            if (slideshow <= 0 || isDestroyed || !isImage || playlist.size < 2) { slideshow = 0; return }
            // a photo that is being zoomed or worked on is not taken away from the person: wait one more turn
            if (!busy && zoom <= 1.01f) {
                playIndex = (playIndex + 1) % playlist.size // after the last photo it starts again
                open(playlist[playIndex], keepList = true)
            }
            ui.postDelayed(this, slideshow * 1000L)
        }
    }

    private fun startSlideshow(sec: Int) {
        slideshow = sec
        ui.removeCallbacks(slideTick)
        ui.postDelayed(slideTick, sec * 1000L)
        showHud(getString(R.string.slide_on_fmt, sec))
    }

    private fun stopSlideshow(say: Boolean) {
        if (slideshow <= 0) return
        slideshow = 0
        ui.removeCallbacks(slideTick)
        if (say) showHud(getString(R.string.slide_off))
    }

    private fun slideshowDialog() {
        val secs = intArrayOf(3, 5, 8, 15)
        AlertDialog.Builder(this)
            .setTitle(R.string.slide_title)
            .setItems(secs.map { getString(R.string.slide_sec_fmt, it) }.toTypedArray()) { _, w -> startSlideshow(secs[w]) }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }
    /** The playlist is the growing result of a streaming upscale ([ExportState.segs]); see [syncStream]. */
    private var streamJob = false

    /**
     * The picture on screen already went through the upscale export (the pieces of "Watch now" / of a running file export, and the
     * finished file when that export ends while it is watched): it is only shown, none of the live effects run on top of it.
     */
    private var plainView = false
    /** Watch now: the player's live effects on the finished pieces. Off by default (the pieces already carry the export's work); remembered. */
    private fun streamFxOn() = getSharedPreferences("crsc", Context.MODE_PRIVATE).getBoolean("stream_fx", false)
    /** Whether the live effects are really on: for a stream it is the Watch now choice above, otherwise the FX switch (and not a plain view). */
    private fun fxEffective(): Boolean = if (streamJob) streamFxOn() else Cfg.playerFx && !plainView
    /** Watch now: the person pressed pause / stop while it was preparing: it goes on preparing but does not start by itself. */
    private var stopWanted = false
    /** Streaming: the spot (microseconds of the whole video) the viewer asked for, while no finished piece covers it; -1 = none. */
    private var pendingSeekUs = -1L
    /** Streaming: where in the next piece to start (ms), -1 = the saved position. */
    private var startAtMs = -1L
    /** Streaming: the pieces that are in the player's playlist, in order (the picture view stays open while pieces are added and removed). */
    private val streamItems = ArrayList<ExportSeg>()
    private var exitAsked = false
    private var fromLibrary = false
    private var autoBudgetCap = Profiles.QUALITY
    private var pendingBudgetApply = true // budget Auto: the first picture of a video applies its budget even when the number did not change
    private var lastAutoUp = 0L          // when Auto last gave a budget step back (after a calm minute)
    private var autoNoRaise = false      // a raise was followed by dropped frames again: stay at the lower budget for this video
    private var lastThermalCheck = 0L
    private var lastThermalCap = Profiles.QUALITY // the heat / battery cap Auto last applied
    private var autoTemporalSet = false  // the temporal clean-up in force was switched on by Auto (so Auto may switch it off again)
    private var lastAutoDown = 0L
    private var panelBuilt = false
    private var dragging = false
    private var controlsOn = true
    private var fxSwitch: Switch? = null
    private var tapSwitch: Switch? = null
    private var rotAxis = -1       // -1 follows the picture's shape, 0 landscape, 1 portrait
    private var rotFree = false    // follow the phone in every direction
    private var rotManual = -1     // the exact direction chosen by hand (an ActivityInfo.SCREEN_ORIENTATION_* value, -1 = off); a video starts without it
    private var rotLock = false    // the direction lock: keeps the screen as it is NOW (separate from the choice above; lasts until switched off or the player closes)
    private var shapeHint = 0      // the shape of the file, read BEFORE it is opened: 0 unknown, 1 landscape, 2 portrait (so the screen is right from the first frame)
    private val panelVideoOnly = ArrayList<View>() // settings rows that mean nothing for a photo
    private lateinit var miniHud: TextView
    private val miniHide = Runnable { if (::miniHud.isInitialized) miniHud.visibility = View.GONE }
    private var firstFrame = false
    private lateinit var poster: ImageView
    private var posterToken = 0

    /** Shows a still picture of the spot the video starts at while the decoder and the effects start (no black screen); local files only. */
    private fun showPoster(u: Uri, atMs: Long) {
        if (!::poster.isInitialized || isImage || streamJob || u.scheme == Net.SCHEME || u.scheme == "http" || u.scheme == "https") return
        val token = ++posterToken
        poster.setImageDrawable(null)
        poster.alpha = 1f
        Thread {
            val bmp = runCatching {
                val mr = android.media.MediaMetadataRetriever()
                try {
                    mr.setDataSource(this, u)
                    mr.getScaledFrameAtTime(atMs.coerceAtLeast(0L) * 1000L, android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 960, 960)
                } finally {
                    runCatching { mr.release() }
                }
            }.getOrNull()
            ui.post {
                if (isDestroyed || token != posterToken || firstFrame || bmp == null) {
                    bmp?.recycle()
                    return@post
                }
                poster.setImageBitmap(bmp)
                poster.visibility = View.VISIBLE
                ui.postDelayed({ if (token == posterToken) hidePoster() }, 6000) // never stays if no frame event comes
            }
        }.start()
    }

    private fun hidePoster() {
        if (!::poster.isInitialized) return
        posterToken++
        if (poster.visibility == View.VISIBLE) poster.animate().alpha(0f).setDuration(120).withEndAction { poster.visibility = View.GONE; poster.setImageDrawable(null) }.start()
    }
    private var stallTries = 0
    private lateinit var zoomBtn: TextView
    private lateinit var toolsBtn: ImageView
    private var zoom = 1f
    private var zoomCx = 0.5f
    private var zoomCy = 0.5f
    // size of the fitted picture (the strip a wide picture occupies); zoomed in, the picture view grows past it up to the whole stage
    private var fitW = 1f
    private var fitH = 1f
    private var pinching = false
    // safe-area insets (camera cutout, status / navigation bars): controls are kept clear of them
    private var insL = 0
    private var insT = 0
    private var insR = 0
    private var insB = 0

    // player settings (saved)
    private var tapPlays = true
    /** Picture size: 0 fit, 1 fill (crop edges), 2 stretch to the screen, 3 = 16:9, 4 = 4:3, 5 = 21:9. Videos only; photos are always fitted. */
    private var aspectMode = 0
    private var aspectBtn: TextView? = null
    /** Size of the stage the picture view was last built for: when it changes (rotation) the view is rebuilt. */
    private var builtStageW = 0
    private var builtStageH = 0
    private var subSize = 18
    private var speed = 1f

    // gesture state
    private var gestureMode = 0 // 0 none, 1 seek, 2 brightness, 3 volume
    // photo swipe (a slow drag also counts, not only a fast fling)
    private var swipeDownX = 0f
    private var swipeDownY = 0f
    private var swipeDone = false
    private var swipeMulti = false
    private var lastStepAt = 0L
    private var seekStartPos = 0L
    private var seekTarget = 0L
    private var brightStart = 0.5f
    private var volStart = 0
    private var holding = false
    private var holdPrevSpeed = 1f

    private val prefs by lazy { getSharedPreferences("crsc_player", Context.MODE_PRIVATE) }
    private val audio by lazy { getSystemService(AudioManager::class.java) }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    private val ticker = object : Runnable {
        override fun run() {
            tick()
            ui.postDelayed(this, 200)
        }
    }

    private val hideRunnable = Runnable {
        if (panel.visibility != View.VISIBLE && isPlaying() && vw > 0) setControlsVisible(false)
    }

    /** Settings panel: back to full opacity shortly after a slider is released. */
    private val panelRestore = Runnable {
        panel.animate().alpha(1f).setDuration(200).start()
        schedulePanelIdle()
    }

    /** Settings panel: fades out and closes itself after a few idle seconds (when fading is enabled). */
    private val panelIdleHide = Runnable {
        if (panel.visibility == View.VISIBLE && Cfg.panelAutoClose) {
            panel.animate().alpha(0f).setDuration(250).withEndAction { hidePanel() }.start()
        }
    }

    /** The decoder may not report a size until it has a surface, so if nothing created the picture view yet, make it anyway. */
    private val sizeFallback = Runnable { ensureViewFallback() }

    private val hudHide = Runnable { hud.visibility = View.GONE }

    /**
     * Some videos start with a black picture or a spinner that never ends (the decoder and the picture surface
     * missed each other). If no frame has been drawn a few seconds after starting, redo what stopping and starting
     * by hand does: re-attach the picture surface, then nudge the decoder, then reload the file at the same spot.
     */
    private val stallCheck = object : Runnable {
        override fun run() {
            val p = player ?: return
            if (isDestroyed || isImage || !hasMedia || firstFrame) return
            val st = p.playbackState
            if (st == Player.STATE_ENDED || st == Player.STATE_IDLE) return
            // a file with no picture at all (audio only) never draws a frame: leave it alone
            if (st == Player.STATE_READY && !p.currentTracks.isTypeSelected(C.TRACK_TYPE_VIDEO)) return
            stallTries++
            when (stallTries) {
                1 -> if (vw > 0) rebuildView() else ensureViewFallback()
                2 -> p.seekTo(p.currentPosition)
                else -> {
                    val pos = p.currentPosition
                    p.stop()
                    p.prepare()
                    p.seekTo(pos)
                    p.playWhenReady = true
                }
            }
            if (stallTries < 4) ui.postDelayed(this, 2500)
        }
    }

    // A video opened for the first time can stay black while the sound plays (the decoder and the picture view did not meet in time);
    // the person got it back by moving the position. The player now notices that no picture reached the screen and does the same itself.
    private var blackTries = 0
    private var blackGl: GlPipeline? = null
    private var blackBase = 0L
    private val blackCheck = object : Runnable {
        override fun run() {
            val p = player ?: return
            if (isDestroyed || isImage || !hasMedia || streamJob) return
            val st = p.playbackState
            if (st == Player.STATE_ENDED || st == Player.STATE_IDLE) return
            if (st == Player.STATE_READY && !p.currentTracks.isTypeSelected(C.TRACK_TYPE_VIDEO)) return // a sound file: no picture is expected
            if (st == Player.STATE_BUFFERING) { ui.postDelayed(this, 1000); return } // still loading: not a black picture yet
            val g = gl
            if (g !== blackGl) { blackGl = g; blackBase = 0L } // the picture view was rebuilt: its counter starts again
            if (g != null && g.presentedFrames > blackBase) return // a picture is on the screen
            blackTries++
            when (blackTries) {
                1 -> { g?.redraw(); p.seekTo(p.currentPosition) } // the same as moving the position a little
                2 -> if (vw > 0) rebuildView() else p.seekTo(p.currentPosition)
                else -> return
            }
            blackBase = gl?.presentedFrames ?: 0L
            blackGl = gl
            ui.postDelayed(this, 1500)
        }
    }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            setPlayIcon(isPlaying)
            if (isPlaying) scheduleHide() else ui.removeCallbacks(hideRunnable)
            updatePip()
            updateSession()
        }

        override fun onRenderedFirstFrame() {
            firstFrame = true
            ui.removeCallbacks(stallCheck)
            // the effects draw their first frame a moment after the decoder's: keep the still picture until then
            ui.postDelayed({ hidePoster() }, 250)
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            updateSession()
            spinner.visibility = if (playbackState == Player.STATE_BUFFERING) View.VISIBLE else View.GONE
            if (playbackState == Player.STATE_READY) ensureViewFallback()
            if (playbackState == Player.STATE_ENDED) {
                if (streamJob) {
                    syncStream()
                    if (!streamAtVideoEnd()) { // the next piece is not ready yet: this is waiting, not the end
                        spinner.visibility = View.VISIBLE
                        return
                    }
                }
                setPlayIcon(false)
                setControlsVisible(true)
                if (!streamJob && Cfg.autoNext && playIndex in 0 until playlist.size - 1) step(1)
            }
        }

        override fun onVideoSizeChanged(videoSize: VideoSize) {
            gl?.let { g ->
                val fr = player?.videoFormat?.frameRate ?: 0f
                g.frameBudgetMs = if (fr > 1f) 1000f / fr else 33f
                g.govReset()
            }
            val par = if (videoSize.pixelWidthHeightRatio > 0f) videoSize.pixelWidthHeightRatio else 1f
            applyMediaSize(videoSize.width, videoSize.height, par)
        }

        override fun onCues(cueGroup: CueGroup) {
            val sb = StringBuilder()
            for (c in cueGroup.cues) {
                val t = c.text ?: continue
                if (sb.isNotEmpty()) sb.append('\n')
                sb.append(t.toString())
            }
            subtitleView.text = sb.toString()
            subtitleView.visibility = if (sb.isEmpty()) View.GONE else View.VISIBLE
        }

        override fun onTracksChanged(tracks: Tracks) {
            if (!isImage && tv == null) sizeFromTracks(tracks)
            val label = pendingSubLabel ?: return
            val p = player ?: return
            for (g in tracks.groups) {
                if (g.type != C.TRACK_TYPE_TEXT) continue
                for (i in 0 until g.length) {
                    if (g.getTrackFormat(i).label == label) {
                        pendingSubLabel = null
                        selectTextTrack(p, g, i)
                        return
                    }
                }
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            Toast.makeText(
                this@PlayerActivity,
                getString(R.string.player_error) + "\n" + (error.message ?: error.errorCodeName),
                Toast.LENGTH_LONG
            ).show()
            spinner.visibility = View.GONE
            setControlsVisible(true)
        }
    }

    private val scaleDetector by lazy {
        ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                zoomAt(zoom * d.scaleFactor, d.focusX, d.focusY, true)
                return true
            }
        })
    }

    private val gesture by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                onSingleTap(e.y)
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (isImage) {
                    // photos: double-tap zooms in at the finger (2.5x), or back to the whole picture
                    if (zoom > 1.05f) setZoom(1f) else zoomAt(2.5f, e.x, e.y, false)
                    return true
                }
                val w = root.width.toFloat()
                when {
                    e.x < w / 3f -> seekBy(-10_000L)
                    e.x > w * 2f / 3f -> seekBy(10_000L)
                    else -> togglePlay()
                }
                return true
            }

            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                // photos: swipe left = next, swipe right = previous (only when not zoomed in)
                if (!isImage || zoom > 1.01f || e1 == null || busy || swipeDone) return false
                val dx = e2.x - e1.x
                if (abs(vx) > 350f && abs(vx) > abs(vy) * 1.2f && abs(dx) > dp(this@PlayerActivity, 36)) {
                    swipeDone = true
                    step(if (dx < 0) 1 else -1)
                    return true
                }
                return false
            }

            override fun onLongPress(e: MotionEvent) {
                val p = player ?: return
                if (isImage || !p.isPlaying) return
                holding = true
                holdPrevSpeed = speed
                p.setPlaybackSpeed(2f)
                showHud("2×", sticky = true)
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
                if (zoom > 1.01f) {
                    // zoomed in: one finger pans instead of seeking / brightness / volume
                    // (measured on the fitted picture, not on the view: the view changes size while zooming)
                    val vwPx = fitW.coerceAtLeast(1f)
                    val vhPx = fitH.coerceAtLeast(1f)
                    zoomCx += distanceX / (vwPx * zoom)
                    zoomCy -= distanceY / (vhPx * zoom)
                    applyZoom()
                    return true
                }
                if (e1 == null || isImage) return false
                val p = player ?: return false
                val w = root.width.toFloat().coerceAtLeast(1f)
                val h = root.height.toFloat().coerceAtLeast(1f)
                val totalX = e2.x - e1.x
                val totalY = e2.y - e1.y
                if (gestureMode == 0) {
                    val slop = ViewConfiguration.get(this@PlayerActivity).scaledTouchSlop
                    if (abs(totalX) < slop && abs(totalY) < slop) return true
                    gestureMode = when {
                        abs(totalX) > abs(totalY) -> 1
                        e1.x < w / 2f -> 2
                        else -> 3
                    }
                    when (gestureMode) {
                        1 -> {
                            seekStartPos = p.currentPosition
                            seekTarget = seekStartPos
                        }
                        2 -> brightStart = currentBrightness()
                        3 -> volStart = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
                    }
                }
                when (gestureMode) {
                    1 -> {
                        val dur = p.duration
                        val upper = if (dur > 0) dur else Long.MAX_VALUE
                        seekTarget = (seekStartPos + (totalX / w * 120_000f).toLong()).coerceIn(0L, upper)
                        val diff = (seekTarget - seekStartPos) / 1000L
                        showHud(fmt(seekTarget) + "  (" + String.format(Locale.US, "%+d", diff) + " s)")
                    }
                    2 -> {
                        val v = (brightStart - totalY / (h * 0.8f)).coerceIn(0.02f, 1f)
                        setBrightness(v)
                        showHud(getString(R.string.player_brightness_fmt, (v * 100).roundToInt()))
                    }
                    3 -> {
                        val maxV = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        val v = (volStart + (-totalY / (h * 0.8f)) * maxV).roundToInt().coerceIn(0, maxV)
                        audio.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0)
                        showHud(getString(R.string.player_volume_fmt, if (maxV > 0) v * 100 / maxV else 0))
                    }
                }
                return true
            }
        })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Cfg.bind(this, "video")
        Ui.init(this, forceDark = true) // the player sits on black: always the dark colours
        tapPlays = prefs.getBoolean("tapPlays", true)
        aspectMode = prefs.getInt("aspectMode", 0).coerceIn(0, 5) // an old "fill" setting is dropped on purpose: it made landscape videos look zoomed in portrait
        subSize = prefs.getInt("subSize", 18).coerceIn(12, 36)
        if (prefs.contains("rot") && !prefs.contains("rot_axis")) {
            // older 5-state setting -> the new axis / lock / free settings
            val old = prefs.getInt("rot", 0)
            prefs.edit()
                .putInt("rot_axis", when (old) { 1 -> 0; 2 -> 1; else -> -1 })
                .putBoolean("rot_free", old == 3)
                .putBoolean("rot_lock", old == 4)
                .remove("rot")
                .apply()
        }
        // the kind of the first media decides which direction setting is read (photo / video), so a photo does not open
        // in the video's direction first and turn afterwards
        intent?.data?.let { first -> isImage = mimeOf(first).startsWith("image/"); shapeHint = probeShape(first) }
        loadRotation()
        requestedOrientation = wantedOrientation() // the right direction from the very first frame (no horizontal flash for a vertical file)
        dl("onCreate")
        volumeControlStream = AudioManager.STREAM_MUSIC

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.setDecorFitsSystemWindows(false)
        window.attributes = window.attributes.also {
            it.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        stage = FrameLayout(this)
        stage.addOnLayoutChangeListener { v, _, _, _, _, _, _, _, _ ->
            // rotation / split screen: rebuild the picture view for the new size (once the layout is final)
            if (vw > 0 && vh > 0 && tv != null && (v.width != builtStageW || v.height != builtStageH)) {
                ui.post { if (!isDestroyed && vw > 0 && vh > 0 && (stage.width != builtStageW || stage.height != builtStageH)) rebuildView() }
            }
        }
        root.addView(stage, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        // a still picture of the video's start spot shown until the first real frame is drawn (instead of a black screen)
        poster = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER; visibility = View.GONE; isClickable = false; isFocusable = false }
        root.addView(poster, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    swipeDownX = ev.x; swipeDownY = ev.y; swipeDone = false; swipeMulti = false
                }
                MotionEvent.ACTION_POINTER_DOWN -> swipeMulti = true
                MotionEvent.ACTION_UP -> {
                    val dx = ev.x - swipeDownX
                    val dy = ev.y - swipeDownY
                    if (isImage && !swipeDone && !swipeMulti && !pinching && zoom <= 1.01f && !busy &&
                        abs(dx) > dp(this, 48) && abs(dx) > abs(dy) * 1.2f
                    ) {
                        swipeDone = true
                        step(if (dx < 0) 1 else -1)
                    }
                }
            }
            scaleDetector.onTouchEvent(ev)
            if ((ev.pointerCount > 1 || scaleDetector.isInProgress) && !pinching) {
                // second finger: switch from the one-finger gestures to pinch zoom
                pinching = true
                val c = MotionEvent.obtain(ev)
                c.action = MotionEvent.ACTION_CANCEL
                gesture.onTouchEvent(c)
                c.recycle()
                gestureMode = 0
                endGesture()
            }
            if (!pinching) gesture.onTouchEvent(ev)
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                endGesture()
                pinching = false
            }
            true
        }

        // ---- subtitles
        subtitleView = TextView(this).apply {
            visibility = View.GONE
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            setTextColor(Color.WHITE)
            setShadowLayer(6f, 0f, 0f, Color.BLACK)
            setBackgroundColor(Color.parseColor("#66000000"))
            setPadding(dp(this@PlayerActivity, 8), dp(this@PlayerActivity, 2), dp(this@PlayerActivity, 8), dp(this@PlayerActivity, 2))
            textSize = subSize.toFloat()
        }
        root.addView(
            subtitleView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
                bottomMargin = dp(this@PlayerActivity, 36)
                leftMargin = dp(this@PlayerActivity, 24)
                rightMargin = dp(this@PlayerActivity, 24)
            }
        )

        // ---- top bar: title + FX on/off + rotation + settings + menu
        titleView = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setShadowLayer(6f, 0f, 0f, Color.BLACK)
        }
        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        topBar.addView(
            titleView,
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(this@PlayerActivity, 8) }
        )
        fxBtn = topButton("FX") { setFx(!fxEffective()) }
        installHoldCompare(fxBtn)
        topBar.addView(fxBtn)
        zoomBtn = topButton("1×") { cycleZoom() }.apply { textSize = 14f }
        topBar.addView(zoomBtn) // the zoom step button stays on the top bar (1× / 2× / 4× / 8×), not hidden in the tools menu
        // zoom / screenshot / rotation / lock / free rotation / edit video live behind ONE tools button (less clutter on the picture);
        // the old buttons stay as hidden objects so their state painting keeps working
        shotBtn = topButton("📷") { videoShot() }
        rotBtn = topButton("↔") { showDirPicker() }
        toolsBtn = iconTop(Icons.EDIT) { showToolsMenu() }
        topBar.addView(toolsBtn)
        paintRot()
        miniHud = TextView(this).apply {
            textSize = 11f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(this@PlayerActivity, 10), dp(this@PlayerActivity, 3), dp(this@PlayerActivity, 10), dp(this@PlayerActivity, 3))
            background = Ui.round(Color.parseColor("#80000000"), dp(this@PlayerActivity, 10).toFloat())
            visibility = View.GONE
        }
        root.addView(
            miniHud,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
                topMargin = dp(this@PlayerActivity, 64)
            }
        )
        volBtn = iconTop(Icons.VOLUME) { toggleVolPanel() }
        topBar.addView(volBtn)
        topBar.addView(iconTop(Icons.GEAR) { togglePanel() })
        topBar.addView(iconTop(Icons.MORE) { showMoreMenu() })
        root.addView(
            topBar,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP).apply {
                val m = dp(this@PlayerActivity, 12)
                setMargins(m, dp(this@PlayerActivity, 4), m, 0)
            }
        )
        buildVolPanel()
        paintFx()

        // ---- centre HUD + buffering spinner
        hud = TextView(this).apply {
            visibility = View.GONE
            setTextColor(Color.WHITE)
            textSize = 20f
            gravity = Gravity.CENTER
            background = Ui.round(Color.parseColor("#B30B1020"), dp(this@PlayerActivity, 14).toFloat())
            setPadding(dp(this@PlayerActivity, 18), dp(this@PlayerActivity, 10), dp(this@PlayerActivity, 18), dp(this@PlayerActivity, 10))
        }
        root.addView(hud, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        autoChip = TextView(this).apply {
            visibility = View.GONE
            setTextColor(Color.parseColor("#E6FFFFFF"))
            textSize = 11f
            maxLines = 2
            background = Ui.round(Color.parseColor("#990B1020"), dp(this@PlayerActivity, 10).toFloat())
            setPadding(dp(this@PlayerActivity, 10), dp(this@PlayerActivity, 5), dp(this@PlayerActivity, 10), dp(this@PlayerActivity, 5))
        }
        root.addView(autoChip, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.START).apply {
            marginStart = dp(this@PlayerActivity, 14)
            bottomMargin = dp(this@PlayerActivity, 100)
        })
        spinner = ProgressBar(this).apply {
            visibility = View.GONE
            indeterminateTintList = ColorStateList.valueOf(Ui.ACCENT)
        }
        root.addView(spinner, FrameLayout.LayoutParams(dp(this, 48), dp(this, 48), Gravity.CENTER))

        // ---- bottom bar: seek row + button row
        bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            isClickable = true
            // stuck to the bottom edge (and the sides): only the top corners are round
            val rr = dp(this@PlayerActivity, 14).toFloat()
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.parseColor("#E60B1020"))
                cornerRadii = floatArrayOf(rr, rr, rr, rr, 0f, 0f, 0f, 0f)
            }
            setPadding(dp(this@PlayerActivity, 10), dp(this@PlayerActivity, 4), dp(this@PlayerActivity, 10), dp(this@PlayerActivity, 6))
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        curText = Ui.text(this, "0:00", 11f, Ui.MUTED)
        durText = Ui.text(this, "0:00", 11f, Ui.MUTED)
        seek = SeekBar(this).apply {
            max = 1000
            val tint = ColorStateList.valueOf(Ui.ACCENT)
            progressTintList = tint
            thumbTintList = tint
            progressBackgroundTintList = ColorStateList.valueOf(Ui.STROKE)
            secondaryProgressTintList = ColorStateList.valueOf(Ui.MUTED)
        }
        seekRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        seekRow.addView(curText)
        // a slim slider: fixed row height, small thumb, no extra touch padding around it
        seek.setPadding(dp(this, 8), 0, dp(this, 8), 0)
        seekRow.addView(seek, LinearLayout.LayoutParams(0, dp(this, 24), 1f).apply {
            marginStart = dp(this@PlayerActivity, 2)
            marginEnd = dp(this@PlayerActivity, 2)
        })
        seekRow.addView(durText)
        bar.addView(seekRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(this, 26)))
        videoOnly.add(seekRow)

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val b1 = barButton("−10") { seekBy(-10_000L) }
        playBtn = barButton("") { togglePlay() }
        Icons.glyphCentered(playBtn, Icons.PLAY, Ui.TEXT, 22)
        val b3 = barButton("+10") { seekBy(10_000L) }
        speedBtn = barButton("1×") { showSpeedMenu() }
        val b5 = barButton("CC") { showTrackMenu(C.TRACK_TYPE_TEXT) }
        val b6 = barButton("") { showTrackMenu(C.TRACK_TYPE_AUDIO) }
        Icons.glyphCentered(b6, Icons.MUSIC, Ui.TEXT, 20)
        val vPrev = barButton("") { step(-1) }
        Icons.glyphCentered(vPrev, Icons.PREV, Ui.TEXT, 20)
        val vNext = barButton("") { step(1) }
        Icons.glyphCentered(vNext, Icons.NEXT, Ui.TEXT, 20)
        for (b in listOf(vPrev, b1, playBtn, b3, vNext, speedBtn, b5, b6)) {
            if (b === vPrev || b === vNext) (b.layoutParams as LinearLayout.LayoutParams).weight = 0.8f
            buttons.addView(b)
            videoOnly.add(b)
        }
        navViews.add(vPrev)
        navViews.add(vNext)
        // photo tools (shown instead of the video buttons when a photo is open)
        val i1 = barButton(getString(R.string.img_enhance)) { showEnhanceMenu() }
        val i2 = barButton(getString(R.string.img_save)) { showSaveMenu() }
        val i3 = barButton(getString(R.string.img_original)) { restoreOriginal() }
        val iPrev = barButton("◀") { step(-1) }
        val iNext = barButton("▶") { step(1) }
        for (b in listOf(iPrev, i1, i2, i3, iNext)) {
            if (b === iPrev || b === iNext) (b.layoutParams as LinearLayout.LayoutParams).weight = 0.6f
            b.visibility = View.GONE
            buttons.addView(b)
            imageOnly.add(b)
        }
        navViews.add(iPrev)
        navViews.add(iNext)
        bar.addView(buttons, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(this@PlayerActivity, 2)
        })
        root.addView(
            bar,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
        )

        // ---- settings panel (built on first open)
        panel = FadePanel(this).apply {
            visibility = View.GONE
            isClickable = true
            background = Ui.round(Color.parseColor("#F5101522"), dp(this@PlayerActivity, 22).toFloat(), Ui.STROKE, dp(this@PlayerActivity, 1))
            setPadding(dp(this@PlayerActivity, 16), dp(this@PlayerActivity, 14), dp(this@PlayerActivity, 16), dp(this@PlayerActivity, 14))
        }
        panel.onTouch = { schedulePanelIdle() }
        root.addView(panel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    val d = if (streamJob) ExportState.totalUs / 1000L else player?.duration ?: 0L
                    if (d > 0) curText.text = fmt(p.toLong() * d / 1000L)
                }
            }

            override fun onStartTrackingTouch(s: SeekBar) {
                dragging = true
                ui.removeCallbacks(hideRunnable)
            }

            override fun onStopTrackingTouch(s: SeekBar) {
                if (streamJob) {
                    val total = ExportState.totalUs / 1000L
                    if (total > 0) streamSeek(s.progress.toLong() * total / 1000L)
                } else {
                    val d = player?.duration ?: 0L
                    if (d > 0) player?.seekTo(s.progress.toLong() * d / 1000L)
                }
                dragging = false
                gl?.redraw()
                scheduleHide()
            }
        })

        setContentView(root)
        root.post { applyInsets() }
        // the status bar pulled in for a moment (clock, battery ...) moves the bars away from the edge; they go back when it leaves
        root.setOnApplyWindowInsetsListener { _, ins ->
            if (::topBar.isInitialized && ::bar.isInitialized) applyInsets(ins)
            ins
        }
        Edge.watchBars(this, root)
        // the phone's status bar pulled in for a moment: the top bar slides down out from under the clock and comes back after
        barWatch = Edge.TransientBars(this, root) { on ->
            topBar.animate().cancel()
            topBar.animate().translationY(if (on) barWatch.barHeight().toFloat() else 0f).setDuration(220)
                .setInterpolator(android.view.animation.DecelerateInterpolator()).start()
        }

        AudioCfg.load(this)
        // a video and the music player do not play together, unless asked; a photo never stops the music
        if (!isImage && !AudioCfg.keepMusic) MusicPlayer.player?.pause()
        val p = ExoPlayer.Builder(this, audioFxRenderersFactory(this))
            .setMediaSourceFactory(androidx.media3.exoplayer.source.DefaultMediaSourceFactory(RoutingDataSourceFactory(this)))
            .setHandleAudioBecomingNoisy(true) // headphones pulled out (wired or Bluetooth) = pause
            .build()
        p.addListener(playerListener)
        p.addAnalyticsListener(object : AnalyticsListener {
            override fun onDroppedVideoFrames(eventTime: AnalyticsListener.EventTime, droppedFrames: Int, elapsedMs: Long) {
                if (Cfg.smoothLive && droppedFrames >= 4 && !isImage && !plainView && !streamJob) gl?.govBump()
                if (!(Cfg.autoMode || BudgetAuto.active()) || isImage || plainView || streamJob || droppedFrames < 6) return
                val now = SystemClock.elapsedRealtime()
                if (now - lastAutoDown < 6000L || Cfg.profileBudget <= Profiles.PERF) return
                if (lastAutoUp > 0L && now - lastAutoUp < 40_000L) autoNoRaise = true // the step given back was too much
                lastAutoDown = now
                ui.post { if (Cfg.autoMode) autoCap(Cfg.profileBudget - 1) else { autoBudgetCap = (Cfg.profileBudget - 1).coerceIn(Profiles.PERF, Profiles.QUALITY); applyBudgetAuto() } }
            }
        })
        player = p
        AudioOut.apply(this, p)
        applyVideoVolume()
        runCatching { (getSystemService(AUDIO_SERVICE) as AudioManager).registerAudioDeviceCallback(audioDevCb, ui) }
        if (!isImage) startSession()

        fromLibrary = intent?.getBooleanExtra(PlayerArgs.FROM_LIB, false) == true
        val d = intent?.data
        val list = intent?.getStringArrayListExtra(PlayerArgs.LIST)
        if (d != null && intent?.getBooleanExtra(PlayerArgs.STREAM, false) == true) {
            streamJob = true
            ExportState.segs.firstOrNull { Uri.fromFile(it.file) == d }?.let { streamItems.add(it) }
            playlist.add(d)
            playIndex = 0
            open(d, keepList = true, plain = true)
            ui.postDelayed(streamTick, 700)
        } else if (d != null && list != null && list.size > 1) {
            playlist.addAll(list.map { Uri.parse(it) })
            playIndex = intent.getIntExtra(PlayerArgs.INDEX, 0).coerceIn(0, playlist.size - 1)
            open(d, keepList = true)
        } else if (d != null) open(d) else showSourceDialog(cancelFinishes = true)
    }

    private fun barButton(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 14f
        gravity = Gravity.CENTER
        setTextColor(Ui.TEXT)
        background = Ui.round(Ui.CHIP, dp(this@PlayerActivity, 10).toFloat())
        setPadding(dp(this@PlayerActivity, 4), 0, dp(this@PlayerActivity, 4), 0)
        maxLines = 1
        layoutParams = LinearLayout.LayoutParams(0, dp(this@PlayerActivity, 38), 1f).apply {
            marginStart = dp(this@PlayerActivity, 3)
            marginEnd = dp(this@PlayerActivity, 3)
        }
        setOnClickListener {
            onClick()
            if (this !== playBtn) scheduleHide()
        }
    }

    /** Top-bar button drawn with the app's line icons (matches the rest of the app). */
    private fun iconTop(kind: Int, onClick: () -> Unit): ImageView = ImageView(this).apply {
        setImageDrawable(LineIcon(kind, Ui.TEXT))
        val p = dp(this@PlayerActivity, 8)
        setPadding(p, p, p, p)
        background = Ui.round(Color.parseColor("#B30B1020"), dp(this@PlayerActivity, 10).toFloat())
        layoutParams = LinearLayout.LayoutParams(dp(this@PlayerActivity, 42), dp(this@PlayerActivity, 38)).apply {
            marginStart = dp(this@PlayerActivity, 6)
        }
        setOnClickListener {
            onClick()
            scheduleHide()
        }
    }

    private fun topButton(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 15f
        gravity = Gravity.CENTER
        setTextColor(Ui.TEXT)
        background = Ui.round(Color.parseColor("#B30B1020"), dp(this@PlayerActivity, 10).toFloat())
        layoutParams = LinearLayout.LayoutParams(dp(this@PlayerActivity, 42), dp(this@PlayerActivity, 38)).apply {
            marginStart = dp(this@PlayerActivity, 6)
        }
        setOnClickListener {
            onClick()
            scheduleHide()
        }
    }

    // ---- choosing what to play ----------------------------------------------------------------

    private fun showSourceDialog(cancelFinishes: Boolean) {
        val items = arrayOf(getString(R.string.player_open_file), getString(R.string.player_open_link))
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.player_button))
            .setItems(items) { _, which -> if (which == 0) pickFile() else showLinkDialog(cancelFinishes) }
            .setOnCancelListener { if (cancelFinishes && !hasMedia) finish() }
            .show()
    }

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*")
            .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("video/*", "audio/*", "image/*"))
        @Suppress("DEPRECATION")
        startActivityForResult(i, REQ_PICK)
    }

    private fun pickSubtitle() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*")
        @Suppress("DEPRECATION")
        startActivityForResult(i, REQ_SUB)
    }

    private fun showLinkDialog(cancelFinishes: Boolean) {
        val input = EditText(this).apply {
            hint = "https://…"
            setSingleLine()
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            val clip = runCatching {
                getSystemService(ClipboardManager::class.java).primaryClip?.getItemAt(0)?.text?.toString()
            }.getOrNull()
            if (clip != null && (clip.startsWith("http://") || clip.startsWith("https://"))) setText(clip.trim())
        }
        val pad = dp(this, 20)
        val box = FrameLayout(this).apply { setPadding(pad, dp(this@PlayerActivity, 8), pad, 0) }
        box.addView(input, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.player_open_link))
            .setView(box)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val t = input.text.toString().trim()
                if (t.startsWith("http://") || t.startsWith("https://")) {
                    open(Uri.parse(t))
                } else {
                    Toast.makeText(this, getString(R.string.player_error), Toast.LENGTH_SHORT).show()
                    if (cancelFinishes && !hasMedia) finish()
                }
            }
            .setNegativeButton(android.R.string.cancel) { _, _ -> if (cancelFinishes && !hasMedia) finish() }
            .setOnCancelListener { if (cancelFinishes && !hasMedia) finish() }
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (ModelFiles.handle(this, req, res, data)) return
        if (TrashOps.handleResult(req, res)) return
        val u = data?.data
        when (req) {
            REQ_PICK -> if (res == RESULT_OK && u != null) open(u) else if (!hasMedia) finish()
            REQ_SUB -> if (res == RESULT_OK && u != null) addSubtitle(u)
            REQ_MODEL -> if (res == RESULT_OK && u != null) importModel(u)
        }
    }

    // ---- opening media ------------------------------------------------------------------------

    private fun mimeOf(u: Uri): String {
        val t = runCatching { contentResolver.getType(u) }.getOrNull()
        if (!t.isNullOrEmpty()) return t
        val ext = MimeTypeMap.getFileExtensionFromUrl(u.toString()).lowercase(Locale.US)
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: ""
    }

    private fun displayName(u: Uri): String {
        if (u.scheme == "content") {
            runCatching {
                contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val n = c.getString(0)
                        if (!n.isNullOrEmpty()) return n
                    }
                }
            }
        }
        return u.lastPathSegment ?: u.toString()
    }

    private fun open(u: Uri, keepList: Boolean = false, plain: Boolean = false) {
        closeMedia()
        AudioCfg.syncMs = 0 // a new file starts with its own sound in sync
        plainView = plain
        hasMedia = true
        currentUri = u
        if (!mimeOf(u).startsWith("image/") && (rotAxis >= 0 || rotFree || rotManual >= 0 || rotLock)) { // a new video follows its own shape again (photos keep the chosen direction)
            rotAxis = -1
            rotFree = false
            rotManual = -1
            rotLock = false // an old lock must not hold a NEW video in the direction of the one before
            paintRot()
        }
        // the shape of the new file is read first, so the screen is turned BEFORE the picture is built (and closeMedia() does not leave it free)
        shapeHint = probeShape(u)
        if (shapeHint != 0) requestedOrientation = wantedOrientation()
        dl("open")
        val wasImage = isImage
        isImage = mimeOf(u).startsWith("image/")
        if (!isImage && !AudioCfg.keepMusic) MusicPlayer.player?.pause()
        applyVideoVolume()
        if (isImage != wasImage) {
            // photos and videos each keep their own screen direction (photos are often portrait, videos landscape)
            loadRotation()
            applyRotation()
            paintRot()
        }
        // photos and videos each keep their own effect settings
        val sec = if (isImage) "photo" else "video"
        if (Cfg.section != sec) {
            Cfg.bind(this, sec)
            syncFx()
            if (panelBuilt) {
                panel.removeAllViews()
                panelBuilt = false
            }
            if (::panel.isInitialized) layoutPanel() // each kind of media has its own panel size
        }
        if (!keepList) {
            playlist.clear()
            playIndex = -1
        }
        autoBudgetCap = Profiles.QUALITY
        pendingBudgetApply = true
        lastAutoUp = 0L
        autoNoRaise = false
        titleView.text = displayName(u)
        updateTitle()
        for (v in videoOnly) v.visibility = if (isImage) View.GONE else View.VISIBLE
        for (v in imageOnly) v.visibility = if (isImage) View.VISIBLE else View.GONE
        for (v in panelVideoOnly) v.visibility = if (isImage) View.GONE else View.VISIBLE
        ControlsBus.mediaIsPhoto = isImage
        for (v in ControlsBus.photoOnly) v.visibility = if (isImage) View.VISIBLE else View.GONE // the "AI-upscale small photos" switch: photos only
        setControlsVisible(true)
        updateTitle() // after the visibility loops above: shows previous / next only when a playlist exists
        if (isImage) openImage(u) else startPlayback(u)
        if (!keepList) findSiblings(u)
    }

    /** "Open with" / picked files: look for the other files of the same type in the same folder (best effort). */
    private fun findSiblings(u: Uri) {
        val wantImage = isImage
        Thread {
            val r = Media.siblings(this, u, wantImage)
            ui.post {
                if (isDestroyed || currentUri != u || r == null) return@post
                playlist.clear()
                playlist.addAll(r.first)
                playIndex = r.second
                updateTitle()
            }
        }.start()
    }

    private fun updateTitle() {
        val base = currentUri?.let { displayName(it) } ?: ""
        titleView.text = if (playlist.size > 1 && playIndex >= 0) "$base  (${playIndex + 1}/${playlist.size})" else base
        val show = if (playlist.size > 1) View.VISIBLE else View.GONE
        // previous / next only appear when there is something to step to (and only for the current media type)
        for (v in navViews) {
            val photoBtn = imageOnly.contains(v)
            v.visibility = if (photoBtn == isImage) show else View.GONE
        }
    }

    private val streamTick = object : Runnable {
        override fun run() {
            if (isDestroyed || !streamJob) return
            syncStream()
            ui.postDelayed(this, 700)
        }
    }

    /**
     * Streaming upscale: tells the worker which spot of the video is being watched (so it knows how far ahead to go
     * and what it may delete), keeps the playlist equal to the pieces that exist, and moves on to a piece that was
     * not ready yet when the previous one ended.
     */
    private fun streamOriginUs(): Long = ExportState.job?.rangeStartUs ?: 0L

    private fun curSeg(): ExportSeg? = player?.let { streamItems.getOrNull(it.currentMediaItemIndex) }

    /** Where the viewer is in the whole video (or the chosen part), in ms. */
    private fun streamPosMs(): Long {
        val p = player ?: return 0L
        if (pendingSeekUs >= 0L) return (pendingSeekUs - streamOriginUs()) / 1000L // waiting for a spot: relative jumps start from THAT spot
        val seg = curSeg() ?: return 0L
        return (seg.startUs - streamOriginUs()) / 1000L + p.currentPosition
    }

    /** End (microseconds of the whole video) of the unbroken run of pieces that is in the player now. */
    private fun streamReadyEndUs(): Long = streamItems.lastOrNull()?.let { it.startUs + it.durUs } ?: 0L

    /** True when the last piece of the playlist is playing and it is the end of the video (or of the chosen part). */
    private fun streamAtVideoEnd(): Boolean {
        val p = player ?: return true
        val total = ExportState.totalUs
        return total > 0 && streamReadyEndUs() >= streamOriginUs() + total - 500_000L && p.currentMediaItemIndex >= streamItems.size - 1
    }

    private fun mediaItemOf(seg: ExportSeg): MediaItem = MediaItem.Builder().setUri(Uri.fromFile(seg.file)).build()

    /** [seg] and the pieces that follow it without a gap. */
    private fun runFrom(seg: ExportSeg): List<ExportSeg> {
        val l = arrayListOf(seg)
        var cur = seg
        while (true) {
            val n = segAt(cur.startUs + cur.durUs, 400_000L) ?: break
            if (n === cur || n in l) break
            l.add(n)
            cur = n
        }
        return l
    }

    /** The finished piece that covers [us] (microseconds of the whole video), if there is one. */
    private fun segAt(us: Long, tolUs: Long = 0L): ExportSeg? =
        ExportState.segs.filter { it.startUs <= us + tolUs && us < it.startUs + it.durUs }.maxByOrNull { it.startUs }

    /** Jumps to [relMs] of the timeline: inside a finished piece at once, otherwise the worker is asked to prepare that spot. */
    private fun streamSeek(relMs: Long) {
        val total = ExportState.totalUs / 1000L
        // (the very end itself is covered by no piece: one ms before it)
        val t = relMs.coerceIn(0L, if (total > 0) total - 1L else Long.MAX_VALUE) * 1000L + streamOriginUs()
        ExportState.playUs = t
        waitSince = 0L
        stopWanted = false
        seekAsked = true // a jump asks for its spot at once (below), when no finished piece covers it
        val seg = segAt(t)
        if (seg != null) {
            pendingSeekUs = -1L
            hudHide.run()
            playSeg(seg, (t - seg.startUs) / 1000L)
        } else if (ExportState.job?.stream != true) {
            toast(R.string.stream_not_ready) // a file export works from the start to the end: only finished parts can be played
        } else {
            pendingSeekUs = t
            ExportState.seekReq = t
            player?.pause()
            spinner.visibility = View.VISIBLE
        }
    }

    /**
     * Plays [seg] from [atMs]. Inside the pieces already in the player's playlist this is a plain seek; otherwise the playlist is
     * replaced (the picture view is NOT rebuilt, so there is no black flash). Only the very first piece opens the view.
     */
    private fun playSeg(seg: ExportSeg, atMs: Long) {
        val p = player ?: return
        val idx = streamItems.indexOf(seg)
        if (hasMedia && idx >= 0) {
            p.seekTo(idx, atMs)
            p.play()
        } else if (hasMedia) {
            val run = runFrom(seg)
            streamItems.clear()
            streamItems.addAll(run)
            p.setMediaItems(run.map { mediaItemOf(it) }, 0, atMs)
            p.prepare()
            p.play()
        } else {
            streamItems.clear()
            streamItems.add(seg)
            startAtMs = atMs
            playIndex = 0
            open(Uri.fromFile(seg.file), keepList = true, plain = !streamFxOn())
        }
        gl?.redraw()
    }

    /** When waiting for pieces: how much must be ready ahead (ms). A phone at least as fast as the video starts at the first piece. */
    private fun streamNeedMs(): Long {
        val sp = ExportState.speed
        val want = if (sp <= 0f || sp >= 1.3f) 1000L else (10_000f / sp).toLong().coerceIn(6_000L, 40_000L)
        // the work never gets further ahead than the "keep ahead" setting (or 30 s when the phone is nearly full): never wait for more
        val a = getSharedPreferences("crsc", Context.MODE_PRIVATE).getInt("stream_ahead_s", 0)
        val low = runCatching { filesDir.usableSpace < 400L * 1024 * 1024 }.getOrDefault(false)
        val mb = getSharedPreferences("crsc", Context.MODE_PRIVATE).getInt("stream_space_mb", 600)
        val cap = if (low) 24_000L else if (mb in 1..150) 12_000L else if (a > 0) a * 800L else 48_000L
        return minOf(want, cap)
    }

    private var slowHinted = false

    private var waitSince = 0L
    private var seekAsked = false
    private var stuckTicks = 0

    /** Where the work is in the whole video (microseconds), as last reported. */
    private fun streamWorkUs(): Long = (ExportState.job?.rangeStartUs ?: 0L) + ExportState.doneUs

    private fun syncStream() {
        val p = player ?: return
        val done = ExportState.result
        if (!ExportState.running && done != null && ExportState.job?.stream != true) {
            // the file export finished while it was watched: go on in the finished file at the same spot
            val pos = streamPosMs()
            val fxWasOn = streamFxOn() // (read before streamJob changes)
            streamJob = false
            streamItems.clear()
            pendingSeekUs = -1L
            startAtMs = pos
            // the finished file is the same picture as the pieces: only shown, unless the person had switched the live effects on for it
            noSavePos = true // closing the last piece must not write "resume here" for a temporary file
            try { open(done, plain = !fxWasOn) } finally { noSavePos = false }
            return
        }
        // the work has stopped (cancelled, failed or finished) while the player waits for a spot nobody is preparing any more
        if (!ExportState.running && ExportState.job?.stream == true && pendingSeekUs >= 0L && segAt(pendingSeekUs, 400_000L) == null) {
            pendingSeekUs = -1L
            waitSince = 0L
            seekAsked = false
            spinner.visibility = View.GONE
            hudHide.run()
            toast(R.string.stream_job_ended)
            return
        }
        val segsNow = ExportState.segs.sortedBy { it.startUs }
        if (segsNow.isEmpty()) return
        // once: the phone is clearly slower than the video at this size, so the person knows why it waits now and then
        if (!slowHinted && ExportState.speed in 0.05f..0.8f && segsNow.size >= 8) {
            slowHinted = true
            Toast.makeText(this, getString(R.string.stream_slow_hint_fmt, ExportState.speed), Toast.LENGTH_LONG).show()
        }
        // the title / counter follows the pieces
        val uris = segsNow.map { Uri.fromFile(it.file) }
        if (uris != playlist.toList()) {
            playlist.clear()
            playlist.addAll(uris)
            playIndex = curSeg()?.let { segsNow.indexOf(it) }?.coerceAtLeast(0) ?: playIndex.coerceIn(0, uris.size - 1)
            updateTitle()
        }
        // waiting for a spot the worker is preparing
        if (pendingSeekUs >= 0L) {
            stuckTicks = 0
            val nowMs = SystemClock.elapsedRealtime()
            if (waitSince == 0L) waitSince = nowMs
            val seg = segAt(pendingSeekUs, 400_000L)
            if (seg == null && !seekAsked && nowMs - waitSince > 4_000L) {
                // nothing covers the spot and the work is not coming here by itself: ask for it
                seekAsked = true
                ExportState.seekReq = pendingSeekUs
            }
            if (seg != null) {
                val t = pendingSeekUs
                // a phone that is slower than the video must build a head start first: play-one-second / stop-one-second is worse
                // than one longer wait followed by smooth playing (45 s at most)
                val run = runFrom(seg)
                val endUs = run.last().startUs + run.last().durUs
                val aheadMs = (endUs - t) / 1000L
                val total = ExportState.totalUs
                val toTheEnd = total > 0 && endUs >= streamOriginUs() + total - 500_000L
                val need = streamNeedMs()
                if (aheadMs >= need || toTheEnd || nowMs - waitSince > 45_000L) {
                    waitSince = 0L
                    seekAsked = false
                    pendingSeekUs = -1L
                    hudHide.run()
                    playSeg(seg, ((t - seg.startUs) / 1000L).coerceAtLeast(0L))
                    if (stopWanted) {
                        stopWanted = false // stopped while it was preparing: the picture is there, paused, at the spot
                        player?.pause()
                        setPlayIcon(false)
                    }
                } else {
                    player?.pause()
                    spinner.visibility = View.VISIBLE
                    setPlayIcon(!stopWanted)
                    showHud(getString(R.string.stream_preparing_fmt, aheadMs / 1000f, need / 1000f) + (if (stopWanted) "\n" + getString(R.string.stream_wait_stopped_short) else ""), true)
                }
            }
            return
        }
        // first piece: start playing it
        if (!hasMedia || streamItems.isEmpty()) {
            val at = ExportState.playUs
            val back = if (at >= 0L) segAt(at) else null
            if (back != null) {
                // coming back to a streaming job that was left: go on at the spot that was watched
                playSeg(back, ((at - back.startUs) / 1000L).coerceAtLeast(0L))
            } else {
                val first = segsNow[0]
                ExportState.playUs = first.startUs
                playSeg(first, 0L)
            }
            return
        }
        // 1) pieces that the worker deleted (far behind the viewer) leave the playlist; the one that plays now never does
        val now = curSeg()
        for (i in streamItems.indices.reversed()) {
            val it = streamItems[i]
            if (it !== now && it !in segsNow) {
                p.removeMediaItem(i)
                streamItems.removeAt(i)
            }
        }
        // 2) pieces that were finished meanwhile are put at the end of the playlist: the player goes on by itself, without a gap
        var last = streamItems.lastOrNull() ?: return
        while (true) {
            val n = segAt(last.startUs + last.durUs, 400_000L) ?: break
            if (n === last || n in streamItems) break
            p.addMediaItem(mediaItemOf(n))
            streamItems.add(n)
            last = n
        }
        curSeg()?.let { ExportState.playUs = it.startUs + p.currentPosition * 1000L }
        // 3) the player reached the end of what was ready: go on with the next piece, or ask the worker for the spot
        if (p.playbackState == Player.STATE_ENDED) {
            val idx = p.currentMediaItemIndex
            if (idx < streamItems.size - 1) {
                p.seekTo(idx + 1, 0L)
                p.play()
            } else if (!streamAtVideoEnd()) {
                val endUs = streamReadyEndUs()
                pendingSeekUs = endUs
                ExportState.playUs = endUs
                waitSince = 0L
                // the work is usually right there, making the next piece: do not make it throw its place away and start again
                val w = streamWorkUs()
                val near = w >= endUs - 1_500_000L && w <= endUs + 20_000_000L
                seekAsked = !near
                if (!near) ExportState.seekReq = endUs
                spinner.visibility = View.VISIBLE
            }
            return
        }
        // 4) watchdog: it should be playing but is not (and it is not just waiting for the work): put it back at the very same spot
        val wantsPlay = p.playWhenReady && p.playbackSuppressionReason == Player.PLAYBACK_SUPPRESSION_REASON_NONE
        val finished = p.playbackState == Player.STATE_ENDED && streamAtVideoEnd()
        if (wantsPlay && !p.isPlaying && p.playbackState != Player.STATE_BUFFERING && !finished && !dragging) stuckTicks++ else stuckTicks = 0
        if (stuckTicks >= 3) {
            stuckTicks = 0
            val t = if (p.playbackState == Player.STATE_ENDED) streamReadyEndUs() else streamPosMs() * 1000L + streamOriginUs()
            val seg = segAt(t, 400_000L)
            if (seg != null) playSeg(seg, ((t - seg.startUs) / 1000L).coerceAtLeast(0L)) else {
                pendingSeekUs = t
                waitSince = 0L
                seekAsked = false
            }
        }
    }

    // ---- save what a streaming upscale has prepared -------------------------------------------------

    /** Joins the pieces that exist now into video file(s) in Movies/ClearOverlay, then runs [then]. */
    private fun saveStreamReady(then: (() -> Unit)? = null) {
        if (ExportState.segs.isEmpty()) {
            Toast.makeText(this, R.string.stream_nothing, Toast.LENGTH_SHORT).show()
            then?.invoke()
            return
        }
        ExportState.saving = true // no piece is deleted while they are joined
        val dlg = AlertDialog.Builder(this).setMessage(R.string.stream_saving).setCancelable(false).show()
        Thread {
            val files = runCatching { ExportState.saveReady(this) }.getOrDefault(emptyList())
            ui.post {
                runCatching { dlg.dismiss() }
                Toast.makeText(this, if (files.isEmpty()) getString(R.string.stream_save_failed) else getString(R.string.stream_saved_fmt, files.size), Toast.LENGTH_LONG).show()
                then?.invoke()
            }
        }.start()
    }

    /** True when the person chose to stop the preparing and delete what was prepared (only then is the work cancelled when the player closes). */
    private var discardStreamOnExit = false

    /**
     * Leaving a streaming upscale (Watch now / Smooth live). Four ways out: leave the video and keep preparing in the background (the default
     * of the first line: nothing is cancelled, the export screen goes on showing it and "Watch" comes back to the same spot), save what is
     * ready and leave, stop and delete, or stay.
     */
    private fun askStreamExit(): Boolean {
        if (!streamJob || ExportState.job?.stream != true || exitAsked) return false
        val items = arrayListOf(getString(R.string.stream_exit_leave))
        val acts = arrayListOf<() -> Unit>({ exitAsked = true; finish() })
        if (ExportState.segs.isNotEmpty()) {
            items.add(getString(R.string.stream_exit_save))
            acts.add { saveStreamReady { exitAsked = true; finish() } }
        }
        items.add(getString(R.string.stream_exit_discard))
        acts.add { discardStreamOnExit = true; exitAsked = true; finish() }
        items.add(getString(R.string.stream_exit_stay))
        acts.add { }
        AlertDialog.Builder(this)
            .setTitle(R.string.stream_exit_ask)
            .setItems(items.toTypedArray()) { _, w -> acts[w]() }
            .show()
        return true
    }

    /** Previous (-1) / next (+1) item of the playlist; videos and photos are never mixed in one playlist. */
    private fun step(d: Int) {
        if (playlist.size < 2 || streamJob) return
        // one swipe = one photo: ignore a second trigger of the same gesture (touch-up + fling) arriving right after
        val now = SystemClock.elapsedRealtime()
        if (now - lastStepAt < 350L) return
        lastStepAt = now
        if (busy) { toast(R.string.img_busy); return }
        val n = playIndex + d
        if (n !in 0 until playlist.size) {
            showHud(getString(if (d > 0) R.string.list_last else R.string.list_first))
            return
        }
        playIndex = n
        open(playlist[n], keepList = true)
    }

    private fun startPlayback(u: Uri) {
        val p = player ?: return
        val item = MediaItem.Builder().setUri(u).setSubtitleConfigurations(subs.toList()).build()
        val start = if (startAtMs >= 0L) startAtMs else if (streamJob) 0L else prefs.getLong(posKey(u), 0L)
        startAtMs = -1L
        showPoster(u, start)
        p.setMediaItem(item, start)
        p.setPlaybackSpeed(speed)
        p.prepare()
        p.playWhenReady = true
        spinner.visibility = View.VISIBLE
        ui.removeCallbacks(sizeFallback)
        ui.postDelayed(sizeFallback, 1500)
        firstFrame = false
        stallTries = 0
        ui.removeCallbacks(stallCheck)
        ui.postDelayed(stallCheck, 3000)
        blackTries = 0
        blackGl = null
        blackBase = 0L
        ui.removeCallbacks(blackCheck)
        ui.postDelayed(blackCheck, 2200)
    }

    private fun closeMedia() {
        resetTune()
        savePosition()
        ui.removeCallbacks(hideRunnable)
        ui.removeCallbacks(sizeFallback)
        ui.removeCallbacks(stallCheck)
        ui.removeCallbacks(blackCheck)
        teardownView()
        hidePoster()
        player?.let {
            it.stop()
            it.clearMediaItems()
        }
        subs.clear()
        subOrig.clear()
        subDelayMs = 0L
        AudioCfg.syncMs = 0
        pendingSubLabel = null
        aiCancel.set(true)
        bitmap = null
        baseBitmap = null
        zoom = 1f
        zoomCx = 0.5f
        zoomCy = 0.5f
        if (::zoomBtn.isInitialized) zoomBtn.text = "1×"
        vw = 0
        vh = 0
        vpar = 1f
        seek.progress = 0
        seek.secondaryProgress = 0
        curText.text = "0:00"
        durText.text = "0:00"
        subtitleView.text = ""
        subtitleView.visibility = View.GONE
        spinner.visibility = View.GONE
    }

    private fun posKey(u: Uri) = "pos_" + u.toString().hashCode()

    private var noSavePos = false

    private fun savePosition() {
        if (streamJob || noSavePos) return // the pieces of a streaming upscale are temporary: nothing to resume
        val u = currentUri ?: return
        val p = player ?: return
        if (isImage || !hasMedia) return
        val dur = p.duration
        val pos = p.currentPosition
        val e = prefs.edit()
        if (dur > 0 && pos > 5_000L && pos < dur - 5_000L) {
            e.putLong(posKey(u), pos)
            History.put(this, History.Entry(0, u.toString(), displayName(u), pos, dur, System.currentTimeMillis()))
        } else {
            e.remove(posKey(u))
            if (dur > 0 && pos >= dur - 5_000L) History.remove(this, 0, u.toString())
        }
        e.apply()
    }

    // ---- photos -------------------------------------------------------------------------------

    private fun openImage(u: Uri) {
        Thread {
            val bmp = runCatching { decodeImage(u) }.getOrNull()
            ui.post {
                if (isDestroyed || !isImage || currentUri != u) return@post
                if (bmp == null) {
                    fail()
                } else {
                    baseBitmap = bmp
                    bitmap = bmp
                    vw = bmp.width
                    vh = bmp.height
                    vpar = 1f
                    applyRotation()
                    rebuildView()
                    if (!Cfg.autoMode && BudgetAuto.active()) applyBudgetAuto()
                    if (Cfg.autoMode) {
                        applyAuto(true)
                        // a very small photo is AI-upscaled right away (few tiles = quick), with the model that suits its size
                        // (not again for a photo whose automatic run was cancelled: see AiSkip)
                        if (Cfg.autoAiSmall && Auto.smallEnoughForAuto(bmp.width, bmp.height) && AiSr.hasModel(this) && !AiSkip.skipped(this, u)) {
                            ui.postDelayed({ if (!isDestroyed && isImage && currentUri == u && !busy && bitmap === baseBitmap) startAi(true) }, 900)
                        }
                    }
                }
            }
        }.start()
    }

    /** Decodes with a power-of-two sample size so the long side stays near [MAX_SIDE], then applies EXIF rotation. */
    private fun decodeImage(u: Uri): Bitmap? {
        // links and network files: read once (every openStream is a new connection), then decode from memory
        val cached: ByteArray? = if (u.scheme == "http" || u.scheme == "https" || u.scheme == Net.SCHEME) openStream(u)?.use { it.readBytes() } else null
        fun open(): java.io.InputStream? = if (cached != null) java.io.ByteArrayInputStream(cached) else openStream(u)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        open()?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > MAX_SIDE) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val raw = open()?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
        val orientation = runCatching {
            open()?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) }
        }.getOrNull() ?: 1
        val mtx = Matrix()
        // EXIF orientation values: 2 flip-H, 3 rot180, 4 flip-V, 5 transpose, 6 rot90, 7 transverse, 8 rot270
        when (orientation) {
            2 -> mtx.postScale(-1f, 1f)
            3 -> mtx.postRotate(180f)
            4 -> mtx.postScale(1f, -1f)
            5 -> { mtx.postRotate(90f); mtx.postScale(-1f, 1f) }
            6 -> mtx.postRotate(90f)
            7 -> { mtx.postRotate(270f); mtx.postScale(-1f, 1f) }
            8 -> mtx.postRotate(270f)
            else -> return raw
        }
        return Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, mtx, true)
    }

    private fun openStream(u: Uri) =
        if (u.scheme == "http" || u.scheme == "https") {
            java.net.URL(u.toString()).openConnection().apply { connectTimeout = 15000; readTimeout = 30000 }.getInputStream()
        } else if (u.scheme == Net.SCHEME) {
            Net.openStream(this, u)
        } else {
            contentResolver.openInputStream(u)
        }

    private fun drawImage(g: GlPipeline, input: Surface) {
        val bmp = bitmap ?: return
        g.setCaptureSize(bmp.width, bmp.height)
        runCatching {
            val c = input.lockCanvas(null)
            try {
                c.drawBitmap(bmp, null, Rect(0, 0, c.width, c.height), Paint(Paint.FILTER_BITMAP_FLAG))
            } finally {
                input.unlockCanvasAndPost(c)
            }
        }.onFailure {
            Toast.makeText(this, getString(R.string.player_error), Toast.LENGTH_LONG).show()
        }
    }

    // ---- photo tools: enhance (Smart fix / offline AI) and save ----------------------------------

    private fun toast(res: Int) = Toast.makeText(this, getString(res), Toast.LENGTH_SHORT).show()

    /** Shows [b] as the current photo (size may have changed after an AI upscale). */
    private fun showBitmap(b: Bitmap) {
        bitmap = b
        vw = b.width
        vh = b.height
        vpar = 1f
        rebuildView()
    }

    private fun restoreOriginal() {
        val b = baseBitmap ?: return
        if (busy) { toast(R.string.img_busy); return }
        if (bitmap === b) toast(R.string.enh_is_original) else showBitmap(b)
    }

    private fun showEnhanceMenu() {
        if (!isImage || bitmap == null) return
        if (busy) { toast(R.string.img_busy); return }
        val items = arrayOf(
            getString(R.string.enh_auto),
            getString(R.string.enh_ai_fmt, if (Cfg.autoMode) getString(R.string.auto_word) else AiSr.activeLabel(this)),
            getString(R.string.enh_models),
            getString(R.string.online_menu),
            getString(R.string.enh_original)
        )
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.enh_title))
            .setItems(items) { _, which ->
                when (which) {
                    0 -> runAutoFix()
                    1 -> startAi()
                    2 -> showModelsDialog()
                    3 -> showOnlineMenu()
                    else -> restoreOriginal()
                }
            }
            .show()
    }

    // ---- online enhancement (cloud, paid) -----------------------------------------------------

    private fun showOnlineMenu() {
        val items = arrayOf(
            getString(R.string.online_photo),
            getString(R.string.online_text),
            getString(R.string.online_settings)
        )
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.online_menu))
            .setItems(items) { _, which ->
                when (which) {
                    0 -> startOnline(Online.PHOTO)
                    1 -> startOnline(Online.TEXT)
                    else -> showOnlineSettings()
                }
            }
            .show()
    }

    private fun startOnline(kind: Int) {
        if (!Online.hasKey(this)) {
            Toast.makeText(this, getString(R.string.online_need_key), Toast.LENGTH_LONG).show()
            showOnlineSettings()
            return
        }
        val src = bitmap ?: return
        val u = currentUri
        busy = true
        aiCancel.set(false)
        showHud(getString(R.string.online_working_fmt, ""), sticky = true)
        Thread {
            var err: String? = null
            val out = try {
                Online.enhance(this, src, kind, aiCancel) { st ->
                    ui.post { if (busy) showHud(getString(R.string.online_working_fmt, st), sticky = true) }
                }
            } catch (t: Throwable) {
                err = t.message ?: t.javaClass.simpleName
                null
            }
            val failure = err
            ui.post {
                busy = false
                hud.visibility = View.GONE
                if (isDestroyed || !isImage || currentUri != u) return@post
                when {
                    failure != null -> Online.showError(this, failure)
                    out == null -> toast(R.string.ai_cancelled)
                    else -> {
                        showBitmap(out)
                        toast(R.string.online_done)
                    }
                }
            }
        }.start()
    }

    private fun showOnlineSettings() = Online.showSettings(this)

    private fun runAutoFix() {
        val src = bitmap ?: return
        val u = currentUri
        busy = true
        showHud(getString(R.string.img_wait), sticky = true)
        Thread {
            val out = runCatching { Enhance.auto(src) }.getOrNull()
            ui.post {
                busy = false
                hud.visibility = View.GONE
                if (isDestroyed || !isImage || currentUri != u) return@post
                when {
                    out == null -> toast(R.string.player_error)
                    out === src -> toast(R.string.enh_nochange)
                    else -> showBitmap(out)
                }
            }
        }.start()
    }

    /** [auto] = started by the app itself when a small photo opened (a cancel is then remembered so it does not start again). */
    private fun startAi(auto: Boolean = false) {
        if (!AiSr.hasModel(this)) {
            showCatalogDialog() // no model yet: offer the one-tap downloads
            return
        }
        val src = bitmap ?: return
        val u = currentUri
        if (Cfg.autoMode) AiSr.setActive(this, Auto.aiModel(this, src.width, src.height))
        busy = true
        aiCancel.set(false)
        aiUserCancel = false
        showHud(getString(R.string.ai_progress_fmt, 0), sticky = true)
        // a tap on the progress box cancels too (Back does as well)
        hud.setOnClickListener {
            if (busy && !aiCancel.get()) {
                aiUserCancel = true
                aiCancel.set(true)
                Toast.makeText(this, getString(R.string.ai_cancelled), Toast.LENGTH_SHORT).show()
            }
        }
        Thread {
            var err: String? = null
            val out = try {
                AiSr.upscale(this, src, { p -> ui.post { if (busy) showHud(getString(R.string.ai_progress_fmt, p), sticky = true) } }, aiCancel)
            } catch (t: Throwable) {
                err = t.message ?: t.javaClass.simpleName
                null
            }
            val failure = err
            ui.post {
                busy = false
                hud.visibility = View.GONE
                hud.setOnClickListener(null)
                // an automatic run that was cancelled is remembered even when the photo was left meanwhile
                if (auto && failure == null && out == null && aiUserCancel && u != null) {
                    val n = AiSkip.cancelled(this, u)
                    if (n >= 2 && Cfg.autoAiSmall) {
                        Cfg.autoAiSmall = false
                        Cfg.save(this)
                        if (!isDestroyed) Toast.makeText(this, R.string.ai_auto_off, Toast.LENGTH_LONG).show()
                        return@post
                    }
                } else if (auto && out != null) {
                    AiSkip.finished(this)
                }
                if (isDestroyed || !isImage || currentUri != u) return@post
                when {
                    failure != null -> Toast.makeText(this, getString(R.string.ai_error_fmt, failure), Toast.LENGTH_LONG).show()
                    out == null -> toast(if (auto) R.string.ai_cancelled_auto else R.string.ai_cancelled)
                    else -> {
                        showBitmap(out)
                        toast(R.string.ai_done)
                    }
                }
            }
        }.start()
    }

    /** AI model library: choose the active model, add one from a file or a link, remove added ones. */
    private fun showModelsDialog() {
        if (busy) { toast(R.string.img_busy); return }
        val list = AiSr.list(this)
        val active = AiSr.activeId(this)
        val labels = ArrayList<String>()
        for (m in list) labels.add((if (m.id == active) "✓  " else "     ") + m.label)
        labels.add(getString(R.string.model_catalog))
        labels.add(getString(R.string.model_add_file))
        labels.add(getString(R.string.model_add_link))
        labels.add(getString(R.string.model_export))
        if (list.any { !it.builtin }) labels.add(getString(R.string.model_remove))
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.model_title))
            .setItems(labels.toTypedArray()) { _, which ->
                when {
                    which < list.size -> {
                        AiSr.setActive(this, list[which].id)
                        Toast.makeText(this, getString(R.string.model_selected_fmt, list[which].label), Toast.LENGTH_SHORT).show()
                    }
                    which == list.size -> showCatalogDialog()
                    which == list.size + 1 -> {
                        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                            .addCategory(Intent.CATEGORY_OPENABLE)
                            .setType("*/*")
                        @Suppress("DEPRECATION")
                        startActivityForResult(i, REQ_MODEL)
                    }
                    which == list.size + 2 -> showModelLinkDialog()
                    which == list.size + 3 -> ModelFiles.start(this)
                    else -> showRemoveModel()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    /** One-tap list of recommended light models (XLSR, QuickSRNet, SESR-M5): tap = download (if needed) and select. */
    private fun showCatalogDialog() {
        if (busy) { toast(R.string.img_busy); return }
        val cat = AiSr.CATALOG
        val labels = cat.map { c ->
            val state = if (AiSr.isInstalled(this, c)) "✓ " else "⬇ "
            val size = if (c.sizeKb >= 1000) String.format(java.util.Locale.US, "%.1f MB", c.sizeKb / 1000f) else "${c.sizeKb} KB"
            state + c.label + "  (" + size + ")\n    " + getString(c.descRes)
        }
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.model_catalog))
            .setItems(labels.toTypedArray()) { _, which -> downloadCatalogModel(cat[which]) }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun downloadCatalogModel(c: AiSr.Cat) {
        busy = true
        showHud(getString(R.string.ai_downloading_fmt, 0), sticky = true)
        Thread {
            var err: String? = null
            var id: String? = null
            try {
                id = AiSr.installCatalog(this, c) { p -> ui.post { if (busy) showHud(getString(R.string.ai_downloading_fmt, p), sticky = true) } }
            } catch (t: Throwable) {
                err = t.message ?: t.javaClass.simpleName
            }
            val failure = err
            val added = id
            ui.post {
                busy = false
                hud.visibility = View.GONE
                if (isDestroyed) return@post
                if (failure != null || added == null) {
                    Toast.makeText(this, getString(R.string.ai_download_fail_fmt, failure ?: "?"), Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, getString(R.string.model_added_fmt, c.label), Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun showRemoveModel() {
        val removable = AiSr.list(this).filter { !it.builtin }
        if (removable.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.model_remove))
            .setItems(removable.map { it.label }.toTypedArray()) { _, which ->
                AiSr.remove(this, removable[which].id)
                Toast.makeText(this, getString(R.string.model_removed_fmt, removable[which].label), Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showModelLinkDialog() {
        val input = EditText(this).apply {
            hint = "https://…/model.tflite"
            setSingleLine()
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            val clip = runCatching {
                getSystemService(ClipboardManager::class.java).primaryClip?.getItemAt(0)?.text?.toString()
            }.getOrNull()
            if (clip != null && (clip.startsWith("http://") || clip.startsWith("https://"))) setText(clip.trim())
        }
        val pad = dp(this, 20)
        val box = FrameLayout(this).apply { setPadding(pad, dp(this@PlayerActivity, 8), pad, 0) }
        box.addView(input, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.model_add_link))
            .setView(box)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val t = input.text.toString().trim()
                if (t.startsWith("http://") || t.startsWith("https://")) downloadModel(t) else toast(R.string.player_error)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun downloadModel(url: String) {
        busy = true
        showHud(getString(R.string.ai_downloading_fmt, 0), sticky = true)
        Thread {
            var err: String? = null
            var id: String? = null
            try {
                id = AiSr.download(this, url) { p -> ui.post { if (busy) showHud(getString(R.string.ai_downloading_fmt, p), sticky = true) } }
            } catch (t: Throwable) {
                err = t.message ?: t.javaClass.simpleName
            }
            val failure = err
            val added = id
            ui.post {
                busy = false
                hud.visibility = View.GONE
                if (isDestroyed) return@post
                if (failure != null || added == null) {
                    Toast.makeText(this, getString(R.string.ai_download_fail_fmt, failure ?: "?"), Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, getString(R.string.model_added_fmt, added), Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun importModel(u: Uri) {
        busy = true
        showHud(getString(R.string.img_wait), sticky = true)
        val name = displayName(u)
        Thread {
            var err: String? = null
            var id: String? = null
            try {
                id = AiSr.importModel(this, u, name)
            } catch (t: Throwable) {
                err = t.message ?: t.javaClass.simpleName
            }
            val failure = err
            val added = id
            ui.post {
                busy = false
                hud.visibility = View.GONE
                if (isDestroyed) return@post
                if (failure != null || added == null) {
                    Toast.makeText(this, getString(R.string.ai_error_fmt, failure ?: "?"), Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, getString(R.string.model_added_fmt, added), Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun showSaveMenu() {
        val b = bitmap ?: return
        if (busy) { toast(R.string.img_busy); return }
        if (gl == null) { toast(R.string.img_busy); return }
        val labels = ArrayList<String>()
        val kinds = ArrayList<Int>()
        labels.add(getString(R.string.save_jpeg) + "  ${b.width}×${b.height}")
        kinds.add(0)
        labels.add(getString(R.string.save_png) + "  ${b.width}×${b.height}")
        kinds.add(1)
        val w2 = b.width * 2
        val h2 = b.height * 2
        if (max(w2, h2) <= 8192 && w2.toLong() * h2 <= 19_500_000L) {
            labels.add(getString(R.string.save_2x) + "  ${w2}×${h2}")
            kinds.add(2)
        }
        val os = outSize(b)
        if (os != null && os.first != b.width && os.first != w2) {
            labels.add(getString(R.string.save_out) + "  ${os.first}×${os.second}")
            kinds.add(3)
        }
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.save_title))
            .setItems(labels.toTypedArray()) { _, which -> saveImage(kinds[which]) }
            .show()
    }

    /**
     * Output size for "Auto" (no output resolution chosen): the picture at the size it has on this screen, so what is saved is the
     * upscaled picture and not the small source. [atLeast2x] (video shots with an upscaler on) makes it at least twice the source.
     * Kept within the same limits as every save (8192 px, 19.5 megapixels); null when there is nothing bigger to make.
     */
    private fun autoOut(w: Int, h: Int, atLeast2x: Boolean): Pair<Int, Int>? {
        if (Cfg.mode == Cfg.MODE_RAW) return null
        val dm = resources.displayMetrics
        val longScreen = maxOf(dm.widthPixels, dm.heightPixels)
        val shortScreen = minOf(dm.widthPixels, dm.heightPixels)
        // before the stage is built the screen is taken in the direction of the picture (a vertical picture gets the vertical screen)
        val sw = if (builtStageW > 0) builtStageW else if (w >= h) longScreen else shortScreen
        val sh = if (builtStageH > 0) builtStageH else if (w >= h) shortScreen else longScreen
        var k = min(sw / w.toFloat(), sh / h.toFloat())
        if (atLeast2x && k < 2f && min(w, h) < 1500) k = 2f // a source that is already big (1440p, 4K) is not blown up for nothing
        if (k <= 1.05f) return null
        val long = max(w, h) * k
        if (long > 8192f) k *= 8192f / long
        val area = w.toDouble() * h * k * k
        if (area > 19_500_000.0) k *= Math.sqrt(19_500_000.0 / area).toFloat()
        val ow = Math.round(w * k)
        val oh = Math.round(h * k)
        return if (ow > w && oh > h) Pair(ow, oh) else null
    }

    /** The size the chosen output resolution (short side) gives this photo, or null when it is Auto / too big to save. */
    private fun outSize(b: Bitmap): Pair<Int, Int>? {
        val o = Cfg.outRes
        if (o <= 0) return autoOut(b.width, b.height, false)
        val k = o.toFloat() / min(b.width, b.height)
        val w = Math.round(b.width * k)
        val h = Math.round(b.height * k)
        if (w < 2 || h < 2 || max(w, h) > 8192 || w.toLong() * h > 19_500_000L) return null
        return Pair(w, h)
    }

    /** Renders the photo through the effect pipeline at full size (offscreen) and writes it to Pictures/ClearOverlay. */
    private fun saveImage(kind: Int) {
        val b = bitmap ?: return
        val g = gl ?: return
        val scale = if (kind == 2) 2 else 1
        val os = if (kind == 3) outSize(b) else null
        val w = os?.first ?: (b.width * scale)
        val h = os?.second ?: (b.height * scale)
        busy = true
        showHud(getString(R.string.save_wait), sticky = true)
        Thread {
            var ok = false
            val out = runCatching { g.snapshot(w, h) }.getOrNull()
            if (out != null) {
                ok = runCatching { writeToGallery(out, kind != 1) }.getOrDefault(false)
                out.recycle()
            }
            ui.post {
                busy = false
                hud.visibility = View.GONE
                if (!isDestroyed) toast(if (ok) R.string.save_ok else R.string.save_fail)
            }
        }.start()
    }

    /** Screenshot of the current video frame with the effects on (at the chosen output size, or the video\u2019s own size), saved to Pictures/ClearOverlay. */
    /**
     * One source picture for "Make settings lighter": the open photo, or the video's frame at the current spot (local files only), kept to at most
     * 1080 on the short side. Called from a worker thread; null when it cannot be had.
     */
    private fun optFrameNow(): Bitmap? {
        val u = currentUri ?: return null
        val raw: Bitmap? = if (isImage) runCatching { baseBitmap?.copy(Bitmap.Config.ARGB_8888, false) }.getOrNull() else {
            if (streamJob) return null
            val posUs = (player?.currentPosition ?: 0L) * 1000L
            val mr = android.media.MediaMetadataRetriever()
            try {
                mr.setDataSource(this, u)
                // some files give no exact frame (HEVC, 10-bit, no key frame near): fall back to the nearest key frame, then the first one
                mr.getFrameAtTime(posUs, android.media.MediaMetadataRetriever.OPTION_CLOSEST)
                    ?: mr.getFrameAtTime(posUs, android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    ?: mr.getFrameAtTime(0L, android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            } catch (e: Exception) {
                null
            } finally {
                runCatching { mr.release() }
            }
        }
        if (raw == null) return null
        val s = min(raw.width, raw.height)
        if (s <= 1080) return raw
        val k = 1080f / s
        val out = Bitmap.createScaledBitmap(raw, Math.round(raw.width * k), Math.round(raw.height * k), true)
        if (out !== raw) raw.recycle()
        return out
    }

    private fun videoShot() {
        val g = gl ?: return
        if (isImage || vw <= 0 || vh <= 0 || busy) return
        val dw = max(2, Math.round(vw * vpar))
        val dh = vh
        var w = dw
        var h = dh
        val o = Cfg.outRes
        if (o > 0) {
            val k = o.toFloat() / min(dw, dh)
            w = Math.round(dw * k)
            h = Math.round(dh * k)
        } else autoOut(dw, dh, true)?.let { w = it.first; h = it.second } // Auto: the upscaled picture, not the small source
        if (max(w, h) > 8192 || w.toLong() * h > 19_500_000L) {
            w = dw
            h = dh
        }
        busy = true
        showMini(getString(R.string.save_wait))
        val fw = w
        val fh = h
        Thread {
            var ok = false
            val out = runCatching { g.snapshot(fw, fh) }.getOrNull()
            if (out != null) {
                ok = runCatching { writeToGallery(out, false) }.getOrDefault(false)
                out.recycle()
            }
            ui.post {
                busy = false
                if (!isDestroyed) toast(if (ok) R.string.save_ok else R.string.save_fail)
            }
        }.start()
    }

    private fun writeToGallery(bmp: Bitmap, jpeg: Boolean): Boolean {
        val srcName = currentUri?.let { displayName(it).substringBeforeLast('.') }.orEmpty().ifBlank { "CRSC" }
        val specs = arrayOf(bmp.width.toString() + "x" + bmp.height) + Stamp.liveSpecs()
        val name = Stamp.name(srcName, *specs) + if (jpeg) ".jpg" else ".png"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.DESCRIPTION, Stamp.description(srcName, *specs))
            put(MediaStore.Images.Media.MIME_TYPE, if (jpeg) "image/jpeg" else "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ClearOverlay")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val resolver = contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
        return try {
            val os = resolver.openOutputStream(uri) ?: error("no stream")
            os.use {
                val fmt = if (jpeg) Bitmap.CompressFormat.JPEG else Bitmap.CompressFormat.PNG
                if (!bmp.compress(fmt, if (jpeg) 95 else 100, it)) error("compress failed")
            }
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            true
        } catch (t: Throwable) {
            runCatching { resolver.delete(uri, null, null) }
            false
        }
    }

    private fun fail() {
        Toast.makeText(this, getString(R.string.player_error), Toast.LENGTH_LONG).show()
        closeMedia()
        hasMedia = false
        setControlsVisible(true)
    }

    // ---- view + pipeline ----------------------------------------------------------------------

    /** (Re)creates the TextureView at the media's aspect ratio, fitted (or filled) inside the window, and its GL pipeline. */
    private fun rebuildView() {
        teardownView()
        if (vw <= 0 || vh <= 0) return
        // size of the area the picture lives in: the stage as laid out right now (the window metrics can still be the
        // old orientation for a moment after a rotation, which made the picture too big = "zoomed" in portrait)
        val b = windowManager.currentWindowMetrics.bounds
        val sw = (if (stage.width > 0) stage.width else b.width()).toFloat()
        val sh = (if (stage.height > 0) stage.height else b.height()).toFloat()
        builtStageW = sw.toInt()
        builtStageH = sh.toInt()
        val aw = vw * vpar * (1f - bars[0] - bars[2]).coerceIn(0.2f, 1f)
        val ah = vh.toFloat() * (1f - bars[1] - bars[3]).coerceIn(0.2f, 1f)
        var fwF: Float
        var fhF: Float
        val mode = if (isImage) 0 else aspectMode
        when (mode) {
            1 -> {
                val k = max(sw / aw, sh / ah)
                fwF = aw * k
                fhF = ah * k
            }
            2 -> {
                fwF = sw
                fhF = sh
            }
            3, 4, 5 -> {
                val r = if (mode == 3) 16f / 9f else if (mode == 4) 4f / 3f else 21f / 9f
                if (sw / sh > r) {
                    fhF = sh
                    fwF = sh * r
                } else {
                    fwF = sw
                    fhF = sw / r
                }
            }
            else -> {
                val k = min(sw / aw, sh / ah)
                fwF = aw * k
                fhF = ah * k
            }
        }
        val fw = fwF.toInt().coerceIn(2, 8192)
        val fh = fhF.toInt().coerceIn(2, 8192)
        val view = TextureView(this).apply { isOpaque = true }
        view.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, width: Int, height: Int) {
                if (tv === view) startPipeline(st)
            }

            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, width: Int, height: Int) {
                // the picture view was resized (zoom): draw it again at the new size (the second one catches the first frame that still had the old size)
                if (tv === view) {
                    gl?.redraw()
                    ui.postDelayed({ if (tv === view) gl?.redraw() }, 80)
                }
            }

            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                if (tv === view) stopPipeline()
                return true
            }

            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        tv = view
        fitW = fw.toFloat()
        fitH = fh.toFloat()
        val lsz = viewSizeFor(zoom)
        stage.addView(view, FrameLayout.LayoutParams(lsz.first, lsz.second, Gravity.CENTER))
    }

    /** Auto crop found (or lost) black bars: the view takes the shape of the picture inside them. */
    private fun onBarsFound(res: FloatArray) {
        if (plainView) return // the export already cut the bars (or not) as asked
        var same = true
        for (k in 0 until 4) if (Math.abs(res[k] - bars[k]) > 0.005f) same = false
        if (same) return
        bars = res.copyOf()
        rebuildView()
    }

    private fun startPipeline(st: SurfaceTexture) {
        if (gl != null) return
        val out = Surface(st)
        outSurface = out
        val g = GlPipeline(out)
        g.onError = { msg ->
            ui.post { Toast.makeText(this, "+CRSC: $msg".take(240), Toast.LENGTH_LONG).show() }
        }
        // "Watch now": the pieces are already upscaled / sharpened by the export, so the live pipeline only shows them (plain copy).
        // Running the player's own effects on top would do everything twice: slower (lag) and over-sharpened.
        g.bypass = !fxEffective()
        g.stillSource = isImage
        g.govAllowed = !isImage && !plainView && !streamJob
        g.onGov = { lv -> ui.post { if (gl === g && !isDestroyed && Cfg.smoothLive) Toast.makeText(this, getString(if (lv == 0) R.string.smooth_full else R.string.smooth_lighter, lv), Toast.LENGTH_SHORT).show() } }
        g.frameGen = Cfg.playerFg && !isImage && !plainView
        g.frameGenN = Cfg.playerFgN
        g.fgQuality = Cfg.playerFgQ
        g.temporal = if (isImage || plainView) 0 else Cfg.playerTemporal
        g.contentOn = true
        g.barL = bars[0]
        g.barB = bars[1]
        g.barR = bars[2]
        g.barT = bars[3]
        g.onBars = { res -> ui.post { if (gl === g && !isDestroyed) onBarsFound(res) } }
        g.onContent = { px ->
            val c = Auto.classify(px)
            val st = if (Cfg.autoLive) FxAuto.measure(px) else null
            ui.post {
                onContentSeen(c)
                if (st != null) onLiveStats(st)
            }
        }
        if (!isImage) g.maxProcRatio = 1.5f // never process far more pixels than the screen can show (4K files on a 1080p screen)
        g.zoom = zoom
        g.zoomX = zoomCx
        g.zoomY = zoomCy
        val zwin = zoomWindow()
        g.zoomWX = zwin.first
        g.zoomWY = zwin.second
        gl = g
        g.start(vw, vh) { input -> ui.post { if (gl === g) onInputReady(g, input) } }
    }

    private fun onInputReady(g: GlPipeline, input: Surface) {
        if (isImage) {
            drawImage(g, input)
        } else {
            player?.setVideoSurface(input)
        }
    }

    private fun stopPipeline() {
        if (!isImage) runCatching { player?.clearVideoSurface() }
        gl?.release()
        gl = null
        runCatching { outSurface?.release() }
        outSurface = null
    }

    private fun teardownView() {
        stopPipeline()
        tv?.let { v ->
            tv = null
            runCatching { stage.removeView(v) }
        }
    }

    // ---- gestures -----------------------------------------------------------------------------

    private fun onSingleTap(y: Float) {
        if (panel.visibility == View.VISIBLE) {
            hidePanel()
            return
        }
        // Tap = play/pause can be switched off (Settings): then a tap only shows / hides the controls.
        // A tap near the top or bottom edge always shows / hides the controls, so they can be brought back
        // even though a normal tap no longer touches them.
        val h = root.height.toFloat().coerceAtLeast(1f)
        val edge = y < h * 0.12f || y > h * 0.85f
        if (isImage || !tapPlays || edge) {
            setControlsVisible(!controlsOn)
            return
        }
        // Play / pause only: controls that are hidden stay hidden (handy for pausing and resuming repeatedly).
        togglePlay()
    }

    private fun endGesture() {
        val p = player
        if (gestureMode == 1 && p != null) {
            if (streamJob) streamSeek(streamPosMs() + (seekTarget - p.currentPosition)) else p.seekTo(seekTarget)
            gl?.redraw()
        }
        gestureMode = 0
        if (holding) {
            holding = false
            p?.setPlaybackSpeed(holdPrevSpeed)
            hud.visibility = View.GONE
        }
    }

    /** A tiny, short-lived label near the top edge (used for FX on / off, so nothing covers the middle of the picture). */
    private fun showMini(text: String) {
        if (!::miniHud.isInitialized) return
        miniHud.text = text
        miniHud.visibility = View.VISIBLE
        ui.removeCallbacks(miniHide)
        ui.postDelayed(miniHide, 800)
    }

    /**
     * What Auto did, as a small quiet note in the lower left corner (a few seconds), not the big box in the middle of the picture
     * that covered it. The centre box stays for jumps, volume and the like.
     */
    private fun showAutoChip(text: String) {
        if (!::autoChip.isInitialized) { showHud(text); return }
        (autoChip.layoutParams as FrameLayout.LayoutParams).let {
            it.bottomMargin = dp(this, if (bar.visibility == View.VISIBLE) 100 else 24)
            autoChip.layoutParams = it
        }
        autoChip.text = text
        autoChip.visibility = View.VISIBLE
        ui.removeCallbacks(autoChipHide)
        ui.postDelayed(autoChipHide, 2600)
    }

    private lateinit var autoChip: TextView
    private val autoChipHide = Runnable { if (::autoChip.isInitialized) autoChip.visibility = View.GONE }

    // ---- live auto-tuning: small changes that follow the picture while it plays ---------------------
    private val tuneCtl = FxAuto.Ctl()

    private fun resetTune() {
        tuneCtl.reset()
        Cfg.tShadows = 0f; Cfg.tHighlights = 0f; Cfg.tContrast = 0f; Cfg.tSaturation = 0f; Cfg.tSharp = 0f; Cfg.tDenoise = 0f
    }

    /** True when the live changes are all (nearly) zero, so a redraw would show nothing new. */
    private fun tuneIsZero() = Cfg.tShadows == 0f && Cfg.tHighlights == 0f && Cfg.tContrast == 0f && Cfg.tSaturation == 0f && Cfg.tSharp == 0f && Cfg.tDenoise == 0f

    /**
     * Called about once a second with the numbers of the frame ([FxAuto]). Only a small, smoothed change is added on top of the
     * person's own settings, and only what they have not already set: dark scenes up, milky blacks and burnt highlights down,
     * flat ones more contrast, grey ones a little colour, soft ones a little sharper, busy or noisy ones calmer. Black bars do not
     * count, one odd frame (a flash) is ignored, a real cut is followed in about 2 s.
     */
    private fun onLiveStats(m: FxAuto.Meas) {
        if (!Cfg.autoLive || !hasMedia || isDestroyed || plainView || streamJob) { if (!tuneIsZero() || tuneCtl.cur.any { it != 0f }) { resetTune(); gl?.redraw() }; return }
        val before = tuneCtl.cur.copyOf()
        val c = tuneCtl.step(m, floatArrayOf(Cfg.shadows, Cfg.highlights, Cfg.contrast, Cfg.saturation), Cfg.autoLiveLevel)
        Cfg.tShadows = c[0]; Cfg.tHighlights = c[1]; Cfg.tContrast = c[2]; Cfg.tSaturation = c[3]; Cfg.tSharp = c[4]; Cfg.tDenoise = c[5]
        val changed = before.indices.any { before[it] != c[it] }
        if (changed && player?.isPlaying != true) gl?.redraw() // a playing video draws the next frame anyway
    }

    private fun setAutoLive(on: Boolean) {
        Cfg.autoLive = on
        Cfg.save(this)
        if (!on) resetTune()
        gl?.measureContentNow() // the first numbers at once
        gl?.redraw()
    }

    private fun showHud(text: String, sticky: Boolean = false) {
        hud.text = text
        hud.visibility = View.VISIBLE
        ui.removeCallbacks(hudHide)
        if (!sticky) ui.postDelayed(hudHide, 900)
    }

    private fun currentBrightness(): Float {
        val b = window.attributes.screenBrightness
        return if (b < 0f) 0.5f else b
    }

    private fun setBrightness(v: Float) {
        window.attributes = window.attributes.also { it.screenBrightness = v }
    }

    private fun seekBy(deltaMs: Long) {
        val p = player ?: return
        if (streamJob) {
            streamSeek(streamPosMs() + deltaMs)
            showHud(String.format(Locale.US, "%+d s", deltaMs / 1000L))
            return
        }
        val dur = p.duration
        val upper = if (dur > 0) dur else Long.MAX_VALUE
        p.seekTo((p.currentPosition + deltaMs).coerceIn(0L, upper))
        showHud(String.format(Locale.US, "%+d s", deltaMs / 1000L))
        gl?.redraw()
    }

    // ---- controls -----------------------------------------------------------------------------

    private fun isPlaying(): Boolean = player?.isPlaying == true

    private fun setPlayIcon(playing: Boolean) {
        Icons.glyphCentered(playBtn, if (playing) Icons.PAUSE else Icons.PLAY, Ui.TEXT, 22)
    }

    private fun togglePlay() {
        val p = player ?: return
        if (streamJob && pendingSeekUs >= 0L) {
            // Watch now is still preparing (the circle turns): pause / play here means "do not start by itself" / "start when ready"
            stopWanted = !stopWanted
            setPlayIcon(!stopWanted)
            showHud(getString(if (stopWanted) R.string.stream_wait_stopped else R.string.stream_wait_going), true)
            return
        }
        when {
            p.playbackState == Player.STATE_ENDED && streamJob && !streamAtVideoEnd() -> {
                // not the end of the video: only the end of what was ready. play() here would start the piece over, so go on from the spot
                p.playWhenReady = true
                stuckTicks = 3
                syncStream()
            }
            p.playbackState == Player.STATE_ENDED -> {
                if (streamJob) streamSeek(0L) else p.seekTo(0L)
                p.play()
            }
            p.isPlaying || p.playWhenReady -> p.pause()
            else -> p.play()
        }
    }

    private fun setControlsVisible(on: Boolean) {
        controlsOn = on
        bar.visibility = if (on) View.VISIBLE else View.GONE
        topBar.visibility = if (on || Cfg.fxPinned) View.VISIBLE else View.GONE
        // pinned FX: only the FX button stays while the rest of the top bar is hidden
        for (i in 0 until topBar.childCount) {
            val ch = topBar.getChildAt(i)
            ch.visibility = when {
                on || ch === fxBtn -> View.VISIBLE
                !Cfg.fxPinned -> View.VISIBLE
                ch === titleView -> View.INVISIBLE
                else -> View.GONE
            }
        }
        if (isImage && ::shotBtn.isInitialized) shotBtn.visibility = View.GONE
        if (isImage && ::volBtn.isInitialized) volBtn.visibility = View.GONE
        if ((!on || isImage) && ::volPanel.isInitialized) volPanel.visibility = View.GONE
        topBar.post { fitTopBar() }
        val lp = subtitleView.layoutParams as FrameLayout.LayoutParams
        lp.bottomMargin = dp(this, if (on) 120 else 36)
        subtitleView.layoutParams = lp
        if (on) scheduleHide()
    }

    private fun scheduleHide() {
        ui.removeCallbacks(hideRunnable)
        if (isPlaying()) ui.postDelayed(hideRunnable, 3500)
    }

    private fun togglePanel() {
        if (panel.visibility == View.VISIBLE) {
            hidePanel()
            return
        }
        if (!panelBuilt) {
            panelBuilt = true
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            box.addView(buildPlayerHeader())
            box.addView(
                buildControls(
                    this,
                    onAdjust = { onPanelAdjust(it) },
                    inPlayer = true,
                    sourceScale = { currentRatio() },
                    autoPick = { autoClass = -1; autoVotes = 0; gl?.measureContentNow(); autoPickForCurrent() },
                    optFrame = { optFrameNow() }
                ) { gl?.temporal = if (isImage || plainView) 0 else Cfg.playerTemporal; gl?.redraw() }, // the temporal clean-up can now come from a quick profile
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )
            panel.addView(box, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        layoutPanel()
        panel.animate().cancel()
        panel.alpha = 1f
        panel.visibility = View.VISIBLE
        panel.post { clampPanel() }
        ui.removeCallbacks(hideRunnable)
        schedulePanelIdle()
    }

    /** Keeps a dragged settings panel inside the window. */
    private fun clampPanel() {
        if (panel.width <= 0) return
        panel.translationX = panel.translationX.coerceIn(-panel.left.toFloat(), (root.width - panel.right).toFloat().coerceAtLeast(-panel.left.toFloat()))
        panel.translationY = panel.translationY.coerceIn(-panel.top.toFloat(), (root.height - panel.bottom).toFloat().coerceAtLeast(-panel.top.toFloat()))
    }

    /**
     * Portrait: a sheet over the lower half. Landscape: a narrow column on the right, so most of the picture
     * stays free to judge the effect.
     */
    /** Narrower top buttons when the screen is narrow (portrait), so ⚙ and ⋮ never fall off the edge. */
    private fun fitTopBar() {
        if (!::topBar.isInitialized) return
        val b = windowManager.currentWindowMetrics.bounds
        val avail = b.width() - dp(this, 24) - insL - insR - dp(this, 56)
        var n = 0
        for (i in 1 until topBar.childCount) if (topBar.getChildAt(i).visibility != View.GONE) n++
        if (n == 0) return
        val w = (avail / n - dp(this, 4)).coerceIn(dp(this, 28), dp(this, 42))
        for (i in 1 until topBar.childCount) {
            val ch = topBar.getChildAt(i)
            val lp = ch.layoutParams as LinearLayout.LayoutParams
            lp.width = w
            lp.marginStart = dp(this, 4)
            ch.layoutParams = lp
        }
    }

    private fun layoutPanel() {
        fitTopBar()
        val b = windowManager.currentWindowMetrics.bounds
        val land = b.width() > b.height()
        val lp = panel.layoutParams as FrameLayout.LayoutParams
        val m = dp(this, 12)
        val sz = Cfg.panelSize.coerceIn(0, 2)
        if (land) {
            lp.width = (b.width() * floatArrayOf(0.30f, 0.40f, 0.52f)[sz]).toInt()
            lp.height = ((b.height() - insT - insB) * floatArrayOf(0.62f, 0.80f, 0.92f)[sz]).toInt()
            lp.gravity = Gravity.END or Gravity.CENTER_VERTICAL
            lp.setMargins(m, m + insT, m + insR, m + insB)
        } else {
            lp.width = if (sz == 0) (b.width() * 0.84f).toInt() else ViewGroup.LayoutParams.MATCH_PARENT
            lp.height = (b.height() * floatArrayOf(0.34f, 0.5f, 0.66f)[sz]).toInt()
            lp.gravity = if (sz == 0) Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL else Gravity.BOTTOM
            lp.setMargins(m + insL, 0, m + insR, dp(this, if (bar.visibility == View.VISIBLE) 84 else 24) + insB)
        }
        panel.layoutParams = lp
    }

    /** Keeps the top bar, bottom bar and panel out of the camera cutout and system-bar areas. */
    private fun applyInsets(ins: WindowInsets? = null) {
        val wi = ins ?: windowManager.currentWindowMetrics.windowInsets
        val full = Edge.full(this, wi)
        insL = full[0]
        insT = full[1]
        insR = full[2]
        insB = full[3]
        val hh = windowManager.currentWindowMetrics.bounds.height()
        val tb = Edge.insets(this, wi, 0, dp(this, 90) + insT)        // the bars only keep clear of a camera hole that is in their own band
        val bb = Edge.insets(this, wi, hh - dp(this, 150) - insB, hh)
        val m = dp(this, 12)
        val tlp = topBar.layoutParams as FrameLayout.LayoutParams
        val blp = bar.layoutParams as FrameLayout.LayoutParams
        val changed = tlp.leftMargin != m + tb[0] || tlp.topMargin != dp(this, 4) + insT || tlp.rightMargin != m + tb[2] ||
            blp.leftMargin != bb[0] || blp.rightMargin != bb[2] || blp.bottomMargin != insB
        if (changed && topBar.isLaidOut) {
            // the bars slide a little instead of jumping when the status bar comes in or leaves
            (topBar.parent as? ViewGroup)?.let {
                android.transition.TransitionManager.beginDelayedTransition(it, android.transition.ChangeBounds().setDuration(160))
            }
        }
        tlp.setMargins(m + tb[0], dp(this, 4) + insT, m + tb[2], 0)
        topBar.layoutParams = tlp
        blp.setMargins(bb[0], 0, bb[2], insB) // flush with the bottom and the sides (only a camera hole / system bar moves it)
        bar.layoutParams = blp
        if (panel.visibility == View.VISIBLE) layoutPanel()
    }

    private fun hidePanel() {
        ui.removeCallbacks(panelRestore)
        ui.removeCallbacks(panelIdleHide)
        panel.animate().cancel()
        panel.alpha = 1f
        panel.visibility = View.GONE
        scheduleHide()
    }

    private fun schedulePanelIdle() {
        ui.removeCallbacks(panelIdleHide)
        if (Cfg.panelAutoClose && panel.visibility == View.VISIBLE) ui.postDelayed(panelIdleHide, 7000)
    }

    /** A slider is held: panel nearly transparent so the picture can be judged; restored a moment after release. */
    private fun onPanelAdjust(active: Boolean) {
        if (!Cfg.panelFade) return
        ui.removeCallbacks(panelRestore)
        ui.removeCallbacks(panelIdleHide)
        if (active) {
            panel.animate().cancel()
            panel.animate().alpha(Cfg.panelFadeLevel).setDuration(120).start()
        } else {
            ui.postDelayed(panelRestore, 1500)
        }
    }

    /** Top of the player's settings panel: options that only exist inside the player. */
    private fun buildPlayerHeader(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(panelHeader(this, getString(R.string.player_panel_title) + " · " + Cfg.sectionLabel(this), panel, { clampPanel() }, { hidePanel() }) { showHud(it) })

        fun sw(label: String, checked: Boolean, onChange: (Boolean) -> Unit) = panelSwitch(this, label, checked, onChange)
        fun gap(v: Int) = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(this@PlayerActivity, v) }

        // panel size first, so it is always easy to reach (each kind of media has its own)
        col.addView(panelSizeRow(this) {
            layoutPanel()
            panel.post { clampPanel() }
        }, gap(10))
        col.addView(Ui.text(this, getString(R.string.panel_lock_hint), 12f, Ui.MUTED), gap(4))

        // ---- playback (videos only)
        val secPlay = panelSection(this, getString(R.string.panel_sec_playback))
        col.addView(secPlay, gap(14))
        panelVideoOnly.add(secPlay)
        val tap = sw(getString(R.string.player_tap_switch), tapPlays) {
            tapPlays = it
            prefs.edit().putBoolean("tapPlays", it).apply()
        }
        tapSwitch = tap
        col.addView(tap, gap(10))
        val tapHint = Ui.text(this, getString(R.string.player_tap_hint), 12f, Ui.MUTED)
        col.addView(tapHint, gap(2))
        panelVideoOnly.add(tap)
        panelVideoOnly.add(tapHint)
        val autoNext = sw(getString(R.string.player_autonext_switch), Cfg.autoNext) {
            Cfg.autoNext = it
            Cfg.save(this)
        }
        col.addView(autoNext, gap(10))
        panelVideoOnly.add(autoNext)
        val aspLbl = Ui.text(this, getString(R.string.player_aspect_title), 12f, Ui.MUTED)
        col.addView(aspLbl, gap(10))
        panelVideoOnly.add(aspLbl)
        val aspRow = Ui.text(this, aspectLabel(), 15f, Ui.ACCENT, true).apply {
            setPadding(dp(this@PlayerActivity, 12), dp(this@PlayerActivity, 10), dp(this@PlayerActivity, 12), dp(this@PlayerActivity, 10))
            background = Ui.round(Ui.CHIP, dp(this@PlayerActivity, 10).toFloat())
            setOnClickListener { showAspectDialog() }
        }
        aspectBtn = aspRow
        col.addView(aspRow, gap(4))
        panelVideoOnly.add(aspRow)

        // ---- effect
        col.addView(panelSection(this, getString(R.string.panel_sec_effect)), gap(16))
        val fx = sw(getString(R.string.player_fx_switch), fxEffective()) { setFx(it) }
        fxSwitch = fx
        col.addView(fx, gap(10))
        // the FX button on the picture belongs to this switch (it used to sit at the end of the Frame generation section)
        col.addView(
            sw(getString(R.string.player_fx_pin_switch), Cfg.fxPinned) {
                Cfg.fxPinned = it
                Cfg.save(this)
                setControlsVisible(controlsOn)
            },
            gap(10)
        )
        if (!isImage) {
            col.addView(sw(getString(R.string.player_tune_switch), Cfg.autoLive) { setAutoLive(it) }, gap(10))
            col.addView(Ui.text(this, getString(R.string.player_tune_hint), 12f, Ui.MUTED), gap(2))
            col.addView(
                chipRow(this, listOf(R.string.player_tune_light, R.string.player_tune_normal, R.string.player_tune_strong).map { getString(it) }, Cfg.autoLiveLevel.coerceIn(0, 2)) { lv ->
                    Cfg.autoLiveLevel = lv
                    Cfg.save(this@PlayerActivity)
                    gl?.measureContentNow() // look again at once with the new strength
                },
                gap(6)
            )
        }
        if (!isImage) {
            col.addView(panelSection(this, getString(R.string.panel_sec_temporal)), gap(16))
            col.addView(Ui.text(this, getString(R.string.export_temporal), 12f, Ui.MUTED), gap(8))
            col.addView(
                chipRow(this, listOf(R.string.export_fg_off, R.string.export_temporal_light, R.string.export_temporal_strong).map { getString(it) }, Cfg.playerTemporal.coerceIn(0, 2)) { q ->
                    Cfg.playerTemporal = q
                    Cfg.save(this@PlayerActivity)
                    gl?.let { it.temporal = q; it.redraw() }
                },
                gap(4)
            )
            col.addView(Ui.text(this, getString(R.string.export_temporal_hint), 12f, Ui.MUTED), gap(2))
            col.addView(panelSection(this, getString(R.string.panel_sec_fg)), gap(16))
            // the options of Frame generation are shown only while it is on
            val fgOpts = ArrayList<View>()
            fun fgAdd(v: View, g: LinearLayout.LayoutParams) { col.addView(v, g); fgOpts.add(v) }
            fun fgShow(on: Boolean) { for (v in fgOpts) v.visibility = if (on) View.VISIBLE else View.GONE }
            col.addView(
                sw(getString(R.string.player_fg_switch), Cfg.playerFg) {
                    Cfg.playerFg = it
                    Cfg.save(this)
                    gl?.frameGen = it
                    fgShow(it)
                    panel.post { clampPanel() }
                },
                gap(10)
            )
            fgAdd(Ui.text(this, getString(R.string.player_fg_quality), 12f, Ui.MUTED), gap(8))
            fgAdd(
                chipRow(this, listOf(R.string.export_fg_vlight, R.string.export_fg_light, R.string.export_fg_normal, R.string.export_fg_high).map { getString(it) }, intArrayOf(3, 0, 1, 2).indexOf(Cfg.playerFgQ.coerceIn(0, 3)).coerceAtLeast(0)) { qi ->
                    val q = intArrayOf(3, 0, 1, 2)[qi]
                    Cfg.playerFgQ = q
                    Cfg.save(this@PlayerActivity)
                    gl?.fgQuality = q
                },
                gap(4)
            )
            fgAdd(Ui.text(this, getString(R.string.player_fg_mult), 12f, Ui.MUTED), gap(8))
            fgAdd(
                chipRow(this, listOf("2x", "3x", "4x"), Cfg.playerFgN.coerceIn(2, 4) - 2) { i ->
                    Cfg.playerFgN = i + 2
                    Cfg.save(this@PlayerActivity)
                    gl?.frameGenN = i + 2
                },
                gap(4)
            )
            fgAdd(Ui.text(this, getString(R.string.player_fg_hint), 12f, Ui.MUTED), gap(2))
            fgShow(Cfg.playerFg)
        }

        // ---- screen effect (the overlay service)
        col.addView(panelSection(this, getString(R.string.panel_sec_overlay)), gap(16))
        col.addView(
            sw(getString(R.string.player_pause_overlay_switch), Cfg.pauseOverlayInPlayer) {
                Cfg.pauseOverlayInPlayer = it
                Cfg.save(this)
                OverlayService.instance?.pauseForPlayer(it)
            },
            gap(10)
        )
        col.addView(Ui.text(this, getString(R.string.player_pause_overlay_hint), 12f, Ui.MUTED), gap(2))


        for (v in panelVideoOnly) v.visibility = if (isImage) View.GONE else View.VISIBLE
        col.addView(panelSection(this, getString(R.string.player_effects_label)), gap(16))
        return col
    }

    // ---- effect on/off (A/B compare) ------------------------------------------------------------

    /**
     * Hold the FX button = see the original picture while the finger is down, let go = the effects are back (A/B compare without
     * toggling and without losing the place). A short tap still switches the effects on / off as before.
     */
    private fun installHoldCompare(btn: TextView) {
        var holding = false
        val start = Runnable {
            if (!fxEffective()) return@Runnable // already off: nothing to compare against
            holding = true
            btn.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
            gl?.let { it.bypass = true; it.redraw() }
            btn.alpha = 0.6f
            showMini(getString(R.string.player_fx_hold))
        }
        btn.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    holding = false
                    v.postDelayed(start, 350)
                    false
                }
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                    v.removeCallbacks(start)
                    if (holding) {
                        holding = false
                        v.alpha = 1f
                        v.isPressed = false // the up event was consumed here, so the view would stay "pressed"
                        syncFx() // puts the pipeline back to what the switch says
                        scheduleHide()
                        true // no click after a hold
                    } else false
                }
                else -> false
            }
        }
    }

    private fun paintFx() {
        val on = fxEffective()
        fxBtn.background = if (on) Ui.gradient(dp(this, 10).toFloat()) else Ui.round(Color.parseColor("#B30B1020"), dp(this, 10).toFloat(), Ui.STROKE, dp(this, 1))
        fxBtn.setTextColor(if (on) Ui.BG else Ui.MUTED)
    }

    /**
     * The saved FX switch and the pipeline's bypass flag drifted apart: Cfg.bind() loads the switch of the kind (video / photo)
     * that is open, but the pipeline was only told when the button was pressed. So FX could look ON and do nothing (and the next
     * press switched it off, only the second one on). This puts the pipeline, the button and the panel switch back in step.
     */
    private fun syncFx() {
        gl?.let {
            val wantBypass = !fxEffective()
            if (it.bypass != wantBypass) {
                it.bypass = wantBypass
                it.redraw()
            }
        }
        if (::fxBtn.isInitialized) paintFx()
        fxSwitch?.let { val shown = fxEffective(); if (it.isChecked != shown) it.isChecked = shown }
    }

    private fun setFx(on: Boolean) {
        if (streamJob) {
            // Watch now: the live effects on top of the finished pieces. Off unless chosen (they add to the lag of a heavy size); remembered
            getSharedPreferences("crsc", Context.MODE_PRIVATE).edit().putBoolean("stream_fx", on).apply()
            plainView = !on
            gl?.let {
                it.bypass = !on
                it.frameGen = on && Cfg.playerFg && !isImage
                it.temporal = if (on) Cfg.playerTemporal else 0
                it.redraw()
            }
            paintFx()
            fxSwitch?.let { if (it.isChecked != on) it.isChecked = on }
            showMini(getString(if (on) R.string.stream_fx_on else R.string.stream_fx_off))
            return
        }
        if (plainView) {
            // the pieces are already processed by the export: the live effects stay off (and the saved FX choice is not touched)
            syncFx()
            showMini(getString(R.string.stream_fx_note))
            return
        }
        if (Cfg.playerFx == on) {
            syncFx()
            return
        }
        Cfg.playerFx = on
        Cfg.save(this)
        gl?.let {
            it.bypass = !on
            it.redraw()
        }
        paintFx()
        fxSwitch?.let { if (it.isChecked != on) it.isChecked = on }
        showMini(getString(if (on) R.string.player_fx_on else R.string.player_fx_off))
    }

    // ---- zoom (inspect how much the picture changed) ---------------------------------------------

    /** Pinch = free zoom; the button steps 1x / 2x / 4x / 8x. Zoomed in, one finger pans. The zoom is
     *  done on the real source pixels inside the pipeline, so FX on/off can be compared at pixel level. */
    /** Zooms to [z] keeping the point under the finger ([sx], [sy] in window pixels) where it is, so a pinch goes where you pinch. */
    private fun zoomAt(z: Float, sx: Float, sy: Float, fromPinch: Boolean) {
        if (stage.width <= 0 || stage.height <= 0 || fitW <= 1f || fitH <= 1f) { setZoom(z, fromPinch); return }
        // the finger's distance from the middle of the stage (the picture view is always centred there), up = positive
        val loc = IntArray(2)
        stage.getLocationInWindow(loc)
        val dx = sx - (loc[0] + stage.width / 2f)
        val dy = (loc[1] + stage.height / 2f) - sy
        val z0 = zoom
        val px = zoomCx + dx / (fitW * z0)
        val py = zoomCy + dy / (fitH * z0)
        setZoom(z, fromPinch)
        if (zoom > 1f) {
            zoomCx = px - dx / (fitW * zoom)
            zoomCy = py - dy / (fitH * zoom)
            applyZoom()
        }
    }

    /**
     * Size of the picture view at zoom [z]. At 1x it is the fitted picture (a wide picture is a strip); zoomed in it grows with the picture
     * up to the whole stage, so a zoomed picture fills the screen instead of staying inside the strip. (Fill-mode videos, whose fitted view
     * is already bigger than the stage, keep their size.)
     */
    private fun viewSizeFor(z: Float): Pair<Int, Int> {
        val maxW = max(builtStageW.toFloat(), fitW)
        val maxH = max(builtStageH.toFloat(), fitH)
        return Pair(min(maxW, fitW * z).toInt().coerceIn(2, 8192), min(maxH, fitH * z).toInt().coerceIn(2, 8192))
    }

    /** The part of the picture (fractions of its width / height) that the view shows at the current zoom. */
    private fun zoomWindow(): Pair<Float, Float> {
        val sz = viewSizeFor(zoom)
        return Pair((sz.first / (fitW * zoom)).coerceIn(0.001f, 1f), (sz.second / (fitH * zoom)).coerceIn(0.001f, 1f))
    }

    private fun applyViewSize() {
        val v = tv ?: return
        val sz = viewSizeFor(zoom)
        val lp = v.layoutParams ?: return
        if (lp.width != sz.first || lp.height != sz.second) {
            lp.width = sz.first
            lp.height = sz.second
            v.layoutParams = lp
        }
    }

    private fun setZoom(z: Float, fromPinch: Boolean = false) {
        zoom = z.coerceIn(1f, MAX_ZOOM)
        if (zoom <= 1.01f) {
            zoom = 1f
            zoomCx = 0.5f
            zoomCy = 0.5f
        }
        applyZoom()
        if (!fromPinch || zoom > 1f) showHud(getString(R.string.player_zoom_fmt, zoom))
    }

    /** One button for the small tools: zoom, screenshot, rotation, lock, free rotation and cutting the video. */
    private fun showToolsMenu() {
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        labels.add(getString(R.string.tools_zoom_fmt, if (zoom == zoom.toInt().toFloat()) zoom.toInt().toString() else String.format(Locale.US, "%.1f", zoom)))
        acts.add { cycleZoom() }
        if (!isImage) { labels.add(getString(R.string.tools_shot)); acts.add { videoShot() } }
        if (!isImage) { labels.add(getString(R.string.aout_title) + "  ·  " + AudioOut.current(this)); acts.add { AudioOut.show(this, player) } }
        if (!isImage) {
            val left = if (sleepAtMs > 0L) ((sleepAtMs - android.os.SystemClock.elapsedRealtime() + 59_999L) / 60_000L).coerceAtLeast(1L) else 0L
            labels.add(getString(R.string.aud_sleep) + if (left > 0L) "  ·  " + getString(R.string.aud_sleep_min_fmt, left.toInt()) else "")
            acts.add { showSleepDialog() }
        }
        if (!isImage && !streamJob) {
            labels.add(getString(R.string.abloop_title) + when {
                abB >= 0L -> "  ·  " + fmt(abA) + " – " + fmt(abB)
                abA >= 0L -> "  ·  A " + fmt(abA)
                else -> ""
            })
            acts.add { cycleAbLoop() }
        }
        labels.add(getString(R.string.tools_dir_fmt, dirName())); acts.add { showDirPicker() }
        val cu = currentUri
        if (cu != null) {
            val mt = mimeOf(cu)
            val target: Class<*> = when {
                isImage -> PhotoEditActivity::class.java
                mt.startsWith("audio/") -> AudioEditActivity::class.java
                else -> EditActivity::class.java
            }
            labels.add(getString(when { isImage -> R.string.tools_edit_photo; mt.startsWith("audio/") -> R.string.tools_edit_audio; else -> R.string.tools_edit_video }))
            acts.add { startActivity(Intent(this, target).setData(cu).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.tools_title)
            .setItems(labels.toTypedArray()) { _, i -> acts[i]() }
            .show()
    }

    // ---- sleep timer (video): pauses the video after a time, so falling asleep to a film does not play all night ------------------
    private var sleepAtMs = 0L
    private val sleepRun = Runnable {
        sleepAtMs = 0L
        player?.pause()
    }

    private fun setSleep(minutes: Int) {
        ui.removeCallbacks(sleepRun)
        if (minutes <= 0) {
            sleepAtMs = 0L
            showHud(getString(R.string.aud_sleep) + ": " + getString(R.string.aud_sleep_off))
            return
        }
        sleepAtMs = android.os.SystemClock.elapsedRealtime() + minutes * 60_000L
        ui.postDelayed(sleepRun, minutes * 60_000L)
        showHud(getString(R.string.aud_sleep) + ": " + getString(R.string.aud_sleep_min_fmt, minutes))
    }

    private fun showSleepDialog() {
        val mins = intArrayOf(0, 15, 30, 45, 60, 90)
        val labels = mins.map { if (it == 0) getString(R.string.aud_sleep_off) else getString(R.string.aud_sleep_min_fmt, it) }.toTypedArray()
        AlertDialog.Builder(this).setTitle(R.string.aud_sleep).setItems(labels) { _, i -> setSleep(mins[i]) }.show()
    }

    // ---- repeat a section A-B (video / music in the player): first tap = start A, second = end B (the loop begins), third = off ----------
    private var abA = -1L
    private var abB = -1L
    private var abUri: Uri? = null

    private fun cycleAbLoop() {
        val p = player ?: return
        val pos = p.currentPosition
        when {
            abA < 0L -> {
                abA = pos
                abUri = currentUri
                showHud(getString(R.string.abloop_a_fmt, fmt(abA)))
            }
            abB < 0L -> {
                if (pos - abA < 1000L) {
                    showHud(getString(R.string.abloop_short))
                } else {
                    abB = pos
                    p.seekTo(abA)
                    showHud(getString(R.string.abloop_on_fmt, fmt(abA), fmt(abB)))
                }
            }
            else -> {
                abA = -1L
                abB = -1L
                showHud(getString(R.string.abloop_off))
            }
        }
    }

    /** Called from the 200 ms tick: at the end of the section go back to its start. */
    private fun abLoopCheck(p: ExoPlayer, pos: Long) {
        if (abA < 0L) return
        if (abUri != currentUri || streamJob || isImage) {
            abA = -1L
            abB = -1L
            return
        }
        if (abB >= 0L && p.isPlaying && pos >= abB && pos < abB + 3000L) p.seekTo(abA)
    }

    private fun cycleZoom() {
        val steps = floatArrayOf(1f, 2f, 4f, 8f)
        val next = steps.firstOrNull { it > zoom + 0.01f } ?: 1f
        setZoom(next)
    }

    private fun applyZoom() {
        val win = zoomWindow()
        val halfX = 0.5f * win.first
        val halfY = 0.5f * win.second
        zoomCx = zoomCx.coerceIn(halfX, 1f - halfX)
        zoomCy = zoomCy.coerceIn(halfY, 1f - halfY)
        applyViewSize()
        gl?.setZoom(zoom, zoomCx, zoomCy, win.first, win.second)
        if (::zoomBtn.isInitialized) {
            zoomBtn.text = if (zoom == zoom.toInt().toFloat()) zoom.toInt().toString() + "×" else String.format(Locale.US, "%.1f×", zoom)
            if (::toolsBtn.isInitialized) toolsBtn.setImageDrawable(LineIcon(Icons.EDIT, if (zoom > 1f) Ui.ACCENT else Ui.TEXT))
            zoomBtn.setTextColor(if (zoom > 1f) Ui.ACCENT else Ui.TEXT)
        }
    }

    // ---- rotation -------------------------------------------------------------------------------
    // ONE setting, one key: Auto (follows the picture) -> the other direction -> the first one -> Follow the phone -> Auto.
    // A video always starts in Auto; a photo remembers its choice. Nothing else (no lock, no hidden saved state) can keep the screen stuck.

    private fun applyRotation() {
        scheduleFitChecks() // the window turns a moment later: make sure the picture ends up at the right size
        rotKicks = 0
        ui.removeCallbacks(rotVerify)
        ui.postDelayed(rotVerify, 900)
        requestedOrientation = wantedOrientation()
        dl("applyRotation")
    }

    /** The orientation request for the current choice (see [applyRotation]). */
    private fun wantedOrientation(): Int {
        if (rotLock) return ActivityInfo.SCREEN_ORIENTATION_LOCKED
        if (rotManual >= 0) return rotManual // chosen by hand: exactly this, whatever the picture is
        if (rotFree) return ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
        val land: Boolean = when {
            rotAxis == 0 -> true
            rotAxis == 1 -> false
            vw > 0 && vh > 0 -> vw * vpar >= vh
            shapeHint == 1 -> true
            shapeHint == 2 -> false
            else -> return ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED // the shape is not known yet: the phone decides
        }
        return if (land) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
    }

    /** The name of the current choice, for the Tools menu and the little message. */
    private fun dirName(): String = getString(when {
        rotManual >= 0 -> R.string.dir_tile_manual
        rotFree -> R.string.dir_free
        rotAxis == 0 -> R.string.dir_landscape
        rotAxis == 1 -> R.string.dir_portrait
        else -> R.string.dir_auto
    }) + (if (rotManual >= 0) ": " + getString(manualWord(rotManual)) else "") + if (rotLock) "  ·  " + getString(R.string.dir_locked) else ""

    /** The short name of an exact direction: where the top of the phone points. */
    private fun manualWord(o: Int): Int = when (o) {
        ActivityInfo.SCREEN_ORIENTATION_PORTRAIT -> R.string.dir_manual_up
        ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE -> R.string.dir_manual_left
        ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT -> R.string.dir_manual_down
        else -> R.string.dir_manual_right
    }

    /**
     * Reads the shape of a file (landscape / portrait) in a few milliseconds, before it is opened: the size and the turn of a photo (EXIF) or
     * of a video (its rotation tag). 0 = not known (a network address, or the file cannot be read).
     */
    private fun probeShape(u: Uri): Int {
        // Read on a helper thread and wait only a short while: a slow source (cloud / SAF provider) must not freeze the screen; then the shape is "unknown"
        val ft = java.util.concurrent.FutureTask<Int> { probeShapeNow(u) }
        Thread(ft, "probeShape").apply { isDaemon = true }.start()
        return try { ft.get(350, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (t: Throwable) { ft.cancel(true); 0 }
    }

    private fun probeShapeNow(u: Uri): Int {
        val sc = u.scheme ?: return 0
        if (sc != "content" && sc != "file") return 0
        return runCatching {
            var w: Int
            var h: Int
            var turn = 0
            if (mimeOf(u).startsWith("image/")) {
                val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(u)?.use { android.graphics.BitmapFactory.decodeStream(it, null, o) }
                w = o.outWidth
                h = o.outHeight
                val ori = contentResolver.openInputStream(u)?.use {
                    android.media.ExifInterface(it).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)
                } ?: 1
                if (ori == 5 || ori == 6 || ori == 7 || ori == 8) turn = 90
            } else {
                val r = android.media.MediaMetadataRetriever()
                try {
                    r.setDataSource(this, u)
                    w = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                    h = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                    turn = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                } finally {
                    runCatching { r.release() }
                }
            }
            if (turn == 90 || turn == 270) { val t = w; w = h; h = t }
            if (w <= 0 || h <= 0) 0 else if (w >= h) 1 else 2
        }.getOrDefault(0)
    }

    private var rotKicks = 0

    /** One line in the direction diary ([DirLog]) with the player's own state. */
    private fun dl(what: String) = DirLog.add(this, what,
        "img=$isImage video=${vw}x$vh par=$vpar hint=$shapeHint axis=$rotAxis free=$rotFree lock=$rotLock manual=$rotManual sec=${Cfg.section} appDir=${Cfg.appDir}")

    /**
     * Some phones ignore a direction request made while the screen is changing (or made again with the same value) and stay in the wrong
     * direction. 0.9 s after a request the screen is checked: when a landscape-only / portrait-only choice is active and the screen is the
     * other way, the request is dropped for a moment and made again (twice at most).
     */
    // The work is a function and the Runnable only calls it: a Runnable that used itself inside its own initialiser ("ui.postDelayed(rotVerify, 900)")
    // does not compile in Kotlin (the compiler cannot infer its type, and with the type written out it says the variable \"must be initialized\").
    private val rotVerify = Runnable { verifyRotation() }

    private fun verifyRotation() {
        if (isDestroyed || isFinishing || !hasMedia || isInPictureInPictureMode) return
        if (isInMultiWindowMode) return
        val needLand = when (wantedOrientation()) {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE -> true
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT -> false
            else -> return // free / not known yet: any direction is fine
        }
        if (isLandscapeNow() == needLand) return
        if (rotKicks >= 2) { dl("verify: still the wrong way, given up"); return }
        rotKicks++
        dl("verify: wrong way, kick $rotKicks")
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        ui.postDelayed({
            if (isDestroyed || isFinishing) return@postDelayed
            requestedOrientation = wantedOrientation()
            scheduleFitChecks()
            ui.postDelayed(rotVerify, 900)
        }, 120)
    }

    /**
     * Safety net for turning the phone: the picture view is normally rebuilt by the stage's layout listener, but while the system turns the
     * window the stage can report a half-way size, or no layout event comes at all (same size after a 180 degree turn, split screen, a
     * slow phone). So the size of the picture view is checked again a few times after every turn / resume / direction request and
     * rebuilt when it does not match the stage. (Seen as: picture too small, or too big, until something else made it redraw.)
     */
    private val fitCheck = Runnable { ensureFit() }

    private fun scheduleFitChecks() {
        ui.removeCallbacks(fitCheck)
        for (d in longArrayOf(0L, 150L, 400L, 900L, 1800L)) ui.postDelayed(fitCheck, d)
    }

    private fun ensureFit() {
        if (isDestroyed || !hasMedia || vw <= 0 || vh <= 0 || !::stage.isInitialized) return
        val sw = stage.width
        val sh = stage.height
        if (sw <= 0 || sh <= 0) return
        if (tv == null || sw != builtStageW || sh != builtStageH) rebuildView() else applyViewSize()
    }

    private fun rotKey() = if (isImage) "_img" else "_vid"

    /** Reads the direction choice: only photos remember it; a video always starts in Auto (an old saved Lock / Free no longer exists). */
    private fun loadRotation() {
        val k = rotKey()
        if (isImage) {
            rotAxis = prefs.getInt("rot_axis$k", -1)
            rotFree = prefs.getBoolean("rot_free$k", false)
        } else {
            rotAxis = -1
            rotFree = false
        }
    }

    /** True when the screen is shown in landscape right now. */
    private fun isLandscapeNow(): Boolean {
        // the whole display, not this window: in split screen / a floating window the window can be tall while the phone is held sideways
        val b = windowManager.maximumWindowMetrics.bounds
        return b.width() > b.height()
    }

    private fun paintRot() {
        if (!::rotBtn.isInitialized) return
        val land = if (rotAxis >= 0) rotAxis == 0 else isLandscapeNow()
        rotBtn.text = if (rotLock) "🔒" else if (rotManual >= 0) "🧭" else if (land) "↔" else "↕"
        rotBtn.setTextColor(if (rotAxis >= 0 || rotFree || rotLock || rotManual >= 0) Ui.ACCENT else Ui.TEXT)
    }

    private fun saveRot() {
        if (!isImage) return // a video does not remember it
        val k = rotKey()
        prefs.edit().putInt("rot_axis$k", rotAxis).putBoolean("rot_free$k", rotFree).apply()
    }

    /** The direction picker: big picture tiles (Auto / Landscape / Portrait / Follow the phone) and, apart, the lock. One tap picks and closes. */
    private fun showDirPicker() {
        val cur = when {
            rotManual >= 0 -> -1
            rotFree -> 3
            rotAxis == 0 -> 1
            rotAxis == 1 -> 2
            else -> 0
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(this@PlayerActivity, 16), dp(this@PlayerActivity, 8), dp(this@PlayerActivity, 16), dp(this@PlayerActivity, 4))
        }
        var dlg: AlertDialog? = null
        col.addView(DirIcons.row(
            this,
            intArrayOf(DirIcons.AUTO, DirIcons.LAND, DirIcons.PORT, DirIcons.FREE),
            listOf(getString(R.string.dir_tile_auto), getString(R.string.dir_tile_land), getString(R.string.dir_tile_port), getString(R.string.dir_tile_free)),
            cur
        ) { i ->
            rotManual = -1 // a ready choice replaces the exact one
            // ... and the lock too: the lock is the strongest rule of wantedOrientation(), so with it left on, Auto / Landscape / Portrait /
            // Follow the phone changed nothing at all (the screen stayed as it was, whatever was chosen)
            rotLock = false
            when (i) {
                1 -> { rotAxis = 0; rotFree = false }
                2 -> { rotAxis = 1; rotFree = false }
                3 -> { rotAxis = -1; rotFree = true }
                else -> { rotAxis = -1; rotFree = false }
            }
            saveRot()
            paintRot()
            applyRotation()
            showMini(dirName())
            dlg?.dismiss()
        })
        // second row, apart from the choice: Manual (the exact direction by hand) and the lock
        val second = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; isBaselineAligned = false }
        second.addView(
            DirIcons.toggle(this, DirIcons.MANUAL, getString(R.string.dir_tile_manual), rotManual >= 0) {
                dlg?.dismiss()
                showManualPicker()
            },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        second.addView(
            DirIcons.toggle(this, DirIcons.LOCK, getString(if (rotLock) R.string.dir_tile_unlock else R.string.dir_tile_lock), rotLock) {
                rotLock = !rotLock
                paintRot()
                applyRotation()
                showMini(getString(if (rotLock) R.string.dir_lock_on else R.string.dir_lock_off))
                dlg?.dismiss()
            },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(this@PlayerActivity, 6) }
        )
        col.addView(second, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@PlayerActivity, 10) })
        // the direction diary (see DirLog): copy it when the direction goes wrong
        col.addView(Ui.text(this, getString(R.string.dir_report), 13f, Ui.ACCENT, true).apply {
            gravity = android.view.Gravity.CENTER
            setPadding(0, dp(this@PlayerActivity, 12), 0, dp(this@PlayerActivity, 4))
            setOnClickListener { DirLog.copy(this@PlayerActivity) }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val d = AlertDialog.Builder(this).setTitle(R.string.dir_picker_title).setView(col).create()
        dlg = d
        d.show()
    }

    /**
     * Manual direction: the exact direction by hand, for a video that has a direction of its own (the picture shows where the TOP of the phone
     * points: the dot is the camera). Stays until another choice is made, the next video opens, or the player closes. Not saved.
     */
    private fun showManualPicker() {
        val os = intArrayOf(
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT, ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE,
            ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT, ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE
        )
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(this@PlayerActivity, 16), dp(this@PlayerActivity, 8), dp(this@PlayerActivity, 16), dp(this@PlayerActivity, 4))
        }
        col.addView(Ui.text(this, getString(R.string.dir_manual_hint), 12f, Ui.MUTED))
        var dlg: AlertDialog? = null
        col.addView(DirIcons.row(
            this,
            intArrayOf(DirIcons.TOP_UP, DirIcons.TOP_LEFT, DirIcons.TOP_DOWN, DirIcons.TOP_RIGHT),
            os.map { getString(manualWord(it)) },
            os.indexOf(rotManual)
        ) { i ->
            rotManual = os[i]
            rotLock = false // an exact choice replaces the lock as well
            rotAxis = -1
            rotFree = false
            saveRot()
            paintRot()
            applyRotation()
            showMini(dirName())
            dlg?.dismiss()
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@PlayerActivity, 8) })
        val d = AlertDialog.Builder(this).setTitle(R.string.dir_manual_title).setView(col).create()
        dlg = d
        d.show()
    }

    // ---- media size / picture view --------------------------------------------------------------

    /**
     * Creates (or resizes) the picture view for a media size. The decoder only reports its video size once it
     * is rendering into a surface, and that surface only exists after this view does, so the size is also taken
     * from the track format (see [sizeFromTracks]) and from a timeout fallback ([ensureViewFallback]).
     */
    private fun applyMediaSize(w: Int, h: Int, par: Float) {
        if (w <= 0 || h <= 0 || isImage) return
        val first = vw == 0
        if (first || w != vw || h != vh || par != vpar || tv == null) {
            if (first || w != vw || h != vh) bars = FloatArray(4) // a new picture size: the bars are measured again
            vw = w
            vh = h
            vpar = par
            if (first) applyRotation()
            rebuildView()
            updatePip()
            if (Cfg.autoMode) ui.post { applyAuto(true) } else if (BudgetAuto.active()) ui.post { applyBudgetAuto() }
        }
    }

    // ---- Auto: profile / strength / budget / mode chosen from the media and from dropped frames ----------

    private fun currentRatio(): Float {
        val v = tv
        val srcW = vw * vpar
        return if (v == null || srcW <= 0f) 1f else v.width / srcW
    }

    private fun autoPickForCurrent(): Auto.Pick? {
        if (!hasMedia || vw <= 0 || vh <= 0) return null
        if (isImage) return Auto.forPhoto(vw, vh)
        val f = player?.videoFormat
        val fps = if (f != null && f.frameRate > 0f) f.frameRate else 0f
        val br = if (f != null && f.bitrate > 0) f.bitrate else 0
        // A video opened from the web is still a video (film / clip rules, black bars, de-interlace, bit-rate based clean-up); the light
        // "stream" profile is for live game streams, which go through StreamFx.
        val p = Auto.forVideo(vw, vh, fps, br, false, currentRatio(), f?.sampleMimeType ?: "", f?.containerMimeType ?: "")
        val cap = Auto.thermalCap(this)
        if (p.budget <= cap) return p
        // hot phone / battery saver: lower budget; the clean-up and temporal parts need at least Balanced
        return Auto.Pick(p.type, p.level, cap, p.why, if (cap >= Profiles.BALANCED) p.temporal else 0, p.canCrop, p.deint, if (cap >= Profiles.BALANCED || p.clean < 0f) p.clean else 0f, p.quality)
    }

    /**
     * GPU budget "Auto" (without the global Auto): the quick profile the person chose is applied again with the budget the picture needs, or the one
     * the dropped frames allow (see [BudgetAuto]). Nothing happens without a quick profile or while the global Auto is on.
     */
    private fun applyBudgetAuto() {
        if (!BudgetAuto.active()) return
        val pick = autoPickForCurrent() ?: return
        val budget = BudgetAuto.resolve(true, pick.budget, autoBudgetCap)
        if (budget == Cfg.profileBudget && !pendingBudgetApply) return
        pendingBudgetApply = false
        Profiles.applyPick(Cfg.profileType, Cfg.profileLevel, budget, true, currentRatio(), pick.quality)
        gl?.temporal = if (isImage || plainView) 0 else Cfg.playerTemporal
        Cfg.save(this)
        gl?.redraw()
        ControlsBus.sync?.invoke()
    }

    /** Applies Auto to the open media (does nothing unless Auto is on). */
    private fun applyAuto(announce: Boolean) {
        if (!Cfg.autoMode) return
        val pick = autoPickForCurrent() ?: return
        val budget = minOf(pick.budget, autoBudgetCap)
        autoClass = -1
        autoVotes = 0
        Profiles.applyPick(pick.type, pick.level, budget, true, currentRatio(), pick.quality)
        Auto.applyExtras(pick)
        if (!isImage) applyAutoTemporal(if (budget >= Profiles.BALANCED) pick.temporal else 0)
        gl?.measureContentNow() // the kind of picture (dark / animation / soft / busy) refines the upscaler a moment later
        Cfg.save(this)
        gl?.redraw()
        ControlsBus.autoNote = autoNote()
        ControlsBus.sync?.invoke()
        if (announce) {
            val b = intArrayOf(R.string.budget_perf, R.string.budget_balanced, R.string.budget_quality)
            showAutoChip(getString(R.string.auto_picked_fmt, getString(Profiles.nameRes(pick.type)), getString(b[budget])))
        }
    }

    private var autoClass = -1          // the picture kind Auto has applied (-1 = none yet)
    private var autoPending = -1
    private var autoVotes = 0
    private var lastClassSwitch = 0L

    /**
     * Live part of Auto: every second or so the app measures what the picture looks like. A new kind must be seen three times
     * in a row, and not more often than every 5 s, before the upscaler changes (so a dark scene in a film does not make the
     * picture flicker between modes).
     */
    private fun onContentSeen(cls: Int) {
        if (!Cfg.autoMode || !hasMedia || isDestroyed || plainView || streamJob) return
        if (cls == autoClass) { autoPending = -1; autoVotes = 0; return }
        if (cls == autoPending) autoVotes++ else { autoPending = cls; autoVotes = 1 }
        val now = SystemClock.elapsedRealtime()
        val first = autoClass < 0
        if (!first && !isImage && (autoVotes < 3 || now - lastClassSwitch < 5000L)) return
        autoClass = cls
        autoPending = -1
        autoVotes = 0
        lastClassSwitch = now
        val pick = autoPickForCurrent() ?: return
        val budget = minOf(pick.budget, autoBudgetCap)
        val ratio = currentRatio()
        // the kind of picture also picks the quick profile (measured on dark / animation / busy test pictures, README 3.89.30)
        val type = when (cls) {
            Auto.C_ANIME -> Profiles.ANIME
            Auto.C_DARK -> Profiles.DARK
            Auto.C_BUSY -> Profiles.BUSY
            else -> pick.type
        }
        Profiles.applyPick(type, pick.level, budget, true, ratio, pick.quality)
        val mode = Auto.upscaleFor(cls, ratio, budget, type, isImage)
        Cfg.mode = mode
        Auto.applyExtras(pick, type) // after the upscaler: anti-ringing follows how strong it is
        Cfg.save(this)
        gl?.avgDrawMs = 0f
        gl?.redraw()
        ControlsBus.autoNote = autoNote()
        ControlsBus.sync?.invoke()
        val modeName = modeLabel(mode)
        if (mode != Cfg.MODE_SHARP && mode != Cfg.MODE_FAST) showAutoChip(getString(R.string.auto_live_fmt, Auto.className(this, cls), modeName))
    }

    private fun modeLabel(mode: Int): String = getString(
        when (mode) {
            Cfg.MODE_NIS -> R.string.mode_nis
            Cfg.MODE_NIS_SOFT -> R.string.mode_nis_soft
            Cfg.MODE_NIS_ORIG -> R.string.mode_nis_orig
            Cfg.MODE_NIS_FAST -> R.string.mode_nis_fast
            Cfg.MODE_NIS_FINE -> R.string.mode_nis_fine
            Cfg.MODE_NIS_MID -> R.string.mode_nis_mid
            Cfg.MODE_LANCZOS -> R.string.mode_lanczos
            Cfg.MODE_CLEAR -> R.string.mode_clear
            Cfg.MODE_ART -> R.string.mode_art
            Cfg.MODE_NEURAL -> R.string.mode_neural
            Cfg.MODE_PIXEL -> R.string.mode_pixel
            Cfg.MODE_FSR -> R.string.mode_fsr
            Cfg.MODE_FAST -> R.string.mode_fast
            Cfg.MODE_SGSR -> R.string.mode_sgsr
            else -> R.string.mode_sharpen
        }
    )

    /** The line Auto shows in the settings panel: what it chose and why (profile, budget, sizes, upscaler, picture kind, frame-drop limit). */
    private fun autoNote(): String {
        if (!hasMedia || vw <= 0 || vh <= 0) return getString(R.string.auto_waiting)
        val b = intArrayOf(R.string.budget_perf, R.string.budget_balanced, R.string.budget_quality)
        val prof = getString(Profiles.nameRes(Cfg.profileType))
        val bud = getString(b[Cfg.profileBudget.coerceIn(0, 2)])
        val srcW = Math.round(vw * vpar)
        val t = tv
        val outTxt = if (t != null && t.width > 0) "${t.width}×${t.height}" else "-"
        val sb = StringBuilder(getString(R.string.auto_note_fmt, prof, bud, "$srcW×$vh", outTxt, String.format(Locale.US, "%.2f", currentRatio()), modeLabel(Cfg.mode)))
        if (autoClass >= 0) sb.append("\n").append(getString(R.string.auto_note_class, Auto.className(this, autoClass)))
        if (!isImage && (Cfg.autoMode || BudgetAuto.active()) && Auto.thermalCap(this) < Profiles.QUALITY) sb.append("\n").append(getString(R.string.auto_note_thermal))
        if (!isImage && autoBudgetCap < Profiles.QUALITY) sb.append("\n").append(getString(R.string.auto_note_cap, getString(b[autoBudgetCap])))
        if (!isImage && autoTemporalSet && Cfg.playerTemporal > 0) sb.append("\n").append(getString(R.string.auto_note_temporal))
        return sb.toString()
    }

    private fun applyAutoTemporal(t: Int) {
        if (t > Cfg.playerTemporal) {
            Cfg.playerTemporal = t
            autoTemporalSet = true
            gl?.temporal = t
        } else if (t == 0 && autoTemporalSet) {
            Cfg.playerTemporal = 0
            autoTemporalSet = false
            gl?.temporal = 0
        }
    }

    /** Frames were dropped: lower the budget one step and keep it lowered for this video. */
    private fun autoCap(budget: Int) {
        autoBudgetCap = budget.coerceIn(Profiles.PERF, Profiles.QUALITY)
        applyAuto(true)
    }

    private fun sizeFromTracks(tracks: Tracks) {
        for (g in tracks.groups) {
            if (g.type != C.TRACK_TYPE_VIDEO) continue
            for (i in 0 until g.length) {
                if (!g.isTrackSelected(i)) continue
                if (sizeFromFormat(g.getTrackFormat(i))) return
            }
        }
    }

    private fun sizeFromFormat(f: Format): Boolean {
        if (f.width <= 0 || f.height <= 0) return false
        val swap = f.rotationDegrees == 90 || f.rotationDegrees == 270
        val par = if (f.pixelWidthHeightRatio > 0f) f.pixelWidthHeightRatio else 1f
        applyMediaSize(if (swap) f.height else f.width, if (swap) f.width else f.height, par)
        return true
    }

    private fun ensureViewFallback() {
        if (isImage || !hasMedia || tv != null) return
        val f = player?.videoFormat
        if (f != null && sizeFromFormat(f)) return
        val b = windowManager.currentWindowMetrics.bounds
        applyMediaSize(b.width(), b.height(), 1f)
    }

    private fun tick() {
        val p = player ?: return
        if (!isImage && hasMedia) {
            val dur = if (streamJob && ExportState.totalUs > 0L) ExportState.totalUs / 1000L else p.duration
            if (!dragging && (controlsOn || panel.visibility == View.VISIBLE)) { // hidden bar: nothing to update (saves work 5 times a second)
                val pos = if (streamJob) (if (pendingSeekUs >= 0L) (pendingSeekUs - streamOriginUs()) / 1000L else streamPosMs()) else p.currentPosition
                curText.text = fmt(pos)
                if (dur > 0) {
                    seek.progress = (pos * 1000L / dur).toInt().coerceIn(0, 1000)
                    seek.secondaryProgress = if (streamJob) ((streamReadyEndUs() - streamOriginUs()) / 1000L * 1000L / dur).toInt().coerceIn(0, 1000) else (p.bufferedPosition * 1000L / dur).toInt().coerceIn(0, 1000)
                }
            }
            if (controlsOn) durText.text = if (dur > 0) fmt(dur) else "LIVE"
            if (abA >= 0L) abLoopCheck(p, p.currentPosition)
            // keep a paused video responding to live setting changes
            if (!p.isPlaying && panel.visibility == View.VISIBLE) gl?.redraw()
            // heat / battery saver: look every 10 s; when the cap changed, Auto picks its budget again
            if ((Cfg.autoMode || BudgetAuto.active()) && SystemClock.elapsedRealtime() - lastThermalCheck > 10_000L) {
                lastThermalCheck = SystemClock.elapsedRealtime()
                val tc = Auto.thermalCap(this)
                if (tc != lastThermalCap) {
                    lastThermalCap = tc
                    if (Cfg.autoMode) applyAuto(false) else applyBudgetAuto()
                }
            }
            // Auto gives a lowered budget step back after a calm minute (once a raise has failed it stays lowered for this video)
            if (BudgetAuto.active() && p.isPlaying && !autoNoRaise && autoBudgetCap < Profiles.QUALITY) {
                val now = SystemClock.elapsedRealtime()
                if (now - lastAutoDown > 60_000L && now - lastAutoUp > 60_000L) {
                    lastAutoUp = now
                    autoBudgetCap++
                    applyBudgetAuto()
                }
            }
            if (Cfg.autoMode && p.isPlaying && !autoNoRaise && autoBudgetCap < Profiles.QUALITY) {
                val now = SystemClock.elapsedRealtime()
                if (now - lastAutoDown > 60_000L && now - lastAutoUp > 60_000L) {
                    lastAutoUp = now
                    autoBudgetCap++
                    applyAuto(true)
                }
            }
        } else if (isImage && panel.visibility == View.VISIBLE) {
            gl?.redraw()
        }
    }

    private fun fmt(ms: Long): String {
        val t = (ms / 1000L).coerceAtLeast(0L)
        val h = t / 3600
        val m = (t % 3600) / 60
        val s = t % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s) else String.format(Locale.US, "%d:%02d", m, s)
    }

    // ---- menus: speed, tracks, more -----------------------------------------------------------

    private fun showSpeedMenu() {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(this@PlayerActivity, 20), dp(this@PlayerActivity, 12), dp(this@PlayerActivity, 20), dp(this@PlayerActivity, 4))
        }
        val label = Ui.text(this, speedLabel(speed), 26f, Ui.ACCENT, true).apply { gravity = Gravity.CENTER }
        col.addView(label)
        // slider 0.25x .. 4.0x in steps of 0.05
        val bar = SeekBar(this).apply {
            max = 75
            progress = Math.round((speed - 0.25f) / 0.05f).coerceIn(0, 75)
            progressTintList = android.content.res.ColorStateList.valueOf(Ui.ACCENT)
            thumbTintList = android.content.res.ColorStateList.valueOf(Ui.ACCENT)
        }
        fun applySpeed(v: Float) {
            speed = Math.round(v * 100f) / 100f
            player?.setPlaybackSpeed(speed)
            speedBtn.text = speedLabel(speed)
            label.text = speedLabel(speed)
        }
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) applySpeed(0.25f + p * 0.05f)
            }

            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        col.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@PlayerActivity, 8) })
        val presets = floatArrayOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f, 2.5f, 3f, 3.5f, 4f)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (v in presets) {
            row.addView(
                Ui.text(this, speedLabel(v), 14f, Ui.TEXT, true).apply {
                    gravity = Gravity.CENTER
                    setPadding(dp(this@PlayerActivity, 12), dp(this@PlayerActivity, 8), dp(this@PlayerActivity, 12), dp(this@PlayerActivity, 8))
                    background = Ui.round(Ui.CHIP, dp(this@PlayerActivity, 10).toFloat())
                    setOnClickListener {
                        applySpeed(v)
                        bar.progress = Math.round((v - 0.25f) / 0.05f).coerceIn(0, 75)
                    }
                },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(this@PlayerActivity, 6) }
            )
        }
        col.addView(
            android.widget.HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                addView(row)
            },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@PlayerActivity, 14) }
        )
        // sleep timer: pauses the video after the chosen minutes (the same choices as in the music player)
        val sleepLabel = Ui.text(this, "", 14f, Ui.MUTED).apply { gravity = Gravity.CENTER }
        fun paintSleep() {
            val left = if (sleepEndMs > 0L) ((sleepEndMs - System.currentTimeMillis() + 59_999L) / 60_000L).toInt() else 0
            sleepLabel.text = if (left > 0) getString(R.string.aud_sleep_left_fmt, left) else getString(R.string.aud_sleep)
        }
        fun setSleep(min: Int) {
            ui.removeCallbacks(sleepStop)
            if (min > 0) {
                sleepEndMs = System.currentTimeMillis() + min * 60_000L
                ui.postDelayed(sleepStop, min * 60_000L)
            } else sleepEndMs = 0L
            paintSleep()
        }
        paintSleep()
        col.addView(sleepLabel, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@PlayerActivity, 16) })
        val sleepRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (m in intArrayOf(0, 15, 30, 45, 60, 90)) {
            sleepRow.addView(
                Ui.text(this, if (m == 0) getString(R.string.aud_sleep_off) else getString(R.string.aud_sleep_min_fmt, m), 13f, Ui.TEXT, true).apply {
                    gravity = Gravity.CENTER
                    setPadding(dp(this@PlayerActivity, 10), dp(this@PlayerActivity, 8), dp(this@PlayerActivity, 10), dp(this@PlayerActivity, 8))
                    background = Ui.round(Ui.CHIP, dp(this@PlayerActivity, 10).toFloat())
                    setOnClickListener { setSleep(m) }
                },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(this@PlayerActivity, 6) }
            )
        }
        col.addView(
            android.widget.HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                addView(sleepRow)
            },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@PlayerActivity, 6) }
        )
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.player_speed))
            .setView(col)
            .setPositiveButton(android.R.string.ok, null)
            .show()
    }

    private fun speedLabel(v: Float): String =
        String.format(Locale.US, "%.2f", v).trimEnd('0').trimEnd('.') + "×"

    private fun trackName(f: Format, n: Int): String {
        val lang = f.language
        val langName = if (!lang.isNullOrEmpty() && lang != "und") Locale.forLanguageTag(lang).getDisplayLanguage(Locale.getDefault()) else ""
        val base = when {
            !f.label.isNullOrEmpty() -> f.label.toString()
            langName.isNotEmpty() -> langName
            else -> getString(R.string.player_track_fmt, n)
        }
        return if (f.channelCount > 0) "$base  (${f.channelCount}ch)" else base
    }

    private fun selectTextTrack(p: Player, g: Tracks.Group, i: Int) {
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i))
            .build()
    }

    private fun showTrackMenu(type: Int) {
        val p = player ?: return
        val isText = type == C.TRACK_TYPE_TEXT
        val labels = ArrayList<String>()
        val entries = ArrayList<Pair<Tracks.Group, Int>>()
        var checked = -1
        if (isText) labels.add(getString(R.string.player_off))
        for (g in p.currentTracks.groups) {
            if (g.type != type) continue
            for (i in 0 until g.length) {
                if (!g.isTrackSupported(i)) continue
                entries.add(Pair(g, i))
                labels.add(trackName(g.getTrackFormat(i), entries.size))
                if (g.isTrackSelected(i)) checked = labels.size - 1
            }
        }
        if (entries.isEmpty()) {
            Toast.makeText(this, getString(R.string.player_no_tracks), Toast.LENGTH_SHORT).show()
            if (!isText) return
        }
        if (isText && (checked < 0 || p.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT))) checked = 0
        AlertDialog.Builder(this)
            .setTitle(getString(if (isText) R.string.player_subs else R.string.player_audio))
            .setSingleChoiceItems(labels.toTypedArray(), checked) { d, which ->
                if (isText && which == 0) {
                    p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                        .build()
                    subtitleView.text = ""
                    subtitleView.visibility = View.GONE
                } else {
                    val (g, i) = entries[if (isText) which - 1 else which]
                    if (isText) {
                        selectTextTrack(p, g, i)
                    } else {
                        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                            .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i))
                            .build()
                    }
                }
                d.dismiss()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun aspectLabel(): String = getString(
        when (aspectMode) {
            1 -> R.string.aspect_fill
            2 -> R.string.aspect_stretch
            3 -> R.string.aspect_169
            4 -> R.string.aspect_43
            5 -> R.string.aspect_219
            else -> R.string.aspect_fit
        }
    )

    /** Picture size (frame): fit, fill, stretch, 16:9, 4:3, 21:9. */
    private fun showAspectDialog() {
        val names = intArrayOf(R.string.aspect_fit, R.string.aspect_fill, R.string.aspect_stretch, R.string.aspect_169, R.string.aspect_43, R.string.aspect_219)
            .map { getString(it) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(R.string.player_aspect_title)
            .setSingleChoiceItems(names, aspectMode) { d, which ->
                aspectMode = which
                prefs.edit().putInt("aspectMode", which).apply()
                aspectBtn?.text = aspectLabel()
                if (vw > 0 && !isImage) rebuildView()
                d.dismiss()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    /**
     * Headphones / Bluetooth taken off or switched off: pause the video, like the music does. ExoPlayer's own
     * "becoming noisy" handling stays on, but some phones (MIUI among them) do not send that broadcast for every kind of
     * headset, so the removal of the audio device itself is watched as well.
     */
    private val audioDevCb = object : android.media.AudioDeviceCallback() {
        override fun onAudioDevicesAdded(added: Array<out android.media.AudioDeviceInfo>) { AudioOut.apply(this@PlayerActivity, player) }
        override fun onAudioDevicesRemoved(removed: Array<out android.media.AudioDeviceInfo>) {
            if (isImage) return
            val gone = removed.any { d ->
                d.isSink && d.type in intArrayOf(
                    android.media.AudioDeviceInfo.TYPE_WIRED_HEADPHONES, android.media.AudioDeviceInfo.TYPE_WIRED_HEADSET,
                    android.media.AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, android.media.AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
                    android.media.AudioDeviceInfo.TYPE_USB_HEADSET, android.media.AudioDeviceInfo.TYPE_USB_DEVICE,
                    android.media.AudioDeviceInfo.TYPE_BLE_HEADSET, android.media.AudioDeviceInfo.TYPE_HEARING_AID
                )
            }
            if (gone) player?.let { if (it.playWhenReady) it.pause() }
        }
    }

    /**
     * Earbuds taken out of the ears (in-ear detection), a headset button, a car or a watch: the phone sends a media key (pause / play) to the
     * app that owns the active media session. A video player without a session never got it (the key went to the music app or nowhere),
     * so a Bluetooth earbud that is only taken out, not switched off, did not stop the video. This session receives those keys.
     */
    private var session: android.media.session.MediaSession? = null

    private fun startSession() {
        if (session != null) return
        runCatching {
            val s = android.media.session.MediaSession(this, "crsc_video")
            s.setCallback(object : android.media.session.MediaSession.Callback() {
                override fun onPlay() { player?.play() }
                override fun onPause() { player?.pause() }
                override fun onStop() { player?.pause() }
                override fun onSeekTo(pos: Long) { player?.seekTo(pos) }
            })
            s.isActive = true
            session = s
            updateSession()
        }
    }

    private fun updateSession() {
        val s = session ?: return
        val p = player ?: return
        runCatching {
            val playing = p.playWhenReady && p.playbackState != Player.STATE_ENDED && p.playbackState != Player.STATE_IDLE
            val st = android.media.session.PlaybackState.Builder()
                .setActions(
                    android.media.session.PlaybackState.ACTION_PLAY or android.media.session.PlaybackState.ACTION_PAUSE or
                        android.media.session.PlaybackState.ACTION_PLAY_PAUSE or android.media.session.PlaybackState.ACTION_STOP or
                        android.media.session.PlaybackState.ACTION_SEEK_TO
                )
                .setState(
                    if (playing) android.media.session.PlaybackState.STATE_PLAYING else android.media.session.PlaybackState.STATE_PAUSED,
                    p.currentPosition.coerceAtLeast(0L), if (playing) p.playbackParameters.speed else 0f
                )
                .build()
            s.setPlaybackState(st)
        }
    }

    private fun releaseSession() {
        val s = session ?: return
        session = null
        runCatching { s.isActive = false }
        runCatching { s.release() }
    }

    private val volHide = Runnable { if (::volPanel.isInitialized) volPanel.visibility = View.GONE }

    /** The quick volume of the video's OWN sound (not the phone's and not the music's): a slider and a mute button under the top bar. */
    private fun buildVolPanel() {
        volPanel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            val p = dp(this@PlayerActivity, 8)
            setPadding(p, p, dp(this@PlayerActivity, 14), p)
            background = Ui.round(Color.parseColor("#E60B1020"), dp(this@PlayerActivity, 14).toFloat())
            visibility = View.GONE
        }
        val icon = ImageView(this).apply {
            val q = dp(this@PlayerActivity, 6)
            setPadding(q, q, q, q)
            setOnClickListener {
                AudioCfg.vidMute = !AudioCfg.vidMute
                AudioCfg.save(this@PlayerActivity)
                applyVideoVolume()
                volRefresh()
                kickVol()
            }
        }
        val bar = SeekBar(this).apply {
            max = 100
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    AudioCfg.vidVolume = p / 100f
                    if (AudioCfg.vidMute && p > 0) AudioCfg.vidMute = false
                    applyVideoVolume()
                    volRefresh(false)
                    kickVol()
                }
                override fun onStartTrackingTouch(s: SeekBar) { ui.removeCallbacks(volHide) }
                override fun onStopTrackingTouch(s: SeekBar) { AudioCfg.save(this@PlayerActivity); kickVol() }
            })
        }
        val label = Ui.text(this, "", 13f).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        volPanel.addView(icon, LinearLayout.LayoutParams(dp(this, 38), dp(this, 38)))
        volPanel.addView(bar, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(this@PlayerActivity, 4) })
        volPanel.addView(label, LinearLayout.LayoutParams(dp(this, 44), ViewGroup.LayoutParams.WRAP_CONTENT))
        volIcon = icon; volBar = bar; volText = label
        root.addView(volPanel, FrameLayout.LayoutParams(dp(this, 270), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END))
    }

    private fun volRefresh(moveBar: Boolean = true) {
        val shown = if (AudioCfg.vidMute) 0 else Math.round(AudioCfg.vidVolume * 100f)
        volIcon?.setImageDrawable(LineIcon(if (shown == 0) Icons.VOLUME_OFF else Icons.VOLUME, if (shown == 0) Ui.MUTED else Ui.ACCENT))
        volText?.text = "$shown%"
        if (moveBar) volBar?.progress = Math.round(AudioCfg.vidVolume * 100f)
    }

    private fun kickVol() {
        ui.removeCallbacks(volHide)
        ui.postDelayed(volHide, 3500)
    }

    private fun toggleVolPanel() {
        if (!::volPanel.isInitialized) return
        if (volPanel.visibility == View.VISIBLE) { ui.removeCallbacks(volHide); volPanel.visibility = View.GONE; return }
        val lp = volPanel.layoutParams as FrameLayout.LayoutParams
        lp.setMargins(0, insT + dp(this, 50), dp(this, 12) + insR, 0)
        volPanel.layoutParams = lp
        volRefresh()
        volPanel.visibility = View.VISIBLE
        kickVol()
    }

    private fun applyVideoVolume() {
        player?.volume = if (AudioCfg.vidMute) 0f else AudioCfg.vidVolume
    }

    /** Video volume (lower / mute; the boost of the enhancer below raises it) and the "keep the music playing" switch. */
    private fun videoSoundSection(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun gap(v: Int) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@PlayerActivity, v) }
        val label = Ui.text(this, "", 14f)
        fun refreshLabel() { label.text = getString(R.string.vid_volume_fmt, if (AudioCfg.vidMute) 0 else Math.round(AudioCfg.vidVolume * 100f)) }
        refreshLabel()
        var syncing = false
        var muteSw: android.widget.Switch? = null
        muteSw = panelSwitch(this, getString(R.string.vid_mute), AudioCfg.vidMute) { on ->
            if (!syncing) {
                AudioCfg.vidMute = on
                AudioCfg.save(this)
                applyVideoVolume()
                refreshLabel()
            }
        }
        val bar = android.widget.SeekBar(this).apply {
            max = 100
            progress = Math.round(AudioCfg.vidVolume * 100f)
            setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: android.widget.SeekBar, p: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    AudioCfg.vidVolume = p / 100f
                    if (AudioCfg.vidMute && p > 0) { AudioCfg.vidMute = false; syncing = true; muteSw?.isChecked = false; syncing = false }
                    applyVideoVolume()
                    refreshLabel()
                }
                override fun onStartTrackingTouch(s: android.widget.SeekBar) {}
                override fun onStopTrackingTouch(s: android.widget.SeekBar) { AudioCfg.save(this@PlayerActivity) }
            })
        }
        val keep = panelSwitch(this, getString(R.string.vid_keep_music), AudioCfg.keepMusic) { on ->
            AudioCfg.keepMusic = on
            AudioCfg.save(this)
        }
        col.addView(label)
        col.addView(bar, gap(2))
        col.addView(muteSw, gap(6))
        col.addView(keep, gap(14))
        col.addView(Ui.text(this, getString(R.string.vid_keep_music_hint), 12f, Ui.MUTED), gap(4))
        col.addView(View(this).apply { setBackgroundColor(Ui.STROKE) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(this, 1)).apply { topMargin = dp(this@PlayerActivity, 14); bottomMargin = dp(this@PlayerActivity, 4) })
        return col
    }

    /** Sound enhancer (clarity, bass, width, loudness, voice) for the video's sound, live; can also save the sound as .m4a. */
    private fun showAudioDialog() {
        val sv = android.widget.ScrollView(this).apply {
            setPadding(dp(this@PlayerActivity, 20), dp(this@PlayerActivity, 12), dp(this@PlayerActivity, 20), 0)
            addView(LinearLayout(this@PlayerActivity).apply {
                orientation = LinearLayout.VERTICAL
                addView(videoSoundSection())
                addView(buildAudioPanel(this@PlayerActivity))
            })
        }
        val b = AlertDialog.Builder(this).setTitle(R.string.aud_video_menu).setView(sv).setPositiveButton(android.R.string.ok, null)
        val u = currentUri
        if (u != null && !streamJob) b.setNeutralButton(R.string.aud_save_track) { _, _ -> runAudioExport(this, u, displayName(u)) }
        b.show()
    }

    private fun showMoreMenu() {
        val labels = ArrayList<String>()
        labels.add(getString(R.string.lib_open))
        labels.add(getString(R.string.player_open_file))
        labels.add(getString(R.string.player_open_link))
        if (!isImage) labels.add(getString(R.string.player_add_sub))
        if (!isImage) labels.add(getString(R.string.player_sub_size_fmt, subSize))
        if (!isImage && subOrig.isNotEmpty()) labels.add(getString(R.string.subsync_menu_fmt, subSecs()))
        if (!isImage && hasMedia) labels.add(getString(R.string.audsync_menu_fmt, audSecs()))
        labels.add(getString(R.string.player_aspect_menu_fmt, aspectLabel()))
        if (!isImage) labels.add(getString(if (tapPlays) R.string.player_tap_play else R.string.player_tap_controls))
        if (isImage && playlist.size >= 2) labels.add(getString(if (slideshow > 0) R.string.slide_stop else R.string.slide_start))
        val keys = ArrayList<String>()
        keys.add("lib"); keys.add("file"); keys.add("link")
        if (!isImage) { keys.add("sub"); keys.add("subsize") }
        if (!isImage && subOrig.isNotEmpty()) keys.add("subsync")
        if (!isImage && hasMedia) keys.add("audsync")
        keys.add("aspect")
        if (!isImage) keys.add("tap")
        if (isImage && playlist.size >= 2) keys.add("slide")
        if (!isImage && currentUri != null && !streamJob) { labels.add(getString(R.string.export_menu)); keys.add("export") }
        if (!isImage) { labels.add(getString(R.string.aud_video_menu)); keys.add("audiofx") }
        if (streamJob) {
            labels.add(getString(R.string.stream_save_ready)); keys.add("savestream")
            labels.add(getString(if (ExportState.keepAll) R.string.stream_keep_on else R.string.stream_keep_off)); keys.add("keepstream")
        }
        if (!isImage && pipSupported() && hasMedia) {
            labels.add("⧉  " + getString(R.string.pip_open)); keys.add("pip")
            labels.add(getString(if (pipOn()) R.string.pip_auto_on else R.string.pip_auto_off)); keys.add("pipauto")
        }
        if (currentUri != null && !streamJob) { labels.add("⤴  " + getString(R.string.share)); keys.add("share") }
        if (currentUri != null && !streamJob) { labels.add(getString(R.string.trash_delete_item)); keys.add("delete") }
        AlertDialog.Builder(this)
            .setItems(labels.toTypedArray()) { _, which ->
                when (keys[which]) {
                    "lib" -> {
                        if (!fromLibrary) startActivity(Intent(this, LibraryActivity::class.java))
                        finish()
                    }
                    "file" -> pickFile()
                    "link" -> showLinkDialog(false)
                    "sub" -> pickSubtitle()
                    "subsize" -> {
                        subSize = if (subSize >= 32) 14 else subSize + 4
                        subtitleView.textSize = subSize.toFloat()
                        prefs.edit().putInt("subSize", subSize).apply()
                        Toast.makeText(this, getString(R.string.player_sub_size_fmt, subSize), Toast.LENGTH_SHORT).show()
                    }
                    "subsync" -> showSubSyncDialog()
                    "audsync" -> showAudSyncDialog()
                    "aspect" -> showAspectDialog()
                    "slide" -> if (slideshow > 0) stopSlideshow(true) else slideshowDialog()
                    "audiofx" -> showAudioDialog()
                    "pip" -> if (!enterPip()) Toast.makeText(this, R.string.pip_failed, Toast.LENGTH_SHORT).show()
                    "pipauto" -> {
                        prefs.edit().putBoolean("pip_on", !pipOn()).apply()
                        updatePip()
                        Toast.makeText(this, getString(if (pipOn()) R.string.pip_auto_on else R.string.pip_auto_off), Toast.LENGTH_SHORT).show()
                    }
                    "savestream" -> saveStreamReady()
                    "keepstream" -> {
                        ExportState.keepAll = !ExportState.keepAll // this viewing only: the next one starts with the setting of the export screen
                        Toast.makeText(this, getString(if (ExportState.keepAll) R.string.stream_keep_on_msg else R.string.stream_keep_off_msg), Toast.LENGTH_LONG).show()
                    }
                    "share" -> currentUri?.let { Share.share(this, listOf(it)) }
                    // move to the trash or delete for good; when it is gone the viewer closes (the list behind it is reloaded)
                    "delete" -> currentUri?.let { u -> TrashOps.confirmDelete(this, listOf(u)) { finish() } }
                    "export" -> currentUri?.let { u ->
                        startActivity(
                            Intent(this, ExportActivity::class.java).setData(u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                .putExtra(ExportActivity.X_NAME, displayName(u))
                        )
                    }
                    "tap" -> {
                        tapPlays = !tapPlays
                        prefs.edit().putBoolean("tapPlays", tapPlays).apply()
                        tapSwitch?.let { if (it.isChecked != tapPlays) it.isChecked = tapPlays }
                        Toast.makeText(this, getString(if (tapPlays) R.string.player_tap_play else R.string.player_tap_controls), Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .show()
    }

    // ---- external subtitles -------------------------------------------------------------------

    private fun addSubtitle(u: Uri) {
        val name = displayName(u)
        Thread {
            val f = runCatching { normalizeSubtitle(u, name) }.getOrNull()
            ui.post {
                if (isDestroyed) return@post
                if (f == null) {
                    Toast.makeText(this, getString(R.string.player_error), Toast.LENGTH_LONG).show()
                } else {
                    val cfg = MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(f))
                        .setMimeType(subtitleMime(name))
                        .setLabel(name)
                        .build()
                    subOrig.add(f to name)
                    subs.add(if (subDelayMs == 0L) cfg else shiftedCfg(f, name))
                    pendingSubLabel = name
                    reloadMedia()
                    Toast.makeText(this, getString(R.string.player_sub_added), Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    // ---- subtitle sync: the added subtitle files are rewritten with every time moved by the chosen delay, then the video is re-prepared ----
    private val subOrig = ArrayList<Pair<File, String>>()
    private var subDelayMs = 0L
    private fun subSecs(): String = String.format(Locale.US, "%+.1f s", subDelayMs / 1000f)

    private fun shiftedCfg(f: File, name: String): MediaItem.SubtitleConfiguration {
        val out = if (subDelayMs == 0L) f else {
            val o = File(cacheDir, "subs_" + subDelayMs + "_" + f.name)
            if (!o.exists()) o.writeText(SubShift.shift(f.readText(Charsets.UTF_8), name, subDelayMs), Charsets.UTF_8)
            o
        }
        return MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(out)).setMimeType(subtitleMime(name)).setLabel(name).build()
    }

    private fun applySubDelay(d: Long) {
        subDelayMs = d
        Thread {
            val list = runCatching { subOrig.map { (f, n) -> shiftedCfg(f, n) } }.getOrNull()
            ui.post {
                if (isDestroyed || list == null) return@post
                subs.clear()
                subs.addAll(list)
                pendingSubLabel = subOrig.lastOrNull()?.second // the new tracks are switched on again (the label is how the player finds it)
                reloadMedia()
                showHud(getString(R.string.subsync_hud_fmt, subSecs()))
            }
        }.start()
    }

    private fun showSubSyncDialog() = showSyncDialog(getString(R.string.subsync_title_fmt, subSecs()), subDelayMs, 600_000L) { applySubDelay(it) }

    private fun audSecs(): String = String.format(Locale.US, "%+.2f s", AudioCfg.syncMs / 1000f)

    /** Sound sync: + plays the sound later, - earlier; applied at once while playing (see [AudioDelayProcessor]). */
    private fun showAudSyncDialog() = showSyncDialog(getString(R.string.audsync_title_fmt, audSecs()), AudioCfg.syncMs.toLong(), AudioCfg.SYNC_LIMIT_MS.toLong()) {
        AudioCfg.syncMs = it.toInt()
        showHud(getString(R.string.audsync_hud_fmt, audSecs()))
    }

    /** Steps of 0.1 / 0.5 / 1 s, a value typed by hand, and back to 0. [onSet] gets the new value in milliseconds. */
    private fun showSyncDialog(title: String, cur: Long, limit: Long, onSet: (Long) -> Unit) {
        val steps = longArrayOf(-1000L, -500L, -100L, 100L, 500L, 1000L)
        val labels = arrayOf("−1 s", "−0.5 s", "−0.1 s", "+0.1 s", "+0.5 s", "+1 s", getString(R.string.sync_custom), getString(R.string.subsync_reset))
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(labels) { _, w ->
                when (w) {
                    6 -> askSyncSeconds(cur, limit, onSet)
                    7 -> onSet(0L)
                    else -> onSet((cur + steps[w]).coerceIn(-limit, limit))
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun askSyncSeconds(cur: Long, limit: Long, onSet: (Long) -> Unit) {
        val et = android.widget.EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
            setText(String.format(Locale.US, "%.2f", cur / 1000f))
            setSelectAllOnFocus(true)
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.sync_custom_title)
            .setView(et)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                // Persian / Arabic digits and the decimal marks of other keyboards are accepted too
                val t = et.text.toString().trim().map { c ->
                    when (c) {
                        in '٠'..'٩' -> '0' + (c - '٠')
                        in '۰'..'۹' -> '0' + (c - '۰')
                        '٫', ',', '،' -> '.'
                        '−', '–' -> '-'
                        else -> c
                    }
                }.joinToString("")
                val v = t.toDoubleOrNull()
                if (v != null) onSet(Math.round(v * 1000.0).coerceIn(-limit, limit))
                else android.widget.Toast.makeText(this, R.string.sync_invalid, android.widget.Toast.LENGTH_SHORT).show() // it was ignored without a word
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    /** Re-prepares the current item (with the external subtitle list) and keeps position and play state. */
    private fun reloadMedia() {
        val p = player ?: return
        val u = currentUri ?: return
        val pos = p.currentPosition
        val play = p.playWhenReady
        val item = MediaItem.Builder().setUri(u).setSubtitleConfigurations(subs.toList()).build()
        p.setMediaItem(item, pos)
        p.prepare()
        p.playWhenReady = play
    }

    private fun subtitleMime(name: String): String {
        val n = name.lowercase(Locale.US)
        return when {
            n.endsWith(".vtt") -> "text/vtt"
            n.endsWith(".ass") || n.endsWith(".ssa") -> "text/x-ssa"
            n.endsWith(".ttml") || n.endsWith(".xml") || n.endsWith(".dfxp") -> "application/ttml+xml"
            else -> "application/x-subrip"
        }
    }

    /**
     * Subtitle files from the web are often not UTF-8 (Windows-1256 for Persian / Arabic, Windows-1252 for
     * Western languages). The player expects UTF-8, so the file is decoded here and rewritten to cache.
     */
    private fun normalizeSubtitle(u: Uri, name: String): File {
        val raw = (openStream(u) ?: error("cannot open")).use { it.readBytes() }
        var data = raw
        val text: String = when {
            data.size >= 3 && data[0] == 0xEF.toByte() && data[1] == 0xBB.toByte() && data[2] == 0xBF.toByte() -> {
                data = data.copyOfRange(3, data.size)
                String(data, Charsets.UTF_8)
            }
            data.size >= 2 && data[0] == 0xFF.toByte() && data[1] == 0xFE.toByte() -> String(data, 2, data.size - 2, Charsets.UTF_16LE)
            data.size >= 2 && data[0] == 0xFE.toByte() && data[1] == 0xFF.toByte() -> String(data, 2, data.size - 2, Charsets.UTF_16BE)
            else -> try {
                Charsets.UTF_8.newDecoder()
                    .onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT)
                    .decode(ByteBuffer.wrap(data))
                    .toString()
            } catch (e: CharacterCodingException) {
                val lang = resources.configuration.locales[0].language
                val cs = if (lang == "fa" || lang == "ar") "windows-1256" else "windows-1252"
                String(data, Charset.forName(cs))
            }
        }
        val ext = when {
            name.lowercase(Locale.US).endsWith(".vtt") -> "vtt"
            name.lowercase(Locale.US).endsWith(".ass") -> "ass"
            name.lowercase(Locale.US).endsWith(".ssa") -> "ssa"
            name.lowercase(Locale.US).endsWith(".ttml") -> "ttml"
            else -> "srt"
        }
        val f = File(cacheDir, "sub_" + System.nanoTime() + "." + ext)
        f.writeText(text, Charsets.UTF_8)
        return f
    }

    // ---- lifecycle ----------------------------------------------------------------------------

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (::barWatch.isInitialized) barWatch.onTouch(ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            if (::barWatch.isInitialized) barWatch.settle()
            if (::topBar.isInitialized) applyInsets()
            if (hasMedia) scheduleFitChecks()
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        dl("config orientation=" + newConfig.orientation)
        panel.translationX = 0f
        panel.translationY = 0f
        // the picture view is rebuilt by the stage's layout listener once the stage really has its new size; rebuilding here already
        // used the old size for a moment (the picture came out small, then jumped to full size)
        root.post { applyInsets() }
        scheduleFitChecks()
    }

    override fun onResume() {
        super.onResume()
        // the direction request is made again (another screen or the system may have changed the orientation meanwhile)
        dl("resume")
        if (hasMedia && ::rotBtn.isInitialized) applyRotation()
        scheduleFitChecks()
        Cfg.bind(this, if (hasMedia && isImage) "photo" else "video")
        syncFx()
        ui.post(ticker)
        if (Cfg.pauseOverlayInPlayer) OverlayService.instance?.pauseForPlayer(true)
    }

    override fun onPause() {
        stopSlideshow(false) // photos must not keep changing behind another screen
        if (isInPictureInPictureMode) {
            // the small floating window keeps playing: nothing is paused and the video keeps its own effect settings
            super.onPause()
            return
        }
        ui.removeCallbacks(ticker)
        ui.removeCallbacks(hideRunnable)
        savePosition()
        player?.pause()
        OverlayService.instance?.pauseForPlayer(false)
        Cfg.bind(this, "screen") // the screen layer goes back to its own settings
        super.onPause()
    }

    override fun onStop() {
        if (inPip) {
            // the floating window was closed: stop playing
            inPip = false
            savePosition()
            player?.pause()
            unregisterPipReceiver()
            OverlayService.instance?.pauseForPlayer(false)
            Cfg.bind(this, "screen")
        }
        super.onStop()
    }

    // ---- floating window (picture in picture): playing goes on in a small window when the app is left --------

    private var inPip = false
    private var pipReceiverOn = false
    private val pipReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            player?.let { if (it.isPlaying) it.pause() else it.play() }
            updatePip()
        }
    }

    private fun pipSupported() = packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_PICTURE_IN_PICTURE)

    private fun pipOn() = prefs.getBoolean("pip_on", true)

    private fun pipParams(): PictureInPictureParams {
        val w = (vw * vpar).toInt().coerceAtLeast(1)
        val h = vh.coerceAtLeast(1)
        val f = w.toFloat() / h
        val ratio = when {
            f > 2.39f -> Rational(239, 100)
            f < 0.418f -> Rational(100, 239)
            else -> Rational(w, h)
        }
        val playing = player?.isPlaying == true
        val icon = Icon.createWithResource(this, if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
        val pi = PendingIntent.getBroadcast(this, 0, Intent(ACT_PIP).setPackage(packageName), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val label = getString(R.string.pip_playpause)
        return PictureInPictureParams.Builder()
            .setAspectRatio(ratio)
            .setActions(listOf(RemoteAction(icon, label, label, pi)))
            .setAutoEnterEnabled(playing && pipOn() && !isImage && hasMedia)
            .build()
    }

    /** Tells the system the shape of the video and whether playing may turn into a floating window by itself (Home / swipe up). */
    private fun updatePip() {
        if (!pipSupported() || isImage || !hasMedia || player == null) return
        runCatching { setPictureInPictureParams(pipParams()) }
    }

    private fun enterPip(): Boolean {
        if (!pipSupported() || isImage || !hasMedia || player == null || vw <= 0) return false
        return runCatching { enterPictureInPictureMode(pipParams()) }.getOrDefault(false)
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (pipOn() && player?.isPlaying == true && !isFinishing && panel.visibility != View.VISIBLE) enterPip()
    }

    private fun unregisterPipReceiver() {
        if (pipReceiverOn) {
            runCatching { unregisterReceiver(pipReceiver) }
            pipReceiverOn = false
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
        if (isInPictureInPictureMode) {
            ui.removeCallbacks(hideRunnable)
            hidePanel()
            bar.visibility = View.GONE
            topBar.visibility = View.GONE
            hud.visibility = View.GONE
            miniHud.visibility = View.GONE
            spinner.visibility = View.GONE
            if (!pipReceiverOn) {
                val f = IntentFilter(ACT_PIP)
                if (android.os.Build.VERSION.SDK_INT >= 33) registerReceiver(pipReceiver, f, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(pipReceiver, f)
                pipReceiverOn = true
            }
        } else {
            unregisterPipReceiver()
            setControlsVisible(true)
        }
    }

    /** The direction is handed back BEFORE the screen below comes up, so the Library never shows in the player's direction. */
    override fun finish() {
        runCatching { requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED }
        dl("finish")
        AppDirection.afterPlayer = true
        super.finish()
    }

    override fun onDestroy() {
        ui.removeCallbacks(slideTick)
        AudioCfg.syncMs = 0 // the music player shares the sound chain: it must not inherit a video's sound delay
        runCatching { requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED } // give the screen back to the phone
        dl("destroy")
        resetTune()
        Ui.init(this)
        runCatching { (getSystemService(AUDIO_SERVICE) as AudioManager).unregisterAudioDeviceCallback(audioDevCb) }
        releaseSession()
        ui.removeCallbacksAndMessages(null)
        OverlayService.instance?.pauseForPlayer(false)
        teardownView()
        player?.release()
        player = null
        aiCancel.set(true)
        bitmap = null
        baseBitmap = null
        runCatching { cacheDir.listFiles()?.forEach { if (it.name.startsWith("sub_")) it.delete() } }
        if (streamJob && isFinishing && ExportState.job?.stream == true) {
            streamJob = false
            if (discardStreamOnExit) {
                // the person chose to stop: stop the work and delete the pieces
                ExportState.playUs = -1L
                if (ExportState.running) ExportService.cancel(this)
                else ExportState.job?.let { VideoExport.discard(this, it.id) }
            }
            // otherwise just leaving the video: the work goes on (it waits by itself while nobody watches); "Watch" on the export screen comes back
        }
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!busy && panel.visibility != View.VISIBLE && askStreamExit()) return
        if (busy) {
            aiUserCancel = true
            aiCancel.set(true)
            Toast.makeText(this, getString(R.string.ai_cancelled), Toast.LENGTH_SHORT).show()
            return
        }
        if (panel.visibility == View.VISIBLE) {
            hidePanel()
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }

    private companion object {
        const val ACT_PIP = "app.clearoverlay.PIP_TOGGLE"
        const val REQ_PICK = 21
        const val REQ_SUB = 22
        const val MAX_ZOOM = 12f
        const val REQ_MODEL = 23
        /** Long-side cap for decoded photos (keeps GPU textures within every device's limit). */
        const val MAX_SIDE = 4096
    }
}

/** Scroll container for the player's settings; reports every finger-down so the idle auto-hide timer restarts. */
class FadePanel(ctx: Context) : ScrollView(ctx) {
    var onTouch: (() -> Unit)? = null

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN || ev.actionMasked == MotionEvent.ACTION_UP) onTouch?.invoke()
        return super.dispatchTouchEvent(ev)
    }
}
