package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.media.AudioManager
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.webkit.MimeTypeMap
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.text.CueGroup
import androidx.media3.exoplayer.ExoPlayer
import java.io.File
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Built-in video / photo player. The file or stream is decoded directly (no screen capture), then goes
 * through the same GPU pipeline as the overlay (denoise / deband / anti-aliasing -> FSR 1 / SGSR 1 /
 * bilinear upscale -> sharpen -> vivid colors), so a low-resolution source is upscaled from its real pixels.
 *
 *  - Engine: Media3 ExoPlayer (local files, direct links, HLS, DASH, mkv/mp4/webm ...), output surface =
 *    [GlPipeline] input, shown in a TextureView.
 *  - Subtitles: embedded tracks or an external .srt / .vtt / .ass file (re-encoded to UTF-8 when needed),
 *    drawn by a TextView on top of the processed picture.
 *  - Gestures: tap, double tap, horizontal drag (seek), vertical drag (left = brightness, right = volume),
 *    long press (2x speed while held).
 *  - Photos: decoded with BitmapFactory (EXIF-rotated, long side capped) and drawn once into the pipeline.
 */
class PlayerActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())

    private lateinit var root: FrameLayout
    private lateinit var stage: FrameLayout
    private lateinit var titleView: TextView
    private lateinit var bar: LinearLayout
    private lateinit var seekRow: LinearLayout
    private lateinit var playBtn: TextView
    private lateinit var seek: SeekBar
    private lateinit var curText: TextView
    private lateinit var durText: TextView
    private lateinit var speedBtn: TextView
    private lateinit var subtitleView: TextView
    private lateinit var hud: TextView
    private lateinit var spinner: ProgressBar
    private lateinit var panel: ScrollView
    private val videoOnly = ArrayList<View>()

    private var tv: TextureView? = null
    private var gl: GlPipeline? = null
    private var outSurface: Surface? = null
    private var player: ExoPlayer? = null

    private var currentUri: Uri? = null
    private val subs = ArrayList<MediaItem.SubtitleConfiguration>()
    private var pendingSubLabel: String? = null

    private var isImage = false
    private var bitmap: Bitmap? = null
    private var vw = 0
    private var vh = 0
    private var vpar = 1f
    private var hasMedia = false
    private var panelBuilt = false
    private var dragging = false

    // player settings (saved)
    private var tapPlays = true
    private var aspectFill = false
    private var subSize = 18
    private var speed = 1f

    // gesture state
    private var gestureMode = 0 // 0 none, 1 seek, 2 brightness, 3 volume
    private var seekStartPos = 0L
    private var seekTarget = 0L
    private var brightStart = 0.5f
    private var volStart = 0
    private var holding = false
    private var holdPrevSpeed = 1f

    private val prefs by lazy { getSharedPreferences("crsc_player", Context.MODE_PRIVATE) }
    private val audio by lazy { getSystemService(AudioManager::class.java) }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    private val ticker = object : Runnable {
        override fun run() {
            tick()
            ui.postDelayed(this, 200)
        }
    }

    private val hideRunnable = Runnable {
        if (panel.visibility != View.VISIBLE && isPlaying() && vw > 0) setControlsVisible(false)
    }

    private val hudHide = Runnable { hud.visibility = View.GONE }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            setPlayIcon(isPlaying)
            if (isPlaying) scheduleHide() else ui.removeCallbacks(hideRunnable)
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            spinner.visibility = if (playbackState == Player.STATE_BUFFERING) View.VISIBLE else View.GONE
            if (playbackState == Player.STATE_ENDED) {
                setPlayIcon(false)
                setControlsVisible(true)
            }
        }

        override fun onVideoSizeChanged(videoSize: VideoSize) {
            val w = videoSize.width
            val h = videoSize.height
            if (w <= 0 || h <= 0 || isImage) return
            val par = if (videoSize.pixelWidthHeightRatio > 0f) videoSize.pixelWidthHeightRatio else 1f
            val first = vw == 0
            if (first || w != vw || h != vh || par != vpar || tv == null) {
                vw = w
                vh = h
                vpar = par
                if (first) {
                    requestedOrientation = if (w * par >= h) {
                        ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    } else {
                        ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                    }
                }
                rebuildView()
            }
        }

        override fun onCues(cueGroup: CueGroup) {
            val sb = StringBuilder()
            for (c in cueGroup.cues) {
                val t = c.text ?: continue
                if (sb.isNotEmpty()) sb.append('\n')
                sb.append(t.toString())
            }
            subtitleView.text = sb.toString()
            subtitleView.visibility = if (sb.isEmpty()) View.GONE else View.VISIBLE
        }

        override fun onTracksChanged(tracks: Tracks) {
            val label = pendingSubLabel ?: return
            val p = player ?: return
            for (g in tracks.groups) {
                if (g.type != C.TRACK_TYPE_TEXT) continue
                for (i in 0 until g.length) {
                    if (g.getTrackFormat(i).label == label) {
                        pendingSubLabel = null
                        selectTextTrack(p, g, i)
                        return
                    }
                }
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            Toast.makeText(
                this@PlayerActivity,
                getString(R.string.player_error) + "\n" + (error.message ?: error.errorCodeName),
                Toast.LENGTH_LONG
            ).show()
            spinner.visibility = View.GONE
            setControlsVisible(true)
        }
    }

    private val gesture by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                onSingleTap()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (isImage) return true
                val w = root.width.toFloat()
                when {
                    e.x < w / 3f -> seekBy(-10_000L)
                    e.x > w * 2f / 3f -> seekBy(10_000L)
                    else -> togglePlay()
                }
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                val p = player ?: return
                if (isImage || !p.isPlaying) return
                holding = true
                holdPrevSpeed = speed
                p.setPlaybackSpeed(2f)
                showHud("2×", sticky = true)
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
                if (e1 == null || isImage) return false
                val p = player ?: return false
                val w = root.width.toFloat().coerceAtLeast(1f)
                val h = root.height.toFloat().coerceAtLeast(1f)
                val totalX = e2.x - e1.x
                val totalY = e2.y - e1.y
                if (gestureMode == 0) {
                    val slop = ViewConfiguration.get(this@PlayerActivity).scaledTouchSlop
                    if (abs(totalX) < slop && abs(totalY) < slop) return true
                    gestureMode = when {
                        abs(totalX) > abs(totalY) -> 1
                        e1.x < w / 2f -> 2
                        else -> 3
                    }
                    when (gestureMode) {
                        1 -> {
                            seekStartPos = p.currentPosition
                            seekTarget = seekStartPos
                        }
                        2 -> brightStart = currentBrightness()
                        3 -> volStart = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
                    }
                }
                when (gestureMode) {
                    1 -> {
                        val dur = p.duration
                        val upper = if (dur > 0) dur else Long.MAX_VALUE
                        seekTarget = (seekStartPos + (totalX / w * 120_000f).toLong()).coerceIn(0L, upper)
                        val diff = (seekTarget - seekStartPos) / 1000L
                        showHud(fmt(seekTarget) + "  (" + String.format(Locale.US, "%+d", diff) + " s)")
                    }
                    2 -> {
                        val v = (brightStart - totalY / (h * 0.8f)).coerceIn(0.02f, 1f)
                        setBrightness(v)
                        showHud(getString(R.string.player_brightness_fmt, (v * 100).roundToInt()))
                    }
                    3 -> {
                        val maxV = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        val v = (volStart + (-totalY / (h * 0.8f)) * maxV).roundToInt().coerceIn(0, maxV)
                        audio.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0)
                        showHud(getString(R.string.player_volume_fmt, if (maxV > 0) v * 100 / maxV else 0))
                    }
                }
                return true
            }
        })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Cfg.load(this)
        tapPlays = prefs.getBoolean("tapPlays", true)
        aspectFill = prefs.getBoolean("aspectFill", false)
        subSize = prefs.getInt("subSize", 18).coerceIn(12, 36)
        volumeControlStream = AudioManager.STREAM_MUSIC

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.setDecorFitsSystemWindows(false)
        window.attributes = window.attributes.also {
            it.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        stage = FrameLayout(this)
        root.addView(stage, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.setOnTouchListener { _, ev ->
            gesture.onTouchEvent(ev)
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) endGesture()
            true
        }

        // ---- subtitles
        subtitleView = TextView(this).apply {
            visibility = View.GONE
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            setTextColor(Color.WHITE)
            setShadowLayer(6f, 0f, 0f, Color.BLACK)
            setBackgroundColor(Color.parseColor("#66000000"))
            setPadding(dp(this@PlayerActivity, 8), dp(this@PlayerActivity, 2), dp(this@PlayerActivity, 8), dp(this@PlayerActivity, 2))
            textSize = subSize.toFloat()
        }
        root.addView(
            subtitleView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
                bottomMargin = dp(this@PlayerActivity, 36)
                leftMargin = dp(this@PlayerActivity, 24)
                rightMargin = dp(this@PlayerActivity, 24)
            }
        )

        // ---- title (top)
        titleView = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setShadowLayer(6f, 0f, 0f, Color.BLACK)
        }
        root.addView(
            titleView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP).apply {
                val m = dp(this@PlayerActivity, 16)
                setMargins(m, dp(this@PlayerActivity, 14), m, 0)
            }
        )

        // ---- centre HUD + buffering spinner
        hud = TextView(this).apply {
            visibility = View.GONE
            setTextColor(Color.WHITE)
            textSize = 20f
            gravity = Gravity.CENTER
            background = Ui.round(Color.parseColor("#B30B1020"), dp(this@PlayerActivity, 14).toFloat())
            setPadding(dp(this@PlayerActivity, 18), dp(this@PlayerActivity, 10), dp(this@PlayerActivity, 18), dp(this@PlayerActivity, 10))
        }
        root.addView(hud, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        spinner = ProgressBar(this).apply {
            visibility = View.GONE
            indeterminateTintList = ColorStateList.valueOf(Ui.ACCENT)
        }
        root.addView(spinner, FrameLayout.LayoutParams(dp(this, 48), dp(this, 48), Gravity.CENTER))

        // ---- bottom bar: seek row + button row
        bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            isClickable = true
            background = Ui.round(Color.parseColor("#D90B1020"), dp(this@PlayerActivity, 14).toFloat())
            setPadding(dp(this@PlayerActivity, 10), dp(this@PlayerActivity, 6), dp(this@PlayerActivity, 10), dp(this@PlayerActivity, 6))
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        curText = Ui.text(this, "0:00", 12f, Ui.MUTED)
        durText = Ui.text(this, "0:00", 12f, Ui.MUTED)
        seek = SeekBar(this).apply {
            max = 1000
            val tint = ColorStateList.valueOf(Ui.ACCENT)
            progressTintList = tint
            thumbTintList = tint
            progressBackgroundTintList = ColorStateList.valueOf(Ui.STROKE)
            secondaryProgressTintList = ColorStateList.valueOf(Ui.MUTED)
        }
        seekRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        seekRow.addView(curText)
        seekRow.addView(seek, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = dp(this@PlayerActivity, 4)
            marginEnd = dp(this@PlayerActivity, 4)
        })
        seekRow.addView(durText)
        bar.addView(seekRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        videoOnly.add(seekRow)

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val b1 = barButton("−10") { seekBy(-10_000L) }
        playBtn = barButton("▶") { togglePlay() }
        playBtn.textSize = 18f
        val b3 = barButton("+10") { seekBy(10_000L) }
        speedBtn = barButton("1×") { showSpeedMenu() }
        val b5 = barButton("CC") { showTrackMenu(C.TRACK_TYPE_TEXT) }
        val b6 = barButton("♪") { showTrackMenu(C.TRACK_TYPE_AUDIO) }
        val b7 = barButton("⚙") { togglePanel() }
        val b8 = barButton("⋮") { showMoreMenu() }
        for (b in listOf(b1, playBtn, b3, speedBtn, b5, b6)) {
            buttons.addView(b)
            videoOnly.add(b)
        }
        buttons.addView(b7)
        buttons.addView(b8)
        bar.addView(buttons, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(this@PlayerActivity, 4)
        })
        root.addView(
            bar,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply {
                val m = dp(this@PlayerActivity, 12)
                setMargins(m, m, m, m)
            }
        )

        // ---- settings panel (built on first open)
        panel = ScrollView(this).apply {
            visibility = View.GONE
            isClickable = true
            background = Ui.round(Color.parseColor("#F5101522"), dp(this@PlayerActivity, 22).toFloat(), Ui.STROKE, dp(this@PlayerActivity, 1))
            setPadding(dp(this@PlayerActivity, 16), dp(this@PlayerActivity, 14), dp(this@PlayerActivity, 16), dp(this@PlayerActivity, 14))
        }
        root.addView(panel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    val d = player?.duration ?: 0L
                    if (d > 0) curText.text = fmt(p.toLong() * d / 1000L)
                }
            }

            override fun onStartTrackingTouch(s: SeekBar) {
                dragging = true
                ui.removeCallbacks(hideRunnable)
            }

            override fun onStopTrackingTouch(s: SeekBar) {
                val d = player?.duration ?: 0L
                if (d > 0) player?.seekTo(s.progress.toLong() * d / 1000L)
                dragging = false
                gl?.redraw()
                scheduleHide()
            }
        })

        setContentView(root)

        val p = ExoPlayer.Builder(this).build()
        p.addListener(playerListener)
        player = p

        val d = intent?.data
        if (d != null) open(d) else showSourceDialog(cancelFinishes = true)
    }

    private fun barButton(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 14f
        gravity = Gravity.CENTER
        setTextColor(Ui.TEXT)
        background = Ui.round(Ui.CHIP, dp(this@PlayerActivity, 10).toFloat())
        setPadding(dp(this@PlayerActivity, 4), dp(this@PlayerActivity, 9), dp(this@PlayerActivity, 4), dp(this@PlayerActivity, 9))
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = dp(this@PlayerActivity, 3)
            marginEnd = dp(this@PlayerActivity, 3)
        }
        setOnClickListener {
            onClick()
            if (this !== playBtn) scheduleHide()
        }
    }

    // ---- choosing what to play ----------------------------------------------------------------

    private fun showSourceDialog(cancelFinishes: Boolean) {
        val items = arrayOf(getString(R.string.player_open_file), getString(R.string.player_open_link))
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.player_button))
            .setItems(items) { _, which -> if (which == 0) pickFile() else showLinkDialog(cancelFinishes) }
            .setOnCancelListener { if (cancelFinishes && !hasMedia) finish() }
            .show()
    }

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*")
            .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("video/*", "audio/*", "image/*"))
        @Suppress("DEPRECATION")
        startActivityForResult(i, REQ_PICK)
    }

    private fun pickSubtitle() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*")
        @Suppress("DEPRECATION")
        startActivityForResult(i, REQ_SUB)
    }

    private fun showLinkDialog(cancelFinishes: Boolean) {
        val input = EditText(this).apply {
            hint = "https://…"
            setSingleLine()
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            val clip = runCatching {
                getSystemService(ClipboardManager::class.java).primaryClip?.getItemAt(0)?.text?.toString()
            }.getOrNull()
            if (clip != null && (clip.startsWith("http://") || clip.startsWith("https://"))) setText(clip.trim())
        }
        val pad = dp(this, 20)
        val box = FrameLayout(this).apply { setPadding(pad, dp(this@PlayerActivity, 8), pad, 0) }
        box.addView(input, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.player_open_link))
            .setView(box)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val t = input.text.toString().trim()
                if (t.startsWith("http://") || t.startsWith("https://")) {
                    open(Uri.parse(t))
                } else {
                    Toast.makeText(this, getString(R.string.player_error), Toast.LENGTH_SHORT).show()
                    if (cancelFinishes && !hasMedia) finish()
                }
            }
            .setNegativeButton(android.R.string.cancel) { _, _ -> if (cancelFinishes && !hasMedia) finish() }
            .setOnCancelListener { if (cancelFinishes && !hasMedia) finish() }
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val u = data?.data
        when (req) {
            REQ_PICK -> if (res == RESULT_OK && u != null) open(u) else if (!hasMedia) finish()
            REQ_SUB -> if (res == RESULT_OK && u != null) addSubtitle(u)
        }
    }

    // ---- opening media ------------------------------------------------------------------------

    private fun mimeOf(u: Uri): String {
        val t = runCatching { contentResolver.getType(u) }.getOrNull()
        if (!t.isNullOrEmpty()) return t
        val ext = MimeTypeMap.getFileExtensionFromUrl(u.toString()).lowercase(Locale.US)
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: ""
    }

    private fun displayName(u: Uri): String {
        if (u.scheme == "content") {
            runCatching {
                contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val n = c.getString(0)
                        if (!n.isNullOrEmpty()) return n
                    }
                }
            }
        }
        return u.lastPathSegment ?: u.toString()
    }

    private fun open(u: Uri) {
        closeMedia()
        hasMedia = true
        currentUri = u
        isImage = mimeOf(u).startsWith("image/")
        titleView.text = displayName(u)
        for (v in videoOnly) v.visibility = if (isImage) View.GONE else View.VISIBLE
        setControlsVisible(true)
        if (isImage) openImage(u) else startPlayback(u)
    }

    private fun startPlayback(u: Uri) {
        val p = player ?: return
        val item = MediaItem.Builder().setUri(u).setSubtitleConfigurations(subs.toList()).build()
        val start = prefs.getLong(posKey(u), 0L)
        p.setMediaItem(item, start)
        p.setPlaybackSpeed(speed)
        p.prepare()
        p.playWhenReady = true
        spinner.visibility = View.VISIBLE
    }

    private fun closeMedia() {
        savePosition()
        ui.removeCallbacks(hideRunnable)
        teardownView()
        player?.let {
            it.stop()
            it.clearMediaItems()
        }
        subs.clear()
        pendingSubLabel = null
        bitmap = null
        vw = 0
        vh = 0
        vpar = 1f
        seek.progress = 0
        seek.secondaryProgress = 0
        curText.text = "0:00"
        durText.text = "0:00"
        subtitleView.text = ""
        subtitleView.visibility = View.GONE
        spinner.visibility = View.GONE
    }

    private fun posKey(u: Uri) = "pos_" + u.toString().hashCode()

    private fun savePosition() {
        val u = currentUri ?: return
        val p = player ?: return
        if (isImage || !hasMedia) return
        val dur = p.duration
        val pos = p.currentPosition
        val e = prefs.edit()
        if (dur > 0 && pos > 5_000L && pos < dur - 5_000L) e.putLong(posKey(u), pos) else e.remove(posKey(u))
        e.apply()
    }

    // ---- photos -------------------------------------------------------------------------------

    private fun openImage(u: Uri) {
        Thread {
            val bmp = runCatching { decodeImage(u) }.getOrNull()
            ui.post {
                if (isDestroyed || !isImage || currentUri != u) return@post
                if (bmp == null) {
                    fail()
                } else {
                    bitmap = bmp
                    vw = bmp.width
                    vh = bmp.height
                    vpar = 1f
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR
                    rebuildView()
                }
            }
        }.start()
    }

    /** Decodes with a power-of-two sample size so the long side stays near [MAX_SIDE], then applies EXIF rotation. */
    private fun decodeImage(u: Uri): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        openStream(u)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > MAX_SIDE) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val raw = openStream(u)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
        val orientation = runCatching {
            openStream(u)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) }
        }.getOrNull() ?: 1
        val mtx = Matrix()
        // EXIF orientation values: 2 flip-H, 3 rot180, 4 flip-V, 5 transpose, 6 rot90, 7 transverse, 8 rot270
        when (orientation) {
            2 -> mtx.postScale(-1f, 1f)
            3 -> mtx.postRotate(180f)
            4 -> mtx.postScale(1f, -1f)
            5 -> { mtx.postRotate(90f); mtx.postScale(-1f, 1f) }
            6 -> mtx.postRotate(90f)
            7 -> { mtx.postRotate(270f); mtx.postScale(-1f, 1f) }
            8 -> mtx.postRotate(270f)
            else -> return raw
        }
        return Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, mtx, true)
    }

    private fun openStream(u: Uri) =
        if (u.scheme == "http" || u.scheme == "https") {
            java.net.URL(u.toString()).openStream()
        } else {
            contentResolver.openInputStream(u)
        }

    private fun drawImage(g: GlPipeline, input: Surface) {
        val bmp = bitmap ?: return
        g.setCaptureSize(bmp.width, bmp.height)
        runCatching {
            val c = input.lockCanvas(null)
            try {
                c.drawBitmap(bmp, null, Rect(0, 0, c.width, c.height), Paint(Paint.FILTER_BITMAP_FLAG))
            } finally {
                input.unlockCanvasAndPost(c)
            }
        }.onFailure {
            Toast.makeText(this, getString(R.string.player_error), Toast.LENGTH_LONG).show()
        }
    }

    private fun fail() {
        Toast.makeText(this, getString(R.string.player_error), Toast.LENGTH_LONG).show()
        closeMedia()
        hasMedia = false
        setControlsVisible(true)
    }

    // ---- view + pipeline ----------------------------------------------------------------------

    /** (Re)creates the TextureView at the media's aspect ratio, fitted (or filled) inside the window, and its GL pipeline. */
    private fun rebuildView() {
        teardownView()
        if (vw <= 0 || vh <= 0) return
        val b = windowManager.currentWindowMetrics.bounds
        val aw = vw * vpar
        val ah = vh.toFloat()
        val sx = b.width().toFloat() / aw
        val sy = b.height().toFloat() / ah
        val s = if (aspectFill && !isImage) max(sx, sy) else min(sx, sy)
        val fw = (aw * s).toInt().coerceIn(2, 8192)
        val fh = (ah * s).toInt().coerceIn(2, 8192)
        val view = TextureView(this).apply { isOpaque = true }
        view.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, width: Int, height: Int) {
                if (tv === view) startPipeline(st)
            }

            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, width: Int, height: Int) {}

            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                if (tv === view) stopPipeline()
                return true
            }

            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        tv = view
        stage.addView(view, FrameLayout.LayoutParams(fw, fh, Gravity.CENTER))
    }

    private fun startPipeline(st: SurfaceTexture) {
        if (gl != null) return
        val out = Surface(st)
        outSurface = out
        val g = GlPipeline(out)
        g.onError = { msg ->
            ui.post { Toast.makeText(this, "+CRSC: $msg".take(240), Toast.LENGTH_LONG).show() }
        }
        gl = g
        g.start(vw, vh) { input -> ui.post { if (gl === g) onInputReady(g, input) } }
    }

    private fun onInputReady(g: GlPipeline, input: Surface) {
        if (isImage) {
            drawImage(g, input)
        } else {
            player?.setVideoSurface(input)
        }
    }

    private fun stopPipeline() {
        if (!isImage) runCatching { player?.clearVideoSurface() }
        gl?.release()
        gl = null
        runCatching { outSurface?.release() }
        outSurface = null
    }

    private fun teardownView() {
        stopPipeline()
        tv?.let { v ->
            tv = null
            runCatching { stage.removeView(v) }
        }
    }

    // ---- gestures -----------------------------------------------------------------------------

    private fun onSingleTap() {
        if (isImage || !tapPlays) {
            setControlsVisible(bar.visibility != View.VISIBLE)
            return
        }
        if (panel.visibility == View.VISIBLE) {
            panel.visibility = View.GONE
            return
        }
        togglePlay()
        setControlsVisible(true)
    }

    private fun endGesture() {
        val p = player
        if (gestureMode == 1 && p != null) {
            p.seekTo(seekTarget)
            gl?.redraw()
        }
        gestureMode = 0
        if (holding) {
            holding = false
            p?.setPlaybackSpeed(holdPrevSpeed)
            hud.visibility = View.GONE
        }
    }

    private fun showHud(text: String, sticky: Boolean = false) {
        hud.text = text
        hud.visibility = View.VISIBLE
        ui.removeCallbacks(hudHide)
        if (!sticky) ui.postDelayed(hudHide, 900)
    }

    private fun currentBrightness(): Float {
        val b = window.attributes.screenBrightness
        return if (b < 0f) 0.5f else b
    }

    private fun setBrightness(v: Float) {
        window.attributes = window.attributes.also { it.screenBrightness = v }
    }

    private fun seekBy(deltaMs: Long) {
        val p = player ?: return
        val dur = p.duration
        val upper = if (dur > 0) dur else Long.MAX_VALUE
        p.seekTo((p.currentPosition + deltaMs).coerceIn(0L, upper))
        showHud(String.format(Locale.US, "%+d s", deltaMs / 1000L))
        gl?.redraw()
    }

    // ---- controls -----------------------------------------------------------------------------

    private fun isPlaying(): Boolean = player?.isPlaying == true

    private fun setPlayIcon(playing: Boolean) {
        playBtn.text = if (playing) "❚❚" else "▶"
    }

    private fun togglePlay() {
        val p = player ?: return
        when {
            p.playbackState == Player.STATE_ENDED -> {
                p.seekTo(0L)
                p.play()
            }
            p.isPlaying || p.playWhenReady -> p.pause()
            else -> p.play()
        }
    }

    private fun setControlsVisible(on: Boolean) {
        bar.visibility = if (on) View.VISIBLE else View.GONE
        titleView.visibility = if (on) View.VISIBLE else View.GONE
        val lp = subtitleView.layoutParams as FrameLayout.LayoutParams
        lp.bottomMargin = dp(this, if (on) 120 else 36)
        subtitleView.layoutParams = lp
        if (on) scheduleHide()
    }

    private fun scheduleHide() {
        ui.removeCallbacks(hideRunnable)
        if (isPlaying()) ui.postDelayed(hideRunnable, 3500)
    }

    private fun togglePanel() {
        if (panel.visibility == View.VISIBLE) {
            panel.visibility = View.GONE
            scheduleHide()
            return
        }
        if (!panelBuilt) {
            panelBuilt = true
            panel.addView(
                buildControls(this) { gl?.redraw() },
                ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )
        }
        val b = windowManager.currentWindowMetrics.bounds
        val lp = panel.layoutParams as FrameLayout.LayoutParams
        lp.height = (b.height() * 0.62f).toInt()
        lp.bottomMargin = dp(this, 110)
        lp.leftMargin = dp(this, 12)
        lp.rightMargin = dp(this, 12)
        panel.layoutParams = lp
        panel.visibility = View.VISIBLE
        ui.removeCallbacks(hideRunnable)
    }

    private fun tick() {
        val p = player ?: return
        if (!isImage && hasMedia) {
            val dur = p.duration
            if (!dragging) {
                val pos = p.currentPosition
                curText.text = fmt(pos)
                if (dur > 0) {
                    seek.progress = (pos * 1000L / dur).toInt().coerceIn(0, 1000)
                    seek.secondaryProgress = (p.bufferedPosition * 1000L / dur).toInt().coerceIn(0, 1000)
                }
            }
            durText.text = if (dur > 0) fmt(dur) else "LIVE"
            // keep a paused video responding to live setting changes
            if (!p.isPlaying && panel.visibility == View.VISIBLE) gl?.redraw()
        } else if (isImage && panel.visibility == View.VISIBLE) {
            gl?.redraw()
        }
    }

    private fun fmt(ms: Long): String {
        val t = (ms / 1000L).coerceAtLeast(0L)
        val h = t / 3600
        val m = (t % 3600) / 60
        val s = t % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s) else String.format(Locale.US, "%d:%02d", m, s)
    }

    // ---- menus: speed, tracks, more -----------------------------------------------------------

    private fun showSpeedMenu() {
        val values = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
        val labels = values.map { speedLabel(it) }.toTypedArray()
        var checked = values.indexOfFirst { it == speed }
        if (checked < 0) checked = 2
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.player_speed))
            .setSingleChoiceItems(labels, checked) { d, which ->
                speed = values[which]
                player?.setPlaybackSpeed(speed)
                speedBtn.text = speedLabel(speed)
                d.dismiss()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun speedLabel(v: Float): String =
        if (v == v.toInt().toFloat()) v.toInt().toString() + "×" else v.toString() + "×"

    private fun trackName(f: Format, n: Int): String {
        val lang = f.language
        val langName = if (!lang.isNullOrEmpty() && lang != "und") Locale.forLanguageTag(lang).getDisplayLanguage(Locale.getDefault()) else ""
        val base = when {
            !f.label.isNullOrEmpty() -> f.label.toString()
            langName.isNotEmpty() -> langName
            else -> getString(R.string.player_track_fmt, n)
        }
        return if (f.channelCount > 0) "$base  (${f.channelCount}ch)" else base
    }

    private fun selectTextTrack(p: Player, g: Tracks.Group, i: Int) {
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i))
            .build()
    }

    private fun showTrackMenu(type: Int) {
        val p = player ?: return
        val isText = type == C.TRACK_TYPE_TEXT
        val labels = ArrayList<String>()
        val entries = ArrayList<Pair<Tracks.Group, Int>>()
        var checked = -1
        if (isText) labels.add(getString(R.string.player_off))
        for (g in p.currentTracks.groups) {
            if (g.type != type) continue
            for (i in 0 until g.length) {
                if (!g.isTrackSupported(i)) continue
                entries.add(Pair(g, i))
                labels.add(trackName(g.getTrackFormat(i), entries.size))
                if (g.isTrackSelected(i)) checked = labels.size - 1
            }
        }
        if (entries.isEmpty()) {
            Toast.makeText(this, getString(R.string.player_no_tracks), Toast.LENGTH_SHORT).show()
            if (!isText) return
        }
        if (isText && (checked < 0 || p.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT))) checked = 0
        AlertDialog.Builder(this)
            .setTitle(getString(if (isText) R.string.player_subs else R.string.player_audio))
            .setSingleChoiceItems(labels.toTypedArray(), checked) { d, which ->
                if (isText && which == 0) {
                    p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                        .build()
                    subtitleView.text = ""
                    subtitleView.visibility = View.GONE
                } else {
                    val (g, i) = entries[if (isText) which - 1 else which]
                    if (isText) {
                        selectTextTrack(p, g, i)
                    } else {
                        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                            .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i))
                            .build()
                    }
                }
                d.dismiss()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showMoreMenu() {
        val labels = ArrayList<String>()
        labels.add(getString(R.string.player_open_file))
        labels.add(getString(R.string.player_open_link))
        if (!isImage) labels.add(getString(R.string.player_add_sub))
        if (!isImage) labels.add(getString(R.string.player_sub_size_fmt, subSize))
        labels.add(getString(if (aspectFill) R.string.player_aspect_fill else R.string.player_aspect_fit))
        if (!isImage) labels.add(getString(if (tapPlays) R.string.player_tap_play else R.string.player_tap_controls))
        val keys = ArrayList<String>()
        keys.add("file"); keys.add("link")
        if (!isImage) { keys.add("sub"); keys.add("subsize") }
        keys.add("aspect")
        if (!isImage) keys.add("tap")
        AlertDialog.Builder(this)
            .setItems(labels.toTypedArray()) { _, which ->
                when (keys[which]) {
                    "file" -> pickFile()
                    "link" -> showLinkDialog(false)
                    "sub" -> pickSubtitle()
                    "subsize" -> {
                        subSize = if (subSize >= 32) 14 else subSize + 4
                        subtitleView.textSize = subSize.toFloat()
                        prefs.edit().putInt("subSize", subSize).apply()
                        Toast.makeText(this, getString(R.string.player_sub_size_fmt, subSize), Toast.LENGTH_SHORT).show()
                    }
                    "aspect" -> {
                        aspectFill = !aspectFill
                        prefs.edit().putBoolean("aspectFill", aspectFill).apply()
                        if (vw > 0) rebuildView()
                    }
                    "tap" -> {
                        tapPlays = !tapPlays
                        prefs.edit().putBoolean("tapPlays", tapPlays).apply()
                        Toast.makeText(this, getString(if (tapPlays) R.string.player_tap_play else R.string.player_tap_controls), Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .show()
    }

    // ---- external subtitles -------------------------------------------------------------------

    private fun addSubtitle(u: Uri) {
        val name = displayName(u)
        Thread {
            val f = runCatching { normalizeSubtitle(u, name) }.getOrNull()
            ui.post {
                if (isDestroyed) return@post
                if (f == null) {
                    Toast.makeText(this, getString(R.string.player_error), Toast.LENGTH_LONG).show()
                } else {
                    val cfg = MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(f))
                        .setMimeType(subtitleMime(name))
                        .setLabel(name)
                        .build()
                    subs.add(cfg)
                    pendingSubLabel = name
                    reloadMedia()
                    Toast.makeText(this, getString(R.string.player_sub_added), Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    /** Re-prepares the current item (with the external subtitle list) and keeps position and play state. */
    private fun reloadMedia() {
        val p = player ?: return
        val u = currentUri ?: return
        val pos = p.currentPosition
        val play = p.playWhenReady
        val item = MediaItem.Builder().setUri(u).setSubtitleConfigurations(subs.toList()).build()
        p.setMediaItem(item, pos)
        p.prepare()
        p.playWhenReady = play
    }

    private fun subtitleMime(name: String): String {
        val n = name.lowercase(Locale.US)
        return when {
            n.endsWith(".vtt") -> "text/vtt"
            n.endsWith(".ass") || n.endsWith(".ssa") -> "text/x-ssa"
            n.endsWith(".ttml") || n.endsWith(".xml") || n.endsWith(".dfxp") -> "application/ttml+xml"
            else -> "application/x-subrip"
        }
    }

    /**
     * Subtitle files from the web are often not UTF-8 (Windows-1256 for Persian / Arabic, Windows-1252 for
     * Western languages). The player expects UTF-8, so the file is decoded here and rewritten to cache.
     */
    private fun normalizeSubtitle(u: Uri, name: String): File {
        val raw = (openStream(u) ?: error("cannot open")).use { it.readBytes() }
        var data = raw
        val text: String = when {
            data.size >= 3 && data[0] == 0xEF.toByte() && data[1] == 0xBB.toByte() && data[2] == 0xBF.toByte() -> {
                data = data.copyOfRange(3, data.size)
                String(data, Charsets.UTF_8)
            }
            data.size >= 2 && data[0] == 0xFF.toByte() && data[1] == 0xFE.toByte() -> String(data, 2, data.size - 2, Charsets.UTF_16LE)
            data.size >= 2 && data[0] == 0xFE.toByte() && data[1] == 0xFF.toByte() -> String(data, 2, data.size - 2, Charsets.UTF_16BE)
            else -> try {
                Charsets.UTF_8.newDecoder()
                    .onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT)
                    .decode(ByteBuffer.wrap(data))
                    .toString()
            } catch (e: CharacterCodingException) {
                val lang = resources.configuration.locales[0].language
                val cs = if (lang == "fa" || lang == "ar") "windows-1256" else "windows-1252"
                String(data, Charset.forName(cs))
            }
        }
        val ext = when {
            name.lowercase(Locale.US).endsWith(".vtt") -> "vtt"
            name.lowercase(Locale.US).endsWith(".ass") -> "ass"
            name.lowercase(Locale.US).endsWith(".ssa") -> "ssa"
            name.lowercase(Locale.US).endsWith(".ttml") -> "ttml"
            else -> "srt"
        }
        val f = File(cacheDir, "sub_" + System.nanoTime() + "." + ext)
        f.writeText(text, Charsets.UTF_8)
        return f
    }

    // ---- lifecycle ----------------------------------------------------------------------------

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (vw > 0 && vh > 0) root.post { rebuildView() }
    }

    override fun onResume() {
        super.onResume()
        ui.post(ticker)
    }

    override fun onPause() {
        ui.removeCallbacks(ticker)
        ui.removeCallbacks(hideRunnable)
        savePosition()
        player?.pause()
        super.onPause()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        teardownView()
        player?.release()
        player = null
        bitmap = null
        runCatching { cacheDir.listFiles()?.forEach { if (it.name.startsWith("sub_")) it.delete() } }
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (panel.visibility == View.VISIBLE) {
            panel.visibility = View.GONE
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }

    private companion object {
        const val REQ_PICK = 21
        const val REQ_SUB = 22
        /** Long-side cap for decoded photos (keeps GPU textures within every device's limit). */
        const val MAX_SIDE = 4096
    }
}
