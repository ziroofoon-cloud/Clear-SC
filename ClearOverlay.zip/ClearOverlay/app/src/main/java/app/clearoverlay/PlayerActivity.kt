package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.app.PendingIntent
import android.app.PictureInPictureParams
import android.app.RemoteAction
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.graphics.drawable.Icon
import android.util.Rational
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.media.AudioManager
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewConfiguration
import android.view.ScaleGestureDetector
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.webkit.MimeTypeMap
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.text.CueGroup
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import java.io.File
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.text.SimpleDateFormat
import java.util.Date
import java.util.concurrent.atomic.AtomicBoolean
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Built-in video / photo player. The file or stream is decoded directly (no screen capture), then goes
 * through the same GPU pipeline as the overlay (denoise / deband / anti-aliasing -> FSR 1 / SGSR 1 /
 * bilinear upscale -> sharpen -> vivid colors), so a low-resolution source is upscaled from its real pixels.
 *
 *  - Engine: Media3 ExoPlayer (local files, direct links, HLS, DASH, mkv/mp4/webm ...), output surface =
 *    [GlPipeline] input, shown in a TextureView.
 *  - Subtitles: embedded tracks or an external .srt / .vtt / .ass file (re-encoded to UTF-8 when needed),
 *    drawn by a TextView on top of the processed picture.
 *  - Gestures: tap, double tap, horizontal drag (seek), vertical drag (left = brightness, right = volume),
 *    long press (2x speed while held).
 *  - Photos: decoded with BitmapFactory (EXIF-rotated, long side capped) and drawn once into the pipeline.
 */
class PlayerActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())

    private lateinit var root: FrameLayout
    private lateinit var stage: FrameLayout
    private lateinit var titleView: TextView
    private lateinit var topBar: LinearLayout
    private lateinit var fxBtn: TextView
    private lateinit var bar: LinearLayout
    private lateinit var seekRow: LinearLayout
    private lateinit var playBtn: TextView
    private lateinit var seek: SeekBar
    private lateinit var curText: TextView
    private lateinit var durText: TextView
    private lateinit var speedBtn: TextView
    private lateinit var subtitleView: TextView
    private lateinit var hud: TextView
    private lateinit var spinner: ProgressBar
    private lateinit var panel: FadePanel
    private val videoOnly = ArrayList<View>()
    private lateinit var shotBtn: TextView

    private var tv: TextureView? = null
    private var gl: GlPipeline? = null
    private var outSurface: Surface? = null
    private var player: ExoPlayer? = null

    private var currentUri: Uri? = null
    private val subs = ArrayList<MediaItem.SubtitleConfiguration>()
    private var pendingSubLabel: String? = null

    private var isImage = false
    private var bitmap: Bitmap? = null
    /** The photo as decoded from the file (before Smart fix / AI); [bitmap] is what is shown and saved. */
    private var baseBitmap: Bitmap? = null
    private var busy = false
    private val aiCancel = AtomicBoolean(false)
    private val imageOnly = ArrayList<View>()
    /** Previous / next buttons: only useful when a playlist exists. */
    private val navViews = ArrayList<View>()
    private lateinit var rotBtn: TextView
    private var vw = 0
    private var vh = 0
    private var vpar = 1f
    private var hasMedia = false
    // playlist (always one type: only videos or only photos) + Auto state
    private val playlist = ArrayList<Uri>()
    private var playIndex = -1
    /** The playlist is the growing result of a streaming upscale ([ExportState.segs]); see [syncStream]. */
    private var streamJob = false
    /** Streaming: the spot (microseconds of the whole video) the viewer asked for, while no finished piece covers it; -1 = none. */
    private var pendingSeekUs = -1L
    /** Streaming: where in the next piece to start (ms), -1 = the saved position. */
    private var startAtMs = -1L
    /** Streaming: the pieces that are in the player's playlist, in order (the picture view stays open while pieces are added and removed). */
    private val streamItems = ArrayList<ExportSeg>()
    private var exitAsked = false
    private var fromLibrary = false
    private var autoBudgetCap = Profiles.QUALITY
    private var lastAutoDown = 0L
    private var panelBuilt = false
    private var dragging = false
    private var controlsOn = true
    private var fxSwitch: Switch? = null
    private var tapSwitch: Switch? = null
    private var rotAxis = -1       // -1 follows the media's shape, 0 landscape, 1 portrait
    private var rotLock = false    // keep exactly the current direction
    private var rotFree = false    // follow the phone in every direction
    private lateinit var lockBtn: TextView
    private val panelVideoOnly = ArrayList<View>() // settings rows that mean nothing for a photo
    private lateinit var freeBtn: TextView
    private lateinit var miniHud: TextView
    private val miniHide = Runnable { if (::miniHud.isInitialized) miniHud.visibility = View.GONE }
    private var firstFrame = false
    private var stallTries = 0
    private lateinit var zoomBtn: TextView
    private lateinit var toolsBtn: ImageView
    private var zoom = 1f
    private var zoomCx = 0.5f
    private var zoomCy = 0.5f
    private var pinching = false
    // safe-area insets (camera cutout, status / navigation bars): controls are kept clear of them
    private var insL = 0
    private var insT = 0
    private var insR = 0
    private var insB = 0

    // player settings (saved)
    private var tapPlays = true
    /** Picture size: 0 fit, 1 fill (crop edges), 2 stretch to the screen, 3 = 16:9, 4 = 4:3, 5 = 21:9. Videos only; photos are always fitted. */
    private var aspectMode = 0
    private var aspectBtn: TextView? = null
    /** Size of the stage the picture view was last built for: when it changes (rotation) the view is rebuilt. */
    private var builtStageW = 0
    private var builtStageH = 0
    private var subSize = 18
    private var speed = 1f

    // gesture state
    private var gestureMode = 0 // 0 none, 1 seek, 2 brightness, 3 volume
    // photo swipe (a slow drag also counts, not only a fast fling)
    private var swipeDownX = 0f
    private var swipeDownY = 0f
    private var swipeDone = false
    private var swipeMulti = false
    private var lastStepAt = 0L
    private var seekStartPos = 0L
    private var seekTarget = 0L
    private var brightStart = 0.5f
    private var volStart = 0
    private var holding = false
    private var holdPrevSpeed = 1f

    private val prefs by lazy { getSharedPreferences("crsc_player", Context.MODE_PRIVATE) }
    private val audio by lazy { getSystemService(AudioManager::class.java) }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    private val ticker = object : Runnable {
        override fun run() {
            tick()
            ui.postDelayed(this, 200)
        }
    }

    private val hideRunnable = Runnable {
        if (panel.visibility != View.VISIBLE && isPlaying() && vw > 0) setControlsVisible(false)
    }

    /** Settings panel: back to full opacity shortly after a slider is released. */
    private val panelRestore = Runnable {
        panel.animate().alpha(1f).setDuration(200).start()
        schedulePanelIdle()
    }

    /** Settings panel: fades out and closes itself after a few idle seconds (when fading is enabled). */
    private val panelIdleHide = Runnable {
        if (panel.visibility == View.VISIBLE && Cfg.panelAutoClose) {
            panel.animate().alpha(0f).setDuration(250).withEndAction { hidePanel() }.start()
        }
    }

    /** The decoder may not report a size until it has a surface, so if nothing created the picture view yet, make it anyway. */
    private val sizeFallback = Runnable { ensureViewFallback() }

    private val hudHide = Runnable { hud.visibility = View.GONE }

    /**
     * Some videos start with a black picture or a spinner that never ends (the decoder and the picture surface
     * missed each other). If no frame has been drawn a few seconds after starting, redo what stopping and starting
     * by hand does: re-attach the picture surface, then nudge the decoder, then reload the file at the same spot.
     */
    private val stallCheck = object : Runnable {
        override fun run() {
            val p = player ?: return
            if (isDestroyed || isImage || !hasMedia || firstFrame) return
            val st = p.playbackState
            if (st == Player.STATE_ENDED || st == Player.STATE_IDLE) return
            // a file with no picture at all (audio only) never draws a frame: leave it alone
            if (st == Player.STATE_READY && !p.currentTracks.isTypeSelected(C.TRACK_TYPE_VIDEO)) return
            stallTries++
            when (stallTries) {
                1 -> if (vw > 0) rebuildView() else ensureViewFallback()
                2 -> p.seekTo(p.currentPosition)
                else -> {
                    val pos = p.currentPosition
                    p.stop()
                    p.prepare()
                    p.seekTo(pos)
                    p.playWhenReady = true
                }
            }
            if (stallTries < 4) ui.postDelayed(this, 2500)
        }
    }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            setPlayIcon(isPlaying)
            if (isPlaying) scheduleHide() else ui.removeCallbacks(hideRunnable)
            updatePip()
        }

        override fun onRenderedFirstFrame() {
            firstFrame = true
            ui.removeCallbacks(stallCheck)
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            spinner.visibility = if (playbackState == Player.STATE_BUFFERING) View.VISIBLE else View.GONE
            if (playbackState == Player.STATE_READY) ensureViewFallback()
            if (playbackState == Player.STATE_ENDED) {
                if (streamJob) {
                    syncStream()
                    if (!streamAtVideoEnd()) { // the next piece is not ready yet: this is waiting, not the end
                        spinner.visibility = View.VISIBLE
                        return
                    }
                }
                setPlayIcon(false)
                setControlsVisible(true)
                if (!streamJob && Cfg.autoNext && playIndex in 0 until playlist.size - 1) step(1)
            }
        }

        override fun onVideoSizeChanged(videoSize: VideoSize) {
            val par = if (videoSize.pixelWidthHeightRatio > 0f) videoSize.pixelWidthHeightRatio else 1f
            applyMediaSize(videoSize.width, videoSize.height, par)
        }

        override fun onCues(cueGroup: CueGroup) {
            val sb = StringBuilder()
            for (c in cueGroup.cues) {
                val t = c.text ?: continue
                if (sb.isNotEmpty()) sb.append('\n')
                sb.append(t.toString())
            }
            subtitleView.text = sb.toString()
            subtitleView.visibility = if (sb.isEmpty()) View.GONE else View.VISIBLE
        }

        override fun onTracksChanged(tracks: Tracks) {
            if (!isImage && tv == null) sizeFromTracks(tracks)
            val label = pendingSubLabel ?: return
            val p = player ?: return
            for (g in tracks.groups) {
                if (g.type != C.TRACK_TYPE_TEXT) continue
                for (i in 0 until g.length) {
                    if (g.getTrackFormat(i).label == label) {
                        pendingSubLabel = null
                        selectTextTrack(p, g, i)
                        return
                    }
                }
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            Toast.makeText(
                this@PlayerActivity,
                getString(R.string.player_error) + "\n" + (error.message ?: error.errorCodeName),
                Toast.LENGTH_LONG
            ).show()
            spinner.visibility = View.GONE
            setControlsVisible(true)
        }
    }

    private val scaleDetector by lazy {
        ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                setZoom(zoom * d.scaleFactor, true)
                return true
            }
        })
    }

    private val gesture by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                onSingleTap(e.y)
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (isImage) return true
                val w = root.width.toFloat()
                when {
                    e.x < w / 3f -> seekBy(-10_000L)
                    e.x > w * 2f / 3f -> seekBy(10_000L)
                    else -> togglePlay()
                }
                return true
            }

            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                // photos: swipe left = next, swipe right = previous (only when not zoomed in)
                if (!isImage || zoom > 1.01f || e1 == null || busy || swipeDone) return false
                val dx = e2.x - e1.x
                if (abs(vx) > 350f && abs(vx) > abs(vy) * 1.2f && abs(dx) > dp(this@PlayerActivity, 36)) {
                    swipeDone = true
                    step(if (dx < 0) 1 else -1)
                    return true
                }
                return false
            }

            override fun onLongPress(e: MotionEvent) {
                val p = player ?: return
                if (isImage || !p.isPlaying) return
                holding = true
                holdPrevSpeed = speed
                p.setPlaybackSpeed(2f)
                showHud("2×", sticky = true)
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
                if (zoom > 1.01f) {
                    // zoomed in: one finger pans instead of seeking / brightness / volume
                    val v = tv
                    val vwPx = (v?.width ?: root.width).toFloat().coerceAtLeast(1f)
                    val vhPx = (v?.height ?: root.height).toFloat().coerceAtLeast(1f)
                    zoomCx += distanceX / (vwPx * zoom)
                    zoomCy -= distanceY / (vhPx * zoom)
                    applyZoom()
                    return true
                }
                if (e1 == null || isImage) return false
                val p = player ?: return false
                val w = root.width.toFloat().coerceAtLeast(1f)
                val h = root.height.toFloat().coerceAtLeast(1f)
                val totalX = e2.x - e1.x
                val totalY = e2.y - e1.y
                if (gestureMode == 0) {
                    val slop = ViewConfiguration.get(this@PlayerActivity).scaledTouchSlop
                    if (abs(totalX) < slop && abs(totalY) < slop) return true
                    gestureMode = when {
                        abs(totalX) > abs(totalY) -> 1
                        e1.x < w / 2f -> 2
                        else -> 3
                    }
                    when (gestureMode) {
                        1 -> {
                            seekStartPos = p.currentPosition
                            seekTarget = seekStartPos
                        }
                        2 -> brightStart = currentBrightness()
                        3 -> volStart = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
                    }
                }
                when (gestureMode) {
                    1 -> {
                        val dur = p.duration
                        val upper = if (dur > 0) dur else Long.MAX_VALUE
                        seekTarget = (seekStartPos + (totalX / w * 120_000f).toLong()).coerceIn(0L, upper)
                        val diff = (seekTarget - seekStartPos) / 1000L
                        showHud(fmt(seekTarget) + "  (" + String.format(Locale.US, "%+d", diff) + " s)")
                    }
                    2 -> {
                        val v = (brightStart - totalY / (h * 0.8f)).coerceIn(0.02f, 1f)
                        setBrightness(v)
                        showHud(getString(R.string.player_brightness_fmt, (v * 100).roundToInt()))
                    }
                    3 -> {
                        val maxV = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        val v = (volStart + (-totalY / (h * 0.8f)) * maxV).roundToInt().coerceIn(0, maxV)
                        audio.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0)
                        showHud(getString(R.string.player_volume_fmt, if (maxV > 0) v * 100 / maxV else 0))
                    }
                }
                return true
            }
        })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Cfg.bind(this, "video")
        Ui.init(this, forceDark = true) // the player sits on black: always the dark colours
        tapPlays = prefs.getBoolean("tapPlays", true)
        aspectMode = prefs.getInt("aspectMode", 0).coerceIn(0, 5) // an old "fill" setting is dropped on purpose: it made landscape videos look zoomed in portrait
        subSize = prefs.getInt("subSize", 18).coerceIn(12, 36)
        if (prefs.contains("rot") && !prefs.contains("rot_axis")) {
            // older 5-state setting -> the new axis / lock / free settings
            val old = prefs.getInt("rot", 0)
            prefs.edit()
                .putInt("rot_axis", when (old) { 1 -> 0; 2 -> 1; else -> -1 })
                .putBoolean("rot_free", old == 3)
                .putBoolean("rot_lock", old == 4)
                .remove("rot")
                .apply()
        }
        // the kind of the first media decides which direction setting is read (photo / video), so a photo does not open
        // in the video's direction first and turn afterwards
        intent?.data?.let { first -> isImage = mimeOf(first).startsWith("image/") }
        loadRotation()
        if (rotAxis >= 0 || rotLock || rotFree) applyRotation()
        volumeControlStream = AudioManager.STREAM_MUSIC

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.setDecorFitsSystemWindows(false)
        window.attributes = window.attributes.also {
            it.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        stage = FrameLayout(this)
        stage.addOnLayoutChangeListener { v, _, _, _, _, _, _, _, _ ->
            // rotation / split screen: rebuild the picture view for the new size (once the layout is final)
            if (vw > 0 && vh > 0 && tv != null && (v.width != builtStageW || v.height != builtStageH)) {
                ui.post { if (!isDestroyed && vw > 0 && vh > 0 && (stage.width != builtStageW || stage.height != builtStageH)) rebuildView() }
            }
        }
        root.addView(stage, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    swipeDownX = ev.x; swipeDownY = ev.y; swipeDone = false; swipeMulti = false
                }
                MotionEvent.ACTION_POINTER_DOWN -> swipeMulti = true
                MotionEvent.ACTION_UP -> {
                    val dx = ev.x - swipeDownX
                    val dy = ev.y - swipeDownY
                    if (isImage && !swipeDone && !swipeMulti && !pinching && zoom <= 1.01f && !busy &&
                        abs(dx) > dp(this, 48) && abs(dx) > abs(dy) * 1.2f
                    ) {
                        swipeDone = true
                        step(if (dx < 0) 1 else -1)
                    }
                }
            }
            scaleDetector.onTouchEvent(ev)
            if ((ev.pointerCount > 1 || scaleDetector.isInProgress) && !pinching) {
                // second finger: switch from the one-finger gestures to pinch zoom
                pinching = true
                val c = MotionEvent.obtain(ev)
                c.action = MotionEvent.ACTION_CANCEL
                gesture.onTouchEvent(c)
                c.recycle()
                gestureMode = 0
                endGesture()
            }
            if (!pinching) gesture.onTouchEvent(ev)
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                endGesture()
                pinching = false
            }
            true
        }

        // ---- subtitles
        subtitleView = TextView(this).apply {
            visibility = View.GONE
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            setTextColor(Color.WHITE)
            setShadowLayer(6f, 0f, 0f, Color.BLACK)
            setBackgroundColor(Color.parseColor("#66000000"))
            setPadding(dp(this@PlayerActivity, 8), dp(this@PlayerActivity, 2), dp(this@PlayerActivity, 8), dp(this@PlayerActivity, 2))
            textSize = subSize.toFloat()
        }
        root.addView(
            subtitleView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
                bottomMargin = dp(this@PlayerActivity, 36)
                leftMargin = dp(this@PlayerActivity, 24)
                rightMargin = dp(this@PlayerActivity, 24)
            }
        )

        // ---- top bar: title + FX on/off + rotation + settings + menu
        titleView = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setShadowLayer(6f, 0f, 0f, Color.BLACK)
        }
        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        topBar.addView(
            titleView,
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(this@PlayerActivity, 8) }
        )
        fxBtn = topButton("FX") { setFx(!Cfg.playerFx) }
        topBar.addView(fxBtn)
        // zoom / screenshot / rotation / lock / free rotation / edit video live behind ONE tools button (less clutter on the picture);
        // the old buttons stay as hidden objects so their state painting keeps working
        zoomBtn = topButton("1×") { cycleZoom() }
        shotBtn = topButton("📷") { videoShot() }
        rotBtn = topButton("↔") { cycleRotation() }
        lockBtn = topButton("🔒") { toggleRotLock() }
        freeBtn = topButton("⟳") { toggleRotFree() }
        toolsBtn = iconTop(Icons.EDIT) { showToolsMenu() }
        topBar.addView(toolsBtn)
        paintRot()
        miniHud = TextView(this).apply {
            textSize = 11f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(this@PlayerActivity, 10), dp(this@PlayerActivity, 3), dp(this@PlayerActivity, 10), dp(this@PlayerActivity, 3))
            background = Ui.round(Color.parseColor("#80000000"), dp(this@PlayerActivity, 10).toFloat())
            visibility = View.GONE
        }
        root.addView(
            miniHud,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
                topMargin = dp(this@PlayerActivity, 64)
            }
        )
        topBar.addView(iconTop(Icons.GEAR) { togglePanel() })
        topBar.addView(iconTop(Icons.MORE) { showMoreMenu() })
        root.addView(
            topBar,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP).apply {
                val m = dp(this@PlayerActivity, 12)
                setMargins(m, dp(this@PlayerActivity, 4), m, 0)
            }
        )
        paintFx()

        // ---- centre HUD + buffering spinner
        hud = TextView(this).apply {
            visibility = View.GONE
            setTextColor(Color.WHITE)
            textSize = 20f
            gravity = Gravity.CENTER
            background = Ui.round(Color.parseColor("#B30B1020"), dp(this@PlayerActivity, 14).toFloat())
            setPadding(dp(this@PlayerActivity, 18), dp(this@PlayerActivity, 10), dp(this@PlayerActivity, 18), dp(this@PlayerActivity, 10))
        }
        root.addView(hud, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        spinner = ProgressBar(this).apply {
            visibility = View.GONE
            indeterminateTintList = ColorStateList.valueOf(Ui.ACCENT)
        }
        root.addView(spinner, FrameLayout.LayoutParams(dp(this, 48), dp(this, 48), Gravity.CENTER))

        // ---- bottom bar: seek row + button row
        bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            isClickable = true
            // stuck to the bottom edge (and the sides): only the top corners are round
            val rr = dp(this@PlayerActivity, 14).toFloat()
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.parseColor("#E60B1020"))
                cornerRadii = floatArrayOf(rr, rr, rr, rr, 0f, 0f, 0f, 0f)
            }
            setPadding(dp(this@PlayerActivity, 10), dp(this@PlayerActivity, 4), dp(this@PlayerActivity, 10), dp(this@PlayerActivity, 6))
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        curText = Ui.text(this, "0:00", 11f, Ui.MUTED)
        durText = Ui.text(this, "0:00", 11f, Ui.MUTED)
        seek = SeekBar(this).apply {
            max = 1000
            val tint = ColorStateList.valueOf(Ui.ACCENT)
            progressTintList = tint
            thumbTintList = tint
            progressBackgroundTintList = ColorStateList.valueOf(Ui.STROKE)
            secondaryProgressTintList = ColorStateList.valueOf(Ui.MUTED)
        }
        seekRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        seekRow.addView(curText)
        // a slim slider: fixed row height, small thumb, no extra touch padding around it
        seek.setPadding(dp(this, 8), 0, dp(this, 8), 0)
        seekRow.addView(seek, LinearLayout.LayoutParams(0, dp(this, 24), 1f).apply {
            marginStart = dp(this@PlayerActivity, 2)
            marginEnd = dp(this@PlayerActivity, 2)
        })
        seekRow.addView(durText)
        bar.addView(seekRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(this, 26)))
        videoOnly.add(seekRow)

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val b1 = barButton("−10") { seekBy(-10_000L) }
        playBtn = barButton("") { togglePlay() }
        Icons.glyphCentered(playBtn, Icons.PLAY, Ui.TEXT, 22)
        val b3 = barButton("+10") { seekBy(10_000L) }
        speedBtn = barButton("1×") { showSpeedMenu() }
        val b5 = barButton("CC") { showTrackMenu(C.TRACK_TYPE_TEXT) }
        val b6 = barButton("") { showTrackMenu(C.TRACK_TYPE_AUDIO) }
        Icons.glyphCentered(b6, Icons.MUSIC, Ui.TEXT, 20)
        val vPrev = barButton("") { step(-1) }
        Icons.glyphCentered(vPrev, Icons.PREV, Ui.TEXT, 20)
        val vNext = barButton("") { step(1) }
        Icons.glyphCentered(vNext, Icons.NEXT, Ui.TEXT, 20)
        for (b in listOf(vPrev, b1, playBtn, b3, vNext, speedBtn, b5, b6)) {
            if (b === vPrev || b === vNext) (b.layoutParams as LinearLayout.LayoutParams).weight = 0.8f
            buttons.addView(b)
            videoOnly.add(b)
        }
        navViews.add(vPrev)
        navViews.add(vNext)
        // photo tools (shown instead of the video buttons when a photo is open)
        val i1 = barButton(getString(R.string.img_enhance)) { showEnhanceMenu() }
        val i2 = barButton(getString(R.string.img_save)) { showSaveMenu() }
        val i3 = barButton(getString(R.string.img_original)) { restoreOriginal() }
        val iPrev = barButton("◀") { step(-1) }
        val iNext = barButton("▶") { step(1) }
        for (b in listOf(iPrev, i1, i2, i3, iNext)) {
            if (b === iPrev || b === iNext) (b.layoutParams as LinearLayout.LayoutParams).weight = 0.6f
            b.visibility = View.GONE
            buttons.addView(b)
            imageOnly.add(b)
        }
        navViews.add(iPrev)
        navViews.add(iNext)
        bar.addView(buttons, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(this@PlayerActivity, 2)
        })
        root.addView(
            bar,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
        )

        // ---- settings panel (built on first open)
        panel = FadePanel(this).apply {
            visibility = View.GONE
            isClickable = true
            background = Ui.round(Color.parseColor("#F5101522"), dp(this@PlayerActivity, 22).toFloat(), Ui.STROKE, dp(this@PlayerActivity, 1))
            setPadding(dp(this@PlayerActivity, 16), dp(this@PlayerActivity, 14), dp(this@PlayerActivity, 16), dp(this@PlayerActivity, 14))
        }
        panel.onTouch = { schedulePanelIdle() }
        root.addView(panel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    val d = if (streamJob) ExportState.totalUs / 1000L else player?.duration ?: 0L
                    if (d > 0) curText.text = fmt(p.toLong() * d / 1000L)
                }
            }

            override fun onStartTrackingTouch(s: SeekBar) {
                dragging = true
                ui.removeCallbacks(hideRunnable)
            }

            override fun onStopTrackingTouch(s: SeekBar) {
                if (streamJob) {
                    val total = ExportState.totalUs / 1000L
                    if (total > 0) streamSeek(s.progress.toLong() * total / 1000L)
                } else {
                    val d = player?.duration ?: 0L
                    if (d > 0) player?.seekTo(s.progress.toLong() * d / 1000L)
                }
                dragging = false
                gl?.redraw()
                scheduleHide()
            }
        })

        setContentView(root)
        root.post { applyInsets() }

        AudioCfg.load(this)
        MusicPlayer.player?.pause() // the music player and the video player must not play together
        val p = ExoPlayer.Builder(this, audioFxRenderersFactory(this))
            .setMediaSourceFactory(androidx.media3.exoplayer.source.DefaultMediaSourceFactory(RoutingDataSourceFactory(this)))
            .build()
        p.addListener(playerListener)
        p.addAnalyticsListener(object : AnalyticsListener {
            override fun onDroppedVideoFrames(eventTime: AnalyticsListener.EventTime, droppedFrames: Int, elapsedMs: Long) {
                if (!Cfg.autoMode || isImage || droppedFrames < 6) return
                val now = SystemClock.elapsedRealtime()
                if (now - lastAutoDown < 6000L || Cfg.profileBudget <= Profiles.PERF) return
                lastAutoDown = now
                ui.post { autoCap(Cfg.profileBudget - 1) }
            }
        })
        player = p

        fromLibrary = intent?.getBooleanExtra(PlayerArgs.FROM_LIB, false) == true
        val d = intent?.data
        val list = intent?.getStringArrayListExtra(PlayerArgs.LIST)
        if (d != null && intent?.getBooleanExtra(PlayerArgs.STREAM, false) == true) {
            streamJob = true
            ExportState.segs.firstOrNull { Uri.fromFile(it.file) == d }?.let { streamItems.add(it) }
            playlist.add(d)
            playIndex = 0
            open(d, keepList = true)
            ui.postDelayed(streamTick, 700)
        } else if (d != null && list != null && list.size > 1) {
            playlist.addAll(list.map { Uri.parse(it) })
            playIndex = intent.getIntExtra(PlayerArgs.INDEX, 0).coerceIn(0, playlist.size - 1)
            open(d, keepList = true)
        } else if (d != null) open(d) else showSourceDialog(cancelFinishes = true)
    }

    private fun barButton(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 14f
        gravity = Gravity.CENTER
        setTextColor(Ui.TEXT)
        background = Ui.round(Ui.CHIP, dp(this@PlayerActivity, 10).toFloat())
        setPadding(dp(this@PlayerActivity, 4), 0, dp(this@PlayerActivity, 4), 0)
        maxLines = 1
        layoutParams = LinearLayout.LayoutParams(0, dp(this@PlayerActivity, 38), 1f).apply {
            marginStart = dp(this@PlayerActivity, 3)
            marginEnd = dp(this@PlayerActivity, 3)
        }
        setOnClickListener {
            onClick()
            if (this !== playBtn) scheduleHide()
        }
    }

    /** Top-bar button drawn with the app's line icons (matches the rest of the app). */
    private fun iconTop(kind: Int, onClick: () -> Unit): ImageView = ImageView(this).apply {
        setImageDrawable(LineIcon(kind, Ui.TEXT))
        val p = dp(this@PlayerActivity, 8)
        setPadding(p, p, p, p)
        background = Ui.round(Color.parseColor("#B30B1020"), dp(this@PlayerActivity, 10).toFloat())
        layoutParams = LinearLayout.LayoutParams(dp(this@PlayerActivity, 42), dp(this@PlayerActivity, 38)).apply {
            marginStart = dp(this@PlayerActivity, 6)
        }
        setOnClickListener {
            onClick()
            scheduleHide()
        }
    }

    private fun topButton(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 15f
        gravity = Gravity.CENTER
        setTextColor(Ui.TEXT)
        background = Ui.round(Color.parseColor("#B30B1020"), dp(this@PlayerActivity, 10).toFloat())
        layoutParams = LinearLayout.LayoutParams(dp(this@PlayerActivity, 42), dp(this@PlayerActivity, 38)).apply {
            marginStart = dp(this@PlayerActivity, 6)
        }
        setOnClickListener {
            onClick()
            scheduleHide()
        }
    }

    // ---- choosing what to play ----------------------------------------------------------------

    private fun showSourceDialog(cancelFinishes: Boolean) {
        val items = arrayOf(getString(R.string.player_open_file), getString(R.string.player_open_link))
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.player_button))
            .setItems(items) { _, which -> if (which == 0) pickFile() else showLinkDialog(cancelFinishes) }
            .setOnCancelListener { if (cancelFinishes && !hasMedia) finish() }
            .show()
    }

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*")
            .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("video/*", "audio/*", "image/*"))
        @Suppress("DEPRECATION")
        startActivityForResult(i, REQ_PICK)
    }

    private fun pickSubtitle() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*")
        @Suppress("DEPRECATION")
        startActivityForResult(i, REQ_SUB)
    }

    private fun showLinkDialog(cancelFinishes: Boolean) {
        val input = EditText(this).apply {
            hint = "https://…"
            setSingleLine()
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            val clip = runCatching {
                getSystemService(ClipboardManager::class.java).primaryClip?.getItemAt(0)?.text?.toString()
            }.getOrNull()
            if (clip != null && (clip.startsWith("http://") || clip.startsWith("https://"))) setText(clip.trim())
        }
        val pad = dp(this, 20)
        val box = FrameLayout(this).apply { setPadding(pad, dp(this@PlayerActivity, 8), pad, 0) }
        box.addView(input, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.player_open_link))
            .setView(box)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val t = input.text.toString().trim()
                if (t.startsWith("http://") || t.startsWith("https://")) {
                    open(Uri.parse(t))
                } else {
                    Toast.makeText(this, getString(R.string.player_error), Toast.LENGTH_SHORT).show()
                    if (cancelFinishes && !hasMedia) finish()
                }
            }
            .setNegativeButton(android.R.string.cancel) { _, _ -> if (cancelFinishes && !hasMedia) finish() }
            .setOnCancelListener { if (cancelFinishes && !hasMedia) finish() }
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (ModelFiles.handle(this, req, res, data)) return
        if (TrashOps.handleResult(req, res)) return
        val u = data?.data
        when (req) {
            REQ_PICK -> if (res == RESULT_OK && u != null) open(u) else if (!hasMedia) finish()
            REQ_SUB -> if (res == RESULT_OK && u != null) addSubtitle(u)
            REQ_MODEL -> if (res == RESULT_OK && u != null) importModel(u)
        }
    }

    // ---- opening media ------------------------------------------------------------------------

    private fun mimeOf(u: Uri): String {
        val t = runCatching { contentResolver.getType(u) }.getOrNull()
        if (!t.isNullOrEmpty()) return t
        val ext = MimeTypeMap.getFileExtensionFromUrl(u.toString()).lowercase(Locale.US)
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: ""
    }

    private fun displayName(u: Uri): String {
        if (u.scheme == "content") {
            runCatching {
                contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val n = c.getString(0)
                        if (!n.isNullOrEmpty()) return n
                    }
                }
            }
        }
        return u.lastPathSegment ?: u.toString()
    }

    private fun open(u: Uri, keepList: Boolean = false) {
        closeMedia()
        hasMedia = true
        currentUri = u
        val wasImage = isImage
        isImage = mimeOf(u).startsWith("image/")
        if (isImage != wasImage) {
            // photos and videos each keep their own screen direction (photos are often portrait, videos landscape)
            loadRotation()
            applyRotation()
            paintRot()
        }
        // photos and videos each keep their own effect settings
        val sec = if (isImage) "photo" else "video"
        if (Cfg.section != sec) {
            Cfg.bind(this, sec)
            if (panelBuilt) {
                panel.removeAllViews()
                panelBuilt = false
            }
            if (::panel.isInitialized) layoutPanel() // each kind of media has its own panel size
        }
        if (!keepList) {
            playlist.clear()
            playIndex = -1
        }
        autoBudgetCap = Profiles.QUALITY
        titleView.text = displayName(u)
        updateTitle()
        for (v in videoOnly) v.visibility = if (isImage) View.GONE else View.VISIBLE
        for (v in imageOnly) v.visibility = if (isImage) View.VISIBLE else View.GONE
        for (v in panelVideoOnly) v.visibility = if (isImage) View.GONE else View.VISIBLE
        setControlsVisible(true)
        updateTitle() // after the visibility loops above: shows previous / next only when a playlist exists
        if (isImage) openImage(u) else startPlayback(u)
        if (!keepList) findSiblings(u)
    }

    /** "Open with" / picked files: look for the other files of the same type in the same folder (best effort). */
    private fun findSiblings(u: Uri) {
        val wantImage = isImage
        Thread {
            val r = Media.siblings(this, u, wantImage)
            ui.post {
                if (isDestroyed || currentUri != u || r == null) return@post
                playlist.clear()
                playlist.addAll(r.first)
                playIndex = r.second
                updateTitle()
            }
        }.start()
    }

    private fun updateTitle() {
        val base = currentUri?.let { displayName(it) } ?: ""
        titleView.text = if (playlist.size > 1 && playIndex >= 0) "$base  (${playIndex + 1}/${playlist.size})" else base
        val show = if (playlist.size > 1) View.VISIBLE else View.GONE
        // previous / next only appear when there is something to step to (and only for the current media type)
        for (v in navViews) {
            val photoBtn = imageOnly.contains(v)
            v.visibility = if (photoBtn == isImage) show else View.GONE
        }
    }

    private val streamTick = object : Runnable {
        override fun run() {
            if (isDestroyed || !streamJob) return
            syncStream()
            ui.postDelayed(this, 700)
        }
    }

    /**
     * Streaming upscale: tells the worker which spot of the video is being watched (so it knows how far ahead to go
     * and what it may delete), keeps the playlist equal to the pieces that exist, and moves on to a piece that was
     * not ready yet when the previous one ended.
     */
    private fun streamOriginUs(): Long = ExportState.job?.rangeStartUs ?: 0L

    private fun curSeg(): ExportSeg? = player?.let { streamItems.getOrNull(it.currentMediaItemIndex) }

    /** Where the viewer is in the whole video (or the chosen part), in ms. */
    private fun streamPosMs(): Long {
        val p = player ?: return 0L
        val seg = curSeg() ?: return 0L
        return (seg.startUs - streamOriginUs()) / 1000L + p.currentPosition
    }

    /** End (microseconds of the whole video) of the unbroken run of pieces that is in the player now. */
    private fun streamReadyEndUs(): Long = streamItems.lastOrNull()?.let { it.startUs + it.durUs } ?: 0L

    /** True when the last piece of the playlist is playing and it is the end of the video (or of the chosen part). */
    private fun streamAtVideoEnd(): Boolean {
        val p = player ?: return true
        val total = ExportState.totalUs
        return total > 0 && streamReadyEndUs() >= streamOriginUs() + total - 500_000L && p.currentMediaItemIndex >= streamItems.size - 1
    }

    private fun mediaItemOf(seg: ExportSeg): MediaItem = MediaItem.Builder().setUri(Uri.fromFile(seg.file)).build()

    /** [seg] and the pieces that follow it without a gap. */
    private fun runFrom(seg: ExportSeg): List<ExportSeg> {
        val l = arrayListOf(seg)
        var cur = seg
        while (true) {
            val n = segAt(cur.startUs + cur.durUs, 400_000L) ?: break
            if (n === cur || n in l) break
            l.add(n)
            cur = n
        }
        return l
    }

    /** The finished piece that covers [us] (microseconds of the whole video), if there is one. */
    private fun segAt(us: Long, tolUs: Long = 0L): ExportSeg? =
        ExportState.segs.filter { it.startUs <= us + tolUs && us < it.startUs + it.durUs }.maxByOrNull { it.startUs }

    /** Jumps to [relMs] of the timeline: inside a finished piece at once, otherwise the worker is asked to prepare that spot. */
    private fun streamSeek(relMs: Long) {
        val total = ExportState.totalUs / 1000L
        val t = (relMs.coerceIn(0L, if (total > 0) total else Long.MAX_VALUE)) * 1000L + streamOriginUs()
        ExportState.playUs = t
        val seg = segAt(t)
        if (seg != null) {
            pendingSeekUs = -1L
            playSeg(seg, (t - seg.startUs) / 1000L)
        } else if (ExportState.job?.stream != true) {
            toast(R.string.stream_not_ready) // a file export works from the start to the end: only finished parts can be played
        } else {
            pendingSeekUs = t
            ExportState.seekReq = t
            player?.pause()
            spinner.visibility = View.VISIBLE
        }
    }

    /**
     * Plays [seg] from [atMs]. Inside the pieces already in the player's playlist this is a plain seek; otherwise the playlist is
     * replaced (the picture view is NOT rebuilt, so there is no black flash). Only the very first piece opens the view.
     */
    private fun playSeg(seg: ExportSeg, atMs: Long) {
        val p = player ?: return
        val idx = streamItems.indexOf(seg)
        if (hasMedia && idx >= 0) {
            p.seekTo(idx, atMs)
            p.play()
        } else if (hasMedia) {
            val run = runFrom(seg)
            streamItems.clear()
            streamItems.addAll(run)
            p.setMediaItems(run.map { mediaItemOf(it) }, 0, atMs)
            p.prepare()
            p.play()
        } else {
            streamItems.clear()
            streamItems.add(seg)
            startAtMs = atMs
            playIndex = 0
            open(Uri.fromFile(seg.file), keepList = true)
        }
        gl?.redraw()
    }

    private fun syncStream() {
        val p = player ?: return
        val done = ExportState.result
        if (!ExportState.running && done != null && ExportState.job?.stream != true) {
            // the file export finished while it was watched: go on in the finished file at the same spot
            val pos = streamPosMs()
            streamJob = false
            streamItems.clear()
            pendingSeekUs = -1L
            startAtMs = pos
            open(done)
            return
        }
        val segsNow = ExportState.segs.sortedBy { it.startUs }
        if (segsNow.isEmpty()) return
        // the title / counter follows the pieces
        val uris = segsNow.map { Uri.fromFile(it.file) }
        if (uris != playlist.toList()) {
            playlist.clear()
            playlist.addAll(uris)
            playIndex = curSeg()?.let { segsNow.indexOf(it) }?.coerceAtLeast(0) ?: playIndex.coerceIn(0, uris.size - 1)
            updateTitle()
        }
        // waiting for a spot the worker is preparing
        if (pendingSeekUs >= 0L) {
            val seg = segAt(pendingSeekUs)
            if (seg != null) {
                val t = pendingSeekUs
                pendingSeekUs = -1L
                playSeg(seg, (t - seg.startUs) / 1000L)
            }
            return
        }
        // first piece: start playing it
        if (!hasMedia || streamItems.isEmpty()) {
            val first = segsNow[0]
            ExportState.playUs = first.startUs
            playSeg(first, 0L)
            return
        }
        // 1) pieces that the worker deleted (far behind the viewer) leave the playlist; the one that plays now never does
        val now = curSeg()
        for (i in streamItems.indices.reversed()) {
            val it = streamItems[i]
            if (it !== now && it !in segsNow) {
                p.removeMediaItem(i)
                streamItems.removeAt(i)
            }
        }
        // 2) pieces that were finished meanwhile are put at the end of the playlist: the player goes on by itself, without a gap
        var last = streamItems.lastOrNull() ?: return
        while (true) {
            val n = segAt(last.startUs + last.durUs, 400_000L) ?: break
            if (n === last || n in streamItems) break
            p.addMediaItem(mediaItemOf(n))
            streamItems.add(n)
            last = n
        }
        curSeg()?.let { ExportState.playUs = it.startUs + p.currentPosition * 1000L }
        // 3) the player reached the end of what was ready: go on with the next piece, or ask the worker for the spot
        if (p.playbackState == Player.STATE_ENDED) {
            val idx = p.currentMediaItemIndex
            if (idx < streamItems.size - 1) {
                p.seekTo(idx + 1, 0L)
                p.play()
            } else if (!streamAtVideoEnd()) {
                val endUs = streamReadyEndUs()
                pendingSeekUs = endUs
                ExportState.playUs = endUs
                ExportState.seekReq = endUs
                spinner.visibility = View.VISIBLE
            }
        }
    }

    // ---- save what a streaming upscale has prepared -------------------------------------------------

    /** Joins the pieces that exist now into video file(s) in Movies/ClearOverlay, then runs [then]. */
    private fun saveStreamReady(then: (() -> Unit)? = null) {
        if (ExportState.segs.isEmpty()) {
            Toast.makeText(this, R.string.stream_nothing, Toast.LENGTH_SHORT).show()
            then?.invoke()
            return
        }
        ExportState.saving = true // no piece is deleted while they are joined
        val dlg = AlertDialog.Builder(this).setMessage(R.string.stream_saving).setCancelable(false).show()
        Thread {
            val files = runCatching { ExportState.saveReady(this) }.getOrDefault(emptyList())
            ui.post {
                runCatching { dlg.dismiss() }
                Toast.makeText(this, if (files.isEmpty()) getString(R.string.stream_save_failed) else getString(R.string.stream_saved_fmt, files.size), Toast.LENGTH_LONG).show()
                then?.invoke()
            }
        }.start()
    }

    /** Leaving a streaming upscale: asks whether to save what was prepared (it is deleted otherwise). */
    private fun askStreamExit(): Boolean {
        if (!streamJob || ExportState.job?.stream != true || exitAsked || ExportState.segs.isEmpty()) return false
        AlertDialog.Builder(this)
            .setMessage(R.string.stream_exit_ask)
            .setPositiveButton(R.string.stream_exit_save) { _, _ ->
                saveStreamReady {
                    exitAsked = true
                    finish()
                }
            }
            .setNegativeButton(R.string.stream_exit_discard) { _, _ ->
                exitAsked = true
                finish()
            }
            .setNeutralButton(R.string.stream_exit_stay, null)
            .show()
        return true
    }

    /** Previous (-1) / next (+1) item of the playlist; videos and photos are never mixed in one playlist. */
    private fun step(d: Int) {
        if (playlist.size < 2 || streamJob) return
        // one swipe = one photo: ignore a second trigger of the same gesture (touch-up + fling) arriving right after
        val now = SystemClock.elapsedRealtime()
        if (now - lastStepAt < 350L) return
        lastStepAt = now
        if (busy) { toast(R.string.img_busy); return }
        val n = playIndex + d
        if (n !in 0 until playlist.size) {
            showHud(getString(if (d > 0) R.string.list_last else R.string.list_first))
            return
        }
        playIndex = n
        open(playlist[n], keepList = true)
    }

    private fun startPlayback(u: Uri) {
        val p = player ?: return
        val item = MediaItem.Builder().setUri(u).setSubtitleConfigurations(subs.toList()).build()
        val start = if (startAtMs >= 0L) startAtMs else if (streamJob) 0L else prefs.getLong(posKey(u), 0L)
        startAtMs = -1L
        p.setMediaItem(item, start)
        p.setPlaybackSpeed(speed)
        p.prepare()
        p.playWhenReady = true
        spinner.visibility = View.VISIBLE
        ui.removeCallbacks(sizeFallback)
        ui.postDelayed(sizeFallback, 1500)
        firstFrame = false
        stallTries = 0
        ui.removeCallbacks(stallCheck)
        ui.postDelayed(stallCheck, 3000)
    }

    private fun closeMedia() {
        savePosition()
        ui.removeCallbacks(hideRunnable)
        ui.removeCallbacks(sizeFallback)
        ui.removeCallbacks(stallCheck)
        teardownView()
        player?.let {
            it.stop()
            it.clearMediaItems()
        }
        subs.clear()
        pendingSubLabel = null
        aiCancel.set(true)
        bitmap = null
        baseBitmap = null
        zoom = 1f
        zoomCx = 0.5f
        zoomCy = 0.5f
        if (::zoomBtn.isInitialized) zoomBtn.text = "1×"
        vw = 0
        vh = 0
        vpar = 1f
        seek.progress = 0
        seek.secondaryProgress = 0
        curText.text = "0:00"
        durText.text = "0:00"
        subtitleView.text = ""
        subtitleView.visibility = View.GONE
        spinner.visibility = View.GONE
    }

    private fun posKey(u: Uri) = "pos_" + u.toString().hashCode()

    private fun savePosition() {
        if (streamJob) return // the pieces of a streaming upscale are temporary: nothing to resume
        val u = currentUri ?: return
        val p = player ?: return
        if (isImage || !hasMedia) return
        val dur = p.duration
        val pos = p.currentPosition
        val e = prefs.edit()
        if (dur > 0 && pos > 5_000L && pos < dur - 5_000L) {
            e.putLong(posKey(u), pos)
            History.put(this, History.Entry(0, u.toString(), displayName(u), pos, dur, System.currentTimeMillis()))
        } else {
            e.remove(posKey(u))
            if (dur > 0 && pos >= dur - 5_000L) History.remove(this, 0, u.toString())
        }
        e.apply()
    }

    // ---- photos -------------------------------------------------------------------------------

    private fun openImage(u: Uri) {
        Thread {
            val bmp = runCatching { decodeImage(u) }.getOrNull()
            ui.post {
                if (isDestroyed || !isImage || currentUri != u) return@post
                if (bmp == null) {
                    fail()
                } else {
                    baseBitmap = bmp
                    bitmap = bmp
                    vw = bmp.width
                    vh = bmp.height
                    vpar = 1f
                    applyRotation()
                    rebuildView()
                    if (Cfg.autoMode) {
                        applyAuto(true)
                        // a very small photo is AI-upscaled right away (few tiles = quick), with the model that suits its size
                        if (Cfg.autoAiSmall && Auto.smallEnoughForAuto(bmp.width, bmp.height) && AiSr.hasModel(this)) {
                            ui.postDelayed({ if (!isDestroyed && isImage && currentUri == u && !busy && bitmap === baseBitmap) startAi() }, 900)
                        }
                    }
                }
            }
        }.start()
    }

    /** Decodes with a power-of-two sample size so the long side stays near [MAX_SIDE], then applies EXIF rotation. */
    private fun decodeImage(u: Uri): Bitmap? {
        // links and network files: read once (every openStream is a new connection), then decode from memory
        val cached: ByteArray? = if (u.scheme == "http" || u.scheme == "https" || u.scheme == Net.SCHEME) openStream(u)?.use { it.readBytes() } else null
        fun open(): java.io.InputStream? = if (cached != null) java.io.ByteArrayInputStream(cached) else openStream(u)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        open()?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > MAX_SIDE) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val raw = open()?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
        val orientation = runCatching {
            open()?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) }
        }.getOrNull() ?: 1
        val mtx = Matrix()
        // EXIF orientation values: 2 flip-H, 3 rot180, 4 flip-V, 5 transpose, 6 rot90, 7 transverse, 8 rot270
        when (orientation) {
            2 -> mtx.postScale(-1f, 1f)
            3 -> mtx.postRotate(180f)
            4 -> mtx.postScale(1f, -1f)
            5 -> { mtx.postRotate(90f); mtx.postScale(-1f, 1f) }
            6 -> mtx.postRotate(90f)
            7 -> { mtx.postRotate(270f); mtx.postScale(-1f, 1f) }
            8 -> mtx.postRotate(270f)
            else -> return raw
        }
        return Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, mtx, true)
    }

    private fun openStream(u: Uri) =
        if (u.scheme == "http" || u.scheme == "https") {
            java.net.URL(u.toString()).openConnection().apply { connectTimeout = 15000; readTimeout = 30000 }.getInputStream()
        } else if (u.scheme == Net.SCHEME) {
            Net.openStream(this, u)
        } else {
            contentResolver.openInputStream(u)
        }

    private fun drawImage(g: GlPipeline, input: Surface) {
        val bmp = bitmap ?: return
        g.setCaptureSize(bmp.width, bmp.height)
        runCatching {
            val c = input.lockCanvas(null)
            try {
                c.drawBitmap(bmp, null, Rect(0, 0, c.width, c.height), Paint(Paint.FILTER_BITMAP_FLAG))
            } finally {
                input.unlockCanvasAndPost(c)
            }
        }.onFailure {
            Toast.makeText(this, getString(R.string.player_error), Toast.LENGTH_LONG).show()
        }
    }

    // ---- photo tools: enhance (Smart fix / offline AI) and save ----------------------------------

    private fun toast(res: Int) = Toast.makeText(this, getString(res), Toast.LENGTH_SHORT).show()

    /** Shows [b] as the current photo (size may have changed after an AI upscale). */
    private fun showBitmap(b: Bitmap) {
        bitmap = b
        vw = b.width
        vh = b.height
        vpar = 1f
        rebuildView()
    }

    private fun restoreOriginal() {
        val b = baseBitmap ?: return
        if (busy) { toast(R.string.img_busy); return }
        if (bitmap === b) toast(R.string.enh_is_original) else showBitmap(b)
    }

    private fun showEnhanceMenu() {
        if (!isImage || bitmap == null) return
        if (busy) { toast(R.string.img_busy); return }
        val items = arrayOf(
            getString(R.string.enh_auto),
            getString(R.string.enh_ai_fmt, if (Cfg.autoMode) getString(R.string.auto_word) else AiSr.activeLabel(this)),
            getString(R.string.enh_models),
            getString(R.string.online_menu),
            getString(R.string.enh_original)
        )
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.enh_title))
            .setItems(items) { _, which ->
                when (which) {
                    0 -> runAutoFix()
                    1 -> startAi()
                    2 -> showModelsDialog()
                    3 -> showOnlineMenu()
                    else -> restoreOriginal()
                }
            }
            .show()
    }

    // ---- online enhancement (cloud, paid) -----------------------------------------------------

    private fun showOnlineMenu() {
        val items = arrayOf(
            getString(R.string.online_photo),
            getString(R.string.online_text),
            getString(R.string.online_settings)
        )
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.online_menu))
            .setItems(items) { _, which ->
                when (which) {
                    0 -> startOnline(Online.PHOTO)
                    1 -> startOnline(Online.TEXT)
                    else -> showOnlineSettings()
                }
            }
            .show()
    }

    private fun startOnline(kind: Int) {
        if (!Online.hasKey(this)) {
            Toast.makeText(this, getString(R.string.online_need_key), Toast.LENGTH_LONG).show()
            showOnlineSettings()
            return
        }
        val src = bitmap ?: return
        val u = currentUri
        busy = true
        aiCancel.set(false)
        showHud(getString(R.string.online_working_fmt, ""), sticky = true)
        Thread {
            var err: String? = null
            val out = try {
                Online.enhance(this, src, kind, aiCancel) { st ->
                    ui.post { if (busy) showHud(getString(R.string.online_working_fmt, st), sticky = true) }
                }
            } catch (t: Throwable) {
                err = t.message ?: t.javaClass.simpleName
                null
            }
            val failure = err
            ui.post {
                busy = false
                hud.visibility = View.GONE
                if (isDestroyed || !isImage || currentUri != u) return@post
                when {
                    failure != null -> Online.showError(this, failure)
                    out == null -> toast(R.string.ai_cancelled)
                    else -> {
                        showBitmap(out)
                        toast(R.string.online_done)
                    }
                }
            }
        }.start()
    }

    private fun showOnlineSettings() = Online.showSettings(this)

    private fun runAutoFix() {
        val src = bitmap ?: return
        val u = currentUri
        busy = true
        showHud(getString(R.string.img_wait), sticky = true)
        Thread {
            val out = runCatching { Enhance.auto(src) }.getOrNull()
            ui.post {
                busy = false
                hud.visibility = View.GONE
                if (isDestroyed || !isImage || currentUri != u) return@post
                when {
                    out == null -> toast(R.string.player_error)
                    out === src -> toast(R.string.enh_nochange)
                    else -> showBitmap(out)
                }
            }
        }.start()
    }

    private fun startAi() {
        if (!AiSr.hasModel(this)) {
            showCatalogDialog() // no model yet: offer the one-tap downloads
            return
        }
        val src = bitmap ?: return
        val u = currentUri
        if (Cfg.autoMode) AiSr.setActive(this, Auto.aiModel(this, src.width, src.height))
        busy = true
        aiCancel.set(false)
        showHud(getString(R.string.ai_progress_fmt, 0), sticky = true)
        Thread {
            var err: String? = null
            val out = try {
                AiSr.upscale(this, src, { p -> ui.post { if (busy) showHud(getString(R.string.ai_progress_fmt, p), sticky = true) } }, aiCancel)
            } catch (t: Throwable) {
                err = t.message ?: t.javaClass.simpleName
                null
            }
            val failure = err
            ui.post {
                busy = false
                hud.visibility = View.GONE
                if (isDestroyed || !isImage || currentUri != u) return@post
                when {
                    failure != null -> Toast.makeText(this, getString(R.string.ai_error_fmt, failure), Toast.LENGTH_LONG).show()
                    out == null -> toast(R.string.ai_cancelled)
                    else -> {
                        showBitmap(out)
                        toast(R.string.ai_done)
                    }
                }
            }
        }.start()
    }

    /** AI model library: choose the active model, add one from a file or a link, remove added ones. */
    private fun showModelsDialog() {
        if (busy) { toast(R.string.img_busy); return }
        val list = AiSr.list(this)
        val active = AiSr.activeId(this)
        val labels = ArrayList<String>()
        for (m in list) labels.add((if (m.id == active) "✓  " else "     ") + m.label)
        labels.add(getString(R.string.model_catalog))
        labels.add(getString(R.string.model_add_file))
        labels.add(getString(R.string.model_add_link))
        labels.add(getString(R.string.model_export))
        if (list.any { !it.builtin }) labels.add(getString(R.string.model_remove))
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.model_title))
            .setItems(labels.toTypedArray()) { _, which ->
                when {
                    which < list.size -> {
                        AiSr.setActive(this, list[which].id)
                        Toast.makeText(this, getString(R.string.model_selected_fmt, list[which].label), Toast.LENGTH_SHORT).show()
                    }
                    which == list.size -> showCatalogDialog()
                    which == list.size + 1 -> {
                        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                            .addCategory(Intent.CATEGORY_OPENABLE)
                            .setType("*/*")
                        @Suppress("DEPRECATION")
                        startActivityForResult(i, REQ_MODEL)
                    }
                    which == list.size + 2 -> showModelLinkDialog()
                    which == list.size + 3 -> ModelFiles.start(this)
                    else -> showRemoveModel()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    /** One-tap list of recommended light models (XLSR, QuickSRNet, SESR-M5): tap = download (if needed) and select. */
    private fun showCatalogDialog() {
        if (busy) { toast(R.string.img_busy); return }
        val cat = AiSr.CATALOG
        val labels = cat.map { c ->
            val state = if (AiSr.isInstalled(this, c)) "✓ " else "⬇ "
            val size = if (c.sizeKb >= 1000) "%.1f MB".format(c.sizeKb / 1000f) else "${c.sizeKb} KB"
            state + c.label + "  (" + size + ")\n    " + getString(c.descRes)
        }
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.model_catalog))
            .setItems(labels.toTypedArray()) { _, which -> downloadCatalogModel(cat[which]) }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun downloadCatalogModel(c: AiSr.Cat) {
        busy = true
        showHud(getString(R.string.ai_downloading_fmt, 0), sticky = true)
        Thread {
            var err: String? = null
            var id: String? = null
            try {
                id = AiSr.installCatalog(this, c) { p -> ui.post { if (busy) showHud(getString(R.string.ai_downloading_fmt, p), sticky = true) } }
            } catch (t: Throwable) {
                err = t.message ?: t.javaClass.simpleName
            }
            val failure = err
            val added = id
            ui.post {
                busy = false
                hud.visibility = View.GONE
                if (isDestroyed) return@post
                if (failure != null || added == null) {
                    Toast.makeText(this, getString(R.string.ai_download_fail_fmt, failure ?: "?"), Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, getString(R.string.model_added_fmt, c.label), Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun showRemoveModel() {
        val removable = AiSr.list(this).filter { !it.builtin }
        if (removable.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.model_remove))
            .setItems(removable.map { it.label }.toTypedArray()) { _, which ->
                AiSr.remove(this, removable[which].id)
                Toast.makeText(this, getString(R.string.model_removed_fmt, removable[which].label), Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showModelLinkDialog() {
        val input = EditText(this).apply {
            hint = "https://…/model.tflite"
            setSingleLine()
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            val clip = runCatching {
                getSystemService(ClipboardManager::class.java).primaryClip?.getItemAt(0)?.text?.toString()
            }.getOrNull()
            if (clip != null && (clip.startsWith("http://") || clip.startsWith("https://"))) setText(clip.trim())
        }
        val pad = dp(this, 20)
        val box = FrameLayout(this).apply { setPadding(pad, dp(this@PlayerActivity, 8), pad, 0) }
        box.addView(input, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.model_add_link))
            .setView(box)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val t = input.text.toString().trim()
                if (t.startsWith("http://") || t.startsWith("https://")) downloadModel(t) else toast(R.string.player_error)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun downloadModel(url: String) {
        busy = true
        showHud(getString(R.string.ai_downloading_fmt, 0), sticky = true)
        Thread {
            var err: String? = null
            var id: String? = null
            try {
                id = AiSr.download(this, url) { p -> ui.post { if (busy) showHud(getString(R.string.ai_downloading_fmt, p), sticky = true) } }
            } catch (t: Throwable) {
                err = t.message ?: t.javaClass.simpleName
            }
            val failure = err
            val added = id
            ui.post {
                busy = false
                hud.visibility = View.GONE
                if (isDestroyed) return@post
                if (failure != null || added == null) {
                    Toast.makeText(this, getString(R.string.ai_download_fail_fmt, failure ?: "?"), Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, getString(R.string.model_added_fmt, added), Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun importModel(u: Uri) {
        busy = true
        showHud(getString(R.string.img_wait), sticky = true)
        val name = displayName(u)
        Thread {
            var err: String? = null
            var id: String? = null
            try {
                id = AiSr.importModel(this, u, name)
            } catch (t: Throwable) {
                err = t.message ?: t.javaClass.simpleName
            }
            val failure = err
            val added = id
            ui.post {
                busy = false
                hud.visibility = View.GONE
                if (isDestroyed) return@post
                if (failure != null || added == null) {
                    Toast.makeText(this, getString(R.string.ai_error_fmt, failure ?: "?"), Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, getString(R.string.model_added_fmt, added), Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun showSaveMenu() {
        val b = bitmap ?: return
        if (busy) { toast(R.string.img_busy); return }
        if (gl == null) { toast(R.string.img_busy); return }
        val labels = ArrayList<String>()
        val kinds = ArrayList<Int>()
        labels.add(getString(R.string.save_jpeg) + "  ${b.width}×${b.height}")
        kinds.add(0)
        labels.add(getString(R.string.save_png) + "  ${b.width}×${b.height}")
        kinds.add(1)
        val w2 = b.width * 2
        val h2 = b.height * 2
        if (max(w2, h2) <= 8192 && w2.toLong() * h2 <= 16_800_000L) {
            labels.add(getString(R.string.save_2x) + "  ${w2}×${h2}")
            kinds.add(2)
        }
        val os = outSize(b)
        if (os != null && os.first != b.width && os.first != w2) {
            labels.add(getString(R.string.save_out) + "  ${os.first}×${os.second}")
            kinds.add(3)
        }
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.save_title))
            .setItems(labels.toTypedArray()) { _, which -> saveImage(kinds[which]) }
            .show()
    }

    /** The size the chosen output resolution (short side) gives this photo, or null when it is Auto / too big to save. */
    private fun outSize(b: Bitmap): Pair<Int, Int>? {
        val o = Cfg.outRes
        if (o <= 0) return null
        val k = o.toFloat() / min(b.width, b.height)
        val w = Math.round(b.width * k)
        val h = Math.round(b.height * k)
        if (w < 2 || h < 2 || max(w, h) > 8192 || w.toLong() * h > 16_800_000L) return null
        return Pair(w, h)
    }

    /** Renders the photo through the effect pipeline at full size (offscreen) and writes it to Pictures/ClearOverlay. */
    private fun saveImage(kind: Int) {
        val b = bitmap ?: return
        val g = gl ?: return
        val scale = if (kind == 2) 2 else 1
        val os = if (kind == 3) outSize(b) else null
        val w = os?.first ?: (b.width * scale)
        val h = os?.second ?: (b.height * scale)
        busy = true
        showHud(getString(R.string.save_wait), sticky = true)
        Thread {
            var ok = false
            val out = runCatching { g.snapshot(w, h) }.getOrNull()
            if (out != null) {
                ok = runCatching { writeToGallery(out, kind != 1) }.getOrDefault(false)
                out.recycle()
            }
            ui.post {
                busy = false
                hud.visibility = View.GONE
                if (!isDestroyed) toast(if (ok) R.string.save_ok else R.string.save_fail)
            }
        }.start()
    }

    /** Screenshot of the current video frame with the effects on (at the chosen output size, or the video\u2019s own size), saved to Pictures/ClearOverlay. */
    private fun videoShot() {
        val g = gl ?: return
        if (isImage || vw <= 0 || vh <= 0 || busy) return
        val dw = max(2, Math.round(vw * vpar))
        val dh = vh
        var w = dw
        var h = dh
        val o = Cfg.outRes
        if (o > 0) {
            val k = o.toFloat() / min(dw, dh)
            w = Math.round(dw * k)
            h = Math.round(dh * k)
        }
        if (max(w, h) > 8192 || w.toLong() * h > 16_800_000L) {
            w = dw
            h = dh
        }
        busy = true
        showMini(getString(R.string.save_wait))
        val fw = w
        val fh = h
        Thread {
            var ok = false
            val out = runCatching { g.snapshot(fw, fh) }.getOrNull()
            if (out != null) {
                ok = runCatching { writeToGallery(out, false) }.getOrDefault(false)
                out.recycle()
            }
            ui.post {
                busy = false
                if (!isDestroyed) toast(if (ok) R.string.save_ok else R.string.save_fail)
            }
        }.start()
    }

    private fun writeToGallery(bmp: Bitmap, jpeg: Boolean): Boolean {
        val srcName = currentUri?.let { displayName(it).substringBeforeLast('.') }.orEmpty().ifBlank { "CRSC" }
        val specs = arrayOf(bmp.width.toString() + "x" + bmp.height) + Stamp.liveSpecs()
        val name = Stamp.name(srcName, *specs) + if (jpeg) ".jpg" else ".png"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.DESCRIPTION, Stamp.description(srcName, *specs))
            put(MediaStore.Images.Media.MIME_TYPE, if (jpeg) "image/jpeg" else "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ClearOverlay")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val resolver = contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
        return try {
            val os = resolver.openOutputStream(uri) ?: error("no stream")
            os.use {
                val fmt = if (jpeg) Bitmap.CompressFormat.JPEG else Bitmap.CompressFormat.PNG
                if (!bmp.compress(fmt, if (jpeg) 95 else 100, it)) error("compress failed")
            }
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            true
        } catch (t: Throwable) {
            runCatching { resolver.delete(uri, null, null) }
            false
        }
    }

    private fun fail() {
        Toast.makeText(this, getString(R.string.player_error), Toast.LENGTH_LONG).show()
        closeMedia()
        hasMedia = false
        setControlsVisible(true)
    }

    // ---- view + pipeline ----------------------------------------------------------------------

    /** (Re)creates the TextureView at the media's aspect ratio, fitted (or filled) inside the window, and its GL pipeline. */
    private fun rebuildView() {
        teardownView()
        if (vw <= 0 || vh <= 0) return
        // size of the area the picture lives in: the stage as laid out right now (the window metrics can still be the
        // old orientation for a moment after a rotation, which made the picture too big = "zoomed" in portrait)
        val b = windowManager.currentWindowMetrics.bounds
        val sw = (if (stage.width > 0) stage.width else b.width()).toFloat()
        val sh = (if (stage.height > 0) stage.height else b.height()).toFloat()
        builtStageW = sw.toInt()
        builtStageH = sh.toInt()
        val aw = vw * vpar
        val ah = vh.toFloat()
        var fwF: Float
        var fhF: Float
        val mode = if (isImage) 0 else aspectMode
        when (mode) {
            1 -> {
                val k = max(sw / aw, sh / ah)
                fwF = aw * k
                fhF = ah * k
            }
            2 -> {
                fwF = sw
                fhF = sh
            }
            3, 4, 5 -> {
                val r = if (mode == 3) 16f / 9f else if (mode == 4) 4f / 3f else 21f / 9f
                if (sw / sh > r) {
                    fhF = sh
                    fwF = sh * r
                } else {
                    fwF = sw
                    fhF = sw / r
                }
            }
            else -> {
                val k = min(sw / aw, sh / ah)
                fwF = aw * k
                fhF = ah * k
            }
        }
        val fw = fwF.toInt().coerceIn(2, 8192)
        val fh = fhF.toInt().coerceIn(2, 8192)
        val view = TextureView(this).apply { isOpaque = true }
        view.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, width: Int, height: Int) {
                if (tv === view) startPipeline(st)
            }

            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, width: Int, height: Int) {}

            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                if (tv === view) stopPipeline()
                return true
            }

            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        tv = view
        stage.addView(view, FrameLayout.LayoutParams(fw, fh, Gravity.CENTER))
    }

    private fun startPipeline(st: SurfaceTexture) {
        if (gl != null) return
        val out = Surface(st)
        outSurface = out
        val g = GlPipeline(out)
        g.onError = { msg ->
            ui.post { Toast.makeText(this, "+CRSC: $msg".take(240), Toast.LENGTH_LONG).show() }
        }
        g.bypass = !Cfg.playerFx
        g.frameGen = Cfg.playerFg && !isImage
        g.frameGenN = Cfg.playerFgN
        g.fgQuality = Cfg.playerFgQ
        g.temporal = if (isImage) 0 else Cfg.playerTemporal
        if (!isImage) g.maxProcRatio = 1.5f // never process far more pixels than the screen can show (4K files on a 1080p screen)
        g.zoom = zoom
        g.zoomX = zoomCx
        g.zoomY = zoomCy
        gl = g
        g.start(vw, vh) { input -> ui.post { if (gl === g) onInputReady(g, input) } }
    }

    private fun onInputReady(g: GlPipeline, input: Surface) {
        if (isImage) {
            drawImage(g, input)
        } else {
            player?.setVideoSurface(input)
        }
    }

    private fun stopPipeline() {
        if (!isImage) runCatching { player?.clearVideoSurface() }
        gl?.release()
        gl = null
        runCatching { outSurface?.release() }
        outSurface = null
    }

    private fun teardownView() {
        stopPipeline()
        tv?.let { v ->
            tv = null
            runCatching { stage.removeView(v) }
        }
    }

    // ---- gestures -----------------------------------------------------------------------------

    private fun onSingleTap(y: Float) {
        if (panel.visibility == View.VISIBLE) {
            hidePanel()
            return
        }
        // Tap = play/pause can be switched off (Settings): then a tap only shows / hides the controls.
        // A tap near the top or bottom edge always shows / hides the controls, so they can be brought back
        // even though a normal tap no longer touches them.
        val h = root.height.toFloat().coerceAtLeast(1f)
        val edge = y < h * 0.12f || y > h * 0.85f
        if (isImage || !tapPlays || edge) {
            setControlsVisible(!controlsOn)
            return
        }
        // Play / pause only: controls that are hidden stay hidden (handy for pausing and resuming repeatedly).
        togglePlay()
    }

    private fun endGesture() {
        val p = player
        if (gestureMode == 1 && p != null) {
            if (streamJob) streamSeek(streamPosMs() + (seekTarget - p.currentPosition)) else p.seekTo(seekTarget)
            gl?.redraw()
        }
        gestureMode = 0
        if (holding) {
            holding = false
            p?.setPlaybackSpeed(holdPrevSpeed)
            hud.visibility = View.GONE
        }
    }

    /** A tiny, short-lived label near the top edge (used for FX on / off, so nothing covers the middle of the picture). */
    private fun showMini(text: String) {
        if (!::miniHud.isInitialized) return
        miniHud.text = text
        miniHud.visibility = View.VISIBLE
        ui.removeCallbacks(miniHide)
        ui.postDelayed(miniHide, 800)
    }

    private fun showHud(text: String, sticky: Boolean = false) {
        hud.text = text
        hud.visibility = View.VISIBLE
        ui.removeCallbacks(hudHide)
        if (!sticky) ui.postDelayed(hudHide, 900)
    }

    private fun currentBrightness(): Float {
        val b = window.attributes.screenBrightness
        return if (b < 0f) 0.5f else b
    }

    private fun setBrightness(v: Float) {
        window.attributes = window.attributes.also { it.screenBrightness = v }
    }

    private fun seekBy(deltaMs: Long) {
        val p = player ?: return
        if (streamJob) {
            streamSeek(streamPosMs() + deltaMs)
            showHud(String.format(Locale.US, "%+d s", deltaMs / 1000L))
            return
        }
        val dur = p.duration
        val upper = if (dur > 0) dur else Long.MAX_VALUE
        p.seekTo((p.currentPosition + deltaMs).coerceIn(0L, upper))
        showHud(String.format(Locale.US, "%+d s", deltaMs / 1000L))
        gl?.redraw()
    }

    // ---- controls -----------------------------------------------------------------------------

    private fun isPlaying(): Boolean = player?.isPlaying == true

    private fun setPlayIcon(playing: Boolean) {
        Icons.glyphCentered(playBtn, if (playing) Icons.PAUSE else Icons.PLAY, Ui.TEXT, 22)
    }

    private fun togglePlay() {
        val p = player ?: return
        when {
            p.playbackState == Player.STATE_ENDED -> {
                if (streamJob) streamSeek(0L) else p.seekTo(0L)
                p.play()
            }
            p.isPlaying || p.playWhenReady -> p.pause()
            else -> p.play()
        }
    }

    private fun setControlsVisible(on: Boolean) {
        controlsOn = on
        bar.visibility = if (on) View.VISIBLE else View.GONE
        topBar.visibility = if (on || Cfg.fxPinned) View.VISIBLE else View.GONE
        // pinned FX: only the FX button stays while the rest of the top bar is hidden
        for (i in 0 until topBar.childCount) {
            val ch = topBar.getChildAt(i)
            ch.visibility = when {
                on || ch === fxBtn -> View.VISIBLE
                !Cfg.fxPinned -> View.VISIBLE
                ch === titleView -> View.INVISIBLE
                else -> View.GONE
            }
        }
        if (isImage && ::shotBtn.isInitialized) shotBtn.visibility = View.GONE
        topBar.post { fitTopBar() }
        val lp = subtitleView.layoutParams as FrameLayout.LayoutParams
        lp.bottomMargin = dp(this, if (on) 120 else 36)
        subtitleView.layoutParams = lp
        if (on) scheduleHide()
    }

    private fun scheduleHide() {
        ui.removeCallbacks(hideRunnable)
        if (isPlaying()) ui.postDelayed(hideRunnable, 3500)
    }

    private fun togglePanel() {
        if (panel.visibility == View.VISIBLE) {
            hidePanel()
            return
        }
        if (!panelBuilt) {
            panelBuilt = true
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            box.addView(buildPlayerHeader())
            box.addView(
                buildControls(
                    this,
                    onAdjust = { onPanelAdjust(it) },
                    inPlayer = true,
                    sourceScale = { currentRatio() },
                    autoPick = { autoPickForCurrent() }
                ) { gl?.redraw() },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )
            panel.addView(box, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        layoutPanel()
        panel.animate().cancel()
        panel.alpha = 1f
        panel.visibility = View.VISIBLE
        panel.post { clampPanel() }
        ui.removeCallbacks(hideRunnable)
        schedulePanelIdle()
    }

    /** Keeps a dragged settings panel inside the window. */
    private fun clampPanel() {
        if (panel.width <= 0) return
        panel.translationX = panel.translationX.coerceIn(-panel.left.toFloat(), (root.width - panel.right).toFloat().coerceAtLeast(-panel.left.toFloat()))
        panel.translationY = panel.translationY.coerceIn(-panel.top.toFloat(), (root.height - panel.bottom).toFloat().coerceAtLeast(-panel.top.toFloat()))
    }

    /**
     * Portrait: a sheet over the lower half. Landscape: a narrow column on the right, so most of the picture
     * stays free to judge the effect.
     */
    /** Narrower top buttons when the screen is narrow (portrait), so ⚙ and ⋮ never fall off the edge. */
    private fun fitTopBar() {
        if (!::topBar.isInitialized) return
        val b = windowManager.currentWindowMetrics.bounds
        val avail = b.width() - dp(this, 24) - insL - insR - dp(this, 56)
        var n = 0
        for (i in 1 until topBar.childCount) if (topBar.getChildAt(i).visibility != View.GONE) n++
        if (n == 0) return
        val w = (avail / n - dp(this, 4)).coerceIn(dp(this, 28), dp(this, 42))
        for (i in 1 until topBar.childCount) {
            val ch = topBar.getChildAt(i)
            val lp = ch.layoutParams as LinearLayout.LayoutParams
            lp.width = w
            lp.marginStart = dp(this, 4)
            ch.layoutParams = lp
        }
    }

    private fun layoutPanel() {
        fitTopBar()
        val b = windowManager.currentWindowMetrics.bounds
        val land = b.width() > b.height()
        val lp = panel.layoutParams as FrameLayout.LayoutParams
        val m = dp(this, 12)
        val sz = Cfg.panelSize.coerceIn(0, 2)
        if (land) {
            lp.width = (b.width() * floatArrayOf(0.30f, 0.40f, 0.52f)[sz]).toInt()
            lp.height = ((b.height() - insT - insB) * floatArrayOf(0.62f, 0.80f, 0.92f)[sz]).toInt()
            lp.gravity = Gravity.END or Gravity.CENTER_VERTICAL
            lp.setMargins(m, m + insT, m + insR, m + insB)
        } else {
            lp.width = if (sz == 0) (b.width() * 0.84f).toInt() else ViewGroup.LayoutParams.MATCH_PARENT
            lp.height = (b.height() * floatArrayOf(0.34f, 0.5f, 0.66f)[sz]).toInt()
            lp.gravity = if (sz == 0) Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL else Gravity.BOTTOM
            lp.setMargins(m + insL, 0, m + insR, dp(this, if (bar.visibility == View.VISIBLE) 84 else 24) + insB)
        }
        panel.layoutParams = lp
    }

    /** Keeps the top bar, bottom bar and panel out of the camera cutout and system-bar areas. */
    private fun applyInsets() {
        val wi = windowManager.currentWindowMetrics.windowInsets
        val full = Edge.full(this, wi)
        insL = full[0]
        insT = full[1]
        insR = full[2]
        insB = full[3]
        val hh = windowManager.currentWindowMetrics.bounds.height()
        val tb = Edge.insets(this, wi, 0, dp(this, 90) + insT)        // the bars only keep clear of a camera hole that is in their own band
        val bb = Edge.insets(this, wi, hh - dp(this, 150) - insB, hh)
        val m = dp(this, 12)
        val tlp = topBar.layoutParams as FrameLayout.LayoutParams
        tlp.setMargins(m + tb[0], dp(this, 4) + insT, m + tb[2], 0)
        topBar.layoutParams = tlp
        val blp = bar.layoutParams as FrameLayout.LayoutParams
        blp.setMargins(bb[0], 0, bb[2], insB) // flush with the bottom and the sides (only a camera hole / system bar moves it)
        bar.layoutParams = blp
        if (panel.visibility == View.VISIBLE) layoutPanel()
    }

    private fun hidePanel() {
        ui.removeCallbacks(panelRestore)
        ui.removeCallbacks(panelIdleHide)
        panel.animate().cancel()
        panel.alpha = 1f
        panel.visibility = View.GONE
        scheduleHide()
    }

    private fun schedulePanelIdle() {
        ui.removeCallbacks(panelIdleHide)
        if (Cfg.panelAutoClose && panel.visibility == View.VISIBLE) ui.postDelayed(panelIdleHide, 7000)
    }

    /** A slider is held: panel nearly transparent so the picture can be judged; restored a moment after release. */
    private fun onPanelAdjust(active: Boolean) {
        if (!Cfg.panelFade) return
        ui.removeCallbacks(panelRestore)
        ui.removeCallbacks(panelIdleHide)
        if (active) {
            panel.animate().cancel()
            panel.animate().alpha(Cfg.panelFadeLevel).setDuration(120).start()
        } else {
            ui.postDelayed(panelRestore, 1500)
        }
    }

    /** Top of the player's settings panel: options that only exist inside the player. */
    private fun buildPlayerHeader(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(panelHeader(this, getString(R.string.player_panel_title) + " · " + Cfg.sectionLabel(this), panel, { clampPanel() }, { hidePanel() }) { showHud(it) })

        fun sw(label: String, checked: Boolean, onChange: (Boolean) -> Unit) = panelSwitch(this, label, checked, onChange)
        fun gap(v: Int) = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(this@PlayerActivity, v) }

        // panel size first, so it is always easy to reach (each kind of media has its own)
        col.addView(panelSizeRow(this) {
            layoutPanel()
            panel.post { clampPanel() }
        }, gap(10))
        col.addView(Ui.text(this, getString(R.string.panel_lock_hint), 12f, Ui.MUTED), gap(4))

        // ---- playback (videos only)
        val secPlay = panelSection(this, getString(R.string.panel_sec_playback))
        col.addView(secPlay, gap(14))
        panelVideoOnly.add(secPlay)
        val tap = sw(getString(R.string.player_tap_switch), tapPlays) {
            tapPlays = it
            prefs.edit().putBoolean("tapPlays", it).apply()
        }
        tapSwitch = tap
        col.addView(tap, gap(10))
        val tapHint = Ui.text(this, getString(R.string.player_tap_hint), 12f, Ui.MUTED)
        col.addView(tapHint, gap(2))
        panelVideoOnly.add(tap)
        panelVideoOnly.add(tapHint)
        val autoNext = sw(getString(R.string.player_autonext_switch), Cfg.autoNext) {
            Cfg.autoNext = it
            Cfg.save(this)
        }
        col.addView(autoNext, gap(10))
        panelVideoOnly.add(autoNext)
        val aspLbl = Ui.text(this, getString(R.string.player_aspect_title), 12f, Ui.MUTED)
        col.addView(aspLbl, gap(10))
        panelVideoOnly.add(aspLbl)
        val aspRow = Ui.text(this, aspectLabel(), 15f, Ui.ACCENT, true).apply {
            setPadding(dp(this@PlayerActivity, 12), dp(this@PlayerActivity, 10), dp(this@PlayerActivity, 12), dp(this@PlayerActivity, 10))
            background = Ui.round(Ui.CHIP, dp(this@PlayerActivity, 10).toFloat())
            setOnClickListener { showAspectDialog() }
        }
        aspectBtn = aspRow
        col.addView(aspRow, gap(4))
        panelVideoOnly.add(aspRow)

        // ---- effect
        col.addView(panelSection(this, getString(R.string.panel_sec_effect)), gap(16))
        val fx = sw(getString(R.string.player_fx_switch), Cfg.playerFx) { setFx(it) }
        fxSwitch = fx
        col.addView(fx, gap(10))
        if (!isImage) {
            col.addView(panelSection(this, getString(R.string.panel_sec_temporal)), gap(16))
            col.addView(Ui.text(this, getString(R.string.export_temporal), 12f, Ui.MUTED), gap(8))
            col.addView(
                chipRow(this, listOf(R.string.export_fg_off, R.string.export_temporal_light, R.string.export_temporal_strong).map { getString(it) }, Cfg.playerTemporal.coerceIn(0, 2)) { q ->
                    Cfg.playerTemporal = q
                    Cfg.save(this@PlayerActivity)
                    gl?.let { it.temporal = q; it.redraw() }
                },
                gap(4)
            )
            col.addView(Ui.text(this, getString(R.string.export_temporal_hint), 12f, Ui.MUTED), gap(2))
            col.addView(panelSection(this, getString(R.string.panel_sec_fg)), gap(16))
            col.addView(
                sw(getString(R.string.player_fg_switch), Cfg.playerFg) {
                    Cfg.playerFg = it
                    Cfg.save(this)
                    gl?.frameGen = it
                },
                gap(10)
            )
            col.addView(Ui.text(this, getString(R.string.player_fg_quality), 12f, Ui.MUTED), gap(8))
            col.addView(
                chipRow(this, listOf(R.string.export_fg_vlight, R.string.export_fg_light, R.string.export_fg_normal, R.string.export_fg_high).map { getString(it) }, intArrayOf(3, 0, 1, 2).indexOf(Cfg.playerFgQ.coerceIn(0, 3)).coerceAtLeast(0)) { qi ->
                    val q = intArrayOf(3, 0, 1, 2)[qi]
                    Cfg.playerFgQ = q
                    Cfg.save(this@PlayerActivity)
                    gl?.fgQuality = q
                },
                gap(4)
            )
            col.addView(Ui.text(this, getString(R.string.player_fg_mult), 12f, Ui.MUTED), gap(8))
            col.addView(
                chipRow(this, listOf("2x", "3x", "4x"), Cfg.playerFgN.coerceIn(2, 4) - 2) { i ->
                    Cfg.playerFgN = i + 2
                    Cfg.save(this@PlayerActivity)
                    gl?.frameGenN = i + 2
                },
                gap(4)
            )
            col.addView(Ui.text(this, getString(R.string.player_fg_hint), 12f, Ui.MUTED), gap(2))
        }
        col.addView(
            sw(getString(R.string.player_fx_pin_switch), Cfg.fxPinned) {
                Cfg.fxPinned = it
                Cfg.save(this)
                setControlsVisible(controlsOn)
            },
            gap(10)
        )

        // ---- screen effect (the overlay service)
        col.addView(panelSection(this, getString(R.string.panel_sec_overlay)), gap(16))
        col.addView(
            sw(getString(R.string.player_pause_overlay_switch), Cfg.pauseOverlayInPlayer) {
                Cfg.pauseOverlayInPlayer = it
                Cfg.save(this)
                OverlayService.instance?.pauseForPlayer(it)
            },
            gap(10)
        )
        col.addView(Ui.text(this, getString(R.string.player_pause_overlay_hint), 12f, Ui.MUTED), gap(2))


        for (v in panelVideoOnly) v.visibility = if (isImage) View.GONE else View.VISIBLE
        col.addView(panelSection(this, getString(R.string.player_effects_label)), gap(16))
        return col
    }

    // ---- effect on/off (A/B compare) ------------------------------------------------------------

    private fun paintFx() {
        val on = Cfg.playerFx
        fxBtn.background = if (on) Ui.gradient(dp(this, 10).toFloat()) else Ui.round(Color.parseColor("#B30B1020"), dp(this, 10).toFloat(), Ui.STROKE, dp(this, 1))
        fxBtn.setTextColor(if (on) Ui.BG else Ui.MUTED)
    }

    private fun setFx(on: Boolean) {
        if (Cfg.playerFx == on) {
            paintFx()
            return
        }
        Cfg.playerFx = on
        Cfg.save(this)
        gl?.let {
            it.bypass = !on
            it.redraw()
        }
        paintFx()
        fxSwitch?.let { if (it.isChecked != on) it.isChecked = on }
        showMini(getString(if (on) R.string.player_fx_on else R.string.player_fx_off))
    }

    // ---- zoom (inspect how much the picture changed) ---------------------------------------------

    /** Pinch = free zoom; the button steps 1x / 2x / 4x / 8x. Zoomed in, one finger pans. The zoom is
     *  done on the real source pixels inside the pipeline, so FX on/off can be compared at pixel level. */
    private fun setZoom(z: Float, fromPinch: Boolean = false) {
        zoom = z.coerceIn(1f, MAX_ZOOM)
        if (zoom <= 1.01f) {
            zoom = 1f
            zoomCx = 0.5f
            zoomCy = 0.5f
        }
        applyZoom()
        if (!fromPinch || zoom > 1f) showHud(getString(R.string.player_zoom_fmt, zoom))
    }

    /** One button for the small tools: zoom, screenshot, rotation, lock, free rotation and cutting the video. */
    private fun showToolsMenu() {
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        labels.add(getString(R.string.tools_zoom_fmt, if (zoom == zoom.toInt().toFloat()) zoom.toInt().toString() else String.format(Locale.US, "%.1f", zoom)))
        acts.add { cycleZoom() }
        if (!isImage) { labels.add(getString(R.string.tools_shot)); acts.add { videoShot() } }
        labels.add(getString(R.string.tools_rotate)); acts.add { cycleRotation() }
        labels.add(getString(if (rotLock) R.string.tools_lock_on else R.string.tools_lock_off)); acts.add { toggleRotLock() }
        labels.add(getString(if (rotFree) R.string.tools_free_on else R.string.tools_free_off)); acts.add { toggleRotFree() }
        val cu = currentUri
        if (cu != null) {
            val mt = mimeOf(cu)
            val target: Class<*> = when {
                isImage -> PhotoEditActivity::class.java
                mt.startsWith("audio/") -> AudioEditActivity::class.java
                else -> EditActivity::class.java
            }
            labels.add(getString(when { isImage -> R.string.tools_edit_photo; mt.startsWith("audio/") -> R.string.tools_edit_audio; else -> R.string.tools_edit_video }))
            acts.add { startActivity(Intent(this, target).setData(cu).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.tools_title)
            .setItems(labels.toTypedArray()) { _, i -> acts[i]() }
            .show()
    }

    private fun cycleZoom() {
        val steps = floatArrayOf(1f, 2f, 4f, 8f)
        val next = steps.firstOrNull { it > zoom + 0.01f } ?: 1f
        setZoom(next)
    }

    private fun applyZoom() {
        val half = 0.5f / zoom
        zoomCx = zoomCx.coerceIn(half, 1f - half)
        zoomCy = zoomCy.coerceIn(half, 1f - half)
        gl?.setZoom(zoom, zoomCx, zoomCy)
        if (::zoomBtn.isInitialized) {
            zoomBtn.text = if (zoom == zoom.toInt().toFloat()) zoom.toInt().toString() + "×" else String.format(Locale.US, "%.1f×", zoom)
            if (::toolsBtn.isInitialized) toolsBtn.setImageDrawable(LineIcon(Icons.EDIT, if (zoom > 1f) Ui.ACCENT else Ui.TEXT))
            zoomBtn.setTextColor(if (zoom > 1f) Ui.ACCENT else Ui.TEXT)
        }
    }

    // ---- rotation -------------------------------------------------------------------------------

    /** Lock wins over free, free wins over the chosen axis, no choice at all = follow the media's shape. */
    private fun applyRotation() {
        requestedOrientation = when {
            rotLock -> ActivityInfo.SCREEN_ORIENTATION_LOCKED
            rotFree -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
            rotAxis == 0 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            rotAxis == 1 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            isImage || vw <= 0 -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
            vw * vpar >= vh -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        }
    }

    private fun rotKey() = if (isImage) "_img" else "_vid"

    /** Reads the direction settings of the current kind of media (the old shared setting is the starting point). */
    private fun loadRotation() {
        val k = rotKey()
        // photos and videos are fully separate: the old shared setting is not used any more
        rotAxis = prefs.getInt("rot_axis$k", -1).coerceIn(-1, 1)
        rotLock = prefs.getBoolean("rot_lock$k", false)
        rotFree = prefs.getBoolean("rot_free$k", false)
    }

    /** True when the screen is shown in landscape right now. */
    private fun isLandscapeNow(): Boolean {
        val b = windowManager.currentWindowMetrics.bounds
        return b.width() > b.height()
    }

    private fun paintRot() {
        if (!::rotBtn.isInitialized) return
        val land = if (rotAxis >= 0) rotAxis == 0 else isLandscapeNow()
        rotBtn.text = if (land) "↔" else "↕"
        rotBtn.setTextColor(if (rotAxis >= 0 && !rotFree && !rotLock) Ui.ACCENT else Ui.TEXT)
        lockBtn.setTextColor(if (rotLock) Ui.ACCENT else Ui.MUTED)
        lockBtn.alpha = if (rotLock) 1f else 0.7f
        freeBtn.setTextColor(if (rotFree && !rotLock) Ui.ACCENT else Ui.MUTED)
        freeBtn.alpha = if (rotFree && !rotLock) 1f else 0.7f
    }

    private fun saveRot() {
        val k = rotKey()
        prefs.edit().putInt("rot_axis$k", rotAxis).putBoolean("rot_lock$k", rotLock).putBoolean("rot_free$k", rotFree).apply()
    }

    /** The orientation key: only two states, landscape <-> portrait (in the chosen one the phone still flips freely between its two ends). */
    private fun cycleRotation() {
        val landNow = if (rotAxis >= 0) rotAxis == 0 else isLandscapeNow()
        rotAxis = if (landNow) 1 else 0
        rotLock = false
        rotFree = false
        saveRot()
        paintRot()
        applyRotation()
        showMini(getString(if (rotAxis == 0) R.string.rot_landscape else R.string.rot_portrait))
    }

    /** Separate key: freeze the direction the screen has right now. */
    private fun toggleRotLock() {
        rotLock = !rotLock
        saveRot()
        paintRot()
        applyRotation()
        showMini(getString(if (rotLock) R.string.rot_lock else R.string.rot_unlock))
    }

    /** Separate key: follow the phone in every direction. */
    private fun toggleRotFree() {
        rotFree = !rotFree
        if (rotFree) rotLock = false
        saveRot()
        paintRot()
        applyRotation()
        showMini(getString(if (rotFree) R.string.rot_free else R.string.rot_free_off))
    }

    // ---- media size / picture view --------------------------------------------------------------

    /**
     * Creates (or resizes) the picture view for a media size. The decoder only reports its video size once it
     * is rendering into a surface, and that surface only exists after this view does, so the size is also taken
     * from the track format (see [sizeFromTracks]) and from a timeout fallback ([ensureViewFallback]).
     */
    private fun applyMediaSize(w: Int, h: Int, par: Float) {
        if (w <= 0 || h <= 0 || isImage) return
        val first = vw == 0
        if (first || w != vw || h != vh || par != vpar || tv == null) {
            vw = w
            vh = h
            vpar = par
            if (first) applyRotation()
            rebuildView()
            updatePip()
            if (Cfg.autoMode) ui.post { applyAuto(true) }
        }
    }

    // ---- Auto: profile / strength / budget / mode chosen from the media and from dropped frames ----------

    private fun currentRatio(): Float {
        val v = tv
        val srcW = vw * vpar
        return if (v == null || srcW <= 0f) 1f else v.width / srcW
    }

    private fun autoPickForCurrent(): Auto.Pick? {
        if (!hasMedia || vw <= 0 || vh <= 0) return null
        if (isImage) return Auto.forPhoto(vw, vh)
        val f = player?.videoFormat
        val fps = if (f != null && f.frameRate > 0f) f.frameRate else 0f
        val br = if (f != null && f.bitrate > 0) f.bitrate else 0
        val u = currentUri
        val stream = u != null && (u.scheme == "http" || u.scheme == "https")
        return Auto.forVideo(vw, vh, fps, br, stream, currentRatio())
    }

    /** Applies Auto to the open media (does nothing unless Auto is on). */
    private fun applyAuto(announce: Boolean) {
        if (!Cfg.autoMode) return
        val pick = autoPickForCurrent() ?: return
        val budget = minOf(pick.budget, autoBudgetCap)
        Profiles.applyPick(pick.type, pick.level, budget, true, currentRatio())
        Cfg.save(this)
        gl?.redraw()
        ControlsBus.sync?.invoke()
        if (announce) {
            val names = intArrayOf(
                R.string.profile_video, R.string.profile_stream, R.string.profile_game,
                R.string.profile_photo, R.string.profile_movie, R.string.profile_anime
            )
            val b = intArrayOf(R.string.budget_perf, R.string.budget_balanced, R.string.budget_quality)
            showHud(getString(R.string.auto_picked_fmt, getString(names[pick.type]), getString(b[budget])))
        }
    }

    /** Frames were dropped: lower the budget one step and keep it lowered for this video. */
    private fun autoCap(budget: Int) {
        autoBudgetCap = budget.coerceIn(Profiles.PERF, Profiles.QUALITY)
        applyAuto(true)
    }

    private fun sizeFromTracks(tracks: Tracks) {
        for (g in tracks.groups) {
            if (g.type != C.TRACK_TYPE_VIDEO) continue
            for (i in 0 until g.length) {
                if (!g.isTrackSelected(i)) continue
                if (sizeFromFormat(g.getTrackFormat(i))) return
            }
        }
    }

    private fun sizeFromFormat(f: Format): Boolean {
        if (f.width <= 0 || f.height <= 0) return false
        val swap = f.rotationDegrees == 90 || f.rotationDegrees == 270
        val par = if (f.pixelWidthHeightRatio > 0f) f.pixelWidthHeightRatio else 1f
        applyMediaSize(if (swap) f.height else f.width, if (swap) f.width else f.height, par)
        return true
    }

    private fun ensureViewFallback() {
        if (isImage || !hasMedia || tv != null) return
        val f = player?.videoFormat
        if (f != null && sizeFromFormat(f)) return
        val b = windowManager.currentWindowMetrics.bounds
        applyMediaSize(b.width(), b.height(), 1f)
    }

    private fun tick() {
        val p = player ?: return
        if (!isImage && hasMedia) {
            val dur = if (streamJob && ExportState.totalUs > 0L) ExportState.totalUs / 1000L else p.duration
            if (!dragging) {
                val pos = if (streamJob) (if (pendingSeekUs >= 0L) (pendingSeekUs - streamOriginUs()) / 1000L else streamPosMs()) else p.currentPosition
                curText.text = fmt(pos)
                if (dur > 0) {
                    seek.progress = (pos * 1000L / dur).toInt().coerceIn(0, 1000)
                    seek.secondaryProgress = if (streamJob) ((streamReadyEndUs() - streamOriginUs()) / 1000L * 1000L / dur).toInt().coerceIn(0, 1000) else (p.bufferedPosition * 1000L / dur).toInt().coerceIn(0, 1000)
                }
            }
            durText.text = if (dur > 0) fmt(dur) else "LIVE"
            // keep a paused video responding to live setting changes
            if (!p.isPlaying && panel.visibility == View.VISIBLE) gl?.redraw()
        } else if (isImage && panel.visibility == View.VISIBLE) {
            gl?.redraw()
        }
    }

    private fun fmt(ms: Long): String {
        val t = (ms / 1000L).coerceAtLeast(0L)
        val h = t / 3600
        val m = (t % 3600) / 60
        val s = t % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s) else String.format(Locale.US, "%d:%02d", m, s)
    }

    // ---- menus: speed, tracks, more -----------------------------------------------------------

    private fun showSpeedMenu() {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(this@PlayerActivity, 20), dp(this@PlayerActivity, 12), dp(this@PlayerActivity, 20), dp(this@PlayerActivity, 4))
        }
        val label = Ui.text(this, speedLabel(speed), 26f, Ui.ACCENT, true).apply { gravity = Gravity.CENTER }
        col.addView(label)
        // slider 0.25x .. 4.0x in steps of 0.05
        val bar = SeekBar(this).apply {
            max = 75
            progress = Math.round((speed - 0.25f) / 0.05f).coerceIn(0, 75)
            progressTintList = android.content.res.ColorStateList.valueOf(Ui.ACCENT)
            thumbTintList = android.content.res.ColorStateList.valueOf(Ui.ACCENT)
        }
        fun applySpeed(v: Float) {
            speed = Math.round(v * 100f) / 100f
            player?.setPlaybackSpeed(speed)
            speedBtn.text = speedLabel(speed)
            label.text = speedLabel(speed)
        }
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) applySpeed(0.25f + p * 0.05f)
            }

            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        col.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@PlayerActivity, 8) })
        val presets = floatArrayOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f, 2.5f, 3f, 3.5f, 4f)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (v in presets) {
            row.addView(
                Ui.text(this, speedLabel(v), 14f, Ui.TEXT, true).apply {
                    gravity = Gravity.CENTER
                    setPadding(dp(this@PlayerActivity, 12), dp(this@PlayerActivity, 8), dp(this@PlayerActivity, 12), dp(this@PlayerActivity, 8))
                    background = Ui.round(Ui.CHIP, dp(this@PlayerActivity, 10).toFloat())
                    setOnClickListener {
                        applySpeed(v)
                        bar.progress = Math.round((v - 0.25f) / 0.05f).coerceIn(0, 75)
                    }
                },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(this@PlayerActivity, 6) }
            )
        }
        col.addView(
            android.widget.HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                addView(row)
            },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@PlayerActivity, 14) }
        )
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.player_speed))
            .setView(col)
            .setPositiveButton(android.R.string.ok, null)
            .show()
    }

    private fun speedLabel(v: Float): String =
        String.format(Locale.US, "%.2f", v).trimEnd('0').trimEnd('.') + "×"

    private fun trackName(f: Format, n: Int): String {
        val lang = f.language
        val langName = if (!lang.isNullOrEmpty() && lang != "und") Locale.forLanguageTag(lang).getDisplayLanguage(Locale.getDefault()) else ""
        val base = when {
            !f.label.isNullOrEmpty() -> f.label.toString()
            langName.isNotEmpty() -> langName
            else -> getString(R.string.player_track_fmt, n)
        }
        return if (f.channelCount > 0) "$base  (${f.channelCount}ch)" else base
    }

    private fun selectTextTrack(p: Player, g: Tracks.Group, i: Int) {
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i))
            .build()
    }

    private fun showTrackMenu(type: Int) {
        val p = player ?: return
        val isText = type == C.TRACK_TYPE_TEXT
        val labels = ArrayList<String>()
        val entries = ArrayList<Pair<Tracks.Group, Int>>()
        var checked = -1
        if (isText) labels.add(getString(R.string.player_off))
        for (g in p.currentTracks.groups) {
            if (g.type != type) continue
            for (i in 0 until g.length) {
                if (!g.isTrackSupported(i)) continue
                entries.add(Pair(g, i))
                labels.add(trackName(g.getTrackFormat(i), entries.size))
                if (g.isTrackSelected(i)) checked = labels.size - 1
            }
        }
        if (entries.isEmpty()) {
            Toast.makeText(this, getString(R.string.player_no_tracks), Toast.LENGTH_SHORT).show()
            if (!isText) return
        }
        if (isText && (checked < 0 || p.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT))) checked = 0
        AlertDialog.Builder(this)
            .setTitle(getString(if (isText) R.string.player_subs else R.string.player_audio))
            .setSingleChoiceItems(labels.toTypedArray(), checked) { d, which ->
                if (isText && which == 0) {
                    p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                        .build()
                    subtitleView.text = ""
                    subtitleView.visibility = View.GONE
                } else {
                    val (g, i) = entries[if (isText) which - 1 else which]
                    if (isText) {
                        selectTextTrack(p, g, i)
                    } else {
                        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                            .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i))
                            .build()
                    }
                }
                d.dismiss()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun aspectLabel(): String = getString(
        when (aspectMode) {
            1 -> R.string.aspect_fill
            2 -> R.string.aspect_stretch
            3 -> R.string.aspect_169
            4 -> R.string.aspect_43
            5 -> R.string.aspect_219
            else -> R.string.aspect_fit
        }
    )

    /** Picture size (frame): fit, fill, stretch, 16:9, 4:3, 21:9. */
    private fun showAspectDialog() {
        val names = intArrayOf(R.string.aspect_fit, R.string.aspect_fill, R.string.aspect_stretch, R.string.aspect_169, R.string.aspect_43, R.string.aspect_219)
            .map { getString(it) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(R.string.player_aspect_title)
            .setSingleChoiceItems(names, aspectMode) { d, which ->
                aspectMode = which
                prefs.edit().putInt("aspectMode", which).apply()
                aspectBtn?.text = aspectLabel()
                if (vw > 0 && !isImage) rebuildView()
                d.dismiss()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    /** Sound enhancer (clarity, bass, width, loudness, voice) for the video's sound, live; can also save the sound as .m4a. */
    private fun showAudioDialog() {
        val sv = android.widget.ScrollView(this).apply {
            setPadding(dp(this@PlayerActivity, 20), dp(this@PlayerActivity, 12), dp(this@PlayerActivity, 20), 0)
            addView(buildAudioPanel(this@PlayerActivity))
        }
        val b = AlertDialog.Builder(this).setTitle(R.string.aud_video_menu).setView(sv).setPositiveButton(android.R.string.ok, null)
        val u = currentUri
        if (u != null && !streamJob) b.setNeutralButton(R.string.aud_save_track) { _, _ -> runAudioExport(this, u, displayName(u)) }
        b.show()
    }

    private fun showMoreMenu() {
        val labels = ArrayList<String>()
        labels.add(getString(R.string.lib_open))
        labels.add(getString(R.string.player_open_file))
        labels.add(getString(R.string.player_open_link))
        if (!isImage) labels.add(getString(R.string.player_add_sub))
        if (!isImage) labels.add(getString(R.string.player_sub_size_fmt, subSize))
        labels.add(getString(R.string.player_aspect_menu_fmt, aspectLabel()))
        if (!isImage) labels.add(getString(if (tapPlays) R.string.player_tap_play else R.string.player_tap_controls))
        val keys = ArrayList<String>()
        keys.add("lib"); keys.add("file"); keys.add("link")
        if (!isImage) { keys.add("sub"); keys.add("subsize") }
        keys.add("aspect")
        if (!isImage) keys.add("tap")
        if (!isImage && currentUri != null && !streamJob) { labels.add(getString(R.string.export_menu)); keys.add("export") }
        if (!isImage) { labels.add(getString(R.string.aud_video_menu)); keys.add("audiofx") }
        if (streamJob) {
            labels.add(getString(R.string.stream_save_ready)); keys.add("savestream")
            labels.add(getString(if (ExportState.keepAll) R.string.stream_keep_on else R.string.stream_keep_off)); keys.add("keepstream")
        }
        if (!isImage && pipSupported() && hasMedia) {
            labels.add("⧉  " + getString(R.string.pip_open)); keys.add("pip")
            labels.add(getString(if (pipOn()) R.string.pip_auto_on else R.string.pip_auto_off)); keys.add("pipauto")
        }
        if (currentUri != null && !streamJob) { labels.add("⤴  " + getString(R.string.share)); keys.add("share") }
        if (currentUri != null && !streamJob) { labels.add(getString(R.string.trash_delete_item)); keys.add("delete") }
        AlertDialog.Builder(this)
            .setItems(labels.toTypedArray()) { _, which ->
                when (keys[which]) {
                    "lib" -> {
                        if (!fromLibrary) startActivity(Intent(this, LibraryActivity::class.java))
                        finish()
                    }
                    "file" -> pickFile()
                    "link" -> showLinkDialog(false)
                    "sub" -> pickSubtitle()
                    "subsize" -> {
                        subSize = if (subSize >= 32) 14 else subSize + 4
                        subtitleView.textSize = subSize.toFloat()
                        prefs.edit().putInt("subSize", subSize).apply()
                        Toast.makeText(this, getString(R.string.player_sub_size_fmt, subSize), Toast.LENGTH_SHORT).show()
                    }
                    "aspect" -> showAspectDialog()
                    "audiofx" -> showAudioDialog()
                    "pip" -> if (!enterPip()) Toast.makeText(this, R.string.pip_failed, Toast.LENGTH_SHORT).show()
                    "pipauto" -> {
                        prefs.edit().putBoolean("pip_on", !pipOn()).apply()
                        updatePip()
                        Toast.makeText(this, getString(if (pipOn()) R.string.pip_auto_on else R.string.pip_auto_off), Toast.LENGTH_SHORT).show()
                    }
                    "savestream" -> saveStreamReady()
                    "keepstream" -> {
                        ExportState.keepAll = !ExportState.keepAll
                        getSharedPreferences("crsc", Context.MODE_PRIVATE).edit().putBoolean("stream_keep", ExportState.keepAll).apply()
                        Toast.makeText(this, getString(if (ExportState.keepAll) R.string.stream_keep_on_msg else R.string.stream_keep_off_msg), Toast.LENGTH_LONG).show()
                    }
                    "share" -> currentUri?.let { Share.share(this, listOf(it)) }
                    // move to the trash or delete for good; when it is gone the viewer closes (the list behind it is reloaded)
                    "delete" -> currentUri?.let { u -> TrashOps.confirmDelete(this, listOf(u)) { finish() } }
                    "export" -> currentUri?.let { u ->
                        startActivity(
                            Intent(this, ExportActivity::class.java).setData(u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                .putExtra(ExportActivity.X_NAME, displayName(u))
                        )
                    }
                    "tap" -> {
                        tapPlays = !tapPlays
                        prefs.edit().putBoolean("tapPlays", tapPlays).apply()
                        tapSwitch?.let { if (it.isChecked != tapPlays) it.isChecked = tapPlays }
                        Toast.makeText(this, getString(if (tapPlays) R.string.player_tap_play else R.string.player_tap_controls), Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .show()
    }

    // ---- external subtitles -------------------------------------------------------------------

    private fun addSubtitle(u: Uri) {
        val name = displayName(u)
        Thread {
            val f = runCatching { normalizeSubtitle(u, name) }.getOrNull()
            ui.post {
                if (isDestroyed) return@post
                if (f == null) {
                    Toast.makeText(this, getString(R.string.player_error), Toast.LENGTH_LONG).show()
                } else {
                    val cfg = MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(f))
                        .setMimeType(subtitleMime(name))
                        .setLabel(name)
                        .build()
                    subs.add(cfg)
                    pendingSubLabel = name
                    reloadMedia()
                    Toast.makeText(this, getString(R.string.player_sub_added), Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    /** Re-prepares the current item (with the external subtitle list) and keeps position and play state. */
    private fun reloadMedia() {
        val p = player ?: return
        val u = currentUri ?: return
        val pos = p.currentPosition
        val play = p.playWhenReady
        val item = MediaItem.Builder().setUri(u).setSubtitleConfigurations(subs.toList()).build()
        p.setMediaItem(item, pos)
        p.prepare()
        p.playWhenReady = play
    }

    private fun subtitleMime(name: String): String {
        val n = name.lowercase(Locale.US)
        return when {
            n.endsWith(".vtt") -> "text/vtt"
            n.endsWith(".ass") || n.endsWith(".ssa") -> "text/x-ssa"
            n.endsWith(".ttml") || n.endsWith(".xml") || n.endsWith(".dfxp") -> "application/ttml+xml"
            else -> "application/x-subrip"
        }
    }

    /**
     * Subtitle files from the web are often not UTF-8 (Windows-1256 for Persian / Arabic, Windows-1252 for
     * Western languages). The player expects UTF-8, so the file is decoded here and rewritten to cache.
     */
    private fun normalizeSubtitle(u: Uri, name: String): File {
        val raw = (openStream(u) ?: error("cannot open")).use { it.readBytes() }
        var data = raw
        val text: String = when {
            data.size >= 3 && data[0] == 0xEF.toByte() && data[1] == 0xBB.toByte() && data[2] == 0xBF.toByte() -> {
                data = data.copyOfRange(3, data.size)
                String(data, Charsets.UTF_8)
            }
            data.size >= 2 && data[0] == 0xFF.toByte() && data[1] == 0xFE.toByte() -> String(data, 2, data.size - 2, Charsets.UTF_16LE)
            data.size >= 2 && data[0] == 0xFE.toByte() && data[1] == 0xFF.toByte() -> String(data, 2, data.size - 2, Charsets.UTF_16BE)
            else -> try {
                Charsets.UTF_8.newDecoder()
                    .onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT)
                    .decode(ByteBuffer.wrap(data))
                    .toString()
            } catch (e: CharacterCodingException) {
                val lang = resources.configuration.locales[0].language
                val cs = if (lang == "fa" || lang == "ar") "windows-1256" else "windows-1252"
                String(data, Charset.forName(cs))
            }
        }
        val ext = when {
            name.lowercase(Locale.US).endsWith(".vtt") -> "vtt"
            name.lowercase(Locale.US).endsWith(".ass") -> "ass"
            name.lowercase(Locale.US).endsWith(".ssa") -> "ssa"
            name.lowercase(Locale.US).endsWith(".ttml") -> "ttml"
            else -> "srt"
        }
        val f = File(cacheDir, "sub_" + System.nanoTime() + "." + ext)
        f.writeText(text, Charsets.UTF_8)
        return f
    }

    // ---- lifecycle ----------------------------------------------------------------------------

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            if (::topBar.isInitialized) applyInsets()
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        panel.translationX = 0f
        panel.translationY = 0f
        root.post {
            applyInsets()
            if (vw > 0 && vh > 0) rebuildView()
        }
    }

    override fun onResume() {
        super.onResume()
        Cfg.bind(this, if (hasMedia && isImage) "photo" else "video")
        ui.post(ticker)
        if (Cfg.pauseOverlayInPlayer) OverlayService.instance?.pauseForPlayer(true)
    }

    override fun onPause() {
        if (isInPictureInPictureMode) {
            // the small floating window keeps playing: nothing is paused and the video keeps its own effect settings
            super.onPause()
            return
        }
        ui.removeCallbacks(ticker)
        ui.removeCallbacks(hideRunnable)
        savePosition()
        player?.pause()
        OverlayService.instance?.pauseForPlayer(false)
        Cfg.bind(this, "screen") // the screen layer goes back to its own settings
        super.onPause()
    }

    override fun onStop() {
        if (inPip) {
            // the floating window was closed: stop playing
            inPip = false
            savePosition()
            player?.pause()
            unregisterPipReceiver()
            OverlayService.instance?.pauseForPlayer(false)
            Cfg.bind(this, "screen")
        }
        super.onStop()
    }

    // ---- floating window (picture in picture): playing goes on in a small window when the app is left --------

    private var inPip = false
    private var pipReceiverOn = false
    private val pipReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            player?.let { if (it.isPlaying) it.pause() else it.play() }
            updatePip()
        }
    }

    private fun pipSupported() = packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_PICTURE_IN_PICTURE)

    private fun pipOn() = prefs.getBoolean("pip_on", true)

    private fun pipParams(): PictureInPictureParams {
        val w = (vw * vpar).toInt().coerceAtLeast(1)
        val h = vh.coerceAtLeast(1)
        val f = w.toFloat() / h
        val ratio = when {
            f > 2.39f -> Rational(239, 100)
            f < 0.418f -> Rational(100, 239)
            else -> Rational(w, h)
        }
        val playing = player?.isPlaying == true
        val icon = Icon.createWithResource(this, if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
        val pi = PendingIntent.getBroadcast(this, 0, Intent(ACT_PIP).setPackage(packageName), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val label = getString(R.string.pip_playpause)
        return PictureInPictureParams.Builder()
            .setAspectRatio(ratio)
            .setActions(listOf(RemoteAction(icon, label, label, pi)))
            .setAutoEnterEnabled(playing && pipOn() && !isImage && hasMedia)
            .build()
    }

    /** Tells the system the shape of the video and whether playing may turn into a floating window by itself (Home / swipe up). */
    private fun updatePip() {
        if (!pipSupported() || isImage || !hasMedia || player == null) return
        runCatching { setPictureInPictureParams(pipParams()) }
    }

    private fun enterPip(): Boolean {
        if (!pipSupported() || isImage || !hasMedia || player == null || vw <= 0) return false
        return runCatching { enterPictureInPictureMode(pipParams()) }.getOrDefault(false)
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (pipOn() && player?.isPlaying == true && !isFinishing && panel.visibility != View.VISIBLE) enterPip()
    }

    private fun unregisterPipReceiver() {
        if (pipReceiverOn) {
            runCatching { unregisterReceiver(pipReceiver) }
            pipReceiverOn = false
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
        if (isInPictureInPictureMode) {
            ui.removeCallbacks(hideRunnable)
            hidePanel()
            bar.visibility = View.GONE
            topBar.visibility = View.GONE
            hud.visibility = View.GONE
            miniHud.visibility = View.GONE
            spinner.visibility = View.GONE
            if (!pipReceiverOn) {
                val f = IntentFilter(ACT_PIP)
                if (android.os.Build.VERSION.SDK_INT >= 33) registerReceiver(pipReceiver, f, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(pipReceiver, f)
                pipReceiverOn = true
            }
        } else {
            unregisterPipReceiver()
            setControlsVisible(true)
        }
    }

    override fun onDestroy() {
        Ui.init(this)
        ui.removeCallbacksAndMessages(null)
        OverlayService.instance?.pauseForPlayer(false)
        teardownView()
        player?.release()
        player = null
        aiCancel.set(true)
        bitmap = null
        baseBitmap = null
        runCatching { cacheDir.listFiles()?.forEach { if (it.name.startsWith("sub_")) it.delete() } }
        if (streamJob && isFinishing && ExportState.job?.stream == true) {
            // leaving a streaming upscale: stop the work and delete the pieces
            streamJob = false
            ExportState.playUs = -1L
            if (ExportState.running) ExportService.cancel(this)
            else ExportState.job?.let { VideoExport.discard(this, it.id) }
        }
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!busy && panel.visibility != View.VISIBLE && askStreamExit()) return
        if (busy) {
            aiCancel.set(true)
            Toast.makeText(this, getString(R.string.ai_cancelled), Toast.LENGTH_SHORT).show()
            return
        }
        if (panel.visibility == View.VISIBLE) {
            hidePanel()
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }

    private companion object {
        const val ACT_PIP = "app.clearoverlay.PIP_TOGGLE"
        const val REQ_PICK = 21
        const val REQ_SUB = 22
        const val MAX_ZOOM = 12f
        const val REQ_MODEL = 23
        /** Long-side cap for decoded photos (keeps GPU textures within every device's limit). */
        const val MAX_SIDE = 4096
    }
}

/** Scroll container for the player's settings; reports every finger-down so the idle auto-hide timer restarts. */
class FadePanel(ctx: Context) : ScrollView(ctx) {
    var onTouch: (() -> Unit)? = null

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN || ev.actionMasked == MotionEvent.ACTION_UP) onTouch?.invoke()
        return super.dispatchTouchEvent(ev)
    }
}
