package app.clearoverlay

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.media.AudioAttributes
import android.media.ExifInterface
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.webkit.MimeTypeMap
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

/**
 * Built-in video / photo viewer. The file is decoded directly (no screen capture), then goes through
 * the same GPU pipeline as the overlay (denoise / deband / anti-aliasing -> FSR 1 / SGSR 1 / bilinear
 * upscale -> sharpen -> vivid colors), so a low-resolution file is upscaled from its real pixels.
 *
 * Video: android.media.MediaPlayer -> [GlPipeline] input surface -> TextureView.
 * Photo: decoded with BitmapFactory (EXIF-rotated, long side capped) and drawn once into the same surface.
 * The settings panel is the same one used by the app screen and the bubble.
 */
class PlayerActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())

    private lateinit var root: FrameLayout
    private lateinit var stage: FrameLayout
    private lateinit var bar: LinearLayout
    private lateinit var playBtn: TextView
    private lateinit var seek: SeekBar
    private lateinit var curText: TextView
    private lateinit var durText: TextView
    private lateinit var panel: ScrollView

    private var tv: TextureView? = null
    private var gl: GlPipeline? = null
    private var outSurface: Surface? = null
    private var mp: MediaPlayer? = null

    private var isImage = false
    private var bitmap: Bitmap? = null
    private var vw = 0
    private var vh = 0
    private var prepared = false
    private var wantPlay = true
    private var dragging = false
    private var hasMedia = false
    private var panelBuilt = false

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    private val ticker = object : Runnable {
        override fun run() {
            tick()
            ui.postDelayed(this, 150)
        }
    }

    private val hideRunnable = Runnable {
        if (panel.visibility != View.VISIBLE && isPlaying()) setControlsVisible(false)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Cfg.load(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.setDecorFitsSystemWindows(false)
        window.attributes = window.attributes.also {
            it.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        stage = FrameLayout(this)
        root.addView(stage, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.setOnClickListener { toggleControls() }

        // ---- bottom bar
        val r = dp(this, 14).toFloat()
        bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = Ui.round(Color.parseColor("#D90B1020"), r)
            setPadding(dp(this@PlayerActivity, 10), dp(this@PlayerActivity, 6), dp(this@PlayerActivity, 10), dp(this@PlayerActivity, 6))
            // keep the bar LTR (time, seek, time) even in a Persian UI
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        playBtn = barButton("▶") { togglePlay() }
        playBtn.textSize = 18f
        bar.addView(playBtn, LinearLayout.LayoutParams(dp(this, 44), dp(this, 40)))
        curText = Ui.text(this, "0:00", 12f, Ui.MUTED)
        durText = Ui.text(this, "0:00", 12f, Ui.MUTED)
        seek = SeekBar(this).apply {
            max = 1000
            val tint = android.content.res.ColorStateList.valueOf(Ui.ACCENT)
            progressTintList = tint
            thumbTintList = tint
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Ui.STROKE)
        }
        bar.addView(curText, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            marginStart = dp(this@PlayerActivity, 6)
        })
        bar.addView(seek, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(durText, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            marginEnd = dp(this@PlayerActivity, 8)
        })
        bar.addView(barButton(getString(R.string.player_settings)) { togglePanel() })
        bar.addView(barButton(getString(R.string.player_open)) { pickFile() })
        val barLp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply {
            val m = dp(this@PlayerActivity, 12)
            setMargins(m, m, m, m)
        }
        root.addView(bar, barLp)

        // ---- settings panel (built on first open)
        panel = ScrollView(this).apply {
            visibility = View.GONE
            background = Ui.round(Color.parseColor("#F5101522"), dp(this@PlayerActivity, 22).toFloat(), Ui.STROKE, dp(this@PlayerActivity, 1))
            setPadding(dp(this@PlayerActivity, 16), dp(this@PlayerActivity, 14), dp(this@PlayerActivity, 16), dp(this@PlayerActivity, 14))
        }
        root.addView(panel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    val d = mp?.duration ?: 0
                    curText.text = fmt((p.toLong() * d / 1000).toInt())
                }
            }

            override fun onStartTrackingTouch(s: SeekBar) {
                dragging = true
            }

            override fun onStopTrackingTouch(s: SeekBar) {
                val d = mp?.duration ?: 0
                runCatching { mp?.seekTo((s.progress.toLong() * d / 1000).toInt(), MediaPlayer.SEEK_CLOSEST) }
                dragging = false
                gl?.redraw()
            }
        })

        setContentView(root)

        val d = intent?.data
        if (d != null) open(d) else pickFile()
    }

    private fun barButton(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 13f
        gravity = Gravity.CENTER
        setTextColor(Ui.TEXT)
        background = Ui.round(Ui.CHIP, dp(this@PlayerActivity, 10).toFloat())
        setPadding(dp(this@PlayerActivity, 10), dp(this@PlayerActivity, 8), dp(this@PlayerActivity, 10), dp(this@PlayerActivity, 8))
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            marginStart = dp(this@PlayerActivity, 6)
        }
        setOnClickListener { onClick() }
    }

    // ---- file picking -----------------------------------------------------------------------

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*")
            .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("video/*", "image/*"))
        @Suppress("DEPRECATION")
        startActivityForResult(i, REQ_PICK)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != REQ_PICK) return
        val u = data?.data
        if (res == RESULT_OK && u != null) {
            open(u)
        } else if (!hasMedia) {
            finish()
        }
    }

    // ---- opening media ----------------------------------------------------------------------

    private fun mimeOf(u: Uri): String {
        val t = contentResolver.getType(u)
        if (!t.isNullOrEmpty()) return t
        val ext = MimeTypeMap.getFileExtensionFromUrl(u.toString()).lowercase(Locale.US)
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: ""
    }

    private fun open(u: Uri) {
        closeMedia()
        hasMedia = true
        isImage = mimeOf(u).startsWith("image/")
        wantPlay = true
        playBtn.visibility = if (isImage) View.GONE else View.VISIBLE
        seek.visibility = if (isImage) View.INVISIBLE else View.VISIBLE
        curText.visibility = if (isImage) View.INVISIBLE else View.VISIBLE
        durText.visibility = if (isImage) View.INVISIBLE else View.VISIBLE
        setControlsVisible(true)
        if (isImage) openImage(u) else openVideo(u)
    }

    private fun closeMedia() {
        ui.removeCallbacks(hideRunnable)
        teardownView()
        runCatching { mp?.release() }
        mp = null
        prepared = false
        bitmap = null
        vw = 0
        vh = 0
        seek.progress = 0
        curText.text = "0:00"
        durText.text = "0:00"
    }

    private fun openVideo(u: Uri) {
        val p = MediaPlayer()
        mp = p
        p.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                .build()
        )
        p.setOnPreparedListener {
            if (mp !== p) return@setOnPreparedListener
            vw = p.videoWidth
            vh = p.videoHeight
            if (vw <= 0 || vh <= 0) {
                fail()
                return@setOnPreparedListener
            }
            prepared = true
            durText.text = fmt(p.duration)
            requestedOrientation = if (vw >= vh) {
                ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            } else {
                ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            }
            rebuildView()
        }
        p.setOnVideoSizeChangedListener { _, w, h ->
            if (mp === p && prepared && w > 0 && h > 0 && (w != vw || h != vh)) {
                vw = w
                vh = h
                rebuildView()
            }
        }
        p.setOnCompletionListener {
            if (mp !== p) return@setOnCompletionListener
            wantPlay = false
            setPlayIcon(false)
            setControlsVisible(true)
        }
        p.setOnErrorListener { _, _, _ ->
            if (mp === p) fail()
            true
        }
        try {
            p.setDataSource(this, u)
            p.prepareAsync()
        } catch (e: Exception) {
            fail()
        }
    }

    private fun openImage(u: Uri) {
        Thread {
            val bmp = runCatching { decodeImage(u) }.getOrNull()
            ui.post {
                if (isDestroyed || !isImage) return@post
                if (bmp == null) {
                    fail()
                } else {
                    bitmap = bmp
                    vw = bmp.width
                    vh = bmp.height
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR
                    rebuildView()
                }
            }
        }.start()
    }

    /** Decodes with a power-of-two sample size so the long side stays near [MAX_SIDE], then applies EXIF rotation. */
    private fun decodeImage(u: Uri): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > MAX_SIDE) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val raw = contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
        val orientation = runCatching {
            contentResolver.openInputStream(u)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)
            }
        }.getOrNull() ?: 1
        val mtx = Matrix()
        // EXIF orientation values: 2 flip-H, 3 rot180, 4 flip-V, 5 transpose, 6 rot90, 7 transverse, 8 rot270
        when (orientation) {
            2 -> mtx.postScale(-1f, 1f)
            3 -> mtx.postRotate(180f)
            4 -> mtx.postScale(1f, -1f)
            5 -> { mtx.postRotate(90f); mtx.postScale(-1f, 1f) }
            6 -> mtx.postRotate(90f)
            7 -> { mtx.postRotate(270f); mtx.postScale(-1f, 1f) }
            8 -> mtx.postRotate(270f)
            else -> return raw
        }
        return Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, mtx, true)
    }

    private fun fail() {
        Toast.makeText(this, getString(R.string.player_error), Toast.LENGTH_LONG).show()
        closeMedia()
        hasMedia = false
        setControlsVisible(true)
    }

    // ---- view + pipeline --------------------------------------------------------------------

    /** (Re)creates the TextureView at the media's aspect ratio, fitted inside the window, and its GL pipeline. */
    private fun rebuildView() {
        teardownView()
        if (vw <= 0 || vh <= 0) return
        val b = windowManager.currentWindowMetrics.bounds
        val s = minOf(b.width().toFloat() / vw, b.height().toFloat() / vh)
        val fw = (vw * s).toInt().coerceAtLeast(2)
        val fh = (vh * s).toInt().coerceAtLeast(2)
        val view = TextureView(this).apply { isOpaque = true }
        view.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, width: Int, height: Int) {
                if (tv === view) startPipeline(st)
            }

            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, width: Int, height: Int) {}

            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                if (tv === view) stopPipeline()
                return true
            }

            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        tv = view
        stage.addView(view, FrameLayout.LayoutParams(fw, fh, Gravity.CENTER))
    }

    private fun startPipeline(st: SurfaceTexture) {
        if (gl != null) return
        val out = Surface(st)
        outSurface = out
        val g = GlPipeline(out)
        g.onError = { msg ->
            ui.post { Toast.makeText(this, "+CRSC: $msg".take(240), Toast.LENGTH_LONG).show() }
        }
        gl = g
        g.start(vw, vh) { input -> ui.post { if (gl === g) onInputReady(g, input) } }
    }

    private fun onInputReady(g: GlPipeline, input: Surface) {
        if (isImage) {
            drawImage(g, input)
        } else {
            val p = mp ?: return
            runCatching { p.setSurface(input) }
            if (prepared && wantPlay) {
                runCatching { p.start() }
                setPlayIcon(true)
                scheduleHide()
            }
        }
    }

    private fun drawImage(g: GlPipeline, input: Surface) {
        val bmp = bitmap ?: return
        g.setCaptureSize(bmp.width, bmp.height)
        runCatching {
            val c = input.lockCanvas(null)
            try {
                c.drawBitmap(bmp, null, Rect(0, 0, c.width, c.height), Paint(Paint.FILTER_BITMAP_FLAG))
            } finally {
                input.unlockCanvasAndPost(c)
            }
        }.onFailure {
            Toast.makeText(this, getString(R.string.player_error), Toast.LENGTH_LONG).show()
        }
    }

    private fun stopPipeline() {
        runCatching { if (!isImage) mp?.setSurface(null) }
        gl?.release()
        gl = null
        runCatching { outSurface?.release() }
        outSurface = null
    }

    private fun teardownView() {
        stopPipeline()
        tv?.let { v ->
            tv = null
            runCatching { stage.removeView(v) }
        }
    }

    // ---- controls ---------------------------------------------------------------------------

    private fun isPlaying(): Boolean = runCatching { mp?.isPlaying == true }.getOrDefault(false)

    private fun setPlayIcon(playing: Boolean) {
        playBtn.text = if (playing) "❚❚" else "▶"
    }

    private fun togglePlay() {
        val p = mp ?: return
        if (!prepared) return
        if (isPlaying()) {
            wantPlay = false
            runCatching { p.pause() }
            setPlayIcon(false)
            ui.removeCallbacks(hideRunnable)
        } else {
            wantPlay = true
            runCatching {
                // finished clips restart from the beginning
                if (p.duration > 0 && p.currentPosition >= p.duration - 200) p.seekTo(0)
                p.start()
            }
            setPlayIcon(true)
            scheduleHide()
        }
    }

    private fun toggleControls() {
        if (panel.visibility == View.VISIBLE) {
            panel.visibility = View.GONE
            return
        }
        setControlsVisible(bar.visibility != View.VISIBLE)
    }

    private fun setControlsVisible(on: Boolean) {
        bar.visibility = if (on) View.VISIBLE else View.GONE
        if (on) scheduleHide()
    }

    private fun scheduleHide() {
        ui.removeCallbacks(hideRunnable)
        if (isPlaying() || (wantPlay && !isImage)) ui.postDelayed(hideRunnable, 3500)
    }

    private fun togglePanel() {
        if (panel.visibility == View.VISIBLE) {
            panel.visibility = View.GONE
            scheduleHide()
            return
        }
        if (!panelBuilt) {
            panelBuilt = true
            panel.addView(
                buildControls(this) { gl?.redraw() },
                ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )
        }
        val b = windowManager.currentWindowMetrics.bounds
        val lp = panel.layoutParams as FrameLayout.LayoutParams
        lp.height = (b.height() * 0.62f).toInt()
        lp.bottomMargin = dp(this, 76)
        val side = dp(this, 12)
        lp.leftMargin = side
        lp.rightMargin = side
        panel.layoutParams = lp
        panel.visibility = View.VISIBLE
        ui.removeCallbacks(hideRunnable)
    }

    private fun tick() {
        val p = mp
        if (p != null && prepared && !isImage) {
            if (!dragging) {
                val d = runCatching { p.duration }.getOrDefault(0)
                val c = runCatching { p.currentPosition }.getOrDefault(0)
                if (d > 0) seek.progress = (c.toLong() * 1000 / d).toInt().coerceIn(0, 1000)
                curText.text = fmt(c)
            }
            // keep a paused video responding to live setting changes
            if (!isPlaying() && panel.visibility == View.VISIBLE) gl?.redraw()
        } else if (isImage && panel.visibility == View.VISIBLE) {
            gl?.redraw()
        }
    }

    private fun fmt(ms: Int): String {
        val t = (ms / 1000).coerceAtLeast(0)
        val h = t / 3600
        val m = (t % 3600) / 60
        val s = t % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s) else String.format(Locale.US, "%d:%02d", m, s)
    }

    // ---- lifecycle --------------------------------------------------------------------------

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (vw > 0 && vh > 0) root.post { rebuildView() }
    }

    override fun onResume() {
        super.onResume()
        ui.post(ticker)
    }

    override fun onPause() {
        ui.removeCallbacks(ticker)
        ui.removeCallbacks(hideRunnable)
        if (isPlaying()) {
            wantPlay = false
            runCatching { mp?.pause() }
            setPlayIcon(false)
        }
        super.onPause()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        teardownView()
        runCatching { mp?.release() }
        mp = null
        bitmap = null
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (panel.visibility == View.VISIBLE) {
            panel.visibility = View.GONE
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }

    private companion object {
        const val REQ_PICK = 21
        /** Long-side cap for decoded photos (keeps GPU textures within every device's limit). */
        const val MAX_SIDE = 4096
    }
}
