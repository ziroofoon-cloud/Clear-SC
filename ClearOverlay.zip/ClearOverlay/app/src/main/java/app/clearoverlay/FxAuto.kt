package app.clearoverlay

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Live auto-tuning of the picture effects ("Auto FX", player): looks at a tiny copy of the frame about once a second and
 * adds a small, smoothed change on top of the person's own settings (Cfg.tShadows ... see [LiveFx]).
 *
 * Replaces the hard-threshold rules of 3.96.2 (mean < 0.32 -> lift ...). What was wrong with them, measured on 54 pictures
 * (photos and their dark / foggy / burnt / grey versions) with the app's own colour shader ported 1:1:
 *  - they removed 0.1 % of the damage of a damaged picture (the best fixed setting would remove 24 %), and in 5 of the 9 kinds of damage they
 *    made it worse (fog: 6 % worse, washed-out colour: 14 % worse);
 *  - black bars of a letterboxed film counted as a dark picture (shadows lifted on every film);
 *  - the person's own shadows / contrast were doubled; one white flash moved the tone for several seconds; a cut took 8 s;
 *  - sharpness and clean-up jumped on / off at one threshold.
 * Now: the tone numbers come from a small ridge regression on the picture's histogram (fitted on the same pictures, tested on
 * photos it had not seen), the bars are ignored, only what the person has not already set is added, a single odd sample is
 * ignored, a confirmed cut is followed in about 2 s, and tiny drifts are not followed at all.
 */
object FxAuto {
    const val BINS = 64
    private const val FEATS = 19

    /** What one frame looks like: brightness histogram of the picture without black bars, colourfulness, edge amount, burnt share. */
    class Meas(val hist: FloatArray, val chroma: Float, val edge: Float, val clipHi: Float)

    /** Level: 0 light, 1 normal, 2 strong. Multiplies the regression (the more it changes, the more it also changes healthy pictures). */
    private val LEVEL = floatArrayOf(0.5f, 1.0f, 1.6f)
    /** Allowed range of the total change (shadows, highlights, contrast, saturation). */
    private val LO = floatArrayOf(-0.25f, -0.40f, 0.0f, -0.10f)
    private val HI = floatArrayOf(0.50f, 0.0f, 0.35f, 0.30f)

    /** Rows = features (see [features]), columns = shadows, highlights, contrast, saturation. Fitted offline, shrink 0.8 included. */
    private val W = arrayOf(
        floatArrayOf(0.18292f, 0.13832f, 0.08036f, 0.05804f),   // 1
        floatArrayOf(-0.02522f, -0.05540f, 0.00738f, 0.03028f),   // mean
        floatArrayOf(-0.07843f, -0.07333f, -0.01810f, 0.01095f),   // p5
        floatArrayOf(-0.01863f, -0.02767f, -0.00517f, 0.03055f),   // p50
        floatArrayOf(-0.01335f, -0.03536f, -0.01635f, -0.02419f),   // p95
        floatArrayOf(-0.19563f, -0.11719f, -0.01209f, -0.00940f),   // p99
        floatArrayOf(0.00100f, -0.00752f, -0.03044f, -0.04344f),   // chroma
        floatArrayOf(-0.02071f, -0.05444f, 0.00002f, 0.02651f),   // clipHi
        floatArrayOf(0.00127f, -0.03997f, -0.03139f, 0.04380f),   // black
        floatArrayOf(0.06146f, -0.04523f, -0.06213f, 0.01341f),   // dark
        floatArrayOf(0.06508f, 0.03797f, 0.00175f, -0.03515f),   // range
        floatArrayOf(-0.00750f, 0.00478f, -0.06555f, -0.06430f),   // edge
        floatArrayOf(0.01284f, 0.00844f, -0.04665f, -0.02331f),   // h_nobright
        floatArrayOf(-0.10019f, -0.01438f, -0.01224f, 0.03611f),   // h_darkmid
        floatArrayOf(-0.07896f, -0.10907f, 0.00503f, 0.03936f),   // h_milky
        floatArrayOf(-0.13258f, -0.13586f, 0.00825f, -0.05603f),   // h_flat
        floatArrayOf(-0.00113f, -0.03015f, 0.00552f, 0.03103f),   // h_burnt
        floatArrayOf(-0.00665f, 0.03490f, -0.03885f, -0.09879f),   // h_pale
        floatArrayOf(-0.00664f, -0.01814f, -0.00592f, -0.00335f),   // h_white
    )

    /** [px]: packed RGB of the 96 x 54 copy. Null when the copy is too small. */
    fun measure(px: IntArray, w: Int = 96, h: Int = 54): Meas? {
        if (px.size < w * h || w < 8 || h < 8) return null
        val l = FloatArray(w * h)
        val rowMax = FloatArray(h)
        val colMax = FloatArray(w)
        for (y in 0 until h) for (x in 0 until w) {
            val c = px[y * w + x]
            val v = (0.299f * ((c shr 16) and 255) + 0.587f * ((c shr 8) and 255) + 0.114f * (c and 255)) / 255f
            l[y * w + x] = v
            if (v > rowMax[y]) rowMax[y] = v
            if (v > colMax[x]) colMax[x] = v
        }
        // black bars (letterbox / pillarbox): rows / columns at the edge that stay black, at most 30 % of the side
        fun run(m: FloatArray, from: Int, step: Int, limit: Int): Int {
            var n = 0
            var i = from
            while (n < limit && i in m.indices && m[i] < 0.04f) { n++; i += step }
            return n
        }
        var top = run(rowMax, 0, 1, (h * 0.30f).toInt())
        var bottom = run(rowMax, h - 1, -1, (h * 0.30f).toInt())
        var left = run(colMax, 0, 1, (w * 0.30f).toInt())
        var right = run(colMax, w - 1, -1, (w * 0.30f).toInt())
        if (h - top - bottom < h * 0.4f || w - left - right < w * 0.4f) { top = 0; bottom = 0; left = 0; right = 0 }
        val y0 = top
        val y1 = h - bottom
        val x0 = left
        val x1 = w - right
        val hist = FloatArray(BINS)
        var chroma = 0f
        var clip = 0
        var n = 0
        for (y in y0 until y1) for (x in x0 until x1) {
            val v = l[y * w + x]
            hist[min(BINS - 1, max(0, (v * (BINS - 1)).toInt()))] += 1f
            val c = px[y * w + x]
            val r = (c shr 16) and 255
            val g = (c shr 8) and 255
            val b = c and 255
            chroma += (max(r, max(g, b)) - min(r, min(g, b))) / 255f
            if (v > 0.97f) clip++
            n++
        }
        if (n == 0) return null
        val inv = 1f / n
        for (i in hist.indices) hist[i] = hist[i] * inv
        var edge = 0f
        for (y in y0 until y1 - 1) for (x in x0 until x1 - 1) {
            val i = y * w + x
            edge += abs(l[i + 1] - l[i]) + abs(l[i + w] - l[i])
        }
        val cells = (y1 - y0 - 1) * (x1 - x0 - 1)
        return Meas(hist, chroma / n, if (cells > 0) edge / cells else 0f, clip.toFloat() / n)
    }

    private fun quant(hist: FloatArray, p: Float): Float {
        var acc = 0f
        for (i in hist.indices) {
            acc += hist[i]
            if (acc >= p) return (i + 0.5f) / BINS
        }
        return (BINS - 0.5f) / BINS
    }

    private fun hg(x: Float) = if (x > 0f) x else 0f

    private fun features(m: Meas): FloatArray {
        val h = m.hist
        val p5 = quant(h, 0.05f)
        val p50 = quant(h, 0.5f)
        val p95 = quant(h, 0.95f)
        val p99 = quant(h, 0.99f)
        var mean = 0f
        for (i in h.indices) mean += h[i] * (i + 0.5f) / BINS
        var dark = 0f
        for (i in 2..15) dark += h[i]
        val range = p95 - p5
        return floatArrayOf(
            1f, mean, p5, p50, p95, p99, m.chroma, m.clipHi, h[0] + h[1], dark, range, min(m.edge, 0.2f),
            hg(0.50f - p99), hg(0.20f - p50), hg(p5 - 0.14f), hg(0.55f - range), hg(m.clipHi - 0.04f), hg(0.14f - m.chroma), hg(p95 - 0.93f)
        )
    }

    private fun smooth(x: Float, a: Float, b: Float): Float {
        val t = ((x - a) / (b - a)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    /** Mean brightness difference between two histograms (area between the two cumulative curves). */
    private fun dist(a: FloatArray, b: FloatArray): Float {
        var ca = 0f
        var cb = 0f
        var s = 0f
        for (i in a.indices) { ca += a[i]; cb += b[i]; s += abs(ca - cb) }
        return s / BINS
    }

    /** The changes to add: shadows, highlights, contrast, saturation, sharpness, denoise (same order as Cfg.t*). */
    class Ctl {
        private var sm: Meas? = null
        private var pending: Meas? = null
        val cur = FloatArray(6)

        fun reset() { sm = null; pending = null; cur.fill(0f) }

        /** [user] = the person's own shadows, highlights, contrast, saturation; [level] 0..2. Returns [cur]. */
        fun step(m: Meas, user: FloatArray, level: Int): FloatArray {
            var fast = false
            val old = sm
            if (old == null) {
                sm = m
                fast = true
            } else {
                val d = dist(old.hist, m.hist)
                if (d > CUT_D) {
                    val p = pending
                    if (p != null && dist(p.hist, m.hist) < CONFIRM_D) {
                        sm = m; pending = null; fast = true     // a second sample agrees: it is a real cut
                    } else {
                        pending = m                             // one odd sample (a flash, a fade frame): wait for a second
                        return cur
                    }
                } else {
                    pending = null
                    val k = 0.6f
                    val mixed = FloatArray(BINS) { old.hist[it] * k + m.hist[it] * (1f - k) }
                    sm = Meas(mixed, old.chroma * k + m.chroma * (1f - k), old.edge * k + m.edge * (1f - k), old.clipHi * k + m.clipHi * (1f - k))
                }
            }
            val s = sm ?: return cur
            val f = features(s)
            val mult = LEVEL[level.coerceIn(0, 2)]
            val tgt = FloatArray(6)
            for (j in 0 until 4) {
                var y = 0f
                for (i in 0 until FEATS) y += f[i] * W[i][j]
                val p = (y * mult).coerceIn(LO[j], HI[j])
                // never fight what the person set: add only what is still missing in the same direction
                tgt[j] = when {
                    p > 0f -> max(0f, p - max(user[j], 0f))
                    p < 0f -> min(0f, p - min(user[j], 0f))
                    else -> 0f
                }
            }
            var mean = 0f
            for (i in s.hist.indices) mean += s.hist[i] * (i + 0.5f) / BINS
            tgt[4] = 0.10f * (1f - smooth(s.edge, 0.012f, 0.035f)) - 0.10f * smooth(s.edge, 0.09f, 0.13f)
            tgt[5] = 0.15f * max(1f - smooth(mean, 0.14f, 0.24f), smooth(s.edge, 0.10f, 0.14f))
            val k = if (fast) 0.7f else 0.3f
            val slew = if (fast) 0.20f else 0.05f
            val dead = if (fast) 0f else DEAD
            for (j in 0 until 6) {
                val diff = tgt[j] - cur[j]
                val moved = if (diff > 0f) max(0f, diff - dead) else -max(0f, -diff - dead)   // tiny drifts are not followed
                cur[j] += (moved * k).coerceIn(-slew, slew)
            }
            return cur
        }
    }

    private const val CUT_D = 0.16f
    private const val CONFIRM_D = 0.10f
    private const val DEAD = 0.012f
}
