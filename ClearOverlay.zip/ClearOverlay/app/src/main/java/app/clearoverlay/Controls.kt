package app.clearoverlay

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

/** Colors and small view factories shared by the app screen and the floating panel. */
object Ui {
    val BG = Color.parseColor("#0B1020")
    val CARD = Color.parseColor("#151B2E")
    val CHIP = Color.parseColor("#1F2940")
    val STROKE = Color.parseColor("#26324D")
    val ACCENT = Color.parseColor("#22D3EE")
    val ACCENT2 = Color.parseColor("#A78BFA")
    val TEXT = Color.parseColor("#F1F5F9")
    val MUTED = Color.parseColor("#94A3B8")
    val DANGER = Color.parseColor("#F87171")
    val OK = Color.parseColor("#4ADE80")

    fun themed(c: Context): Context = ContextThemeWrapper(c, android.R.style.Theme_DeviceDefault)

    fun round(color: Int, radius: Float, strokeColor: Int = 0, strokeW: Int = 0) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
        if (strokeW > 0) setStroke(strokeW, strokeColor)
    }

    fun gradient(radius: Float) =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(ACCENT, ACCENT2)).apply {
            cornerRadius = radius
        }

    fun text(c: Context, s: String, sp: Float, color: Int = TEXT, bold: Boolean = false) = TextView(c).apply {
        text = s
        textSize = sp
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }
}

/**
 * Mode chips, sharpness, render scale and boost. Used by the main screen and by the bubble's panel,
 * so both always look and behave the same. [onApply] is called when something needs the capture
 * size to be re-applied (mode / render scale).
 */
fun buildControls(base: Context, onApply: () -> Unit): LinearLayout {
    val ctx = Ui.themed(base)
    val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }

    fun gap(v: Int) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(ctx, v) }

    // ---- mode chips
    col.addView(Ui.text(ctx, "Mode", 12f, Ui.MUTED))
    val chipRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
    val names = arrayOf("Sharpen", "FSR 1", "SGSR 1")
    val chips = names.map { n ->
        TextView(ctx).apply {
            text = n
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(dp(ctx, 8), dp(ctx, 10), dp(ctx, 8), dp(ctx, 10))
        }
    }
    chips.forEach { chip ->
        chipRow.addView(
            chip,
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(ctx, 6)
            }
        )
    }
    col.addView(chipRow, gap(6))

    // ---- sharpness
    val sharpLabel = Ui.text(ctx, "", 14f)
    val sharpBar = SeekBar(ctx).apply {
        max = 100
        progress = (Cfg.sharp * 100).toInt()
    }
    sharpLabel.text = "Sharpness  ${sharpBar.progress}%"
    col.addView(sharpLabel, gap(14))
    col.addView(sharpBar, gap(2))

    // ---- render scale
    val scaleLabel = Ui.text(ctx, "", 14f)
    val scaleBar = SeekBar(ctx).apply {
        max = 50
        progress = Cfg.scalePct.coerceIn(50, 100) - 50
    }
    scaleLabel.text = "Render scale  ${50 + scaleBar.progress}%"
    col.addView(scaleLabel, gap(10))
    col.addView(scaleBar, gap(2))

    // ---- boost
    val boost = Switch(ctx).apply {
        text = "Boost (extra sharpening pass)"
        setTextColor(Ui.TEXT)
        isChecked = Cfg.boost
    }
    col.addView(boost, gap(12))

    val tint = ColorStateList.valueOf(Ui.ACCENT)
    val track = ColorStateList.valueOf(Ui.STROKE)
    for (b in arrayOf(sharpBar, scaleBar)) {
        b.progressTintList = tint
        b.thumbTintList = tint
        b.progressBackgroundTintList = track
    }

    fun paint() {
        val radius = dp(ctx, 12).toFloat()
        chips.forEachIndexed { i, chip ->
            if (Cfg.mode == i) {
                chip.background = Ui.gradient(radius)
                chip.setTextColor(Ui.BG)
                chip.setTypeface(null, Typeface.BOLD)
            } else {
                chip.background = Ui.round(Ui.CHIP, radius)
                chip.setTextColor(Ui.MUTED)
                chip.setTypeface(null, Typeface.NORMAL)
            }
        }
        val scaleOn = Cfg.mode != Cfg.MODE_SHARP
        scaleBar.isEnabled = scaleOn
        val a = if (scaleOn) 1f else 0.4f
        scaleBar.alpha = a
        scaleLabel.alpha = a
    }
    paint()

    chips.forEachIndexed { i, chip ->
        chip.setOnClickListener {
            Cfg.mode = i
            Cfg.save(ctx)
            paint()
            onApply()
        }
    }

    sharpBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            Cfg.sharp = p / 100f
            sharpLabel.text = "Sharpness  $p%"
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) = Cfg.save(ctx)
    })

    scaleBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            scaleLabel.text = "Render scale  ${50 + p}%"
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) {
            Cfg.scalePct = 50 + s.progress
            Cfg.save(ctx)
            onApply()
        }
    })

    boost.setOnCheckedChangeListener { _, checked ->
        Cfg.boost = checked
        Cfg.save(ctx)
    }
    return col
}
