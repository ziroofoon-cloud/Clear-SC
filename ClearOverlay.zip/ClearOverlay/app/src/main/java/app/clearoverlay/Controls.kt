package app.clearoverlay

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

/** Colors and small view factories shared by the app screen and the floating panel. */
object Ui {
    val BG = Color.parseColor("#0B1020")
    val CARD = Color.parseColor("#151B2E")
    val CHIP = Color.parseColor("#1F2940")
    val STROKE = Color.parseColor("#26324D")
    val ACCENT = Color.parseColor("#22D3EE")
    val ACCENT2 = Color.parseColor("#A78BFA")
    val TEXT = Color.parseColor("#F1F5F9")
    val MUTED = Color.parseColor("#94A3B8")
    val DANGER = Color.parseColor("#F87171")
    val OK = Color.parseColor("#4ADE80")

    fun themed(c: Context): Context = ContextThemeWrapper(c, android.R.style.Theme_DeviceDefault)

    fun round(color: Int, radius: Float, strokeColor: Int = 0, strokeW: Int = 0) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
        if (strokeW > 0) setStroke(strokeW, strokeColor)
    }

    fun gradient(radius: Float) =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(ACCENT, ACCENT2)).apply {
            cornerRadius = radius
        }

    fun text(c: Context, s: String, sp: Float, color: Int = TEXT, bold: Boolean = false) = TextView(c).apply {
        text = s
        textSize = sp
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }
}

/**
 * Horizontal swipe row: no scrollbar, soft fading edges so it is clear there is more to swipe to.
 * [row] holds the chips; [scrollToChip] centers a given chip (used to reveal the selected one).
 */
class ChipScroller(ctx: Context, val row: LinearLayout) : HorizontalScrollView(ctx) {
    init {
        isHorizontalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        isHorizontalFadingEdgeEnabled = true
        setFadingEdgeLength(dp(ctx, 28))
        isFillViewport = true
        clipToPadding = false
        addView(row, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT))
    }

    fun scrollToChip(chip: View, animate: Boolean = false) {
        post {
            val x = (chip.left - (width - chip.width) / 2).coerceAtLeast(0)
            if (animate) smoothScrollTo(x, 0) else scrollTo(x, 0)
        }
    }
}

/**
 * Mode chips, sharpness, anti-aliasing, render resolution, vivid colors, boost, bubble size and bubble auto-hide.
 * Used by the main screen and by the bubble's panel, so both always look and behave the same.
 * [onApply] is called when something needs the capture size to be re-applied (mode / render scale).
 * All labels come from res/values(-fa)/strings.xml, so the panel follows the device's language.
 */
fun buildControls(base: Context, onApply: () -> Unit): LinearLayout {
    val ctx = Ui.themed(Lang.wrap(base))
    val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }

    fun gap(v: Int) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(ctx, v) }

    // ---- mode chips
    col.addView(Ui.text(ctx, ctx.getString(R.string.mode_label), 12f, Ui.MUTED))
    val chipRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
    val names = arrayOf(
        ctx.getString(R.string.mode_sharpen),
        ctx.getString(R.string.mode_fsr),
        ctx.getString(R.string.mode_sgsr),
        ctx.getString(R.string.mode_fast),
        ctx.getString(R.string.mode_raw)
    )
    val chips = names.map { n ->
        TextView(ctx).apply {
            text = n
            textSize = 14f
            gravity = Gravity.CENTER
            minWidth = dp(ctx, 64)
            setPadding(dp(ctx, 16), dp(ctx, 10), dp(ctx, 16), dp(ctx, 10))
            maxLines = 1
        }
    }
    chips.forEach { chip ->
        chipRow.addView(
            chip,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginEnd = dp(ctx, 6)
            }
        )
    }
    val modeScroll = ChipScroller(ctx, chipRow)
    col.addView(modeScroll, gap(6))

    // ---- sharpness
    val sharpLabel = Ui.text(ctx, "", 14f)
    val sharpBar = SeekBar(ctx).apply {
        max = 100
        progress = (Cfg.sharp * 100).toInt()
    }
    sharpLabel.text = ctx.getString(R.string.sharpness_fmt, sharpBar.progress)
    col.addView(sharpLabel, gap(14))
    col.addView(sharpBar, gap(2))

    // ---- render resolution (presets + custom slider)
    // Phone resolution classes (1080p/1440p/4K) name the SHORT edge (width in portrait), not the
    // long one, e.g. a "1080p/FHD+" panel is usually 1080x2400, not 1080 tall. Presets are compared
    // against that short edge; the single scale factor this yields is then applied to both axes.
    val screenBounds = ctx.getSystemService(WindowManager::class.java)?.maximumWindowMetrics?.bounds
    val nativeW = screenBounds?.width() ?: 1080
    val nativeHFull = screenBounds?.height() ?: 2400
    val nativeH = minOf(nativeW, nativeHFull)
    col.addView(Ui.text(ctx, ctx.getString(R.string.render_resolution_label), 12f, Ui.MUTED), gap(14))
    val presetRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
    // label to preset-height pairs (short edge). Lower-than-native presets are for upscaling
    // (render low, upscale back); higher ones supersample. PRESET_CUSTOM (0) lets the slider drive scalePct.
    val presetDefs = Cfg.PRESETS.map { h ->
        (if (h == Cfg.PRESET_4K) ctx.getString(R.string.preset_4k) else "${h}p") to h
    } + (ctx.getString(R.string.preset_custom) to Cfg.PRESET_CUSTOM)
    val presetChips = presetDefs.map { (label, _) ->
        TextView(ctx).apply {
            text = label
            textSize = 13f
            gravity = Gravity.CENTER
            minWidth = dp(ctx, 56)
            maxLines = 1
            setPadding(dp(ctx, 14), dp(ctx, 8), dp(ctx, 14), dp(ctx, 8))
        }
    }
    presetChips.forEachIndexed { i, chip ->
        presetRow.addView(
            chip,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                if (i != presetChips.lastIndex) marginEnd = dp(ctx, 6)
            }
        )
    }
    val presetScroll = ChipScroller(ctx, presetRow)
    col.addView(presetScroll, gap(6))

    val scaleLabel = Ui.text(ctx, "", 14f)
    val scaleBar = SeekBar(ctx).apply {
        max = Cfg.SCALE_MAX - Cfg.SCALE_MIN
        progress = Cfg.scalePct.coerceIn(Cfg.SCALE_MIN, Cfg.SCALE_MAX) - Cfg.SCALE_MIN
    }
    fun scaleText(pct: Int) = ctx.getString(R.string.custom_scale_fmt, pct, nativeW, nativeHFull)
    scaleLabel.text = scaleText(Cfg.SCALE_MIN + scaleBar.progress)
    col.addView(scaleLabel, gap(10))
    col.addView(scaleBar, gap(2))
    val scaleHint = Ui.text(ctx, ctx.getString(R.string.scale_sharpen_hint), 12f, Ui.MUTED)
    col.addView(scaleHint, gap(4))

    // ---- anti-aliasing (swipeable chips + strength)
    col.addView(Ui.text(ctx, ctx.getString(R.string.aa_label), 12f, Ui.MUTED), gap(14))
    val aaRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
    val aaNames = listOf(
        ctx.getString(R.string.aa_off),
        ctx.getString(R.string.aa_fxaa_fast),
        ctx.getString(R.string.aa_fxaa_quality),
        ctx.getString(R.string.aa_edge)
    )
    val aaChips = aaNames.map { n ->
        TextView(ctx).apply {
            text = n
            textSize = 13f
            gravity = Gravity.CENTER
            minWidth = dp(ctx, 56)
            maxLines = 1
            setPadding(dp(ctx, 14), dp(ctx, 8), dp(ctx, 14), dp(ctx, 8))
        }
    }
    aaChips.forEachIndexed { i, chip ->
        aaRow.addView(
            chip,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                if (i != aaChips.lastIndex) marginEnd = dp(ctx, 6)
            }
        )
    }
    val aaScroll = ChipScroller(ctx, aaRow)
    col.addView(aaScroll, gap(6))
    val aaLabel = Ui.text(ctx, "", 14f)
    val aaBar = SeekBar(ctx).apply {
        max = 100
        progress = (Cfg.aaStrength * 100).toInt().coerceIn(0, 100)
        alpha = if (Cfg.aaMode == Cfg.AA_OFF) 0.4f else 1f
    }
    aaLabel.alpha = aaBar.alpha
    aaLabel.text = ctx.getString(R.string.aa_strength_fmt, aaBar.progress)
    col.addView(aaLabel, gap(10))
    col.addView(aaBar, gap(2))

    // ---- vivid colors
    val vividLabel = Ui.text(ctx, "", 14f)
    val vividBar = SeekBar(ctx).apply {
        max = 100
        progress = (Cfg.vivid * 100).toInt().coerceIn(0, 100)
    }
    vividLabel.text = ctx.getString(R.string.vivid_colors_fmt, vividBar.progress)
    col.addView(vividLabel, gap(14))
    col.addView(vividBar, gap(2))

    // ---- boost
    val boost = Switch(ctx).apply {
        text = ctx.getString(R.string.boost_switch)
        setTextColor(Ui.TEXT)
        isChecked = Cfg.boost
    }
    col.addView(boost, gap(12))

    // ---- bubble size
    val bubbleSizeLabel = Ui.text(ctx, "", 14f)
    val bubbleSizeBar = SeekBar(ctx).apply {
        max = Cfg.BUBBLE_MAX_DP - Cfg.BUBBLE_MIN_DP
        progress = Cfg.bubbleSizeDp.coerceIn(Cfg.BUBBLE_MIN_DP, Cfg.BUBBLE_MAX_DP) - Cfg.BUBBLE_MIN_DP
    }
    bubbleSizeLabel.text = ctx.getString(R.string.bubble_size_fmt, Cfg.BUBBLE_MIN_DP + bubbleSizeBar.progress)
    col.addView(bubbleSizeLabel, gap(14))
    col.addView(bubbleSizeBar, gap(2))

    // ---- bubble auto-hide
    val autoHide = Switch(ctx).apply {
        text = ctx.getString(R.string.bubble_autohide_switch)
        setTextColor(Ui.TEXT)
        isChecked = Cfg.bubbleSleep
    }
    col.addView(autoHide, gap(12))

    // ---- bubble sleep delay
    val sleepLabel = Ui.text(ctx, "", 14f)
    val sleepBar = SeekBar(ctx).apply {
        max = Cfg.BUBBLE_SLEEP_MAX_SEC - Cfg.BUBBLE_SLEEP_MIN_SEC
        progress = Cfg.bubbleSleepSec.coerceIn(Cfg.BUBBLE_SLEEP_MIN_SEC, Cfg.BUBBLE_SLEEP_MAX_SEC) - Cfg.BUBBLE_SLEEP_MIN_SEC
        alpha = if (Cfg.bubbleSleep) 1f else 0.4f
    }
    sleepLabel.alpha = sleepBar.alpha
    sleepLabel.text = ctx.getString(R.string.bubble_sleep_fmt, Cfg.BUBBLE_SLEEP_MIN_SEC + sleepBar.progress)
    col.addView(sleepLabel, gap(10))
    col.addView(sleepBar, gap(2))

    val tint = ColorStateList.valueOf(Ui.ACCENT)
    val track = ColorStateList.valueOf(Ui.STROKE)
    for (b in arrayOf(sharpBar, scaleBar, aaBar, vividBar, bubbleSizeBar, sleepBar)) {
        b.progressTintList = tint
        b.thumbTintList = tint
        b.progressBackgroundTintList = track
    }

    fun paintPresets() {
        val radius = dp(ctx, 10).toFloat()
        presetChips.forEachIndexed { i, chip ->
            val presetVal = presetDefs[i].second
            chip.isEnabled = true
            chip.alpha = 1f
            if (Cfg.renderPreset == presetVal) {
                chip.background = Ui.gradient(radius)
                chip.setTextColor(Ui.BG)
                chip.setTypeface(null, Typeface.BOLD)
                presetScroll.scrollToChip(chip)
            } else {
                chip.background = Ui.round(Ui.CHIP, radius)
                chip.setTextColor(Ui.MUTED)
                chip.setTypeface(null, Typeface.NORMAL)
            }
        }
    }

    fun paintAa() {
        val radius = dp(ctx, 10).toFloat()
        aaChips.forEachIndexed { i, chip ->
            if (Cfg.aaMode == i) {
                chip.background = Ui.gradient(radius)
                chip.setTextColor(Ui.BG)
                chip.setTypeface(null, Typeface.BOLD)
                aaScroll.scrollToChip(chip)
            } else {
                chip.background = Ui.round(Ui.CHIP, radius)
                chip.setTextColor(Ui.MUTED)
                chip.setTypeface(null, Typeface.NORMAL)
            }
        }
        aaBar.alpha = if (Cfg.aaMode == Cfg.AA_OFF) 0.4f else 1f
        aaLabel.alpha = aaBar.alpha
    }

    fun paint() {
        val radius = dp(ctx, 12).toFloat()
        chips.forEachIndexed { i, chip ->
            if (Cfg.mode == i) {
                chip.background = Ui.gradient(radius)
                chip.setTextColor(Ui.BG)
                chip.setTypeface(null, Typeface.BOLD)
                modeScroll.scrollToChip(chip)
            } else {
                chip.background = Ui.round(Ui.CHIP, radius)
                chip.setTextColor(Ui.MUTED)
                chip.setTypeface(null, Typeface.NORMAL)
            }
        }
        // The render-resolution controls are always active. In Sharpen mode only values above 100%
        // matter (supersampling); a short note says so.
        scaleHint.text = ctx.getString(if (Cfg.mode == Cfg.MODE_RAW) R.string.scale_raw_hint else R.string.scale_sharpen_hint)
        scaleHint.visibility = if (Cfg.mode == Cfg.MODE_SHARP || Cfg.mode == Cfg.MODE_RAW) android.view.View.VISIBLE else android.view.View.GONE
        paintPresets()
    }
    paint()
    paintAa()

    aaChips.forEachIndexed { i, chip ->
        chip.setOnClickListener {
            Cfg.aaMode = i
            Cfg.save(ctx)
            paintAa()
        }
    }

    aaBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            Cfg.aaStrength = p / 100f
            aaLabel.text = ctx.getString(R.string.aa_strength_fmt, p)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) = Cfg.save(ctx)
    })

    presetChips.forEachIndexed { i, chip ->
        chip.setOnClickListener {
            val presetVal = presetDefs[i].second
            Cfg.renderPreset = presetVal
            if (presetVal != Cfg.PRESET_CUSTOM) {
                val pct = Cfg.pctForPreset(presetVal, nativeH)
                Cfg.scalePct = pct
                scaleBar.progress = (pct - Cfg.SCALE_MIN).coerceIn(0, scaleBar.max)
                scaleLabel.text = scaleText(pct)
            }
            paintPresets()
            Cfg.save(ctx)
            onApply()
        }
    }

    chips.forEachIndexed { i, chip ->
        chip.setOnClickListener {
            Cfg.mode = i
            Cfg.save(ctx)
            paint()
            onApply()
        }
    }

    sharpBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            Cfg.sharp = p / 100f
            sharpLabel.text = ctx.getString(R.string.sharpness_fmt, p)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) = Cfg.save(ctx)
    })

    scaleBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            if (fromUser && Cfg.renderPreset != Cfg.PRESET_CUSTOM) {
                Cfg.renderPreset = Cfg.PRESET_CUSTOM
                paintPresets()
            }
            scaleLabel.text = scaleText(Cfg.SCALE_MIN + p)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) {
            Cfg.scalePct = Cfg.SCALE_MIN + s.progress
            Cfg.save(ctx)
            onApply()
        }
    })

    vividBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            Cfg.vivid = p / 100f
            vividLabel.text = ctx.getString(R.string.vivid_colors_fmt, p)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) = Cfg.save(ctx)
    })

    bubbleSizeBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            bubbleSizeLabel.text = ctx.getString(R.string.bubble_size_fmt, Cfg.BUBBLE_MIN_DP + p)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) {
            Cfg.bubbleSizeDp = Cfg.BUBBLE_MIN_DP + s.progress
            Cfg.save(ctx)
            OverlayService.instance?.applyBubbleSize()
        }
    })

    boost.setOnCheckedChangeListener { _, checked ->
        Cfg.boost = checked
        Cfg.save(ctx)
    }

    autoHide.setOnCheckedChangeListener { _, checked ->
        Cfg.bubbleSleep = checked
        Cfg.save(ctx)
        sleepBar.alpha = if (checked) 1f else 0.4f
        sleepLabel.alpha = sleepBar.alpha
        if (checked) OverlayService.instance?.refreshBubbleIdleTimer() else OverlayService.instance?.wakeBubble()
    }

    sleepBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            sleepLabel.text = ctx.getString(R.string.bubble_sleep_fmt, Cfg.BUBBLE_SLEEP_MIN_SEC + p)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) {
            Cfg.bubbleSleepSec = Cfg.BUBBLE_SLEEP_MIN_SEC + s.progress
            Cfg.save(ctx)
        }
    })

    // ---- reset to defaults
    val reset = Ui.text(ctx, ctx.getString(R.string.reset_defaults), 13f, Ui.ACCENT, true).apply {
        gravity = Gravity.CENTER
        setPadding(0, dp(ctx, 10), 0, 0)
    }
    col.addView(reset, gap(16))
    reset.setOnClickListener {
        Cfg.sharp = 0.7f
        Cfg.mode = Cfg.MODE_SHARP
        Cfg.scalePct = 100
        Cfg.renderPreset = Cfg.PRESET_CUSTOM
        Cfg.aaMode = Cfg.AA_OFF
        Cfg.aaStrength = 0.75f
        Cfg.vivid = 0f
        Cfg.boost = false
        Cfg.bubbleSizeDp = Cfg.BUBBLE_DEFAULT_DP
        Cfg.bubbleSleep = true
        Cfg.bubbleSleepSec = Cfg.BUBBLE_SLEEP_DEFAULT_SEC
        Cfg.save(ctx)

        sharpBar.progress = (Cfg.sharp * 100).toInt()
        sharpLabel.text = ctx.getString(R.string.sharpness_fmt, sharpBar.progress)
        scaleBar.progress = (Cfg.scalePct - Cfg.SCALE_MIN).coerceIn(0, scaleBar.max)
        scaleLabel.text = scaleText(Cfg.scalePct)
        aaBar.progress = 75
        aaLabel.text = ctx.getString(R.string.aa_strength_fmt, 75)
        vividBar.progress = 0
        vividLabel.text = ctx.getString(R.string.vivid_colors_fmt, 0)
        boost.isChecked = false
        bubbleSizeBar.progress = Cfg.BUBBLE_DEFAULT_DP - Cfg.BUBBLE_MIN_DP
        bubbleSizeLabel.text = ctx.getString(R.string.bubble_size_fmt, Cfg.BUBBLE_DEFAULT_DP)
        autoHide.isChecked = true
        sleepBar.progress = Cfg.BUBBLE_SLEEP_DEFAULT_SEC - Cfg.BUBBLE_SLEEP_MIN_SEC
        sleepLabel.text = ctx.getString(R.string.bubble_sleep_fmt, Cfg.BUBBLE_SLEEP_DEFAULT_SEC)
        sleepBar.alpha = 1f
        sleepLabel.alpha = 1f

        paint()
        paintAa()
        OverlayService.instance?.applyBubbleSize()
        OverlayService.instance?.refreshBubbleIdleTimer()
        onApply()
    }
    return col
}
