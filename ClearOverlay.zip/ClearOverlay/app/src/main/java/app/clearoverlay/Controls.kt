package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Toast
import android.widget.Switch
import android.widget.TextView

fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

/** Colors and small view factories shared by the app screen and the floating panel. */
object Ui {
    var BG = Color.parseColor("#0B1020")
    var CARD = Color.parseColor("#151B2E")
    var CHIP = Color.parseColor("#1F2940")
    var STROKE = Color.parseColor("#26324D")
    var ACCENT = Color.parseColor("#22D3EE")
    var ACCENT2 = Color.parseColor("#A78BFA")
    var TEXT = Color.parseColor("#F1F5F9")
    var MUTED = Color.parseColor("#94A3B8")
    var DANGER = Color.parseColor("#F87171")
    var OK = Color.parseColor("#4ADE80")

    /** True when the light palette is active; [classic] = flat square-ish look instead of rounded + gradient. */
    var light = false
    var classic = false

    /**
     * Picks the palette from the saved theme settings ([Cfg.themeMode] / [Cfg.themeStyle]; call Cfg.load first).
     * [forceDark] is used by the video / photo / manga screens, which sit on black: they always use the dark colours.
     */
    fun init(c: Context, forceDark: Boolean = false) {
        val night = (c.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
        light = !forceDark && when (Cfg.themeMode) { 1 -> false; 2 -> true; else -> !night }
        classic = Cfg.themeStyle == 1
        when {
            !classic && !light -> pal("#0B1020", "#151B2E", "#1F2940", "#26324D", "#22D3EE", "#A78BFA", "#F1F5F9", "#94A3B8", "#F87171", "#4ADE80")
            !classic && light -> pal("#F3F5FA", "#FFFFFF", "#E7EBF4", "#D3D9E8", "#0891B2", "#7C3AED", "#0F172A", "#586178", "#DC2626", "#15803D")
            classic && !light -> pal("#111111", "#1C1C1C", "#2B2B2B", "#434343", "#33B5E5", "#0099CC", "#EDEDED", "#A3A3A3", "#FF4444", "#99CC00")
            else -> pal("#ECECEC", "#FFFFFF", "#DEDEDE", "#BDBDBD", "#0288D1", "#01579B", "#212121", "#616161", "#C62828", "#2E7D32")
        }
    }

    private fun pal(bg: String, card: String, chip: String, stroke: String, a1: String, a2: String, text: String, muted: String, danger: String, ok: String) {
        BG = Color.parseColor(bg); CARD = Color.parseColor(card); CHIP = Color.parseColor(chip); STROKE = Color.parseColor(stroke)
        ACCENT = Color.parseColor(a1); ACCENT2 = Color.parseColor(a2); TEXT = Color.parseColor(text); MUTED = Color.parseColor(muted)
        DANGER = Color.parseColor(danger); OK = Color.parseColor(ok)
    }

    fun theme(): Int =
        if (light) android.R.style.Theme_DeviceDefault_Light_NoActionBar else android.R.style.Theme_DeviceDefault_NoActionBar

    /** Status / navigation bar colour and icon colour for the current palette. */
    fun styleBars(w: android.view.Window) {
        w.statusBarColor = BG
        w.navigationBarColor = BG
        runCatching {
            val m = android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            w.insetsController?.setSystemBarsAppearance(if (light) m else 0, m)
        }
    }

    fun themed(c: Context): Context =
        ContextThemeWrapper(c, if (light) android.R.style.Theme_DeviceDefault_Light else android.R.style.Theme_DeviceDefault)

    private fun rad(r: Float) = if (classic) r * 0.45f else r

    fun round(color: Int, radius: Float, strokeColor: Int = 0, strokeW: Int = 0) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = rad(radius)
        if (strokeW > 0) setStroke(strokeW, strokeColor)
    }

    fun gradient(radius: Float) =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, if (classic) intArrayOf(ACCENT, ACCENT) else intArrayOf(ACCENT, ACCENT2)).apply {
            cornerRadius = rad(radius)
        }

    /** One font family for the whole app: clean sans (Latin) with the system's Persian fallback; bold = medium weight. */
    val FONT: Typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    val FONT_BOLD: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)

    fun text(c: Context, s: String, sp: Float, color: Int = TEXT, bold: Boolean = false) = TextView(c).apply {
        text = s
        textSize = sp
        setTextColor(color)
        typeface = if (bold) FONT_BOLD else FONT
    }
}

/**
 * "Panel size" chips (small / medium / large), shared by every settings panel (player, manga reader, ...).
 * [onChange] is called after [Cfg.panelSize] changed and was saved.
 */
fun panelSizeRow(ctx: Context, onChange: () -> Unit): LinearLayout {
    val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    col.addView(Ui.text(ctx, ctx.getString(R.string.panel_size_label), 12f, Ui.MUTED))
    val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
    val chips = ArrayList<TextView>()
    fun paint() {
        val r = dp(ctx, 10).toFloat()
        chips.forEachIndexed { i, c ->
            if (i == Cfg.panelSize) {
                c.background = Ui.gradient(r)
                c.setTextColor(Ui.BG)
            } else {
                c.background = Ui.round(Ui.CHIP, r)
                c.setTextColor(Ui.MUTED)
            }
        }
    }
    listOf(R.string.panel_size_small, R.string.panel_size_medium, R.string.panel_size_large).forEachIndexed { i, r ->
        val c = TextView(ctx).apply {
            text = ctx.getString(r)
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(dp(ctx, 6), dp(ctx, 7), dp(ctx, 6), dp(ctx, 7))
            setOnClickListener {
                Cfg.panelSize = i
                Cfg.save(ctx)
                paint()
                onChange()
            }
        }
        chips.add(c)
        row.addView(c, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i > 0) marginStart = dp(ctx, 6) })
    }
    paint()
    col.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(ctx, 4) })
    return col
}

/** A thin divider + accent title that groups the options of one kind (playback, effect, panel ...) in a settings panel. */
fun panelSection(ctx: Context, title: String): LinearLayout {
    val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    col.addView(View(ctx).apply { setBackgroundColor(Ui.STROKE) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 1)))
    col.addView(
        Ui.text(ctx, title, 13f, Ui.ACCENT, true),
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(ctx, 8) }
    )
    return col
}

/**
 * Title row of a floating settings panel: title, lock (🔒 / 🔓: unlocked = drag the panel by this row) and close.
 * [target] is the panel that moves, [clamp] keeps it inside the window, [say] shows a short message.
 */
fun panelHeader(ctx: Context, title: String, target: View, clamp: () -> Unit, onClose: () -> Unit, say: (String) -> Unit): LinearLayout {
    val head = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL }
    head.addView(Ui.text(ctx, title, 18f, Ui.TEXT, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
    val lock = Ui.text(ctx, if (Cfg.panelLocked) "🔒" else "🔓", 18f, Ui.ACCENT, true).apply {
        setPadding(dp(ctx, 10), dp(ctx, 4), dp(ctx, 6), dp(ctx, 4))
    }
    lock.setOnClickListener {
        Cfg.panelLocked = !Cfg.panelLocked
        Cfg.save(ctx)
        lock.text = if (Cfg.panelLocked) "🔒" else "🔓"
        say(ctx.getString(if (Cfg.panelLocked) R.string.panel_locked else R.string.panel_unlocked))
    }
    head.addView(lock)
    var dx0 = 0f
    var dy0 = 0f
    var tx0 = 0f
    var ty0 = 0f
    head.setOnTouchListener { v, ev ->
        if (Cfg.panelLocked) return@setOnTouchListener false
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dx0 = ev.rawX; dy0 = ev.rawY
                tx0 = target.translationX; ty0 = target.translationY
                v.parent?.requestDisallowInterceptTouchEvent(true)
                true
            }
            MotionEvent.ACTION_MOVE -> {
                target.translationX = tx0 + (ev.rawX - dx0)
                target.translationY = ty0 + (ev.rawY - dy0)
                clamp()
                true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> true
            else -> false
        }
    }
    head.addView(Ui.text(ctx, "✕", 20f, Ui.ACCENT, true).apply {
        setPadding(dp(ctx, 12), dp(ctx, 4), dp(ctx, 4), dp(ctx, 4))
        setOnClickListener { onClose() }
    })
    return head
}

/** A labelled on/off switch in the panel's style. */
fun panelSwitch(ctx: Context, label: String, checked: Boolean, onChange: (Boolean) -> Unit) = Switch(ctx).apply {
    text = label
    setTextColor(Ui.TEXT)
    isChecked = checked
    setOnCheckedChangeListener { _, c -> onChange(c) }
}

/** Lets code outside the panel (Auto, the player) tell the currently built settings panel to refresh its views. */
object ControlsBus {
    @Volatile var sync: (() -> Unit)? = null
}

/**
 * Horizontal swipe row: no scrollbar, soft fading edges so it is clear there is more to swipe to.
 * [row] holds the chips; [scrollToChip] centers a given chip (used to reveal the selected one).
 */
class ChipScroller(ctx: Context, val row: LinearLayout) : HorizontalScrollView(ctx) {
    init {
        isHorizontalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        isHorizontalFadingEdgeEnabled = true
        setFadingEdgeLength(dp(ctx, 28))
        isFillViewport = true
        clipToPadding = false
        addView(row, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT))
    }

    fun scrollToChip(chip: View, animate: Boolean = false) {
        post {
            val x = (chip.left - (width - chip.width) / 2).coerceAtLeast(0)
            if (animate) smoothScrollTo(x, 0) else scrollTo(x, 0)
        }
    }
}

/**
 * Mode chips, sharpness, detail/deblur, anti-aliasing, render resolution, vivid colors, boost, bubble size and bubble auto-hide.
 * Used by the main screen and by the bubble's panel, so both always look and behave the same.
 * [onApply] is called when something needs the capture size to be re-applied (mode / render scale).
 * [onAdjust] gets true when a finger goes down on any slider and false when it lifts (used to fade the panel).
 * [inPlayer] = built for the video / photo player (profiles then use FSR 1 upscaling); [sourceScale] gives the current
 * output-size / source-size ratio there, which the "Auto" strength uses.
 * All labels come from res/values(-fa)/strings.xml, so the panel follows the device's language.
 */
fun buildControls(
    base: Context,
    onAdjust: (Boolean) -> Unit = {},
    inPlayer: Boolean = false,
    sourceScale: () -> Float = { 1f },
    autoPick: (() -> Auto.Pick?)? = null,
    onApply: () -> Unit
): LinearLayout {
    val ctx = Ui.themed(Lang.wrap(base))
    val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    val profileNamesRes = intArrayOf(
        R.string.profile_video, R.string.profile_stream, R.string.profile_game,
        R.string.profile_photo, R.string.profile_movie, R.string.profile_anime, R.string.profile_text, R.string.profile_manga
    )
    val budgetNamesRes = intArrayOf(R.string.budget_perf, R.string.budget_balanced, R.string.budget_quality)

    fun gap(v: Int) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(ctx, v) }

    // ---- Auto: the app picks profile, strength, budget, AA, mode and AI model itself
    val autoSwitch = Switch(ctx).apply {
        text = ctx.getString(R.string.auto_switch)
        setTextColor(Ui.TEXT)
        textSize = 15f
        isChecked = Cfg.autoMode
    }
    var autoSilent = false
    fun autoOff() {
        if (!Cfg.autoMode) return
        Cfg.autoMode = false
        Cfg.save(ctx)
        autoSilent = true
        autoSwitch.isChecked = false
        autoSilent = false
    }
    col.addView(autoSwitch)
    col.addView(Ui.text(ctx, ctx.getString(R.string.auto_hint), 12f, Ui.MUTED), gap(2))
    val autoWhy = Ui.text(ctx, "", 12f, Ui.ACCENT2)
    autoWhy.visibility = View.GONE
    col.addView(autoWhy, gap(2))

    // ---- my profiles (saved by the user; filled in at the end of this function, after syncAll exists)
    var onUserEdited: () -> Unit = {}
    var refreshUser: () -> Unit = {}
    col.addView(Ui.text(ctx, ctx.getString(R.string.uprof_label), 12f, Ui.MUTED), gap(14))
    val userRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
    col.addView(ChipScroller(ctx, userRow), gap(6))
    col.addView(Ui.text(ctx, ctx.getString(R.string.uprof_hint), 12f, Ui.MUTED), gap(4))

    // ---- quick profiles (momentary: apply a set of values, everything below updates)
    col.addView(Ui.text(ctx, ctx.getString(R.string.profiles_label), 12f, Ui.MUTED), gap(14))
    val profileRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
    val profileNames = listOf(
        ctx.getString(R.string.profile_video),
        ctx.getString(R.string.profile_stream),
        ctx.getString(R.string.profile_game),
        ctx.getString(R.string.profile_photo),
        ctx.getString(R.string.profile_movie),
        ctx.getString(R.string.profile_anime),
        ctx.getString(R.string.profile_text),
        ctx.getString(R.string.profile_manga)
    )
    val profileDescs = listOf(
        R.string.profile_desc_video, R.string.profile_desc_stream, R.string.profile_desc_game,
        R.string.profile_desc_photo, R.string.profile_desc_movie, R.string.profile_desc_anime, R.string.profile_desc_text, R.string.profile_desc_manga
    )
    val profileChips = profileNames.map { n ->
        TextView(ctx).apply {
            text = n
            textSize = 13f
            gravity = Gravity.CENTER
            minWidth = dp(ctx, 56)
            maxLines = 1
            setPadding(dp(ctx, 14), dp(ctx, 8), dp(ctx, 14), dp(ctx, 8))
            background = Ui.round(Ui.CHIP, dp(ctx, 10).toFloat(), Ui.ACCENT, dp(ctx, 1))
            setTextColor(Ui.ACCENT)
        }
    }
    profileChips.forEachIndexed { i, chip ->
        profileRow.addView(
            chip,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                if (i != profileChips.lastIndex) marginEnd = dp(ctx, 6)
            }
        )
    }
    col.addView(ChipScroller(ctx, profileRow), gap(6))

    // ---- profile strength (like DLSS Quality / Balanced / Performance)
    col.addView(Ui.text(ctx, ctx.getString(R.string.profile_level_label), 12f, Ui.MUTED), gap(10))
    val levelRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
    val levelNames = ArrayList<String>().apply {
        add(ctx.getString(R.string.level_light))
        add(ctx.getString(R.string.level_balanced))
        add(ctx.getString(R.string.level_strong))
        if (inPlayer) add(ctx.getString(R.string.level_auto))
    }
    val levelChips = levelNames.map { n ->
        TextView(ctx).apply {
            text = n
            textSize = 13f
            gravity = Gravity.CENTER
            minWidth = dp(ctx, 56)
            maxLines = 1
            setPadding(dp(ctx, 14), dp(ctx, 8), dp(ctx, 14), dp(ctx, 8))
        }
    }
    levelChips.forEachIndexed { i, chip ->
        levelRow.addView(
            chip,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                if (i != levelChips.lastIndex) marginEnd = dp(ctx, 6)
            }
        )
    }
    col.addView(ChipScroller(ctx, levelRow), gap(6))

    // ---- GPU budget (like DLSS Performance / Balanced / Quality): how much work per frame
    col.addView(Ui.text(ctx, ctx.getString(R.string.profile_budget_label), 12f, Ui.MUTED), gap(10))
    val budgetRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
    val budgetChips = listOf(R.string.budget_perf, R.string.budget_balanced, R.string.budget_quality).map { r ->
        TextView(ctx).apply {
            text = ctx.getString(r)
            textSize = 13f
            gravity = Gravity.CENTER
            minWidth = dp(ctx, 56)
            maxLines = 1
            setPadding(dp(ctx, 14), dp(ctx, 8), dp(ctx, 14), dp(ctx, 8))
        }
    }
    budgetChips.forEachIndexed { i, chip ->
        budgetRow.addView(
            chip,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                if (i != budgetChips.lastIndex) marginEnd = dp(ctx, 6)
            }
        )
    }
    col.addView(ChipScroller(ctx, budgetRow), gap(6))
    col.addView(Ui.text(ctx, ctx.getString(R.string.profile_hint), 12f, Ui.MUTED), gap(4))
    val profileDesc = Ui.text(ctx, "", 12f, Ui.ACCENT2)
    col.addView(profileDesc, gap(4))

    /** Selected profile + strength are highlighted; touching any slider clears the profile (values are then custom). */
    fun paintProfiles() {
        val radius = dp(ctx, 10).toFloat()
        val di = Cfg.profileType
        if (di in profileDescs.indices) {
            profileDesc.text = ctx.getString(profileDescs[di])
            profileDesc.visibility = View.VISIBLE
        } else {
            profileDesc.visibility = View.GONE
        }
        profileChips.forEachIndexed { i, chip ->
            if (Cfg.profileType == i) {
                chip.background = Ui.gradient(radius)
                chip.setTextColor(Ui.BG)
                chip.setTypeface(null, Typeface.BOLD)
            } else {
                chip.background = Ui.round(Ui.CHIP, radius, Ui.ACCENT, dp(ctx, 1))
                chip.setTextColor(Ui.ACCENT)
                chip.setTypeface(null, Typeface.NORMAL)
            }
        }
        budgetChips.forEachIndexed { i, chip ->
            if (Cfg.profileBudget == i) {
                chip.background = Ui.round(Ui.ACCENT, radius)
                chip.setTextColor(Ui.BG)
                chip.setTypeface(null, Typeface.BOLD)
            } else {
                chip.background = Ui.round(Ui.CHIP, radius)
                chip.setTextColor(Ui.MUTED)
                chip.setTypeface(null, Typeface.NORMAL)
            }
        }
        levelChips.forEachIndexed { i, chip ->
            if (Cfg.profileLevel.coerceAtMost(levelChips.size - 1) == i) {
                chip.background = Ui.round(Ui.ACCENT2, radius)
                chip.setTextColor(Ui.BG)
                chip.setTypeface(null, Typeface.BOLD)
            } else {
                chip.background = Ui.round(Ui.CHIP, radius)
                chip.setTextColor(Ui.MUTED)
                chip.setTypeface(null, Typeface.NORMAL)
            }
        }
    }
    paintProfiles()

    // ---- mode chips
    col.addView(Ui.text(ctx, ctx.getString(R.string.mode_label), 12f, Ui.MUTED), gap(14))
    val chipRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
    // shown order -> mode value (CRSC Lanczos sits before Fast and Raw)
    val modeOrder = intArrayOf(Cfg.MODE_SHARP, Cfg.MODE_FSR, Cfg.MODE_SGSR, Cfg.MODE_LANCZOS, Cfg.MODE_FAST, Cfg.MODE_RAW)
    val names = arrayOf(
        ctx.getString(R.string.mode_sharpen),
        ctx.getString(R.string.mode_fsr),
        ctx.getString(R.string.mode_sgsr),
        ctx.getString(R.string.mode_lanczos),
        ctx.getString(R.string.mode_fast),
        ctx.getString(R.string.mode_raw)
    )
    val chips = names.map { n ->
        TextView(ctx).apply {
            text = n
            textSize = 14f
            gravity = Gravity.CENTER
            minWidth = dp(ctx, 64)
            setPadding(dp(ctx, 16), dp(ctx, 10), dp(ctx, 16), dp(ctx, 10))
            maxLines = 1
        }
    }
    chips.forEach { chip ->
        chipRow.addView(
            chip,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginEnd = dp(ctx, 6)
            }
        )
    }
    val modeScroll = ChipScroller(ctx, chipRow)
    col.addView(modeScroll, gap(6))

    // ---- sharpness
    val sharpLabel = Ui.text(ctx, "", 14f)
    val sharpBar = SeekBar(ctx).apply {
        max = 100
        progress = (Cfg.sharp * 100).toInt()
    }
    sharpLabel.text = ctx.getString(R.string.sharpness_fmt, sharpBar.progress)
    col.addView(sharpLabel, gap(14))
    col.addView(sharpBar, gap(2))

    // ---- detail / deblur (wide unsharp mask for soft, already-upscaled sources like low-res video)
    val detailLabel = Ui.text(ctx, "", 14f)
    val detailBar = SeekBar(ctx).apply {
        max = 100
        progress = (Cfg.detail * 100).toInt().coerceIn(0, 100)
    }
    detailLabel.text = ctx.getString(R.string.detail_fmt, detailBar.progress)
    col.addView(detailLabel, gap(14))
    col.addView(detailBar, gap(2))
    val detailSizeLabel = Ui.text(ctx, "", 14f)
    val detailSizeBar = SeekBar(ctx).apply {
        max = 100
        progress = (Cfg.detailSize * 100).toInt().coerceIn(0, 100)
        alpha = if (Cfg.detail > 0f) 1f else 0.4f
    }
    detailSizeLabel.alpha = detailSizeBar.alpha
    detailSizeLabel.text = ctx.getString(R.string.detail_size_fmt, detailSizeBar.progress)
    col.addView(detailSizeLabel, gap(10))
    col.addView(detailSizeBar, gap(2))

    // ---- denoise / deblock and deband (clean up low-bitrate video before sharpening)
    val denoiseLabel = Ui.text(ctx, "", 14f)
    val denoiseBar = SeekBar(ctx).apply {
        max = 100
        progress = (Cfg.denoise * 100).toInt().coerceIn(0, 100)
    }
    denoiseLabel.text = ctx.getString(R.string.denoise_fmt, denoiseBar.progress)
    col.addView(denoiseLabel, gap(14))
    col.addView(denoiseBar, gap(2))
    val debandLabel = Ui.text(ctx, "", 14f)
    val debandBar = SeekBar(ctx).apply {
        max = 100
        progress = (Cfg.deband * 100).toInt().coerceIn(0, 100)
    }
    debandLabel.text = ctx.getString(R.string.deband_fmt, debandBar.progress)
    col.addView(debandLabel, gap(10))
    col.addView(debandBar, gap(2))

    // ---- render resolution (presets + custom slider)
    // Phone resolution classes (1080p/1440p/4K) name the SHORT edge (width in portrait), not the
    // long one, e.g. a "1080p/FHD+" panel is usually 1080x2400, not 1080 tall. Presets are compared
    // against that short edge; the single scale factor this yields is then applied to both axes.
    val screenBounds = ctx.getSystemService(WindowManager::class.java)?.maximumWindowMetrics?.bounds
    val nativeW = screenBounds?.width() ?: 1080
    val nativeHFull = screenBounds?.height() ?: 2400
    val nativeH = minOf(nativeW, nativeHFull)
    if (!inPlayer) col.addView(Ui.text(ctx, ctx.getString(R.string.render_resolution_label), 12f, Ui.MUTED), gap(14))
    val presetRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
    // label to preset-height pairs (short edge). Lower-than-native presets are for upscaling
    // (render low, upscale back); higher ones supersample. PRESET_CUSTOM (0) lets the slider drive scalePct.
    val presetDefs = Cfg.PRESETS.map { h ->
        (if (h == Cfg.PRESET_4K) ctx.getString(R.string.preset_4k) else "${h}p") to h
    } + (ctx.getString(R.string.preset_custom) to Cfg.PRESET_CUSTOM)
    val presetChips = presetDefs.map { (label, _) ->
        TextView(ctx).apply {
            text = label
            textSize = 13f
            gravity = Gravity.CENTER
            minWidth = dp(ctx, 56)
            maxLines = 1
            setPadding(dp(ctx, 14), dp(ctx, 8), dp(ctx, 14), dp(ctx, 8))
        }
    }
    presetChips.forEachIndexed { i, chip ->
        presetRow.addView(
            chip,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                if (i != presetChips.lastIndex) marginEnd = dp(ctx, 6)
            }
        )
    }
    val presetScroll = ChipScroller(ctx, presetRow)
    if (!inPlayer) col.addView(presetScroll, gap(6))

    val scaleLabel = Ui.text(ctx, "", 14f)
    val scaleBar = SeekBar(ctx).apply {
        max = Cfg.SCALE_MAX - Cfg.SCALE_MIN
        progress = Cfg.scalePct.coerceIn(Cfg.SCALE_MIN, Cfg.SCALE_MAX) - Cfg.SCALE_MIN
    }
    fun scaleText(pct: Int) = ctx.getString(R.string.custom_scale_fmt, pct, nativeW, nativeHFull)
    scaleLabel.text = scaleText(Cfg.SCALE_MIN + scaleBar.progress)
    val scaleHint = Ui.text(ctx, ctx.getString(R.string.scale_sharpen_hint), 12f, Ui.MUTED)
    if (!inPlayer) {
        col.addView(scaleLabel, gap(10))
        col.addView(scaleBar, gap(2))
        col.addView(scaleHint, gap(4))
    } else {
        // ---- player / photo: input resolution -> output resolution (the player's own resolution chain)
        col.addView(Ui.text(ctx, ctx.getString(R.string.res_chain_title), 12f, Ui.MUTED), gap(14))
        val info = Ui.text(ctx, "", 12f, Ui.ACCENT).apply { setTextIsSelectable(false) }
        col.addView(info, gap(4))
        fun refreshInfo() {
            if (!info.isAttachedToWindow) return
            info.text = ctx.getString(R.string.res_chain_info_fmt, Cfg.resInfo.ifEmpty { "-" })
            info.postDelayed({ refreshInfo() }, 600)
        }
        info.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) = refreshInfo()
            override fun onViewDetachedFromWindow(v: View) {}
        })
        fun resChips(label: String, labels: List<String>, values: List<Int>, get: () -> Int, set: (Int) -> Unit) {
            col.addView(Ui.text(ctx, label, 13f, Ui.TEXT), gap(10))
            val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            val chips = ArrayList<TextView>()
            fun paint() {
                val r = dp(ctx, 10).toFloat()
                chips.forEachIndexed { i, ch ->
                    val on = values[i] == get()
                    ch.background = if (on) Ui.gradient(r) else Ui.round(Ui.CHIP, r)
                    ch.setTextColor(if (on) Ui.BG else Ui.MUTED)
                }
            }
            labels.forEachIndexed { i, l ->
                val ch = TextView(ctx).apply {
                    text = l
                    textSize = 13f
                    gravity = Gravity.CENTER
                    minWidth = dp(ctx, 52)
                    maxLines = 1
                    setPadding(dp(ctx, 12), dp(ctx, 8), dp(ctx, 12), dp(ctx, 8))
                    setOnClickListener {
                        onUserEdited()
                        set(values[i])
                        Cfg.save(ctx)
                        paint()
                        onApply()
                    }
                }
                chips.add(ch)
                row.addView(ch, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    if (i != labels.lastIndex) marginEnd = dp(ctx, 6)
                })
            }
            paint()
            col.addView(ChipScroller(ctx, row), gap(4))
        }
        val auto = ctx.getString(R.string.res_auto)
        resChips(
            ctx.getString(R.string.res_input_label),
            listOf(auto, "240p", "360p", "480p", "540p", "720p", "1080p"),
            listOf(0, 240, 360, 480, 540, 720, 1080), { Cfg.inRes }, { Cfg.inRes = it }
        )
        resChips(
            ctx.getString(R.string.res_output_label),
            listOf(auto, "480p", "540p", "720p", "1080p", "1440p", ctx.getString(R.string.preset_4k)),
            listOf(0, 480, 540, 720, 1080, 1440, 2160), { Cfg.outRes }, { Cfg.outRes = it }
        )
        col.addView(Ui.text(ctx, ctx.getString(R.string.res_chain_hint), 12f, Ui.MUTED), gap(4))
    }

    // ---- anti-aliasing (swipeable chips + strength)
    col.addView(Ui.text(ctx, ctx.getString(R.string.aa_label), 12f, Ui.MUTED), gap(14))
    val aaRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
    val aaNames = listOf(
        ctx.getString(R.string.aa_off),
        ctx.getString(R.string.aa_fxaa_fast),
        ctx.getString(R.string.aa_fxaa_quality),
        ctx.getString(R.string.aa_edge)
    )
    val aaChips = aaNames.map { n ->
        TextView(ctx).apply {
            text = n
            textSize = 13f
            gravity = Gravity.CENTER
            minWidth = dp(ctx, 56)
            maxLines = 1
            setPadding(dp(ctx, 14), dp(ctx, 8), dp(ctx, 14), dp(ctx, 8))
        }
    }
    aaChips.forEachIndexed { i, chip ->
        aaRow.addView(
            chip,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                if (i != aaChips.lastIndex) marginEnd = dp(ctx, 6)
            }
        )
    }
    val aaScroll = ChipScroller(ctx, aaRow)
    col.addView(aaScroll, gap(6))
    val aaLabel = Ui.text(ctx, "", 14f)
    val aaBar = SeekBar(ctx).apply {
        max = 100
        progress = (Cfg.aaStrength * 100).toInt().coerceIn(0, 100)
        alpha = if (Cfg.aaMode == Cfg.AA_OFF) 0.4f else 1f
    }
    aaLabel.alpha = aaBar.alpha
    aaLabel.text = ctx.getString(R.string.aa_strength_fmt, aaBar.progress)
    col.addView(aaLabel, gap(10))
    col.addView(aaBar, gap(2))

    // ---- vivid colors
    val vividLabel = Ui.text(ctx, "", 14f)
    val vividBar = SeekBar(ctx).apply {
        max = 100
        progress = (Cfg.vivid * 100).toInt().coerceIn(0, 100)
    }
    vividLabel.text = ctx.getString(R.string.vivid_colors_fmt, vividBar.progress)
    col.addView(vividLabel, gap(14))
    col.addView(vividBar, gap(2))

    // ---- contrast (-50 .. +50 around the middle)
    val contrastLabel = Ui.text(ctx, "", 14f)
    val contrastBar = SeekBar(ctx).apply {
        max = 100
        progress = ((Cfg.contrast + 1f) * 50f).toInt().coerceIn(0, 100)
    }
    contrastLabel.text = ctx.getString(R.string.contrast_fmt, contrastBar.progress - 50)
    col.addView(contrastLabel, gap(14))
    col.addView(contrastBar, gap(2))

    // ---- boost
    val boost = Switch(ctx).apply {
        text = ctx.getString(R.string.boost_switch)
        setTextColor(Ui.TEXT)
        isChecked = Cfg.boost
    }
    col.addView(boost, gap(12))

    // ---- layer opacity (screen overlay only): blends the processed layer with the real screen below
    val layerLabel = Ui.text(ctx, "", 14f)
    val layerBar = SeekBar(ctx).apply {
        max = 100
        progress = (Cfg.dim * 100).toInt().coerceIn(0, 100)
    }
    layerLabel.text = ctx.getString(R.string.layer_alpha_fmt, layerBar.progress)
    if (!inPlayer) {
        col.addView(layerLabel, gap(14))
        col.addView(layerBar, gap(2))
        col.addView(Ui.text(ctx, ctx.getString(R.string.layer_alpha_hint), 12f, Ui.MUTED), gap(2))
    }
    layerBar.progressTintList = ColorStateList.valueOf(Ui.ACCENT)
    layerBar.thumbTintList = ColorStateList.valueOf(Ui.ACCENT)
    layerBar.progressBackgroundTintList = ColorStateList.valueOf(Ui.STROKE)
    layerBar.setOnTouchListener { _, ev ->
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> onAdjust(true)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> onAdjust(false)
        }
        false
    }
    layerBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            layerLabel.text = ctx.getString(R.string.layer_alpha_fmt, p)
            if (fromUser) {
                Cfg.dim = p / 100f
                OverlayService.instance?.applyLayerAlpha() // live
            }
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) {
            Cfg.dim = s.progress / 100f
            Cfg.save(ctx)
            OverlayService.instance?.applyLayerAlpha()
        }
    })

    // ---- bubble size
    val bubbleSizeLabel = Ui.text(ctx, "", 14f)
    val bubbleSizeBar = SeekBar(ctx).apply {
        max = Cfg.BUBBLE_MAX_DP - Cfg.BUBBLE_MIN_DP
        progress = Cfg.bubbleSizeDp.coerceIn(Cfg.BUBBLE_MIN_DP, Cfg.BUBBLE_MAX_DP) - Cfg.BUBBLE_MIN_DP
    }
    bubbleSizeLabel.text = ctx.getString(R.string.bubble_size_fmt, Cfg.BUBBLE_MIN_DP + bubbleSizeBar.progress)
    // the bubble belongs to the screen layer only: no bubble rows in the video / photo / manga / GIF panels
    if (!inPlayer) {
        col.addView(bubbleSizeLabel, gap(14))
        col.addView(bubbleSizeBar, gap(2))
    }

    // ---- bubble auto-hide
    val autoHide = Switch(ctx).apply {
        text = ctx.getString(R.string.bubble_autohide_switch)
        setTextColor(Ui.TEXT)
        isChecked = Cfg.bubbleSleep
    }
    if (!inPlayer) col.addView(autoHide, gap(12))

    // ---- bubble sleep delay
    val sleepLabel = Ui.text(ctx, "", 14f)
    val sleepBar = SeekBar(ctx).apply {
        max = Cfg.BUBBLE_SLEEP_MAX_SEC - Cfg.BUBBLE_SLEEP_MIN_SEC
        progress = Cfg.bubbleSleepSec.coerceIn(Cfg.BUBBLE_SLEEP_MIN_SEC, Cfg.BUBBLE_SLEEP_MAX_SEC) - Cfg.BUBBLE_SLEEP_MIN_SEC
        alpha = if (Cfg.bubbleSleep) 1f else 0.4f
    }
    sleepLabel.alpha = sleepBar.alpha
    sleepLabel.text = ctx.getString(R.string.bubble_sleep_fmt, Cfg.BUBBLE_SLEEP_MIN_SEC + sleepBar.progress)
    if (!inPlayer) {
        col.addView(sleepLabel, gap(10))
        col.addView(sleepBar, gap(2))
    }

    // ---- fade the panel while adjusting
    val fade = Switch(ctx).apply {
        text = ctx.getString(R.string.panel_fade_switch)
        setTextColor(Ui.TEXT)
        isChecked = Cfg.panelFade
    }
    col.addView(fade, gap(12))
    col.addView(Ui.text(ctx, ctx.getString(R.string.panel_fade_hint), 12f, Ui.MUTED), gap(4))
    fade.setOnCheckedChangeListener { _, checked ->
        Cfg.panelFade = checked
        Cfg.save(ctx)
    }
    // how transparent the panel gets while a slider is held (100% = it never dims)
    val fadeLvlLabel = Ui.text(ctx, "", 14f)
    val fadeLvlBar = SeekBar(ctx).apply {
        max = 95
        progress = (Cfg.panelFadeLevel * 100).toInt().coerceIn(5, 100) - 5
    }
    fadeLvlLabel.text = ctx.getString(R.string.panel_opacity_fmt, fadeLvlBar.progress + 5)
    col.addView(fadeLvlLabel, gap(10))
    col.addView(fadeLvlBar, gap(2))
    col.addView(Ui.text(ctx, ctx.getString(R.string.panel_opacity_hint), 12f, Ui.MUTED), gap(2))
    fadeLvlBar.progressTintList = ColorStateList.valueOf(Ui.ACCENT)
    fadeLvlBar.thumbTintList = ColorStateList.valueOf(Ui.ACCENT)
    fadeLvlBar.progressBackgroundTintList = ColorStateList.valueOf(Ui.STROKE)
    fadeLvlBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            fadeLvlLabel.text = ctx.getString(R.string.panel_opacity_fmt, p + 5)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) {
            Cfg.panelFadeLevel = (s.progress + 5) / 100f
            Cfg.save(ctx)
        }
    })
    if (inPlayer) {
        val autoClose = Switch(ctx).apply {
            text = ctx.getString(R.string.panel_autoclose_switch)
            setTextColor(Ui.TEXT)
            isChecked = Cfg.panelAutoClose
        }
        col.addView(autoClose, gap(12))
        autoClose.setOnCheckedChangeListener { _, checked ->
            Cfg.panelAutoClose = checked
            Cfg.save(ctx)
        }
    }

    val tint = ColorStateList.valueOf(Ui.ACCENT)
    val track = ColorStateList.valueOf(Ui.STROKE)
    for (b in arrayOf(sharpBar, detailBar, detailSizeBar, denoiseBar, debandBar, scaleBar, aaBar, vividBar, contrastBar, bubbleSizeBar, sleepBar)) {
        b.progressTintList = tint
        b.thumbTintList = tint
        b.progressBackgroundTintList = track
        b.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    if (b !== bubbleSizeBar && b !== sleepBar) {
                        if (Cfg.profileType != -1) {
                            Cfg.profileType = -1
                            paintProfiles()
                        }
                        onUserEdited()
                    }
                    onAdjust(true)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> onAdjust(false)
            }
            false
        }
    }

    fun paintPresets() {
        val radius = dp(ctx, 10).toFloat()
        presetChips.forEachIndexed { i, chip ->
            val presetVal = presetDefs[i].second
            chip.isEnabled = true
            chip.alpha = 1f
            if (Cfg.renderPreset == presetVal) {
                chip.background = Ui.gradient(radius)
                chip.setTextColor(Ui.BG)
                chip.setTypeface(null, Typeface.BOLD)
                presetScroll.scrollToChip(chip)
            } else {
                chip.background = Ui.round(Ui.CHIP, radius)
                chip.setTextColor(Ui.MUTED)
                chip.setTypeface(null, Typeface.NORMAL)
            }
        }
    }

    fun paintAa() {
        val radius = dp(ctx, 10).toFloat()
        aaChips.forEachIndexed { i, chip ->
            if (Cfg.aaMode == i) {
                chip.background = Ui.gradient(radius)
                chip.setTextColor(Ui.BG)
                chip.setTypeface(null, Typeface.BOLD)
                aaScroll.scrollToChip(chip)
            } else {
                chip.background = Ui.round(Ui.CHIP, radius)
                chip.setTextColor(Ui.MUTED)
                chip.setTypeface(null, Typeface.NORMAL)
            }
        }
        aaBar.alpha = if (Cfg.aaMode == Cfg.AA_OFF) 0.4f else 1f
        aaLabel.alpha = aaBar.alpha
    }

    fun paint() {
        val radius = dp(ctx, 12).toFloat()
        chips.forEachIndexed { i, chip ->
            if (Cfg.mode == modeOrder[i]) {
                chip.background = Ui.gradient(radius)
                chip.setTextColor(Ui.BG)
                chip.setTypeface(null, Typeface.BOLD)
                modeScroll.scrollToChip(chip)
            } else {
                chip.background = Ui.round(Ui.CHIP, radius)
                chip.setTextColor(Ui.MUTED)
                chip.setTypeface(null, Typeface.NORMAL)
            }
        }
        // The render-resolution controls are always active. In Sharpen mode only values above 100%
        // matter (supersampling); a short note says so.
        scaleHint.text = ctx.getString(if (Cfg.mode == Cfg.MODE_RAW) R.string.scale_raw_hint else R.string.scale_sharpen_hint)
        scaleHint.visibility = if (Cfg.mode == Cfg.MODE_SHARP || Cfg.mode == Cfg.MODE_RAW) android.view.View.VISIBLE else android.view.View.GONE
        paintPresets()
    }
    paint()
    paintAa()

    aaChips.forEachIndexed { i, chip ->
        chip.setOnClickListener {
            onUserEdited()
            Cfg.aaMode = i
            Cfg.save(ctx)
            paintAa()
        }
    }

    aaBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            Cfg.aaStrength = p / 100f
            aaLabel.text = ctx.getString(R.string.aa_strength_fmt, p)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) = Cfg.save(ctx)
    })

    presetChips.forEachIndexed { i, chip ->
        chip.setOnClickListener {
            val presetVal = presetDefs[i].second
            onUserEdited()
            Cfg.renderPreset = presetVal
            if (presetVal != Cfg.PRESET_CUSTOM) {
                val pct = Cfg.pctForPreset(presetVal, nativeH)
                Cfg.scalePct = pct
                scaleBar.progress = (pct - Cfg.SCALE_MIN).coerceIn(0, scaleBar.max)
                scaleLabel.text = scaleText(pct)
            }
            paintPresets()
            Cfg.save(ctx)
            onApply()
        }
    }

    chips.forEachIndexed { i, chip ->
        chip.setOnClickListener {
            onUserEdited()
            Cfg.mode = modeOrder[i]
            Cfg.save(ctx)
            paint()
            onApply()
        }
    }

    denoiseBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            Cfg.denoise = p / 100f
            denoiseLabel.text = ctx.getString(R.string.denoise_fmt, p)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) = Cfg.save(ctx)
    })

    debandBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            Cfg.deband = p / 100f
            debandLabel.text = ctx.getString(R.string.deband_fmt, p)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) = Cfg.save(ctx)
    })

    detailBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            Cfg.detail = p / 100f
            detailLabel.text = ctx.getString(R.string.detail_fmt, p)
            detailSizeBar.alpha = if (p > 0) 1f else 0.4f
            detailSizeLabel.alpha = detailSizeBar.alpha
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) = Cfg.save(ctx)
    })

    detailSizeBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            Cfg.detailSize = p / 100f
            detailSizeLabel.text = ctx.getString(R.string.detail_size_fmt, p)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) = Cfg.save(ctx)
    })

    sharpBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            Cfg.sharp = p / 100f
            sharpLabel.text = ctx.getString(R.string.sharpness_fmt, p)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) = Cfg.save(ctx)
    })

    scaleBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            if (fromUser && Cfg.renderPreset != Cfg.PRESET_CUSTOM) {
                Cfg.renderPreset = Cfg.PRESET_CUSTOM
                paintPresets()
            }
            scaleLabel.text = scaleText(Cfg.SCALE_MIN + p)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) {
            Cfg.scalePct = Cfg.SCALE_MIN + s.progress
            Cfg.save(ctx)
            onApply()
        }
    })

    vividBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            Cfg.vivid = p / 100f
            vividLabel.text = ctx.getString(R.string.vivid_colors_fmt, p)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) = Cfg.save(ctx)
    })

    contrastBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            Cfg.contrast = (p - 50) / 50f
            contrastLabel.text = ctx.getString(R.string.contrast_fmt, p - 50)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) = Cfg.save(ctx)
    })

    bubbleSizeBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            bubbleSizeLabel.text = ctx.getString(R.string.bubble_size_fmt, Cfg.BUBBLE_MIN_DP + p)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) {
            Cfg.bubbleSizeDp = Cfg.BUBBLE_MIN_DP + s.progress
            Cfg.save(ctx)
            OverlayService.instance?.applyBubbleSize()
        }
    })

    boost.setOnCheckedChangeListener { _, checked ->
        if (boost.isPressed) onUserEdited()
        Cfg.boost = checked
        Cfg.save(ctx)
    }

    autoHide.setOnCheckedChangeListener { _, checked ->
        Cfg.bubbleSleep = checked
        Cfg.save(ctx)
        sleepBar.alpha = if (checked) 1f else 0.4f
        sleepLabel.alpha = sleepBar.alpha
        if (checked) OverlayService.instance?.refreshBubbleIdleTimer() else OverlayService.instance?.wakeBubble()
    }

    sleepBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            sleepLabel.text = ctx.getString(R.string.bubble_sleep_fmt, Cfg.BUBBLE_SLEEP_MIN_SEC + p)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) {
            Cfg.bubbleSleepSec = Cfg.BUBBLE_SLEEP_MIN_SEC + s.progress
            Cfg.save(ctx)
        }
    })

    // ---- reset to defaults
    val reset = Ui.text(ctx, ctx.getString(R.string.reset_defaults), 13f, Ui.ACCENT, true).apply {
        gravity = Gravity.CENTER
        setPadding(0, dp(ctx, 10), 0, 0)
    }
    col.addView(reset, gap(16))
    /** Pushes every Cfg value back into the views (used by Reset and by the quick profiles). */
    fun syncAll() {
        sharpBar.progress = (Cfg.sharp * 100).toInt()
        sharpLabel.text = ctx.getString(R.string.sharpness_fmt, sharpBar.progress)
        scaleBar.progress = (Cfg.scalePct - Cfg.SCALE_MIN).coerceIn(0, scaleBar.max)
        scaleLabel.text = scaleText(Cfg.scalePct)
        detailBar.progress = (Cfg.detail * 100).toInt()
        detailLabel.text = ctx.getString(R.string.detail_fmt, detailBar.progress)
        detailSizeBar.progress = (Cfg.detailSize * 100).toInt()
        detailSizeLabel.text = ctx.getString(R.string.detail_size_fmt, detailSizeBar.progress)
        detailSizeBar.alpha = if (Cfg.detail > 0f) 1f else 0.4f
        detailSizeLabel.alpha = detailSizeBar.alpha
        denoiseBar.progress = (Cfg.denoise * 100).toInt()
        denoiseLabel.text = ctx.getString(R.string.denoise_fmt, denoiseBar.progress)
        debandBar.progress = (Cfg.deband * 100).toInt()
        debandLabel.text = ctx.getString(R.string.deband_fmt, debandBar.progress)
        aaBar.progress = (Cfg.aaStrength * 100).toInt()
        aaLabel.text = ctx.getString(R.string.aa_strength_fmt, aaBar.progress)
        vividBar.progress = (Cfg.vivid * 100).toInt()
        vividLabel.text = ctx.getString(R.string.vivid_colors_fmt, vividBar.progress)
        contrastBar.progress = ((Cfg.contrast + 1f) * 50f).toInt().coerceIn(0, 100)
        contrastLabel.text = ctx.getString(R.string.contrast_fmt, contrastBar.progress - 50)
        boost.isChecked = Cfg.boost
        layerBar.progress = (Cfg.dim * 100).toInt().coerceIn(0, 100)
        layerLabel.text = ctx.getString(R.string.layer_alpha_fmt, layerBar.progress)
        bubbleSizeBar.progress = Cfg.bubbleSizeDp - Cfg.BUBBLE_MIN_DP
        bubbleSizeLabel.text = ctx.getString(R.string.bubble_size_fmt, Cfg.bubbleSizeDp)
        autoHide.isChecked = Cfg.bubbleSleep
        sleepBar.progress = Cfg.bubbleSleepSec - Cfg.BUBBLE_SLEEP_MIN_SEC
        sleepLabel.text = ctx.getString(R.string.bubble_sleep_fmt, Cfg.bubbleSleepSec)
        sleepBar.alpha = if (Cfg.bubbleSleep) 1f else 0.4f
        sleepLabel.alpha = sleepBar.alpha
        paint()
        paintAa()
        paintProfiles()
    }

    reset.setOnClickListener {
        Cfg.userProfile = null
        Cfg.profileType = -1
        Cfg.profileLevel = 1
        Cfg.profileBudget = Profiles.BALANCED
        Cfg.sharp = 0.7f
        Cfg.mode = Cfg.MODE_SHARP
        Cfg.scalePct = 100
        Cfg.renderPreset = Cfg.PRESET_CUSTOM
        Cfg.detail = 0f
        Cfg.detailSize = 0.4f
        Cfg.denoise = 0f
        Cfg.deband = 0f
        Cfg.aaMode = Cfg.AA_OFF
        Cfg.aaStrength = 0.75f
        Cfg.vivid = 0f
        Cfg.contrast = 0f
        Cfg.inRes = 0
        Cfg.outRes = 0
        Cfg.boost = false
        Cfg.layerAlpha = 1f
        Cfg.dim = 0f
        Cfg.bubbleSizeDp = Cfg.BUBBLE_DEFAULT_DP
        Cfg.bubbleSleep = true
        Cfg.bubbleSleepSec = Cfg.BUBBLE_SLEEP_DEFAULT_SEC
        Cfg.save(ctx)
        syncAll()
        refreshUser()
        OverlayService.instance?.applyLayerAlpha()
        OverlayService.instance?.applyBubbleSize()
        OverlayService.instance?.refreshBubbleIdleTimer()
        onApply()
    }

    // Profiles only touch the picture settings (never the bubble ones). The values come from the Profiles tables
    // (content type x strength, separate tables for the player and for the screen overlay). Still starting
    // points: fine-tune afterwards.
    var autoBackedUp = false // one backup per run of quick-profile taps (switching 3 profiles in a row keeps the ORIGINAL)
    fun applyProfile() {
        val type = Cfg.profileType
        if (type < 0) return
        // Hand-made settings are about to be replaced: keep a copy so they can be brought back with one tap.
        if (!autoBackedUp && Cfg.userProfile == null) UserProfiles.saveAuto(ctx)
        autoBackedUp = true
        Cfg.userProfile = null
        refreshUser()
        val ratio = if (inPlayer) sourceScale() else 1f
        // Auto (player only): the more the picture is enlarged, the more cleanup + detail it needs.
        val lvl = if (inPlayer && Cfg.profileLevel >= 3) Profiles.autoLevel(ratio) else Cfg.profileLevel.coerceIn(0, 2)
        val v = Profiles.withBudget(Profiles.get(type, lvl, inPlayer), Cfg.profileBudget)
        Cfg.mode = Profiles.upscaleMode(inPlayer, ratio, Cfg.profileBudget)
        Cfg.scalePct = 100
        Cfg.renderPreset = Cfg.PRESET_CUSTOM
        Cfg.boost = false
        Cfg.vivid = 0f
        Cfg.sharp = v.sharp
        Cfg.detail = v.detail
        Cfg.detailSize = v.detailSize
        Cfg.denoise = v.denoise
        Cfg.deband = v.deband
        Cfg.aaMode = v.aa
        Cfg.aaStrength = v.aaStr
        Cfg.save(ctx)
        syncAll()
        onApply()
    }
    profileChips.forEachIndexed { i, chip ->
        chip.setOnClickListener {
            autoOff()
            if (Cfg.profileType == -1) autoBackedUp = false
            Cfg.profileType = i
            applyProfile()
        }
    }
    budgetChips.forEachIndexed { i, chip ->
        chip.setOnClickListener {
            autoOff()
            Cfg.profileBudget = i
            if (Cfg.profileType >= 0) applyProfile() else {
                Cfg.save(ctx)
                paintProfiles()
            }
        }
    }
    levelChips.forEachIndexed { i, chip ->
        chip.setOnClickListener {
            autoOff()
            Cfg.profileLevel = i
            if (Cfg.profileType >= 0) applyProfile() else {
                Cfg.save(ctx)
                paintProfiles()
            }
        }
    }

    // ---- my profiles: Save / Load / Update / Delete (logic; the row was added at the top)
    val owner: Context = if (base is Activity) base else ctx
    fun dialog(b: AlertDialog.Builder) {
        val d = b.create()
        if (base !is Activity) d.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        d.show()
    }
    lateinit var rebuildUser: () -> Unit
    fun userLabel(n: String) = if (n == UserProfiles.AUTO) ctx.getString(R.string.uprof_auto) else n
    fun loadUser(n: String) {
        autoOff()
        if (UserProfiles.apply(ctx, n)) {
            syncAll()
            rebuildUser()
            OverlayService.instance?.applyLayerAlpha()
            onApply()
            Toast.makeText(ctx, ctx.getString(R.string.uprof_loaded_fmt, userLabel(n)), Toast.LENGTH_SHORT).show()
        }
    }
    fun saveUser(n: String) {
        val name = UserProfiles.clean(n)
        if (name.isEmpty()) return
        UserProfiles.save(ctx, name)
        Cfg.userProfile = name
        Cfg.save(ctx)
        rebuildUser()
        Toast.makeText(ctx, ctx.getString(R.string.uprof_saved_fmt, name), Toast.LENGTH_SHORT).show()
    }
    fun askSave(default: String) {
        val input = EditText(owner).apply {
            setSingleLine()
            setText(default)
            setSelection(text.length)
            hint = ctx.getString(R.string.uprof_name_hint)
        }
        val box = LinearLayout(owner).apply { setPadding(dp(ctx, 20), dp(ctx, 8), dp(ctx, 20), 0) }
        box.addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val b = AlertDialog.Builder(owner)
            .setTitle(ctx.getString(R.string.uprof_save_title))
            .setView(box)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val n = UserProfiles.clean(input.text.toString())
                if (n.isEmpty()) return@setPositiveButton
                if (UserProfiles.has(ctx, n) && !n.equals(Cfg.userProfile, true)) {
                    dialog(
                        AlertDialog.Builder(owner)
                            .setMessage(ctx.getString(R.string.uprof_overwrite_fmt, n))
                            .setPositiveButton(android.R.string.ok) { _, _ -> saveUser(n) }
                            .setNegativeButton(android.R.string.cancel, null)
                    )
                } else saveUser(n)
            }
            .setNegativeButton(android.R.string.cancel, null)
        dialog(b)
    }
    fun userMenu(n: String) {
        val items = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        if (n != UserProfiles.AUTO) {
            items.add(ctx.getString(R.string.uprof_update))
            acts.add { saveUser(n) }
        }
        items.add(ctx.getString(R.string.uprof_delete))
        acts.add {
            UserProfiles.delete(ctx, n)
            if (Cfg.userProfile.equals(n, true)) {
                Cfg.userProfile = null
                Cfg.save(ctx)
            }
            rebuildUser()
        }
        dialog(
            AlertDialog.Builder(owner)
                .setTitle(userLabel(n))
                .setItems(items.toTypedArray()) { _, which -> acts[which]() }
                .setNegativeButton(android.R.string.cancel, null)
        )
    }
    rebuildUser = {
        userRow.removeAllViews()
        val radius = dp(ctx, 10).toFloat()
        fun chip(text: String, selected: Boolean, accentOutline: Boolean): TextView = TextView(ctx).apply {
            this.text = text
            textSize = 13f
            gravity = Gravity.CENTER
            minWidth = dp(ctx, 56)
            maxLines = 1
            setPadding(dp(ctx, 14), dp(ctx, 8), dp(ctx, 14), dp(ctx, 8))
            if (selected) {
                background = Ui.gradient(radius)
                setTextColor(Ui.BG)
                setTypeface(null, Typeface.BOLD)
            } else if (accentOutline) {
                background = Ui.round(Ui.CHIP, radius, Ui.OK, dp(ctx, 1))
                setTextColor(Ui.OK)
            } else {
                background = Ui.round(Ui.CHIP, radius)
                setTextColor(Ui.TEXT)
            }
        }
        fun add(v: View) = userRow.addView(
            v,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(ctx, 6) }
        )
        val saveChip = chip("＋  " + ctx.getString(R.string.uprof_save), false, true)
        saveChip.setOnClickListener {
            askSave(Cfg.userProfile?.takeIf { it != UserProfiles.AUTO }
                ?: ctx.getString(R.string.uprof_default_fmt, UserProfiles.names(ctx).count { it != UserProfiles.AUTO } + 1))
        }
        add(saveChip)
        for (n in UserProfiles.names(ctx)) {
            val c = chip(userLabel(n), Cfg.userProfile.equals(n, true), false)
            c.setOnClickListener { loadUser(n) }
            c.setOnLongClickListener { userMenu(n); true }
            add(c)
        }
    }
    onUserEdited = {
        autoOff()
        if (Cfg.userProfile != null) {
            Cfg.userProfile = null
            Cfg.save(ctx)
            rebuildUser()
        }
    }
    refreshUser = { rebuildUser() }
    rebuildUser()

    // ---- Auto (logic)
    fun runAuto() {
        val ratio = if (inPlayer) sourceScale() else 1f
        val why: String
        if (inPlayer) {
            val pick = autoPick?.invoke()
            if (pick == null) {
                // nothing is open yet: the next video / photo applies Auto when it opens
                autoWhy.text = ctx.getString(R.string.auto_waiting)
                autoWhy.visibility = View.VISIBLE
                return
            }
            Profiles.applyPick(pick.type, pick.level, pick.budget, true, ratio)
            why = ctx.getString(R.string.auto_picked_fmt, ctx.getString(profileNamesRes[pick.type]), ctx.getString(budgetNamesRes[pick.budget]))
        } else {
            Auto.applyOverlayStep(2)
            OverlayService.instance?.autoReset()
            why = ctx.getString(R.string.auto_picked_overlay)
        }
        Cfg.save(ctx)
        syncAll()
        refreshUser()
        autoWhy.text = why
        autoWhy.visibility = View.VISIBLE
        onApply()
    }
    autoSwitch.setOnCheckedChangeListener { _, on ->
        if (autoSilent) return@setOnCheckedChangeListener
        Cfg.autoMode = on
        Cfg.save(ctx)
        if (on) runAuto() else autoWhy.visibility = View.GONE
    }
    ControlsBus.sync = {
        syncAll()
        refreshUser()
        autoSilent = true
        autoSwitch.isChecked = Cfg.autoMode
        autoSilent = false
        if (!Cfg.autoMode) autoWhy.visibility = View.GONE
    }

    return col
}
