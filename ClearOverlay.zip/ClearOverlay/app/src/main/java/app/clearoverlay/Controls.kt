package app.clearoverlay

import android.app.Activity
import kotlin.math.roundToInt
import android.app.AlertDialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Toast
import android.widget.Switch
import android.widget.TextView

fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

/** Colors and small view factories shared by the app screen and the floating panel. */
object Ui {
    var BG = Color.parseColor("#0B1020")
    var CARD = Color.parseColor("#151B2E")
    var CHIP = Color.parseColor("#1F2940")
    var STROKE = Color.parseColor("#26324D")
    var ACCENT = Color.parseColor("#22D3EE")
    var ACCENT2 = Color.parseColor("#A78BFA")
    var TEXT = Color.parseColor("#F1F5F9")
    var MUTED = Color.parseColor("#94A3B8")
    var DANGER = Color.parseColor("#F87171")
    var OK = Color.parseColor("#4ADE80")

    /** True when the light palette is active; [classic] = flat square-ish look instead of rounded + gradient. */
    var light = false
    var classic = false

    /**
     * Picks the palette from the saved theme settings ([Cfg.themeMode] / [Cfg.themeStyle]; call Cfg.load first).
     * [forceDark] is used by the video / photo / manga screens, which sit on black: they always use the dark colours.
     */
    // The colours are global, but several screens are alive at the same time (the player on black, the main screen, the floating panel of the
    // screen layer, a service). Whichever of them started last used to decide the colours of everything built afterwards, so buttons came out
    // white on white or black on black. Now the screen that is on top owns the palette: it is set again every time a screen comes back, and a
    // service / background caller can no longer change it while a screen is showing.
    private var hooked = false
    private var topScreen: android.app.Activity? = null
    private val DARK_SCREENS = setOf("PlayerActivity", "MangaActivity", "GifActivity")

    private fun hook(c: Context) {
        if (hooked) return
        val app = c.applicationContext as? android.app.Application ?: return
        hooked = true
        app.registerActivityLifecycleCallbacks(object : android.app.Application.ActivityLifecycleCallbacks {
            override fun onActivityPreResumed(a: android.app.Activity) {
                topScreen = a
                if (a.javaClass.name.startsWith("app.clearoverlay.")) init(a, a.javaClass.simpleName in DARK_SCREENS)
            }
            override fun onActivityPaused(a: android.app.Activity) { if (topScreen === a) topScreen = null }
            override fun onActivityDestroyed(a: android.app.Activity) { if (topScreen === a) topScreen = null }
            override fun onActivityCreated(a: android.app.Activity, b: android.os.Bundle?) {}
            override fun onActivityStarted(a: android.app.Activity) {}
            override fun onActivityResumed(a: android.app.Activity) {}
            override fun onActivityStopped(a: android.app.Activity) {}
            override fun onActivitySaveInstanceState(a: android.app.Activity, b: android.os.Bundle) {}
        })
    }

    // The palette is one global, but screens are not all in the same theme (player / manga / gif are always dark). Every screen
    // re-applies its own palette when it comes to the front and is rebuilt if the colours it was built with are not the ones
    // now in force, so buttons can no longer end up black/white after coming back from another screen.
    private val built = java.util.WeakHashMap<android.app.Activity, String>()
    private var watching = false
    private fun darkScreen(a: android.app.Activity) = a is PlayerActivity || a is MangaActivity || a is GifActivity
    private fun sig() = "$BG/$CARD/$ACCENT/$TEXT"
    /** Screens where a rebuild would throw away what the person is doing (editors, exports, batch jobs): they keep their colours until they are opened again. */
    private fun hasUnsavedWork(a: android.app.Activity): Boolean {
        val n = a.javaClass.simpleName
        return n.contains("Edit") || n.contains("Export") || n.contains("Shrink") || n.contains("Batch") || n.contains("Clean") || n.contains("Files") || n.contains("Net") || n.contains("Trash")
    }

    private fun watch(c: Context) {
        if (watching) return
        val app = c.applicationContext as? android.app.Application ?: return
        watching = true
        app.registerActivityLifecycleCallbacks(object : android.app.Application.ActivityLifecycleCallbacks {
            override fun onActivityStarted(a: android.app.Activity) {
                if (a.javaClass.name.startsWith("app.clearoverlay") && built[a] == null) built[a] = sig()
            }
            override fun onActivityResumed(a: android.app.Activity) {
                if (!a.javaClass.name.startsWith("app.clearoverlay")) return
                init(a, darkScreen(a))
                val was = built[a]
                if (was == null) built[a] = sig()
                else if (was != sig() && !darkScreen(a) && !a.isFinishing && !hasUnsavedWork(a)) {
                    built.remove(a)
                    a.recreate()
                }
            }
            override fun onActivityCreated(a: android.app.Activity, b: android.os.Bundle?) {}
            override fun onActivityPaused(a: android.app.Activity) {}
            override fun onActivityStopped(a: android.app.Activity) {}
            override fun onActivitySaveInstanceState(a: android.app.Activity, b: android.os.Bundle) {}
            override fun onActivityDestroyed(a: android.app.Activity) { built.remove(a) }
        })
    }

    fun init(c: Context, forceDark: Boolean = false) {
        watch(c)
        hook(c)
        // a service (or any non-screen caller) must not recolour the screen that is showing
        if (c !is android.app.Activity && topScreen != null) return
        val night = (c.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
        light = !forceDark && when (Cfg.themeMode) { 1 -> false; 2 -> true; else -> !night }
        classic = Cfg.themeStyle == 1
        when {
            !classic && !light -> pal("#0B1020", "#151B2E", "#1F2940", "#26324D", "#22D3EE", "#A78BFA", "#F1F5F9", "#94A3B8", "#F87171", "#4ADE80")
            !classic && light -> pal("#F3F5FA", "#FFFFFF", "#E7EBF4", "#D3D9E8", "#0891B2", "#7C3AED", "#0F172A", "#586178", "#DC2626", "#15803D")
            classic && !light -> pal("#111111", "#1C1C1C", "#2B2B2B", "#434343", "#33B5E5", "#0099CC", "#EDEDED", "#A3A3A3", "#FF4444", "#99CC00")
            else -> pal("#ECECEC", "#FFFFFF", "#DEDEDE", "#BDBDBD", "#0288D1", "#01579B", "#212121", "#616161", "#C62828", "#2E7D32")
        }
        if (Cfg.themeAccent in 1..7) {
            val a = ACCENTS[Cfg.themeAccent]
            ACCENT = Color.parseColor(if (light) a[2] else a[0])
            ACCENT2 = Color.parseColor(if (light) a[3] else a[1])
        }
    }

    /** Accent choices: dark accent, dark second colour, light accent, light second colour. Index 0 is the default (not listed here). */
    val ACCENTS = arrayOf(
        arrayOf("#22D3EE", "#A78BFA", "#0891B2", "#7C3AED"),
        arrayOf("#60A5FA", "#818CF8", "#2563EB", "#4F46E5"),
        arrayOf("#4ADE80", "#2DD4BF", "#16A34A", "#0D9488"),
        arrayOf("#FB923C", "#FBBF24", "#EA580C", "#D97706"),
        arrayOf("#F472B6", "#C084FC", "#DB2777", "#9333EA"),
        arrayOf("#F87171", "#FB923C", "#DC2626", "#EA580C"),
        arrayOf("#A78BFA", "#F472B6", "#7C3AED", "#DB2777"),
        arrayOf("#FACC15", "#FB923C", "#CA8A04", "#EA580C")
    )

    private fun pal(bg: String, card: String, chip: String, stroke: String, a1: String, a2: String, text: String, muted: String, danger: String, ok: String) {
        BG = Color.parseColor(bg); CARD = Color.parseColor(card); CHIP = Color.parseColor(chip); STROKE = Color.parseColor(stroke)
        ACCENT = Color.parseColor(a1); ACCENT2 = Color.parseColor(a2); TEXT = Color.parseColor(text); MUTED = Color.parseColor(muted)
        DANGER = Color.parseColor(danger); OK = Color.parseColor(ok)
    }

    fun theme(): Int =
        if (light) android.R.style.Theme_DeviceDefault_Light_NoActionBar else android.R.style.Theme_DeviceDefault_NoActionBar

    /** Status / navigation bar colour and icon colour for the current palette. */
    fun styleBars(w: android.view.Window) {
        w.statusBarColor = BG
        w.navigationBarColor = BG
        runCatching {
            val m = android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            w.insetsController?.setSystemBarsAppearance(if (light) m else 0, m)
        }
    }

    fun themed(c: Context): Context =
        ContextThemeWrapper(c, if (light) android.R.style.Theme_DeviceDefault_Light else android.R.style.Theme_DeviceDefault)

    private fun rad(r: Float) = if (classic) r * 0.45f else r

    fun round(color: Int, radius: Float, strokeColor: Int = 0, strokeW: Int = 0) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = rad(radius)
        if (strokeW > 0) setStroke(strokeW, strokeColor)
    }

    fun gradient(radius: Float) =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, if (classic) intArrayOf(ACCENT, ACCENT) else intArrayOf(ACCENT, ACCENT2)).apply {
            cornerRadius = rad(radius)
        }

    /** One font family for the whole app: clean sans (Latin) with the system's Persian fallback; bold = medium weight. */
    val FONT: Typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    val FONT_BOLD: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)

    fun text(c: Context, s: String, sp: Float, color: Int = TEXT, bold: Boolean = false) = TextView(c).apply {
        // Look level (Settings > Appearance): 0 full; 1 light = explanations cut to their first sentence; 2 minimal = explanations removed
        val hint = color == MUTED && !bold && s.length > 28
        var t = s
        if (hint && Cfg.uiMode == 1) {
            val cut = t.indexOfFirst { it == '.' || it == '。' || it == '؟' || it == '\n' }
            t = if (cut in 12..110) t.substring(0, cut + 1) else if (t.length > 90) t.take(88).trimEnd() + "…" else t
        }
        text = t
        textSize = sp
        setTextColor(color)
        typeface = if (bold) FONT_BOLD else FONT
        if (hint && Cfg.uiMode == 2) visibility = View.GONE
    }
}

/**
 * "Panel size" chips (small / medium / large), shared by every settings panel (player, manga reader, ...).
 * [onChange] is called after [Cfg.panelSize] changed and was saved.
 */
fun panelSizeRow(ctx: Context, onChange: () -> Unit): LinearLayout {
    val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    col.addView(Ui.text(ctx, ctx.getString(R.string.panel_size_label), 12f, Ui.MUTED))
    val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
    val chips = ArrayList<TextView>()
    fun paint() {
        val r = dp(ctx, 10).toFloat()
        chips.forEachIndexed { i, c ->
            if (i == Cfg.panelSize) {
                c.background = Ui.gradient(r)
                c.setTextColor(Ui.BG)
            } else {
                c.background = Ui.round(Ui.CHIP, r)
                c.setTextColor(Ui.MUTED)
            }
        }
    }
    listOf(R.string.panel_size_small, R.string.panel_size_medium, R.string.panel_size_large).forEachIndexed { i, r ->
        val c = TextView(ctx).apply {
            text = ctx.getString(r)
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(dp(ctx, 6), dp(ctx, 7), dp(ctx, 6), dp(ctx, 7))
            setOnClickListener {
                Cfg.panelSize = i
                Cfg.save(ctx)
                paint()
                onChange()
            }
        }
        chips.add(c)
        row.addView(c, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i > 0) marginStart = dp(ctx, 6) })
    }
    paint()
    col.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(ctx, 4) })
    return col
}

/** A thin divider + accent title that groups the options of one kind (playback, effect, panel ...) in a settings panel. */
fun panelSection(ctx: Context, title: String): LinearLayout {
    val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    col.addView(View(ctx).apply { setBackgroundColor(Ui.STROKE) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 1)))
    col.addView(
        Ui.text(ctx, title, 13f, Ui.ACCENT, true),
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(ctx, 8) }
    )
    return col
}

/**
 * Title row of a floating settings panel: title, lock (🔒 / 🔓: unlocked = drag the panel by this row) and close.
 * [target] is the panel that moves, [clamp] keeps it inside the window, [say] shows a short message.
 */
fun panelHeader(ctx: Context, title: String, target: View, clamp: () -> Unit, onClose: () -> Unit, say: (String) -> Unit): LinearLayout {
    val head = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL }
    head.addView(Ui.text(ctx, title, 18f, Ui.TEXT, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
    val lock = Icons.button(ctx, Icons.LOCK, if (Cfg.panelLocked) Ui.ACCENT else Ui.MUTED, 34) {}
    lock.setOnClickListener {
        Cfg.panelLocked = !Cfg.panelLocked
        Cfg.save(ctx)
        lock.setImageDrawable(LineIcon(Icons.LOCK, if (Cfg.panelLocked) Ui.ACCENT else Ui.MUTED))
        say(ctx.getString(if (Cfg.panelLocked) R.string.panel_locked else R.string.panel_unlocked))
    }
    head.addView(lock)
    var dx0 = 0f
    var dy0 = 0f
    var tx0 = 0f
    var ty0 = 0f
    head.setOnTouchListener { v, ev ->
        if (Cfg.panelLocked) return@setOnTouchListener false
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dx0 = ev.rawX; dy0 = ev.rawY
                tx0 = target.translationX; ty0 = target.translationY
                v.parent?.requestDisallowInterceptTouchEvent(true)
                true
            }
            MotionEvent.ACTION_MOVE -> {
                target.translationX = tx0 + (ev.rawX - dx0)
                target.translationY = ty0 + (ev.rawY - dy0)
                clamp()
                true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> true
            else -> false
        }
    }
    head.addView(Icons.button(ctx, Icons.CLOSE, Ui.ACCENT, 34) { onClose() })
    return head
}

/** A labelled on/off switch in the panel's style. */
fun panelSwitch(ctx: Context, label: String, checked: Boolean, onChange: (Boolean) -> Unit) = Switch(ctx).apply {
    text = label
    setTextColor(Ui.TEXT)
    isChecked = checked
    setOnCheckedChangeListener { _, c -> onChange(c) }
}

/** Lets code outside the panel (Auto, the player) tell the currently built settings panel to refresh its views. */
object ControlsBus {
    @Volatile var sync: (() -> Unit)? = null
    /** What Auto chose and why (set by the player); shown under the Auto switch while Auto is on. */
    @Volatile var autoNote: String? = null
    /** Rows that mean something only for a photo (the player shows them for a photo and hides them for a video). */
    val photoOnly = ArrayList<View>()
    /** True while the player has a photo open (set by the player); new photo-only rows start with this visibility. */
    @Volatile var mediaIsPhoto = false
}

/**
 * Horizontal swipe row: no scrollbar, soft fading edges so it is clear there is more to swipe to.
 * [row] holds the chips; [scrollToChip] centers a given chip (used to reveal the selected one).
 */
class ChipScroller(ctx: Context, val row: LinearLayout) : HorizontalScrollView(ctx) {
    init {
        isHorizontalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        isHorizontalFadingEdgeEnabled = true
        setFadingEdgeLength(dp(ctx, 28))
        isFillViewport = true
        clipToPadding = false
        addView(row, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT))
    }

    /**
     * Every chip keeps the size its own text needs (long labels do not make some chips bigger than the others by weight);
     * when all of them fit on the screen they share the width equally, otherwise the row swipes sideways.
     */
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val avail = MeasureSpec.getSize(widthMeasureSpec) - paddingLeft - paddingRight
        val n = row.childCount
        if (n > 0 && avail > 0) {
            var natural = 0
            var maxW = 0
            var margins = 0
            for (i in 0 until n) {
                val c = row.getChildAt(i)
                val lp = c.layoutParams as LinearLayout.LayoutParams
                lp.weight = 0f
                lp.width = ViewGroup.LayoutParams.WRAP_CONTENT
                c.measure(MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED), MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED))
                natural += c.measuredWidth
                maxW = maxOf(maxW, c.measuredWidth)
                margins += lp.marginStart + lp.marginEnd
            }
            if (natural + margins <= avail) {
                // fits: equal widths if the widest still fits that way, else natural widths spread nothing
                val each = (avail - margins) / n
                if (each >= maxW) for (i in 0 until n) (row.getChildAt(i).layoutParams as LinearLayout.LayoutParams).width = each
            }
        }
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
    }

    fun scrollToChip(chip: View, animate: Boolean = false) {
        post {
            val x = (chip.left - (width - chip.width) / 2).coerceAtLeast(0)
            if (animate) smoothScrollTo(x, 0) else scrollTo(x, 0)
        }
    }
}

/**
 * Mode chips, sharpness, detail/deblur, anti-aliasing, render resolution, vivid colors, boost, bubble size and bubble auto-hide.
 * Used by the main screen and by the bubble's panel, so both always look and behave the same.
 * [onApply] is called when something needs the capture size to be re-applied (mode / render scale).
 * [onAdjust] gets true when a finger goes down on any slider and false when it lifts (used to fade the panel).
 * [inPlayer] = built for the video / photo player (profiles then use FSR 1 upscaling); [sourceScale] gives the current
 * output-size / source-size ratio there, which the "Auto" strength uses.
 * All labels come from res/values(-fa)/strings.xml, so the panel follows the device's language.
 */
fun buildControls(
    base: Context,
    onAdjust: (Boolean) -> Unit = {},
    inPlayer: Boolean = false,
    sourceScale: () -> Float = { 1f },
    autoPick: (() -> Auto.Pick?)? = null,
    optFrame: (() -> android.graphics.Bitmap?)? = null,
    onApply: () -> Unit
): LinearLayout {
    val ctx = Ui.themed(Lang.wrap(base))
    val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    val profileNamesRes = intArrayOf(
        R.string.profile_video, R.string.profile_stream, R.string.profile_game,
        R.string.profile_photo, R.string.profile_movie, R.string.profile_anime, R.string.profile_text, R.string.profile_manga, R.string.profile_repair,
        R.string.profile_dark, R.string.profile_busy, R.string.profile_gamehq
    )
    val budgetNamesRes = intArrayOf(R.string.budget_perf, R.string.budget_balanced, R.string.budget_quality)

    fun gap(v: Int) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(ctx, v) }

    // ---- Auto: the app picks profile, strength, budget, AA, mode and AI model itself
    val autoSwitch = Switch(ctx).apply {
        text = ctx.getString(R.string.auto_switch)
        setTextColor(Ui.TEXT)
        textSize = 15f
        isChecked = Cfg.autoMode
    }
    var autoSilent = false
    fun autoOff() {
        if (!Cfg.autoMode) return
        Cfg.autoMode = false
        Cfg.save(ctx)
        autoSilent = true
        autoSwitch.isChecked = false
        autoSilent = false
    }
    // ---- how heavy the picture settings are (an estimate; refreshed while the panel is on screen)
    val loadBar = android.widget.ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
    val loadText = Ui.text(ctx, "", 13f, Ui.TEXT, true)
    val loadSub = Ui.text(ctx, "", 11f, Ui.MUTED)
    val loadBox = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(ctx, 12), dp(ctx, 10), dp(ctx, 12), dp(ctx, 10))
        background = Ui.round(Ui.CHIP, dp(ctx, 12).toFloat())
        addView(loadText)
        addView(loadBar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 8)).apply { topMargin = dp(ctx, 6) })
        addView(loadSub, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(ctx, 4) })
    }
    fun loadNames() = intArrayOf(R.string.fxc_l0, R.string.fxc_l1, R.string.fxc_l2, R.string.fxc_l3)
    var lastCost: FxCost.Result? = null
    fun refreshLoad() {
        val r = FxCost.estimate(ctx, Cfg.section == "video") // (a photo in the player has no frame generation / temporal clean-up)
        lastCost = r
        val k = FxCost.msPerUnit(ctx) // > 0 once "Measure speed" has been run on this phone: the load is then in milliseconds
        val est = r.total * k
        val lv = if (k > 0f) FxCost.levelMs(est) else FxCost.level(r.total)
        val colors = intArrayOf(0xFF34D399.toInt(), 0xFFFACC15.toInt(), 0xFFFB923C.toInt(), 0xFFF87171.toInt())
        loadText.text = ctx.getString(R.string.fxc_title) + ": " + ctx.getString(loadNames()[lv]) +
            (if (k > 0f) String.format(java.util.Locale.US, "  (≈ %.1f ms)", est) else String.format(java.util.Locale.US, "  (%.1f×)", r.total))
        loadText.setTextColor(colors[lv])
        loadBar.progress = (if (k > 0f) est / 40f * 100f else r.total / 8f * 100f).toInt().coerceIn(2, 100)
        loadBar.progressTintList = android.content.res.ColorStateList.valueOf(colors[lv])
        val ms = if (android.os.SystemClock.elapsedRealtime() - Cfg.drawMsAt < 3000L) Cfg.drawMs else 0f // an old number (nothing is being drawn now) is not shown
        loadSub.text = (if (k > 0f) ctx.getString(R.string.fxc_cal_fmt, est, (1000f / est.coerceAtLeast(0.5f)).toInt().coerceAtMost(240)) + (if (!FxCost.hasOwn(ctx)) "\n" + ctx.getString(R.string.fxc_unmeasured) else "") else ctx.getString(R.string.fxc_hint) + "\n" + ctx.getString(R.string.fxc_nocal)) +
            (if (ms > 0f) "\n" + ctx.getString(R.string.fxc_measured_fmt, ms) else "")
    }
    loadBox.setOnClickListener {
        val r = lastCost ?: return@setOnClickListener
        val sb = StringBuilder()
        val kk = FxCost.msPerUnit(ctx)
        for (p in r.parts.take(10)) {
            if (kk > 0f) sb.append(String.format(java.util.Locale.US, "%.1f ms   ", p.cost * kk))
            else sb.append(String.format(java.util.Locale.US, "%.1f×   ", p.cost))
            sb.append(ctx.getString(p.label)).append('\n')
        }
        // the panel can live in the floating window of the screen layer (no activity): that dialog needs the overlay window type
        val d = android.app.AlertDialog.Builder(base).setTitle(R.string.fxc_title).setMessage(sb.toString().trim() + "\n\n" + ctx.getString(R.string.fxc_explain)).setPositiveButton(android.R.string.ok, null).create()
        if (base !is Activity) d.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        d.show()
    }
    // refresh now and then while the panel is on screen (the settings change from many places)
    val loadTick = object : Runnable {
        override fun run() {
            if (!loadBox.isAttachedToWindow) return
            refreshLoad()
            loadBox.postDelayed(this, 700)
        }
    }
    loadBox.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
        override fun onViewAttachedToWindow(v: View) { loadBox.removeCallbacks(loadTick); loadBox.post(loadTick) }
        override fun onViewDetachedFromWindow(v: View) { loadBox.removeCallbacks(loadTick) }
    })
    refreshLoad()
    col.addView(loadBox)
    col.addView(autoSwitch, gap(10))
    col.addView(Ui.text(ctx, ctx.getString(R.string.auto_hint), 12f, Ui.MUTED), gap(2))
    val autoWhy = Ui.text(ctx, "", 12f, Ui.ACCENT2)
    autoWhy.visibility = View.GONE
    col.addView(autoWhy, gap(2))
    if (inPlayer) {
        // the photo viewer starts an AI upscale by itself for a small photo while Auto is on: it can be switched off here.
        // It means nothing for a video, so it is shown only while a photo is open (the player hides it for a video).
        ControlsBus.photoOnly.clear()
        val aiSw = Switch(ctx).apply {
            text = ctx.getString(R.string.auto_ai_small)
            setTextColor(Ui.TEXT)
            textSize = 14f
            isChecked = Cfg.autoAiSmall
            setOnCheckedChangeListener { _, on ->
                Cfg.autoAiSmall = on
                if (on) AiSkip.reset(ctx)
                Cfg.save(ctx)
            }
        }
        val aiHint = Ui.text(ctx, ctx.getString(R.string.auto_ai_small_hint), 12f, Ui.MUTED)
        col.addView(aiSw, gap(10))
        col.addView(aiHint, gap(2))
        for (v in listOf<View>(aiSw, aiHint)) {
            v.visibility = if (ControlsBus.mediaIsPhoto) View.VISIBLE else View.GONE
            ControlsBus.photoOnly.add(v)
        }
    }

    // ---- my profiles (saved by the user; filled in at the end of this function, after syncAll exists)
    var onUserEdited: () -> Unit = {}
    var refreshUser: () -> Unit = {}
    col.addView(Ui.text(ctx, ctx.getString(R.string.uprof_label), 12f, Ui.MUTED), gap(14))
    val userRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
    col.addView(ChipScroller(ctx, userRow), gap(6))
    col.addView(Ui.text(ctx, ctx.getString(R.string.uprof_hint), 12f, Ui.MUTED), gap(4))

    // ---- quick profiles (momentary: apply a set of values, everything below updates)
    col.addView(Ui.text(ctx, ctx.getString(R.string.profiles_label), 12f, Ui.MUTED), gap(14))
    val profileNames = listOf(
        ctx.getString(R.string.profile_video),
        ctx.getString(R.string.profile_stream),
        ctx.getString(R.string.profile_game),
        ctx.getString(R.string.profile_photo),
        ctx.getString(R.string.profile_movie),
        ctx.getString(R.string.profile_anime),
        ctx.getString(R.string.profile_text),
        ctx.getString(R.string.profile_manga),
        ctx.getString(R.string.profile_repair),
        ctx.getString(R.string.profile_dark),
        ctx.getString(R.string.profile_busy),
        ctx.getString(R.string.profile_gamehq)
    )
    val profileDescs = listOf(
        R.string.profile_desc_video, R.string.profile_desc_stream, R.string.profile_desc_game,
        R.string.profile_desc_photo, R.string.profile_desc_movie, R.string.profile_desc_anime, R.string.profile_desc_text, R.string.profile_desc_manga, R.string.profile_desc_repair,
        R.string.profile_desc_dark, R.string.profile_desc_busy, R.string.profile_desc_gamehq
    )
    val profileChips = profileNames.map { n ->
        TextView(ctx).apply {
            text = n
            textSize = 13f
            gravity = Gravity.CENTER
            minWidth = dp(ctx, 56)
            maxLines = 1
            setPadding(dp(ctx, 14), dp(ctx, 8), dp(ctx, 14), dp(ctx, 8))
            background = Ui.round(Ui.CHIP, dp(ctx, 10).toFloat(), Ui.ACCENT, dp(ctx, 1))
            setTextColor(Ui.ACCENT)
        }
    }
    // a tidy grid of cards (3 per row, equal width) instead of a long scrolling row: everything is visible at once
    val profileGrid = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    profileChips.chunked(3).forEachIndexed { r, rowChips ->
        val rowL = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        for (k in 0 until 3) {
            val chip = rowChips.getOrNull(k)
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (k != 2) marginEnd = dp(ctx, 6)
            }
            if (chip != null) {
                chip.setPadding(dp(ctx, 6), dp(ctx, 11), dp(ctx, 6), dp(ctx, 11))
                chip.minWidth = 0
                chip.ellipsize = android.text.TextUtils.TruncateAt.END
                rowL.addView(chip, lp)
            } else {
                rowL.addView(View(ctx), lp) // keeps the last row's cards the same width
            }
        }
        profileGrid.addView(rowL, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            if (r > 0) topMargin = dp(ctx, 6)
        })
    }
    col.addView(profileGrid, gap(8))

    // ---- profile strength (like DLSS Quality / Balanced / Performance)
    col.addView(Ui.text(ctx, ctx.getString(R.string.profile_level_label), 12f, Ui.MUTED), gap(10))
    val levelRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
    val levelNames = ArrayList<String>().apply {
        add(ctx.getString(R.string.level_light))
        add(ctx.getString(R.string.level_balanced))
        add(ctx.getString(R.string.level_strong))
        if (inPlayer) add(ctx.getString(R.string.level_auto))
    }
    val levelChips = levelNames.map { n ->
        TextView(ctx).apply {
            text = n
            textSize = 13f
            gravity = Gravity.CENTER
            minWidth = dp(ctx, 56)
            maxLines = 1
            setPadding(dp(ctx, 14), dp(ctx, 8), dp(ctx, 14), dp(ctx, 8))
        }
    }
    levelChips.forEachIndexed { i, chip ->
        chip.minWidth = 0
        levelRow.addView(
            chip,
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (i != levelChips.lastIndex) marginEnd = dp(ctx, 6)
            }
        )
    }
    col.addView(levelRow, gap(6))

    // ---- GPU budget (like DLSS Performance / Balanced / Quality): how much work per frame
    col.addView(Ui.text(ctx, ctx.getString(R.string.profile_budget_label), 12f, Ui.MUTED), gap(10))
    val budgetRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
    val budgetChips = listOf(R.string.budget_perf, R.string.budget_balanced, R.string.budget_quality, R.string.budget_auto).map { r ->
        TextView(ctx).apply {
            text = ctx.getString(r)
            textSize = 12.5f
            gravity = Gravity.CENTER
            minWidth = dp(ctx, 56)
            maxLines = 1
            setPadding(dp(ctx, 14), dp(ctx, 8), dp(ctx, 14), dp(ctx, 8))
        }
    }
    budgetChips.forEachIndexed { i, chip ->
        chip.minWidth = 0
        budgetRow.addView(
            chip,
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (i != budgetChips.lastIndex) marginEnd = dp(ctx, 6)
            }
        )
    }
    col.addView(budgetRow, gap(6))
    // what the chosen budget does (and, on Auto, what it picked right now)
    val budgetNote = Ui.text(ctx, "", 12f, Ui.ACCENT2)
    col.addView(budgetNote, gap(4))
    col.addView(Ui.text(ctx, ctx.getString(R.string.profile_hint), 12f, Ui.MUTED), gap(4))
    val profileDesc = Ui.text(ctx, "", 12f, Ui.ACCENT2)
    col.addView(profileDesc, gap(4))

    /** Selected profile + strength are highlighted; touching any slider clears the profile (values are then custom). */
    fun paintProfiles() {
        val radius = dp(ctx, 10).toFloat()
        val di = Cfg.profileType
        if (di in profileDescs.indices) {
            // what the profile really set (read back from the live settings, so it is right for every strength / budget / Auto)
            val upName = ctx.getString(when (Cfg.mode) {
                Cfg.MODE_FSR -> R.string.mode_fsr
                Cfg.MODE_SGSR -> R.string.mode_sgsr
                Cfg.MODE_FAST -> R.string.mode_fast
                Cfg.MODE_RAW -> R.string.mode_raw
                Cfg.MODE_LANCZOS -> R.string.mode_lanczos
                Cfg.MODE_CLEAR -> R.string.mode_clear
                Cfg.MODE_ART -> R.string.mode_art
                Cfg.MODE_PIXEL -> R.string.mode_pixel
                Cfg.MODE_NIS -> R.string.mode_nis
                Cfg.MODE_NIS_SOFT -> R.string.mode_nis_soft
                Cfg.MODE_NIS_ORIG -> R.string.mode_nis_orig
                Cfg.MODE_NIS_FAST -> R.string.mode_nis_fast
                Cfg.MODE_NIS_FINE -> R.string.mode_nis_fine
                Cfg.MODE_NIS_MID -> R.string.mode_nis_mid
                else -> R.string.mode_sharpen
            })
            val aaName = ctx.getString(when (Cfg.aaMode) {
                Cfg.AA_FXAA_FAST -> R.string.aa_fxaa_fast
                Cfg.AA_FXAA_QUALITY -> R.string.aa_fxaa_quality
                Cfg.AA_EDGE -> R.string.aa_edge
                Cfg.AA_SMART -> R.string.aa_smart
                else -> R.string.aa_off
            })
            fun pc(v: Float) = Math.round(v * 100f)
            // the other sections strength and budget set (read back from the live settings)
            val also = ArrayList<String>()
            if (Cfg.mode == Cfg.MODE_LANCZOS) also.add(ctx.getString(R.string.rel_crsc_fmt, Cfg.crscLevel))
            if (Cfg.cleanUp) also.add(ctx.getString(R.string.rel_clean_fmt, pc(Cfg.cleanLevel)))
            if (inPlayer && Cfg.playerTemporal > 0) also.add(ctx.getString(R.string.rel_temporal))
            if (Cfg.clarity > 0.004f) also.add(ctx.getString(R.string.rel_clarity_fmt, pc(Cfg.clarity)))
            if (Cfg.gameLight > 0.004f) also.add(ctx.getString(R.string.rel_gamelight_fmt, pc(Cfg.gameLight)))
            if (Cfg.antiRing > 0.004f) also.add(ctx.getString(R.string.rel_antiring_fmt, pc(Cfg.antiRing)))
            profileDesc.text = ctx.getString(profileDescs[di]) + "\n" +
                ctx.getString(R.string.profile_now_fmt, upName, pc(Cfg.sharp), pc(Cfg.detail), pc(Cfg.denoise), pc(Cfg.deband), aaName) +
                (if (also.isNotEmpty()) "\n" + ctx.getString(R.string.profile_also_fmt, also.joinToString(" · ")) else "") +
                (if (inPlayer && Cfg.profileLevel >= 3) "\n" + ctx.getString(R.string.strength_auto_now_fmt, pc(Cfg.strengthNow / 2f)) else "")
            profileDesc.visibility = View.VISIBLE
        } else {
            profileDesc.visibility = View.GONE
        }
        profileChips.forEachIndexed { i, chip ->
            if (Cfg.profileType == i) {
                chip.background = Ui.gradient(radius)
                chip.setTextColor(Ui.BG)
                chip.setTypeface(null, Typeface.BOLD)
            } else {
                chip.background = Ui.round(Ui.CHIP, radius, Ui.ACCENT, dp(ctx, 1))
                chip.setTextColor(Ui.ACCENT)
                chip.setTypeface(null, Typeface.NORMAL)
            }
        }
        val budgetShown = if (Cfg.budgetAuto) 3 else Cfg.profileBudget
        budgetNote.text = (if (Cfg.budgetAuto) ctx.getString(R.string.budget_auto_now_fmt, ctx.getString(budgetNamesRes[Cfg.profileBudget.coerceIn(0, 2)])) + "\n" else "") +
            ctx.getString(intArrayOf(R.string.budget_perf_desc, R.string.budget_balanced_desc, R.string.budget_quality_desc)[Cfg.profileBudget.coerceIn(0, 2)])
        budgetChips.forEachIndexed { i, chip ->
            if (budgetShown == i) {
                chip.background = Ui.round(Ui.ACCENT, radius)
                chip.setTextColor(Ui.BG)
                chip.setTypeface(null, Typeface.BOLD)
            } else {
                chip.background = Ui.round(Ui.CHIP, radius)
                chip.setTextColor(Ui.MUTED)
                chip.setTypeface(null, Typeface.NORMAL)
            }
        }
        levelChips.forEachIndexed { i, chip ->
            if (Cfg.profileLevel.coerceAtMost(levelChips.size - 1) == i) {
                chip.background = Ui.round(Ui.ACCENT2, radius)
                chip.setTextColor(Ui.BG)
                chip.setTypeface(null, Typeface.BOLD)
            } else {
                chip.background = Ui.round(Ui.CHIP, radius)
                chip.setTextColor(Ui.MUTED)
                chip.setTypeface(null, Typeface.NORMAL)
            }
        }
    }
    paintProfiles()

    val gUp = col.childCount
    // ---- mode chips
    col.addView(Ui.text(ctx, ctx.getString(R.string.mode_label), 12f, Ui.MUTED), gap(14))
    val chipRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
    // shown order -> mode value (CRSC Lanczos sits before Fast and Raw)
    val modeOrder = intArrayOf(Cfg.MODE_SHARP, Cfg.MODE_FSR, Cfg.MODE_SGSR, Cfg.MODE_CLEAR, Cfg.MODE_ART, Cfg.MODE_NIS, Cfg.MODE_NIS_ORIG, Cfg.MODE_NIS_FAST, Cfg.MODE_NIS_FINE, Cfg.MODE_LANCZOS, Cfg.MODE_FAST, Cfg.MODE_RAW)
    val names = arrayOf(
        ctx.getString(R.string.mode_sharpen),
        ctx.getString(R.string.mode_fsr),
        ctx.getString(R.string.mode_sgsr),
        ctx.getString(R.string.mode_clear),
        ctx.getString(R.string.mode_art),
        ctx.getString(R.string.mode_nis),
        ctx.getString(R.string.mode_nis_orig),
        ctx.getString(R.string.mode_nis_fast),
        ctx.getString(R.string.mode_nis_fine),
        ctx.getString(R.string.mode_lanczos),
        ctx.getString(R.string.mode_fast),
        ctx.getString(R.string.mode_raw)
    )
    val chips = names.map { n ->
        TextView(ctx).apply {
            text = n
            textSize = 14f
            gravity = Gravity.CENTER
            minWidth = dp(ctx, 64)
            setPadding(dp(ctx, 16), dp(ctx, 10), dp(ctx, 16), dp(ctx, 10))
            maxLines = 1
        }
    }
    chips.forEach { chip ->
        chipRow.addView(
            chip,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginEnd = dp(ctx, 6)
            }
        )
    }
    val modeScroll = ChipScroller(ctx, chipRow)
    col.addView(modeScroll, gap(6))
    // CRSC Edge: light .. crisp (more passes = better and heavier)
    val crscBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    crscBox.addView(Ui.text(ctx, ctx.getString(R.string.crsc_quality), 12f, Ui.MUTED), gap(10))
    val crscQRow = Rebuildable(ctx) {
        chipRow(ctx, listOf(R.string.crsc_l0, R.string.crsc_l1, R.string.crsc_l2, R.string.crsc_l3, R.string.crsc_l4, R.string.crsc_l5).map { ctx.getString(it) }, Cfg.crscLevel.coerceIn(0, 5)) { q ->
            onUserEdited()
            Cfg.crscLevel = q
            Cfg.save(ctx)
            onApply()
        }
    }
    crscBox.addView(crscQRow, gap(6))
    val crscExactRow = Rebuildable(ctx) {
        panelSwitch(ctx, ctx.getString(R.string.crsc_exact), Cfg.crscExact) { on ->
            onUserEdited()
            Cfg.crscExact = on
            Cfg.save(ctx)
            onApply()
        }
    }
    crscBox.addView(crscExactRow, gap(10))
    crscBox.addView(Ui.text(ctx, ctx.getString(R.string.crsc_exact_hint), 12f, Ui.MUTED), gap(2))
    crscBox.visibility = if (Cfg.mode == Cfg.MODE_LANCZOS) View.VISIBLE else View.GONE
    col.addView(crscBox)
    // NIS fast: Exact / Medium / Light (less work, a little less like NIS original)
    var fastMid = Cfg.mode == Cfg.MODE_NIS_MID
    lateinit var nisFastBox: LinearLayout
    lateinit var nisMidBox: LinearLayout
    val midBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    val midRow = Rebuildable(ctx) {
        fastMid = Cfg.mode == Cfg.MODE_NIS_MID || (fastMid && Cfg.mode != Cfg.MODE_NIS_FAST)
        chipRow(ctx, listOf(ctx.getString(R.string.crsc_kind_std), ctx.getString(R.string.variant_mid)), if (fastMid) 1 else 0) { k ->
            onUserEdited()
            fastMid = k == 1
            Cfg.mode = if (fastMid) Cfg.MODE_NIS_MID else Cfg.MODE_NIS_FAST
            Cfg.save(ctx)
            nisFastBox.visibility = if (fastMid) View.GONE else View.VISIBLE
            nisMidBox.visibility = if (fastMid) View.VISIBLE else View.GONE
            onApply()
        }
    }
    midBox.addView(midRow, gap(8))
    midBox.visibility = if (Cfg.mode == Cfg.MODE_NIS_FAST || Cfg.mode == Cfg.MODE_NIS_MID) View.VISIBLE else View.GONE
    col.addView(midBox)
    nisFastBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    nisFastBox.addView(Ui.text(ctx, ctx.getString(R.string.nisfast_quality), 12f, Ui.MUTED), gap(10))
    val nisFastRow = Rebuildable(ctx) {
        chipRow(ctx, listOf(R.string.nisfast_l0, R.string.nisfast_l1, R.string.nisfast_l2).map { ctx.getString(it) }, Cfg.nisFastLevel.coerceIn(0, 2)) { q ->
            onUserEdited()
            Cfg.nisFastLevel = q
            Cfg.save(ctx)
            onApply()
        }
    }
    nisFastBox.addView(nisFastRow, gap(6))
    nisFastBox.addView(Ui.text(ctx, ctx.getString(R.string.nisfast_hint), 12f, Ui.MUTED), gap(2))
    nisFastBox.visibility = if (Cfg.mode == Cfg.MODE_NIS_FAST || Cfg.mode == Cfg.MODE_NIS_FINE) View.VISIBLE else View.GONE
    col.addView(nisFastBox)
    // NIS fast Mid: Exact / Medium (how Mid always was) / Light, the same three levels as NIS fast
    nisMidBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    nisMidBox.addView(Ui.text(ctx, ctx.getString(R.string.nismid_quality), 12f, Ui.MUTED), gap(10))
    val nisMidRow = Rebuildable(ctx) {
        chipRow(ctx, listOf(R.string.nismid_l0, R.string.nismid_l1, R.string.nismid_l2).map { ctx.getString(it) }, Cfg.nisMidLevel.coerceIn(0, 2)) { q ->
            onUserEdited()
            Cfg.nisMidLevel = q
            Cfg.save(ctx)
            onApply()
        }
    }
    nisMidBox.addView(nisMidRow, gap(6))
    nisMidBox.addView(Ui.text(ctx, ctx.getString(R.string.nismid_hint), 12f, Ui.MUTED), gap(2))
    nisMidBox.visibility = if (Cfg.mode == Cfg.MODE_NIS_MID) View.VISIBLE else View.GONE
    col.addView(nisMidBox)
    // Aura (Standard / Soft) and NIS fast (Standard / Mid): one chip each in the list, the variant is picked in a small row under it
    var auraSoft = Cfg.mode == Cfg.MODE_NIS_SOFT
    val auraBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    val auraRow = Rebuildable(ctx) {
        auraSoft = Cfg.mode == Cfg.MODE_NIS_SOFT || (auraSoft && Cfg.mode != Cfg.MODE_NIS)
        chipRow(ctx, listOf(ctx.getString(R.string.crsc_kind_std), ctx.getString(R.string.variant_soft)), if (auraSoft) 1 else 0) { k ->
            onUserEdited()
            auraSoft = k == 1
            Cfg.mode = if (auraSoft) Cfg.MODE_NIS_SOFT else Cfg.MODE_NIS
            Cfg.save(ctx)
            onApply()
        }
    }
    auraBox.addView(auraRow, gap(8))
    auraBox.visibility = if (Cfg.mode == Cfg.MODE_NIS || Cfg.mode == Cfg.MODE_NIS_SOFT) View.VISIBLE else View.GONE
    col.addView(auraBox)
    // sharpening layer that works on top of every upscaler (not only CRSC Edge)
    val crispBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    crispBox.addView(Ui.text(ctx, ctx.getString(R.string.crsc_plus), 12f, Ui.MUTED), gap(12))
    // the two rows are built again from the settings whenever they change (a profile / Auto / Reset can change them from outside)
    lateinit var crispRows: Rebuildable
    crispRows = Rebuildable(ctx) {
        val rows = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        // second row (only while the sharpener is on): which shader does the work, so the card stays short
        val kindRow = chipRow(ctx, listOf(ctx.getString(R.string.crsc_kind_std), ctx.getString(R.string.crsc_kind_fast)), if (Cfg.crscNisFast) 1 else 0) { k ->
            onUserEdited()
            Cfg.crscNisFast = k == 1
            Cfg.save(ctx)
            onApply()
        }
        rows.addView(
            chipRow(ctx, listOf(R.string.crsc_nis_off, R.string.crsc_nis_soft, R.string.crsc_nis_mid, R.string.crsc_nis_strong, R.string.crsc_nis_max).map { ctx.getString(it) }, Cfg.crscNis.coerceIn(0, 4)) { q ->
                onUserEdited()
                Cfg.crscNis = q
                Cfg.save(ctx)
                kindRow.visibility = if (q > 0) View.VISIBLE else View.GONE
                onApply()
            },
            gap(6)
        )
        kindRow.visibility = if (Cfg.crscNis > 0) View.VISIBLE else View.GONE
        rows.addView(kindRow, gap(6))
        rows
    }
    crispBox.addView(crispRows)
    crispBox.addView(Ui.text(ctx, ctx.getString(R.string.crsc_plus_hint), 12f, Ui.MUTED), gap(2))
    crispBox.visibility = if (Cfg.mode == Cfg.MODE_RAW || Cfg.mode == Cfg.MODE_CLEAR || Cfg.mode == Cfg.MODE_ART) View.GONE else View.VISIBLE
    col.addView(crispBox)

    // ---- "Fine pixels": its own option on top of any upscaler (switch + how fine the squares are, in blocks per source pixel)
    val finePixBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    val pixBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    val finePixSw = Switch(ctx).apply {
        text = ctx.getString(R.string.mode_pixel)
        setTextColor(Ui.TEXT)
        isChecked = Cfg.finePixels
        setOnCheckedChangeListener { _, c ->
            Cfg.finePixels = c
            pixBox.visibility = if (c) View.VISIBLE else View.GONE
            Cfg.save(ctx)
            onApply()
        }
    }
    finePixBox.addView(finePixSw, gap(14))
    val pixLabel = Ui.text(ctx, "", 14f)
    val pixBar = SeekBar(ctx).apply {
        // logarithmic: 0.1x ... 8x, so the small values (big squares) and the large ones are both easy to set; it sticks to 1x, 0.5x and 0.25x
        max = 1000
        progress = (Math.log((Cfg.pixelFactor / Cfg.PIXEL_MIN).toDouble()) / Math.log((Cfg.PIXEL_MAX / Cfg.PIXEL_MIN).toDouble()) * 1000.0).roundToInt().coerceIn(0, max)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (!fromUser) { pixLabel.text = pixelText(ctx, Cfg.pixelFactor); return } // set by the panel refresh (profile, Auto): the stored value is not rounded to the slider's steps
                var f = (Cfg.PIXEL_MIN * Math.pow((Cfg.PIXEL_MAX / Cfg.PIXEL_MIN).toDouble(), p / 1000.0)).toFloat()
                for (snap in floatArrayOf(0.25f, 0.5f, 1f, 2f, 4f)) if (Math.abs(f - snap) < snap * 0.04f) f = snap
                Cfg.pixelFactor = f.coerceIn(Cfg.PIXEL_MIN, Cfg.PIXEL_MAX)
                pixLabel.text = pixelText(ctx, Cfg.pixelFactor)
            }

            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) = Cfg.save(ctx)
        })
    }
    pixLabel.text = pixelText(ctx, Cfg.pixelFactor)
    pixBox.addView(pixLabel, gap(12))
    pixBox.addView(pixBar, gap(2))
    pixBox.addView(Ui.text(ctx, ctx.getString(R.string.pixel_hint), 12f, Ui.MUTED), gap(2))
    pixBox.visibility = if (Cfg.finePixels) View.VISIBLE else View.GONE
    finePixBox.addView(pixBox)
    finePixBox.visibility = if (Cfg.mode == Cfg.MODE_RAW) View.GONE else View.VISIBLE // Raw already is square blocks of source pixels
    col.addView(finePixBox)

    val gSharp = col.childCount
    // ---- sharpness
    col.addView(Ui.text(ctx, ctx.getString(R.string.sc_head_sharp), 12f, Ui.ACCENT, true), gap(6))
    val sharpLabel = Ui.text(ctx, "", 14f)
    val sharpBar = SeekBar(ctx).apply {
        max = 100
        progress = (Cfg.sharp * 100).roundToInt()
    }
    sharpLabel.text = ctx.getString(R.string.sharpness_fmt, sharpBar.progress)
    col.addView(sharpLabel, gap(14))
    col.addView(sharpBar, gap(2))

    // ---- detail / deblur (wide unsharp mask for soft, already-upscaled sources like low-res video)
    val detailLabel = Ui.text(ctx, "", 14f)
    val detailBar = SeekBar(ctx).apply {
        max = 100
        progress = (Cfg.detail * 100).roundToInt().coerceIn(0, 100)
    }
    detailLabel.text = ctx.getString(R.string.detail_fmt, detailBar.progress)
    col.addView(detailLabel, gap(14))
    col.addView(detailBar, gap(2))
    val detailSizeLabel = Ui.text(ctx, "", 14f)
    val detailSizeBar = SeekBar(ctx).apply {
        max = 100
        progress = (Cfg.detailSize * 100).roundToInt().coerceIn(0, 100)
        alpha = if (Cfg.detail > 0f) 1f else 0.4f
    }
    detailSizeLabel.alpha = detailSizeBar.alpha
    detailSizeLabel.text = ctx.getString(R.string.detail_size_fmt, detailSizeBar.progress)
    col.addView(detailSizeLabel, gap(10))
    col.addView(detailSizeBar, gap(2))
    // protect noise: the sharpening (RCAS) works less on noise-like pixels
    val protectLabel = Ui.text(ctx, "", 14f)
    val protectBar = SeekBar(ctx).apply {
        max = 100
        progress = (Cfg.sharpProtect * 100).roundToInt().coerceIn(0, 100)
    }
    protectLabel.text = ctx.getString(R.string.protect_fmt, protectBar.progress)
    col.addView(protectLabel, gap(14))
    col.addView(protectBar, gap(2))
    col.addView(Ui.text(ctx, ctx.getString(R.string.protect_hint), 11f, Ui.MUTED), gap(2))

    // ---- clean-up: one row of quick strengths, then the sliders (clean up low-bitrate video before sharpening)
    col.addView(Ui.text(ctx, ctx.getString(R.string.sc_head_clean), 12f, Ui.ACCENT, true), gap(22))
    var cleanPresetHook: (Int) -> Unit = {} // set below, once syncAll() exists
    val cleanPresetRow = Rebuildable(ctx) {
        chipRow(ctx, listOf(R.string.cleanp_off, R.string.cleanp_light, R.string.cleanp_normal, R.string.cleanp_strong).map { ctx.getString(it) }, cleanPresetIndex()) { i -> cleanPresetHook(i) }
    }
    col.addView(cleanPresetRow, gap(8))
    val denoiseLabel = Ui.text(ctx, "", 14f)
    val denoiseBar = SeekBar(ctx).apply {
        max = 100
        progress = (Cfg.denoise * 100).roundToInt().coerceIn(0, 100)
    }
    denoiseLabel.text = ctx.getString(R.string.denoise_fmt, denoiseBar.progress)
    col.addView(denoiseLabel, gap(14))
    col.addView(denoiseBar, gap(2))
    // colour clean-up: smooths only the colour (blotches, bleeding, coloured noise); the brightness, and so the detail, stays
    val chromaLabel = Ui.text(ctx, "", 14f)
    val chromaBar = SeekBar(ctx).apply {
        max = 100
        progress = (Cfg.chromaClean * 100).roundToInt().coerceIn(0, 100)
    }
    chromaLabel.text = ctx.getString(R.string.chroma_fmt, chromaBar.progress)
    col.addView(chromaLabel, gap(10))
    col.addView(chromaBar, gap(2))
    col.addView(Ui.text(ctx, ctx.getString(R.string.chroma_hint), 11f, Ui.MUTED), gap(2))
    val debandLabel = Ui.text(ctx, "", 14f)
    val debandBar = SeekBar(ctx).apply {
        max = 100
        progress = (Cfg.deband * 100).roundToInt().coerceIn(0, 100)
    }
    debandLabel.text = ctx.getString(R.string.deband_fmt, debandBar.progress)
    col.addView(debandLabel, gap(10))
    col.addView(debandBar, gap(2))
    val scReset = Ui.text(ctx, ctx.getString(R.string.sc_reset), 13f, Ui.ACCENT, true).apply {
        gravity = Gravity.CENTER
        setPadding(0, dp(ctx, 12), 0, dp(ctx, 4))
    }
    col.addView(scReset, gap(10))

    val gRes = col.childCount
    // ---- render resolution (presets + custom slider)
    // Phone resolution classes (1080p/1440p/4K) name the SHORT edge (width in portrait), not the
    // long one, e.g. a "1080p/FHD+" panel is usually 1080x2400, not 1080 tall. Presets are compared
    // against that short edge; the single scale factor this yields is then applied to both axes.
    val screenBounds = ctx.getSystemService(WindowManager::class.java)?.maximumWindowMetrics?.bounds
    val nativeW = screenBounds?.width() ?: 1080
    val nativeHFull = screenBounds?.height() ?: 2400
    val nativeH = minOf(nativeW, nativeHFull)
    if (!inPlayer) col.addView(Ui.text(ctx, ctx.getString(R.string.render_resolution_label), 12f, Ui.MUTED), gap(14))
    val presetRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
    // label to preset-height pairs (short edge). Lower-than-native presets are for upscaling
    // (render low, upscale back); higher ones supersample. PRESET_CUSTOM (0) lets the slider drive scalePct.
    val presetDefs = Cfg.PRESETS.map { h ->
        (if (h == Cfg.PRESET_4K) ctx.getString(R.string.preset_4k) else "${h}p") to h
    } + (ctx.getString(R.string.preset_custom) to Cfg.PRESET_CUSTOM)
    val presetChips = presetDefs.map { (label, _) ->
        TextView(ctx).apply {
            text = label
            textSize = 13f
            gravity = Gravity.CENTER
            minWidth = dp(ctx, 56)
            maxLines = 1
            setPadding(dp(ctx, 14), dp(ctx, 8), dp(ctx, 14), dp(ctx, 8))
        }
    }
    presetChips.forEachIndexed { i, chip ->
        presetRow.addView(
            chip,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                if (i != presetChips.lastIndex) marginEnd = dp(ctx, 6)
            }
        )
    }
    val presetScroll = ChipScroller(ctx, presetRow)
    if (!inPlayer) col.addView(presetScroll, gap(6))

    val scaleLabel = Ui.text(ctx, "", 14f)
    val scaleBar = SeekBar(ctx).apply {
        max = Cfg.SCALE_MAX - Cfg.SCALE_MIN
        progress = Cfg.scalePct.coerceIn(Cfg.SCALE_MIN, Cfg.SCALE_MAX) - Cfg.SCALE_MIN
    }
    fun scaleText(pct: Int) = ctx.getString(R.string.custom_scale_fmt, pct, nativeW, nativeHFull)
    scaleLabel.text = scaleText(Cfg.SCALE_MIN + scaleBar.progress)
    val scaleHint = Ui.text(ctx, ctx.getString(R.string.scale_sharpen_hint), 12f, Ui.MUTED)
    if (!inPlayer) {
        col.addView(scaleLabel, gap(10))
        col.addView(scaleBar, gap(2))
        col.addView(scaleHint, gap(4))
    } else {
        // ---- player / photo: input resolution -> output resolution (the player's own resolution chain)
        col.addView(Ui.text(ctx, ctx.getString(R.string.res_chain_title), 12f, Ui.MUTED), gap(14))
        val info = Ui.text(ctx, "", 12f, Ui.ACCENT).apply { setTextIsSelectable(false) }
        col.addView(info, gap(4))
        fun refreshInfo() {
            if (!info.isAttachedToWindow) return
            info.text = ctx.getString(R.string.res_chain_info_fmt, Cfg.resInfo.ifEmpty { "-" })
            info.postDelayed({ refreshInfo() }, 600)
        }
        info.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) = refreshInfo()
            override fun onViewDetachedFromWindow(v: View) {}
        })
        fun resChips(label: String, labels: List<String>, values: List<Int>, get: () -> Int, set: (Int) -> Unit) {
            col.addView(Ui.text(ctx, label, 13f, Ui.TEXT), gap(10))
            val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            val chips = ArrayList<TextView>()
            fun paint() {
                val r = dp(ctx, 10).toFloat()
                chips.forEachIndexed { i, ch ->
                    val on = values[i] == get()
                    ch.background = if (on) Ui.gradient(r) else Ui.round(Ui.CHIP, r)
                    ch.setTextColor(if (on) Ui.BG else Ui.MUTED)
                }
            }
            labels.forEachIndexed { i, l ->
                val ch = TextView(ctx).apply {
                    text = l
                    textSize = 13f
                    gravity = Gravity.CENTER
                    minWidth = dp(ctx, 52)
                    maxLines = 1
                    setPadding(dp(ctx, 12), dp(ctx, 8), dp(ctx, 12), dp(ctx, 8))
                    setOnClickListener {
                        onUserEdited()
                        set(values[i])
                        Cfg.save(ctx)
                        paint()
                        onApply()
                    }
                }
                chips.add(ch)
                row.addView(ch, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    if (i != labels.lastIndex) marginEnd = dp(ctx, 6)
                })
            }
            paint()
            col.addView(ChipScroller(ctx, row), gap(4))
        }
        val auto = ctx.getString(R.string.res_auto)
        // the input size is detected from the file (the old "Input" choice is gone: Middle does the same job and is clearer)
        resChips(
            ctx.getString(R.string.res_mid_label),
            listOf(auto, "240p", "360p", "480p", "540p", "720p", "1080p", "1440p", ctx.getString(R.string.preset_4k)),
            listOf(0, 240, 360, 480, 540, 720, 1080, 1440, 2160), { Cfg.midRes }, { Cfg.midRes = it }
        )
        resChips(
            ctx.getString(R.string.res_output_label),
            listOf(auto, "480p", "540p", "720p", "1080p", "1440p", ctx.getString(R.string.preset_4k), ctx.getString(R.string.preset_6k)),
            listOf(0, 480, 540, 720, 1080, 1440, 2160, 3240), { Cfg.outRes }, { Cfg.outRes = it }
        )
        col.addView(Ui.text(ctx, ctx.getString(R.string.res_chain_hint), 12f, Ui.MUTED), gap(4))
        col.addView(Ui.text(ctx, ctx.getString(R.string.res_mid_hint), 12f, Ui.MUTED), gap(4))
    }

    val gAa = col.childCount
    // ---- anti-aliasing (swipeable chips + strength)
    col.addView(Ui.text(ctx, ctx.getString(R.string.aa_label), 12f, Ui.MUTED), gap(14))
    val aaRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
    val aaNames = listOf(
        ctx.getString(R.string.aa_off),
        ctx.getString(R.string.aa_fxaa_fast),
        ctx.getString(R.string.aa_fxaa_quality),
        ctx.getString(R.string.aa_edge),
        ctx.getString(R.string.aa_smart)
    )
    val aaChips = aaNames.map { n ->
        TextView(ctx).apply {
            text = n
            textSize = 13f
            gravity = Gravity.CENTER
            minWidth = dp(ctx, 56)
            maxLines = 1
            setPadding(dp(ctx, 14), dp(ctx, 8), dp(ctx, 14), dp(ctx, 8))
        }
    }
    aaChips.forEachIndexed { i, chip ->
        aaRow.addView(
            chip,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                if (i != aaChips.lastIndex) marginEnd = dp(ctx, 6)
            }
        )
    }
    val aaScroll = ChipScroller(ctx, aaRow)
    col.addView(aaScroll, gap(6))
    val aaLabel = Ui.text(ctx, "", 14f)
    val aaBar = SeekBar(ctx).apply {
        max = 100
        progress = (Cfg.aaStrength * 100).roundToInt().coerceIn(0, 100)
        alpha = if (Cfg.aaMode == Cfg.AA_OFF) 0.4f else 1f
    }
    aaLabel.alpha = aaBar.alpha
    aaLabel.text = ctx.getString(R.string.aa_strength_fmt, aaBar.progress)
    col.addView(aaLabel, gap(10))
    col.addView(aaBar, gap(2))

    val gCol = col.childCount
    // ---- looks: ready colour moods (cinematic, artistic, cheerful, horror ...); only the colour settings below are set
    col.addView(Ui.text(ctx, ctx.getString(R.string.look_title), 12f, Ui.MUTED), gap(16))
    var curLook = -1
    var lookOff = false // "Off": the Looks section is switched off (the colour sliders are back to 0 and the strength bar is dimmed)
    var lookStrength = 100
    var lookApply: () -> Unit = {}
    // the marked chip is what really is on (the panel is built again for every photo / video: before, it always came back as Custom)
    run {
        val d = Looks.detect()
        if (d != null) { curLook = d.first; lookStrength = d.second } else if (Looks.neutral() && Looks.wasOff(ctx)) lookOff = true
    }
    // chips: 0 = Off, 1 = Custom (no ready look; the colour sliders stay as they are), 2.. = the ready looks
    val lookNames = listOf(ctx.getString(R.string.look_off), ctx.getString(R.string.look_custom)) + Looks.ALL.map { ctx.getString(it.name) }
    val lookChips = ArrayList<TextView>()
    var lookBarRef: SeekBar? = null
    var lookLabelRef: TextView? = null
    var lookResetRef: View? = null
    var lookChipsPaintRef: () -> Unit = {}
    fun lookChipsPaint() = lookChipsPaintRef()
    /** Colours were changed by hand / a profile / Auto: a marked look that no longer matches becomes Custom, and Off ends when a colour is set. */
    fun lookReconcile() {
        var ch = false
        if (curLook >= 0 && !Looks.matches(curLook, lookStrength / 100f)) { curLook = -1; ch = true }
        if (lookOff && !Looks.neutral()) { lookOff = false; Looks.setOff(ctx, false); ch = true }
        if (ch) lookChipsPaint()
    }
    fun paintLooks() {
        val r = dp(ctx, 10).toFloat()
        lookChips.forEachIndexed { i, c ->
            val sel = when (i) { 0 -> lookOff; 1 -> !lookOff && curLook == -1; else -> !lookOff && i - 2 == curLook }
            c.background = if (sel) Ui.gradient(r) else Ui.round(Ui.CHIP, r)
            c.setTextColor(if (sel) Ui.BG else Ui.TEXT)
        }
        lookResetRef?.visibility = if (!lookOff && curLook == -1) View.VISIBLE else View.GONE // the reset belongs to Custom
        val a = if (lookOff) 0.4f else 1f
        lookBarRef?.let { it.alpha = a; it.isEnabled = !lookOff }
        lookLabelRef?.alpha = a
    }
    val lookRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
    lookNames.forEachIndexed { i, n ->
        val chip = TextView(ctx).apply {
            text = n
            textSize = 13f
            gravity = Gravity.CENTER
            maxLines = 1
            setPadding(dp(ctx, 14), dp(ctx, 8), dp(ctx, 14), dp(ctx, 8))
            setOnClickListener {
                val wasCustom = !lookOff && curLook == -1
                if (wasCustom && i != 1) Looks.saveCustom(ctx) // leaving Custom: my own colours are kept for later
                when (i) {
                    0 -> { lookOff = true; curLook = -1; Looks.setOff(ctx, true); lookApply() }   // Off: no look, colour sliders back to 0
                    1 -> {                                                                       // Custom: my own colours come back
                        lookOff = false
                        curLook = -1
                        Looks.setOff(ctx, false)
                        if (!wasCustom) { Looks.restoreCustom(ctx); lookApply() }
                    }
                    else -> { lookOff = false; curLook = i - 2; Looks.setOff(ctx, false); lookApply() } // a ready look
                }
                paintLooks()
            }
        }
        lookChips.add(chip)
        lookRow.addView(chip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(ctx, 6) })
    }
    lookChipsPaintRef = { paintLooks() }
    col.addView(ChipScroller(ctx, lookRow), gap(6))
    // Custom: one tap puts all colour settings back to 0 and forgets the saved custom colours
    val lookReset = TextView(ctx).apply {
        text = ctx.getString(R.string.look_reset)
        textSize = 13f
        gravity = Gravity.CENTER
        setTextColor(Ui.TEXT)
        background = Ui.round(Ui.CHIP, dp(ctx, 10).toFloat())
        setPadding(dp(ctx, 14), dp(ctx, 8), dp(ctx, 14), dp(ctx, 8))
        setOnClickListener {
            Looks.apply(-1, 0f)       // every colour setting 0
            Cfg.vignette = 0f; Cfg.fade = 0f
            Looks.clearCustom(ctx)    // the saved custom colours are forgotten too
            lookApply()               // save, refresh the sliders, redraw (Custom stays marked)
            paintLooks()
        }
    }
    lookResetRef = lookReset
    col.addView(lookReset, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(ctx, 6) })
    paintLooks()
    val lookLabel = Ui.text(ctx, ctx.getString(R.string.look_strength_fmt, lookStrength), 13f)
    val lookBar = SeekBar(ctx).apply { max = 100; progress = lookStrength }
    lookBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            lookStrength = p
            lookLabel.text = ctx.getString(R.string.look_strength_fmt, p)
            if (fromUser && curLook >= 0) lookApply()
        }
        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) {}
    })
    lookBarRef = lookBar
    lookLabelRef = lookLabel
    paintLooks()
    col.addView(lookLabel, gap(8))
    col.addView(lookBar, gap(2))
    col.addView(Ui.text(ctx, ctx.getString(R.string.look_hint), 12f, Ui.MUTED), gap(2))

    // ---- vivid colors
    val vividLabel = Ui.text(ctx, "", 14f)
    val vividBar = SeekBar(ctx).apply {
        max = 100
        progress = (Cfg.vivid * 100).roundToInt().coerceIn(0, 100)
    }
    vividLabel.text = ctx.getString(R.string.vivid_colors_fmt, vividBar.progress)
    val vividViews = listOf<View>(vividLabel, vividBar)

    // ---- contrast (-50 .. +50 around the middle)
    val contrastLabel = Ui.text(ctx, "", 14f)
    val contrastBar = SeekBar(ctx).apply {
        max = 100
        progress = ((Cfg.contrast + 1f) * 50f).roundToInt().coerceIn(0, 100)
    }
    contrastLabel.text = ctx.getString(R.string.contrast_fmt, contrastBar.progress - 50)
    val contrastViews = listOf<View>(contrastLabel, contrastBar)

    // ---- tone rows: shadows, highlights, saturation, warmth (-100..+100), film grain (0..100)
    class ToneRow(val fmt: Int, val bipolar: Boolean, val get: () -> Float, val set: (Float) -> Unit)
    val toneRows = listOf(
        ToneRow(R.string.shadows_fmt, true, { Cfg.shadows }, { Cfg.shadows = it }),
        ToneRow(R.string.highlights_fmt, true, { Cfg.highlights }, { Cfg.highlights = it }),
        ToneRow(R.string.saturation_fmt, true, { Cfg.saturation }, { Cfg.saturation = it }),
        ToneRow(R.string.warmth_fmt, true, { Cfg.warmth }, { Cfg.warmth = it }),
        ToneRow(R.string.tint_fmt, true, { Cfg.tint }, { Cfg.tint = it }),
        ToneRow(R.string.vibrance_fmt, true, { Cfg.vibrance }, { Cfg.vibrance = it }),
        ToneRow(R.string.brightness_fmt, true, { Cfg.brightness }, { Cfg.brightness = it }),
        ToneRow(R.string.grain_fmt, false, { Cfg.grain }, { Cfg.grain = it }),
        ToneRow(R.string.clarity_fmt, true, { Cfg.clarity }, { Cfg.clarity = it }),
        ToneRow(R.string.antiring_fmt, false, { Cfg.antiRing }, { Cfg.antiRing = it }),
        ToneRow(R.string.gamelight_fmt, false, { Cfg.gameLight }, { Cfg.gameLight = it }),
        ToneRow(R.string.vignette_fmt, true, { Cfg.vignette }, { Cfg.vignette = it }),
        ToneRow(R.string.fade_fmt, false, { Cfg.fade }, { Cfg.fade = it })
    )
    fun toneShown(r: ToneRow, p: Int) = if (r.bipolar) p - 100 else p
    fun toneProgress(r: ToneRow) = if (r.bipolar) ((r.get() + 1f) * 100f).roundToInt().coerceIn(0, 200) else (r.get() * 100f).roundToInt().coerceIn(0, 100)
    val toneLabels = ArrayList<TextView>()
    val toneBars = ArrayList<SeekBar>()
    for (r in toneRows) {
        val lab = Ui.text(ctx, "", 14f)
        val bar = SeekBar(ctx).apply {
            max = if (r.bipolar) 200 else 100
            progress = toneProgress(r)
        }
        lab.text = ctx.getString(r.fmt, toneShown(r, bar.progress))
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                r.set(if (r.bipolar) (p - 100) / 100f else p / 100f)
                lab.text = ctx.getString(r.fmt, toneShown(r, p))
            }

            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) = Cfg.save(ctx)
        })
        toneLabels.add(lab)
        toneBars.add(bar)
    }
    // the sliders in three small groups (the rows keep their order in the lists above: they are only ADDED here in the groups' order)
    fun addToneGroup(title: Int, first: Boolean, vararg items: Any) {
        col.addView(Ui.text(ctx, ctx.getString(title), 12f, Ui.ACCENT, true), gap(if (first) 14 else 20))
        for (it in items) {
            if (it is Int) { col.addView(toneLabels[it], gap(14)); col.addView(toneBars[it], gap(2)) }
            else { val (l, b) = it as List<*>; col.addView(l as View, gap(14)); col.addView(b as View, gap(2)) }
        }
    }
    // 0 shadows, 1 highlights, 2 saturation, 3 warmth, 4 tint, 5 vibrance, 6 brightness, 7 grain, 8 clarity, 9 anti-ringing, 10 game light, 11 vignette, 12 fade
    addToneGroup(R.string.cg_light, true, contrastViews, 6, 0, 1)
    addToneGroup(R.string.cg_colour, false, vividViews, 2, 5, 3, 4)
    addToneGroup(R.string.cg_finish, false, 8, 7, 11, 12, 9, 10)
    val gVid = col.childCount
    // ---- "What does this video need?": looks at the video that is playing (Auto's analysis) and offers what it found as one tap
    val showCheck = inPlayer && autoPick != null
    if (showCheck) {
        col.addView(Ui.text(ctx, ctx.getString(R.string.vo_head_check), 12f, Ui.ACCENT, true), gap(6))
        col.addView(
            Ui.text(ctx, ctx.getString(R.string.vo_check_button), 15f, Ui.ACCENT, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(ctx, 12), dp(ctx, 10), dp(ctx, 12), dp(ctx, 10))
                background = Ui.round(Ui.CHIP, dp(ctx, 12).toFloat())
                setOnClickListener {
                    val pick = autoPick?.invoke()
                    if (pick == null) { Toast.makeText(ctx, R.string.vo_check_none, Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                    val lines = ArrayList<String>()
                    val todo = ArrayList<() -> Unit>()
                    if (pick.type == Profiles.PHOTO) lines.add("• " + ctx.getString(R.string.vo_check_photo))
                    else {
                        if (pick.deint == 1) { lines.add("• " + ctx.getString(R.string.vo_check_interlaced)); if (Cfg.deint == 0) todo.add { Cfg.deint = 1 } }
                        else lines.add("• " + ctx.getString(R.string.vo_check_progressive))
                        val bpp = if (pick.quality > 0f) String.format(java.util.Locale.US, "%.3f", pick.quality) else ""
                        when {
                            pick.clean > 0f -> {
                                lines.add("• " + ctx.getString(R.string.vo_check_clean_fmt, bpp, (pick.clean * 100).roundToInt()))
                                if (!Cfg.cleanUp || Math.abs(Cfg.cleanLevel - pick.clean) > 0.04f) todo.add { Cfg.cleanUp = true; Cfg.cleanLevel = pick.clean }
                            }
                            pick.clean == 0f -> lines.add("• " + ctx.getString(R.string.vo_check_clean_none_fmt, bpp))
                            else -> lines.add("• " + ctx.getString(R.string.vo_check_unknown))
                        }
                        if (pick.canCrop) { lines.add("• " + ctx.getString(R.string.vo_check_crop)); if (!Cfg.autoCrop) todo.add { Cfg.autoCrop = true } }
                    }
                    val b = AlertDialog.Builder(ctx).setTitle(R.string.vo_check_title).setMessage(lines.joinToString("\n\n"))
                    if (todo.isNotEmpty()) {
                        b.setPositiveButton(R.string.vo_check_apply) { _, _ ->
                            onUserEdited()
                            todo.forEach { it() }
                            Cfg.save(ctx)
                            ControlsBus.sync?.invoke()
                            onApply()
                        }
                        b.setNegativeButton(android.R.string.cancel, null)
                    } else b.setPositiveButton(android.R.string.ok, null)
                    b.show()
                }
            },
            gap(10)
        )
        col.addView(Ui.text(ctx, ctx.getString(R.string.vo_check_hint), 12f, Ui.MUTED), gap(2))
    }
    col.addView(Ui.text(ctx, ctx.getString(R.string.vo_head_pic), 12f, Ui.ACCENT, true), gap(if (showCheck) 22 else 6))
    // ---- deinterlace (video player): off / rebuild odd lines / rebuild even lines, only where combing shows
    col.addView(Ui.text(ctx, ctx.getString(R.string.deint_label), 12f, Ui.MUTED), gap(14))
    val deintRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
    val deintChips = listOf(R.string.deint_off, R.string.deint_odd, R.string.deint_even).map { rid ->
        TextView(ctx).apply {
            text = ctx.getString(rid)
            textSize = 13f
            gravity = Gravity.CENTER
            minWidth = dp(ctx, 56)
            maxLines = 1
            setPadding(dp(ctx, 14), dp(ctx, 8), dp(ctx, 14), dp(ctx, 8))
        }
    }
    deintChips.forEachIndexed { i, chip ->
        deintRow.addView(
            chip,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                if (i != deintChips.lastIndex) marginEnd = dp(ctx, 6)
            }
        )
    }
    col.addView(ChipScroller(ctx, deintRow), gap(6))
    col.addView(Ui.text(ctx, ctx.getString(R.string.deint_hint), 12f, Ui.MUTED), gap(4))
    fun paintDeint() {
        val radius = dp(ctx, 10).toFloat()
        deintChips.forEachIndexed { i, chip ->
            if (Cfg.deint == i) {
                chip.background = Ui.gradient(radius)
                chip.setTextColor(Ui.BG)
                chip.setTypeface(null, Typeface.BOLD)
            } else {
                chip.background = Ui.round(Ui.CHIP, radius)
                chip.setTextColor(Ui.MUTED)
                chip.setTypeface(null, Typeface.NORMAL)
            }
        }
    }
    deintChips.forEachIndexed { i, chip ->
        chip.setOnClickListener {
            onUserEdited()
            Cfg.deint = i
            Cfg.save(ctx)
            paintDeint()
        }
    }
    paintDeint()
    val autoCropSw = Switch(ctx).apply {
        text = ctx.getString(R.string.autocrop_switch)
        setTextColor(Ui.TEXT)
        isChecked = Cfg.autoCrop
        setOnCheckedChangeListener { v, c ->
            if (v.isPressed) onUserEdited()
            Cfg.autoCrop = c
            Cfg.save(ctx)
        }
    }
    col.addView(autoCropSw, gap(14))
    col.addView(Ui.text(ctx, ctx.getString(R.string.autocrop_hint), 12f, Ui.MUTED), gap(2))
    // adapt the clean-up to the size of the video: 144p..480p have much more compression damage than HD
    val cleanAutoSw = Switch(ctx).apply {
        text = ctx.getString(R.string.clean_auto_switch)
        setTextColor(Ui.TEXT)
        isChecked = Cfg.cleanAuto
        setOnCheckedChangeListener { _, c ->
            onUserEdited()
            Cfg.cleanAuto = c
            Cfg.save(ctx)
            onApply()
        }
    }
    col.addView(cleanAutoSw, gap(14))
    col.addView(Ui.text(ctx, ctx.getString(R.string.clean_auto_hint), 12f, Ui.MUTED), gap(2))
    col.addView(Ui.text(ctx, ctx.getString(R.string.vo_head_perf), 12f, Ui.ACCENT, true), gap(22))
    val smoothSw = Switch(ctx).apply {
        text = ctx.getString(R.string.smooth_switch)
        setTextColor(Ui.TEXT)
        isChecked = Cfg.smoothLive
        setOnCheckedChangeListener { _, c ->
            Cfg.smoothLive = c
            Cfg.save(ctx)
        }
    }
    col.addView(smoothSw, gap(14))
    col.addView(Ui.text(ctx, ctx.getString(R.string.smooth_hint), 12f, Ui.MUTED), gap(2))
    col.addView(
        Ui.text(ctx, ctx.getString(R.string.opt_button), 15f, Ui.ACCENT, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(ctx, 12), dp(ctx, 10), dp(ctx, 12), dp(ctx, 10))
            background = Ui.round(Ui.CHIP, dp(ctx, 12).toFloat())
            setOnClickListener {
                if (optFrame != null) smartOptimize(ctx, optFrame) { autoOff(); ControlsBus.sync?.invoke(); onApply() }
                else {
                    val changed = Optimize.run()
                    if (changed.isNotEmpty()) {
                        autoOff()
                        Cfg.save(ctx)
                        ControlsBus.sync?.invoke() // (syncAll and refreshUser are declared further down)
                        onApply()
                    }
                    AlertDialog.Builder(ctx)
                        .setTitle(R.string.opt_button)
                        .setMessage(
                            if (changed.isEmpty()) ctx.getString(R.string.opt_none)
                            else ctx.getString(R.string.opt_done) + "\n\n" + changed.joinToString("\n") { "• " + ctx.getString(it) }
                        )
                        .setPositiveButton(android.R.string.ok, null).show()
                }
            }
        },
        gap(10)
    )
    col.addView(Ui.text(ctx, ctx.getString(R.string.opt_hint), 12f, Ui.MUTED), gap(2))
    // ---- sound sync (player): the sound is a little ahead of / behind the picture; the same setting as the "..." menu, finer (+-2.5 s in 50 ms steps)
    var soundBarRef: SeekBar? = null
    if (inPlayer) {
        col.addView(Ui.text(ctx, ctx.getString(R.string.vo_head_sound), 12f, Ui.ACCENT, true), gap(22))
        val soundLabel = Ui.text(ctx, "", 14f)
        fun soundText() { soundLabel.text = ctx.getString(R.string.vo_sound_fmt, String.format(java.util.Locale.US, "%+.2f s", AudioCfg.syncMs / 1000f)) }
        val soundBar = SeekBar(ctx).apply {
            max = 100
            progress = (AudioCfg.syncMs / 50 + 50).coerceIn(0, 100)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    if (fromUser) AudioCfg.syncMs = (p - 50) * 50
                    soundText()
                }

                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        soundText()
        soundBarRef = soundBar
        col.addView(soundLabel, gap(8))
        col.addView(soundBar, gap(2))
        col.addView(Ui.text(ctx, ctx.getString(R.string.vo_sound_hint), 12f, Ui.MUTED), gap(2))
    }
    col.addView(
        Ui.text(ctx, ctx.getString(R.string.vo_reset), 13f, Ui.ACCENT, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(ctx, 12), 0, dp(ctx, 4))
            setOnClickListener {
                onUserEdited()
                Cfg.deint = 0
                paintDeint()
                autoCropSw.isChecked = false
                cleanAutoSw.isChecked = false
                smoothSw.isChecked = false
                soundBarRef?.let { AudioCfg.syncMs = 0; it.progress = 50 }
                Cfg.save(ctx)
                onApply()
            }
        },
        gap(10)
    )
    fun toneRefresh() {
        if (cleanAutoSw.isChecked != Cfg.cleanAuto) cleanAutoSw.isChecked = Cfg.cleanAuto
        if (smoothSw.isChecked != Cfg.smoothLive) smoothSw.isChecked = Cfg.smoothLive
        if (autoCropSw.isChecked != Cfg.autoCrop) autoCropSw.isChecked = Cfg.autoCrop
        soundBarRef?.let { val v = (AudioCfg.syncMs / 50 + 50).coerceIn(0, 100); if (it.progress != v) it.progress = v }
        for ((i, r) in toneRows.withIndex()) {
            toneBars[i].progress = toneProgress(r)
            toneLabels[i].text = ctx.getString(r.fmt, toneShown(r, toneBars[i].progress))
        }
        paintDeint()
    }

    var upRefresh: () -> Unit = {}
    val gSpd = col.childCount
    // ---- Upscaler speed (global GPU tricks; which upscalers they touch is shown for the one in use)
    col.addView(Ui.text(ctx, ctx.getString(R.string.up_title), 15f, Ui.TEXT, true), gap(14))
    val upScope = Ui.text(ctx, "", 12f, Ui.MUTED)
    val upChips = ArrayList<TextView>()
    fun upScopeText(): String {
        val m = Cfg.mode
        val lv = Cfg.upOpt
        val name = ctx.getString(
            when (m) {
                Cfg.MODE_LANCZOS -> R.string.mode_lanczos
                Cfg.MODE_CLEAR -> R.string.mode_clear
                Cfg.MODE_ART -> R.string.mode_art
                Cfg.MODE_PIXEL -> R.string.mode_pixel
                Cfg.MODE_FSR -> R.string.mode_fsr
                Cfg.MODE_NIS -> R.string.mode_nis
                Cfg.MODE_NIS_SOFT -> R.string.mode_nis_soft
                Cfg.MODE_NIS_FAST -> R.string.mode_nis_fast
                Cfg.MODE_NIS_FINE -> R.string.mode_nis_fine
                Cfg.MODE_NIS_MID -> R.string.mode_nis_mid
                Cfg.MODE_NIS_ORIG -> R.string.mode_nis_orig
                Cfg.MODE_SGSR -> R.string.mode_sgsr
                Cfg.MODE_FAST -> R.string.mode_fast
                Cfg.MODE_RAW -> R.string.mode_raw
                else -> R.string.mode_sharpen
            }
        )
        val shader = lv >= 2 && (m == Cfg.MODE_NIS || m == Cfg.MODE_NIS_SOFT)
        val crscLite = lv >= 2 && m == Cfg.MODE_LANCZOS
        val gather = lv >= 1 && (m == Cfg.MODE_NIS_FAST || m == Cfg.MODE_NIS_FINE || m == Cfg.MODE_NIS_MID)
        val edge = lv >= 1 && m == Cfg.MODE_LANCZOS
        val any = lv >= 1 && m != Cfg.MODE_RAW
        return ctx.getString(
            when {
                lv == 0 -> R.string.up_scope_none
                shader -> R.string.up_scope_shader
                crscLite -> R.string.up_scope_crsc
                gather || edge -> R.string.up_scope_some
                any -> R.string.up_scope_hint_only
                else -> R.string.up_scope_none
            }, name
        )
    }
    fun paintUp() {
        upChips.forEachIndexed { i, t ->
            val r = dp(ctx, 12).toFloat()
            if (Cfg.upOpt == i) { t.background = Ui.gradient(r); t.setTextColor(Ui.BG) }
            else { t.background = Ui.round(Ui.CHIP, r); t.setTextColor(Ui.MUTED) }
        }
        upScope.text = upScopeText()
    }
    val upRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
    listOf(R.string.up_0, R.string.up_1, R.string.up_2).forEachIndexed { i, n ->
        val chip = TextView(ctx).apply {
            text = ctx.getString(n)
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(dp(ctx, 6), dp(ctx, 10), dp(ctx, 6), dp(ctx, 10))
            setOnClickListener {
                if (Cfg.upOpt != i) {
                    Cfg.upOpt = i
                    Cfg.save(ctx)
                    paintUp()
                    refreshLoad()
                    onApply()
                }
            }
        }
        upChips.add(chip)
        upRow.addView(chip, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i > 0) marginStart = dp(ctx, 6) })
    }
    col.addView(upRow, gap(6))
    col.addView(Ui.text(ctx, ctx.getString(R.string.up_all_hint), 12f, Ui.MUTED), gap(4))
    col.addView(upScope, gap(2))
    col.addView(
        Ui.text(ctx, ctx.getString(R.string.pt_button), 14f, Ui.ACCENT, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(ctx, 12), dp(ctx, 10), dp(ctx, 12), dp(ctx, 10))
            background = Ui.round(Ui.CHIP, dp(ctx, 12).toFloat())
            setOnClickListener {
                if (PassTimer.running) return@setOnClickListener
                PassTimer.start()
                val btn = this
                var waited = 0
                fun finish() {
                    btn.text = ctx.getString(R.string.pt_button)
                    val shown = PassTimer.partial() ?: ctx.getString(R.string.pt_none)
                    // the real frame time of these settings makes the Load number above a measured one for this phone
                    if (PassTimer.realMedianMs > 0.0 && FxCost.calibrate(ctx, Cfg.section == "video", PassTimer.realMedianMs)) refreshLoad()
                    runCatching {
                        AlertDialog.Builder(ctx).setTitle(R.string.pt_button).setMessage(shown)
                            .setPositiveButton(R.string.pt_copy) { _, _ ->
                                val cm = ctx.getSystemService(android.content.ClipboardManager::class.java)
                                cm?.setPrimaryClip(android.content.ClipData.newPlainText("pass times", shown))
                                Toast.makeText(ctx, R.string.pt_copied, Toast.LENGTH_SHORT).show()
                            }
                            .setNegativeButton(android.R.string.cancel, null).show()
                    }
                }
                lateinit var poll: Runnable
                poll = Runnable {
                    waited += 500
                    if (!PassTimer.running || waited > 40_000) { finish(); return@Runnable }
                    btn.text = if (PassTimer.inPlain) ctx.getString(R.string.pt_plain) else ctx.getString(R.string.pt_running_fmt, PassTimer.round.coerceAtMost(PassTimer.ROUNDS), PassTimer.ROUNDS)
                    btn.postDelayed(poll, 500)
                }
                btn.text = ctx.getString(R.string.pt_running_fmt, 1, PassTimer.ROUNDS)
                btn.postDelayed(poll, 500)
            }
        },
        gap(8)
    )
    col.addView(Ui.text(ctx, ctx.getString(R.string.pt_hint), 12f, Ui.MUTED), gap(2))
    paintUp()
    upRefresh = { paintUp() }

    val gFix = col.childCount
    // ---- Smart fix (white balance, levels, shadow lift measured from the picture)
    val smartFixSw = Switch(ctx).apply {
        text = ctx.getString(R.string.smartfix_switch)
        setTextColor(Ui.TEXT)
        isChecked = Cfg.smartFix
        setOnCheckedChangeListener { v, c ->
            if (v.isPressed) onUserEdited()
            Cfg.smartFix = c
            Cfg.save(ctx)
        }
    }
    col.addView(smartFixSw, gap(12))
    col.addView(Ui.text(ctx, ctx.getString(R.string.smartfix_hint), 12f, Ui.MUTED), gap(2))
    val fixLvLabel = Ui.text(ctx, "", 14f)
    val fixLvBar = SeekBar(ctx).apply {
        max = 100
        progress = (Cfg.fixLevel * 100).roundToInt().coerceIn(0, 100)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                Cfg.fixLevel = p / 100f
                fixLvLabel.text = ctx.getString(R.string.fixlv_fmt, p)
            }

            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) { onUserEdited(); Cfg.save(ctx) }
        })
    }
    fixLvLabel.text = ctx.getString(R.string.fixlv_fmt, fixLvBar.progress)
    col.addView(fixLvLabel, gap(8))
    col.addView(fixLvBar, gap(2))
    val fixSpLabel = Ui.text(ctx, "", 14f)
    val fixSpBar = SeekBar(ctx).apply {
        max = 100
        progress = (Cfg.fixSpeed * 100).roundToInt().coerceIn(0, 100)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                Cfg.fixSpeed = p / 100f
                fixSpLabel.text = ctx.getString(R.string.fixspd_fmt, p)
            }

            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) { onUserEdited(); Cfg.save(ctx) }
        })
    }
    fixSpLabel.text = ctx.getString(R.string.fixspd_fmt, fixSpBar.progress)
    col.addView(fixSpLabel, gap(8))
    col.addView(fixSpBar, gap(2))
    col.addView(Ui.text(ctx, ctx.getString(R.string.fixspd_hint), 12f, Ui.MUTED), gap(2))

    // ---- Clean upscale (denoise -> sharpen -> anti-aliasing -> upscale -> colour restore)
    val cleanUpSw = Switch(ctx).apply {
        text = ctx.getString(R.string.cleanup_switch)
        setTextColor(Ui.TEXT)
        isChecked = Cfg.cleanUp
        setOnCheckedChangeListener { v, c ->
            if (v.isPressed) onUserEdited()
            Cfg.cleanUp = c
            Cfg.save(ctx)
        }
    }
    col.addView(cleanUpSw, gap(12))
    val cleanLvLabel = Ui.text(ctx, "", 14f)
    val cleanNow = Ui.text(ctx, "", 12f, Ui.MUTED)
    // what the chain does at this strength (the formulas of the passes in GlPipeline; "Adapt clean-up to the video size" then scales them for the video)
    fun paintCleanNow() {
        val l = Cfg.cleanLevel
        val dn = maxOf(Cfg.denoise, 0.08f + 0.25f * l)
        val sh = maxOf(Cfg.sharp * 0.6f, 0.15f + 0.8f * l)
        cleanNow.text = ctx.getString(R.string.cleanup_now_fmt, (dn * 100).roundToInt(), (sh * 100).roundToInt(), (0.65f * l * 100).roundToInt())
    }
    val cleanLvBar = SeekBar(ctx).apply {
        max = 100
        progress = (Cfg.cleanLevel * 100).roundToInt().coerceIn(0, 100)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                Cfg.cleanLevel = p / 100f
                cleanLvLabel.text = ctx.getString(R.string.cleanup_lv_fmt, p)
                paintCleanNow()
            }

            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) { onUserEdited(); Cfg.save(ctx) }
        })
    }
    cleanLvLabel.text = ctx.getString(R.string.cleanup_lv_fmt, cleanLvBar.progress)
    col.addView(cleanLvLabel, gap(8))
    col.addView(cleanLvBar, gap(2))
    paintCleanNow()
    col.addView(cleanNow, gap(2))
    col.addView(Ui.text(ctx, ctx.getString(R.string.cleanup_hint), 12f, Ui.MUTED), gap(2))

    // ---- boost
    val boost = Switch(ctx).apply {
        text = ctx.getString(R.string.boost_switch)
        setTextColor(Ui.TEXT)
        isChecked = Cfg.boost
    }
    col.addView(boost, gap(12))

    val gPan = col.childCount
    // ---- layer opacity (screen overlay only): blends the processed layer with the real screen below
    val layerLabel = Ui.text(ctx, "", 14f)
    val layerBar = SeekBar(ctx).apply {
        max = 100
        progress = (Cfg.dim * 100).roundToInt().coerceIn(0, 100)
    }
    layerLabel.text = ctx.getString(R.string.layer_alpha_fmt, layerBar.progress)
    if (!inPlayer) {
        col.addView(layerLabel, gap(14))
        col.addView(layerBar, gap(2))
        col.addView(Ui.text(ctx, ctx.getString(R.string.layer_alpha_hint), 12f, Ui.MUTED), gap(2))
    }
    layerBar.progressTintList = ColorStateList.valueOf(Ui.ACCENT)
    layerBar.thumbTintList = ColorStateList.valueOf(Ui.ACCENT)
    layerBar.progressBackgroundTintList = ColorStateList.valueOf(Ui.STROKE)
    layerBar.setOnTouchListener { _, ev ->
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> onAdjust(true)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> onAdjust(false)
        }
        false
    }
    layerBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            layerLabel.text = ctx.getString(R.string.layer_alpha_fmt, p)
            if (fromUser) {
                Cfg.dim = p / 100f
                OverlayService.instance?.applyLayerAlpha() // live
            }
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) {
            Cfg.dim = s.progress / 100f
            Cfg.save(ctx)
            OverlayService.instance?.applyLayerAlpha()
        }
    })

    // ---- bubble size
    val bubbleSizeLabel = Ui.text(ctx, "", 14f)
    val bubbleSizeBar = SeekBar(ctx).apply {
        max = Cfg.BUBBLE_MAX_DP - Cfg.BUBBLE_MIN_DP
        progress = Cfg.bubbleSizeDp.coerceIn(Cfg.BUBBLE_MIN_DP, Cfg.BUBBLE_MAX_DP) - Cfg.BUBBLE_MIN_DP
    }
    bubbleSizeLabel.text = ctx.getString(R.string.bubble_size_fmt, Cfg.BUBBLE_MIN_DP + bubbleSizeBar.progress)
    // the bubble belongs to the screen layer only: no bubble rows in the video / photo / manga / GIF panels
    if (!inPlayer) {
        col.addView(bubbleSizeLabel, gap(14))
        col.addView(bubbleSizeBar, gap(2))
    }

    // ---- bubble auto-hide
    val autoHide = Switch(ctx).apply {
        text = ctx.getString(R.string.bubble_autohide_switch)
        setTextColor(Ui.TEXT)
        isChecked = Cfg.bubbleSleep
    }
    if (!inPlayer) col.addView(autoHide, gap(12))

    // ---- bubble sleep delay
    val sleepLabel = Ui.text(ctx, "", 14f)
    val sleepBar = SeekBar(ctx).apply {
        max = Cfg.BUBBLE_SLEEP_MAX_SEC - Cfg.BUBBLE_SLEEP_MIN_SEC
        progress = Cfg.bubbleSleepSec.coerceIn(Cfg.BUBBLE_SLEEP_MIN_SEC, Cfg.BUBBLE_SLEEP_MAX_SEC) - Cfg.BUBBLE_SLEEP_MIN_SEC
        alpha = if (Cfg.bubbleSleep) 1f else 0.4f
    }
    sleepLabel.alpha = sleepBar.alpha
    sleepLabel.text = ctx.getString(R.string.bubble_sleep_fmt, Cfg.BUBBLE_SLEEP_MIN_SEC + sleepBar.progress)
    if (!inPlayer) {
        col.addView(sleepLabel, gap(10))
        col.addView(sleepBar, gap(2))
    }

    // ---- how visible the sleeping bubble stays
    val idleLabel = Ui.text(ctx, "", 14f)
    val idleBar = SeekBar(ctx).apply {
        max = 75
        progress = Cfg.bubbleIdleAlpha.coerceIn(15, 90) - 15
        alpha = if (Cfg.bubbleSleep) 1f else 0.4f
    }
    idleLabel.alpha = idleBar.alpha
    idleLabel.text = ctx.getString(R.string.bubble_idle_fmt, 15 + idleBar.progress)
    if (!inPlayer) {
        col.addView(idleLabel, gap(10))
        col.addView(idleBar, gap(2))
    }

    // ---- fade the panel while adjusting
    val fade = Switch(ctx).apply {
        text = ctx.getString(R.string.panel_fade_switch)
        setTextColor(Ui.TEXT)
        isChecked = Cfg.panelFade
    }
    col.addView(fade, gap(12))
    col.addView(Ui.text(ctx, ctx.getString(R.string.panel_fade_hint), 12f, Ui.MUTED), gap(4))
    fade.setOnCheckedChangeListener { _, checked ->
        Cfg.panelFade = checked
        Cfg.save(ctx)
    }
    // how transparent the panel gets while a slider is held (100% = it never dims)
    val fadeLvlLabel = Ui.text(ctx, "", 14f)
    val fadeLvlBar = SeekBar(ctx).apply {
        max = 95
        progress = (Cfg.panelFadeLevel * 100).roundToInt().coerceIn(5, 100) - 5
    }
    fadeLvlLabel.text = ctx.getString(R.string.panel_opacity_fmt, fadeLvlBar.progress + 5)
    col.addView(fadeLvlLabel, gap(10))
    col.addView(fadeLvlBar, gap(2))
    col.addView(Ui.text(ctx, ctx.getString(R.string.panel_opacity_hint), 12f, Ui.MUTED), gap(2))
    fadeLvlBar.progressTintList = ColorStateList.valueOf(Ui.ACCENT)
    fadeLvlBar.thumbTintList = ColorStateList.valueOf(Ui.ACCENT)
    fadeLvlBar.progressBackgroundTintList = ColorStateList.valueOf(Ui.STROKE)
    fadeLvlBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            fadeLvlLabel.text = ctx.getString(R.string.panel_opacity_fmt, p + 5)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) {
            Cfg.panelFadeLevel = (s.progress + 5) / 100f
            Cfg.save(ctx)
        }
    })
    if (inPlayer) {
        val autoClose = Switch(ctx).apply {
            text = ctx.getString(R.string.panel_autoclose_switch)
            setTextColor(Ui.TEXT)
            isChecked = Cfg.panelAutoClose
        }
        col.addView(autoClose, gap(12))
        autoClose.setOnCheckedChangeListener { _, checked ->
            Cfg.panelAutoClose = checked
            Cfg.save(ctx)
        }
    }

    val tint = ColorStateList.valueOf(Ui.ACCENT)
    val track = ColorStateList.valueOf(Ui.STROKE)
    for (b in arrayOf(sharpBar, detailBar, detailSizeBar, protectBar, denoiseBar, chromaBar, debandBar, scaleBar, aaBar, vividBar, contrastBar, bubbleSizeBar, sleepBar, idleBar) + toneBars) {
        b.progressTintList = tint
        b.thumbTintList = tint
        b.progressBackgroundTintList = track
        b.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    if (b !== bubbleSizeBar && b !== sleepBar && b !== idleBar) {
                        if (Cfg.profileType != -1) {
                            Cfg.profileType = -1
                            paintProfiles()
                        }
                        onUserEdited()
                    }
                    onAdjust(true)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> onAdjust(false)
            }
            false
        }
    }

    fun paintPresets() {
        val radius = dp(ctx, 10).toFloat()
        presetChips.forEachIndexed { i, chip ->
            val presetVal = presetDefs[i].second
            chip.isEnabled = true
            chip.alpha = 1f
            if (Cfg.renderPreset == presetVal) {
                chip.background = Ui.gradient(radius)
                chip.setTextColor(Ui.BG)
                chip.setTypeface(null, Typeface.BOLD)
                presetScroll.scrollToChip(chip)
            } else {
                chip.background = Ui.round(Ui.CHIP, radius)
                chip.setTextColor(Ui.MUTED)
                chip.setTypeface(null, Typeface.NORMAL)
            }
        }
    }

    fun paintAa() {
        val radius = dp(ctx, 10).toFloat()
        aaChips.forEachIndexed { i, chip ->
            if (Cfg.aaMode == i) {
                chip.background = Ui.gradient(radius)
                chip.setTextColor(Ui.BG)
                chip.setTypeface(null, Typeface.BOLD)
                aaScroll.scrollToChip(chip)
            } else {
                chip.background = Ui.round(Ui.CHIP, radius)
                chip.setTextColor(Ui.MUTED)
                chip.setTypeface(null, Typeface.NORMAL)
            }
        }
        aaBar.alpha = if (Cfg.aaMode == Cfg.AA_OFF) 0.4f else 1f
        aaLabel.alpha = aaBar.alpha
    }

    fun paint() {
        crscBox.visibility = if (Cfg.mode == Cfg.MODE_LANCZOS) View.VISIBLE else View.GONE
        nisFastBox.visibility = if (Cfg.mode == Cfg.MODE_NIS_FAST || Cfg.mode == Cfg.MODE_NIS_FINE) View.VISIBLE else View.GONE
        nisMidBox.visibility = if (Cfg.mode == Cfg.MODE_NIS_MID) View.VISIBLE else View.GONE
        auraBox.visibility = if (Cfg.mode == Cfg.MODE_NIS || Cfg.mode == Cfg.MODE_NIS_SOFT) View.VISIBLE else View.GONE
        midBox.visibility = if (Cfg.mode == Cfg.MODE_NIS_FAST || Cfg.mode == Cfg.MODE_NIS_MID) View.VISIBLE else View.GONE
        crispBox.visibility = if (Cfg.mode == Cfg.MODE_RAW || Cfg.mode == Cfg.MODE_CLEAR || Cfg.mode == Cfg.MODE_ART) View.GONE else View.VISIBLE
        finePixBox.visibility = if (Cfg.mode == Cfg.MODE_RAW) View.GONE else View.VISIBLE
        pixBox.visibility = if (Cfg.finePixels) View.VISIBLE else View.GONE
        if (finePixSw.isChecked != Cfg.finePixels) finePixSw.isChecked = Cfg.finePixels
        pixBar.progress = (Math.log((Cfg.pixelFactor / Cfg.PIXEL_MIN).toDouble()) / Math.log((Cfg.PIXEL_MAX / Cfg.PIXEL_MIN).toDouble()) * 1000.0).roundToInt().coerceIn(0, pixBar.max)
        val radius = dp(ctx, 12).toFloat()
        chips.forEachIndexed { i, chip ->
            val shown = when (Cfg.mode) { Cfg.MODE_NIS_SOFT -> Cfg.MODE_NIS; Cfg.MODE_NIS_MID -> Cfg.MODE_NIS_FAST; else -> Cfg.mode }
            if (shown == modeOrder[i]) {
                chip.background = Ui.gradient(radius)
                chip.setTextColor(Ui.BG)
                chip.setTypeface(null, Typeface.BOLD)
                modeScroll.scrollToChip(chip)
            } else {
                chip.background = Ui.round(Ui.CHIP, radius)
                chip.setTextColor(Ui.MUTED)
                chip.setTypeface(null, Typeface.NORMAL)
            }
        }
        // The render-resolution controls are always active. In Sharpen mode only values above 100%
        // matter (supersampling); a short note says so.
        scaleHint.text = ctx.getString(if (Cfg.mode == Cfg.MODE_RAW) R.string.scale_raw_hint else R.string.scale_sharpen_hint)
        scaleHint.visibility = if (Cfg.mode == Cfg.MODE_SHARP || Cfg.mode == Cfg.MODE_RAW) android.view.View.VISIBLE else android.view.View.GONE
        paintPresets()
    }
    paint()
    paintAa()

    aaChips.forEachIndexed { i, chip ->
        chip.setOnClickListener {
            onUserEdited()
            Cfg.aaMode = i
            Cfg.save(ctx)
            paintAa()
        }
    }

    aaBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            Cfg.aaStrength = p / 100f
            aaLabel.text = ctx.getString(R.string.aa_strength_fmt, p)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) { onUserEdited(); Cfg.save(ctx) }
    })

    presetChips.forEachIndexed { i, chip ->
        chip.setOnClickListener {
            val presetVal = presetDefs[i].second
            onUserEdited()
            Cfg.renderPreset = presetVal
            if (presetVal != Cfg.PRESET_CUSTOM) {
                val pct = Cfg.pctForPreset(presetVal, nativeH)
                Cfg.scalePct = pct
                scaleBar.progress = (pct - Cfg.SCALE_MIN).coerceIn(0, scaleBar.max)
                scaleLabel.text = scaleText(pct)
            }
            paintPresets()
            Cfg.save(ctx)
            onApply()
        }
    }

    chips.forEachIndexed { i, chip ->
        chip.setOnClickListener {
            onUserEdited()
            Cfg.mode = when (modeOrder[i]) {
                Cfg.MODE_NIS -> if (auraSoft) Cfg.MODE_NIS_SOFT else Cfg.MODE_NIS
                Cfg.MODE_NIS_FAST -> if (fastMid) Cfg.MODE_NIS_MID else Cfg.MODE_NIS_FAST
                else -> modeOrder[i]
            }
            Cfg.save(ctx)
            paint()
            onApply()
        }
    }

    denoiseBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            Cfg.denoise = p / 100f
            denoiseLabel.text = ctx.getString(R.string.denoise_fmt, p)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) { onUserEdited(); Cfg.save(ctx); cleanPresetRow.refresh() }
    })

    chromaBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            Cfg.chromaClean = p / 100f
            chromaLabel.text = ctx.getString(R.string.chroma_fmt, p)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) { onUserEdited(); Cfg.save(ctx); cleanPresetRow.refresh() }
    })

    protectBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            Cfg.sharpProtect = p / 100f
            protectLabel.text = ctx.getString(R.string.protect_fmt, p)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) { onUserEdited(); Cfg.save(ctx) }
    })

    debandBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            Cfg.deband = p / 100f
            debandLabel.text = ctx.getString(R.string.deband_fmt, p)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) { onUserEdited(); Cfg.save(ctx); cleanPresetRow.refresh() }
    })

    detailBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            Cfg.detail = p / 100f
            detailLabel.text = ctx.getString(R.string.detail_fmt, p)
            detailSizeBar.alpha = if (p > 0) 1f else 0.4f
            detailSizeLabel.alpha = detailSizeBar.alpha
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) { onUserEdited(); Cfg.save(ctx) }
    })

    detailSizeBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            Cfg.detailSize = p / 100f
            detailSizeLabel.text = ctx.getString(R.string.detail_size_fmt, p)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) { onUserEdited(); Cfg.save(ctx) }
    })

    sharpBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            Cfg.sharp = p / 100f
            sharpLabel.text = ctx.getString(R.string.sharpness_fmt, p)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) { onUserEdited(); Cfg.save(ctx) }
    })

    scaleBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            if (fromUser && Cfg.renderPreset != Cfg.PRESET_CUSTOM) {
                Cfg.renderPreset = Cfg.PRESET_CUSTOM
                paintPresets()
            }
            scaleLabel.text = scaleText(Cfg.SCALE_MIN + p)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) {
            Cfg.scalePct = Cfg.SCALE_MIN + s.progress
            Cfg.save(ctx)
            onApply()
        }
    })

    vividBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            Cfg.vivid = p / 100f
            vividLabel.text = ctx.getString(R.string.vivid_colors_fmt, p)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) { onUserEdited(); Cfg.save(ctx) }
    })

    contrastBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            Cfg.contrast = (p - 50) / 50f
            contrastLabel.text = ctx.getString(R.string.contrast_fmt, p - 50)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) { onUserEdited(); Cfg.save(ctx) }
    })

    bubbleSizeBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            bubbleSizeLabel.text = ctx.getString(R.string.bubble_size_fmt, Cfg.BUBBLE_MIN_DP + p)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) {
            Cfg.bubbleSizeDp = Cfg.BUBBLE_MIN_DP + s.progress
            Cfg.save(ctx)
            OverlayService.instance?.applyBubbleSize()
        }
    })

    boost.setOnCheckedChangeListener { _, checked ->
        if (boost.isPressed) onUserEdited()
        Cfg.boost = checked
        Cfg.save(ctx)
    }

    autoHide.setOnCheckedChangeListener { _, checked ->
        Cfg.bubbleSleep = checked
        Cfg.save(ctx)
        sleepBar.alpha = if (checked) 1f else 0.4f
        sleepLabel.alpha = sleepBar.alpha
        idleBar.alpha = sleepBar.alpha
        idleLabel.alpha = sleepBar.alpha
        if (checked) OverlayService.instance?.refreshBubbleIdleTimer() else OverlayService.instance?.wakeBubble()
    }

    sleepBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            sleepLabel.text = ctx.getString(R.string.bubble_sleep_fmt, Cfg.BUBBLE_SLEEP_MIN_SEC + p)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) {
            Cfg.bubbleSleepSec = Cfg.BUBBLE_SLEEP_MIN_SEC + s.progress
            Cfg.save(ctx)
        }
    })

    idleBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            idleLabel.text = ctx.getString(R.string.bubble_idle_fmt, 15 + p)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) {
            Cfg.bubbleIdleAlpha = 15 + s.progress
            Cfg.save(ctx)
        }
    })

    val gEnd = col.childCount
    // ---- reset to defaults
    val reset = Ui.text(ctx, ctx.getString(R.string.reset_defaults), 13f, Ui.ACCENT, true).apply {
        gravity = Gravity.CENTER
        setPadding(0, dp(ctx, 10), 0, 0)
    }
    col.addView(reset, gap(16))
    /** Pushes every Cfg value back into the views (used by Reset and by the quick profiles). */
    fun syncAll() {
        upRefresh()
        sharpBar.progress = (Cfg.sharp * 100).roundToInt()
        sharpLabel.text = ctx.getString(R.string.sharpness_fmt, sharpBar.progress)
        scaleBar.progress = (Cfg.scalePct - Cfg.SCALE_MIN).coerceIn(0, scaleBar.max)
        scaleLabel.text = scaleText(Cfg.scalePct)
        detailBar.progress = (Cfg.detail * 100).roundToInt()
        detailLabel.text = ctx.getString(R.string.detail_fmt, detailBar.progress)
        detailSizeBar.progress = (Cfg.detailSize * 100).roundToInt()
        detailSizeLabel.text = ctx.getString(R.string.detail_size_fmt, detailSizeBar.progress)
        detailSizeBar.alpha = if (Cfg.detail > 0f) 1f else 0.4f
        detailSizeLabel.alpha = detailSizeBar.alpha
        denoiseBar.progress = (Cfg.denoise * 100).roundToInt()
        denoiseLabel.text = ctx.getString(R.string.denoise_fmt, denoiseBar.progress)
        debandBar.progress = (Cfg.deband * 100).roundToInt()
        debandLabel.text = ctx.getString(R.string.deband_fmt, debandBar.progress)
        chromaBar.progress = (Cfg.chromaClean * 100).roundToInt()
        chromaLabel.text = ctx.getString(R.string.chroma_fmt, chromaBar.progress)
        protectBar.progress = (Cfg.sharpProtect * 100).roundToInt()
        protectLabel.text = ctx.getString(R.string.protect_fmt, protectBar.progress)
        cleanPresetRow.refresh()
        aaBar.progress = (Cfg.aaStrength * 100).roundToInt()
        aaLabel.text = ctx.getString(R.string.aa_strength_fmt, aaBar.progress)
        vividBar.progress = (Cfg.vivid * 100).roundToInt()
        vividLabel.text = ctx.getString(R.string.vivid_colors_fmt, vividBar.progress)
        contrastBar.progress = ((Cfg.contrast + 1f) * 50f).roundToInt().coerceIn(0, 100)
        contrastLabel.text = ctx.getString(R.string.contrast_fmt, contrastBar.progress - 50)
        toneRefresh()
        boost.isChecked = Cfg.boost
        if (smartFixSw.isChecked != Cfg.smartFix) smartFixSw.isChecked = Cfg.smartFix
        if (cleanUpSw.isChecked != Cfg.cleanUp) cleanUpSw.isChecked = Cfg.cleanUp
        cleanLvBar.progress = (Cfg.cleanLevel * 100).roundToInt().coerceIn(0, 100)
        fixLvBar.progress = (Cfg.fixLevel * 100).roundToInt().coerceIn(0, 100)
        fixSpBar.progress = (Cfg.fixSpeed * 100).roundToInt().coerceIn(0, 100)
        paintCleanNow()
        layerBar.progress = (Cfg.dim * 100).roundToInt().coerceIn(0, 100)
        layerLabel.text = ctx.getString(R.string.layer_alpha_fmt, layerBar.progress)
        bubbleSizeBar.progress = Cfg.bubbleSizeDp - Cfg.BUBBLE_MIN_DP
        bubbleSizeLabel.text = ctx.getString(R.string.bubble_size_fmt, Cfg.bubbleSizeDp)
        autoHide.isChecked = Cfg.bubbleSleep
        sleepBar.progress = Cfg.bubbleSleepSec - Cfg.BUBBLE_SLEEP_MIN_SEC
        sleepLabel.text = ctx.getString(R.string.bubble_sleep_fmt, Cfg.bubbleSleepSec)
        sleepBar.alpha = if (Cfg.bubbleSleep) 1f else 0.4f
        sleepLabel.alpha = sleepBar.alpha
        idleBar.progress = Cfg.bubbleIdleAlpha - 15
        idleLabel.text = ctx.getString(R.string.bubble_idle_fmt, Cfg.bubbleIdleAlpha)
        idleBar.alpha = sleepBar.alpha
        idleLabel.alpha = sleepBar.alpha
        // the rows under the mode chips (CRSC Edge quality, NIS levels, variants, crispness) show the settings now in force
        crscQRow.refresh(); crscExactRow.refresh(); midRow.refresh(); nisFastRow.refresh(); nisMidRow.refresh(); auraRow.refresh(); crispRows.refresh()
        paint()
        paintAa()
        paintProfiles()
    }

    // the clean-up row (Off / Light / Normal / Strong) and the reset link of the sharpness and clean-up section
    cleanPresetHook = { i ->
        onUserEdited()
        val p = CLEAN_PRESETS[i.coerceIn(0, CLEAN_PRESETS.size - 1)]
        Cfg.denoise = p[0]
        Cfg.chromaClean = p[1]
        Cfg.deband = p[2]
        Cfg.save(ctx)
        syncAll()
        onApply()
    }
    scReset.setOnClickListener {
        onUserEdited()
        Cfg.sharp = 0.7f
        Cfg.detail = 0f
        Cfg.detailSize = 0.4f
        Cfg.sharpProtect = 0f
        Cfg.denoise = 0f
        Cfg.chromaClean = 0f
        Cfg.deband = 0f
        Cfg.save(ctx)
        syncAll()
        onApply()
    }
    reset.setOnClickListener {
        Cfg.userProfile = null
        Cfg.profileType = -1
        Cfg.profileLevel = 1
        Cfg.profileBudget = Profiles.BALANCED
        Cfg.budgetAuto = false
        Cfg.sharp = 0.7f
        Cfg.mode = Cfg.MODE_SHARP
        Cfg.scalePct = 100
        Cfg.renderPreset = Cfg.PRESET_CUSTOM
        Cfg.detail = 0f
        Cfg.detailSize = 0.4f
        Cfg.denoise = 0f
        Cfg.chromaClean = 0f
        Cfg.sharpProtect = 0f
        Cfg.deband = 0f
        Cfg.aaMode = Cfg.AA_OFF
        Cfg.aaStrength = 0.75f
        Cfg.vivid = 0f
        Cfg.contrast = 0f
        Cfg.shadows = 0f; Cfg.highlights = 0f; Cfg.saturation = 0f; Cfg.warmth = 0f; Cfg.grain = 0f
        Cfg.vignette = 0f; Cfg.fade = 0f
        Cfg.brightness = 0f; Cfg.vibrance = 0f; Cfg.tint = 0f
        Cfg.clarity = 0f; Cfg.antiRing = 0f; Cfg.deint = 0; Cfg.gameLight = 0f
        Cfg.inRes = 0
        Cfg.outRes = 0
        Cfg.midRes = 0
        Cfg.boost = false
        Cfg.layerAlpha = 1f
        Cfg.dim = 0f
        Cfg.bubbleSizeDp = Cfg.BUBBLE_DEFAULT_DP
        Cfg.bubbleSleep = true
        Cfg.bubbleSleepSec = Cfg.BUBBLE_SLEEP_DEFAULT_SEC
        Cfg.bubbleIdleAlpha = 45
        Cfg.save(ctx)
        syncAll()
        refreshUser()
        OverlayService.instance?.applyLayerAlpha()
        OverlayService.instance?.applyBubbleSize()
        OverlayService.instance?.refreshBubbleIdleTimer()
        onApply()
    }

    // Profiles only touch the picture settings (never the bubble ones). The values come from the Profiles tables
    // (content type x strength, separate tables for the player and for the screen overlay). Still starting
    // points: fine-tune afterwards.
    var autoBackedUp = false // one backup per run of quick-profile taps (switching 3 profiles in a row keeps the ORIGINAL)
    fun applyProfile() {
        val type = Cfg.profileType
        if (type < 0) return
        // Hand-made settings are about to be replaced: keep a copy so they can be brought back with one tap.
        if (!autoBackedUp && Cfg.userProfile == null) UserProfiles.saveAuto(ctx)
        autoBackedUp = true
        Cfg.userProfile = null
        refreshUser()
        val ratio = if (inPlayer) sourceScale() else 1f
        // Auto (player only): the more the picture is enlarged, the more cleanup + detail it needs.
        // (smooth: also from how few bits per pixel the file has, when the bit rate is known)
        val quality = if (inPlayer && Cfg.profileLevel >= 3) (autoPick?.invoke()?.quality ?: -1f) else -1f
        val strength = Profiles.resolveStrength(Cfg.profileLevel, inPlayer, ratio, quality)
        Cfg.strengthNow = strength
        val lvl = Math.round(strength).coerceIn(0, 2)
        // budget Auto: picked from the picture (player) or from the measured frame time (screen layer); the pick is stored as the budget
        if (Cfg.budgetAuto) Cfg.profileBudget = BudgetAuto.resolve(inPlayer, autoPick?.invoke()?.budget)
        val v = Profiles.withBudget(Profiles.getBlend(type, strength, inPlayer), Cfg.profileBudget)
        Cfg.mode = Profiles.upscaleMode(inPlayer, ratio, Cfg.profileBudget, type)
        Cfg.crscLevel = Profiles.crscFor(type)
        Cfg.scalePct = 100
        Cfg.renderPreset = Cfg.PRESET_CUSTOM
        Cfg.boost = false
        Cfg.vivid = 0f
        Cfg.sharp = v.sharp
        Cfg.detail = v.detail
        Cfg.detailSize = v.detailSize
        Cfg.denoise = v.denoise
        Cfg.deband = v.deband
        Cfg.aaMode = v.aa
        Cfg.aaStrength = v.aaStr
        Profiles.applyLook(type, lvl)
        // strength and budget also set the sections they belong to (CRSC Edge, anti-ringing, clarity, clean upscale, temporal clean-up)
        Profiles.applyRelated(type, strength, Cfg.profileBudget, inPlayer, ratio)
        Cfg.save(ctx)
        syncAll()
        onApply()
    }
    profileChips.forEachIndexed { i, chip ->
        chip.setOnClickListener {
            autoOff()
            if (Cfg.profileType == -1) autoBackedUp = false
            Cfg.profileType = i
            applyProfile()
        }
    }
    budgetChips.forEachIndexed { i, chip ->
        chip.setOnClickListener {
            autoOff()
            Cfg.budgetAuto = i == 3
            if (i < 3) Cfg.profileBudget = i
            else Cfg.profileBudget = BudgetAuto.resolve(inPlayer, autoPick?.invoke()?.budget)
            if (Cfg.profileType >= 0) applyProfile() else {
                Cfg.save(ctx)
                paintProfiles()
            }
        }
    }
    levelChips.forEachIndexed { i, chip ->
        chip.setOnClickListener {
            autoOff()
            Cfg.profileLevel = i
            if (Cfg.profileType >= 0) applyProfile() else {
                Cfg.save(ctx)
                paintProfiles()
            }
        }
    }

    // ---- my profiles: Save / Load / Update / Delete (logic; the row was added at the top)
    val owner: Context = if (base is Activity) base else ctx
    fun dialog(b: AlertDialog.Builder) {
        val d = b.create()
        if (base !is Activity) d.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        d.show()
    }
    lateinit var rebuildUser: () -> Unit
    fun userLabel(n: String) = if (n == UserProfiles.AUTO) ctx.getString(R.string.uprof_auto) else n
    fun loadUser(n: String) {
        autoOff()
        if (UserProfiles.apply(ctx, n)) {
            syncAll()
            rebuildUser()
            OverlayService.instance?.applyLayerAlpha()
            onApply()
            Toast.makeText(ctx, ctx.getString(R.string.uprof_loaded_fmt, userLabel(n)), Toast.LENGTH_SHORT).show()
        }
    }
    fun saveUser(n: String) {
        val name = UserProfiles.clean(n)
        if (name.isEmpty()) return
        UserProfiles.save(ctx, name)
        Cfg.userProfile = name
        Cfg.save(ctx)
        rebuildUser()
        Toast.makeText(ctx, ctx.getString(R.string.uprof_saved_fmt, name), Toast.LENGTH_SHORT).show()
    }
    fun askSave(default: String) {
        val input = EditText(owner).apply {
            setSingleLine()
            setText(default)
            setSelection(text.length)
            hint = ctx.getString(R.string.uprof_name_hint)
        }
        val box = LinearLayout(owner).apply { setPadding(dp(ctx, 20), dp(ctx, 8), dp(ctx, 20), 0) }
        box.addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val b = AlertDialog.Builder(owner)
            .setTitle(ctx.getString(R.string.uprof_save_title))
            .setView(box)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val n = UserProfiles.clean(input.text.toString())
                if (n.isEmpty()) return@setPositiveButton
                if (UserProfiles.has(ctx, n) && !n.equals(Cfg.userProfile, true)) {
                    dialog(
                        AlertDialog.Builder(owner)
                            .setMessage(ctx.getString(R.string.uprof_overwrite_fmt, n))
                            .setPositiveButton(android.R.string.ok) { _, _ -> saveUser(n) }
                            .setNegativeButton(android.R.string.cancel, null)
                    )
                } else saveUser(n)
            }
            .setNegativeButton(android.R.string.cancel, null)
        dialog(b)
    }
    fun askRename(old: String) {
        val input = EditText(owner).apply {
            setSingleLine()
            setText(old)
            setSelection(text.length)
            hint = ctx.getString(R.string.uprof_name_hint)
        }
        val box = LinearLayout(owner).apply { setPadding(dp(ctx, 20), dp(ctx, 8), dp(ctx, 20), 0) }
        box.addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        dialog(
            AlertDialog.Builder(owner)
                .setTitle(ctx.getString(R.string.uprof_rename_title))
                .setView(box)
                .setPositiveButton(android.R.string.ok) { _, _ ->
                    val nn = UserProfiles.clean(input.text.toString())
                    if (nn.isEmpty() || nn == old) return@setPositiveButton
                    if (UserProfiles.rename(ctx, old, nn)) {
                        if (Cfg.userProfile.equals(old, true)) {
                            Cfg.userProfile = nn
                            Cfg.save(ctx)
                        }
                        rebuildUser()
                        Toast.makeText(ctx, ctx.getString(R.string.uprof_renamed_fmt, nn), Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(ctx, ctx.getString(R.string.uprof_rename_taken), Toast.LENGTH_LONG).show()
                    }
                }
                .setNegativeButton(android.R.string.cancel, null)
        )
    }
    fun userMenu(n: String) {
        val items = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        if (n != UserProfiles.AUTO) {
            items.add(ctx.getString(R.string.uprof_update))
            acts.add { saveUser(n) }
            items.add(ctx.getString(R.string.uprof_rename))
            acts.add { askRename(n) }
        }
        items.add(ctx.getString(R.string.uprof_delete))
        acts.add {
            UserProfiles.delete(ctx, n)
            if (Cfg.userProfile.equals(n, true)) {
                Cfg.userProfile = null
                Cfg.save(ctx)
            }
            rebuildUser()
        }
        dialog(
            AlertDialog.Builder(owner)
                .setTitle(userLabel(n))
                .setItems(items.toTypedArray()) { _, which -> acts[which]() }
                .setNegativeButton(android.R.string.cancel, null)
        )
    }
    rebuildUser = {
        userRow.removeAllViews()
        val radius = dp(ctx, 10).toFloat()
        fun chip(text: String, selected: Boolean, accentOutline: Boolean): TextView = TextView(ctx).apply {
            this.text = text
            textSize = 13f
            gravity = Gravity.CENTER
            minWidth = dp(ctx, 56)
            maxLines = 1
            setPadding(dp(ctx, 14), dp(ctx, 8), dp(ctx, 14), dp(ctx, 8))
            if (selected) {
                background = Ui.gradient(radius)
                setTextColor(Ui.BG)
                setTypeface(null, Typeface.BOLD)
            } else if (accentOutline) {
                background = Ui.round(Ui.CHIP, radius, Ui.OK, dp(ctx, 1))
                setTextColor(Ui.OK)
            } else {
                background = Ui.round(Ui.CHIP, radius)
                setTextColor(Ui.TEXT)
            }
        }
        fun add(v: View) = userRow.addView(
            v,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(ctx, 6) }
        )
        val saveChip = chip("＋  " + ctx.getString(R.string.uprof_save), false, true)
        saveChip.setOnClickListener {
            askSave(Cfg.userProfile?.takeIf { it != UserProfiles.AUTO }
                ?: ctx.getString(R.string.uprof_default_fmt, UserProfiles.names(ctx).count { it != UserProfiles.AUTO } + 1))
        }
        add(saveChip)
        for (n in UserProfiles.names(ctx)) {
            val c = chip(userLabel(n), Cfg.userProfile.equals(n, true), false)
            c.setOnClickListener { loadUser(n) }
            c.setOnLongClickListener { userMenu(n); true }
            add(c)
        }
    }
    onUserEdited = {
        autoOff()
        col.post { lookReconcile() } // after the slider has stored its value: a look that no longer matches is Custom now
        if (Cfg.userProfile != null) {
            Cfg.userProfile = null
            Cfg.save(ctx)
            rebuildUser()
        }
    }
    refreshUser = { rebuildUser() }
    rebuildUser()

    // ---- Auto (logic)
    fun runAuto() {
        val ratio = if (inPlayer) sourceScale() else 1f
        val why: String
        if (inPlayer) {
            val pick = autoPick?.invoke()
            if (pick == null) {
                // nothing is open yet: the next video / photo applies Auto when it opens
                autoWhy.text = ctx.getString(R.string.auto_waiting)
                autoWhy.visibility = View.VISIBLE
                return
            }
            Profiles.applyPick(pick.type, pick.level, pick.budget, true, ratio, pick.quality)
            Auto.applyExtras(pick)
            why = ctx.getString(R.string.auto_picked_fmt, ctx.getString(profileNamesRes[pick.type]), ctx.getString(budgetNamesRes[pick.budget]))
        } else {
            Auto.applyOverlayStep(2)
            OverlayService.instance?.autoReset()
            why = ctx.getString(R.string.auto_picked_overlay)
        }
        Cfg.save(ctx)
        syncAll()
        refreshUser()
        autoWhy.text = why
        autoWhy.visibility = View.VISIBLE
        onApply()
    }
    autoSwitch.setOnCheckedChangeListener { _, on ->
        if (autoSilent) return@setOnCheckedChangeListener
        Cfg.autoMode = on
        Cfg.save(ctx)
        if (on) runAuto() else autoWhy.visibility = View.GONE
    }
    lookApply = {
        autoOff()
        if (lookOff || curLook >= 0) Looks.apply(curLook, lookStrength / 100f) // Custom: the colours are already the user's (restored) ones
        Cfg.save(ctx)
        syncAll()
        refreshUser()
        onApply()
    }
    ControlsBus.sync = {
        lookReconcile() // a profile / Auto changed the colours: it is Custom now (or the section is not Off any more)
        syncAll()
        refreshUser()
        autoSilent = true
        autoSwitch.isChecked = Cfg.autoMode
        autoSilent = false
        if (!Cfg.autoMode) autoWhy.visibility = View.GONE
        else if (inPlayer) ControlsBus.autoNote?.let { autoWhy.text = it; autoWhy.visibility = View.VISIBLE }
    }

    // ---- group the long list into folding sections (the views are only moved, nothing else changes)
    run {
        val starts = intArrayOf(gUp, gSharp, gRes, gAa, gCol, gVid, gSpd, gFix, gPan, gEnd)
        val names = intArrayOf(R.string.fxg_upscale, R.string.fxg_sharp, R.string.fxg_size, R.string.fxg_aa, R.string.fxg_color, R.string.fxg_video, R.string.fxg_speed, R.string.fxg_fix, R.string.fxg_panel)
        val opens = booleanArrayOf(true, true, false, false, false, false, false, false, false)
        val groups = ArrayList<List<View>>()
        for (i in names.indices) groups.add((starts[i] until starts[i + 1]).map { col.getChildAt(it) })
        col.removeViews(gUp, gEnd - gUp)
        var at = gUp
        for (i in names.indices) {
            if (groups[i].isEmpty()) continue
            col.addView(panelGroup(ctx, names[i], opens[i], groups[i]), at++, gap(12))
        }
    }

    return col
}

/** Quick strengths of the clean-up row: Denoise, Colour clean-up, Deband (Off / Light / Normal / Strong). */
private val CLEAN_PRESETS = arrayOf(
    floatArrayOf(0f, 0f, 0f),
    floatArrayOf(0.15f, 0.20f, 0.10f),
    floatArrayOf(0.30f, 0.40f, 0.20f),
    floatArrayOf(0.50f, 0.65f, 0.30f)
)

/** The preset the three sliders are on right now, or -1 (a custom mix: no chip is lit). */
private fun cleanPresetIndex(): Int {
    for (i in CLEAN_PRESETS.indices) {
        val p = CLEAN_PRESETS[i]
        if (Math.abs(Cfg.denoise - p[0]) < 0.02f && Math.abs(Cfg.chromaClean - p[1]) < 0.02f && Math.abs(Cfg.deband - p[2]) < 0.02f) return i
    }
    return -1
}

/** Which folding sections of the picture settings are open (kept while the app runs, so a rebuilt panel looks the same). */
private val openGroups = HashMap<Int, Boolean>()

/** A folding section: a tappable title bar and a body that holds [views]. */
/** "Squares 2.0x finer" / "Squares 2.0x bigger" (below 1x the squares are bigger than a source pixel). */
private fun pixelText(ctx: Context, f: Float): String =
    if (f < 0.995f) ctx.getString(R.string.pixel_fmt_big, 1f / f) else ctx.getString(R.string.pixel_fmt, f)

private fun panelGroup(ctx: Context, titleRes: Int, startOpen: Boolean, views: List<View>): LinearLayout {
    val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    val body = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    for (v in views) body.addView(v)
    val chev = Ui.text(ctx, "", 16f, Ui.ACCENT, true)
    val header = LinearLayout(ctx).apply {
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(ctx, 14), dp(ctx, 12), dp(ctx, 14), dp(ctx, 12))
        background = Ui.round(Ui.CHIP, dp(ctx, 12).toFloat(), Ui.STROKE, dp(ctx, 1))
        addView(Ui.text(ctx, ctx.getString(titleRes), 15f, Ui.TEXT, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        addView(chev)
    }
    fun paint() {
        val open = openGroups[titleRes] ?: startOpen
        body.visibility = if (open) View.VISIBLE else View.GONE
        chev.text = if (open) "\u25BE" else "\u25B8"
    }
    header.setOnClickListener {
        openGroups[titleRes] = !(openGroups[titleRes] ?: startOpen)
        paint()
    }
    paint()
    box.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    box.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(ctx, 2) })
    return box
}

/** A row of chips that scrolls sideways when the labels do not fit; the chosen one is painted like everywhere else in the app. */
/** A row (chips, switch) that is built from the current settings and can be built again, so a profile / Auto / Reset that changed the settings is shown right. */
class Rebuildable(ctx: Context, private val build: () -> View) : FrameLayout(ctx) {
    init { addView(build()) }
    fun refresh() {
        removeAllViews()
        addView(build())
    }
}

fun chipRow(ctx: Context, labels: List<String>, selected: Int, onPick: (Int) -> Unit): View {
    val row = LinearLayout(ctx)
    val views = ArrayList<TextView>()
    fun paint(sel: Int) {
        val r = dp(ctx, 10).toFloat()
        views.forEachIndexed { i, c ->
            if (i == sel) {
                c.background = Ui.gradient(r)
                c.setTextColor(Ui.BG)
            } else {
                c.background = Ui.round(Ui.CHIP, r)
                c.setTextColor(Ui.MUTED)
            }
        }
    }
    labels.forEachIndexed { i, l ->
        val c = TextView(ctx).apply {
            text = l
            textSize = 13f
            gravity = Gravity.CENTER
            maxLines = 1
            minWidth = dp(ctx, 56)
            setPadding(dp(ctx, 12), dp(ctx, 9), dp(ctx, 12), dp(ctx, 9))
            setOnClickListener { paint(i); onPick(i) }
        }
        views.add(c)
        row.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i > 0) marginStart = dp(ctx, 6) })
    }
    paint(selected)
    return ChipScroller(ctx, row)
}


/**
 * "Make settings lighter": takes one real frame ([frame]), lets [SmartOpt] look for lighter settings that give nearly the same picture on this
 * phone, then shows what it found and applies it only when the user agrees.
 */
private fun smartOptimize(ctx: Context, frame: () -> android.graphics.Bitmap?, applied: () -> Unit) {
    val ui = android.os.Handler(android.os.Looper.getMainLooper())
    val cancel = java.util.concurrent.atomic.AtomicBoolean(false)
    val tv = Ui.text(ctx, ctx.getString(R.string.so_working), 14f, Ui.TEXT).apply { setPadding(dp(ctx, 22), dp(ctx, 8), dp(ctx, 22), 0) }
    val dlg = AlertDialog.Builder(ctx).setTitle(R.string.opt_button).setView(tv).setCancelable(false)
        .setNegativeButton(android.R.string.cancel) { _, _ -> cancel.set(true) }.create()
    dlg.show()
    val screenShort = minOf(ctx.resources.displayMetrics.widthPixels, ctx.resources.displayMetrics.heightPixels)
    Thread {
        var res: SmartOpt.Result? = null
        var failed = false
        try {
            val f = frame()
            if (f == null) failed = true
            else {
                res = SmartOpt.run(f, screenShort, { cancel.get() }) { step -> ui.post { tv.text = ctx.getString(R.string.so_working_fmt, step) } }
                f.recycle()
                if (res == null && !cancel.get()) failed = true
            }
        } catch (t: Throwable) {
            failed = true
        }
        ui.post {
            runCatching { dlg.dismiss() }
            if (cancel.get()) return@post
            val r = res
            if (failed || r == null) {
                AlertDialog.Builder(ctx).setTitle(R.string.opt_button).setMessage(R.string.so_failed).setPositiveButton(android.R.string.ok, null).show()
                return@post
            }
            if (!r.changed) {
                AlertDialog.Builder(ctx).setTitle(R.string.opt_button).setMessage(R.string.so_nothing).setPositiveButton(android.R.string.ok, null).show()
                return@post
            }
            val saved = if (r.msBefore > 0) ((r.msBefore - r.msAfter) * 100L / r.msBefore).toInt().coerceIn(0, 99) else 0
            val fpsB = if (r.msBefore > 0) (1000L / r.msBefore).toInt() else 0
            val fpsA = if (r.msAfter > 0) (1000L / r.msAfter).toInt() else 0
            val times = ctx.getString(R.string.so_times_fmt, r.msBefore.toInt(), r.msAfter.toInt(), fpsB, fpsA)
            val lines = r.moves.distinct().joinToString("\n") { "• " + ctx.getString(it) }
            AlertDialog.Builder(ctx).setTitle(R.string.opt_button)
                .setMessage(ctx.getString(R.string.so_result_fmt, saved, String.format(java.util.Locale.US, "%.0f", r.psnr)) + "\n" + times + "\n\n" + lines + "\n\n" + ctx.getString(R.string.so_note))
                .setPositiveButton(R.string.so_apply) { _, _ ->
                    SmartOpt.apply(r)
                    Cfg.save(ctx)
                    applied()
                }
                .setNegativeButton(android.R.string.cancel, null).show()
        }
    }.start()
}
