package app.clearoverlay

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipInputStream
import kotlin.math.max
import kotlin.math.min

/**
 * Offline AI super-resolution on the phone's CPU (LiteRT / TensorFlow Lite).
 *
 * Models are small .tflite files downloaded from inside the app (see [CATALOG]) or added by hand (from storage or a direct
 * link) and kept in the app's private folder. An optional model can still be bundled at assets/models/sr.tflite. Everything runs with no internet.
 * Any float32 image-to-image .tflite with 3 channels that outputs an integer multiple of its input works
 * (input / output in 0..1, NHWC or NCHW). The photo is cut into overlapping tiles that match the model's input
 * size and the results are stitched back together.
 */
object AiSr {
    /** One selectable model. [builtin] = the one bundled in the APK (assets/models/sr.tflite). */
    class Entry(val id: String, val label: String, val builtin: Boolean)

    const val BUILTIN = "@asset"
    private const val ASSET = "models/sr.tflite"
    private const val PAD = 8

    /** XLSR / QuickSRNet are tiny (tens of KB), so the "is this a real model" floor is low. */
    private const val MIN_MODEL_BYTES = 10_000L

    /**
     * Models the app can fetch with one tap (Qualcomm AI Hub, float .tflite zips on a public bucket).
     * All are float32, 3-channel, fixed 128x128 tile input; the upscale factor is read from the model itself.
     * [stars] = rough relative speed on a mid-range CPU (more = faster); quality goes the other way.
     */
    class Cat(val id: String, val label: String, val url: String, val sizeKb: Int, val descRes: Int, val speed: Int)

    private const val QAI = "https://qaihub-public-assets.s3.us-west-2.amazonaws.com/qai-hub-models/models/"
    val CATALOG: List<Cat> = listOf(
        Cat(
            "Real_ESRGAN_x4v3", "Real-ESRGAN General x4v3",
            "https://huggingface.co/qualcomm/Real-ESRGAN-General-x4v3/resolve/1cadd892450d350bfd18e20e490931020063c2be/Real-ESRGAN-General-x4v3.tflite?download=true",
            4880, R.string.cat_realesrgan, 1
        ),
        Cat("XLSR", "XLSR", QAI + "xlsr/releases/v0.64.0/xlsr-tflite-float.zip", 115, R.string.cat_xlsr, 5),
        Cat("QuickSRNet_Small", "QuickSRNet Small", QAI + "quicksrnetsmall/releases/v0.64.0/quicksrnetsmall-tflite-float.zip", 100, R.string.cat_qsr_small, 5),
        Cat("QuickSRNet_Medium", "QuickSRNet Medium", QAI + "quicksrnetmedium/releases/v0.64.0/quicksrnetmedium-tflite-float.zip", 243, R.string.cat_qsr_medium, 4),
        Cat("QuickSRNet_Large", "QuickSRNet Large", QAI + "quicksrnetlarge/releases/v0.64.0/quicksrnetlarge-tflite-float.zip", 400, R.string.cat_qsr_large, 3),
        Cat("SESR_M5", "SESR-M5", QAI + "sesr_m5/releases/v0.59.0/sesr_m5-tflite-float.zip", 1320, R.string.cat_sesr, 3)
    )

    fun isInstalled(ctx: Context, c: Cat): Boolean = File(dir(ctx), c.id + ".tflite").isFile

    /** Downloads (or just selects, when already there) a catalog model. */
    fun installCatalog(ctx: Context, c: Cat, onProgress: (Int) -> Unit): String {
        if (isInstalled(ctx, c)) {
            setActive(ctx, c.id)
            return c.id
        }
        return download(ctx, c.url, c.id, onProgress)
    }

    /** Longest side fed to the model: x4 of this stays within the 4096 px cap used for photos. */
    private const val MAX_IN = 1024

    private fun dir(ctx: Context) = File(ctx.filesDir, "models")
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("crsc", Context.MODE_PRIVATE)

    private fun assetExists(ctx: Context): Boolean =
        runCatching { ctx.assets.open(ASSET).use { true } }.getOrDefault(false)

    /** The bundled model, copied out of the APK once (the interpreter needs a real file). */
    private fun builtinFile(ctx: Context): File {
        val f = File(ctx.filesDir, "builtin_sr.tflite")
        if (!(f.isFile && f.length() > 100_000L)) {
            ctx.assets.open(ASSET).use { ins -> f.outputStream().use { ins.copyTo(it) } }
        }
        return f
    }

    /** All models the user can choose from: the built-in one first, then the ones added by hand. */
    fun list(ctx: Context): List<Entry> {
        val out = ArrayList<Entry>()
        if (assetExists(ctx)) out.add(Entry(BUILTIN, "Real-ESRGAN General x4v3 (built-in)", true))
        dir(ctx).listFiles()
            ?.filter { it.isFile && it.name.endsWith(".tflite") && it.length() > MIN_MODEL_BYTES }
            ?.sortedBy { it.name }
            ?.forEach {
                val id = it.name.removeSuffix(".tflite")
                out.add(Entry(id, id.replace('_', ' '), false))
            }
        return out
    }

    fun hasModel(ctx: Context): Boolean = list(ctx).isNotEmpty()

    fun activeId(ctx: Context): String {
        val l = list(ctx)
        val want = prefs(ctx).getString("ai_model", BUILTIN)
        return l.firstOrNull { it.id == want }?.id ?: l.firstOrNull()?.id ?: BUILTIN
    }

    fun activeLabel(ctx: Context): String {
        val id = activeId(ctx)
        return list(ctx).firstOrNull { it.id == id }?.label ?: "-"
    }

    fun setActive(ctx: Context, id: String) {
        prefs(ctx).edit().putString("ai_model", id).apply()
    }

    fun remove(ctx: Context, id: String) {
        if (id != BUILTIN) File(dir(ctx), "$id.tflite").delete()
    }

    private fun activeFile(ctx: Context): File {
        val id = activeId(ctx)
        return if (id == BUILTIN) builtinFile(ctx) else File(dir(ctx), "$id.tflite")
    }

    private fun safeName(s: String): String {
        val n = s.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_')
        return (if (n.isEmpty()) "model" else n).take(40)
    }

    private fun uniqueId(ctx: Context, base: String): String {
        var id = base
        var i = 2
        while (File(dir(ctx), "$id.tflite").exists()) {
            id = base + "_" + i
            i++
        }
        return id
    }

    /** Adds a model picked from storage. Returns its id (and makes it the active one). */
    fun importModel(ctx: Context, u: Uri, name: String): String {
        dir(ctx).mkdirs()
        val tmp = File(dir(ctx), "import.tmp")
        (ctx.contentResolver.openInputStream(u) ?: error("cannot open")).use { ins ->
            tmp.outputStream().use { ins.copyTo(it) }
        }
        return install(ctx, tmp, safeName(name))
    }

    /** Adds a model from a direct link. [onProgress] gets 0..100. Returns its id (and makes it the active one). */
    fun download(ctx: Context, url: String, forcedName: String? = null, onProgress: (Int) -> Unit): String {
        dir(ctx).mkdirs()
        val tmp = File(dir(ctx), "import.tmp")
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000
        c.readTimeout = 30_000
        c.instanceFollowRedirects = true
        try {
            if (c.responseCode != 200) error("HTTP ${c.responseCode}")
            val total = c.contentLengthLong
            c.inputStream.use { ins ->
                tmp.outputStream().use { os ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        os.write(buf, 0, n)
                        done += n
                        if (total > 0) onProgress((done * 100 / total).toInt().coerceIn(0, 100))
                    }
                }
            }
        } catch (t: Throwable) {
            tmp.delete()
            throw t
        } finally {
            c.disconnect()
        }
        val last = url.substringBefore('?').substringAfterLast('/')
        return install(ctx, tmp, forcedName ?: safeName(last))
    }

    /** Qualcomm ships the .tflite inside a .zip: if the file is a zip, replace it with the first .tflite inside. */
    private fun unzipIfNeeded(f: File) {
        val isZip = f.length() > 4 && f.inputStream().use { it.read() == 0x50 && it.read() == 0x4B }
        if (!isZip) return
        val out = File(f.parentFile, "unzip.tmp")
        try {
            ZipInputStream(f.inputStream().buffered()).use { z ->
                while (true) {
                    val e = z.nextEntry ?: error("no .tflite inside the zip")
                    if (e.isDirectory || !e.name.endsWith(".tflite")) continue
                    var total = 0L
                    out.outputStream().use { os ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = z.read(buf)
                            if (n < 0) break
                            total += n
                            if (total > 200L * 1024 * 1024) error("model too big")
                            os.write(buf, 0, n)
                        }
                    }
                    break
                }
            }
            if (!f.delete() || !out.renameTo(f)) error("cannot unpack model")
        } catch (t: Throwable) {
            out.delete()
            throw t
        }
    }

    private fun install(ctx: Context, tmp: File, base: String): String {
        try {
            unzipIfNeeded(tmp)
            if (tmp.length() < MIN_MODEL_BYTES) error("file too small")
            val ip = Interpreter(tmp, Interpreter.Options().setNumThreads(1))
            try {
                if (ip.getInputTensor(0).dataType() != DataType.FLOAT32) error("model input must be float32")
                if (ip.getInputTensor(0).shape().size != 4) error("model input must be an image (4 dimensions)")
            } finally {
                ip.close()
            }
            val id = uniqueId(ctx, base)
            if (!tmp.renameTo(File(dir(ctx), "$id.tflite"))) error("cannot save model")
            setActive(ctx, id)
            return id
        } catch (t: Throwable) {
            tmp.delete()
            throw t
        }
    }

    /**
     * Upscales [src] with the model. Returns null if [cancel] was set. Long: run it on a worker thread.
     * [onProgress] gets 0..100 after every tile.
     */
    fun upscale(
        ctx: Context, src: Bitmap, onProgress: (Int) -> Unit, cancel: AtomicBoolean,
        maxIn: Int = MAX_IN, maxOutPx: Long = 0L
    ): Bitmap? {
        val opts = Interpreter.Options().setNumThreads(4)
        val interp = Interpreter(activeFile(ctx), opts)
        try {
            var inShape = interp.getInputTensor(0).shape()
            if (inShape.size != 4 || inShape.any { it <= 0 }) {
                interp.resizeInput(0, intArrayOf(1, 128, 128, 3))
                interp.allocateTensors()
                inShape = interp.getInputTensor(0).shape()
            }
            if (interp.getInputTensor(0).dataType() != DataType.FLOAT32) error("model input must be float32")
            val nchw = inShape[1] == 3 && inShape[3] != 3
            val th = if (nchw) inShape[2] else inShape[1]
            val tw = if (nchw) inShape[3] else inShape[2]
            val outShape = interp.getOutputTensor(0).shape()
            if (outShape.size != 4) error("unsupported model output")
            val oh = if (nchw) outShape[2] else outShape[1]
            val ow = if (nchw) outShape[3] else outShape[2]
            val s = max(1, ow / tw)
            if (s * tw != ow || s * th != oh) error("model output is not a whole multiple of its input")
            val coreW = tw - 2 * PAD
            val coreH = th - 2 * PAD
            if (coreW < 8 || coreH < 8) error("model tile too small")

            // limit the input so that the result stays within 4096 px
            val longSide = max(src.width, src.height)
            val limit = max(64, 4096 / s).coerceAtMost(maxIn)
            var f = if (longSide > limit) limit.toFloat() / longSide else 1f
            if (maxOutPx > 0L) {
                // keep the result's pixel count (memory) under the budget
                val outPx = (src.width.toDouble() * s) * (src.height.toDouble() * s)
                if (outPx * f * f > maxOutPx) f = Math.sqrt(maxOutPx / outPx).toFloat()
            }
            val work = if (f < 1f) {
                Bitmap.createScaledBitmap(src, max(1, (src.width * f).toInt()), max(1, (src.height * f).toInt()), true)
            } else src
            val w = work.width
            val h = work.height
            val px = IntArray(w * h)
            work.getPixels(px, 0, w, 0, 0, w, h)
            if (work !== src) work.recycle()

            val result = Bitmap.createBitmap(w * s, h * s, Bitmap.Config.ARGB_8888)
            val inBuf = ByteBuffer.allocateDirect(tw * th * 3 * 4).order(ByteOrder.nativeOrder())
            val outBuf = ByteBuffer.allocateDirect(ow * oh * 3 * 4).order(ByteOrder.nativeOrder())
            val inF = inBuf.asFloatBuffer()
            val tilesX = (w + coreW - 1) / coreW
            val tilesY = (h + coreH - 1) / coreH
            val total = tilesX * tilesY
            var done = 0
            val inPlane = tw * th
            val outPlane = ow * oh
            val k = 1f / 255f

            for (ty in 0 until tilesY) {
                for (tx in 0 until tilesX) {
                    if (cancel.get()) {
                        result.recycle()
                        return null
                    }
                    val x0 = tx * coreW
                    val y0 = ty * coreH
                    for (j in 0 until th) {
                        val sy = (y0 - PAD + j).coerceIn(0, h - 1)
                        for (i in 0 until tw) {
                            val sx = (x0 - PAD + i).coerceIn(0, w - 1)
                            val c = px[sy * w + sx]
                            val r = ((c shr 16) and 0xFF) * k
                            val g = ((c shr 8) and 0xFF) * k
                            val b = (c and 0xFF) * k
                            if (nchw) {
                                val p = j * tw + i
                                inF.put(p, r)
                                inF.put(inPlane + p, g)
                                inF.put(2 * inPlane + p, b)
                            } else {
                                val p = (j * tw + i) * 3
                                inF.put(p, r)
                                inF.put(p + 1, g)
                                inF.put(p + 2, b)
                            }
                        }
                    }
                    inBuf.rewind()
                    outBuf.rewind()
                    interp.run(inBuf, outBuf)
                    outBuf.rewind()
                    val oF = outBuf.asFloatBuffer()

                    val cw = min(coreW, w - x0)
                    val ch = min(coreH, h - y0)
                    val bw = cw * s
                    val bh = ch * s
                    val block = IntArray(bw * bh)
                    for (oy in 0 until bh) {
                        val gy = PAD * s + oy
                        for (ox in 0 until bw) {
                            val gx = PAD * s + ox
                            val r: Float
                            val g: Float
                            val b: Float
                            if (nchw) {
                                val p = gy * ow + gx
                                r = oF.get(p)
                                g = oF.get(outPlane + p)
                                b = oF.get(2 * outPlane + p)
                            } else {
                                val p = (gy * ow + gx) * 3
                                r = oF.get(p)
                                g = oF.get(p + 1)
                                b = oF.get(p + 2)
                            }
                            val ri = (r * 255f + 0.5f).toInt().coerceIn(0, 255)
                            val gi = (g * 255f + 0.5f).toInt().coerceIn(0, 255)
                            val bi = (b * 255f + 0.5f).toInt().coerceIn(0, 255)
                            block[oy * bw + ox] = (0xFF shl 24) or (ri shl 16) or (gi shl 8) or bi
                        }
                    }
                    result.setPixels(block, 0, bw, x0 * s, y0 * s, bw, bh)
                    done++
                    onProgress(done * 100 / total)
                }
            }
            return result
        } finally {
            interp.close()
        }
    }
}
