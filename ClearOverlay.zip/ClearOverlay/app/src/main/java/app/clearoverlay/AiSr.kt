package app.clearoverlay

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.min

/**
 * Offline AI super-resolution on the phone's CPU (LiteRT / TensorFlow Lite).
 *
 * The model is one small .tflite file (default: Real-ESRGAN General x4v3, ~5 MB, BSD-3). It is downloaded once
 * (or picked from storage) into the app's private folder; after that everything runs with no internet.
 * Any float32 image-to-image .tflite with 3 channels that outputs an integer multiple of its input works
 * (input / output in 0..1, NHWC or NCHW). The photo is cut into overlapping tiles that match the model's input
 * size and the results are stitched back together.
 */
object AiSr {
    private const val MODEL_URL =
        "https://huggingface.co/qualcomm/Real-ESRGAN-General-x4v3/resolve/1cadd892450d350bfd18e20e490931020063c2be/Real-ESRGAN-General-x4v3.tflite?download=true"
    private const val PAD = 8

    /** Longest side fed to the model: x4 of this stays within the 4096 px cap used for photos. */
    private const val MAX_IN = 1024

    private fun modelFile(ctx: Context) = File(File(ctx.filesDir, "models"), "sr.tflite")

    private const val ASSET = "models/sr.tflite"

    private fun assetExists(ctx: Context): Boolean =
        runCatching { ctx.assets.open(ASSET).use { true } }.getOrDefault(false)

    /** True if a model is installed or bundled in the APK. */
    fun hasModel(ctx: Context): Boolean =
        modelFile(ctx).let { it.isFile && it.length() > 100_000L } || assetExists(ctx)

    /** Copies the model bundled in the APK to private storage on first use. */
    private fun ensureModel(ctx: Context) {
        val dst = modelFile(ctx)
        if (dst.isFile && dst.length() > 100_000L) return
        dst.parentFile?.mkdirs()
        val tmp = File(dst.parentFile, "sr.tmp")
        ctx.assets.open(ASSET).use { ins -> tmp.outputStream().use { ins.copyTo(it) } }
        installModel(tmp, dst)
    }

    /** Downloads the default model. Returns when finished; throws on failure. [onProgress] gets 0..100. */
    fun download(ctx: Context, onProgress: (Int) -> Unit) {
        val dst = modelFile(ctx)
        dst.parentFile?.mkdirs()
        val tmp = File(dst.parentFile, "sr.tmp")
        val c = URL(MODEL_URL).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000
        c.readTimeout = 30_000
        c.instanceFollowRedirects = true
        try {
            if (c.responseCode != 200) error("HTTP ${c.responseCode}")
            val total = c.contentLengthLong
            c.inputStream.use { ins ->
                tmp.outputStream().use { os ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        os.write(buf, 0, n)
                        done += n
                        if (total > 0) onProgress((done * 100 / total).toInt().coerceIn(0, 100))
                    }
                }
            }
        } finally {
            c.disconnect()
        }
        installModel(tmp, dst)
    }

    /** Copies a user-picked .tflite file in and checks that it loads. */
    fun importModel(ctx: Context, u: Uri) {
        val dst = modelFile(ctx)
        dst.parentFile?.mkdirs()
        val tmp = File(dst.parentFile, "sr.tmp")
        (ctx.contentResolver.openInputStream(u) ?: error("cannot open")).use { ins ->
            tmp.outputStream().use { ins.copyTo(it) }
        }
        installModel(tmp, dst)
    }

    private fun installModel(tmp: File, dst: File) {
        try {
            if (tmp.length() < 100_000L) error("file too small")
            val ip = Interpreter(tmp, Interpreter.Options().setNumThreads(1))
            try {
                val inT = ip.getInputTensor(0)
                if (inT.dataType() != DataType.FLOAT32) error("model input must be float32")
            } finally {
                ip.close()
            }
            dst.delete()
            if (!tmp.renameTo(dst)) error("cannot save model")
        } catch (t: Throwable) {
            tmp.delete()
            throw t
        }
    }

    /**
     * Upscales [src] with the model. Returns null if [cancel] was set. Long: run it on a worker thread.
     * [onProgress] gets 0..100 after every tile.
     */
    fun upscale(ctx: Context, src: Bitmap, onProgress: (Int) -> Unit, cancel: AtomicBoolean): Bitmap? {
        ensureModel(ctx)
        val opts = Interpreter.Options().setNumThreads(4)
        val interp = Interpreter(modelFile(ctx), opts)
        try {
            var inShape = interp.getInputTensor(0).shape()
            if (inShape.size != 4 || inShape.any { it <= 0 }) {
                interp.resizeInput(0, intArrayOf(1, 128, 128, 3))
                interp.allocateTensors()
                inShape = interp.getInputTensor(0).shape()
            }
            if (interp.getInputTensor(0).dataType() != DataType.FLOAT32) error("model input must be float32")
            val nchw = inShape[1] == 3 && inShape[3] != 3
            val th = if (nchw) inShape[2] else inShape[1]
            val tw = if (nchw) inShape[3] else inShape[2]
            val outShape = interp.getOutputTensor(0).shape()
            if (outShape.size != 4) error("unsupported model output")
            val oh = if (nchw) outShape[2] else outShape[1]
            val ow = if (nchw) outShape[3] else outShape[2]
            val s = max(1, ow / tw)
            if (s * tw != ow || s * th != oh) error("model output is not a whole multiple of its input")
            val coreW = tw - 2 * PAD
            val coreH = th - 2 * PAD
            if (coreW < 8 || coreH < 8) error("model tile too small")

            // limit the input so that the result stays within 4096 px
            val longSide = max(src.width, src.height)
            val limit = max(64, 4096 / s).coerceAtMost(MAX_IN)
            val work = if (longSide > limit) {
                val f = limit.toFloat() / longSide
                Bitmap.createScaledBitmap(src, max(1, (src.width * f).toInt()), max(1, (src.height * f).toInt()), true)
            } else src
            val w = work.width
            val h = work.height
            val px = IntArray(w * h)
            work.getPixels(px, 0, w, 0, 0, w, h)
            if (work !== src) work.recycle()

            val result = Bitmap.createBitmap(w * s, h * s, Bitmap.Config.ARGB_8888)
            val inBuf = ByteBuffer.allocateDirect(tw * th * 3 * 4).order(ByteOrder.nativeOrder())
            val outBuf = ByteBuffer.allocateDirect(ow * oh * 3 * 4).order(ByteOrder.nativeOrder())
            val inF = inBuf.asFloatBuffer()
            val tilesX = (w + coreW - 1) / coreW
            val tilesY = (h + coreH - 1) / coreH
            val total = tilesX * tilesY
            var done = 0
            val inPlane = tw * th
            val outPlane = ow * oh
            val k = 1f / 255f

            for (ty in 0 until tilesY) {
                for (tx in 0 until tilesX) {
                    if (cancel.get()) {
                        result.recycle()
                        return null
                    }
                    val x0 = tx * coreW
                    val y0 = ty * coreH
                    for (j in 0 until th) {
                        val sy = (y0 - PAD + j).coerceIn(0, h - 1)
                        for (i in 0 until tw) {
                            val sx = (x0 - PAD + i).coerceIn(0, w - 1)
                            val c = px[sy * w + sx]
                            val r = ((c shr 16) and 0xFF) * k
                            val g = ((c shr 8) and 0xFF) * k
                            val b = (c and 0xFF) * k
                            if (nchw) {
                                val p = j * tw + i
                                inF.put(p, r)
                                inF.put(inPlane + p, g)
                                inF.put(2 * inPlane + p, b)
                            } else {
                                val p = (j * tw + i) * 3
                                inF.put(p, r)
                                inF.put(p + 1, g)
                                inF.put(p + 2, b)
                            }
                        }
                    }
                    inBuf.rewind()
                    outBuf.rewind()
                    interp.run(inBuf, outBuf)
                    outBuf.rewind()
                    val oF = outBuf.asFloatBuffer()

                    val cw = min(coreW, w - x0)
                    val ch = min(coreH, h - y0)
                    val bw = cw * s
                    val bh = ch * s
                    val block = IntArray(bw * bh)
                    for (oy in 0 until bh) {
                        val gy = PAD * s + oy
                        for (ox in 0 until bw) {
                            val gx = PAD * s + ox
                            val r: Float
                            val g: Float
                            val b: Float
                            if (nchw) {
                                val p = gy * ow + gx
                                r = oF.get(p)
                                g = oF.get(outPlane + p)
                                b = oF.get(2 * outPlane + p)
                            } else {
                                val p = (gy * ow + gx) * 3
                                r = oF.get(p)
                                g = oF.get(p + 1)
                                b = oF.get(p + 2)
                            }
                            val ri = (r * 255f + 0.5f).toInt().coerceIn(0, 255)
                            val gi = (g * 255f + 0.5f).toInt().coerceIn(0, 255)
                            val bi = (b * 255f + 0.5f).toInt().coerceIn(0, 255)
                            block[oy * bw + ox] = (0xFF shl 24) or (ri shl 16) or (gi shl 8) or bi
                        }
                    }
                    result.setPixels(block, 0, bw, x0 * s, y0 * s, bw, bh)
                    done++
                    onProgress(done * 100 / total)
                }
            }
            return result
        } finally {
            interp.close()
        }
    }
}
