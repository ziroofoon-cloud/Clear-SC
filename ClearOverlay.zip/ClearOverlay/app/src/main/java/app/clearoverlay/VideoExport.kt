package app.clearoverlay

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.provider.MediaStore
import android.view.Surface
import java.io.File
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.nio.ByteBuffer
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** What to export: the source, the size and the quality tier. */
class ExportJob(
    val id: String,
    val uri: String,
    val name: String,
    /** Short side of the result in pixels (720 or 1080). */
    val targetShort: Int,
    /** 0 fast, 1 medium, 2 high quality. */
    val tier: Int,
    /** Content: false = normal video, true = anime / cartoon. */
    val anime: Boolean,
    /** true = H.265 (smaller file, same look); falls back to H.264 when the phone has no H.265 encoder. */
    val hevc: Boolean = false,
    /** Upscaler: Cfg.MODE_FSR (FSR 1) or Cfg.MODE_SGSR (SGSR 1). */
    val mode: Int = Cfg.MODE_FSR,
    /** -1 = by tier, else 0..1. */
    val sharpOv: Float = -1f,
    val vividOv: Float = 0f,
    /** 0 max speed, 1 balanced, 2 gentle (rests between frames). */
    val pace: Int = 0,
    /** Only this part of the video (microseconds); end 0 = to the end. */
    val rangeStartUs: Long = 0L,
    val rangeEndUs: Long = 0L,
    /** Streaming upscale (see [ExportOpts.stream]). */
    val stream: Boolean = false
)

/** A finished piece of the result: the file plays on its own; [startUs] is where it starts in the whole video. */
class ExportSeg(val file: File, val startUs: Long, val durUs: Long)

/**
 * Offline "upscale a video to a new file": decodes the video with the hardware decoder, runs every frame through the
 * same GL pipeline as the player (denoise / deband / FSR 1 / sharpen ...) and re-encodes it with the hardware encoder.
 * Sound is copied untouched. The result is written in pieces of about a minute ([ExportSeg]) that can be watched at
 * once, and joined into one file at the end.
 *
 * Only the picture is re-encoded, with the frame rate of the source (60 fps stays 60 fps).
 */
class VideoExport(private val ctx: Context, private val job: ExportJob) {

    interface Listener {
        /** [doneUs] of [totalUs] of the video is finished; [speed] = seconds of video per second of work (0 = unknown yet). */
        fun onProgress(doneUs: Long, totalUs: Long, speed: Float)

        fun onSegment(seg: ExportSeg)
    }

    companion object {
        const val SEG_US = 60_000_000L
        /** Streaming: how far ahead of the viewer the work may go, and how long a watched piece is kept. */
        const val STREAM_SEG_US = 8_000_000L

        /** How much of the job with this id is already finished on disk (microseconds), 0 when nothing / not resumable. */
        fun doneUs(ctx: Context, id: String): Long = runCatching {
            val d = File(File(ctx.filesDir, "export"), id)
            val mf = File(d, "job.json")
            if (!mf.exists()) return@runCatching 0L
            val arr = JSONObject(mf.readText()).getJSONArray("segs")
            var end = 0L
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val f = File(d, o.getString("f"))
                if (!f.exists() || f.length() == 0L) break
                end = o.getLong("s") + o.getLong("d")
            }
            end
        }.getOrDefault(0L)

        /** Length of the whole video the job was started with (microseconds), 0 when unknown. */
        fun totalUs(ctx: Context, id: String): Long = runCatching {
            JSONObject(File(File(File(ctx.filesDir, "export"), id), "job.json").readText()).optLong("total")
        }.getOrDefault(0L)

        /** Bytes of the finished pieces on disk. */
        fun bytesSoFar(ctx: Context, id: String): Long =
            File(File(ctx.filesDir, "export"), id).listFiles()?.filter { it.name.endsWith(".mp4") }?.sumOf { it.length() } ?: 0L

        /** Forgets an unfinished job so the next start begins from zero. */
        fun discard(ctx: Context, id: String) {
            runCatching { File(File(ctx.filesDir, "export"), id).deleteRecursively() }
        }

        fun dir(ctx: Context, id: String): File = File(File(ctx.filesDir, "export"), id).also { it.mkdirs() }

        /** Picture settings of a tier. Content: anime uses the anime table (clean flat areas), the rest the low-res video table. */
        /** Bit 8 of the job "mode": frame generation (twice the frame rate). The low byte is the upscaler. */
        const val FG_FLAG = 256

        /** Temporal clean-up level in bits 18-19 of the mode: 0 off, 1 light, 2 strong. */
        fun temporalLevel(mode: Int) = ((mode shr 18) and 3).coerceAtMost(2)

        /** Frames made per source frame: 1 = frame generation off, 2..4. Bits 11-12 of the mode hold (factor - 2); bits 13-14 = search quality. */
        fun fgFactor(mode: Int) = if ((mode and FG_FLAG) != 0) 2 + ((mode shr 11) and 3).coerceAtMost(2) else 1
        /** Motion search quality in bits 13-14: 0 light, 1 normal, 2 high. */
        fun fgQuality(mode: Int) = ((mode shr 13) and 3).coerceAtMost(2)
        fun fgBits(on: Boolean, factor: Int, quality: Int) = if (!on) 0 else FG_FLAG or ((factor.coerceIn(2, 4) - 2) shl 11) or (quality.coerceIn(0, 2) shl 13)

        fun fxFor(tier: Int, anime: Boolean, mode: Int = Cfg.MODE_FSR, sharpOv: Float = -1f, vividOv: Float = 0f): FxSet {
            val type = if (anime) Profiles.ANIME else Profiles.VIDEO
            val level = tier.coerceIn(0, 2) // light / balanced / strong
            val budget = tier.coerceIn(0, 2) // performance / balanced / quality
            val maxTier = tier >= 3 // Maximum: the Best settings plus a second sharpening pass
            val v = Profiles.withBudget(Profiles.get(type, level, true), budget)
            return FxSet(mode and 0xFF, if (sharpOv >= 0f) sharpOv.coerceIn(0f, 1f) else v.sharp, v.detail, v.detailSize, v.denoise, v.deband, v.aa, v.aaStr, boost = maxTier, vivid = vividOv.coerceIn(0f, 1f))
        }

        /** Encoder bit rate for the result size and frame rate: low-res sources compress badly when upscaled, so it is generous. */
        /** Bit 9-10 of the job "mode": file size. 0 normal, 1 small, 2 smallest. */
        fun sizeLevel(mode: Int) = (mode shr 9) and 3

        fun bitrate(w: Int, h: Int, fps: Float, tier: Int, mode: Int = 0): Int {
            val k = floatArrayOf(1f, 0.55f, 0.32f)[sizeLevel(mode).coerceIn(0, 2)]
            val lo = if (k < 1f) 600_000L else 1_500_000L
            return (rawBitrate(w, h, fps, tier) * k).toLong().coerceAtLeast(lo).toInt()
        }

        private fun rawBitrate(w: Int, h: Int, fps: Float, tier: Int): Int {
            val px = w.toLong() * h
            val bpp = floatArrayOf(0.060f, 0.080f, 0.110f, 0.140f)[tier.coerceIn(0, 3)] // bits per pixel per frame
            val f = fps.coerceIn(15f, 60f)
            return (px * bpp * f).toLong().coerceIn(1_500_000L, 20_000_000L).toInt()
        }
    }

    private val segs = ArrayList<ExportSeg>()

    /** Streaming: the viewer is waiting at the end of the piece that is being written, so close it at the next key frame. */
    @Volatile private var closeAsap = false

    /** Length of one piece: a minute for a file, a few seconds when streaming so the viewer gets the first piece quickly. */
    private val segUs = if (job.stream) STREAM_SEG_US else SEG_US

    /** How far ahead of the viewer the work may go (Auto = a bit more when the phone is slower than the video). */
    private fun aheadUs(): Long {
        val s = ctx.getSharedPreferences("crsc", Context.MODE_PRIVATE).getInt("stream_ahead_s", 0)
        if (s > 0) return s * 1_000_000L
        val sp = ExportState.speed
        return if (sp <= 0f) 90_000_000L else (60_000_000L / min(sp, 1f)).toLong().coerceIn(60_000_000L, 300_000_000L)
    }

    /** How long a watched piece is kept (for going back a little). */
    private fun behindUs(): Long {
        val s = ctx.getSharedPreferences("crsc", Context.MODE_PRIVATE).getInt("stream_behind_s", 0)
        return if (s > 0) s * 1_000_000L else 30_000_000L
    }

    // ---- encoder side state ----
    private var enc: MediaCodec? = null
    private var encFmt: MediaFormat? = null
    private var audioFmt: MediaFormat? = null
    private var ax: MediaExtractor? = null
    private var audioDone = true
    private var audioSkipped = false
    private val abuf: ByteBuffer = ByteBuffer.allocate(1 shl 20)
    private val ainfo = MediaCodec.BufferInfo()
    private val vinfo = MediaCodec.BufferInfo()

    private var mux: MediaMuxer? = null
    private var mV = -1
    private var mA = -1
    private var segFile: File? = null
    private var segStart = 0L
    private var lastPts = 0L
    private var segIndex = 0
    private var frameDurUs = 33_333L
    private var metaTotal = 0L
    /** Where the chosen part starts in the whole video (0 = whole video). Pieces are joined from here. */
    private var rangeBase = 0L
    private var metaW = 0
    private var metaH = 0

    /** Remembers the finished pieces on disk, so a job that was cut short (app killed, phone restarted) can go on from there. */
    private fun saveMeta() {
        if (job.stream) return
        runCatching {
            val arr = JSONArray()
            for (s in segs) arr.put(JSONObject().put("f", s.file.name).put("s", s.startUs).put("d", s.durUs))
            val j = JSONObject().put("total", metaTotal).put("w", metaW).put("h", metaH).put("segs", arr)
            File(dir(ctx, job.id), "job.json").writeText(j.toString())
        }
    }

    /** Runs the whole job on the calling (worker) thread. Returns the Uri of the finished file, or null if cancelled. */
    /** True when the last run was stopped on purpose with the finished part saved (see [run]'s stopSave). */
    @Volatile var partial = false

    /** True when the last run was paused: the finished pieces are kept on disk and the job can be continued later. */
    @Volatile var paused = false

    fun run(cancel: AtomicBoolean, l: Listener, stopSave: AtomicBoolean = AtomicBoolean(false), pauseReq: AtomicBoolean = AtomicBoolean(false)): Uri? {
        val srcUri = Uri.parse(job.uri)
        val ex = MediaExtractor()
        var netFile: File? = null
        var dec: MediaCodec? = null
        var gl: GlPipeline? = null
        var encSurface: Surface? = null
        var inSurface: Surface? = null
        try {
            if (srcUri.scheme == Net.SCHEME) {
                // a video on a network server is copied to the phone first (the decoder needs a seekable file)
                netFile = Net.download(ctx, srcUri, { _, _ -> }, { !cancel.get() })
                if (cancel.get()) return null
                ex.setDataSource(netFile.path)
            } else {
                ex.setDataSource(ctx, srcUri, null)
            }
            var vTrack = -1
            var aTrack = -1
            for (i in 0 until ex.trackCount) {
                val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("video/") && vTrack < 0) vTrack = i
                if (mime.startsWith("audio/") && aTrack < 0) aTrack = i
            }
            if (vTrack < 0) throw IOException("no video track")
            val vf = ex.getTrackFormat(vTrack)
            val vMime = vf.getString(MediaFormat.KEY_MIME) ?: throw IOException("unknown video type")
            val w = vf.getInteger(MediaFormat.KEY_WIDTH)
            val h = vf.getInteger(MediaFormat.KEY_HEIGHT)
            val rot = if (vf.containsKey(MediaFormat.KEY_ROTATION)) vf.getInteger(MediaFormat.KEY_ROTATION) else 0
            val dispW = if (rot % 180 == 90) h else w
            val dispH = if (rot % 180 == 90) w else h
            val trackUs = if (vf.containsKey(MediaFormat.KEY_DURATION)) vf.getLong(MediaFormat.KEY_DURATION) else 0L
            // the real length: the last picture of the video track (the stored duration can be wrong, e.g. in videos that
            // were cut or re-muxed by a messenger), so "x of y" and the percentage always match what is really processed
            var lastPtsSeen = 0L
            runCatching {
                ex.selectTrack(vTrack)
                var guard = 0
                while (guard++ < 3_000_000) {
                    val t = ex.sampleTime
                    if (t < 0) break
                    if (t > lastPtsSeen) lastPtsSeen = t
                    if (!ex.advance()) break
                }
                ex.seekTo(0L, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            }
            val totalUs = if (lastPtsSeen > 0L) lastPtsSeen + frameDurUs else trackUs
            val fps = (runCatching { vf.getInteger(MediaFormat.KEY_FRAME_RATE).toFloat() }.getOrNull()
                ?: runCatching { vf.getFloat(MediaFormat.KEY_FRAME_RATE) }.getOrNull() ?: 30f).let { if (it < 5f) 30f else it }
            frameDurUs = (1_000_000f / fps).toLong().coerceIn(4_000L, 200_000L)
            // only a part of the video? (start / end are kept inside the video)
            val rs = job.rangeStartUs.coerceIn(0L, if (totalUs > 0) totalUs else Long.MAX_VALUE)
            val ends = if (job.rangeEndUs > 0L && (totalUs <= 0L || job.rangeEndUs < totalUs)) job.rangeEndUs else Long.MAX_VALUE
            if (ends != Long.MAX_VALUE && ends <= rs) throw IOException("the end of the part is before its start")
            val spanTotal = (if (ends != Long.MAX_VALUE) ends else totalUs) - rs
            rangeBase = rs

            // result size: short side = target, same shape, even numbers
            val k = job.targetShort.toFloat() / min(dispW, dispH)
            val ow = (((dispW * k).roundToInt() + 1) / 2 * 2).coerceIn(64, 4096)
            val oh = (((dispH * k).roundToInt() + 1) / 2 * 2).coerceIn(64, 4096)

            // a job that was cut short before continues after its last finished piece
            metaTotal = totalUs
            metaW = ow
            metaH = oh
            val jd = dir(ctx, job.id)
            if (!job.stream) runCatching {
                val mf = File(jd, "job.json")
                if (mf.exists()) {
                    val j = JSONObject(mf.readText())
                    if (Math.abs(j.optLong("total") - totalUs) < 1000L && j.optInt("w") == ow && j.optInt("h") == oh) {
                        val arr = j.getJSONArray("segs")
                        for (i in 0 until arr.length()) {
                            val o = arr.getJSONObject(i)
                            val f = File(jd, o.getString("f"))
                            if (!f.exists() || f.length() == 0L) break
                            segs.add(ExportSeg(f, o.getLong("s"), o.getLong("d")))
                        }
                    }
                }
            }
            var resumeUs = rs
            if (segs.isNotEmpty()) {
                segIndex = segs.size
                resumeUs = segs.last().startUs + segs.last().durUs
            } else {
                jd.listFiles()?.forEach { it.delete() }
            }

            // sound: copied as it is (compressed samples), into every piece
            if (aTrack >= 0) {
                val a = MediaExtractor()
                if (netFile != null) a.setDataSource(netFile.path) else a.setDataSource(ctx, srcUri, null)
                a.selectTrack(aTrack)
                ax = a
                audioFmt = a.getTrackFormat(aTrack)
                audioDone = false
            }

            // encoder
            var encMime = if (job.hevc) "video/hevc" else "video/avc"
            fun encFormat(high: Boolean) = MediaFormat.createVideoFormat(encMime, ow, oh).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                val br = bitrate(ow, oh, fps * fgFactor(job.mode), job.tier, job.mode)
                setInteger(MediaFormat.KEY_BIT_RATE, if (encMime == "video/hevc") (br * 0.7f).toInt() else br)
                setInteger(MediaFormat.KEY_FRAME_RATE, min(fps * fgFactor(job.mode), 120f).roundToInt())
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
                if (high && encMime == "video/avc") setInteger(MediaFormat.KEY_PROFILE, MediaCodecInfo.CodecProfileLevel.AVCProfileHigh)
            }
            fun makeEnc(): MediaCodec {
                var c = MediaCodec.createEncoderByType(encMime)
                try {
                    c.configure(encFormat(true), null, null, MediaCodec.CONFIGURE_FLAG_ENCODE) // H.264 High profile: better quality per bit
                } catch (t: Throwable) {
                    runCatching { c.release() }
                    c = MediaCodec.createEncoderByType(encMime)
                    c.configure(encFormat(false), null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                }
                return c
            }
            val e = try {
                makeEnc()
            } catch (t: Throwable) {
                if (encMime == "video/hevc" && segs.isEmpty()) {
                    encMime = "video/avc" // no usable H.265 encoder: plain H.264
                    makeEnc()
                } else throw t
            }
            enc = e
            encSurface = e.createInputSurface()
            e.start()

            // GL pipeline: decoder -> [GL: effects] -> encoder
            val g = GlPipeline(encSurface)
            gl = g
            g.recordable = true
            g.exportMode = true
            g.frameGen = (job.mode and FG_FLAG) != 0
            g.temporal = temporalLevel(job.mode)
            g.frameGenN = fgFactor(job.mode)
            g.fgQuality = fgQuality(job.mode)
            g.fx = fxFor(job.tier, job.anime, job.mode, job.sharpOv, job.vividOv)
            val aiLevel = VideoAi.level(job.mode)
            if (aiLevel > 0) {
                val aiId = VideoAi.modelFor(ctx, aiLevel) ?: throw IOException("no AI model is installed for this level")
                g.aiHook = { bmp ->
                    val small = VideoAi.shrink(bmp, aiLevel)
                    try {
                        AiSr.upscale(ctx, small, { }, cancel, modelId = aiId, keep = true)
                    } finally {
                        if (small !== bmp) small.recycle()
                    }
                }
            }
            val halfRate = VideoAi.half(job.mode)
            var frameNo = 0
            val ready = CountDownLatch(1)
            val glErr = java.util.concurrent.atomic.AtomicReference<String?>(null)
            g.onError = { msg ->
                glErr.set(msg)
                ready.countDown()
                g.exportLatch?.countDown()
            }
            g.start(dispW, dispH) { s ->
                inSurface = s
                ready.countDown()
            }
            if (!ready.await(15, TimeUnit.SECONDS) || inSurface == null) throw IOException(glErr.get() ?: "GPU setup timeout")
            glErr.get()?.let { throw IOException(it) }

            // decoder (renders into the GL input surface)
            val d = MediaCodec.createDecoderByType(vMime)
            dec = d
            d.configure(vf, inSurface, null, 0)
            d.start()
            ex.selectTrack(vTrack)
            if (resumeUs > 0) {
                ex.seekTo(resumeUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
                ax?.seekTo(resumeUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
                flushNewSegs(l)
                l.onProgress((resumeUs - rs).coerceAtLeast(0L), spanTotal, 0f)
            }

            val di = MediaCodec.BufferInfo()
            var inputDone = false
            var outDone = false
            var atEnd = false // streaming: the whole video was worked through; wait for the viewer to jump somewhere else
            val t0 = System.nanoTime()
            var lastReport = 0L
            var repAt = 0L
            var repPts = 0L
            var smooth = 0f
            var lastSpeed = 0f
            var lastAlive = System.nanoTime()
            val spanEndUs = if (ends != Long.MAX_VALUE) ends else if (totalUs > 0) totalUs else Long.MAX_VALUE
            if (job.stream) {
                l.onProgress(0L, spanTotal, 0f)
                if (lastPts < rs) lastPts = rs
            }

            /** Lets the encoder hand over the last frames of the piece before it is closed. */
            fun settle() {
                repeat(5) {
                    try {
                        Thread.sleep(40)
                    } catch (ie: InterruptedException) {
                    }
                    drainEncoder(false)
                }
            }

            /** Streaming: the work goes on from [t0] (the viewer jumped, or a finished piece lies ahead). */
            fun jumpTo(t0: Long) {
                val t = t0.coerceIn(rs, spanEndUs)
                settle()
                pumpAudio(lastPts + frameDurUs)
                closeSeg()
                flushNewSegs(l)
                runCatching { d.flush() }
                ex.seekTo(t, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
                if (ax != null) {
                    runCatching { ax?.seekTo(t, MediaExtractor.SEEK_TO_CLOSEST_SYNC) }
                    audioDone = false
                }
                inputDone = false
                outDone = false
                atEnd = false
                closeAsap = false
                resumeUs = t
                lastPts = t
                lastAlive = System.nanoTime()
                gl?.resetHist = true
                runCatching { e.setParameters(android.os.Bundle().apply { putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0) }) }
            }

            /** Streaming: the end of the video (or of the chosen part) is reached: close the last piece and wait. */
            fun enterEnd() {
                settle()
                pumpAudio(lastPts + frameDurUs)
                closeSeg()
                flushNewSegs(l)
                atEnd = true
                inputDone = true
            }
            while (!outDone) {
                if (cancel.get()) return null
                if (pauseReq.get()) {
                    paused = true
                    break
                }
                if (stopSave.get()) {
                    // "stop and save": finish what is done so far; the pieces stay on disk so the job can go on later
                    partial = true
                    break
                }
                if (job.stream) {
                    // streaming: the viewer jumped to a spot that has no finished piece
                    val sr = ExportState.seekReq
                    if (sr >= 0L) {
                        ExportState.seekReq = -1L
                        val covered = mux != null && sr >= segStart && sr <= lastPts + frameDurUs
                        if (covered) {
                            closeAsap = true // the piece being written already covers it: publish it early
                        } else {
                            jumpTo(sr)
                        }
                    }
                    // the viewer is on a finished piece far ahead of the work: go on from the end of that piece
                    val pu = ExportState.playUs
                    if (pu >= 0L && !atEnd && lastPts + segUs < pu) {
                        var t = pu
                        while (true) {
                            val c = segs.firstOrNull { it.startUs <= t && t < it.startUs + it.durUs } ?: break
                            t = c.startUs + c.durUs
                        }
                        jumpTo(t)
                    }
                    if (atEnd) {
                        lastAlive = System.nanoTime()
                        try {
                            Thread.sleep(250)
                        } catch (ie: InterruptedException) {
                            return null
                        }
                        continue
                    }
                    // wait while the work is far ahead of the viewer, and delete what is far away from the viewer
                    if (!streamGate(cancel, pauseReq, rs)) continue
                    lastAlive = System.nanoTime()
                }
                if (System.nanoTime() - lastAlive > 40_000_000_000L) throw IOException("the decoder stopped delivering frames")
                if (!inputDone) {
                    val ii = d.dequeueInputBuffer(2_000)
                    if (ii >= 0) {
                        val ib = d.getInputBuffer(ii) ?: throw IOException("decoder buffer")
                        val n = ex.readSampleData(ib, 0)
                        if (n < 0) {
                            d.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            d.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = d.dequeueOutputBuffer(di, 4_000)
                if (oi >= 0) {
                    lastAlive = System.nanoTime()
                    val eos = (di.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                    val skip = di.size > 0 && di.presentationTimeUs < resumeUs - frameDurUs / 2 // frames before the resume point are already done
                    if (di.size > 0 && di.presentationTimeUs >= ends) {
                        // the end of the chosen part: this frame and the rest are not needed
                        d.releaseOutputBuffer(oi, false)
                        if (job.stream) enterEnd() else outDone = true
                        continue
                    }
                    val drop = di.size > 0 && !skip && halfRate && (frameNo++ and 1) == 1 // half frame rate: every second frame is left out
                    if (di.size > 0 && !skip && !drop) {
                        val ft0 = System.nanoTime()
                        val latch = CountDownLatch(1)
                        g.exportLatch = latch
                        d.releaseOutputBuffer(oi, true)
                        if (!latch.await(if (aiLevel > 0) 900L else 15L, TimeUnit.SECONDS)) throw IOException(glErr.get() ?: "GPU timeout")
                        glErr.get()?.let { throw IOException(it) }
                        drainEncoder(false)
                        val now = System.nanoTime()
                        if (now - lastReport > 700_000_000L) {
                            lastReport = now
                            val el = (now - t0) / 1e9f
                            // speed = video seconds per real second, smoothed over the last half minute or so (a plain average since the start
                            // is thrown off by the first slow frames, the model loading and the pauses), so "time left" stays honest
                            val inst = if (repAt > 0L && now > repAt && di.presentationTimeUs > repPts) (di.presentationTimeUs - repPts) / 1e6f / ((now - repAt) / 1e9f) else 0f
                            repAt = now
                            repPts = di.presentationTimeUs
                            if (inst > 0f) smooth = if (smooth <= 0f) inst else smooth * 0.8f + inst * 0.2f
                            val speed = if (el > 3f) smooth else 0f
                            if (speed > 0f) lastSpeed = speed
                            l.onProgress((di.presentationTimeUs - rs).coerceAtLeast(0L), spanTotal, speed)
                        }
                        // pieces that were just closed
                        flushNewSegs(l)
                        if (job.stream) {
                            // a piece that was finished earlier lies right ahead: do not do it twice
                            val nxt = segs.filter { it.startUs > segStart && it.startUs <= lastPts + frameDurUs && it.startUs + it.durUs > lastPts + frameDurUs }.maxByOrNull { it.startUs + it.durUs }
                            if (nxt != null) jumpTo(nxt.startUs + nxt.durUs)
                        }
                        if (job.pace > 0) {
                            // "balanced" / "gentle": rest between frames so the phone stays cooler
                            val worked = (System.nanoTime() - ft0) / 1_000_000L
                            val rest = (worked * (if (job.pace == 1) 0.6 else 1.5)).toLong().coerceIn(1L, 400L)
                            Thread.sleep(rest)
                        }
                    } else {
                        d.releaseOutputBuffer(oi, false)
                    }
                    if (eos) {
                        if (job.stream) enterEnd() else outDone = true
                    }
                }
            }
            e.signalEndOfInputStream()
            drainEncoder(true)
            pumpAudio(if (partial || paused) lastPts + frameDurUs else ends)
            closeSeg()
            flushNewSegs(l)
            if (paused) return null
            if (job.stream) {
                // nothing is written to the gallery: the viewer plays the pieces, then they are deleted
                l.onProgress(spanTotal, spanTotal, 0f)
                return null
            }
            if (!partial) l.onProgress(spanTotal, spanTotal, 0f)
            if (segs.isEmpty()) throw IOException("nothing was written")
            // remember how fast this phone really is, so the next estimate is better
            // only plain runs teach the estimate: the AI model and frame generation have their own cost and would skew it
            if (!partial && !job.stream && lastSpeed > 0f && spanTotal > 60_000_000L && aiLevel == 0 && fgFactor(job.mode) == 1) {
                ExportInfo.saveMpx(ctx, lastSpeed * fps * ow * oh / 1e6f * ExportInfo.COST[job.tier.coerceIn(0, 3)] * ExportInfo.PACE[job.pace.coerceIn(0, 2)])
            }
            return join(job.name, cancel, partial)
        } finally {
            AiSr.closeCache()
            runCatching { dec?.stop() }
            runCatching { dec?.release() }
            runCatching { enc?.stop() }
            runCatching { enc?.release() }
            runCatching { gl?.release() }
            runCatching { encSurface?.release() }
            runCatching { ex.release() }
            runCatching { ax?.release() }
            runCatching { mux?.release() }
            runCatching { netFile?.delete() }
        }
    }

    // ---- writing pieces ---------------------------------------------------------------------------

    private var reported = 0

    private fun flushNewSegs(l: Listener) {
        while (reported < segs.size) l.onSegment(segs[reported++])
    }

    private fun drainEncoder(eos: Boolean) {
        val e = enc ?: return
        var idle = 0
        while (true) {
            val i = e.dequeueOutputBuffer(vinfo, if (eos) 10_000 else 0)
            when {
                i == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    if (!eos) return
                    if (++idle > 500) return // 5 s without anything
                }
                i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> encFmt = e.outputFormat
                i >= 0 -> {
                    idle = 0
                    val buf = e.getOutputBuffer(i)
                    if (buf != null && vinfo.size > 0 && (vinfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                        writeVideo(buf, vinfo)
                    }
                    val end = (vinfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                    e.releaseOutputBuffer(i, false)
                    if (end) return
                }
            }
        }
    }

    private fun writeVideo(buf: ByteBuffer, info: MediaCodec.BufferInfo) {
        val key = (info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0
        val pts = info.presentationTimeUs
        if (mux == null) {
            if (!key) return // a piece always starts with a key frame
            openSeg(pts)
        } else if (key && (pts - segStart >= segUs || closeAsap)) {
            closeAsap = false
            pumpAudio(pts) // the sound up to here belongs to the piece that ends
            closeSeg()
            openSeg(pts)
        }
        val m = mux ?: return
        buf.position(info.offset)
        buf.limit(info.offset + info.size)
        val bi = MediaCodec.BufferInfo()
        bi.set(info.offset, info.size, max(0L, pts - segStart), info.flags)
        m.writeSampleData(mV, buf, bi)
        lastPts = pts
        pumpAudio(pts)
    }

    private fun openSeg(startUs: Long) {
        val f = File(dir(ctx, job.id), String.format("seg_%04d.mp4", segIndex++))
        f.delete()
        val m = MediaMuxer(f.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        mV = m.addTrack(encFmt ?: throw IOException("no encoder format"))
        mA = -1
        val af = audioFmt
        if (af != null && !audioDone) {
            mA = try {
                m.addTrack(af)
            } catch (t: Throwable) {
                audioDone = true
                audioSkipped = true
                -1
            }
        }
        m.start()
        mux = m
        segFile = f
        segStart = startUs
    }

    /**
     * Streaming: deletes pieces that ended long before the spot being watched, and waits (about half a second at a
     * time) while the finished work is more than the "ahead" setting ahead of that spot. Returns false when the wait
     * was cut short by cancel / pause, so the caller can check them.
     */
    private fun dropSeg(s: ExportSeg) {
        runCatching { s.file.delete() }
        val i = segs.indexOf(s)
        if (i >= 0) {
            segs.removeAt(i)
            if (i < reported) reported-- // keeps the "already reported" counter right, or a new piece could be missed
        }
        ExportState.segs.remove(s)
    }

    private fun streamGate(cancel: AtomicBoolean, pauseReq: AtomicBoolean, rangeStart: Long): Boolean {
        while (true) {
            val pu = ExportState.playUs
            if (pu >= 0L) {
                // far behind the viewer, or far ahead of him (he jumped away): not needed any more
                val far = 2 * aheadUs() + behindUs()
                val old = segs.filter { it.startUs + it.durUs < pu - behindUs() || it.startUs > pu + far }
                for (s in old) dropSeg(s)
            }
            val ref = if (pu >= 0L) pu else rangeStart
            if (lastPts - ref <= aheadUs()) return true
            if (cancel.get() || pauseReq.get() || ExportState.seekReq >= 0L) return false
            try {
                Thread.sleep(400)
            } catch (e: InterruptedException) {
                return false
            }
        }
    }

    private fun closeSeg() {
        val m = mux ?: return
        val f = segFile
        runCatching { m.stop() }
        runCatching { m.release() }
        mux = null
        if (f != null && f.length() > 0) {
            segs.add(ExportSeg(f, segStart, lastPts + frameDurUs - segStart))
            saveMeta()
        }
        segFile = null
    }

    /** Copies the sound samples that start before [untilUs] into the open piece. */
    private fun pumpAudio(untilUs: Long) {
        val a = ax ?: return
        val m = mux ?: return
        if (mA < 0) return
        while (!audioDone) {
            val t = a.sampleTime
            if (t < 0) {
                audioDone = true
                break
            }
            if (t > untilUs) break
            if (t < segStart) {
                a.advance() // sound from before this piece starts (after a jump): not needed
                continue
            }
            abuf.clear()
            val n = a.readSampleData(abuf, 0)
            if (n < 0) {
                audioDone = true
                break
            }
            ainfo.set(0, n, max(0L, t - segStart), a.sampleFlags)
            m.writeSampleData(mA, abuf, ainfo)
            a.advance()
        }
    }

    // ---- joining the pieces into one file in Movies/ClearOverlay --------------------------------------

    /** "_14m00-19m00" for a chosen part, nothing for the whole video. */
    private fun rangeTag(): String {
        if (job.rangeStartUs <= 0L && job.rangeEndUs <= 0L) return ""
        fun t(us: Long): String {
            val s = us / 1_000_000L
            return if (s >= 3600) String.format("%dh%02dm%02d", s / 3600, s % 3600 / 60, s % 60) else String.format("%dm%02d", s / 60, s % 60)
        }
        return "_" + t(job.rangeStartUs) + "-" + (if (job.rangeEndUs > 0L) t(job.rangeEndUs) else "end")
    }

    private fun join(name: String, cancel: AtomicBoolean, partial: Boolean = false): Uri? {
        val res = ctx.contentResolver
        val base = name.substringBeforeLast('.').replace(Regex("[\\\\/:*?\"<>|]"), "_").ifEmpty { "video" }
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, base + "_" + job.targetShort + "p" + rangeTag() + (if (partial) "_partial" else "") + ".mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ClearOverlay")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val out = res.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: throw IOException("cannot create the output file")
        var ok = false
        try {
            res.openFileDescriptor(out, "rw")!!.use { pfd ->
                val mx = MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                try {
                    // tracks from the first piece
                    val probe = MediaExtractor()
                    probe.setDataSource(segs[0].file.path)
                    var pv = -1
                    var pa = -1
                    for (i in 0 until probe.trackCount) {
                        val mime = probe.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
                        if (mime.startsWith("video/") && pv < 0) pv = i
                        if (mime.startsWith("audio/") && pa < 0) pa = i
                    }
                    val oV = mx.addTrack(probe.getTrackFormat(pv))
                    val oA = if (pa >= 0) mx.addTrack(probe.getTrackFormat(pa)) else -1
                    probe.release()
                    mx.start()
                    val buf = ByteBuffer.allocate(2 shl 20)
                    val bi = MediaCodec.BufferInfo()
                    // a chosen part starts at 0 in its own file
                    val joinBase = if (job.rangeStartUs > 0L || job.rangeEndUs > 0L) segs[0].startUs else 0L
                    for (s in segs) {
                        if (cancel.get()) throw IOException("cancelled")
                        val ev = MediaExtractor()
                        val ea = MediaExtractor()
                        try {
                            ev.setDataSource(s.file.path)
                            ea.setDataSource(s.file.path)
                            var tv = -1
                            var ta = -1
                            for (i in 0 until ev.trackCount) {
                                val mime = ev.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
                                if (mime.startsWith("video/") && tv < 0) tv = i
                                if (mime.startsWith("audio/") && ta < 0) ta = i
                            }
                            ev.selectTrack(tv)
                            if (ta >= 0 && oA >= 0) ea.selectTrack(ta)
                            var aLive = ta >= 0 && oA >= 0
                            while (true) {
                                val vt = ev.sampleTime
                                val at = if (aLive) ea.sampleTime else -1L
                                if (vt < 0 && at < 0) break
                                val useA = at >= 0 && (vt < 0 || at < vt)
                                val src = if (useA) ea else ev
                                buf.clear()
                                val n = src.readSampleData(buf, 0)
                                if (n < 0) {
                                    if (useA) aLive = false else break
                                    continue
                                }
                                bi.set(0, n, (src.sampleTime + s.startUs - joinBase).coerceAtLeast(0L), src.sampleFlags)
                                mx.writeSampleData(if (useA) oA else oV, buf, bi)
                                src.advance()
                            }
                        } finally {
                            runCatching { ev.release() }
                            runCatching { ea.release() }
                        }
                    }
                    mx.stop()
                    ok = true
                } finally {
                    runCatching { mx.release() }
                }
            }
        } finally {
            if (ok) {
                val v2 = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                res.update(out, v2, null, null)
            } else {
                runCatching { res.delete(out, null, null) }
            }
        }
        if (audioSkipped) AudioNote.skipped = true
        return if (ok) out else null
    }
}

/** Set when the sound of the last export could not be copied (a sound type the MP4 writer does not take). */
object AudioNote {
    @Volatile var skipped = false
}
