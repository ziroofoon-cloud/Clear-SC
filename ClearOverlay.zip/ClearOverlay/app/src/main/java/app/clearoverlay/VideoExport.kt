package app.clearoverlay

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.provider.MediaStore
import android.view.Surface
import java.io.File
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.nio.ByteBuffer
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** What to export: the source, the size and the quality tier. */
class ExportJob(
    val id: String,
    val uri: String,
    val name: String,
    /** Short side of the result in pixels (720 or 1080). */
    val targetShort: Int,
    /** 0 fast, 1 medium, 2 high quality. */
    val tier: Int,
    /** Content: false = normal video, true = anime / cartoon. */
    val anime: Boolean,
    /** true = H.265 (smaller file, same look); falls back to H.264 when the phone has no H.265 encoder. */
    val hevc: Boolean = false,
    /** Upscaler: Cfg.MODE_FSR (FSR 1) or Cfg.MODE_SGSR (SGSR 1). */
    val mode: Int = Cfg.MODE_FSR,
    /** -1 = by tier, else 0..1. */
    val sharpOv: Float = -1f,
    val vividOv: Float = 0f,
    /** 0 max speed, 1 balanced, 2 gentle (rests between frames). */
    val pace: Int = 0,
    /** Only this part of the video (microseconds); end 0 = to the end. */
    val rangeStartUs: Long = 0L,
    val rangeEndUs: Long = 0L,
    /** Streaming upscale (see [ExportOpts.stream]). */
    val stream: Boolean = false,
    /** The newer picture settings (see [Look.encode]); "" = all off. */
    val look: String = ""
)

/** A finished piece of the result: the file plays on its own; [startUs] is where it starts in the whole video. */
class ExportSeg(val file: File, val startUs: Long, val durUs: Long)

/**
 * Offline "upscale a video to a new file": decodes the video with the hardware decoder, runs every frame through the
 * same GL pipeline as the player (denoise / deband / FSR 1 / sharpen ...) and re-encodes it with the hardware encoder.
 * Sound is copied untouched. The result is written in pieces of about a minute ([ExportSeg]) that can be watched at
 * once, and joined into one file at the end.
 *
 * Only the picture is re-encoded, with the frame rate of the source (60 fps stays 60 fps).
 */
class VideoExport(private val ctx: Context, private val job: ExportJob) {

    interface Listener {
        /** [doneUs] of [totalUs] of the video is finished; [speed] = seconds of video per second of work (0 = unknown yet). */
        fun onProgress(doneUs: Long, totalUs: Long, speed: Float)

        fun onSegment(seg: ExportSeg)
    }

    companion object {
        const val SEG_US = 60_000_000L
        /** Streaming: how far ahead of the viewer the work may go, and how long a watched piece is kept. */
        const val STREAM_SEG_US = 3_000_000L
        /** Streaming: the first piece after a start or a jump is as short as the key-frame spacing allows, so the picture appears at once. */
        const val STREAM_FIRST_US = 1_000_000L

        /** How much of the job with this id is already finished on disk (microseconds), 0 when nothing / not resumable. */
        fun doneUs(ctx: Context, id: String): Long = runCatching {
            val d = File(File(ctx.filesDir, "export"), id)
            val mf = File(d, "job.json")
            if (!mf.exists()) return@runCatching 0L
            val arr = JSONObject(mf.readText()).getJSONArray("segs")
            var end = 0L
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val f = File(d, o.getString("f"))
                if (!f.exists() || f.length() == 0L) break
                end = o.getLong("s") + o.getLong("d")
            }
            end
        }.getOrDefault(0L)

        /** Length of the whole video the job was started with (microseconds), 0 when unknown. */
        fun totalUs(ctx: Context, id: String): Long = runCatching {
            JSONObject(File(File(File(ctx.filesDir, "export"), id), "job.json").readText()).optLong("total")
        }.getOrDefault(0L)

        /** Bytes of the finished pieces on disk. */
        fun bytesSoFar(ctx: Context, id: String): Long =
            File(File(ctx.filesDir, "export"), id).listFiles()?.filter { it.name.endsWith(".mp4") }?.sumOf { it.length() } ?: 0L

        /** Forgets an unfinished job so the next start begins from zero. */
        fun discard(ctx: Context, id: String) {
            runCatching { File(File(ctx.filesDir, "export"), id).deleteRecursively() }
        }

        /**
         * Joins finished pieces (in order) into one MP4 in Movies/ClearOverlay. [joinBase] is subtracted from the piece start times
         * (0 = the times of the whole video). Also used by "save what is ready" of a streaming upscale.
         */
        fun joinSegs(ctx: Context, list: List<ExportSeg>, displayName: String, joinBase: Long, cancel: AtomicBoolean, description: String? = null): Uri? {
            if (list.isEmpty()) return null
            val res = ctx.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
                if (description != null) put(MediaStore.Video.Media.DESCRIPTION, description)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ClearOverlay")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val out = res.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: throw IOException("cannot create the output file")
            var ok = false
            try {
                res.openFileDescriptor(out, "rw")!!.use { pfd ->
                    val mx = MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                    try {
                        // tracks from the first piece
                        val probe = MediaExtractor()
                        probe.setDataSource(list[0].file.path)
                        var pv = -1
                        var pa = -1
                        for (i in 0 until probe.trackCount) {
                            val mime = probe.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
                            if (mime.startsWith("video/") && pv < 0) pv = i
                            if (mime.startsWith("audio/") && pa < 0) pa = i
                        }
                        val oV = mx.addTrack(probe.getTrackFormat(pv))
                        val oA = if (pa >= 0) mx.addTrack(probe.getTrackFormat(pa)) else -1
                        probe.release()
                        mx.start()
                        val buf = ByteBuffer.allocate(2 shl 20)
                        val bi = MediaCodec.BufferInfo()
                        for (s in list) {
                            if (cancel.get()) throw IOException("cancelled")
                            val ev = MediaExtractor()
                            val ea = MediaExtractor()
                            try {
                                ev.setDataSource(s.file.path)
                                ea.setDataSource(s.file.path)
                                var tv = -1
                                var ta = -1
                                for (i in 0 until ev.trackCount) {
                                    val mime = ev.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
                                    if (mime.startsWith("video/") && tv < 0) tv = i
                                    if (mime.startsWith("audio/") && ta < 0) ta = i
                                }
                                ev.selectTrack(tv)
                                if (ta >= 0 && oA >= 0) ea.selectTrack(ta)
                                var aLive = ta >= 0 && oA >= 0
                                while (true) {
                                    val vt = ev.sampleTime
                                    val at = if (aLive) ea.sampleTime else -1L
                                    if (vt < 0 && at < 0) break
                                    val useA = at >= 0 && (vt < 0 || at < vt)
                                    val src = if (useA) ea else ev
                                    buf.clear()
                                    val n = src.readSampleData(buf, 0)
                                    if (n < 0) {
                                        if (useA) aLive = false else break
                                        continue
                                    }
                                    bi.set(0, n, (src.sampleTime + s.startUs - joinBase).coerceAtLeast(0L), src.sampleFlags)
                                    mx.writeSampleData(if (useA) oA else oV, buf, bi)
                                    src.advance()
                                }
                            } finally {
                                runCatching { ev.release() }
                                runCatching { ea.release() }
                            }
                        }
                        mx.stop()
                        ok = true
                    } finally {
                        runCatching { mx.release() }
                    }
                }
            } finally {
                if (ok) {
                    val v2 = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                    res.update(out, v2, null, null)
                } else {
                    runCatching { res.delete(out, null, null) }
                }
            }
            return if (ok) out else null
        }

        fun dir(ctx: Context, id: String): File = File(File(ctx.filesDir, "export"), id).also { it.mkdirs() }

        /** Marker file inside the folder of a streaming ("Watch now") job: its pieces are temporary and never continued. */
        const val STREAM_MARK = "stream.tmp"

        /**
         * Folders of streaming jobs that were not cleaned up (the app was killed, the phone restarted, the player crashed).
         * Their pieces are only temporary, so they are removed at once instead of waiting a week like unfinished file exports.
         */
        fun cleanStreamLeftovers(ctx: Context) {
            runCatching {
                File(ctx.filesDir, "export").listFiles()?.forEach { d ->
                    if (d.isDirectory && File(d, STREAM_MARK).exists()) d.deleteRecursively()
                }
            }
        }

        /** Picture settings of a tier. Content: anime uses the anime table (clean flat areas), the rest the low-res video table. */
        /** Bit 8 of the job "mode": frame generation (twice the frame rate). The low byte is the upscaler. */
        const val FG_FLAG = 256
        /** Bit 26 of the job "mode": Smart fix (white balance / levels / shadow lift measured from the frames). */
        const val SMARTFIX_FLAG = 1 shl 26

        /** Temporal clean-up level in bits 18-19 of the mode: 0 off, 1 light, 2 strong. */
        fun temporalLevel(mode: Int) = ((mode shr 18) and 3).coerceAtMost(2)

        /** Frames made per source frame: 1 = frame generation off, 2..4. Bits 11-12 of the mode hold (factor - 2); bits 13-14 = search quality. */
        fun fgFactor(mode: Int) = if ((mode and FG_FLAG) != 0) 2 + ((mode shr 11) and 3).coerceAtMost(2) else 1
        /** Motion search quality in bits 13-14: 0 light, 1 normal, 2 high. */
        /** 0 light, 1 normal, 2 high, 3 very light */
        fun fgQuality(mode: Int) = (mode shr 13) and 3
        fun fgBits(on: Boolean, factor: Int, quality: Int) = if (!on) 0 else FG_FLAG or ((factor.coerceIn(2, 4) - 2) shl 11) or (quality.coerceIn(0, 3) shl 13)

        fun fxFor(tier: Int, anime: Boolean, mode: Int = Cfg.MODE_FSR, sharpOv: Float = -1f, vividOv: Float = 0f, look: String = ""): FxSet {
            val lk = Look.decode(look)
            if (lk.live) {
                // "Smooth live": exactly the player's settings, not the ones a quality tier would pick
                return FxSet(mode and 0xFF, lk.lSharp, lk.lDetail, lk.lDetailSize, lk.lDenoise, lk.lDeband, lk.lAaMode, lk.lAaStr, boost = lk.lBoost, vivid = lk.lVivid, smartFix = (mode and SMARTFIX_FLAG) != 0,
                    contrast = lk.contrast, shadows = lk.shadows, highlights = lk.highlights, saturation = lk.saturation, warmth = lk.warmth, grain = lk.grain, clarity = lk.clarity, antiRing = lk.antiRing, deint = lk.deint, cleanUp = lk.lClean, cleanLevel = lk.lCleanLevel)
            }
            val type = if (anime) Profiles.ANIME else Profiles.VIDEO
            val level = tier.coerceIn(0, 2) // light / balanced / strong
            val budget = tier.coerceIn(0, 2) // performance / balanced / quality
            val maxTier = tier >= 3 // Maximum: the Best settings plus a second sharpening pass
            val v = Profiles.withBudget(Profiles.get(type, level, true), budget)
            return FxSet(mode and 0xFF, if (sharpOv >= 0f) sharpOv.coerceIn(0f, 1f) else v.sharp, v.detail, v.detailSize, v.denoise, v.deband, v.aa, v.aaStr, boost = maxTier, vivid = vividOv.coerceIn(0f, 1f), smartFix = (mode and SMARTFIX_FLAG) != 0,
                contrast = lk.contrast, shadows = lk.shadows, highlights = lk.highlights, saturation = lk.saturation, warmth = lk.warmth, grain = lk.grain, clarity = lk.clarity, antiRing = lk.antiRing, deint = lk.deint)
        }

        /** Encoder bit rate for the result size and frame rate: low-res sources compress badly when upscaled, so it is generous. */
        /** Bit 9-10 of the job "mode": file size. 0 normal, 1 small, 2 smallest. */
        fun sizeLevel(mode: Int) = (mode shr 9) and 3

        fun bitrate(w: Int, h: Int, fps: Float, tier: Int, mode: Int = 0): Int {
            val k = floatArrayOf(1f, 0.55f, 0.32f)[sizeLevel(mode).coerceIn(0, 2)]
            val lo = if (k < 1f) 600_000L else 1_500_000L
            return (rawBitrate(w, h, fps, tier) * k).toLong().coerceAtLeast(lo).toInt()
        }

        private fun rawBitrate(w: Int, h: Int, fps: Float, tier: Int): Int {
            val px = w.toLong() * h
            val bpp = floatArrayOf(0.060f, 0.080f, 0.110f, 0.140f)[tier.coerceIn(0, 3)] // bits per pixel per frame
            val f = fps.coerceIn(15f, 60f)
            return (px * bpp * f).toLong().coerceIn(1_500_000L, 20_000_000L).toInt()
        }
    }

    private val segs = ArrayList<ExportSeg>()

    /** Streaming: the viewer is waiting at the end of the piece that is being written, so close it at the next key frame. */
    @Volatile private var closeAsap = false

    /** Length of one piece: a minute for a file, a few seconds when streaming so the viewer gets the first piece quickly. */
    private val segUs = if (job.stream) STREAM_SEG_US else SEG_US

    /** Streaming: nanoseconds the work spent waiting in [streamGate] since the last speed report (not counted as work). */
    @Volatile private var gateWaitNs = 0L

    /** Streaming: true until the first piece after a start / jump is closed (that one is kept short). */
    @Volatile private var freshRun = job.stream

    /** How far ahead of the viewer the work may go (Auto = a bit more when the phone is slower than the video). */
    private fun aheadUs(): Long {
        val s = ctx.getSharedPreferences("crsc", Context.MODE_PRIVATE).getInt("stream_ahead_s", 0)
        // the phone is nearly full: do not run far ahead (the pieces would eat the last free space)
        val lowSpace = runCatching { ctx.filesDir.usableSpace < 400L * 1024 * 1024 }.getOrDefault(false)
        if (s > 0) return (if (lowSpace) min(s, 30) else s) * 1_000_000L
        if (lowSpace) return 30_000_000L
        val sp = ExportState.speed
        return if (sp <= 0f) 90_000_000L else (60_000_000L / min(sp, 1f)).toLong().coerceIn(60_000_000L, 300_000_000L)
    }

    /** How long a watched piece is kept (for going back a little). */
    private fun behindUs(): Long {
        val s = ctx.getSharedPreferences("crsc", Context.MODE_PRIVATE).getInt("stream_behind_s", 0)
        return if (s > 0) s * 1_000_000L else 10_000_000L
    }

    // ---- encoder side state ----
    private var enc: MediaCodec? = null
    private var encFmt: MediaFormat? = null
    private var audioFmt: MediaFormat? = null
    private var ax: MediaExtractor? = null
    private var audioDone = true
    private var audioSkipped = false
    private val abuf: ByteBuffer = ByteBuffer.allocate(1 shl 20)
    private val ainfo = MediaCodec.BufferInfo()
    private val vinfo = MediaCodec.BufferInfo()

    private var mux: MediaMuxer? = null
    private var mV = -1
    private var mA = -1
    private var segFile: File? = null
    private var segStart = 0L
    private var lastPts = 0L
    private var segIndex = 0
    private var frameDurUs = 33_333L
    private var metaTotal = 0L
    /** Where the chosen part starts in the whole video (0 = whole video). Pieces are joined from here. */
    private var rangeBase = 0L
    private var metaW = 0
    private var metaH = 0

    /** Remembers the finished pieces on disk, so a job that was cut short (app killed, phone restarted) can go on from there. */
    private fun saveMeta() {
        if (job.stream) return
        runCatching {
            val arr = JSONArray()
            for (s in segs) arr.put(JSONObject().put("f", s.file.name).put("s", s.startUs).put("d", s.durUs))
            val j = JSONObject().put("total", metaTotal).put("w", metaW).put("h", metaH).put("segs", arr)
            File(dir(ctx, job.id), "job.json").writeText(j.toString())
        }
    }

    /** Runs the whole job on the calling (worker) thread. Returns the Uri of the finished file, or null if cancelled. */
    /** True when the last run was stopped on purpose with the finished part saved (see [run]'s stopSave). */
    @Volatile var partial = false

    /** True when the last run was paused: the finished pieces are kept on disk and the job can be continued later. */
    @Volatile var paused = false

    fun run(cancel: AtomicBoolean, l: Listener, stopSave: AtomicBoolean = AtomicBoolean(false), pauseReq: AtomicBoolean = AtomicBoolean(false)): Uri? {
        val srcUri = Uri.parse(job.uri)
        val ex = MediaExtractor()
        var netFile: File? = null
        var dec: MediaCodec? = null
        var gl: GlPipeline? = null
        var encSurface: Surface? = null
        var inSurface: Surface? = null
        try {
            if (srcUri.scheme == Net.SCHEME) {
                // a video on a network server is copied to the phone first (the decoder needs a seekable file)
                netFile = Net.download(ctx, srcUri, { _, _ -> }, { !cancel.get() })
                if (cancel.get()) return null
                ex.setDataSource(netFile.path)
            } else {
                ex.setDataSource(ctx, srcUri, null)
            }
            var vTrack = -1
            var aTrack = -1
            for (i in 0 until ex.trackCount) {
                val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("video/") && vTrack < 0) vTrack = i
                if (mime.startsWith("audio/") && aTrack < 0) aTrack = i
            }
            if (vTrack < 0) throw IOException("no video track")
            val vf = ex.getTrackFormat(vTrack)
            val vMime = vf.getString(MediaFormat.KEY_MIME) ?: throw IOException("unknown video type")
            val w = vf.getInteger(MediaFormat.KEY_WIDTH)
            val h = vf.getInteger(MediaFormat.KEY_HEIGHT)
            val rot = if (vf.containsKey(MediaFormat.KEY_ROTATION)) vf.getInteger(MediaFormat.KEY_ROTATION) else 0
            val dispW = if (rot % 180 == 90) h else w
            val dispH = if (rot % 180 == 90) w else h
            val trackUs = if (vf.containsKey(MediaFormat.KEY_DURATION)) vf.getLong(MediaFormat.KEY_DURATION) else 0L
            // the real length: the last picture of the video track (the stored duration can be wrong, e.g. in videos that
            // were cut or re-muxed by a messenger), so "x of y" and the percentage always match what is really processed
            var lastPtsSeen = 0L
            runCatching {
                ex.selectTrack(vTrack)
                var guard = 0
                while (guard++ < 3_000_000) {
                    val t = ex.sampleTime
                    if (t < 0) break
                    if (t > lastPtsSeen) lastPtsSeen = t
                    if (!ex.advance()) break
                }
                ex.seekTo(0L, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            }
            val totalUs = if (lastPtsSeen > 0L) lastPtsSeen + frameDurUs else trackUs
            val fps = (runCatching { vf.getInteger(MediaFormat.KEY_FRAME_RATE).toFloat() }.getOrNull()
                ?: runCatching { vf.getFloat(MediaFormat.KEY_FRAME_RATE) }.getOrNull() ?: 30f).let { if (it < 5f) 30f else it }
            frameDurUs = (1_000_000f / fps).toLong().coerceIn(4_000L, 200_000L)
            // only a part of the video? (start / end are kept inside the video)
            val rs = job.rangeStartUs.coerceIn(0L, if (totalUs > 0) totalUs else Long.MAX_VALUE)
            val ends = if (job.rangeEndUs > 0L && (totalUs <= 0L || job.rangeEndUs < totalUs)) job.rangeEndUs else Long.MAX_VALUE
            if (ends != Long.MAX_VALUE && ends <= rs) throw IOException("the end of the part is before its start")
            val spanTotal = (if (ends != Long.MAX_VALUE) ends else totalUs) - rs
            rangeBase = rs

            // "Auto" picture look: chosen once from a few frames and kept in the job folder, so a continued job gets the same look
            var lookTxt = job.look
            if (Look.decode(lookTxt).auto) {
                val lf = File(dir(ctx, job.id), "look.txt")
                val saved = runCatching { lf.readText() }.getOrNull()
                lookTxt = if (saved != null) saved else {
                    val end = if (ends != Long.MAX_VALUE) ends else totalUs
                    val netPath = netFile?.path
                    val found = LookAuto.analyze(rs, end) { mr -> if (netPath != null) mr.setDataSource(netPath) else mr.setDataSource(ctx, srcUri) }.encode()
                    runCatching { lf.writeText(found) }
                    found
                }
            }
            // "Cut black bars": measured once from a few frames and kept in the job folder, so a continued job uses the same crop
            // (left, bottom, right, top as fractions of the picture)
            var bars = FloatArray(4)
            if (Look.decode(lookTxt).cutBars) {
                val bf = File(dir(ctx, job.id), "bars.txt")
                val saved = runCatching { bf.readText().split(',').map { it.trim().toFloat() }.toFloatArray() }.getOrNull()
                bars = if (saved != null && saved.size == 4) saved else {
                    val end = if (ends != Long.MAX_VALUE) ends else totalUs
                    val netPath = netFile?.path
                    val found = BarScan.detect(rs, end) { mr -> if (netPath != null) mr.setDataSource(netPath) else mr.setDataSource(ctx, srcUri) }
                    runCatching { bf.writeText(found.joinToString(",")) }
                    found
                }
                for (i in 0 until 4) bars[i] = bars[i].coerceIn(0f, 0.45f)
            }
            val cropW = dispW * (1f - bars[0] - bars[2])
            val cropH = dispH * (1f - bars[1] - bars[3])

            // result size: short side = target, same shape (of the picture inside the bars), even numbers
            // (4K / 6K when the phone's encoder takes them, otherwise smaller with the same shape; see ExportInfo.fitOut)
            val (ow0, oh0) = ExportInfo.fitOut(cropW, cropH, job.targetShort, job.hevc)
            var ow = ow0
            var oh = oh0

            // a job that was cut short before continues after its last finished piece
            metaTotal = totalUs
            metaW = ow
            metaH = oh
            val jd = dir(ctx, job.id)
            if (!job.stream) runCatching {
                val mf = File(jd, "job.json")
                if (mf.exists()) {
                    val j = JSONObject(mf.readText())
                    if (Math.abs(j.optLong("total") - totalUs) < 1000L && j.optInt("w") == ow && j.optInt("h") == oh) {
                        val arr = j.getJSONArray("segs")
                        for (i in 0 until arr.length()) {
                            val o = arr.getJSONObject(i)
                            val f = File(jd, o.getString("f"))
                            if (!f.exists() || f.length() == 0L) break
                            segs.add(ExportSeg(f, o.getLong("s"), o.getLong("d")))
                        }
                    }
                }
            }
            var resumeUs = rs
            if (segs.isNotEmpty()) {
                segIndex = segs.size
                resumeUs = segs.last().startUs + segs.last().durUs
            } else {
                jd.listFiles()?.forEach { it.delete() }
                // (the clean-up above also removed the look / bars just measured: write them again, or a continued job would measure again)
                if (Look.decode(job.look).auto) runCatching { File(jd, "look.txt").writeText(lookTxt) }
                if (Look.decode(lookTxt).cutBars) runCatching { File(jd, "bars.txt").writeText(bars.joinToString(",")) }
            }
            if (job.stream) runCatching { File(jd, STREAM_MARK).writeText("1") }

            // sound: copied as it is (compressed samples), into every piece
            if (aTrack >= 0) {
                val a = MediaExtractor()
                if (netFile != null) a.setDataSource(netFile.path) else a.setDataSource(ctx, srcUri, null)
                a.selectTrack(aTrack)
                ax = a
                audioFmt = a.getTrackFormat(aTrack)
                audioDone = false
            }

            // encoder
            var encMime = if (job.hevc) "video/hevc" else "video/avc"
            fun encFormat(high: Boolean) = MediaFormat.createVideoFormat(encMime, ow, oh).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                // "Watch now": the pieces are temporary (a couple of minutes on disk at most), so they get a richer bit rate than a
                // file: less of the upscaled detail is lost in the encoder, and the picture can beat the live effect
                val br0 = bitrate(ow, oh, fps * fgFactor(job.mode), job.tier, job.mode)
                val br = if (job.stream) (br0 * 1.5f).toInt().coerceAtMost(40_000_000) else br0
                setInteger(MediaFormat.KEY_BIT_RATE, if (encMime == "video/hevc") (br * 0.7f).toInt() else br)
                if (high && job.stream) setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
                setInteger(MediaFormat.KEY_FRAME_RATE, min(fps * fgFactor(job.mode), 120f).roundToInt())
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
                if (high && encMime == "video/avc") setInteger(MediaFormat.KEY_PROFILE, MediaCodecInfo.CodecProfileLevel.AVCProfileHigh)
            }
            fun makeEnc(): MediaCodec {
                var c = MediaCodec.createEncoderByType(encMime)
                try {
                    c.configure(encFormat(true), null, null, MediaCodec.CONFIGURE_FLAG_ENCODE) // H.264 High profile: better quality per bit
                } catch (t: Throwable) {
                    runCatching { c.release() }
                    c = MediaCodec.createEncoderByType(encMime)
                    c.configure(encFormat(false), null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                }
                return c
            }
            val e = try {
                makeEnc()
            } catch (t: Throwable) {
                if (encMime == "video/hevc" && segs.isEmpty()) {
                    encMime = "video/avc" // no usable H.265 encoder: plain H.264
                    // (H.264 may take less than H.265 did: fit the size again, same shape)
                    val fit = ExportInfo.fitOut(cropW, cropH, job.targetShort, false)
                    ow = fit.first
                    oh = fit.second
                    metaW = ow
                    metaH = oh
                    makeEnc()
                } else throw t
            }
            enc = e
            encSurface = e.createInputSurface()
            e.start()

            // GL pipeline: decoder -> [GL: effects] -> encoder
            val g = GlPipeline(encSurface)
            gl = g
            g.recordable = true
            g.exportMode = true
            g.frameGen = (job.mode and FG_FLAG) != 0
            g.temporal = temporalLevel(job.mode)
            g.crscOverride = (job.mode shr 21) and 7
            g.frameGenN = fgFactor(job.mode)
            g.fgQuality = fgQuality(job.mode)
            g.fx = fxFor(job.tier, job.anime, job.mode, job.sharpOv, job.vividOv, lookTxt)
            g.barL = bars[0]
            g.barB = bars[1]
            g.barR = bars[2]
            g.barT = bars[3]
            val aiLevel = VideoAi.level(job.mode)
            if (aiLevel > 0) {
                val aiId = VideoAi.modelFor(ctx, aiLevel) ?: throw IOException("no AI model is installed for this level")
                g.aiHook = { bmp ->
                    val small = VideoAi.shrink(bmp, aiLevel)
                    try {
                        AiSr.upscale(ctx, small, { }, cancel, modelId = aiId, keep = true)
                    } finally {
                        if (small !== bmp) small.recycle()
                    }
                }
            }
            val halfRate = VideoAi.half(job.mode)
            // frame rate cap: the export screen's setting; "Smooth live" has its own: Auto (0: all frames until the phone proves too slow, then
            // 30 and then 24 fps by itself), All frames (1), 30 or 24 fps
            val liveJob = job.stream && Look.decode(lookTxt).live
            val liveFps = ctx.getSharedPreferences("crsc", Context.MODE_PRIVATE).getInt("live_fps", 0)
            val autoFps = liveJob && liveFps == 0
            var capChangeAt = System.nanoTime()
            var capUs = if (liveJob) (if (liveFps == 30 || liveFps == 24) 1_000_000L / liveFps else 0L)
                else ctx.getSharedPreferences("crsc", Context.MODE_PRIVATE).getInt("export_fps_cap", 0).let { if (it > 0) 1_000_000L / it else 0L }
            var nextKeepUs = Long.MIN_VALUE
            var frameNo = 0
            val ready = CountDownLatch(1)
            val glErr = java.util.concurrent.atomic.AtomicReference<String?>(null)
            g.onError = { msg ->
                glErr.set(msg)
                ready.countDown()
                g.exportLatch?.countDown()
            }
            g.start(dispW, dispH) { s ->
                inSurface = s
                ready.countDown()
            }
            if (!ready.await(15, TimeUnit.SECONDS) || inSurface == null) throw IOException(glErr.get() ?: "GPU setup timeout")
            glErr.get()?.let { throw IOException(it) }

            // decoder (renders into the GL input surface)
            val d = MediaCodec.createDecoderByType(vMime)
            dec = d
            d.configure(vf, inSurface, null, 0)
            d.start()
            ex.selectTrack(vTrack)
            if (resumeUs > 0) {
                ex.seekTo(resumeUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
                ax?.seekTo(resumeUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
                flushNewSegs(l)
                l.onProgress((resumeUs - rs).coerceAtLeast(0L), spanTotal, 0f)
            }

            val di = MediaCodec.BufferInfo()
            var inputDone = false
            var outDone = false
            var atEnd = false // streaming: the whole video was worked through; wait for the viewer to jump somewhere else
            val t0 = System.nanoTime()
            var lastReport = 0L
            var lastLearn = 0L
            var repAt = 0L
            var repPts = 0L
            var smooth = 0f
            var lastSpeed = 0f
            var lastAlive = System.nanoTime()
            val spanEndUs = if (ends != Long.MAX_VALUE) ends else if (totalUs > 0) totalUs else Long.MAX_VALUE
            if (job.stream) {
                l.onProgress(0L, spanTotal, 0f)
                if (lastPts < rs) lastPts = rs
            }

            /** Lets the encoder hand over the last frames of the piece before it is closed. */
            fun settle() {
                repeat(5) {
                    try {
                        Thread.sleep(40)
                    } catch (ie: InterruptedException) {
                    }
                    drainEncoder(false)
                }
            }

            /** Streaming: the work goes on from [t0] (the viewer jumped, or a finished piece lies ahead). */
            fun jumpTo(t0: Long) {
                val t = t0.coerceIn(rs, spanEndUs)
                settle()
                pumpAudio(lastPts + frameDurUs)
                closeSeg()
                flushNewSegs(l)
                runCatching { d.flush() }
                ex.seekTo(t, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
                if (ax != null) {
                    runCatching { ax?.seekTo(t, MediaExtractor.SEEK_TO_CLOSEST_SYNC) }
                    audioDone = false
                }
                inputDone = false
                outDone = false
                atEnd = false
                closeAsap = false
                freshRun = true
                resumeUs = t
                lastPts = t
                lastAlive = System.nanoTime()
                repAt = 0L // the next speed measurement starts fresh (the picture time jumped)
                gateWaitNs = 0L
                gl?.resetHist = true
                runCatching { e.setParameters(android.os.Bundle().apply { putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0) }) }
            }

            /** Streaming: the end of the video (or of the chosen part) is reached: close the last piece and wait. */
            fun enterEnd() {
                settle()
                pumpAudio(lastPts + frameDurUs)
                closeSeg()
                flushNewSegs(l)
                atEnd = true
                inputDone = true
            }
            while (!outDone) {
                if (cancel.get()) return null
                if (pauseReq.get()) {
                    paused = true
                    break
                }
                if (stopSave.get()) {
                    // "stop and save": finish what is done so far; the pieces stay on disk so the job can go on later
                    partial = true
                    break
                }
                if (job.stream) {
                    // streaming: the viewer jumped to a spot that has no finished piece
                    val sr = ExportState.seekReq
                    if (sr >= 0L) {
                        ExportState.seekReq = -1L
                        // (a little tolerance: the next piece starts a few ms away from where the last one ends; without it a
                        // viewer who simply ran out of finished pieces made the work throw away its place and start over)
                        val covered = sr >= (if (mux != null) segStart else lastPts) - 400_000L && sr <= lastPts + frameDurUs + 400_000L
                        if (covered) {
                            closeAsap = true // the piece being written already covers it: publish it early
                        } else {
                            jumpTo(sr)
                        }
                    }
                    // the viewer is on a finished piece far ahead of the work: go on from the end of that piece
                    val pu = ExportState.playUs
                    if (pu >= 0L && !atEnd && lastPts + segUs < pu) {
                        var t = pu
                        while (true) {
                            val c = segs.firstOrNull { it.startUs <= t && t < it.startUs + it.durUs } ?: break
                            t = c.startUs + c.durUs
                        }
                        jumpTo(t)
                    }
                    if (atEnd) {
                        cleanBehind() // the whole video is made: what was watched still goes
                        lastAlive = System.nanoTime()
                        try {
                            Thread.sleep(250)
                        } catch (ie: InterruptedException) {
                            return null
                        }
                        continue
                    }
                    // wait while the work is far ahead of the viewer, and delete what is far away from the viewer
                    if (!streamGate(cancel, pauseReq, rs)) continue
                    lastAlive = System.nanoTime()
                    // the part ahead is ready: now the part just behind the viewer ("keep this much behind me") is made too, if it is missing
                    // (after a jump the work starts at the spot itself, so the picture appears at once; the part before it follows)
                    val fill = backfillReq
                    if (fill >= 0L) {
                        backfillReq = -1L
                        jumpTo(fill)
                    }
                }
                if (System.nanoTime() - lastAlive > 40_000_000_000L) throw IOException("the decoder stopped delivering frames")
                if (!inputDone) {
                    val ii = d.dequeueInputBuffer(2_000)
                    if (ii >= 0) {
                        val ib = d.getInputBuffer(ii) ?: throw IOException("decoder buffer")
                        val n = ex.readSampleData(ib, 0)
                        if (n < 0) {
                            d.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            d.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = d.dequeueOutputBuffer(di, 4_000)
                if (oi >= 0) {
                    lastAlive = System.nanoTime()
                    val eos = (di.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                    val skip = di.size > 0 && di.presentationTimeUs < resumeUs - frameDurUs / 2 // frames before the resume point are already done
                    if (di.size > 0 && di.presentationTimeUs >= ends) {
                        // the end of the chosen part: this frame and the rest are not needed
                        d.releaseOutputBuffer(oi, false)
                        if (job.stream) enterEnd() else outDone = true
                        continue
                    }
                    var drop = di.size > 0 && !skip && halfRate && (frameNo++ and 1) == 1 // half frame rate: every second frame is left out
                    if (capUs > 0L && di.size > 0 && !skip && !drop) {
                        // frame rate cap (30 / 24 fps): a frame is kept when its time has reached the next slot (a quarter slot of slack for time jitter)
                        if (nextKeepUs == Long.MIN_VALUE || Math.abs(di.presentationTimeUs - nextKeepUs) > 4 * capUs) nextKeepUs = di.presentationTimeUs
                        if (di.presentationTimeUs + capUs / 4 < nextKeepUs) drop = true else nextKeepUs += capUs
                    }
                    if (di.size > 0 && !skip && !drop) {
                        val ft0 = System.nanoTime()
                        val latch = CountDownLatch(1)
                        g.exportLatch = latch
                        d.releaseOutputBuffer(oi, true)
                        if (!latch.await(if (aiLevel > 0) 900L else 15L, TimeUnit.SECONDS)) throw IOException(glErr.get() ?: "GPU timeout")
                        glErr.get()?.let { throw IOException(it) }
                        drainEncoder(false)
                        val now = System.nanoTime()
                        if (now - lastReport > 700_000_000L) {
                            lastReport = now
                            val el = (now - t0) / 1e9f
                            // speed = video seconds per real second, smoothed over the last half minute or so (a plain average since the start
                            // is thrown off by the first slow frames, the model loading and the pauses), so "time left" stays honest
                            // (streaming: the time the work waited for the viewer is not work, so it is taken out; otherwise a phone that is
                            // fast enough looked slow, and a jump forward looked absurdly fast)
                            val waited = gateWaitNs
                            gateWaitNs = 0L
                            val spanNs = now - repAt - waited
                            val inst = if (repAt > 0L && spanNs > 50_000_000L && di.presentationTimeUs > repPts) (di.presentationTimeUs - repPts) / 1e6f / (spanNs / 1e9f) else 0f
                            repAt = now
                            repPts = di.presentationTimeUs
                            if (inst > 0f) smooth = if (smooth <= 0f) inst else smooth * 0.8f + inst * 0.2f
                            val speed = if (el > 3f) smooth else 0f
                            if (speed > 0f) lastSpeed = speed
                            // Smooth live, Auto: the phone is slower than the video -> leave out every second frame (60 -> 30), and if that is
                            // still not enough, down to 24 fps; the speed is measured again after each step. It never goes back up by itself.
                            if (autoFps && speed > 0f && speed < 0.95f && el > 6f && now - capChangeAt > 8_000_000_000L) {
                                val cur = if (capUs > 0L) 1_000_000f / capUs else fps
                                val next = if (cur > 31f && fps > 31f) 30 else if (cur > 25f && fps > 25f) 24 else 0
                                if (next > 0) {
                                    capUs = 1_000_000L / next
                                    capChangeAt = now
                                    nextKeepUs = Long.MIN_VALUE
                                    smooth = 0f
                                    repAt = 0L
                                }
                            }
                            // streaming never reaches the end of a file export, so the phone's speed is learned while it works
                            if (job.stream && speed > 0f && el > 20f && aiLevel == 0 && fgFactor(job.mode) == 1 && capUs == 0L && now - lastLearn > 15_000_000_000L) {
                                lastLearn = now
                                ExportInfo.saveMpx(ctx, speed * fps * ow * oh / 1e6f * ExportInfo.COST[job.tier.coerceIn(0, 3)] * ExportInfo.PACE[job.pace.coerceIn(0, 2)] * ExportInfo.modeCost(job.mode).toFloat() * (1f + 0.3f * temporalLevel(job.mode)))
                            }
                            l.onProgress((di.presentationTimeUs - rs).coerceAtLeast(0L), spanTotal, speed)
                        }
                        // pieces that were just closed
                        flushNewSegs(l)
                        if (job.stream) {
                            // a piece that was finished earlier lies right ahead: do not do it twice
                            val nxt = segs.filter { it.startUs > segStart && it.startUs <= lastPts + frameDurUs && it.startUs + it.durUs > lastPts + frameDurUs }.maxByOrNull { it.startUs + it.durUs }
                            if (nxt != null) jumpTo(nxt.startUs + nxt.durUs)
                        }
                        // (streaming: no rest. The work already idles by itself whenever it is far enough ahead of the viewer, and a rest
                        // would only make a phone that is slower than the video even slower)
                        if (job.pace > 0 && !job.stream) {
                            // "balanced" / "gentle": rest between frames so the phone stays cooler
                            val worked = (System.nanoTime() - ft0) / 1_000_000L
                            val rest = (worked * (if (job.pace == 1) 0.6 else 1.5)).toLong().coerceIn(1L, 400L)
                            Thread.sleep(rest)
                        }
                    } else {
                        d.releaseOutputBuffer(oi, false)
                    }
                    if (eos) {
                        if (job.stream) enterEnd() else outDone = true
                    }
                }
            }
            e.signalEndOfInputStream()
            drainEncoder(true)
            pumpAudio(if (partial || paused) lastPts + frameDurUs else ends)
            closeSeg()
            flushNewSegs(l)
            if (paused) return null
            if (job.stream) {
                // nothing is written to the gallery: the viewer plays the pieces, then they are deleted
                l.onProgress(spanTotal, spanTotal, 0f)
                return null
            }
            if (!partial) l.onProgress(spanTotal, spanTotal, 0f)
            if (segs.isEmpty()) throw IOException("nothing was written")
            // remember how fast this phone really is, so the next estimate is better
            // only plain runs teach the estimate: the AI model and frame generation have their own cost and would skew it
            if (!partial && !job.stream && lastSpeed > 0f && spanTotal > 60_000_000L && aiLevel == 0 && fgFactor(job.mode) == 1 && capUs == 0L) {
                ExportInfo.saveMpx(ctx, lastSpeed * fps * ow * oh / 1e6f * ExportInfo.COST[job.tier.coerceIn(0, 3)] * ExportInfo.PACE[job.pace.coerceIn(0, 2)] * ExportInfo.modeCost(job.mode).toFloat() * (1f + 0.3f * temporalLevel(job.mode)))
            }
            return join(job.name, cancel, partial)
        } finally {
            AiSr.closeCache()
            runCatching { dec?.stop() }
            runCatching { dec?.release() }
            runCatching { enc?.stop() }
            runCatching { enc?.release() }
            runCatching { gl?.release() }
            runCatching { encSurface?.release() }
            runCatching { ex.release() }
            runCatching { ax?.release() }
            runCatching { mux?.release() }
            runCatching { netFile?.delete() }
        }
    }

    // ---- writing pieces ---------------------------------------------------------------------------

    private var reported = 0

    private fun flushNewSegs(l: Listener) {
        while (reported < segs.size) l.onSegment(segs[reported++])
    }

    private fun drainEncoder(eos: Boolean) {
        val e = enc ?: return
        var idle = 0
        while (true) {
            val i = e.dequeueOutputBuffer(vinfo, if (eos) 10_000 else 0)
            when {
                i == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    if (!eos) return
                    if (++idle > 500) return // 5 s without anything
                }
                i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> encFmt = e.outputFormat
                i >= 0 -> {
                    idle = 0
                    val buf = e.getOutputBuffer(i)
                    if (buf != null && vinfo.size > 0 && (vinfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                        writeVideo(buf, vinfo)
                    }
                    val end = (vinfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                    e.releaseOutputBuffer(i, false)
                    if (end) return
                }
            }
        }
    }

    private fun writeVideo(buf: ByteBuffer, info: MediaCodec.BufferInfo) {
        val key = (info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0
        val pts = info.presentationTimeUs
        if (mux == null) {
            if (!key) return // a piece always starts with a key frame
            openSeg(pts)
        } else if (key && (pts - segStart >= (if (freshRun) STREAM_FIRST_US else segUs) || closeAsap)) {
            closeAsap = false
            freshRun = false
            pumpAudio(pts) // the sound up to here belongs to the piece that ends
            closeSeg()
            openSeg(pts)
        }
        val m = mux ?: return
        buf.position(info.offset)
        buf.limit(info.offset + info.size)
        val bi = MediaCodec.BufferInfo()
        bi.set(info.offset, info.size, max(0L, pts - segStart), info.flags)
        m.writeSampleData(mV, buf, bi)
        lastPts = pts
        pumpAudio(pts)
    }

    private fun openSeg(startUs: Long) {
        val f = File(dir(ctx, job.id), String.format(java.util.Locale.US, "seg_%04d.mp4", segIndex++))
        f.delete()
        val m = MediaMuxer(f.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        mV = m.addTrack(encFmt ?: throw IOException("no encoder format"))
        mA = -1
        val af = audioFmt
        if (af != null && !audioDone) {
            mA = try {
                m.addTrack(af)
            } catch (t: Throwable) {
                audioDone = true
                audioSkipped = true
                -1
            }
        }
        m.start()
        mux = m
        segFile = f
        segStart = startUs
    }

    /**
     * Streaming: deletes pieces that ended long before the spot being watched, and waits (about half a second at a
     * time) while the finished work is more than the "ahead" setting ahead of that spot. Returns false when the wait
     * was cut short by cancel / pause, so the caller can check them.
     */
    private fun dropSeg(s: ExportSeg) {
        runCatching { s.file.delete() }
        val i = segs.indexOf(s)
        if (i >= 0) {
            segs.removeAt(i)
            if (i < reported) reported-- // keeps the "already reported" counter right, or a new piece could be missed
        }
        ExportState.segs.remove(s)
    }

    /** Streaming: deletes the pieces that were watched (further back than the "keep" setting) or lie far ahead of a viewer who jumped away. */
    private fun cleanBehind() {
        val pu = ExportState.playUs
        if (pu < 0L || ExportState.keepAll || ExportState.saving) return
        val far = 2 * aheadUs() + behindUs()
        val old = segs.filter { it.startUs + it.durUs < pu - behindUs() || it.startUs > pu + far }
        for (s in old) dropSeg(s)
    }

    /** Streaming: the most disk the pieces may use (bytes, 0 = no limit). The work waits when it is over, but never gets nearer than 50 s ahead for that. */
    private fun spaceCapBytes(): Long {
        val mb = ctx.getSharedPreferences("crsc", Context.MODE_PRIVATE).getInt("stream_space_mb", 600)
        return if (mb <= 0) 0L else mb * 1024L * 1024L
    }

    /** Streaming: where the work should go back to, to make the missing part behind the viewer (-1 = nothing to do). Set by [streamGate], used by the loop. */
    @Volatile private var backfillReq = -1L
    private var lastBackfill = -1L
    private var lastBackfillAt = 0L

    /** The first spot of the stretch [ref - behind, ref) that no piece covers (gaps under 1.5 s are not worth a trip), or -1. */
    private fun missingBehind(ref: Long, rangeStart: Long): Long {
        val lo = max(rangeStart, ref - behindUs())
        if (ref - lo < 2_000_000L) return -1L
        val open = if (mux != null) ExportSeg(File(""), segStart, max(0L, lastPts + frameDurUs - segStart)) else null
        val all = if (open != null) segs + open else segs
        var cur = lo
        while (cur < ref - 1_500_000L) {
            val c = all.filter { it.startUs <= cur + 400_000L && it.startUs + it.durUs > cur }.maxByOrNull { it.startUs + it.durUs } ?: return cur
            cur = c.startUs + c.durUs
        }
        return -1L
    }

    private fun streamGate(cancel: AtomicBoolean, pauseReq: AtomicBoolean, rangeStart: Long): Boolean {
        while (true) {
            val pu = ExportState.playUs
            cleanBehind()
            val ref = if (pu >= 0L) pu else rangeStart
            val cap = spaceCapBytes()
            // the head start must stay possible: 50 s ahead, or only 15 s for a small limit (150 MB or less)
            val full = cap > 0L && lastPts - ref > (if (cap <= 150L * 1024 * 1024) 15_000_000L else 50_000_000L) && segs.sumOf { it.file.length() } > cap
            if (lastPts - ref <= aheadUs() && !full) return true
            // far enough ahead: instead of idling, make the part behind the viewer that is still missing (not twice for the same spot)
            if (!full && pu >= 0L && !ExportState.saving && !closeAsap) {
                val g = missingBehind(ref, rangeStart)
                val now = System.nanoTime()
                if (g >= 0L && !(g == lastBackfill && now - lastBackfillAt < 30_000_000_000L)) {
                    lastBackfill = g
                    lastBackfillAt = now
                    backfillReq = g
                    return true
                }
            }
            if (cancel.get() || pauseReq.get() || ExportState.seekReq >= 0L) return false
            val w0 = System.nanoTime()
            try {
                Thread.sleep(400)
            } catch (e: InterruptedException) {
                return false
            }
            gateWaitNs += System.nanoTime() - w0
        }
    }

    private fun closeSeg() {
        val m = mux ?: return
        val f = segFile
        runCatching { m.stop() }
        runCatching { m.release() }
        mux = null
        if (f != null && f.length() > 0) {
            segs.add(ExportSeg(f, segStart, lastPts + frameDurUs - segStart))
            saveMeta()
        }
        segFile = null
    }

    /** Copies the sound samples that start before [untilUs] into the open piece. */
    private fun pumpAudio(untilUs: Long) {
        val a = ax ?: return
        val m = mux ?: return
        if (mA < 0) return
        while (!audioDone) {
            val t = a.sampleTime
            if (t < 0) {
                audioDone = true
                break
            }
            if (t > untilUs) break
            if (t < segStart) {
                a.advance() // sound from before this piece starts (after a jump): not needed
                continue
            }
            abuf.clear()
            val n = a.readSampleData(abuf, 0)
            if (n < 0) {
                audioDone = true
                break
            }
            ainfo.set(0, n, max(0L, t - segStart), a.sampleFlags)
            m.writeSampleData(mA, abuf, ainfo)
            a.advance()
        }
    }

    // ---- joining the pieces into one file in Movies/ClearOverlay --------------------------------------

    /** "_14m00-19m00" for a chosen part, nothing for the whole video. */
    private fun rangeTag(): String {
        if (job.rangeStartUs <= 0L && job.rangeEndUs <= 0L) return ""
        fun t(us: Long): String {
            val s = us / 1_000_000L
            return if (s >= 3600) String.format(java.util.Locale.US, "%dh%02dm%02d", s / 3600, s % 3600 / 60, s % 60) else String.format(java.util.Locale.US, "%dm%02d", s / 60, s % 60)
        }
        return "_" + t(job.rangeStartUs) + "-" + (if (job.rangeEndUs > 0L) t(job.rangeEndUs) else "end")
    }

    private fun join(name: String, cancel: AtomicBoolean, partial: Boolean = false): Uri? {
        val base = name.substringBeforeLast('.').replace(Regex("[\\\\/:*?\"<>|]"), "_").ifEmpty { "video" }
        val joinBase = if (job.rangeStartUs > 0L || job.rangeEndUs > 0L) segs[0].startUs else 0L
        val specs = arrayOf(
            job.targetShort.toString() + "p", rangeTag().trimStart('_'), Stamp.modeName(job.mode), Stamp.tierName(job.tier),
            if (job.hevc) "H265" else "H264", if (fgFactor(job.mode) > 1) "FG" + fgFactor(job.mode) + "x" else null, if ((job.mode and SMARTFIX_FLAG) != 0) "SmartFix" else null, if (partial) "partial" else null
        )
        val out = joinSegs(ctx, ArrayList(segs), Stamp.name(base, *specs) + ".mp4", joinBase, cancel, Stamp.description(base, *specs))
        if (audioSkipped) AudioNote.skipped = true
        return out
    }
}

/** Set when the sound of the last export could not be copied (a sound type the MP4 writer does not take). */
object AudioNote {
    @Volatile var skipped = false
}
