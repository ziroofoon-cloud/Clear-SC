package app.clearoverlay

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

private const val PI = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

private fun openActivity(ctx: Context, code: Int, cls: Class<*>): PendingIntent =
    PendingIntent.getActivity(ctx, code, Intent(ctx, cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PI)

/** 1x1 widget: the overlay (switches the effect when the service runs; otherwise opens the app, the screen-capture permission needs a screen). */
class OverlayWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) mgr.updateAppWidget(id, build(ctx))
    }

    companion object {
        fun build(ctx: Context): RemoteViews {
            val v = RemoteViews(ctx.packageName, R.layout.widget_one_overlay)
            val pi = if (OverlayService.running)
                PendingIntent.getService(ctx, 11, Intent(ctx, OverlayService::class.java).setAction(OverlayService.ACT_TOGGLE), PI)
            else openActivity(ctx, 11, MainActivity::class.java)
            v.setOnClickPendingIntent(R.id.w_root, pi)
            return v
        }

        fun refresh(ctx: Context) = runCatching {
            val m = AppWidgetManager.getInstance(ctx)
            for (id in m.getAppWidgetIds(ComponentName(ctx, OverlayWidget::class.java))) m.updateAppWidget(id, build(ctx))
        }
    }
}

/** 1x1 widget: the library. */
class LibraryWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) {
            val v = RemoteViews(ctx.packageName, R.layout.widget_one_library)
            v.setOnClickPendingIntent(R.id.w_root, openActivity(ctx, 12, LibraryActivity::class.java))
            mgr.updateAppWidget(id, v)
        }
    }
}

/** 1x1 widget: Free up space. */
class ShrinkWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) {
            val v = RemoteViews(ctx.packageName, R.layout.widget_one_shrink)
            v.setOnClickPendingIntent(R.id.w_root, openActivity(ctx, 13, ShrinkActivity::class.java))
            mgr.updateAppWidget(id, v)
        }
    }
}

/** 4x1 widget: the music player (title, artist, previous / play-pause / next); a tap on the title opens the player. */
class MusicWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) mgr.updateAppWidget(id, build(ctx))
    }

    companion object {
        private fun svc(ctx: Context, code: Int, action: String): PendingIntent =
            PendingIntent.getForegroundService(ctx, code, Intent(ctx, MusicService::class.java).setAction(action), PI)

        fun build(ctx: Context): RemoteViews {
            val v = RemoteViews(ctx.packageName, R.layout.widget_music)
            val p = runCatching { MusicPlayer.player }.getOrNull()
            val t = if (p != null) runCatching { MusicPlayer.current() }.getOrNull() else null
            val playing = p != null && runCatching { p.isPlaying }.getOrDefault(false)
            v.setTextViewText(R.id.wm_title, t?.title?.takeIf { it.isNotBlank() } ?: ctx.getString(R.string.widget_music))
            v.setTextViewText(R.id.wm_artist, t?.artist ?: "")
            v.setImageViewResource(R.id.wm_play, if (playing) R.drawable.ic_w_pause else R.drawable.ic_w_play)
            v.setOnClickPendingIntent(R.id.wm_open, openActivity(ctx, 21, AudioActivity::class.java))
            if (p != null) {
                v.setOnClickPendingIntent(R.id.wm_prev, svc(ctx, 22, MusicService.ACT_PREV))
                v.setOnClickPendingIntent(R.id.wm_play, svc(ctx, 23, MusicService.ACT_TOGGLE))
                v.setOnClickPendingIntent(R.id.wm_next, svc(ctx, 24, MusicService.ACT_NEXT))
            } else { // nothing loaded (the process was restarted): the buttons open the player where a track is chosen
                val o = openActivity(ctx, 25, AudioActivity::class.java)
                v.setOnClickPendingIntent(R.id.wm_prev, o)
                v.setOnClickPendingIntent(R.id.wm_play, o)
                v.setOnClickPendingIntent(R.id.wm_next, o)
            }
            return v
        }

        fun refresh(ctx: Context) {
            runCatching {
                val m = AppWidgetManager.getInstance(ctx)
                for (id in m.getAppWidgetIds(ComponentName(ctx, MusicWidget::class.java))) m.updateAppWidget(id, build(ctx))
            }
        }
    }
}
