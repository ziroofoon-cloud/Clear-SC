package app.clearoverlay

/**
 * "Lite 8": the feature maps between the passes of an AI network are kept in 8 bits (RGBA8) and not in 16-bit floats (RGBA16F): half the memory and half the memory traffic, which is
 * what limits these networks on a phone GPU (half-precision maths only makes the arithmetic lighter, the maps stay 16-bit).
 *
 * A value v (a PReLU output, about -1.5 .. +3) is stored as `0.5 + 0.5 * sign(v) * sqrt(|v| / R)` (a square-root curve: fine steps near zero where most values are, coarse for large ones) and read back
 * as `s * |s| * R` with `s = 2 * e - 1`. R = 3: the largest value that fits; offline (Mesa, real pictures, all the AI 2x and AI 3x / Nova levels tried) the final picture differs from the 16-bit one by
 * 0.3 of 255 on average and by 7 at most at the normal strength (the check is `tools/shader_test/lite8_check.py` and `ai3_lite8_check.py`; R = 2 starts to clip, R = 8 gives 0.5 on average).
 * Only the maps between passes are 8-bit: the first pass reads the picture as it is, the last pass writes the picture as it is, and every sum inside a pass is still float.
 */
object Lite8 {
    const val R = 3.0f
    private val FETCH = Regex("texelFetch\\((uT\\d+),\\s*([^,]+?),\\s*0\\)")
    private val OUT = Regex("(?m)^(\\s*o\\d+ = )(.*);\\s*$")
    private val ZERO = Regex("(o\\d+) = vec4\\(0\\.0\\);")

    /**
     * The shader [src] with 8-bit maps: when [dec] every read of a map (`texelFetch(uT..)`) is decoded; when [enc] every output `oN = ...;` is encoded (and the "flat place" zero of the skip options is
     * the encoded zero). A convolution pass in the middle has both, the first pass only [enc] (it reads the picture), the last pass only [dec] (it writes the picture). Returns null when the text has no `void main()`.
     */
    fun wrap(src: String, dec: Boolean, enc: Boolean): String? {
        val i = src.indexOf("void main()")
        if (i < 0) return null
        var s = src
        if (dec) s = FETCH.replace(s) { "l8d(texelFetch(" + it.groupValues[1] + ", " + it.groupValues[2] + ", 0))" }
        if (enc) {
            s = OUT.replace(s) { it.groupValues[1] + "l8e(" + it.groupValues[2] + ");" }
            s = ZERO.replace(s) { it.groupValues[1] + " = vec4(0.5);" }
        }
        val j = s.indexOf("void main()")
        val fn = "\nconst float L8R = " + R + ";\n" +
            "vec4 l8d(vec4 e){ vec4 s = e * 2.0 - 1.0; return sign(s) * s * s * L8R; }\n" +
            "vec4 l8e(vec4 v){ return sign(v) * sqrt(min(abs(v) / L8R, 1.0)) * 0.5 + 0.5; }\n"
        return s.substring(0, j) + fn + s.substring(j)
    }
}
