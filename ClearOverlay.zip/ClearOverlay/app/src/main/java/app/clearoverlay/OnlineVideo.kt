package app.clearoverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Environment
import android.os.IBinder
import android.os.PowerManager
import android.provider.MediaStore
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

/** Progress of the cloud (Replicate) video upscale, shown by the export screen. */
object OnlineVideoState {
    @Volatile var running = false
    @Volatile var status = ""
    @Volatile var error: String? = null
    @Volatile var result: Uri? = null
}

/**
 * Upscales a video with a cloud AI model (Replicate, default lucataco/real-esrgan-video). The video (or the chosen part
 * of it) is cut into a small mp4, uploaded, processed in the cloud and the result is saved to Movies/ClearOverlay.
 * It costs money on the user's own Replicate account and the upload is limited in size.
 */
object OnlineVideo {
    const val MAX_UPLOAD = 95L * 1024 * 1024
    val RESOLUTIONS = listOf("HD", "FHD", "4k")

    /** Copies the video (or the part between the two times) to an mp4 without re-encoding. Keyframe aligned. */
    fun cut(ctx: Context, uri: Uri, startUs: Long, endUs: Long, out: File, cancel: AtomicBoolean) {
        val ex = MediaExtractor()
        ex.setDataSource(ctx, uri, null)
        val mux = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        try {
            val map = HashMap<Int, Int>()
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val m = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (m.startsWith("video/") || m.startsWith("audio/")) {
                    runCatching { map[i] = mux.addTrack(f); ex.selectTrack(i) }
                }
            }
            if (map.isEmpty()) throw IllegalStateException("no tracks")
            mux.start()
            if (startUs > 0) ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            val buf = ByteBuffer.allocate(2 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()
            var base = -1L
            while (!cancel.get()) {
                buf.clear()
                val n = ex.readSampleData(buf, 0)
                if (n < 0) break
                val t = ex.sampleTime
                if (endUs > 0 && t > endUs) break
                if (base < 0) base = t
                val tr = map[ex.sampleTrackIndex]
                if (tr != null) {
                    info.set(0, n, (t - base).coerceAtLeast(0), if (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                    mux.writeSampleData(tr, buf, info)
                }
                ex.advance()
            }
        } finally {
            runCatching { mux.stop() }
            runCatching { mux.release() }
            ex.release()
        }
    }

    private fun upload(token: String, f: File): String {
        val boundary = "----crsc" + System.nanoTime()
        val head = ("--$boundary\r\nContent-Disposition: form-data; name=\"content\"; filename=\"in.mp4\"\r\nContent-Type: video/mp4\r\n\r\n").toByteArray()
        val tail = "\r\n--$boundary--\r\n".toByteArray()
        val c = URL("${Online.API}/files").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 20000
        c.readTimeout = 180000
        c.doOutput = true
        c.setFixedLengthStreamingMode(head.size + f.length() + tail.size)
        c.setRequestProperty("Authorization", "Bearer $token")
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        c.outputStream.use { o ->
            o.write(head)
            f.inputStream().use { it.copyTo(o, 64 * 1024) }
            o.write(tail)
        }
        val code = c.responseCode
        val body = (if (code in 200..299) c.inputStream else c.errorStream)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
        c.disconnect()
        if (code !in 200..299) Online.fail(Online.Resp(code, body))
        return JSONObject(body).getJSONObject("urls").getString("get")
    }

    /** Whole job. Worker thread only. Returns the saved file, or null when cancelled. */
    fun run(ctx: Context, uri: Uri, name: String, startUs: Long, endUs: Long, resolution: String, cancel: AtomicBoolean, status: (String) -> Unit): Uri? {
        val token = Online.key(ctx)
        if (token.isEmpty()) throw IllegalStateException("no API token (Online settings)")
        val slug = Online.videoModel(ctx)
        val tmp = File(ctx.cacheDir, "online_in.mp4")
        try {
            status(ctx.getString(R.string.ovid_cut))
            cut(ctx, uri, startUs, endUs, tmp, cancel)
            if (cancel.get()) return null
            if (tmp.length() > MAX_UPLOAD) throw IllegalStateException(ctx.getString(R.string.ovid_too_big, (tmp.length() shr 20).toInt()))
            status(ctx.getString(R.string.ovid_upload, (tmp.length() shr 20).toInt()))
            val url = upload(token, tmp)
            if (cancel.get()) return null

            status(ctx.getString(R.string.ovid_start))
            val version = try { Online.latestVersion(token, slug) } catch (t: IllegalStateException) { null }
            val variants = listOf(
                JSONObject().put("video_path", url).put("resolution", resolution),
                JSONObject().put("video_path", url)
            )
            var start = Online.Resp(0, "")
            val endpoint = if (version != null) "${Online.API}/predictions" else "${Online.API}/models/$slug/predictions"
            for (input in variants) {
                val body = (if (version != null) JSONObject().put("version", version) else JSONObject()).put("input", input).toString()
                start = Online.call("POST", endpoint, token, body)
                var tries = 0
                while (start.code == 429 && tries < 4) {
                    tries++
                    Thread.sleep(8000)
                    if (cancel.get()) return null
                    start = Online.call("POST", endpoint, token, body)
                }
                if (start.code != 422) break
            }
            if (start.code !in 200..299) Online.fail(start)
            val job = JSONObject(start.body)
            val getUrl = job.getJSONObject("urls").getString("get")
            val cancelUrl = job.getJSONObject("urls").optString("cancel")

            val t0 = System.currentTimeMillis()
            var out: String? = null
            var netErrors = 0
            while (true) {
                if (cancel.get()) {
                    if (cancelUrl.isNotEmpty()) runCatching { Online.call("POST", cancelUrl, token) }
                    return null
                }
                if (System.currentTimeMillis() - t0 > 3L * 3600 * 1000) throw IllegalStateException("timeout")
                Thread.sleep(5000)
                val r = try { Online.call("GET", getUrl, token) } catch (e: java.io.IOException) {
                    if (++netErrors > 8) throw e
                    continue
                }
                netErrors = 0
                if (r.code !in 200..299) Online.fail(r)
                val j = JSONObject(r.body)
                status(ctx.getString(R.string.ovid_wait, ((System.currentTimeMillis() - t0) / 1000).toInt() / 60))
                when (j.optString("status")) {
                    "succeeded" -> {
                        val o = j.opt("output")
                        out = when (o) {
                            is String -> o
                            is org.json.JSONArray -> if (o.length() > 0) o.optString(0) else null
                            is JSONObject -> o.optString("url").ifEmpty { null }
                            else -> null
                        }
                        break
                    }
                    "failed", "canceled" -> throw IllegalStateException(j.optString("error").ifEmpty { j.optString("status") }.take(300) +
                        (j.optString("logs").takeIf { it.isNotBlank() }?.let { "\n" + it.takeLast(300) } ?: ""))
                }
            }
            val outUrl = out ?: throw IllegalStateException("empty result")

            status(ctx.getString(R.string.ovid_download))
            val base = name.substringBeforeLast('.').ifBlank { "video" }.replace(Regex("[^\\p{L}\\p{N}._-]"), "_")
            val cv = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, base + "_online_AI_" + resolution + ".mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/ClearOverlay")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val dst = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv) ?: throw IllegalStateException("cannot create the file")
            try {
                val c = URL(outUrl).openConnection() as HttpURLConnection
                c.connectTimeout = 20000
                c.readTimeout = 120000
                try {
                    c.inputStream.use { i -> ctx.contentResolver.openOutputStream(dst)!!.use { o -> i.copyTo(o, 64 * 1024) } }
                } finally { c.disconnect() }
                if (cancel.get()) { ctx.contentResolver.delete(dst, null, null); return null }
                cv.clear()
                cv.put(MediaStore.Video.Media.IS_PENDING, 0)
                ctx.contentResolver.update(dst, cv, null, null)
            } catch (t: Throwable) {
                runCatching { ctx.contentResolver.delete(dst, null, null) }
                throw t
            }
            return dst
        } finally {
            tmp.delete()
        }
    }
}

/** Keeps the cloud video job alive in the background (foreground service with a notification). */
class OnlineVideoService : Service() {
    private val cancel = AtomicBoolean(false)

    companion object {
        const val ACT_START = "app.clearoverlay.OVID_START"
        const val ACT_CANCEL = "app.clearoverlay.OVID_CANCEL"
        private const val CH = "crsc_online_video"
        private const val ID = 78

        fun start(ctx: Context, uri: Uri, name: String, startUs: Long, endUs: Long, resolution: String) {
            ctx.startForegroundService(
                Intent(ctx, OnlineVideoService::class.java).setAction(ACT_START).setData(uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    .putExtra("name", name).putExtra("s", startUs).putExtra("e", endUs).putExtra("res", resolution)
            )
        }

        fun cancel(ctx: Context) {
            ctx.startService(Intent(ctx, OnlineVideoService::class.java).setAction(ACT_CANCEL))
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun notif(text: String, ongoing: Boolean): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, ExportActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val b = Notification.Builder(this, CH).setSmallIcon(R.drawable.ic_stat).setContentTitle(getString(R.string.ovid_title))
            .setContentText(text).setContentIntent(open).setOnlyAlertOnce(true).setOngoing(ongoing)
        if (ongoing) {
            b.setProgress(0, 0, true)
            val c = PendingIntent.getService(this, 2, Intent(this, OnlineVideoService::class.java).setAction(ACT_CANCEL), PendingIntent.FLAG_IMMUTABLE)
            b.addAction(Notification.Action.Builder(null, getString(R.string.export_cancel), c).build())
        }
        return b.build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACT_CANCEL) {
            cancel.set(true)
            return START_NOT_STICKY
        }
        val u = intent?.data
        if (intent?.action != ACT_START || u == null || OnlineVideoState.running) {
            if (!OnlineVideoState.running) stopSelf()
            return START_NOT_STICKY
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, getString(R.string.ovid_title), NotificationManager.IMPORTANCE_LOW))
        startForeground(ID, notif(getString(R.string.ovid_cut), true), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        val wl = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "crsc:onlinevideo").also { it.acquire(4L * 3600 * 1000) }
        cancel.set(false)
        OnlineVideoState.running = true
        OnlineVideoState.error = null
        OnlineVideoState.result = null
        val name = intent.getStringExtra("name") ?: "video"
        val s = intent.getLongExtra("s", 0L)
        val e = intent.getLongExtra("e", 0L)
        val res = intent.getStringExtra("res") ?: "FHD"
        Thread {
            var out: Uri? = null
            var err: String? = null
            try {
                out = OnlineVideo.run(this, u, name, s, e, res, cancel) { t ->
                    OnlineVideoState.status = t
                    nm.notify(ID, notif(t, true))
                }
            } catch (t: Throwable) {
                err = (t.message ?: t.javaClass.simpleName)
            }
            OnlineVideoState.result = out
            OnlineVideoState.error = err
            OnlineVideoState.status = ""
            OnlineVideoState.running = false
            runCatching { wl.release() }
            stopForeground(STOP_FOREGROUND_REMOVE)
            val msg = when {
                err != null -> getString(R.string.ovid_failed)
                out != null -> getString(R.string.ovid_done)
                else -> getString(R.string.ovid_cancelled)
            }
            nm.notify(ID + 1, notif(msg, false))
            stopSelf()
        }.start()
        return START_NOT_STICKY
    }
}
