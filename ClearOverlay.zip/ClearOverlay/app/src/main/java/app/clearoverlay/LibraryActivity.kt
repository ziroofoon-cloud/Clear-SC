package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.provider.MediaStore
import android.os.Bundle
import android.database.ContentObserver
import android.media.MediaScannerConnection
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.abs
import java.util.concurrent.Executors

/**
 * The app's own gallery: videos, photos and manga folders straight from the phone's media index, so nothing has to be
 * picked in a file manager. Videos / photos open in the player with the other items of the folder as a playlist;
 * a manga folder (any image folder) or a .cbz / .zip file opens in the manga reader.
 *
 * Extras (3.8.0):
 *  - folders added by hand (for folders the phone's media index does not list), shown next to the automatic ones;
 *  - categories ("Favorites" + any you create) for videos and photos; long-press an item to select, then add it;
 *  - long-press a folder to add all of it to a category, or (hand-added) to remove it from the library.
 */
class LibraryActivity : Activity() {

    private class Cell(
        val title: String,
        val sub: String,
        val thumb: Uri?,
        val kind: Int,
        val folder: Media.Folder? = null,
        val item: Media.Item? = null,
        val cat: LibStore.Category? = null,
        val icon: String = ""
    )

    private class Holder(
        val box: LinearLayout,
        val iv: ImageView,
        val icon: TextView,
        val badge: TextView,
        val check: TextView,
        val star: TextView,
        val name: TextView,
        val sub: TextView
    ) {
        var key: String? = null
    }

    private val ui = Handler(Looper.getMainLooper())
    private val pool = Executors.newFixedThreadPool(3)
    private lateinit var grid: GridView
    private lateinit var titleTv: TextView
    private lateinit var msg: TextView
    private lateinit var allowBtn: TextView
    private lateinit var bar: LinearLayout
    private lateinit var barRemove: TextView
    private lateinit var tabViews: List<TextView>
    private lateinit var refreshBtn: View
    private lateinit var newCatBtn: View
    private lateinit var hiddenBtn: View
    private lateinit var barHide: TextView
    private var showHidden = false
    private val scrollPos = HashMap<String, Pair<Int, Int>>()
    private var observing = false
    private val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            // the phone's media index changed (new / removed files): reload shortly, once for a burst of changes
            ui.removeCallbacks(autoReload)
            ui.postDelayed(autoReload, 700)
        }
    }
    private val autoReload = Runnable { if (!isDestroyed && loaded) reload() }

    private var tab = 0 // 0 videos, 1 photos, 2 manga
    private var openBucket: Long? = null
    private var openName = ""
    private var openCat: String? = null
    private var videos: List<Media.Item> = emptyList()
    private var images: List<Media.Item> = emptyList()
    private var photos: List<Media.Item> = emptyList() // images without GIFs
    private var gifs: List<Media.Item> = emptyList()
    private var cells: List<Cell> = emptyList()
    private var loaded = false
    private var gen = 0
    private var lastLevel = ""
    private var customScans: Map<String, Media.Scan> = emptyMap()
    private var favSet: Set<String> = emptySet()

    private var selecting = false
    private val selected = LinkedHashSet<String>()

    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Cfg.load(this)
        Ui.init(this)
        setTheme(Ui.theme())
        super.onCreate(savedInstanceState)
        Ui.styleBars(window)
        tab = getSharedPreferences("crsc_player", MODE_PRIVATE).getInt("libtab", 0).coerceIn(0, 3)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
        }
        val pad = dp(this, 12)

        val head = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(pad, dp(this@LibraryActivity, 10), pad, 0)
        }
        titleTv = Ui.text(this, getString(R.string.lib_title), 22f, Ui.TEXT, true).apply {
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            letterSpacing = 0.01f
            setOnClickListener { goBack() }
        }
        head.addView(titleTv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        newCatBtn = Icons.button(this, Icons.TAG_PLUS) { onNewCat() }
        head.addView(newCatBtn)
        head.addView(Icons.button(this, Icons.FOLDER_PLUS) { pickTree() })
        hiddenBtn = Icons.button(this, Icons.EYE_OFF) { toggleHidden() }
        hiddenBtn.alpha = 0.5f
        hiddenBtn.setOnLongClickListener { pinMenu(); true }
        head.addView(hiddenBtn)
        refreshBtn = Icons.button(this, Icons.REFRESH) { manualRefresh() }
        head.addView(refreshBtn)
        head.addView(Icons.button(this, Icons.OPEN) { startActivity(Intent(this, PlayerActivity::class.java)) })
        root.addView(head)

        val tabRow = LinearLayout(this).apply {
            setPadding(pad, dp(this@LibraryActivity, 10), pad, dp(this@LibraryActivity, 6))
        }
        val names = listOf(R.string.lib_tab_videos, R.string.lib_tab_photos, R.string.lib_tab_manga, R.string.lib_tab_gif)
        tabViews = names.mapIndexed { i, r ->
            TextView(this).apply {
                text = getString(r)
                textSize = 14f
                typeface = Ui.FONT
                gravity = Gravity.CENTER
                setPadding(dp(this@LibraryActivity, 10), dp(this@LibraryActivity, 9), dp(this@LibraryActivity, 10), dp(this@LibraryActivity, 9))
                setOnClickListener { selectTab(i) }
            }
        }
        tabViews.forEachIndexed { i, v ->
            tabRow.addView(
                v,
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i > 0) marginStart = dp(this@LibraryActivity, 6) }
            )
        }
        root.addView(tabRow)

        msg = Ui.text(this, "", 14f, Ui.MUTED).apply {
            gravity = Gravity.CENTER
            setPadding(pad * 2, pad, pad * 2, pad)
            visibility = View.GONE
        }
        root.addView(msg)
        allowBtn = Ui.text(this, getString(R.string.lib_allow), 15f, Ui.BG, true).apply {
            gravity = Gravity.CENTER
            background = Ui.gradient(dp(this@LibraryActivity, 14).toFloat())
            setPadding(dp(this@LibraryActivity, 20), dp(this@LibraryActivity, 12), dp(this@LibraryActivity, 20), dp(this@LibraryActivity, 12))
            visibility = View.GONE
            setOnClickListener { requestPermissions(Media.permissions(), REQ_PERM) }
        }
        root.addView(allowBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            bottomMargin = pad
        })

        grid = GridView(this).apply {
            setPadding(pad, 0, pad, pad)
            clipToPadding = false
            horizontalSpacing = dp(this@LibraryActivity, 8)
            verticalSpacing = dp(this@LibraryActivity, 10)
            selector = Ui.round(Color.TRANSPARENT, 0f)
            isVerticalScrollBarEnabled = false
        }
        grid.adapter = adapter
        grid.setOnItemClickListener { _, _, pos, _ -> cells.getOrNull(pos)?.let { onCell(it) } }
        grid.setOnItemLongClickListener { _, _, pos, _ ->
            cells.getOrNull(pos)?.let { onLong(it) }
            true
        }
        // swipe sideways on the list to move to the neighbouring section (Videos / Photos / Manga / GIF)
        val tabGd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null || selecting) return false
                val dx = e2.x - e1.x
                if (abs(vx) > 450f && abs(vx) > abs(vy) * 1.5f && abs(dx) > dp(this@LibraryActivity, 56)) {
                    swipeTab(if (dx < 0) 1 else -1)
                    return true
                }
                return false
            }
        })
        grid.setOnTouchListener { _, ev ->
            tabGd.onTouchEvent(ev)
            false
        }
        root.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // selection bar (only while items are selected)
        bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Ui.CARD)
            setPadding(pad, dp(this@LibraryActivity, 8), pad, dp(this@LibraryActivity, 8))
            visibility = View.GONE
        }
        fun barBtn(label: String, onClick: () -> Unit): TextView = Ui.text(this, label, 14f, Ui.TEXT, true).apply {
            gravity = Gravity.CENTER
            maxLines = 1
            setPadding(dp(this@LibraryActivity, 6), dp(this@LibraryActivity, 10), dp(this@LibraryActivity, 6), dp(this@LibraryActivity, 10))
            background = Ui.round(Ui.CHIP, dp(this@LibraryActivity, 10).toFloat())
            setOnClickListener { onClick() }
            bar.addView(this, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (bar.childCount > 0) marginStart = dp(this@LibraryActivity, 6)
            })
        }
        barHide = barBtn(getString(R.string.lib_hide)) { hideSelected() }
        barBtn("★") { toggleFavorite() }
        barBtn(getString(R.string.lib_add_to)) { if (selected.isNotEmpty()) chooseCat(selected.toList()) }
        barRemove = barBtn(getString(R.string.lib_remove)) { removeSelectedFromCat() }
        barBtn(getString(R.string.lib_select_all)) { selectAll() }
        barBtn("✕") { exitSelect() }
        root.addView(bar)

        setContentView(root)
        paintTabs()

        reload()
        if (!Media.granted(this)) requestPermissions(Media.permissions(), REQ_PERM)
    }

    @Suppress("unused")
    private fun smallBtn(label: String, onClick: () -> Unit) = Ui.text(this, label, 20f).apply {
        setPadding(dp(this@LibraryActivity, 10), dp(this@LibraryActivity, 6), dp(this@LibraryActivity, 10), dp(this@LibraryActivity, 6))
        setOnClickListener { onClick() }
    }

    private fun paintTabs() {
        val r = dp(this, 12).toFloat()
        tabViews.forEachIndexed { i, v ->
            if (i == tab) {
                v.background = Ui.gradient(r)
                v.setTextColor(Ui.BG)
                v.typeface = Ui.FONT_BOLD
            } else {
                v.background = Ui.round(Ui.CHIP, r)
                v.setTextColor(Ui.MUTED)
                v.typeface = Ui.FONT
            }
        }
    }

    /** [d] = +1 when the finger moved left. In a right-to-left layout the tabs are mirrored, so the direction flips. */
    private fun swipeTab(d: Int) {
        val rtl = grid.layoutDirection == View.LAYOUT_DIRECTION_RTL
        val n = tab + (if (rtl) -d else d)
        if (n !in 0..3) return
        val w = grid.width.toFloat().coerceAtLeast(1f)
        grid.animate().cancel()
        grid.animate().translationX(-d * w * 0.25f).alpha(0f).setDuration(90).withEndAction {
            if (isDestroyed) return@withEndAction
            selectTab(n)
            grid.translationX = d * w * 0.25f
            grid.animate().translationX(0f).alpha(1f).setDuration(150).start()
        }.start()
    }

    private fun selectTab(i: Int) {
        if (tab == i && openBucket == null && openCat == null) return
        exitSelect(false)
        tab = i
        openBucket = null
        openCat = null
        getSharedPreferences("crsc_player", MODE_PRIVATE).edit().putInt("libtab", i).apply()
        paintTabs()
        refresh()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == REQ_PERM) reload()
    }

    override fun onResume() {
        super.onResume()
        Ui.init(this)
        if (loaded) reload()
    }

    override fun onStart() {
        super.onStart()
        if (!observing) {
            observing = true
            runCatching {
                contentResolver.registerContentObserver(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, observer)
                contentResolver.registerContentObserver(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, observer)
            }
        }
    }

    override fun onStop() {
        if (observing) {
            observing = false
            runCatching { contentResolver.unregisterContentObserver(observer) }
        }
        ui.removeCallbacks(autoReload)
        super.onStop()
    }

    /**
     * Reads the phone's media index and the hand-added folders in the background.
     * [rescan] = also walk the hand-added folders again (otherwise their last scan is reused, it can be slow).
     */
    private fun reload(rescan: Boolean = false) {
        val mine = ++gen
        val granted = Media.granted(this)
        val old = customScans
        val flist = LibStore.folders(this)
        if (!loaded) showMsg(getString(R.string.lib_loading))
        spin(true)
        Thread {
            val v = if (granted) Media.queryVideos(this) else emptyList()
            val im = if (granted) Media.queryImages(this) else emptyList()
            // stage 1: show the phone's own index at once (it is fast); the slow hand-added folders follow
            ui.post {
                if (isDestroyed || mine != gen) return@post
                val ocv = ArrayList<Media.Item>()
                val oci = ArrayList<Media.Item>()
                for (sc in old.values) {
                    ocv.addAll(sc.videos)
                    oci.addAll(sc.images)
                }
                Media.markDupes(v, ocv)
                Media.markDupes(im, oci)
                videos = (v + ocv).sortedByDescending { it.dateAdded }
                images = (im + oci).sortedByDescending { it.dateAdded }
                splitImages()
                loaded = true
                refresh()
            }
            // stage 2: hand-added folders are walked again every time (a new file there shows up right away)
            val scans = HashMap<String, Media.Scan>()
            for (f in flist) {
                scans[f.uri] = Media.scanTree(this, Uri.parse(f.uri), f.name)
            }
            val cv = ArrayList<Media.Item>()
            val ci = ArrayList<Media.Item>()
            for (sc in scans.values) {
                cv.addAll(sc.videos)
                ci.addAll(sc.images)
            }
            Media.markDupes(v, cv)
            Media.markDupes(im, ci)
            val allV = (v + cv).sortedByDescending { it.dateAdded }
            val allI = (im + ci).sortedByDescending { it.dateAdded }
            ui.post {
                if (isDestroyed || mine != gen) return@post
                customScans = scans
                videos = allV
                images = allI
                splitImages()
                loaded = true
                refresh()
                spin(false)
                if (rescan) Toast.makeText(this, getString(R.string.lib_updated), Toast.LENGTH_SHORT).show()
            }
        }.start()
    }

    private var spinning = false
    private fun spin(on: Boolean) {
        if (!::refreshBtn.isInitialized) return
        if (!on) {
            spinning = false
            refreshBtn.animate().cancel()
            refreshBtn.rotation = 0f
            return
        }
        if (spinning) return
        spinning = true
        val step = object : Runnable {
            override fun run() {
                if (!spinning || isDestroyed) return
                refreshBtn.animate().rotationBy(360f).setDuration(700).withEndAction(this).start()
            }
        }
        step.run()
    }

    /** 🔄: asks the phone to index new files first (that is what made new photos show up minutes late), then reloads. */
    private fun manualRefresh() {
        Toast.makeText(this, getString(R.string.lib_refreshing), Toast.LENGTH_SHORT).show()
        Thread {
            val paths = ArrayList<String>()
            runCatching {
                val root = Environment.getExternalStorageDirectory()
                for (name in listOf("DCIM", "Pictures", "Movies", "Download", "Documents", "Comics", "Manga", "Music")) {
                    walkForScan(java.io.File(root, name), 0, paths)
                }
                // top-level folders of the storage root too (manga / video folders are often created there)
                root.listFiles()?.forEach { d ->
                    if (d.isDirectory && !d.name.startsWith(".") && d.name != "Android") walkForScan(d, 0, paths)
                }
            }
            if (paths.isNotEmpty()) {
                runCatching { MediaScannerConnection.scanFile(applicationContext, paths.take(4000).toTypedArray(), null, null) }
            }
            ui.postDelayed({ if (!isDestroyed) reload(true) }, if (paths.isEmpty()) 0L else 900L)
        }.start()
    }

    private fun walkForScan(dir: java.io.File, depth: Int, out: MutableList<String>) {
        if (depth > 6 || out.size > 4000) return
        val kids = dir.listFiles() ?: return
        for (f in kids) {
            if (f.name.startsWith(".")) continue
            if (f.isDirectory) walkForScan(f, depth + 1, out)
            else {
                val ext = f.name.substringAfterLast('.', "").lowercase()
                if (ext in SCAN_EXT) out.add(f.absolutePath)
            }
        }
    }

    private fun splitImages() {
        val (g, p) = images.partition { it.name.endsWith(".gif", ignoreCase = true) }
        gifs = g
        photos = p
    }

    private fun srcList(): List<Media.Item> = when (tab) {
        0 -> videos
        1 -> photos
        2 -> images
        else -> gifs
    }

    private fun showMsg(s: String) {
        msg.text = s
        msg.visibility = View.VISIBLE
    }

    private fun catName(c: LibStore.Category) = if (c.builtin) getString(R.string.lib_fav) else c.name

    private fun sortFor(l: List<Media.Item>, bucket: Long?): List<Media.Item> = when {
        bucket != null && Media.isCustom(bucket) -> l.sortedWith { a, b -> Media.natural(a.path, b.path) }
        tab != 1 -> l.sortedWith { a, b -> Media.natural(a.name, b.name) }
        else -> l
    }

    /** Rebuilds the grid for the current tab / folder / category. */
    private fun refresh() {
        msg.visibility = View.GONE
        allowBtn.visibility = View.GONE
        grid.visibility = View.VISIBLE
        val list = ArrayList<Cell>()
        val b = openBucket
        val ci = openCat
        val full = srcList()
        val hs = LibStore.hidden(this)
        val src = if (showHidden) full else full.filter { x -> x.uri.toString() !in hs && "f$tab:${x.bucketId}" !in hs }
        favSet = if (tab < 2) LibStore.cat(this, if (tab == 0) LibStore.FAV_V else LibStore.FAV_P)?.items?.toHashSet() ?: emptySet() else emptySet()
        var real = 0

        if (ci != null) {
            val c = LibStore.cat(this, ci)
            if (c == null) {
                openCat = null
                refresh()
                return
            }
            titleTv.text = "‹  " + catName(c)
            for (it in sortFor(src.filter { x -> c.items.contains(x.uri.toString()) }, null)) list.add(itemCell(it))
            real = list.size
        } else if (b != null) {
            titleTv.text = "‹  $openName"
            val items = if (Media.isCustom(b)) sortFor(src.filter { it.bucketId == b }, b) else Media.inFolder(src, b, byName = tab != 1)
            for (it in items) list.add(itemCell(it))
            real = list.size
        } else if (showHidden) {
            titleTv.text = "‹  " + getString(R.string.lib_hidden_title)
            val hf = Media.folders(full).filter { "f$tab:${it.id}" in hs }
            for (f in hf) {
                list.add(Cell(f.name, "• " + getString(R.string.lib_items_fmt, f.count), f.cover, K_FOLDER, f, icon = "📁"))
                real++
            }
            if (tab != 2) {
                for (x in sortFor(full.filter { it.uri.toString() in hs }, null)) {
                    list.add(itemCell(x))
                    real++
                }
            }
        } else {
            titleTv.text = getString(R.string.lib_title)
            if (tab == 2) {
                list.add(Cell(getString(R.string.lib_open_cbz), "", null, K_CBZ, icon = "📚"))
            } else {
                if (src.isNotEmpty()) {
                    val allName = getString(when (tab) { 0 -> R.string.lib_all_videos; 3 -> R.string.lib_all_gifs; else -> R.string.lib_all_photos })
                    list.add(Cell(allName, getString(R.string.lib_items_fmt, src.size), src[0].uri, K_FOLDER, Media.Folder(Media.ALL, allName, src.size, src[0].uri, tab == 0)))
                    real++
                }
                val cats = LibStore.cats(this, tab)
                val strs = if (cats.isNotEmpty()) src.map { it.uri.toString() } else emptyList()
                for (c in cats) {
                    var n = 0
                    var cover: Uri? = null
                    for (i in src.indices) if (c.items.contains(strs[i])) {
                        n++
                        if (cover == null) cover = src[i].uri
                    }
                    val title = (if (c.builtin) "★ " else "") + catName(c)
                    list.add(Cell(title, getString(R.string.lib_items_fmt, n), cover, K_CAT, cat = c, icon = if (c.builtin) "⭐" else "🏷"))
                    real++
                }
            }
            val customList = LibStore.folders(this)
            val fl = ArrayList<Media.Folder>(Media.folders(src))
            val have = fl.map { it.id }.toHashSet()
            for (cf in customList) {
                if (cf.id in have) continue
                val sc = customScans[cf.uri]
                val hasAny = sc != null && (sc.videos.isNotEmpty() || sc.images.isNotEmpty())
                if (!hasAny && "f$tab:${cf.id}" !in hs) fl.add(Media.Folder(cf.id, cf.name, 0, null, tab == 0, cf.uri))
            }
            fl.sortWith { x, y -> Media.natural(x.name, y.name) }
            for (f in fl) {
                val custom = Media.isCustom(f.id)
                val sub = (if (custom) "• " else "") + getString(R.string.lib_items_fmt, f.count)
                list.add(Cell(f.name, sub, f.cover, K_FOLDER, f, icon = "📁"))
                real++
            }
        }

        cells = list
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val folderMode = b == null && ci == null
        grid.numColumns = if (folderMode) (if (land) 4 else 2) else (if (land) 5 else 3)
        adapter.notifyDataSetChanged()

        val level = "$tab|$b|$ci"
        if (level != lastLevel) {
            // remember where the old level was scrolled to, and come back to the same place on return
            if (lastLevel.isNotEmpty()) {
                val first = grid.firstVisiblePosition
                val top = grid.getChildAt(0)?.top ?: 0
                scrollPos[lastLevel] = Pair(first, top)
            }
            lastLevel = level
            val saved = scrollPos[level]
            grid.post {
                if (saved != null) grid.setSelectionFromTop(saved.first, saved.second) else grid.setSelection(0)
            }
        }
        newCatBtn.visibility = if (tab < 2 && b == null && ci == null && !showHidden) View.VISIBLE else View.GONE
        hiddenBtn.alpha = if (showHidden) 1f else 0.5f

        if (!loaded) {
            showMsg(getString(R.string.lib_loading))
        } else if (folderMode && !Media.granted(this)) {
            showMsg(getString(R.string.lib_need_perm))
            allowBtn.visibility = View.VISIBLE
        } else if (real == 0) {
            showMsg(getString(if (ci != null) R.string.lib_cat_empty else if (showHidden && folderMode) R.string.lib_hidden_empty else R.string.lib_empty))
        }
        updateBar()
    }

    private fun itemCell(it: Media.Item) =
        Cell(it.name.substringBeforeLast('.'), if (it.isVideo) fmtDur(it.durationMs) else "", it.uri, K_ITEM, item = it)

    // ---- taps ---------------------------------------------------------------------------------

    private fun onCell(c: Cell) {
        if (selecting) {
            c.item?.let { toggle(it) }
            return
        }
        when (c.kind) {
            K_CBZ -> {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                    .addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("*/*")
                    .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-cbz", "application/vnd.comicbook+zip", "application/octet-stream"))
                @Suppress("DEPRECATION")
                startActivityForResult(i, REQ_CBZ)
            }
            K_CAT -> {
                openCat = c.cat?.id
                refresh()
            }
            K_FOLDER -> {
                val f = c.folder ?: return
                if (tab == 2) {
                    val tree = LibStore.folders(this).firstOrNull { it.id == f.id }?.uri
                    val i = Intent(this, MangaActivity::class.java).putExtra(MangaActivity.EXTRA_NAME, f.name)
                    if (tree != null) i.putExtra(MangaActivity.EXTRA_TREE, tree) else i.putExtra(MangaActivity.EXTRA_BUCKET, f.id)
                    startActivity(i)
                } else {
                    openBucket = f.id
                    openName = f.name
                    refresh()
                }
            }
            K_ITEM -> {
                val it = c.item ?: return
                val items = cells.mapNotNull { x -> x.item }
                val idx = items.indexOfFirst { x -> x.uri == it.uri }.coerceAtLeast(0)
                val i = Intent(this, if (tab == 3) GifActivity::class.java else PlayerActivity::class.java)
                    .setData(it.uri)
                    .putExtra(PlayerArgs.FROM_LIB, true)
                    .putExtra(PlayerArgs.INDEX, idx)
                    .putStringArrayListExtra(PlayerArgs.LIST, ArrayList(items.map { x -> x.uri.toString() }))
                startActivity(i)
            }
        }
    }

    private fun onNewCat() {
        if (tab > 1) return
        askName(getString(R.string.lib_new_cat), "") { n ->
            LibStore.createCat(this, tab, n)
            refresh()
        }
    }

    private fun onLong(c: Cell) {
        val item = c.item
        when {
            item != null -> if (selecting) toggle(item) else startSelect(item)
            selecting -> Unit
            c.kind == K_CAT -> c.cat?.let { catMenu(it) }
            c.kind == K_FOLDER -> c.folder?.let { folderMenu(it) }
        }
    }

    // ---- selection ----------------------------------------------------------------------------

    private fun startSelect(it: Media.Item) {
        selecting = true
        selected.clear()
        selected.add(it.uri.toString())
        updateBar()
        adapter.notifyDataSetChanged()
    }

    private fun toggle(it: Media.Item) {
        val k = it.uri.toString()
        if (!selected.remove(k)) selected.add(k)
        if (selected.isEmpty()) exitSelect() else {
            updateBar()
            adapter.notifyDataSetChanged()
        }
    }

    private fun exitSelect(repaint: Boolean = true) {
        selecting = false
        selected.clear()
        bar.visibility = View.GONE
        if (repaint) {
            updateBar()
            adapter.notifyDataSetChanged()
        }
    }

    private fun selectAll() {
        for (c in cells) c.item?.let { selected.add(it.uri.toString()) }
        updateBar()
        adapter.notifyDataSetChanged()
    }

    private fun updateBar() {
        bar.visibility = if (selecting) View.VISIBLE else View.GONE
        barRemove.visibility = if (openCat != null) View.VISIBLE else View.GONE
        barHide.text = getString(if (showHidden) R.string.lib_unhide else R.string.lib_hide)
        if (selecting) titleTv.text = getString(R.string.lib_selected_fmt, selected.size)
    }

    // ---- optional PIN for the hidden section (long-press the eye icon to set / change / remove) ----

    private fun pinPrefs() = getSharedPreferences("crsc", Context.MODE_PRIVATE)
    private fun pinHash(p: String): String =
        java.security.MessageDigest.getInstance("SHA-256").digest(("crsc|" + p).toByteArray()).joinToString("") { "%02x".format(it) }
    private fun pinIsSet() = !pinPrefs().getString("hidden_pin", "").isNullOrEmpty()
    private fun pinMatches(p: String) = pinPrefs().getString("hidden_pin", "") == pinHash(p)

    private fun askPin(titleRes: Int, onOk: (String) -> Unit) {
        val et = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
            setSingleLine()
        }
        AlertDialog.Builder(this)
            .setTitle(getString(titleRes))
            .setView(et)
            .setPositiveButton(android.R.string.ok) { _, _ -> onOk(et.text.toString()) }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun pinMenu() {
        val set = pinIsSet()
        val items = if (set) arrayOf(getString(R.string.lib_pin_change), getString(R.string.lib_pin_remove))
        else arrayOf(getString(R.string.lib_pin_set))
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.lib_pin_title))
            .setItems(items) { _, which ->
                if (set && which == 1) {
                    askPin(R.string.lib_pin_enter) { p ->
                        if (pinMatches(p)) {
                            pinPrefs().edit().remove("hidden_pin").apply()
                            Toast.makeText(this, getString(R.string.lib_pin_removed), Toast.LENGTH_SHORT).show()
                        } else Toast.makeText(this, getString(R.string.lib_pin_wrong), Toast.LENGTH_SHORT).show()
                    }
                } else {
                    val setNew = {
                        askPin(R.string.lib_pin_new) { p ->
                            if (p.length < 4) Toast.makeText(this, getString(R.string.lib_pin_short), Toast.LENGTH_SHORT).show()
                            else {
                                pinPrefs().edit().putString("hidden_pin", pinHash(p)).apply()
                                Toast.makeText(this, getString(R.string.lib_pin_saved), Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                    if (set) askPin(R.string.lib_pin_enter) { p -> if (pinMatches(p)) setNew() else Toast.makeText(this, getString(R.string.lib_pin_wrong), Toast.LENGTH_SHORT).show() }
                    else setNew()
                }
            }
            .show()
    }

    private fun toggleHidden() {
        if (!showHidden && pinIsSet()) {
            askPin(R.string.lib_pin_enter) { p ->
                if (pinMatches(p)) doToggleHidden() else Toast.makeText(this, getString(R.string.lib_pin_wrong), Toast.LENGTH_SHORT).show()
            }
            return
        }
        doToggleHidden()
    }

    private fun doToggleHidden() {
        exitSelect(false)
        showHidden = !showHidden
        openBucket = null
        openCat = null
        refresh()
    }

    private fun hideSelected() {
        if (selected.isEmpty()) return
        val n = if (showHidden) LibStore.unhide(this, selected.toList()) else LibStore.hide(this, selected.toList())
        Toast.makeText(this, getString(if (showHidden) R.string.lib_unhidden_fmt else R.string.lib_hidden_fmt, n), Toast.LENGTH_SHORT).show()
        exitSelect(false)
        refresh()
    }

    private fun toggleFavorite() {
        if (selected.isEmpty() || tab > 1) return
        val id = if (tab == 0) LibStore.FAV_V else LibStore.FAV_P
        if (selected.all { favSet.contains(it) }) {
            LibStore.removeFrom(this, id, selected.toList())
            Toast.makeText(this, getString(R.string.lib_removed), Toast.LENGTH_SHORT).show()
        } else {
            val n = LibStore.addTo(this, id, selected.toList())
            Toast.makeText(this, getString(R.string.lib_added_fmt, n, getString(R.string.lib_fav)), Toast.LENGTH_SHORT).show()
        }
        exitSelect(false)
        refresh()
    }

    private fun removeSelectedFromCat() {
        val id = openCat ?: return
        LibStore.removeFrom(this, id, selected.toList())
        Toast.makeText(this, getString(R.string.lib_removed), Toast.LENGTH_SHORT).show()
        exitSelect(false)
        refresh()
    }

    // ---- categories ---------------------------------------------------------------------------

    /** "Add to…": pick a category (or make a new one) and put [uris] into it. */
    private fun chooseCat(uris: List<String>) {
        if (tab > 1 || uris.isEmpty()) return
        val cats = LibStore.cats(this, tab)
        val labels = ArrayList<String>()
        for (c in cats) labels.add((if (c.builtin) "★ " else "# ") + catName(c))
        labels.add("+ " + getString(R.string.lib_new_cat) + "…")
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.lib_choose_cat))
            .setItems(labels.toTypedArray()) { _, which ->
                if (which < cats.size) addToCat(cats[which], uris)
                else askName(getString(R.string.lib_new_cat), "") { n -> addToCat(LibStore.createCat(this, tab, n), uris) }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun addToCat(c: LibStore.Category, uris: List<String>) {
        val n = LibStore.addTo(this, c.id, uris)
        Toast.makeText(this, getString(R.string.lib_added_fmt, n, catName(c)), Toast.LENGTH_SHORT).show()
        exitSelect(false)
        refresh()
    }

    private fun catMenu(c: LibStore.Category) {
        if (c.builtin) return
        val labels = arrayOf(getString(R.string.lib_rename), getString(R.string.lib_delete_cat))
        AlertDialog.Builder(this)
            .setTitle(c.name)
            .setItems(labels) { _, which ->
                if (which == 0) {
                    askName(getString(R.string.lib_rename), c.name) { n ->
                        LibStore.rename(this, c.id, n)
                        refresh()
                    }
                } else {
                    AlertDialog.Builder(this)
                        .setMessage(getString(R.string.lib_delete_cat_confirm_fmt, c.name))
                        .setPositiveButton(android.R.string.ok) { _, _ ->
                            LibStore.delete(this, c.id)
                            refresh()
                        }
                        .setNegativeButton(android.R.string.cancel, null)
                        .show()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun askName(title: String, def: String, ok: (String) -> Unit) {
        val input = EditText(this).apply {
            setSingleLine()
            setText(def)
            setSelection(text.length)
            hint = getString(R.string.lib_cat_name_hint)
        }
        val box = LinearLayout(this).apply { setPadding(dp(this@LibraryActivity, 20), dp(this@LibraryActivity, 8), dp(this@LibraryActivity, 20), 0) }
        box.addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val n = input.text.toString().trim().take(40)
                if (n.isNotEmpty()) ok(n)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    // ---- folders added by hand ----------------------------------------------------------------

    private fun pickTree() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
        )
        @Suppress("DEPRECATION")
        startActivityForResult(i, REQ_TREE)
    }

    private fun folderMenu(f: Media.Folder) {
        val src = srcList()
        val custom = LibStore.folders(this).firstOrNull { it.id == f.id }
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        if (tab < 2 && f.count > 0) {
            labels.add(getString(R.string.lib_add_all_to))
            acts.add { chooseCat(Media.inFolder(src, f.id, false).map { it.uri.toString() }) }
        }
        if (custom != null) {
            labels.add(getString(R.string.lib_folder_remove))
            acts.add {
                AlertDialog.Builder(this)
                    .setMessage(getString(R.string.lib_folder_remove_confirm_fmt, custom.name))
                    .setPositiveButton(android.R.string.ok) { _, _ ->
                        LibStore.removeFolder(this, custom.uri)
                        runCatching { contentResolver.releasePersistableUriPermission(Uri.parse(custom.uri), Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                        reload()
                    }
                    .setNegativeButton(android.R.string.cancel, null)
                    .show()
            }
        }
        if (f.id != Media.ALL) {
            val key = "f$tab:${f.id}"
            val isH = LibStore.hidden(this).contains(key)
            labels.add(getString(if (isH) R.string.lib_unhide_folder else R.string.lib_hide_folder))
            acts.add {
                if (isH) LibStore.unhide(this, listOf(key)) else LibStore.hide(this, listOf(key))
                refresh()
            }
        }
        if (labels.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle(f.name)
            .setItems(labels.toTypedArray()) { _, which -> acts[which]() }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val u = data?.data
        if (res != RESULT_OK || u == null) return
        if (req == REQ_CBZ) {
            startActivity(Intent(this, MangaActivity::class.java).setData(u))
        } else if (req == REQ_TREE) {
            runCatching { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            val name = Media.treeName(this, u)
            if (LibStore.addFolder(this, u.toString(), name)) {
                Toast.makeText(this, getString(R.string.lib_folder_added_fmt, name), Toast.LENGTH_SHORT).show()
                reload()
            } else {
                Toast.makeText(this, getString(R.string.lib_folder_exists), Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---- navigation ---------------------------------------------------------------------------

    private fun goBack(): Boolean {
        if (selecting) {
            exitSelect()
            return true
        }
        if (openBucket != null || openCat != null) {
            openBucket = null
            openCat = null
            refresh()
            return true
        }
        return false
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!goBack()) {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (loaded) refresh()
    }

    override fun onDestroy() {
        pool.shutdownNow()
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun fmtDur(ms: Long): String {
        if (ms <= 0) return ""
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec) else String.format(Locale.US, "%d:%02d", m, sec)
    }

    // ---- grid adapter -------------------------------------------------------------------------

    private val adapter = object : BaseAdapter() {
        override fun getCount() = cells.size
        override fun getItem(position: Int): Any = cells[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val cols = grid.numColumns.coerceAtLeast(1)
            val colW = ((grid.width - grid.paddingLeft - grid.paddingRight - (cols - 1) * grid.horizontalSpacing) / cols).coerceAtLeast(dp(this@LibraryActivity, 60))
            val h = (convertView?.tag as? Holder) ?: makeHolder()
            val c = cells[position]
            val special = c.kind == K_CBZ
            val isVid = c.item?.isVideo == true
            val key = c.item?.uri?.toString()
            val sel = key != null && selected.contains(key)

            h.name.text = c.title
            h.name.setTextColor(if (special) Ui.ACCENT else Ui.TEXT)
            h.sub.text = c.sub
            h.sub.visibility = if (c.sub.isEmpty() || isVid) View.GONE else View.VISIBLE
            h.badge.text = if (isVid) c.sub else ""
            h.badge.visibility = if (isVid && c.sub.isNotEmpty()) View.VISIBLE else View.GONE
            h.iv.alpha = if (sel) 0.5f else 1f

            h.star.visibility = if (key != null && favSet.contains(key)) View.VISIBLE else View.GONE
            if (c.item != null && selecting) {
                h.check.visibility = View.VISIBLE
                h.check.text = if (sel) "✓" else ""
                h.check.setTextColor(Ui.BG)
                h.check.background = if (sel) Ui.round(Ui.ACCENT, dp(this@LibraryActivity, 10).toFloat())
                else Ui.round(Color.parseColor("#80000000"), dp(this@LibraryActivity, 10).toFloat(), Color.WHITE, dp(this@LibraryActivity, 1))
            } else {
                h.check.visibility = View.GONE
            }

            h.iv.setImageDrawable(null)
            h.key = null
            val u = c.thumb
            if (u == null || special) {
                h.iv.scaleType = ImageView.ScaleType.CENTER
                val ik = Icons.fromEmoji(c.icon)
                h.icon.text = ""
                h.icon.background = if (ik >= 0) LineIcon(ik, Ui.ACCENT) else null
                h.icon.visibility = if (ik >= 0) View.VISIBLE else View.GONE
            } else {
                h.icon.visibility = View.GONE
                h.iv.scaleType = ImageView.ScaleType.CENTER_CROP
                val k = u.toString()
                h.key = k
                val hit = cache.get(k)
                if (hit != null) {
                    h.iv.setImageBitmap(hit)
                } else {
                    pool.execute {
                        val bmp = Media.thumb(this@LibraryActivity, u, colW.coerceIn(120, 480)) ?: return@execute
                        cache.put(k, bmp)
                        ui.post { if (h.key == k) h.iv.setImageBitmap(bmp) }
                    }
                }
            }
            return h.box
        }

        private fun makeHolder(): Holder {
            val ctx = this@LibraryActivity
            val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            // a square cell whose size comes only from the column width the grid hands out: it can never end up smaller
            // (or taller) than its neighbours, whatever the grid's own width was a moment ago
            val frame = object : FrameLayout(ctx) {
                override fun onMeasure(w: Int, h: Int) {
                    super.onMeasure(w, w)
                }
            }
            val iv = ImageView(ctx).apply {
                background = Ui.round(Ui.CHIP, dp(ctx, 8).toFloat())
                outlineProvider = ViewOutlineProvider.BACKGROUND
                clipToOutline = true
            }
            frame.addView(iv)
            val icon = Ui.text(ctx, "", 26f, Ui.ACCENT).apply { visibility = View.GONE }
            frame.addView(icon, FrameLayout.LayoutParams(dp(ctx, 44), dp(ctx, 44), Gravity.CENTER))
            val badge = Ui.text(ctx, "", 11f, Color.WHITE, true).apply {
                setPadding(dp(ctx, 5), dp(ctx, 1), dp(ctx, 5), dp(ctx, 1))
                background = Ui.round(Color.parseColor("#B3000000"), dp(ctx, 5).toFloat())
            }
            frame.addView(badge, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END).apply {
                setMargins(0, 0, dp(ctx, 5), dp(ctx, 5))
            })
            val check = Ui.text(ctx, "", 13f, Ui.BG, true).apply {
                gravity = Gravity.CENTER
                visibility = View.GONE
            }
            frame.addView(check, FrameLayout.LayoutParams(dp(ctx, 22), dp(ctx, 22), Gravity.TOP or Gravity.START).apply {
                setMargins(dp(ctx, 5), dp(ctx, 5), 0, 0)
            })
            val star = Ui.text(ctx, "★", 15f, Color.parseColor("#FACC15"), true).apply {
                setShadowLayer(4f, 0f, 0f, Color.BLACK)
                visibility = View.GONE
            }
            frame.addView(star, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END).apply {
                setMargins(0, dp(ctx, 3), dp(ctx, 6), 0)
            })
            box.addView(frame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            val name = Ui.text(ctx, "", 13f, Ui.TEXT).apply {
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
            }
            box.addView(name, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(ctx, 4) })
            val sub = Ui.text(ctx, "", 11f, Ui.MUTED)
            box.addView(sub)
            val h = Holder(box, iv, icon, badge, check, star, name, sub)
            box.tag = h
            return h
        }
    }

    private companion object {
        val SCAN_EXT = setOf(
            "jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif", "avif",
            "mp4", "mkv", "webm", "avi", "mov", "m4v", "3gp", "ts", "flv", "wmv", "mpg", "mpeg"
        )
        const val REQ_PERM = 31
        const val REQ_CBZ = 32
        const val REQ_TREE = 33

        const val K_FOLDER = 0
        const val K_ITEM = 1
        const val K_CAT = 2
        const val K_CBZ = 3
    }
}
