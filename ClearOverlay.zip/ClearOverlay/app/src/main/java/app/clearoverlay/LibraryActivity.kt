package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import java.util.concurrent.Executors

/**
 * The app's own gallery: videos, photos and manga folders straight from the phone's media index, so nothing has to be
 * picked in a file manager. Videos / photos open in the player with the other items of the folder as a playlist;
 * a manga folder (any image folder) or a .cbz / .zip file opens in the manga reader.
 *
 * Extras (3.8.0):
 *  - folders added by hand (for folders the phone's media index does not list), shown next to the automatic ones;
 *  - categories ("Favorites" + any you create) for videos and photos; long-press an item to select, then add it;
 *  - long-press a folder to add all of it to a category, or (hand-added) to remove it from the library.
 */
class LibraryActivity : Activity() {

    private class Cell(
        val title: String,
        val sub: String,
        val thumb: Uri?,
        val kind: Int,
        val folder: Media.Folder? = null,
        val item: Media.Item? = null,
        val cat: LibStore.Category? = null,
        val icon: String = ""
    )

    private class Holder(
        val box: LinearLayout,
        val iv: ImageView,
        val icon: TextView,
        val badge: TextView,
        val check: TextView,
        val star: TextView,
        val name: TextView,
        val sub: TextView
    ) {
        var key: String? = null
    }

    private val ui = Handler(Looper.getMainLooper())
    private val pool = Executors.newFixedThreadPool(3)
    private lateinit var grid: GridView
    private lateinit var titleTv: TextView
    private lateinit var msg: TextView
    private lateinit var allowBtn: TextView
    private lateinit var bar: LinearLayout
    private lateinit var barRemove: TextView
    private lateinit var tabViews: List<TextView>

    private var tab = 0 // 0 videos, 1 photos, 2 manga
    private var openBucket: Long? = null
    private var openName = ""
    private var openCat: String? = null
    private var videos: List<Media.Item> = emptyList()
    private var images: List<Media.Item> = emptyList()
    private var cells: List<Cell> = emptyList()
    private var loaded = false
    private var gen = 0
    private var lastLevel = ""
    private var customScans: Map<String, Media.Scan> = emptyMap()
    private var favSet: Set<String> = emptySet()

    private var selecting = false
    private val selected = LinkedHashSet<String>()

    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Cfg.load(this)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        tab = getSharedPreferences("crsc_player", MODE_PRIVATE).getInt("libtab", 0).coerceIn(0, 2)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
        }
        val pad = dp(this, 12)

        val head = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(pad, dp(this@LibraryActivity, 10), pad, 0)
        }
        titleTv = Ui.text(this, getString(R.string.lib_title), 22f, Ui.TEXT, true).apply {
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setOnClickListener { goBack() }
        }
        head.addView(titleTv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(smallBtn("＋📁") { pickTree() })
        head.addView(smallBtn("🔄") { reload(true) })
        head.addView(smallBtn("📂") { startActivity(Intent(this, PlayerActivity::class.java)) })
        root.addView(head)

        val tabRow = LinearLayout(this).apply {
            setPadding(pad, dp(this@LibraryActivity, 10), pad, dp(this@LibraryActivity, 6))
        }
        val names = listOf(R.string.lib_tab_videos, R.string.lib_tab_photos, R.string.lib_tab_manga)
        tabViews = names.mapIndexed { i, r ->
            TextView(this).apply {
                text = getString(r)
                textSize = 14f
                gravity = Gravity.CENTER
                setPadding(dp(this@LibraryActivity, 10), dp(this@LibraryActivity, 9), dp(this@LibraryActivity, 10), dp(this@LibraryActivity, 9))
                setOnClickListener { selectTab(i) }
            }
        }
        tabViews.forEachIndexed { i, v ->
            tabRow.addView(
                v,
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i > 0) marginStart = dp(this@LibraryActivity, 6) }
            )
        }
        root.addView(tabRow)

        msg = Ui.text(this, "", 14f, Ui.MUTED).apply {
            gravity = Gravity.CENTER
            setPadding(pad * 2, pad, pad * 2, pad)
            visibility = View.GONE
        }
        root.addView(msg)
        allowBtn = Ui.text(this, getString(R.string.lib_allow), 15f, Ui.BG, true).apply {
            gravity = Gravity.CENTER
            background = Ui.gradient(dp(this@LibraryActivity, 14).toFloat())
            setPadding(dp(this@LibraryActivity, 20), dp(this@LibraryActivity, 12), dp(this@LibraryActivity, 20), dp(this@LibraryActivity, 12))
            visibility = View.GONE
            setOnClickListener { requestPermissions(Media.permissions(), REQ_PERM) }
        }
        root.addView(allowBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            bottomMargin = pad
        })

        grid = GridView(this).apply {
            setPadding(pad, 0, pad, pad)
            clipToPadding = false
            horizontalSpacing = dp(this@LibraryActivity, 8)
            verticalSpacing = dp(this@LibraryActivity, 10)
            selector = Ui.round(Color.TRANSPARENT, 0f)
            isVerticalScrollBarEnabled = false
        }
        grid.adapter = adapter
        grid.setOnItemClickListener { _, _, pos, _ -> cells.getOrNull(pos)?.let { onCell(it) } }
        grid.setOnItemLongClickListener { _, _, pos, _ ->
            cells.getOrNull(pos)?.let { onLong(it) }
            true
        }
        root.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // selection bar (only while items are selected)
        bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Ui.CARD)
            setPadding(pad, dp(this@LibraryActivity, 8), pad, dp(this@LibraryActivity, 8))
            visibility = View.GONE
        }
        fun barBtn(label: String, onClick: () -> Unit): TextView = Ui.text(this, label, 14f, Ui.TEXT, true).apply {
            gravity = Gravity.CENTER
            maxLines = 1
            setPadding(dp(this@LibraryActivity, 6), dp(this@LibraryActivity, 10), dp(this@LibraryActivity, 6), dp(this@LibraryActivity, 10))
            background = Ui.round(Ui.CHIP, dp(this@LibraryActivity, 10).toFloat())
            setOnClickListener { onClick() }
            bar.addView(this, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (bar.childCount > 0) marginStart = dp(this@LibraryActivity, 6)
            })
        }
        barBtn("★") { toggleFavorite() }
        barBtn(getString(R.string.lib_add_to)) { if (selected.isNotEmpty()) chooseCat(selected.toList()) }
        barRemove = barBtn(getString(R.string.lib_remove)) { removeSelectedFromCat() }
        barBtn(getString(R.string.lib_select_all)) { selectAll() }
        barBtn("✕") { exitSelect() }
        root.addView(bar)

        setContentView(root)
        paintTabs()

        reload()
        if (!Media.granted(this)) requestPermissions(Media.permissions(), REQ_PERM)
    }

    private fun smallBtn(label: String, onClick: () -> Unit) = Ui.text(this, label, 20f).apply {
        setPadding(dp(this@LibraryActivity, 10), dp(this@LibraryActivity, 6), dp(this@LibraryActivity, 10), dp(this@LibraryActivity, 6))
        setOnClickListener { onClick() }
    }

    private fun paintTabs() {
        val r = dp(this, 12).toFloat()
        tabViews.forEachIndexed { i, v ->
            if (i == tab) {
                v.background = Ui.gradient(r)
                v.setTextColor(Ui.BG)
                v.setTypeface(null, android.graphics.Typeface.BOLD)
            } else {
                v.background = Ui.round(Ui.CHIP, r)
                v.setTextColor(Ui.MUTED)
                v.setTypeface(null, android.graphics.Typeface.NORMAL)
            }
        }
    }

    private fun selectTab(i: Int) {
        if (tab == i && openBucket == null && openCat == null) return
        exitSelect(false)
        tab = i
        openBucket = null
        openCat = null
        getSharedPreferences("crsc_player", MODE_PRIVATE).edit().putInt("libtab", i).apply()
        paintTabs()
        refresh()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == REQ_PERM) reload()
    }

    override fun onResume() {
        super.onResume()
        if (loaded) reload()
    }

    /**
     * Reads the phone's media index and the hand-added folders in the background.
     * [rescan] = also walk the hand-added folders again (otherwise their last scan is reused, it can be slow).
     */
    private fun reload(rescan: Boolean = false) {
        val mine = ++gen
        val granted = Media.granted(this)
        val old = customScans
        val flist = LibStore.folders(this)
        if (!loaded) showMsg(getString(R.string.lib_loading))
        Thread {
            val v = if (granted) Media.queryVideos(this) else emptyList()
            val im = if (granted) Media.queryImages(this) else emptyList()
            val scans = HashMap<String, Media.Scan>()
            for (f in flist) {
                scans[f.uri] = (if (rescan) null else old[f.uri]) ?: Media.scanTree(this, Uri.parse(f.uri), f.name)
            }
            val cv = ArrayList<Media.Item>()
            val ci = ArrayList<Media.Item>()
            for (s in scans.values) {
                cv.addAll(s.videos)
                ci.addAll(s.images)
            }
            Media.markDupes(v, cv)
            Media.markDupes(im, ci)
            val allV = (v + cv).sortedByDescending { it.dateAdded }
            val allI = (im + ci).sortedByDescending { it.dateAdded }
            ui.post {
                if (isDestroyed || mine != gen) return@post
                customScans = scans
                videos = allV
                images = allI
                loaded = true
                refresh()
            }
        }.start()
    }

    private fun showMsg(s: String) {
        msg.text = s
        msg.visibility = View.VISIBLE
    }

    private fun catName(c: LibStore.Category) = if (c.builtin) getString(R.string.lib_fav) else c.name

    private fun sortFor(l: List<Media.Item>, bucket: Long?): List<Media.Item> = when {
        bucket != null && Media.isCustom(bucket) -> l.sortedWith { a, b -> Media.natural(a.path, b.path) }
        tab != 1 -> l.sortedWith { a, b -> Media.natural(a.name, b.name) }
        else -> l
    }

    /** Rebuilds the grid for the current tab / folder / category. */
    private fun refresh() {
        msg.visibility = View.GONE
        allowBtn.visibility = View.GONE
        grid.visibility = View.VISIBLE
        val list = ArrayList<Cell>()
        val b = openBucket
        val ci = openCat
        val src = if (tab == 0) videos else images
        favSet = if (tab < 2) LibStore.cat(this, if (tab == 0) LibStore.FAV_V else LibStore.FAV_P)?.items?.toHashSet() ?: emptySet() else emptySet()
        var real = 0

        if (ci != null) {
            val c = LibStore.cat(this, ci)
            if (c == null) {
                openCat = null
                refresh()
                return
            }
            titleTv.text = "‹  " + catName(c)
            for (it in sortFor(src.filter { x -> c.items.contains(x.uri.toString()) }, null)) list.add(itemCell(it))
            real = list.size
        } else if (b != null) {
            titleTv.text = "‹  $openName"
            val items = if (Media.isCustom(b)) sortFor(src.filter { it.bucketId == b }, b) else Media.inFolder(src, b, byName = tab != 1)
            for (it in items) list.add(itemCell(it))
            real = list.size
        } else {
            titleTv.text = getString(R.string.lib_title)
            if (tab == 2) {
                list.add(Cell(getString(R.string.lib_open_cbz), "", null, K_CBZ, icon = "📚"))
            } else {
                if (src.isNotEmpty()) {
                    val allName = getString(if (tab == 0) R.string.lib_all_videos else R.string.lib_all_photos)
                    list.add(Cell(allName, getString(R.string.lib_items_fmt, src.size), src[0].uri, K_FOLDER, Media.Folder(Media.ALL, allName, src.size, src[0].uri, tab == 0)))
                    real++
                }
                val cats = LibStore.cats(this, tab)
                val strs = if (cats.isNotEmpty()) src.map { it.uri.toString() } else emptyList()
                for (c in cats) {
                    var n = 0
                    var cover: Uri? = null
                    for (i in src.indices) if (c.items.contains(strs[i])) {
                        n++
                        if (cover == null) cover = src[i].uri
                    }
                    val title = (if (c.builtin) "⭐ " else "🏷 ") + catName(c)
                    list.add(Cell(title, getString(R.string.lib_items_fmt, n), cover, K_CAT, cat = c, icon = if (c.builtin) "⭐" else "🏷"))
                    real++
                }
                list.add(Cell(getString(R.string.lib_new_cat), "", null, K_NEWCAT, icon = "＋"))
            }
            val customList = LibStore.folders(this)
            val fl = ArrayList<Media.Folder>(Media.folders(src))
            val have = fl.map { it.id }.toHashSet()
            for (cf in customList) {
                if (cf.id in have) continue
                val sc = customScans[cf.uri]
                val hasAny = sc != null && (sc.videos.isNotEmpty() || sc.images.isNotEmpty())
                if (!hasAny) fl.add(Media.Folder(cf.id, cf.name, 0, null, tab == 0, cf.uri))
            }
            fl.sortWith { x, y -> Media.natural(x.name, y.name) }
            for (f in fl) {
                val custom = Media.isCustom(f.id)
                val sub = (if (custom) "📌 " else "") + getString(R.string.lib_items_fmt, f.count)
                list.add(Cell(f.name, sub, f.cover, K_FOLDER, f, icon = "📁"))
                real++
            }
            list.add(Cell(getString(R.string.lib_add_folder), "", null, K_ADD, icon = "📁"))
        }

        cells = list
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val folderMode = b == null && ci == null
        grid.numColumns = if (folderMode) (if (land) 4 else 2) else (if (land) 5 else 3)
        adapter.notifyDataSetChanged()

        val level = "$tab|$b|$ci"
        if (level != lastLevel) {
            lastLevel = level
            grid.setSelection(0)
        }

        if (!loaded) {
            showMsg(getString(R.string.lib_loading))
        } else if (folderMode && !Media.granted(this)) {
            showMsg(getString(R.string.lib_need_perm))
            allowBtn.visibility = View.VISIBLE
        } else if (real == 0) {
            showMsg(getString(if (ci != null) R.string.lib_cat_empty else R.string.lib_empty))
        }
        updateBar()
    }

    private fun itemCell(it: Media.Item) =
        Cell(it.name.substringBeforeLast('.'), if (it.isVideo) fmtDur(it.durationMs) else "", it.uri, K_ITEM, item = it)

    // ---- taps ---------------------------------------------------------------------------------

    private fun onCell(c: Cell) {
        if (selecting) {
            c.item?.let { toggle(it) }
            return
        }
        when (c.kind) {
            K_CBZ -> {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                    .addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("*/*")
                    .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-cbz", "application/vnd.comicbook+zip", "application/octet-stream"))
                @Suppress("DEPRECATION")
                startActivityForResult(i, REQ_CBZ)
            }
            K_ADD -> pickTree()
            K_NEWCAT -> askName(getString(R.string.lib_new_cat), "") { n ->
                LibStore.createCat(this, tab, n)
                refresh()
            }
            K_CAT -> {
                openCat = c.cat?.id
                refresh()
            }
            K_FOLDER -> {
                val f = c.folder ?: return
                if (tab == 2) {
                    val tree = LibStore.folders(this).firstOrNull { it.id == f.id }?.uri
                    val i = Intent(this, MangaActivity::class.java).putExtra(MangaActivity.EXTRA_NAME, f.name)
                    if (tree != null) i.putExtra(MangaActivity.EXTRA_TREE, tree) else i.putExtra(MangaActivity.EXTRA_BUCKET, f.id)
                    startActivity(i)
                } else {
                    openBucket = f.id
                    openName = f.name
                    refresh()
                }
            }
            K_ITEM -> {
                val it = c.item ?: return
                val items = cells.mapNotNull { x -> x.item }
                val idx = items.indexOfFirst { x -> x.uri == it.uri }.coerceAtLeast(0)
                val i = Intent(this, PlayerActivity::class.java)
                    .setData(it.uri)
                    .putExtra(PlayerArgs.FROM_LIB, true)
                    .putExtra(PlayerArgs.INDEX, idx)
                    .putStringArrayListExtra(PlayerArgs.LIST, ArrayList(items.map { x -> x.uri.toString() }))
                startActivity(i)
            }
        }
    }

    private fun onLong(c: Cell) {
        val item = c.item
        when {
            item != null -> if (selecting) toggle(item) else startSelect(item)
            selecting -> Unit
            c.kind == K_CAT -> c.cat?.let { catMenu(it) }
            c.kind == K_FOLDER -> c.folder?.let { folderMenu(it) }
        }
    }

    // ---- selection ----------------------------------------------------------------------------

    private fun startSelect(it: Media.Item) {
        selecting = true
        selected.clear()
        selected.add(it.uri.toString())
        updateBar()
        adapter.notifyDataSetChanged()
    }

    private fun toggle(it: Media.Item) {
        val k = it.uri.toString()
        if (!selected.remove(k)) selected.add(k)
        if (selected.isEmpty()) exitSelect() else {
            updateBar()
            adapter.notifyDataSetChanged()
        }
    }

    private fun exitSelect(repaint: Boolean = true) {
        selecting = false
        selected.clear()
        bar.visibility = View.GONE
        if (repaint) {
            updateBar()
            adapter.notifyDataSetChanged()
        }
    }

    private fun selectAll() {
        for (c in cells) c.item?.let { selected.add(it.uri.toString()) }
        updateBar()
        adapter.notifyDataSetChanged()
    }

    private fun updateBar() {
        bar.visibility = if (selecting) View.VISIBLE else View.GONE
        barRemove.visibility = if (openCat != null) View.VISIBLE else View.GONE
        if (selecting) titleTv.text = getString(R.string.lib_selected_fmt, selected.size)
    }

    private fun toggleFavorite() {
        if (selected.isEmpty() || tab > 1) return
        val id = if (tab == 0) LibStore.FAV_V else LibStore.FAV_P
        if (selected.all { favSet.contains(it) }) {
            LibStore.removeFrom(this, id, selected.toList())
            Toast.makeText(this, getString(R.string.lib_removed), Toast.LENGTH_SHORT).show()
        } else {
            val n = LibStore.addTo(this, id, selected.toList())
            Toast.makeText(this, getString(R.string.lib_added_fmt, n, getString(R.string.lib_fav)), Toast.LENGTH_SHORT).show()
        }
        exitSelect(false)
        refresh()
    }

    private fun removeSelectedFromCat() {
        val id = openCat ?: return
        LibStore.removeFrom(this, id, selected.toList())
        Toast.makeText(this, getString(R.string.lib_removed), Toast.LENGTH_SHORT).show()
        exitSelect(false)
        refresh()
    }

    // ---- categories ---------------------------------------------------------------------------

    /** "Add to…": pick a category (or make a new one) and put [uris] into it. */
    private fun chooseCat(uris: List<String>) {
        if (tab > 1 || uris.isEmpty()) return
        val cats = LibStore.cats(this, tab)
        val labels = ArrayList<String>()
        for (c in cats) labels.add((if (c.builtin) "⭐ " else "🏷 ") + catName(c))
        labels.add("＋ " + getString(R.string.lib_new_cat) + "…")
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.lib_choose_cat))
            .setItems(labels.toTypedArray()) { _, which ->
                if (which < cats.size) addToCat(cats[which], uris)
                else askName(getString(R.string.lib_new_cat), "") { n -> addToCat(LibStore.createCat(this, tab, n), uris) }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun addToCat(c: LibStore.Category, uris: List<String>) {
        val n = LibStore.addTo(this, c.id, uris)
        Toast.makeText(this, getString(R.string.lib_added_fmt, n, catName(c)), Toast.LENGTH_SHORT).show()
        exitSelect(false)
        refresh()
    }

    private fun catMenu(c: LibStore.Category) {
        if (c.builtin) return
        val labels = arrayOf(getString(R.string.lib_rename), getString(R.string.lib_delete_cat))
        AlertDialog.Builder(this)
            .setTitle(c.name)
            .setItems(labels) { _, which ->
                if (which == 0) {
                    askName(getString(R.string.lib_rename), c.name) { n ->
                        LibStore.rename(this, c.id, n)
                        refresh()
                    }
                } else {
                    AlertDialog.Builder(this)
                        .setMessage(getString(R.string.lib_delete_cat_confirm_fmt, c.name))
                        .setPositiveButton(android.R.string.ok) { _, _ ->
                            LibStore.delete(this, c.id)
                            refresh()
                        }
                        .setNegativeButton(android.R.string.cancel, null)
                        .show()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun askName(title: String, def: String, ok: (String) -> Unit) {
        val input = EditText(this).apply {
            setSingleLine()
            setText(def)
            setSelection(text.length)
            hint = getString(R.string.lib_cat_name_hint)
        }
        val box = LinearLayout(this).apply { setPadding(dp(this@LibraryActivity, 20), dp(this@LibraryActivity, 8), dp(this@LibraryActivity, 20), 0) }
        box.addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val n = input.text.toString().trim().take(40)
                if (n.isNotEmpty()) ok(n)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    // ---- folders added by hand ----------------------------------------------------------------

    private fun pickTree() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
        )
        @Suppress("DEPRECATION")
        startActivityForResult(i, REQ_TREE)
    }

    private fun folderMenu(f: Media.Folder) {
        val src = if (tab == 0) videos else images
        val custom = LibStore.folders(this).firstOrNull { it.id == f.id }
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        if (tab < 2 && f.count > 0) {
            labels.add(getString(R.string.lib_add_all_to))
            acts.add { chooseCat(Media.inFolder(src, f.id, false).map { it.uri.toString() }) }
        }
        if (custom != null) {
            labels.add(getString(R.string.lib_folder_remove))
            acts.add {
                AlertDialog.Builder(this)
                    .setMessage(getString(R.string.lib_folder_remove_confirm_fmt, custom.name))
                    .setPositiveButton(android.R.string.ok) { _, _ ->
                        LibStore.removeFolder(this, custom.uri)
                        runCatching { contentResolver.releasePersistableUriPermission(Uri.parse(custom.uri), Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                        reload()
                    }
                    .setNegativeButton(android.R.string.cancel, null)
                    .show()
            }
        }
        if (labels.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle(f.name)
            .setItems(labels.toTypedArray()) { _, which -> acts[which]() }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val u = data?.data
        if (res != RESULT_OK || u == null) return
        if (req == REQ_CBZ) {
            startActivity(Intent(this, MangaActivity::class.java).setData(u))
        } else if (req == REQ_TREE) {
            runCatching { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            val name = Media.treeName(this, u)
            if (LibStore.addFolder(this, u.toString(), name)) {
                Toast.makeText(this, getString(R.string.lib_folder_added_fmt, name), Toast.LENGTH_SHORT).show()
                reload()
            } else {
                Toast.makeText(this, getString(R.string.lib_folder_exists), Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---- navigation ---------------------------------------------------------------------------

    private fun goBack(): Boolean {
        if (selecting) {
            exitSelect()
            return true
        }
        if (openBucket != null || openCat != null) {
            openBucket = null
            openCat = null
            refresh()
            return true
        }
        return false
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!goBack()) {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (loaded) refresh()
    }

    override fun onDestroy() {
        pool.shutdownNow()
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun fmtDur(ms: Long): String {
        if (ms <= 0) return ""
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec) else String.format(Locale.US, "%d:%02d", m, sec)
    }

    // ---- grid adapter -------------------------------------------------------------------------

    private val adapter = object : BaseAdapter() {
        override fun getCount() = cells.size
        override fun getItem(position: Int): Any = cells[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val cols = grid.numColumns.coerceAtLeast(1)
            val colW = ((grid.width - grid.paddingLeft - grid.paddingRight - (cols - 1) * grid.horizontalSpacing) / cols).coerceAtLeast(dp(this@LibraryActivity, 60))
            val h = (convertView?.tag as? Holder) ?: makeHolder()
            val c = cells[position]
            val special = c.kind >= K_CBZ
            val isVid = c.item?.isVideo == true
            val key = c.item?.uri?.toString()
            val sel = key != null && selected.contains(key)

            h.iv.layoutParams = FrameLayout.LayoutParams(colW, if (special) dp(this@LibraryActivity, 64) else colW)
            h.name.text = c.title
            h.name.setTextColor(if (special) Ui.ACCENT else Ui.TEXT)
            h.sub.text = c.sub
            h.sub.visibility = if (c.sub.isEmpty() || isVid) View.GONE else View.VISIBLE
            h.badge.text = if (isVid) c.sub else ""
            h.badge.visibility = if (isVid && c.sub.isNotEmpty()) View.VISIBLE else View.GONE
            h.iv.alpha = if (sel) 0.5f else 1f

            h.star.visibility = if (key != null && favSet.contains(key)) View.VISIBLE else View.GONE
            if (c.item != null && selecting) {
                h.check.visibility = View.VISIBLE
                h.check.text = if (sel) "✓" else ""
                h.check.setTextColor(Ui.BG)
                h.check.background = if (sel) Ui.round(Ui.ACCENT, dp(this@LibraryActivity, 10).toFloat())
                else Ui.round(Color.parseColor("#80000000"), dp(this@LibraryActivity, 10).toFloat(), Color.WHITE, dp(this@LibraryActivity, 1))
            } else {
                h.check.visibility = View.GONE
            }

            h.iv.setImageDrawable(null)
            h.key = null
            val u = c.thumb
            if (u == null || special) {
                h.iv.scaleType = ImageView.ScaleType.CENTER
                h.icon.text = c.icon
                h.icon.visibility = if (c.icon.isNotEmpty()) View.VISIBLE else View.GONE
            } else {
                h.icon.visibility = View.GONE
                h.iv.scaleType = ImageView.ScaleType.CENTER_CROP
                val k = u.toString()
                h.key = k
                val hit = cache.get(k)
                if (hit != null) {
                    h.iv.setImageBitmap(hit)
                } else {
                    pool.execute {
                        val bmp = Media.thumb(this@LibraryActivity, u, colW.coerceIn(120, 480)) ?: return@execute
                        cache.put(k, bmp)
                        ui.post { if (h.key == k) h.iv.setImageBitmap(bmp) }
                    }
                }
            }
            return h.box
        }

        private fun makeHolder(): Holder {
            val ctx = this@LibraryActivity
            val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            val frame = FrameLayout(ctx)
            val iv = ImageView(ctx).apply {
                background = Ui.round(Ui.CHIP, dp(ctx, 8).toFloat())
                outlineProvider = ViewOutlineProvider.BACKGROUND
                clipToOutline = true
            }
            frame.addView(iv)
            val icon = Ui.text(ctx, "", 26f, Ui.ACCENT).apply { visibility = View.GONE }
            frame.addView(icon, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
            val badge = Ui.text(ctx, "", 11f, Color.WHITE, true).apply {
                setPadding(dp(ctx, 5), dp(ctx, 1), dp(ctx, 5), dp(ctx, 1))
                background = Ui.round(Color.parseColor("#B3000000"), dp(ctx, 5).toFloat())
            }
            frame.addView(badge, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END).apply {
                setMargins(0, 0, dp(ctx, 5), dp(ctx, 5))
            })
            val check = Ui.text(ctx, "", 13f, Ui.BG, true).apply {
                gravity = Gravity.CENTER
                visibility = View.GONE
            }
            frame.addView(check, FrameLayout.LayoutParams(dp(ctx, 22), dp(ctx, 22), Gravity.TOP or Gravity.START).apply {
                setMargins(dp(ctx, 5), dp(ctx, 5), 0, 0)
            })
            val star = Ui.text(ctx, "★", 15f, Color.parseColor("#FACC15"), true).apply {
                setShadowLayer(4f, 0f, 0f, Color.BLACK)
                visibility = View.GONE
            }
            frame.addView(star, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END).apply {
                setMargins(0, dp(ctx, 3), dp(ctx, 6), 0)
            })
            box.addView(frame)
            val name = Ui.text(ctx, "", 12f, Ui.TEXT).apply {
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
            }
            box.addView(name, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(ctx, 4) })
            val sub = Ui.text(ctx, "", 11f, Ui.MUTED)
            box.addView(sub)
            val h = Holder(box, iv, icon, badge, check, star, name, sub)
            box.tag = h
            return h
        }
    }

    private companion object {
        const val REQ_PERM = 31
        const val REQ_CBZ = 32
        const val REQ_TREE = 33

        const val K_FOLDER = 0
        const val K_ITEM = 1
        const val K_CAT = 2
        const val K_CBZ = 3
        const val K_ADD = 4
        const val K_NEWCAT = 5
    }
}
