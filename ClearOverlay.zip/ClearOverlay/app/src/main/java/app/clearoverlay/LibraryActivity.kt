package app.clearoverlay

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale
import java.util.concurrent.Executors

/**
 * The app's own gallery: videos, photos and manga folders straight from the phone's media index, so nothing has to be
 * picked in a file manager. Videos / photos open in the player with the other items of the folder as a playlist;
 * a manga folder (any image folder) or a .cbz / .zip file opens in the manga reader.
 */
class LibraryActivity : Activity() {

    private class Cell(
        val title: String,
        val sub: String,
        val thumb: Uri?,
        val folder: Media.Folder? = null,
        val item: Media.Item? = null,
        val special: Int = 0 // 1 = "open a .cbz / .zip file"
    )

    private class Holder(val box: LinearLayout, val iv: ImageView, val badge: TextView, val name: TextView, val sub: TextView) {
        var key: String? = null
    }

    private val ui = Handler(Looper.getMainLooper())
    private val pool = Executors.newFixedThreadPool(3)
    private lateinit var grid: GridView
    private lateinit var titleTv: TextView
    private lateinit var msg: TextView
    private lateinit var allowBtn: TextView
    private lateinit var tabViews: List<TextView>

    private var tab = 0 // 0 videos, 1 photos, 2 manga
    private var openBucket: Long? = null
    private var openName = ""
    private var videos: List<Media.Item> = emptyList()
    private var images: List<Media.Item> = emptyList()
    private var cells: List<Cell> = emptyList()
    private var loaded = false

    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Cfg.load(this)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        tab = getSharedPreferences("crsc_player", MODE_PRIVATE).getInt("libtab", 0).coerceIn(0, 2)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
        }
        val pad = dp(this, 12)

        val head = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(pad, dp(this@LibraryActivity, 10), pad, 0)
        }
        titleTv = Ui.text(this, getString(R.string.lib_title), 22f, Ui.TEXT, true)
        head.addView(titleTv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(smallBtn("🔄") { reload() })
        head.addView(smallBtn("📂") { startActivity(Intent(this, PlayerActivity::class.java)) })
        root.addView(head)

        val tabRow = LinearLayout(this).apply {
            setPadding(pad, dp(this@LibraryActivity, 10), pad, dp(this@LibraryActivity, 6))
        }
        val names = listOf(R.string.lib_tab_videos, R.string.lib_tab_photos, R.string.lib_tab_manga)
        tabViews = names.mapIndexed { i, r ->
            TextView(this).apply {
                text = getString(r)
                textSize = 14f
                gravity = Gravity.CENTER
                setPadding(dp(this@LibraryActivity, 10), dp(this@LibraryActivity, 9), dp(this@LibraryActivity, 10), dp(this@LibraryActivity, 9))
                setOnClickListener { selectTab(i) }
            }
        }
        tabViews.forEachIndexed { i, v ->
            tabRow.addView(
                v,
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i > 0) marginStart = dp(this@LibraryActivity, 6) }
            )
        }
        root.addView(tabRow)

        msg = Ui.text(this, "", 14f, Ui.MUTED).apply {
            gravity = Gravity.CENTER
            setPadding(pad * 2, pad * 2, pad * 2, pad)
            visibility = View.GONE
        }
        root.addView(msg)
        allowBtn = Ui.text(this, getString(R.string.lib_allow), 15f, Ui.BG, true).apply {
            gravity = Gravity.CENTER
            background = Ui.gradient(dp(this@LibraryActivity, 14).toFloat())
            setPadding(dp(this@LibraryActivity, 20), dp(this@LibraryActivity, 12), dp(this@LibraryActivity, 20), dp(this@LibraryActivity, 12))
            visibility = View.GONE
            setOnClickListener { requestPermissions(Media.permissions(), REQ_PERM) }
        }
        root.addView(allowBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.CENTER_HORIZONTAL
        })

        grid = GridView(this).apply {
            setPadding(pad, 0, pad, pad)
            clipToPadding = false
            horizontalSpacing = dp(this@LibraryActivity, 8)
            verticalSpacing = dp(this@LibraryActivity, 10)
            selector = Ui.round(Color.TRANSPARENT, 0f)
            isVerticalScrollBarEnabled = false
        }
        grid.adapter = adapter
        grid.setOnItemClickListener { _, _, pos, _ -> onCell(cells[pos]) }
        root.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        paintTabs()

        if (Media.granted(this)) reload() else showNeedPermission()
        if (!Media.granted(this)) requestPermissions(Media.permissions(), REQ_PERM)
    }

    private fun smallBtn(label: String, onClick: () -> Unit) = Ui.text(this, label, 20f).apply {
        setPadding(dp(this@LibraryActivity, 12), dp(this@LibraryActivity, 6), dp(this@LibraryActivity, 12), dp(this@LibraryActivity, 6))
        setOnClickListener { onClick() }
    }

    private fun paintTabs() {
        val r = dp(this, 12).toFloat()
        tabViews.forEachIndexed { i, v ->
            if (i == tab) {
                v.background = Ui.gradient(r)
                v.setTextColor(Ui.BG)
                v.setTypeface(null, android.graphics.Typeface.BOLD)
            } else {
                v.background = Ui.round(Ui.CHIP, r)
                v.setTextColor(Ui.MUTED)
                v.setTypeface(null, android.graphics.Typeface.NORMAL)
            }
        }
    }

    private fun selectTab(i: Int) {
        if (tab == i && openBucket == null) return
        tab = i
        openBucket = null
        getSharedPreferences("crsc_player", MODE_PRIVATE).edit().putInt("libtab", i).apply()
        paintTabs()
        refresh()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == REQ_PERM) {
            if (Media.granted(this)) reload() else showNeedPermission()
        }
    }

    override fun onResume() {
        super.onResume()
        if (loaded && Media.granted(this)) reload()
    }

    private fun showNeedPermission() {
        grid.visibility = View.GONE
        msg.text = getString(R.string.lib_need_perm)
        msg.visibility = View.VISIBLE
        allowBtn.visibility = View.VISIBLE
    }

    private fun reload() {
        if (!Media.granted(this)) {
            showNeedPermission()
            return
        }
        Thread {
            val v = Media.queryVideos(this)
            val im = Media.queryImages(this)
            ui.post {
                if (isDestroyed) return@post
                videos = v
                images = im
                loaded = true
                refresh()
            }
        }.start()
    }

    /** Rebuilds the grid for the current tab / folder. */
    private fun refresh() {
        msg.visibility = View.GONE
        allowBtn.visibility = View.GONE
        grid.visibility = View.VISIBLE
        val list = ArrayList<Cell>()
        val b = openBucket
        val src = if (tab == 0) videos else images
        if (b == null) {
            titleTv.text = getString(R.string.lib_title)
            if (tab == 2) list.add(Cell(getString(R.string.lib_open_cbz), "", null, special = 1))
            if (src.isNotEmpty() && tab != 2) {
                val allName = getString(if (tab == 0) R.string.lib_all_videos else R.string.lib_all_photos)
                list.add(Cell(allName, getString(R.string.lib_items_fmt, src.size), src[0].uri, Media.Folder(Media.ALL, allName, src.size, src[0].uri, tab == 0)))
            }
            for (f in Media.folders(src)) list.add(Cell(f.name, getString(R.string.lib_items_fmt, f.count), f.cover, f))
        } else {
            titleTv.text = "‹  $openName"
            for (it in Media.inFolder(src, b, byName = tab != 1)) {
                list.add(Cell(it.name.substringBeforeLast('.'), if (it.isVideo) fmtDur(it.durationMs) else "", it.uri, null, it))
            }
        }
        cells = list
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val folderMode = b == null
        grid.numColumns = if (folderMode) (if (land) 4 else 2) else (if (land) 5 else 3)
        adapter.notifyDataSetChanged()
        if (list.isEmpty() || (list.size == 1 && list[0].special == 1)) {
            msg.text = getString(R.string.lib_empty)
            msg.visibility = View.VISIBLE
        }
    }

    private fun onCell(c: Cell) {
        if (c.special == 1) {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                .addCategory(Intent.CATEGORY_OPENABLE)
                .setType("*/*")
                .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-cbz", "application/vnd.comicbook+zip", "application/octet-stream"))
            @Suppress("DEPRECATION")
            startActivityForResult(i, REQ_CBZ)
            return
        }
        val f = c.folder
        if (f != null) {
            if (tab == 2) {
                startActivity(
                    Intent(this, MangaActivity::class.java)
                        .putExtra(MangaActivity.EXTRA_BUCKET, f.id)
                        .putExtra(MangaActivity.EXTRA_NAME, f.name)
                )
            } else {
                openBucket = f.id
                openName = f.name
                refresh()
            }
            return
        }
        val it = c.item ?: return
        val items = cells.mapNotNull { x -> x.item }
        val idx = items.indexOfFirst { x -> x.uri == it.uri }.coerceAtLeast(0)
        val i = Intent(this, PlayerActivity::class.java)
            .setData(it.uri)
            .putExtra(PlayerArgs.FROM_LIB, true)
            .putExtra(PlayerArgs.INDEX, idx)
            .putStringArrayListExtra(PlayerArgs.LIST, ArrayList(items.map { x -> x.uri.toString() }))
        startActivity(i)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val u = data?.data
        if (req == REQ_CBZ && res == RESULT_OK && u != null) {
            startActivity(Intent(this, MangaActivity::class.java).setData(u))
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (openBucket != null) {
            openBucket = null
            refresh()
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (loaded) refresh()
    }

    override fun onDestroy() {
        pool.shutdownNow()
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun fmtDur(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec) else String.format(Locale.US, "%d:%02d", m, sec)
    }

    // ---- grid adapter -------------------------------------------------------------------------

    private val adapter = object : BaseAdapter() {
        override fun getCount() = cells.size
        override fun getItem(position: Int): Any = cells[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val cols = grid.numColumns.coerceAtLeast(1)
            val colW = ((grid.width - grid.paddingLeft - grid.paddingRight - (cols - 1) * grid.horizontalSpacing) / cols).coerceAtLeast(dp(this@LibraryActivity, 60))
            val h = (convertView?.tag as? Holder) ?: makeHolder()
            val c = cells[position]
            val square = if (c.special == 1) dp(this@LibraryActivity, 64) else colW
            h.iv.layoutParams = FrameLayout.LayoutParams(colW, square)
            h.name.text = c.title
            h.sub.text = c.sub
            h.sub.visibility = if (c.sub.isEmpty() || c.item?.isVideo == true) View.GONE else View.VISIBLE
            h.badge.text = if (c.item?.isVideo == true) c.sub else ""
            h.badge.visibility = if (c.item?.isVideo == true && c.sub.isNotEmpty()) View.VISIBLE else View.GONE
            h.iv.setImageDrawable(null)
            h.iv.setBackgroundColor(Ui.CHIP)
            if (c.special == 1) {
                h.iv.scaleType = ImageView.ScaleType.CENTER
                h.key = null
                h.iv.setImageDrawable(null)
                h.name.setTextColor(Ui.ACCENT)
            } else {
                h.name.setTextColor(Ui.TEXT)
                h.iv.scaleType = ImageView.ScaleType.CENTER_CROP
                val u = c.thumb
                if (u != null) {
                    val key = u.toString()
                    h.key = key
                    val hit = cache.get(key)
                    if (hit != null) {
                        h.iv.setImageBitmap(hit)
                    } else {
                        pool.execute {
                            val bmp = Media.thumb(this@LibraryActivity, u, colW.coerceIn(120, 480)) ?: return@execute
                            cache.put(key, bmp)
                            ui.post { if (h.key == key) h.iv.setImageBitmap(bmp) }
                        }
                    }
                }
            }
            return h.box
        }

        private fun makeHolder(): Holder {
            val box = LinearLayout(this@LibraryActivity).apply { orientation = LinearLayout.VERTICAL }
            val frame = FrameLayout(this@LibraryActivity)
            val iv = ImageView(this@LibraryActivity).apply { background = Ui.round(Ui.CHIP, dp(this@LibraryActivity, 8).toFloat()) }
            frame.addView(iv)
            val badge = Ui.text(this@LibraryActivity, "", 11f, Color.WHITE, true).apply {
                setPadding(dp(this@LibraryActivity, 5), dp(this@LibraryActivity, 1), dp(this@LibraryActivity, 5), dp(this@LibraryActivity, 1))
                background = Ui.round(Color.parseColor("#B3000000"), dp(this@LibraryActivity, 5).toFloat())
            }
            frame.addView(badge, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END).apply {
                setMargins(0, 0, dp(this@LibraryActivity, 5), dp(this@LibraryActivity, 5))
            })
            box.addView(frame)
            val name = Ui.text(this@LibraryActivity, "", 12f, Ui.TEXT).apply {
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
            }
            box.addView(name, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@LibraryActivity, 4) })
            val sub = Ui.text(this@LibraryActivity, "", 11f, Ui.MUTED)
            box.addView(sub)
            val h = Holder(box, iv, badge, name, sub)
            box.tag = h
            return h
        }
    }

    private companion object {
        const val REQ_PERM = 31
        const val REQ_CBZ = 32
    }
}
