package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.provider.MediaStore
import android.os.Bundle
import android.database.ContentObserver
import android.media.MediaScannerConnection
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.abs
import java.util.concurrent.Executors

/**
 * The app's own gallery: videos, photos and manga folders straight from the phone's media index, so nothing has to be
 * picked in a file manager. Videos / photos open in the player with the other items of the folder as a playlist;
 * a manga folder (any image folder) or a .cbz / .zip file opens in the manga reader.
 *
 * Extras (3.8.0):
 *  - folders added by hand (for folders the phone's media index does not list), shown next to the automatic ones;
 *  - categories ("Favorites" + any you create) for videos and photos; long-press an item to select, then add it;
 *  - long-press a folder to add all of it to a category, or (hand-added) to remove it from the library.
 */
class LibraryActivity : Activity() {

    private class Cell(
        val title: String,
        val sub: String,
        val thumb: Uri?,
        val kind: Int,
        val folder: Media.Folder? = null,
        val item: Media.Item? = null,
        val cat: LibStore.Category? = null,
        val icon: String = "",
        val hist: History.Entry? = null,
        val book: Uri? = null
    )

    private class Holder(
        val box: LinearLayout,
        val iv: ImageView,
        val icon: TextView,
        val badge: TextView,
        val check: TextView,
        val star: TextView,
        val name: TextView,
        val sub: TextView
    ) {
        var key: String? = null
    }

    private val ui = Handler(Looper.getMainLooper())
    private val pool = Executors.newFixedThreadPool(3)
    private lateinit var grid: GridView
    private lateinit var titleTv: TextView
    private lateinit var msg: TextView
    private lateinit var allowBtn: TextView
    private lateinit var bar: LinearLayout
    private lateinit var tabViews: List<TextView>
    private val tabNameRes = intArrayOf(R.string.lib_tab_videos, R.string.lib_tab_photos, R.string.lib_tab_manga, R.string.lib_tab_gif, R.string.lib_tab_music)
    private lateinit var refreshBtn: View
    private var canNewCat = false // "New category" is offered only at the top level of the videos / photos tabs
    private var showHidden = false
    private var query = ""                 // text typed in the search box ('' = no filter)
    private lateinit var searchEt: EditText
    private val scrollPos = HashMap<String, Pair<Int, Int>>()
    private var observing = false
    private val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            // the phone's media index changed (new / removed files): reload shortly, once for a burst of changes
            ui.removeCallbacks(autoReload)
            ui.postDelayed(autoReload, 700)
        }
    }
    private val autoReload = Runnable { if (!isDestroyed && loaded) reload() }

    private var tab = 0 // 0 videos, 1 photos, 2 manga
    private var openBucket: Long? = null
    private var openName = ""
    private var openCat: String? = null
    private var openHist = false
    private var videos: List<Media.Item> = emptyList()
    private var images: List<Media.Item> = emptyList()
    private var photos: List<Media.Item> = emptyList() // images without GIFs
    private var gifs: List<Media.Item> = emptyList()
    private var audios: List<Media.Item> = emptyList()
    private var cells: List<Cell> = emptyList()
    private var loaded = false
    private var gen = 0
    private var lastLevel = ""
    private var pickMode = false
    private var customScans: Map<String, Media.Scan> = emptyMap()
    private var favSet: Set<String> = emptySet()

    private var selecting = false
    private val selected = LinkedHashSet<String>()

    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Cfg.bind(this, "screen")
        Ui.init(this)
        setTheme(Ui.theme())
        super.onCreate(savedInstanceState)
        val appCtx = applicationContext
        Thread { Storage.autoClean(appCtx) }.start() // old temporary files go away by themselves
        Ui.styleBars(window)
        tab = getSharedPreferences("crsc_player", MODE_PRIVATE).getInt("libtab", 0).coerceIn(0, 4)
        // opened by another screen only to choose a file (for example the upscale screen): a tap returns the file
        pickMode = intent.getBooleanExtra(LibraryArgs.PICK, false)
        if (pickMode) tab = intent.getIntExtra(LibraryArgs.PICK_TAB, 0).coerceIn(0, 4)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
        }
        val pad = dp(this, 12)

        val head = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(pad, dp(this@LibraryActivity, 10), pad, 0)
        }
        titleTv = Ui.text(this, getString(R.string.lib_title), 22f, Ui.TEXT, true).apply {
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            letterSpacing = 0.01f
            setOnClickListener { goBack() }
        }
        head.addView(titleTv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        // three icons only (search, refresh, more); the rarer actions live in the menu behind the dots
        head.addView(Icons.button(this, Icons.SEARCH) { toggleSearch() })
        refreshBtn = Icons.button(this, Icons.REFRESH) { manualRefresh() }
        head.addView(refreshBtn)
        head.addView(Icons.button(this, Icons.MORE, Ui.TEXT) { moreMenu() })
        root.addView(head)

        val tabRow = LinearLayout(this).apply {
            setPadding(pad, dp(this@LibraryActivity, 10), pad, dp(this@LibraryActivity, 6))
        }
        tabViews = tabNameRes.mapIndexed { i, r ->
            TextView(this).apply {
                text = getString(r)
                textSize = 14f
                typeface = Ui.FONT
                maxLines = 1
                gravity = Gravity.CENTER
                setPadding(dp(this@LibraryActivity, 10), dp(this@LibraryActivity, 9), dp(this@LibraryActivity, 10), dp(this@LibraryActivity, 9))
                setOnClickListener { selectTab(i) }
            }
        }
        tabViews.forEachIndexed { i, v ->
            tabRow.addView(
                v,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i > 0) marginStart = dp(this@LibraryActivity, 6) }
            )
        }
        root.addView(ChipScroller(this, tabRow))

        // search box (opened with the magnifier at the top): filters what is shown by name; at the top level of a section it looks in all files
        searchEt = EditText(this).apply {
            setSingleLine()
            hint = getString(R.string.lib_search_hint)
            setTextColor(Ui.TEXT)
            setHintTextColor(Ui.MUTED)
            visibility = View.GONE
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) {
                    val t = s?.toString() ?: ""
                    if (t != query) {
                        query = t
                        refresh()
                    }
                }
            })
        }
        root.addView(searchEt, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(pad, 0, pad, dp(this@LibraryActivity, 4))
        })

        msg = Ui.text(this, "", 14f, Ui.MUTED).apply {
            gravity = Gravity.CENTER
            setPadding(pad * 2, pad, pad * 2, pad)
            visibility = View.GONE
        }
        root.addView(msg)
        allowBtn = Ui.text(this, getString(R.string.lib_allow), 15f, Ui.BG, true).apply {
            gravity = Gravity.CENTER
            background = Ui.gradient(dp(this@LibraryActivity, 14).toFloat())
            setPadding(dp(this@LibraryActivity, 20), dp(this@LibraryActivity, 12), dp(this@LibraryActivity, 20), dp(this@LibraryActivity, 12))
            visibility = View.GONE
            setOnClickListener { requestPermissions(Media.permissions(), REQ_PERM) }
        }
        root.addView(allowBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            bottomMargin = pad
        })

        grid = GridView(this).apply {
            setPadding(pad, 0, pad, pad)
            clipToPadding = false
            horizontalSpacing = dp(this@LibraryActivity, 8)
            verticalSpacing = dp(this@LibraryActivity, 10)
            selector = Ui.round(Color.TRANSPARENT, 0f)
            isVerticalScrollBarEnabled = false
        }
        grid.adapter = adapter
        // when the grid gets its real width (first layout, a turn, split screen) the tiles are asked for again, so none stays at the size of the moment before
        var lastGridW = 0
        grid.addOnLayoutChangeListener { _, l, _, r, _, _, _, _, _ ->
            val w = r - l
            if (w > 0 && w != lastGridW) {
                lastGridW = w
                grid.post { if (!isFinishing && !isDestroyed) adapter.notifyDataSetChanged() }
            }
        }
        grid.setOnItemClickListener { _, _, pos, _ -> cells.getOrNull(pos)?.let { onCell(it) } }
        grid.setOnItemLongClickListener { _, _, pos, _ ->
            cells.getOrNull(pos)?.let { onLong(it) }
            true
        }
        // swipe sideways on the list to move to the neighbouring section (Videos / Photos / Manga / GIF)
        val tabGd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null || selecting) return false
                val dx = e2.x - e1.x
                if (abs(vx) > 450f && abs(vx) > abs(vy) * 1.5f && abs(dx) > dp(this@LibraryActivity, 56)) {
                    swipeTab(if (dx < 0) 1 else -1)
                    return true
                }
                return false
            }
        })
        // pinch to change how many tiles fit in a row (folders and items are remembered separately)
        var pinch = 1f
        var lastSlide = 0L   // when a sideways slide between sections last happened: a pinch right after it is just a clumsy second finger
        val sg = android.view.ScaleGestureDetector(this, object : android.view.ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(d: android.view.ScaleGestureDetector): Boolean {
                pinch = 1f
                return true
            }

            override fun onScale(d: android.view.ScaleGestureDetector): Boolean {
                pinch *= d.scaleFactor
                return true
            }

            override fun onScaleEnd(d: android.view.ScaleGestureDetector) {
                if (swiping || android.os.SystemClock.uptimeMillis() - lastSlide < 900L) return
                val folders = openBucket == null && openCat == null
                // the column count is remembered per direction: five columns chosen lying down must not make the tiles tiny when the phone stands up
                val landNow = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
                val key = (if (folders) "cols_f" else "cols_i") + "_" + tab + (if (landNow) "_l" else "_p")
                val cur = grid.numColumns.coerceAtLeast(1)
                val next = when {
                    pinch > 1.3f -> cur - 1
                    pinch < 0.75f -> cur + 1
                    else -> cur
                }.coerceIn(1, 6)
                if (next != cur) {
                    getSharedPreferences("crsc_player", MODE_PRIVATE).edit().putInt(key, next).apply()
                    // never rebuild the grid in the middle of a touch event
                    grid.post { if (!isFinishing) runCatching { refresh() } }
                }
            }
        })
        var downX = 0f
        var downY = 0f
        var sideways = false
        val slop = android.view.ViewConfiguration.get(this).scaledTouchSlop
        grid.setOnTouchListener { _, ev ->
            sg.onTouchEvent(ev)
            if (!sg.isInProgress && ev.pointerCount < 2) tabGd.onTouchEvent(ev)
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = ev.x; downY = ev.y; sideways = false }
                MotionEvent.ACTION_MOVE -> if (!sideways && ev.pointerCount == 1 && !selecting && !sg.isInProgress) {
                    val dx = abs(ev.x - downX)
                    val dy = abs(ev.y - downY)
                    if (dx > slop * 2 && dx > dy * 1.6f) {
                        // a sideways slide: the list must not also scroll up / down (it ended up shifted), so it gets a cancel
                        sideways = true
                        lastSlide = android.os.SystemClock.uptimeMillis()
                        val c = MotionEvent.obtain(ev)
                        c.action = MotionEvent.ACTION_CANCEL
                        grid.onTouchEvent(c)
                        c.recycle()
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (sideways) {
                    lastSlide = android.os.SystemClock.uptimeMillis()
                    // a slower slide that is long enough also changes the section (the fast fling is handled above)
                    if (ev.actionMasked == MotionEvent.ACTION_UP && !swiping && abs(ev.x - downX) > dp(this@LibraryActivity, 90)) swipeTab(if (ev.x < downX) 1 else -1)
                }
            }
            sideways
        }
        root.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // selection bar (only while items are selected)
        bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Ui.CARD)
            setPadding(pad, dp(this@LibraryActivity, 8), pad, dp(this@LibraryActivity, 8))
            visibility = View.GONE
        }
        fun barIcon(kind: Int, desc: String?, onClick: () -> Unit) {
            val v = Icons.button(this, kind, Ui.TEXT) { onClick() }
            v.background = Ui.round(Ui.CHIP, dp(this@LibraryActivity, 12).toFloat())
            if (desc != null) v.contentDescription = desc
            bar.addView(v, LinearLayout.LayoutParams(0, dp(this@LibraryActivity, 44), 1f).apply {
                if (bar.childCount > 0) marginStart = dp(this@LibraryActivity, 8)
            })
        }
        // the selection bar: close, favourite, add to a category, share, delete, and a menu with the rest (the count is in the title)
        barIcon(Icons.CLOSE, null) { exitSelect() }
        barIcon(Icons.STAR, getString(R.string.lib_fav)) { toggleFavorite() }
        barIcon(Icons.TAG_PLUS, getString(R.string.lib_add_to)) { if (selected.isNotEmpty()) chooseCat(selected.toList()) }
        barIcon(Icons.SHARE, getString(R.string.share)) { if (selected.isNotEmpty()) Share.share(this, selected.map { Uri.parse(it) }) }
        barIcon(Icons.TRASH, getString(R.string.trash_delete_item)) { deleteSelected() }
        barIcon(Icons.MORE, null) { selectionMenu() }
        root.addView(bar)
        MiniPlayer.attach(this, root)

        setContentView(root)
        paintTabs()

        reload()
        if (!Media.granted(this)) requestPermissions(Media.permissions(), REQ_PERM)
    }

    @Suppress("unused")
    /** How many files a tab shows (what is hidden or only a double of another file is not counted); -1 = not counted (manga). */
    private fun tabCount(i: Int): Int {
        val l = when (i) { 0 -> videos; 1 -> photos; 3 -> gifs; 4 -> audios; else -> return -1 }
        val hs = LibStore.hidden(this)
        return l.count { x -> !x.dupe && x.uri.toString() !in hs && "f$i:${x.bucketId}" !in hs }
    }

    private fun paintTabs() {
        val r = dp(this, 12).toFloat()
        tabViews.forEachIndexed { i, v ->
            // the name, and after it a smaller number of files once the library is loaded
            val sb = android.text.SpannableStringBuilder(getString(tabNameRes[i]))
            val n = if (loaded) tabCount(i) else -1
            if (n > 0) {
                sb.append("  ")
                val at = sb.length
                sb.append(if (n >= 10_000) "${n / 1000}k" else n.toString())
                sb.setSpan(android.text.style.RelativeSizeSpan(0.78f), at, sb.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            v.text = sb
            if (i == tab) {
                v.background = Ui.gradient(r)
                v.setTextColor(Ui.BG)
                v.typeface = Ui.FONT_BOLD
            } else {
                v.background = Ui.round(Ui.CHIP, r)
                v.setTextColor(Ui.MUTED)
                v.typeface = Ui.FONT
            }
        }
    }

    /** [d] = +1 when the finger moved left. In a right-to-left layout the tabs are mirrored, so the direction flips. */
    private var swiping = false

    private fun swipeTab(d: Int) {
        if (swiping) return // a second swipe in the middle of the slide left the list shifted and half faded
        val rtl = grid.layoutDirection == View.LAYOUT_DIRECTION_RTL
        val n = tab + (if (rtl) -d else d)
        if (n !in 0..4) return
        swiping = true
        val w = grid.width.toFloat().coerceAtLeast(1f)
        grid.smoothScrollBy(0, 0) // stop a fling that is still running: it would go on scrolling the next section
        grid.animate().cancel()
        val settle = Runnable {
            swiping = false
            grid.translationX = 0f
            grid.translationY = 0f
            grid.alpha = 1f
            grid.requestLayout()
        }
        grid.animate().translationX(-d * w * 0.25f).alpha(0f).setDuration(90).withEndAction {
            if (isDestroyed) return@withEndAction
            selectTab(n)
            grid.translationX = d * w * 0.25f
            grid.animate().translationX(0f).alpha(1f).setDuration(150).withEndAction(settle).start()
        }.start()
        grid.postDelayed(settle, 700) // safety: whatever happened to the animation, the list ends up normal
    }

    private fun selectTab(i: Int) {
        if (tab == i && openBucket == null && openCat == null) return
        exitSelect(false)
        tab = i
        openBucket = null
        openCat = null
        openHist = false
        getSharedPreferences("crsc_player", MODE_PRIVATE).edit().putInt("libtab", i).apply()
        paintTabs()
        refresh()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == REQ_PERM) reload()
    }

    override fun onResume() {
        super.onResume()
        Ui.init(this)
        if (loaded) reload()
    }

    override fun onStart() {
        super.onStart()
        if (!observing) {
            observing = true
            runCatching {
                contentResolver.registerContentObserver(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, observer)
                contentResolver.registerContentObserver(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, observer)
            }
        }
    }

    override fun onStop() {
        if (observing) {
            observing = false
            runCatching { contentResolver.unregisterContentObserver(observer) }
        }
        ui.removeCallbacks(autoReload)
        super.onStop()
    }

    /**
     * Reads the phone's media index and the hand-added folders in the background.
     * [rescan] = also walk the hand-added folders again (otherwise their last scan is reused, it can be slow).
     */
    private fun reload(rescan: Boolean = false) {
        val mine = ++gen
        val granted = Media.granted(this)
        val old = customScans
        val flist = LibStore.folders(this)
        if (!loaded) showMsg(getString(R.string.lib_loading), Icons.REFRESH)
        spin(true)
        Thread {
            val v = if (granted) Media.queryVideos(this) else emptyList()
            val im = if (granted) Media.queryImages(this) else emptyList()
            val au = if (granted) Media.queryAudio(this) else emptyList()
            // stage 1: show the phone's own index at once (it is fast); the slow hand-added folders follow
            ui.post {
                if (isDestroyed || mine != gen) return@post
                val ocv = ArrayList<Media.Item>()
                val oci = ArrayList<Media.Item>()
                for (sc in old.values) {
                    ocv.addAll(sc.videos)
                    oci.addAll(sc.images)
                }
                Media.markDupes(v, ocv)
                Media.markDupes(im, oci)
                videos = (v + ocv).sortedByDescending { it.dateAdded }
                images = (im + oci).sortedByDescending { it.dateAdded }
                splitImages()
                audios = au
                loaded = true
                refresh()
            }
            // stage 2: hand-added folders are walked again every time (a new file there shows up right away)
            val scans = HashMap<String, Media.Scan>()
            for (f in flist) {
                scans[f.uri] = Media.scanTree(this, Uri.parse(f.uri), f.name)
            }
            val cv = ArrayList<Media.Item>()
            val ci = ArrayList<Media.Item>()
            for (sc in scans.values) {
                cv.addAll(sc.videos)
                ci.addAll(sc.images)
            }
            Media.markDupes(v, cv)
            Media.markDupes(im, ci)
            val allV = (v + cv).sortedByDescending { it.dateAdded }
            val allI = (im + ci).sortedByDescending { it.dateAdded }
            ui.post {
                if (isDestroyed || mine != gen) return@post
                customScans = scans
                videos = allV
                images = allI
                audios = au
                splitImages()
                loaded = true
                refresh()
                spin(false)
                if (rescan) Toast.makeText(this, getString(R.string.lib_updated), Toast.LENGTH_SHORT).show()
            }
        }.start()
    }

    private var spinning = false
    private fun spin(on: Boolean) {
        if (!::refreshBtn.isInitialized) return
        if (!on) {
            spinning = false
            refreshBtn.animate().cancel()
            refreshBtn.rotation = 0f
            return
        }
        if (spinning) return
        spinning = true
        val step = object : Runnable {
            override fun run() {
                if (!spinning || isDestroyed) return
                refreshBtn.animate().rotationBy(360f).setDuration(700).withEndAction(this).start()
            }
        }
        step.run()
    }

    /** 🔄: asks the phone to index new files first (that is what made new photos show up minutes late), then reloads. */
    private fun manualRefresh() {
        Toast.makeText(this, getString(R.string.lib_refreshing), Toast.LENGTH_SHORT).show()
        Thread {
            val paths = ArrayList<String>()
            runCatching {
                val root = Environment.getExternalStorageDirectory()
                for (name in listOf("DCIM", "Pictures", "Movies", "Download", "Documents", "Comics", "Manga", "Music")) {
                    walkForScan(java.io.File(root, name), 0, paths)
                }
                // top-level folders of the storage root too (manga / video folders are often created there)
                root.listFiles()?.forEach { d ->
                    if (d.isDirectory && !d.name.startsWith(".") && d.name != "Android") walkForScan(d, 0, paths)
                }
            }
            if (paths.isNotEmpty()) {
                runCatching { MediaScannerConnection.scanFile(applicationContext, paths.take(4000).toTypedArray(), null, null) }
            }
            ui.postDelayed({ if (!isDestroyed) reload(true) }, if (paths.isEmpty()) 0L else 900L)
        }.start()
    }

    private fun walkForScan(dir: java.io.File, depth: Int, out: MutableList<String>) {
        if (depth > 6 || out.size > 4000) return
        val kids = dir.listFiles() ?: return
        for (f in kids) {
            if (f.name.startsWith(".")) continue
            if (f.isDirectory) walkForScan(f, depth + 1, out)
            else {
                val ext = f.name.substringAfterLast('.', "").lowercase()
                if (ext in SCAN_EXT) out.add(f.absolutePath)
            }
        }
    }

    private fun splitImages() {
        val (g, p) = images.partition { it.name.endsWith(".gif", ignoreCase = true) }
        gifs = g
        photos = p
    }

    private fun srcList(): List<Media.Item> = when (tab) {
        0 -> videos
        1 -> photos
        2 -> images
        4 -> audios
        else -> gifs
    }

    /** A message in the middle of the screen with a large line icon above it (loading, no permission, nothing here yet). */
    private fun showMsg(s: String, icon: Int = -1) {
        msg.text = s
        val k = if (icon >= 0) icon else when (tab) { 0 -> Icons.FILM; 1 -> Icons.IMAGE; 2 -> Icons.BOOK; 3 -> Icons.IMAGE; else -> Icons.MUSIC }
        val d = LineIcon(k, Ui.MUTED)
        val sz = dp(this, 56)
        d.setBounds(0, 0, sz, sz)
        msg.setCompoundDrawables(null, d, null, null)
        msg.compoundDrawablePadding = dp(this, 12)
        msg.visibility = View.VISIBLE
    }

    private fun catName(c: LibStore.Category) = if (c.builtin) getString(R.string.lib_fav) else c.name

    /** How the videos of a folder are ordered: 0 name (as always), 1 newest, 2 oldest, 3 longest, 4 shortest, 5 biggest. Saved. */
    private var videoSort: Int
        get() = getSharedPreferences("lib_view", MODE_PRIVATE).getInt("vsort", 0).coerceIn(0, 5)
        set(v) { getSharedPreferences("lib_view", MODE_PRIVATE).edit().putInt("vsort", v).apply() }

    private fun byVideoSort(l: List<Media.Item>): List<Media.Item> = when (videoSort) {
        1 -> l.sortedByDescending { it.dateAdded }
        2 -> l.sortedBy { it.dateAdded }
        3 -> l.sortedByDescending { it.durationMs }
        4 -> l.sortedBy { if (it.durationMs > 0) it.durationMs else Long.MAX_VALUE }
        5 -> l.sortedByDescending { it.size }
        else -> l
    }

    /** How the photos of a folder are ordered: 0 newest (as always), 1 oldest, 2 name, 3 biggest file. Saved. */
    private var photoSort: Int
        get() = getSharedPreferences("lib_view", MODE_PRIVATE).getInt("psort", 0).coerceIn(0, 3)
        set(v) { getSharedPreferences("lib_view", MODE_PRIVATE).edit().putInt("psort", v).apply() }

    private fun byPhotoSort(l: List<Media.Item>): List<Media.Item> = when (photoSort) {
        1 -> l.sortedBy { it.dateAdded }
        2 -> l.sortedWith { a, b -> Media.natural(a.name, b.name) }
        3 -> l.sortedByDescending { it.size }
        else -> l
    }

    private fun photoSortDialog() {
        val names = arrayOf(R.string.psort_newest, R.string.psort_oldest, R.string.psort_name, R.string.psort_biggest).map { getString(it) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(R.string.psort_title)
            .setSingleChoiceItems(names, photoSort) { d, w -> photoSort = w; d.dismiss(); refresh() }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun sortFor(l: List<Media.Item>, bucket: Long?): List<Media.Item> = when {
        bucket != null && Media.isCustom(bucket) -> l.sortedWith { a, b -> Media.natural(a.path, b.path) }
        tab == 0 && videoSort != 0 -> byVideoSort(l)
        tab == 1 && photoSort != 0 -> byPhotoSort(l)
        tab != 1 -> l.sortedWith { a, b -> Media.natural(a.name, b.name) }
        else -> l
    }

    private fun videoSortDialog() {
        val names = arrayOf(R.string.vsort_name, R.string.vsort_newest, R.string.vsort_oldest, R.string.vsort_longest, R.string.vsort_shortest, R.string.vsort_biggest)
            .map { getString(it) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(R.string.vsort_title)
            .setSingleChoiceItems(names, videoSort) { d, w -> videoSort = w; d.dismiss(); refresh() }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    /** Rebuilds the grid for the current tab / folder / category. */
    private fun refresh() {
        msg.visibility = View.GONE
        allowBtn.visibility = View.GONE
        grid.visibility = View.VISIBLE
        val list = ArrayList<Cell>()
        val b = openBucket
        val ci = openCat
        if (loaded && b == null && ci == null && !openHist) paintTabs() // the numbers on the tabs follow what is shown (hide, new files)
        val full = srcList()
        val hs = LibStore.hidden(this)
        val src = if (showHidden) full else full.filter { x -> x.uri.toString() !in hs && "f$tab:${x.bucketId}" !in hs }
        favSet = if (tab < 2) LibStore.cat(this, if (tab == 0) LibStore.FAV_V else LibStore.FAV_P)?.items?.toHashSet() ?: emptySet() else emptySet()
        var real = 0

        if (ci != null) {
            val c = LibStore.cat(this, ci)
            if (c == null) {
                openCat = null
                openHist = false
                refresh()
                return
            }
            titleTv.text = "‹  " + catName(c)
            for (it in sortFor(src.filter { x -> c.items.contains(x.uri.toString()) }, null)) list.add(itemCell(it))
            real = list.size
        } else if (b != null) {
            titleTv.text = "‹  $openName"
            val items = if (Media.isCustom(b)) sortFor(src.filter { it.bucketId == b }, b)
                else Media.inFolder(src, b, byName = tab != 1).let { if (tab == 0 && videoSort != 0) byVideoSort(it) else if (tab == 1 && photoSort != 0) byPhotoSort(it) else it }
            for (it in items) list.add(itemCell(it))
            real = list.size
        } else if (openHist) {
            titleTv.text = "‹  " + getString(R.string.hist_title)
            for (e in histVisible(histKind())) {
                val sub = when (e.kind) {
                    0 -> fmtDur(e.pos) + " / " + fmtDur(e.total)
                    2 -> (e.ref.takeIf { it.isNotBlank() }?.let { "$it · " } ?: "") +
                        android.text.format.DateUtils.getRelativeTimeSpanString(e.time, System.currentTimeMillis(), android.text.format.DateUtils.MINUTE_IN_MILLIS)
                    else -> getString(R.string.manga_progress_fmt, e.pos.toInt() + 1, e.total.toInt())
                }
                list.add(Cell(e.title, sub, if (e.kind == 0) Uri.parse(e.id) else null, K_HENT, icon = if (e.kind == 2) "🎵" else "📚", hist = e))
                real++
            }
        } else if (showHidden) {
            titleTv.text = "‹  " + getString(R.string.lib_hidden_title)
            val hf = Media.folders(full).filter { "f$tab:${it.id}" in hs }
            for (f in hf) {
                list.add(Cell(f.name, "• " + getString(R.string.lib_items_fmt, f.count), f.cover, K_FOLDER, f, icon = "📁"))
                real++
            }
            if (tab != 2) {
                for (x in sortFor(full.filter { it.uri.toString() in hs }, null)) {
                    list.add(itemCell(x))
                    real++
                }
            }
        } else {
            titleTv.text = getString(R.string.lib_title)
            val hn = if (tab == 0 || tab == 2 || tab == 4) histVisible(histKind()).size else 0
            if (hn > 0) list.add(Cell(getString(R.string.hist_title), getString(R.string.lib_items_fmt, hn), null, K_HIST, icon = "🕘"))
            list.add(Cell(getString(R.string.net_title), getString(R.string.net_tile_sub), null, K_NET, icon = "🌐"))
            if (tab == 2) {
                list.add(Cell(getString(R.string.lib_open_cbz), "", null, K_CBZ, icon = "📚"))
            } else {
                if (src.isNotEmpty()) {
                    val allName = getString(when (tab) { 0 -> R.string.lib_all_videos; 3 -> R.string.lib_all_gifs; 4 -> R.string.lib_all_music; else -> R.string.lib_all_photos })
                    list.add(Cell(allName, getString(R.string.lib_items_fmt, src.size), src[0].uri, K_FOLDER, Media.Folder(Media.ALL, allName, src.size, src[0].uri, tab == 0 || tab == 4)))
                    real++
                }
                val cats = (if (tab == 4) emptyList() else LibStore.cats(this, tab))
                val strs = if (cats.isNotEmpty()) src.map { it.uri.toString() } else emptyList()
                for (c in cats) {
                    var n = 0
                    var cover: Uri? = null
                    for (i in src.indices) if (c.items.contains(strs[i])) {
                        n++
                        if (cover == null) cover = src[i].uri
                    }
                    val title = (if (c.builtin) "★ " else "") + catName(c)
                    list.add(Cell(title, getString(R.string.lib_items_fmt, n), cover, K_CAT, cat = c, icon = if (c.builtin) "⭐" else "🏷"))
                    real++
                }
            }
            val customList = LibStore.folders(this)
            val fl = ArrayList<Media.Folder>(Media.folders(src))
            val have = fl.map { it.id }.toHashSet()
            for (cf in customList) {
                if (cf.id in have) continue
                val sc = customScans[cf.uri]
                val hasAny = sc != null && (sc.videos.isNotEmpty() || sc.images.isNotEmpty())
                if (!hasAny && "f$tab:${cf.id}" !in hs) fl.add(Media.Folder(cf.id, cf.name, 0, null, tab == 0, cf.uri))
            }
            fl.sortWith { x, y -> Media.natural(x.name, y.name) }
            for (f in fl) {
                val custom = Media.isCustom(f.id)
                val sub = (if (custom) "• " else "") + getString(R.string.lib_items_fmt, f.count)
                list.add(Cell(f.name, sub, f.cover, K_FOLDER, f, icon = "📁"))
                real++
            }
            if (tab == 2) {
                // PDF / CBZ / CBR / ZIP files found inside the hand-added folders
                for (cf in customList) {
                    for (bk in customScans[cf.uri]?.books.orEmpty()) {
                        list.add(Cell(bk.first.substringAfterLast('/').substringBeforeLast('.'), cf.name, null, K_BOOK, icon = "📚", book = bk.second))
                        real++
                    }
                }
            }
        }

        // search filter
        val q = query.trim()
        if (q.isNotEmpty()) {
            if (b == null && ci == null && !openHist && !showHidden && tab != 2) {
                list.clear()
                for (x in sortFor(src.filter { it.name.contains(q, ignoreCase = true) }, null)) list.add(itemCell(x))
            } else {
                list.retainAll { it.title.contains(q, ignoreCase = true) }
            }
            real = list.size
        }

        cells = list
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val folderMode = b == null && ci == null
        val savedCols = getSharedPreferences("crsc_player", MODE_PRIVATE).getInt((if (folderMode) "cols_f" else "cols_i") + "_" + tab + (if (land) "_l" else "_p"), 0)
        val newCols = if (savedCols > 0) savedCols else if (folderMode) (if (land) 4 else 3) else (if (land) 5 else 3)
        if (grid.numColumns != newCols) {
            // recycled cells were measured for the old column width: drop them so tiles cannot overlap or crash the grid
            val first = grid.firstVisiblePosition
            grid.numColumns = newCols
            grid.adapter = adapter
            if (first > 0) grid.setSelection(first.coerceAtMost((cells.size - 1).coerceAtLeast(0)))
        }
        adapter.notifyDataSetChanged()

        val level = "$tab|$b|$ci"
        if (level != lastLevel) {
            // remember where the old level was scrolled to, and come back to the same place on return
            if (lastLevel.isNotEmpty()) {
                val first = grid.firstVisiblePosition
                val top = grid.getChildAt(0)?.top ?: 0
                scrollPos[lastLevel] = Pair(first, top)
            }
            lastLevel = level
            val saved = scrollPos[level]
            grid.post {
                if (saved != null) grid.setSelectionFromTop(saved.first, saved.second) else grid.setSelection(0)
            }
        }
        canNewCat = tab < 2 && b == null && ci == null && !showHidden

        if (!loaded) {
            showMsg(getString(R.string.lib_loading), Icons.REFRESH)
        } else if (folderMode && !Media.granted(this)) {
            showMsg(getString(R.string.lib_need_perm), Icons.LOCK)
            allowBtn.visibility = View.VISIBLE
        } else if (real == 0) {
            showMsg(getString(if (ci != null) R.string.lib_cat_empty else if (showHidden && folderMode) R.string.lib_hidden_empty else R.string.lib_empty))
        }
        updateBar()
    }

    private fun itemCell(it: Media.Item) =
        Cell(it.name.substringBeforeLast('.'), if (it.isVideo) fmtDur(it.durationMs) else "", it.uri, K_ITEM, item = it)

    // ---- taps ---------------------------------------------------------------------------------

    private fun onCell(c: Cell) {
        if (selecting) {
            c.item?.let { toggle(it) }
            return
        }
        when (c.kind) {
            K_CBZ -> {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                    .addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("*/*") // no type filter: providers report .cbz / .pdf in many different ways
                @Suppress("DEPRECATION")
                startActivityForResult(i, REQ_CBZ)
            }
            K_BOOK -> c.book?.let { startActivity(Intent(this, MangaActivity::class.java).setData(it).putExtra(MangaActivity.EXTRA_NAME, c.title)) }
            K_NET -> startActivity(Intent(this, NetActivity::class.java))
            K_HIST -> {
                openHist = true
                refresh()
            }
            K_HENT -> c.hist?.let { openHistory(it) }
            K_CAT -> {
                openCat = c.cat?.id
                openHist = false
                refresh()
            }
            K_FOLDER -> {
                val f = c.folder ?: return
                if (tab == 2) {
                    val tree = LibStore.folders(this).firstOrNull { it.id == f.id }?.uri
                    val i = Intent(this, MangaActivity::class.java).putExtra(MangaActivity.EXTRA_NAME, f.name)
                    if (tree != null) i.putExtra(MangaActivity.EXTRA_TREE, tree) else i.putExtra(MangaActivity.EXTRA_BUCKET, f.id)
                    startActivity(i)
                } else {
                    openBucket = f.id
                    openName = f.name
                    refresh()
                }
            }
            K_ITEM -> {
                val it = c.item ?: return
                if (pickMode) {
                    setResult(
                        RESULT_OK,
                        Intent().setData(it.uri).putExtra(LibraryArgs.NAME, it.name).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    )
                    finish()
                    return
                }
                val items = cells.mapNotNull { x -> x.item }
                val idx = items.indexOfFirst { x -> x.uri == it.uri }.coerceAtLeast(0)
                if (tab == 4) {
                    MusicPlayer.handoff = items.map { x -> MusicPlayer.Track(x.uri, x.name.substringBeforeLast('.'), "", x.durationMs) }
                    startActivity(Intent(this, AudioActivity::class.java).setData(it.uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                    return
                }
                val i = Intent(this, if (tab == 3) GifActivity::class.java else PlayerActivity::class.java)
                    .setData(it.uri)
                    .putExtra(PlayerArgs.FROM_LIB, true)
                    .putExtra(PlayerArgs.INDEX, idx)
                    .putStringArrayListExtra(PlayerArgs.LIST, ArrayList(items.map { x -> x.uri.toString() }))
                startActivity(i)
            }
        }
    }

    private fun onNewCat() {
        if (tab > 1) return
        askName(getString(R.string.lib_new_cat), "") { n ->
            LibStore.createCat(this, tab, n)
            refresh()
        }
    }

    /** Long-press a .cbz / .zip / .pdf tile: enhance all its pages into a new .cbz (runs in the background). */
    private fun bookMenu(title: String, uri: Uri) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(arrayOf(getString(R.string.batch_enhance_file), getString(R.string.trash_delete_item))) { _, w ->
                if (w == 1) {
                    TrashOps.confirmDelete(this, listOf(uri)) { reload() }
                    return@setItems
                }
                startActivity(
                    Intent(this, BatchActivity::class.java)
                        .putExtra(BatchActivity.X_SRC, uri.toString())
                        .putExtra(BatchActivity.X_NAME, title)
                        .putExtra(BatchActivity.X_MANGA, true)
                )
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun onLong(c: Cell) {
        val item = c.item
        when {
            item != null -> if (selecting) toggle(item) else startSelect(item)
            selecting -> Unit
            c.kind == K_CAT -> c.cat?.let { catMenu(it) }
            c.kind == K_FOLDER -> c.folder?.let { folderMenu(it) }
            c.kind == K_BOOK -> c.book?.let { bookMenu(c.title, it) }
            c.kind == K_HENT -> c.hist?.let { e ->
                AlertDialog.Builder(this)
                    .setMessage(e.title)
                    .setPositiveButton(R.string.hist_remove) { _, _ ->
                        History.remove(this, e.kind, e.id)
                        refresh()
                    }
                    .setNegativeButton(android.R.string.cancel, null)
                    .show()
            }
            c.kind == K_HIST -> AlertDialog.Builder(this)
                .setMessage(getString(R.string.hist_clear_confirm))
                .setPositiveButton(android.R.string.ok) { _, _ ->
                    History.clear(this, histKind())
                    refresh()
                }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        }
    }

    /** Continues a video or a manga from the history list (the player / reader jump to the saved spot by themselves). */
    /** The history kind of the open section: 0 videos, 1 manga, 2 songs. */
    private fun histKind(): Int = when (tab) { 2 -> 1; 4 -> 2; else -> 0 }

    /** The history of a kind without what was hidden: a hidden file, or a file of a hidden folder, must not show up here either (until "show hidden" is on). */
    private fun histVisible(kind: Int): List<History.Entry> {
        val all = History.list(this, kind)
        if (showHidden) return all
        val hs = LibStore.hidden(this)
        if (hs.isEmpty()) return all
        if (kind == 1) {
            // a manga entry is keyed by the reader's key: what was opened is in src / ref ("file" = the file's uri, "bucket" = the folder's id; "tree" = a folder picked outside the Library: cannot be hidden)
            return all.filter { e ->
                when (e.src) {
                    "file" -> e.ref !in hs
                    "bucket" -> "f2:${e.ref}" !in hs
                    else -> true
                }
            }
        }
        val t = if (kind == 2) 4 else 0
        val items = if (t == 4) audios else videos
        val bucket = HashMap<String, String>()
        for (x in items) bucket[x.uri.toString()] = x.bucketId.toString()
        return all.filter { e -> e.id !in hs && bucket[e.id]?.let { b -> "f$t:$b" in hs } != true }
    }

    private fun openHistory(e: History.Entry) {
        if (e.kind == 2) {
            // the songs of the history (newest first) are the list for Next / Previous, like the other lists of the Library
            MusicPlayer.handoff = histVisible(2).map { x -> MusicPlayer.Track(Uri.parse(x.id), x.title, x.ref, x.total) }
            startActivity(Intent(this, AudioActivity::class.java).setData(Uri.parse(e.id)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } else if (e.kind == 0) {
            startActivity(Intent(this, PlayerActivity::class.java).setData(Uri.parse(e.id)).putExtra(PlayerArgs.FROM_LIB, true))
        } else {
            val i = Intent(this, MangaActivity::class.java).putExtra(MangaActivity.EXTRA_NAME, e.title)
            when (e.src) {
                "tree" -> i.putExtra(MangaActivity.EXTRA_TREE, e.ref)
                "bucket" -> i.putExtra(MangaActivity.EXTRA_BUCKET, e.ref.toLongOrNull() ?: return)
                else -> i.data = Uri.parse(e.ref)
            }
            startActivity(i)
        }
    }

    // ---- selection ----------------------------------------------------------------------------

    private fun startSelect(it: Media.Item) {
        selecting = true
        selected.clear()
        selected.add(it.uri.toString())
        updateBar()
        adapter.notifyDataSetChanged()
    }

    private fun toggle(it: Media.Item) {
        val k = it.uri.toString()
        if (!selected.remove(k)) selected.add(k)
        if (selected.isEmpty()) exitSelect() else {
            updateBar()
            adapter.notifyDataSetChanged()
        }
    }

    private fun exitSelect(repaint: Boolean = true) {
        selecting = false
        selected.clear()
        bar.visibility = View.GONE
        if (repaint) {
            updateBar()
            adapter.notifyDataSetChanged()
        }
    }

    /** The rarer actions on the chosen files (the bar keeps the five that are used most). */
    private fun selectionMenu() {
        if (selected.isEmpty()) return
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        labels.add(getString(if (showHidden) R.string.lib_unhide else R.string.lib_hide)); acts.add { hideSelected() }
        if (tab == 0 || tab == 1 || tab == 3 || tab == 4) {
            labels.add(getString(if (tab == 1) R.string.batch_menu_short else R.string.lib_save_live)); acts.add { saveLive() }
        }
        labels.add(getString(R.string.fm_rename)); acts.add { renameSelected() }
        if (openCat != null) { labels.add(getString(R.string.lib_remove)); acts.add { removeSelectedFromCat() } }
        labels.add(getString(R.string.lib_select_all_long)); acts.add { selectAll() }
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.lib_selected_fmt, selected.size))
            .setItems(labels.toTypedArray()) { _, w -> acts[w]() }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun selectAll() {
        for (c in cells) c.item?.let { selected.add(it.uri.toString()) }
        updateBar()
        adapter.notifyDataSetChanged()
    }

    /** The bar's pencil button: renames the one chosen file. */
    private fun renameSelected() {
        if (selected.size != 1) {
            Toast.makeText(this, getString(R.string.rename_pick_one), Toast.LENGTH_SHORT).show()
            return
        }
        val u = Uri.parse(selected.first())
        val cur = runCatching { audioDisplayName(this, u) }.getOrNull()?.takeIf { it.isNotBlank() } ?: (u.lastPathSegment ?: "").substringAfterLast('/')
        TrashOps.renameDialog(this, u, cur) {
            exitSelect()
            reload()
        }
    }

    /** The bar's bin button: move the chosen files to the trash or delete them for good. */
    private fun deleteSelected() {
        if (selected.isEmpty()) {
            Toast.makeText(this, getString(R.string.batch_select_some), Toast.LENGTH_SHORT).show()
            return
        }
        TrashOps.confirmDelete(this, selected.map { Uri.parse(it) }) {
            exitSelect()
            reload()
        }
    }

    /** The bar's save button: pictures go to "Enhance to files"; videos / GIFs / songs are saved with the live settings of their section. */
    private fun saveLive() {
        if (selected.isEmpty()) {
            Toast.makeText(this, getString(R.string.batch_select_some), Toast.LENGTH_SHORT).show()
            return
        }
        when (tab) {
            1 -> enhanceSelected()
            0, 3 -> {
                if (selected.size != 1) {
                    Toast.makeText(this, getString(R.string.lib_live_one), Toast.LENGTH_LONG).show()
                    return
                }
                startActivity(
                    Intent(this, ExportActivity::class.java)
                        .setData(Uri.parse(selected.first()))
                        .putExtra(ExportActivity.X_LIVE, true)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                )
                exitSelect()
            }
            4 -> {
                val list = selected.toList()
                exitSelect()
                saveSongs(list)
            }
        }
    }

    /** Songs: the sound settings of the music player (equaliser, voice, bass ...) are baked into a new file, one after the other. */
    private fun saveSongs(list: List<String>) {
        val app = applicationContext
        AudioCfg.load(app)
        val params = AudioCfg.snapshot()
        Toast.makeText(this, getString(R.string.lib_songs_start_fmt, list.size), Toast.LENGTH_LONG).show()
        Thread {
            var ok = 0
            var bad = 0
            for (s in list) {
                val u = Uri.parse(s)
                val nm = runCatching {
                    app.contentResolver.query(u, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
                }.getOrNull()?.substringBeforeLast('.')?.ifBlank { null } ?: "song"
                val base = nm.replace(Regex("[\\\\/:*?\"<>|]"), "_") + "_sound"
                val r = AudioExport.run(app, u, base, params, java.util.concurrent.atomic.AtomicBoolean(false)) { }
                if (r.uri != null) ok++ else bad++
            }
            ui.post { Toast.makeText(app, app.getString(R.string.lib_songs_done_fmt, ok, bad), Toast.LENGTH_LONG).show() }
        }.start()
    }

    /** Photos tab: send the selected pictures to "Enhance to files". */
    private fun enhanceSelected() {
        if (selected.isEmpty()) {
            Toast.makeText(this, getString(R.string.batch_select_some), Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(
            Intent(this, BatchActivity::class.java)
                .putStringArrayListExtra(BatchActivity.X_URIS, ArrayList(selected))
                .putExtra(BatchActivity.X_NAME, openName.ifEmpty { "photos" })
                .putExtra(BatchActivity.X_MANGA, false)
        )
        exitSelect()
    }

    /** Long-press a folder (Photos / Manga): enhance every picture in it. */
    private fun enhanceFolder(f: Media.Folder, customTree: String?) {
        val manga = tab == 2
        val src = srcList()
        Thread {
            val list: List<Uri> = when {
                !manga -> Media.inFolder(src, f.id, false).map { it.uri }
                customTree != null -> Media.mangaPagesTree(this, Uri.parse(customTree))
                f.id == Media.ALL -> src.map { it.uri }
                else -> Media.mangaPages(this, f.id)
            }
            ui.post {
                if (isDestroyed) return@post
                if (list.isEmpty()) {
                    Toast.makeText(this, getString(R.string.lib_empty), Toast.LENGTH_SHORT).show()
                } else {
                    startActivity(
                        Intent(this, BatchActivity::class.java)
                            .putStringArrayListExtra(BatchActivity.X_URIS, ArrayList(list.map { it.toString() }))
                            .putExtra(BatchActivity.X_NAME, f.name)
                            .putExtra(BatchActivity.X_MANGA, manga)
                    )
                }
            }
        }.start()
    }

    private fun updateBar() {
        bar.visibility = if (selecting) View.VISIBLE else View.GONE
        if (selecting) titleTv.text = getString(R.string.lib_selected_fmt, selected.size)
    }

    // ---- optional PIN for the hidden section (long-press the eye icon to set / change / remove) ----

    private fun pinPrefs() = getSharedPreferences("crsc", Context.MODE_PRIVATE)
    private fun pinHash(p: String): String =
        java.security.MessageDigest.getInstance("SHA-256").digest(("crsc|" + p).toByteArray()).joinToString("") { "%02x".format(it) }
    private fun pinIsSet() = !pinPrefs().getString("hidden_pin", "").isNullOrEmpty()
    private fun pinMatches(p: String) = pinPrefs().getString("hidden_pin", "") == pinHash(p)

    private fun askPin(titleRes: Int, onOk: (String) -> Unit) {
        val et = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
            setSingleLine()
        }
        AlertDialog.Builder(this)
            .setTitle(getString(titleRes))
            .setView(et)
            .setPositiveButton(android.R.string.ok) { _, _ -> onOk(et.text.toString()) }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    /** The menu behind the three dots in the header: everything that used to be a row of small icons. */
    private fun moreMenu() {
        val ids = ArrayList<Int>()
        val labels = ArrayList<String>()
        if (canNewCat) { ids.add(0); labels.add(getString(R.string.lib_new_cat)) }
        ids.add(1); labels.add(getString(R.string.lib_menu_add_folder))
        if (tab == 0) { ids.add(6); labels.add(getString(R.string.vsort_title)) }
        if (tab == 1) { ids.add(7); labels.add(getString(R.string.psort_title)) }
        ids.add(2); labels.add(getString(if (showHidden) R.string.lib_menu_hidden_hide else R.string.lib_menu_hidden_show))
        ids.add(3); labels.add(getString(R.string.lib_pin_title))
        ids.add(4); labels.add(getString(R.string.lib_menu_open_player))
        ids.add(5); labels.add(getString(R.string.lib_menu_trash))
        AlertDialog.Builder(this).setItems(labels.toTypedArray()) { _, w ->
            when (ids[w]) {
                0 -> onNewCat()
                1 -> pickTree()
                2 -> toggleHidden()
                6 -> videoSortDialog()
                7 -> photoSortDialog()
                3 -> pinMenu()
                4 -> startActivity(Intent(this, PlayerActivity::class.java))
                5 -> startActivity(Intent(this@LibraryActivity, TrashActivity::class.java))
            }
        }.show()
    }

    private fun pinMenu() {
        val set = pinIsSet()
        val items = if (set) arrayOf(getString(R.string.lib_pin_change), getString(R.string.lib_pin_remove))
        else arrayOf(getString(R.string.lib_pin_set))
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.lib_pin_title))
            .setItems(items) { _, which ->
                if (set && which == 1) {
                    askPin(R.string.lib_pin_enter) { p ->
                        if (pinMatches(p)) {
                            pinPrefs().edit().remove("hidden_pin").apply()
                            Toast.makeText(this, getString(R.string.lib_pin_removed), Toast.LENGTH_SHORT).show()
                        } else Toast.makeText(this, getString(R.string.lib_pin_wrong), Toast.LENGTH_SHORT).show()
                    }
                } else {
                    val setNew = {
                        askPin(R.string.lib_pin_new) { p ->
                            if (p.length < 4) Toast.makeText(this, getString(R.string.lib_pin_short), Toast.LENGTH_SHORT).show()
                            else {
                                pinPrefs().edit().putString("hidden_pin", pinHash(p)).apply()
                                Toast.makeText(this, getString(R.string.lib_pin_saved), Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                    if (set) askPin(R.string.lib_pin_enter) { p -> if (pinMatches(p)) setNew() else Toast.makeText(this, getString(R.string.lib_pin_wrong), Toast.LENGTH_SHORT).show() }
                    else setNew()
                }
            }
            .show()
    }

    private fun toggleHidden() {
        if (!showHidden && pinIsSet()) {
            askPin(R.string.lib_pin_enter) { p ->
                if (pinMatches(p)) doToggleHidden() else Toast.makeText(this, getString(R.string.lib_pin_wrong), Toast.LENGTH_SHORT).show()
            }
            return
        }
        doToggleHidden()
    }

    private fun doToggleHidden() {
        exitSelect(false)
        showHidden = !showHidden
        openBucket = null
        openCat = null
        openHist = false
        refresh()
    }

    private fun hideSelected() {
        if (selected.isEmpty()) return
        val n = if (showHidden) LibStore.unhide(this, selected.toList()) else LibStore.hide(this, selected.toList())
        Toast.makeText(this, getString(if (showHidden) R.string.lib_unhidden_fmt else R.string.lib_hidden_fmt, n), Toast.LENGTH_SHORT).show()
        exitSelect(false)
        refresh()
    }

    private fun toggleFavorite() {
        if (selected.isEmpty() || tab > 1) return
        val id = if (tab == 0) LibStore.FAV_V else LibStore.FAV_P
        if (selected.all { favSet.contains(it) }) {
            LibStore.removeFrom(this, id, selected.toList())
            Toast.makeText(this, getString(R.string.lib_removed), Toast.LENGTH_SHORT).show()
        } else {
            val n = LibStore.addTo(this, id, selected.toList())
            Toast.makeText(this, getString(R.string.lib_added_fmt, n, getString(R.string.lib_fav)), Toast.LENGTH_SHORT).show()
        }
        exitSelect(false)
        refresh()
    }

    private fun removeSelectedFromCat() {
        val id = openCat ?: return
        LibStore.removeFrom(this, id, selected.toList())
        Toast.makeText(this, getString(R.string.lib_removed), Toast.LENGTH_SHORT).show()
        exitSelect(false)
        refresh()
    }

    // ---- categories ---------------------------------------------------------------------------

    /** "Add to…": pick a category (or make a new one) and put [uris] into it. */
    private fun chooseCat(uris: List<String>) {
        if (tab > 1 || uris.isEmpty()) return
        val cats = (if (tab == 4) emptyList() else LibStore.cats(this, tab))
        val labels = ArrayList<String>()
        for (c in cats) labels.add((if (c.builtin) "★ " else "# ") + catName(c))
        labels.add("+ " + getString(R.string.lib_new_cat) + "…")
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.lib_choose_cat))
            .setItems(labels.toTypedArray()) { _, which ->
                if (which < cats.size) addToCat(cats[which], uris)
                else askName(getString(R.string.lib_new_cat), "") { n -> addToCat(LibStore.createCat(this, tab, n), uris) }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun addToCat(c: LibStore.Category, uris: List<String>) {
        val n = LibStore.addTo(this, c.id, uris)
        Toast.makeText(this, getString(R.string.lib_added_fmt, n, catName(c)), Toast.LENGTH_SHORT).show()
        exitSelect(false)
        refresh()
    }

    private fun catMenu(c: LibStore.Category) {
        if (c.builtin) return
        val labels = arrayOf(getString(R.string.lib_rename), getString(R.string.lib_delete_cat))
        AlertDialog.Builder(this)
            .setTitle(c.name)
            .setItems(labels) { _, which ->
                if (which == 0) {
                    askName(getString(R.string.lib_rename), c.name) { n ->
                        LibStore.rename(this, c.id, n)
                        refresh()
                    }
                } else {
                    AlertDialog.Builder(this)
                        .setMessage(getString(R.string.lib_delete_cat_confirm_fmt, c.name))
                        .setPositiveButton(android.R.string.ok) { _, _ ->
                            LibStore.delete(this, c.id)
                            refresh()
                        }
                        .setNegativeButton(android.R.string.cancel, null)
                        .show()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun askName(title: String, def: String, ok: (String) -> Unit) {
        val input = EditText(this).apply {
            setSingleLine()
            setText(def)
            setSelection(text.length)
            hint = getString(R.string.lib_cat_name_hint)
        }
        val box = LinearLayout(this).apply { setPadding(dp(this@LibraryActivity, 20), dp(this@LibraryActivity, 8), dp(this@LibraryActivity, 20), 0) }
        box.addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val n = input.text.toString().trim().take(40)
                if (n.isNotEmpty()) ok(n)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    // ---- folders added by hand ----------------------------------------------------------------

    private fun pickTree() {
        AlertDialog.Builder(this)
            .setItems(arrayOf(getString(R.string.lib_pick_app), getString(R.string.lib_pick_system))) { _, w ->
                if (w == 0) {
                    FolderPicker.show(this) { dir ->
                        val key = Uri.fromFile(dir).toString()
                        if (LibStore.addFolder(this, key, dir.name.ifEmpty { dir.path })) {
                            Toast.makeText(this, getString(R.string.lib_folder_added_fmt, dir.name), Toast.LENGTH_SHORT).show()
                            reload()
                        } else {
                            Toast.makeText(this, getString(R.string.lib_folder_exists), Toast.LENGTH_SHORT).show()
                        }
                    }
                } else pickSystemTree()
            }
            .show()
    }

    private fun pickSystemTree() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
        )
        @Suppress("DEPRECATION")
        startActivityForResult(i, REQ_TREE)
    }

    private fun folderMenu(f: Media.Folder) {
        val src = srcList()
        val custom = LibStore.folders(this).firstOrNull { it.id == f.id }
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        if (tab < 2 && f.count > 0) {
            labels.add(getString(R.string.lib_add_all_to))
            acts.add { chooseCat(Media.inFolder(src, f.id, false).map { it.uri.toString() }) }
        }
        if ((tab == 1 || tab == 2) && f.count > 0) {
            labels.add(getString(R.string.batch_menu_folder))
            acts.add { enhanceFolder(f, custom?.uri) }
        }
        if (custom != null) {
            labels.add(getString(R.string.lib_folder_remove))
            acts.add {
                AlertDialog.Builder(this)
                    .setMessage(getString(R.string.lib_folder_remove_confirm_fmt, custom.name))
                    .setPositiveButton(android.R.string.ok) { _, _ ->
                        LibStore.removeFolder(this, custom.uri)
                        runCatching { contentResolver.releasePersistableUriPermission(Uri.parse(custom.uri), Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                        reload()
                    }
                    .setNegativeButton(android.R.string.cancel, null)
                    .show()
            }
        }
        if (f.id != Media.ALL) {
            val key = "f$tab:${f.id}"
            val isH = LibStore.hidden(this).contains(key)
            labels.add(getString(if (isH) R.string.lib_unhide_folder else R.string.lib_hide_folder))
            acts.add {
                if (isH) LibStore.unhide(this, listOf(key)) else LibStore.hide(this, listOf(key))
                refresh()
            }
        }
        if (labels.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle(f.name)
            .setItems(labels.toTypedArray()) { _, which -> acts[which]() }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (TrashOps.handleResult(req, res)) return
        val u = data?.data
        if (res != RESULT_OK || u == null) return
        if (req == REQ_CBZ) {
            runCatching { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } // so History can reopen it
            startActivity(Intent(this, MangaActivity::class.java).setData(u))
        } else if (req == REQ_TREE) {
            runCatching { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            val name = Media.treeName(this, u)
            if (LibStore.addFolder(this, u.toString(), name)) {
                Toast.makeText(this, getString(R.string.lib_folder_added_fmt, name), Toast.LENGTH_SHORT).show()
                reload()
            } else {
                Toast.makeText(this, getString(R.string.lib_folder_exists), Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---- navigation ---------------------------------------------------------------------------

    private fun toggleSearch() {
        if (searchEt.visibility == View.VISIBLE) {
            searchEt.setText("")
            searchEt.visibility = View.GONE
            getSystemService(android.view.inputmethod.InputMethodManager::class.java)?.hideSoftInputFromWindow(searchEt.windowToken, 0)
        } else {
            searchEt.visibility = View.VISIBLE
            searchEt.requestFocus()
            getSystemService(android.view.inputmethod.InputMethodManager::class.java)?.showSoftInput(searchEt, 0)
        }
    }

    private fun goBack(): Boolean {
        if (selecting) {
            exitSelect()
            return true
        }
        if (openBucket != null || openCat != null) {
            openBucket = null
            openCat = null
            openHist = false
            refresh()
            return true
        }
        return false
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!goBack()) {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (loaded) refresh()
    }

    override fun onDestroy() {
        pool.shutdownNow()
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun fmtDur(ms: Long): String {
        if (ms <= 0) return ""
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec) else String.format(Locale.US, "%d:%02d", m, sec)
    }

    // ---- grid adapter -------------------------------------------------------------------------

    private val adapter = object : BaseAdapter() {
        override fun getCount() = cells.size
        override fun getItem(position: Int): Any = cells[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val cols = grid.numColumns.coerceAtLeast(1)
            // before the first layout (or in the middle of a turn) the grid reports width 0: use the screen width then, so the thumbnails are not asked for in the smallest size
            val gridW = if (grid.width > 0) grid.width else resources.displayMetrics.widthPixels
            val colW = ((gridW - grid.paddingLeft - grid.paddingRight - (cols - 1) * grid.horizontalSpacing) / cols).coerceAtLeast(dp(this@LibraryActivity, 60))
            val h = (convertView?.tag as? Holder) ?: makeHolder()
            val c = cells.getOrNull(position) ?: return h.box
            val special = c.kind == K_CBZ || c.kind == K_HIST || c.kind == K_NET
            val isVid = c.item?.isVideo == true
            val key = c.item?.uri?.toString()
            val sel = key != null && selected.contains(key)

            h.name.text = c.title
            h.name.setTextColor(if (special) Ui.ACCENT else Ui.TEXT)
            h.sub.text = c.sub
            h.sub.visibility = if (c.sub.isEmpty() || isVid) View.GONE else View.VISIBLE
            h.badge.text = if (isVid) c.sub else ""
            h.badge.visibility = if (isVid && c.sub.isNotEmpty()) View.VISIBLE else View.GONE
            h.iv.alpha = if (sel) 0.5f else 1f

            h.star.visibility = if (key != null && favSet.contains(key)) View.VISIBLE else View.GONE
            if (c.item != null && selecting) {
                h.check.visibility = View.VISIBLE
                if (sel) Icons.glyph(h.check, Icons.CHECK, Ui.BG, 14) else { h.check.text = ""; Icons.clear(h.check) }
                h.check.setTextColor(Ui.BG)
                h.check.background = if (sel) Ui.round(Ui.ACCENT, dp(this@LibraryActivity, 10).toFloat())
                else Ui.round(Color.parseColor("#80000000"), dp(this@LibraryActivity, 10).toFloat(), Color.WHITE, dp(this@LibraryActivity, 1))
            } else {
                h.check.visibility = View.GONE
            }

            h.iv.setImageDrawable(null)
            h.key = null
            val u = c.thumb
            // a comic file (or a comic in the history) shows its first page, like a thumbnail
            val bookUri: Uri? = if (special) null else c.book
                ?: c.hist?.takeIf { it.kind == 1 && it.src == "file" }?.let { runCatching { Uri.parse(it.ref) }.getOrNull() }
            if (bookUri != null) {
                val bk = bookUri.toString()
                h.key = bk
                val hit = BookCovers.cached(bookUri)
                if (hit != null) {
                    h.icon.visibility = View.GONE
                    h.iv.scaleType = ImageView.ScaleType.CENTER_CROP
                    h.iv.setImageBitmap(hit)
                } else {
                    // the book icon until the cover is ready (a file without a readable first page keeps it)
                    h.iv.scaleType = ImageView.ScaleType.CENTER
                    val ik = Icons.fromEmoji(c.icon)
                    h.icon.text = ""
                    h.icon.background = if (ik >= 0) LineIcon(ik, Ui.ACCENT) else null
                    h.icon.visibility = if (ik >= 0) View.VISIBLE else View.GONE
                    BookCovers.load(this@LibraryActivity, bookUri) { b ->
                        if (b != null && h.key == bk) {
                            h.icon.visibility = View.GONE
                            h.iv.scaleType = ImageView.ScaleType.CENTER_CROP
                            h.iv.setImageBitmap(b)
                        }
                    }
                }
            } else if (u == null || special) {
                h.iv.scaleType = ImageView.ScaleType.CENTER
                val ik = Icons.fromEmoji(c.icon)
                h.icon.text = ""
                h.icon.background = if (ik >= 0) LineIcon(ik, Ui.ACCENT) else null
                h.icon.visibility = if (ik >= 0) View.VISIBLE else View.GONE
            } else {
                h.icon.visibility = View.GONE
                h.iv.scaleType = ImageView.ScaleType.CENTER_CROP
                val k = u.toString()
                h.key = k
                val hit = cache.get(k)
                if (hit != null) {
                    h.iv.setImageBitmap(hit)
                } else {
                    pool.execute {
                        val bmp = Media.thumb(this@LibraryActivity, u, colW.coerceIn(120, 480)) ?: return@execute
                        cache.put(k, bmp)
                        ui.post { if (h.key == k) h.iv.setImageBitmap(bmp) }
                    }
                }
            }
            return h.box
        }

        private fun makeHolder(): Holder {
            val ctx = this@LibraryActivity
            val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            // a square cell whose size comes only from the column width the grid hands out: it can never end up smaller
            // (or taller) than its neighbours, whatever the grid's own width was a moment ago
            val frame = object : FrameLayout(ctx) {
                override fun onMeasure(w: Int, h: Int) {
                    super.onMeasure(w, w)
                }
            }
            val iv = ImageView(ctx).apply {
                background = Ui.round(Ui.CHIP, dp(ctx, 8).toFloat())
                outlineProvider = ViewOutlineProvider.BACKGROUND
                clipToOutline = true
            }
            frame.addView(iv)
            val icon = Ui.text(ctx, "", 26f, Ui.ACCENT).apply { visibility = View.GONE }
            frame.addView(icon, FrameLayout.LayoutParams(dp(ctx, 44), dp(ctx, 44), Gravity.CENTER))
            val badge = Ui.text(ctx, "", 11f, Color.WHITE, true).apply {
                setPadding(dp(ctx, 5), dp(ctx, 1), dp(ctx, 5), dp(ctx, 1))
                background = Ui.round(Color.parseColor("#B3000000"), dp(ctx, 5).toFloat())
            }
            frame.addView(badge, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END).apply {
                setMargins(0, 0, dp(ctx, 5), dp(ctx, 5))
            })
            val check = Ui.text(ctx, "", 13f, Ui.BG, true).apply {
                gravity = Gravity.CENTER
                visibility = View.GONE
            }
            frame.addView(check, FrameLayout.LayoutParams(dp(ctx, 22), dp(ctx, 22), Gravity.TOP or Gravity.START).apply {
                setMargins(dp(ctx, 5), dp(ctx, 5), 0, 0)
            })
            val star = Ui.text(ctx, "", 15f, Color.parseColor("#FACC15"), true).apply {
                setShadowLayer(4f, 0f, 0f, Color.BLACK)
                visibility = View.GONE
                Icons.glyph(this, Icons.STAR_FILL, Color.parseColor("#FACC15"), 17)
            }
            frame.addView(star, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END).apply {
                setMargins(0, dp(ctx, 3), dp(ctx, 6), 0)
            })
            box.addView(frame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            val name = Ui.text(ctx, "", 13f, Ui.TEXT).apply {
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
            }
            box.addView(name, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(ctx, 4) })
            val sub = Ui.text(ctx, "", 11f, Ui.MUTED)
            box.addView(sub)
            val h = Holder(box, iv, icon, badge, check, star, name, sub)
            box.tag = h
            return h
        }
    }

    private companion object {
        val SCAN_EXT = setOf(
            "jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif", "avif",
            "mp4", "mkv", "webm", "avi", "mov", "m4v", "3gp", "ts", "flv", "wmv", "mpg", "mpeg"
        )
        const val REQ_PERM = 31
        const val REQ_CBZ = 32
        const val REQ_TREE = 33

        const val K_FOLDER = 0
        const val K_ITEM = 1
        const val K_CAT = 2
        const val K_CBZ = 3
        const val K_HIST = 4
        const val K_HENT = 5
        const val K_NET = 6
        const val K_BOOK = 7
    }
}

/** Extras for opening [LibraryActivity] as a file chooser (returns the tapped video / GIF as the result's data). */
object LibraryArgs {
    const val PICK = "app.clearoverlay.LIB_PICK"
    const val PICK_TAB = "app.clearoverlay.LIB_PICK_TAB"
    const val NAME = "app.clearoverlay.LIB_NAME"
}
