package app.clearoverlay

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Smart auto-fix for photos. Classic image analysis (no model, instant, fully offline): it measures the photo's
 * colour balance and brightness range, then applies white balance + levels + a gentle shadow lift (or highlight
 * pull-down) with one look-up table per channel. Returns the SAME bitmap when the photo already looks balanced.
 */
object Enhance {
    fun auto(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        if (w < 2 || h < 2) return src
        val step = max(1, sqrt(w.toDouble() * h / 150_000.0).toInt())
        val row = IntArray(w)

        // pass 1: channel means (gray-world white balance, applied only partly)
        val sum = DoubleArray(3)
        var n = 0
        var y = 0
        while (y < h) {
            src.getPixels(row, 0, w, 0, y, w, 1)
            var x = 0
            while (x < w) {
                val c = row[x]
                sum[0] += ((c shr 16) and 0xFF).toDouble()
                sum[1] += ((c shr 8) and 0xFF).toDouble()
                sum[2] += (c and 0xFF).toDouble()
                n++
                x += step
            }
            y += step
        }
        if (n == 0) return src
        val mean = DoubleArray(3) { sum[it] / n }
        val gray = (mean[0] + mean[1] + mean[2]) / 3.0
        val gain = DoubleArray(3) { i -> (1.0 + 0.6 * (gray / max(mean[i], 1.0) - 1.0)).coerceIn(0.85, 1.2) }

        // pass 2: brightness histogram after white balance
        val hist = IntArray(256)
        y = 0
        while (y < h) {
            src.getPixels(row, 0, w, 0, y, w, 1)
            var x = 0
            while (x < w) {
                val c = row[x]
                val r = min(255.0, ((c shr 16) and 0xFF) * gain[0])
                val g = min(255.0, ((c shr 8) and 0xFF) * gain[1])
                val b = min(255.0, (c and 0xFF) * gain[2])
                hist[(0.299 * r + 0.587 * g + 0.114 * b).toInt().coerceIn(0, 255)]++
                x += step
            }
            y += step
        }
        var acc = 0
        var lo = 0
        for (i in 0..255) {
            acc += hist[i]
            if (acc >= n * 0.004) { lo = i; break }
        }
        acc = 0
        var hi = 255
        for (i in 0..255) {
            acc += hist[i]
            if (acc >= n * 0.996) { hi = i; break }
        }
        lo = min(lo, 45)
        hi = max(hi, 195)
        val span = (hi - lo).toDouble()

        var mSum = 0.0
        for (i in 0..255) mSum += hist[i] * ((i - lo) / span).coerceIn(0.0, 1.0)
        val m = (mSum / n).coerceIn(0.02, 0.98)
        val raw = when {
            m < 0.40 -> ln(0.44) / ln(m) // dark photo: lift the mid-tones
            m > 0.68 -> ln(0.58) / ln(m) // very bright photo: pull them down a little
            else -> 1.0
        }
        val gamma = (1.0 + 0.7 * (raw - 1.0)).coerceIn(0.65, 1.2)

        val untouched = gain.all { abs(it - 1.0) < 0.02 } && lo <= 3 && hi >= 252 && abs(gamma - 1.0) < 0.03
        if (untouched) return src

        val lut = Array(3) { c ->
            IntArray(256) { i ->
                val v = ((i * gain[c] - lo) / span).coerceIn(0.0, 1.0)
                (v.pow(gamma) * 255.0 + 0.5).toInt().coerceIn(0, 255)
            }
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        for (yy in 0 until h) {
            src.getPixels(row, 0, w, 0, yy, w, 1)
            for (x in 0 until w) {
                val c = row[x]
                row[x] = (c and 0xFF000000.toInt()) or
                    (lut[0][(c shr 16) and 0xFF] shl 16) or
                    (lut[1][(c shr 8) and 0xFF] shl 8) or
                    lut[2][c and 0xFF]
            }
            out.setPixels(row, 0, w, 0, yy, w, 1)
        }
        return out
    }
}
