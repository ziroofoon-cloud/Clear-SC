package app.clearoverlay

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Smart auto-fix for photos. Classic image analysis (no model, instant, fully offline): it measures the photo's
 * colour balance and brightness range, then applies white balance + levels + a gentle shadow lift (or highlight
 * pull-down) with one look-up table per channel. Returns the SAME bitmap when the photo already looks balanced.
 */
object Enhance {
    fun auto(src: Bitmap, level: Float = 1f): Bitmap {
        val w = src.width
        val h = src.height
        if (w < 2 || h < 2) return src
        val step = max(1, sqrt(w.toDouble() * h / 150_000.0).toInt())
        // a grid sample of the photo, measured by the same analysis as the live Smart fix (black bars, colourful pictures and bright skies are handled there)
        val sw = (w + step - 1) / step
        val sh = (h + step - 1) / step
        val px = IntArray(sw * sh)
        val row = IntArray(w)
        var k = 0
        var y = 0
        while (y < h) {
            src.getPixels(row, 0, w, 0, y, w, 1)
            var x = 0
            while (x < w) { px[k++] = row[x]; x += step }
            y += step
        }
        val m = (SmartFix.measure(px, sw) ?: return src).scaled(level)
        val lo255 = m.lo * 255.0
        val hi255 = (m.lo + m.span) * 255.0
        val untouched = m.gain.all { abs(it - 1.0) < 0.02 } && lo255 <= 3.0 && hi255 >= 252.0 && abs(m.gamma - 1.0) < 0.03 && m.sat < 0.02f
        if (untouched) return src
        val span = m.span.toDouble()
        val lut = Array(3) { c ->
            IntArray(256) { i ->
                val v = ((i * m.gain[c] / 255.0 - m.lo) / span).coerceIn(0.0, 1.0)
                var y = v.pow(m.gamma.toDouble())
                if (m.gamma < 1f) { // lifting dark pictures: the bright end is kept (it is not washed out)
                    val t = ((v - 0.55) / 0.45).coerceIn(0.0, 1.0).let { it * it * (3.0 - 2.0 * it) }
                    y = y * (1.0 - t) + v * t
                }
                (y * 255.0 + 0.5).toInt().coerceIn(0, 255)
            }
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        for (yy in 0 until h) {
            src.getPixels(row, 0, w, 0, yy, w, 1)
            for (x in 0 until w) {
                val c = row[x]
                var r = lut[0][(c shr 16) and 0xFF]
                var g = lut[1][(c shr 8) and 0xFF]
                var b = lut[2][c and 0xFF]
                if (m.sat > 0.01f) { // a dull picture: the weak colours are lifted, the strong ones hardly (like "Vibrance")
                    val mx = max(r, max(g, b)); val mn = min(r, min(g, b))
                    val l = 0.299f * r + 0.587f * g + 0.114f * b
                    val k = 1f + m.sat * (1f - (mx - mn) / 255f)
                    r = (l + (r - l) * k + 0.5f).toInt().coerceIn(0, 255)
                    g = (l + (g - l) * k + 0.5f).toInt().coerceIn(0, 255)
                    b = (l + (b - l) * k + 0.5f).toInt().coerceIn(0, 255)
                }
                row[x] = (c and 0xFF000000.toInt()) or (r shl 16) or (g shl 8) or b
            }
            out.setPixels(row, 0, w, 0, yy, w, 1)
        }
        return out
    }
}

/**
 * Smart fix for moving pictures and the live screen: the same analysis as [Enhance.auto] (gray-world white balance, levels,
 * shadow lift / highlight pull-down) but on a tiny copy of the frame, giving numbers for a GPU pass instead of a new bitmap.
 */
object SmartFix {
    /** [sat] = lift of weak colours (0 = none) for a dull, washed-out picture. */
    class Params(val gain: FloatArray, val lo: Float, val span: Float, val gamma: Float, val sat: Float = 0f) {
        /** The same correction at [k] of its strength (0 = none, 1 = as measured). */
        fun scaled(k: Float): Params {
            if (k >= 0.999f) return this
            val q = k.coerceIn(0f, 1f)
            return Params(FloatArray(3) { 1f + (gain[it] - 1f) * q }, lo * q, 1f + (span - 1f) * q, 1f + (gamma - 1f) * q, sat * q)
        }

        companion object {
            val NONE = Params(floatArrayOf(1f, 1f, 1f), 0f, 1f, 1f)
        }
    }

    /** Black bars (letterbox / pillarbox) at the edges of a frame of [w] pixels per row: rows / columns whose brightest pixel is nearly black. */
    private fun barRange(px: IntArray, w: Int, h: Int, rows: Boolean): IntArray {
        val n = if (rows) h else w
        fun dark(i: Int): Boolean {
            var mx = 0
            if (rows) for (x in 0 until w) { val c = px[i * w + x]; mx = max(mx, max((c shr 16) and 0xFF, max((c shr 8) and 0xFF, c and 0xFF))) }
            else for (y in 0 until h) { val c = px[y * w + i]; mx = max(mx, max((c shr 16) and 0xFF, max((c shr 8) and 0xFF, c and 0xFF))) }
            return mx <= 14
        }
        var a = 0
        while (a < n && dark(a)) a++
        var b = n
        while (b > a && dark(b - 1)) b--
        // a frame that is (nearly) all dark is not "bars": use all of it
        return if (b - a < n * 0.4) intArrayOf(0, n) else intArrayOf(a, b)
    }

    /**
     * [px] = packed 0xRRGGBB pixels of a small copy of the frame, [w] = pixels per row (0 = unknown: no bar detection); null when it is empty.
     * Compared with a plain gray-world measure: black bars at the edges are left out (they pulled the picture towards "too dark"),
     * near-gray pixels count most for the white balance (a green field or a blue sky is not a colour cast; the more colourful the picture, the
     * weaker the balance), the balance keeps the brightness, and the brightness target uses the median as well as the mean (a small
     * bright window does not make the rest look "bright enough").
     */
    fun measure(px: IntArray, w: Int = 0): Params? {
        if (px.isEmpty()) return null
        val h = if (w > 0) px.size / w else 0
        var r0 = 0; var r1 = h; var c0 = 0; var c1 = w
        if (w > 0 && h >= 4 && w >= 4) {
            val rr = barRange(px, w, h, true); r0 = rr[0]; r1 = rr[1]
            val cc = barRange(px, w, h, false); c0 = cc[0]; c1 = cc[1]
        }
        val region: IntArray = if (w > 0 && h >= 4 && (r0 > 0 || r1 < h || c0 > 0 || c1 < w)) {
            val o = IntArray((r1 - r0) * (c1 - c0))
            var q = 0
            for (y in r0 until r1) for (x in c0 until c1) o[q++] = px[y * w + x]
            o
        } else px
        val n = region.size
        if (n == 0) return null
        val sum = DoubleArray(3)
        var wsum = 0.0
        var sSum = 0.0
        var sN = 0
        for (c in region) {
            val r = ((c shr 16) and 0xFF).toDouble()
            val g = ((c shr 8) and 0xFF).toDouble()
            val b = (c and 0xFF).toDouble()
            val mx = max(r, max(g, b))
            val mn = min(r, min(g, b))
            val sat = if (mx > 0.0) (mx - mn) / mx else 0.0
            val l = 0.299 * r + 0.587 * g + 0.114 * b
            var wt = (1.0 - sat).coerceAtLeast(0.05).let { it * it }
            if (l < 12.0 || l > 245.0) wt *= 0.3 // black / clipped white say nothing about the light colour
            else { sSum += sat; sN++ }
            sum[0] += r * wt; sum[1] += g * wt; sum[2] += b * wt
            wsum += wt
        }
        if (wsum <= 1e-6) return Params.NONE
        val mean = DoubleArray(3) { sum[it] / wsum }
        val gray = (mean[0] + mean[1] + mean[2]) / 3.0
        val conf = (wsum / n).coerceIn(0.45, 1.0)
        val strength = 0.7 * conf
        val g0 = DoubleArray(3) { i -> 1.0 + strength * (gray / max(mean[i], 1.0) - 1.0) }
        val lg = 0.299 * g0[0] + 0.587 * g0[1] + 0.114 * g0[2]
        val gain = DoubleArray(3) { i -> (g0[i] / lg).coerceIn(0.85, 1.2) } // same brightness: only the colour moves
        val hist = IntArray(256)
        for (c in region) {
            val r = min(255.0, ((c shr 16) and 0xFF) * gain[0])
            val g = min(255.0, ((c shr 8) and 0xFF) * gain[1])
            val b = min(255.0, (c and 0xFF) * gain[2])
            hist[(0.299 * r + 0.587 * g + 0.114 * b).toInt().coerceIn(0, 255)]++
        }
        var acc = 0
        var lo = 0
        for (i in 0..255) {
            acc += hist[i]
            if (acc >= n * 0.004) { lo = i; break }
        }
        acc = 0
        var hi = 255
        for (i in 0..255) {
            acc += hist[i]
            if (acc >= n * 0.996) { hi = i; break }
        }
        lo = min(lo, 45)
        hi = max(hi, 195)
        val span = (hi - lo).toDouble()
        var mSum = 0.0
        for (i in 0..255) mSum += hist[i] * ((i - lo) / span).coerceIn(0.0, 1.0)
        var med = 128
        acc = 0
        for (i in 0..255) { acc += hist[i]; if (acc * 2 >= n) { med = i; break } }
        val mean01 = mSum / n
        val med01 = ((med - lo) / span).coerceIn(0.0, 1.0)
        val m = (0.5 * mean01 + 0.5 * med01).coerceIn(0.02, 0.98)
        val raw = when {
            m < 0.40 -> ln(0.44) / ln(m)
            m > 0.68 -> ln(0.58) / ln(m)
            else -> 1.0
        }
        val gamma = (1.0 + 0.7 * (raw - 1.0)).coerceIn(0.65, 1.2)
        // a dull (washed-out, grey) picture gets its weak colours lifted; a colourful one is left alone, and so is a black-and-white one
        val ms = if (sN > 0) sSum / sN else 0.2
        val satLift = 0.30 * ((0.28 - ms) / 0.28).coerceIn(0.0, 1.0) * ((ms - 0.04) / 0.06).coerceIn(0.0, 1.0)
        return Params(floatArrayOf(gain[0].toFloat(), gain[1].toFloat(), gain[2].toFloat()), (lo / 255.0).toFloat(), (span / 255.0).toFloat().coerceAtLeast(0.2f), gamma.toFloat(), satLift.toFloat())
    }
}
