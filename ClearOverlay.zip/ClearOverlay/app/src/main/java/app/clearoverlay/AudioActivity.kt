package app.clearoverlay

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.content.res.Configuration
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.BaseAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.Player
import java.util.concurrent.atomic.AtomicBoolean

/** Name of a file behind a content / file uri (falls back to the last path piece). */
fun audioDisplayName(act: Activity, u: Uri): String {
    var n: String? = null
    runCatching {
        act.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) n = c.getString(0)
        }
    }
    return n ?: (u.lastPathSegment ?: "audio")
}

/** Saves an enhanced .m4a copy of [uri] with the current enhancer settings; shows a small progress dialog. */
fun runAudioExport(act: Activity, uri: Uri, name: String) {
    val cancel = AtomicBoolean(false)
    val box = LinearLayout(act).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(act, 22), dp(act, 12), dp(act, 22), dp(act, 4))
    }
    val state = TextView(act).apply { text = "0%"; textSize = 16f }
    box.addView(state)
    val dlg = AlertDialog.Builder(act)
        .setTitle(R.string.aud_export_title)
        .setView(box)
        .setCancelable(false)
        .setNegativeButton(android.R.string.cancel) { _, _ -> cancel.set(true) }
        .create()
    dlg.show()
    act.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    val params = AudioCfg.snapshot()
    val app = act.applicationContext
    val base = name.substringBeforeLast('.').replace(Regex("[\\\\/:*?\"<>|]"), "_") + "_enhanced"
    Thread {
        var last = -1
        val r = AudioExport.run(app, uri, base, params, cancel) { f ->
            val pct = (f * 100).toInt()
            if (pct != last) {
                last = pct
                act.runOnUiThread { state.text = "$pct%" }
            }
        }
        act.runOnUiThread {
            act.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            runCatching { dlg.dismiss() }
            if (!act.isDestroyed) {
                val msg = when {
                    r.uri != null -> act.getString(R.string.aud_export_done_fmt, "$base.${r.ext}")
                    r.error == "cancelled" -> null
                    else -> act.getString(R.string.aud_export_fail_fmt, r.error ?: "?")
                }
                if (msg != null) Toast.makeText(act, msg, Toast.LENGTH_LONG).show()
            }
        }
    }.start()
}

/**
 * Music player: your songs / podcasts / ASMR with album art, a queue (next / previous / shuffle / repeat), background playback
 * (with a notification), the sound enhancer ([AudioCfg]) and a button that saves an enhanced copy as a normal .m4a file.
 * Also opens when you tap a song in the Library or "Open with" an audio file: it then plays that song and queues all the others.
 */
@Suppress("UnsafeOptInUsageError")
class AudioActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private var allTracks: List<MusicPlayer.Track> = emptyList()
    private var tracks: List<MusicPlayer.Track> = emptyList()
    private var loaded = false
    private var startUri: Uri? = null           // the song the Library / "Open with" asked for; played as soon as the list is loaded
    private lateinit var searchBox: android.widget.EditText
    private lateinit var sleepBtn: TextView
    private lateinit var speedBtn: TextView
    private lateinit var listView: ListView
    private lateinit var empty: TextView
    private lateinit var soundScroll: ScrollView
    private lateinit var tabTracks: TextView
    private lateinit var tabSound: TextView
    private lateinit var nowTitle: TextView
    private lateinit var nowArtist: TextView
    private lateinit var timeNow: TextView
    private lateinit var timeEnd: TextView
    private lateinit var seek: SeekBar
    private lateinit var playBtn: ImageView
    private lateinit var shuffleBtn: ImageView
    private lateinit var repeatBtn: ImageView
    private lateinit var modeTv: TextView
    private lateinit var cover: Covers.CoverView
    private lateinit var nowEq: EqView
    private var dragging = false
    private var showSound = false
    private var lastKey = ""
    private var shownCover: Uri? = null
    private val adapter = TrackAdapter()
    // which list is shown: null = all songs, FAV = favorites, anything else = the name of a playlist
    private var listSel: String? = null
    private val chipsRow by lazy { LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL } }
    private lateinit var chipScroll: View

    private val ticker = object : Runnable {
        override fun run() {
            refreshNow()
            ui.postDelayed(this, 500)
        }
    }

    override fun attachBaseContext(newBase: android.content.Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Cfg.bind(this, "screen")
        Ui.init(this)
        setTheme(Ui.theme())
        super.onCreate(savedInstanceState)
        Ui.styleBars(window)
        AudioCfg.load(this)
        volumeControlStream = android.media.AudioManager.STREAM_MUSIC
        startUri = if (savedInstanceState == null) intent?.data else null
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val pad = dp(this, 14)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
            setPadding(pad, dp(this@AudioActivity, 10), pad, dp(this@AudioActivity, 8))
        }
        // keep clear of the status bar, the navigation bar and the camera cut-out (in landscape they are at the sides)
        root.setOnApplyWindowInsetsListener { v, ins ->
            val i = ins.getInsetsIgnoringVisibility(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            v.setPadding(pad + i.left, dp(this, 10) + i.top, pad + i.right, dp(this, 8) + i.bottom)
            ins
        }

        // ---- top bar
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(Icons.button(this, Icons.CHEV_LEFT, Ui.TEXT, 44) { finish() })
        top.addView(Ui.text(this, getString(R.string.aud_title), 20f, Ui.TEXT, true).apply {
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(Icons.button(this, Icons.REFRESH, Ui.ACCENT, 44) { manualRefresh() })
        top.addView(Icons.button(this, Icons.VOLUME, Ui.ACCENT, 44) { AudioOut.show(this) })
        top.addView(Icons.button(this, Icons.SEARCH, Ui.ACCENT, 44) { toggleSearch() })
        top.addView(Icons.button(this, Icons.OPEN, Ui.ACCENT, 44) { pickFile() })
        root.addView(top)

        // ---- left part (tabs, search, list / sound settings)
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tabTracks = tab(getString(R.string.aud_tab_tracks)) { setTab(false) }
        tabSound = tab(getString(R.string.aud_tab_sound)) { setTab(true) }
        tabs.addView(tabTracks, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(this@AudioActivity, 6) })
        tabs.addView(tabSound, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        left.addView(tabs, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@AudioActivity, 8) })
        // all songs / favorites / my playlists / + new playlist
        chipScroll = ChipScroller(this, chipsRow)
        left.addView(chipScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@AudioActivity, 8) })
        rebuildChips()

        searchBox = android.widget.EditText(this).apply {
            hint = getString(R.string.aud_search_hint)
            textSize = 14f
            setSingleLine()
            setTextColor(Ui.TEXT)
            setHintTextColor(Ui.MUTED)
            visibility = View.GONE
            background = Ui.round(Ui.CHIP, dp(this@AudioActivity, 12).toFloat())
            setPadding(dp(this@AudioActivity, 14), dp(this@AudioActivity, 10), dp(this@AudioActivity, 14), dp(this@AudioActivity, 10))
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) { applyFilter() }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
        }
        left.addView(searchBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@AudioActivity, 8) })

        val frame = android.widget.FrameLayout(this)
        listView = ListView(this).apply {
            divider = null
            selector = Ui.round(Color.TRANSPARENT, 0f)
            adapter = this@AudioActivity.adapter
            setOnItemClickListener { _, _, pos, _ -> MusicPlayer.play(this@AudioActivity, tracks, pos); refreshNow() }
            setOnItemLongClickListener { _, _, pos, _ -> tracks.getOrNull(pos)?.let { trackMenu(it) }; true }
        }
        frame.addView(listView)
        empty = Ui.text(this, getString(R.string.aud_nothing), 14f, Ui.MUTED).apply {
            gravity = Gravity.CENTER
            visibility = View.GONE
            setPadding(dp(this@AudioActivity, 20), dp(this@AudioActivity, 20), dp(this@AudioActivity, 20), dp(this@AudioActivity, 20))
            setOnClickListener { requestAudio() }
        }
        frame.addView(empty, android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // ---- sound tab
        val soundCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.round(Ui.CARD, dp(this@AudioActivity, 20).toFloat(), Ui.STROKE, dp(this@AudioActivity, 1))
            setPadding(dp(this@AudioActivity, 16), dp(this@AudioActivity, 16), dp(this@AudioActivity, 16), dp(this@AudioActivity, 16))
        }
        soundCol.addView(buildAudioPanel(this))
        soundCol.addView(Ui.text(this, getString(R.string.aud_export_hint), 12f, Ui.MUTED), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@AudioActivity, 16) })
        soundCol.addView(audioFormatButton(this), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@AudioActivity, 8) })
        soundCol.addView(
            TextView(this).apply {
                text = getString(R.string.aud_export)
                gravity = Gravity.CENTER
                textSize = 14f
                setTextColor(Ui.ACCENT)
                background = Ui.round(Ui.CHIP, dp(this@AudioActivity, 12).toFloat(), Ui.ACCENT, dp(this@AudioActivity, 1))
                setPadding(0, dp(this@AudioActivity, 12), 0, dp(this@AudioActivity, 12))
                setOnClickListener { exportCurrent() }
            },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@AudioActivity, 8) }
        )
        soundScroll = ScrollView(this).apply { visibility = View.GONE; addView(soundCol) }
        frame.addView(soundScroll, android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        left.addView(frame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = dp(this@AudioActivity, 8) })

        // ---- now playing card
        val now = buildNowCard(land)

        if (land) {
            // landscape: the list on the left, the player on the right
            val body = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            body.addView(left, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
            body.addView(ScrollView(this).apply { addView(now) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply { marginStart = dp(this@AudioActivity, 12); topMargin = dp(this@AudioActivity, 8) })
            root.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        } else {
            root.addView(left, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            root.addView(now, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@AudioActivity, 8) })
        }

        setContentView(root)
        setTab(false)
        // the list the Library showed is used at once, so Next / Previous work even before (or without) the audio permission
        if (MusicPlayer.handoff.isNotEmpty()) {
            allTracks = MusicPlayer.handoff
            loaded = true
            applyFilter()
        }
        if (hasAudioAccess()) loadTracks() else if (allTracks.isEmpty()) requestAudio()
        if (!hasAudioAccess()) startUri?.let { u ->
            startUri = null
            startFrom(u)
        }
    }

    /** The "now playing" card: cover, title, progress, controls (shuffle, previous, play / pause, next, repeat) and sleep / speed. */
    private fun buildNowCard(land: Boolean): LinearLayout {
        val now = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.round(Ui.CARD, dp(this@AudioActivity, 22).toFloat(), Ui.STROKE, dp(this@AudioActivity, 1))
            setPadding(dp(this@AudioActivity, 12), dp(this@AudioActivity, 8), dp(this@AudioActivity, 12), dp(this@AudioActivity, 8))
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val cs = dp(this, if (land) 72 else 52)
        cover = Covers.CoverView(this, cs, 14)
        head.addView(cover, LinearLayout.LayoutParams(cs, cs))
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        nowTitle = Ui.text(this, "", 14f, Ui.TEXT, true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        nowArtist = Ui.text(this, "", 12f, Ui.MUTED).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        texts.addView(nowTitle)
        texts.addView(nowArtist, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@AudioActivity, 2) })
        head.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(this@AudioActivity, 14) })
        nowEq = EqView(this, 4)
        head.addView(nowEq, LinearLayout.LayoutParams(dp(this, 22), dp(this, 22)).apply { marginStart = dp(this@AudioActivity, 8) })
        cover.setOnClickListener { if (MusicPlayer.current() != null) NowPlayingFull.show(this) }
        now.addView(head)

        seek = SeekBar(this).apply {
            max = 1000
            progressTintList = android.content.res.ColorStateList.valueOf(Ui.ACCENT)
            thumbTintList = android.content.res.ColorStateList.valueOf(Ui.ACCENT)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    if (fromUser) {
                        val d = MusicPlayer.player?.duration ?: 0L
                        timeNow.text = fmt(d * p / 1000L)
                    }
                }

                override fun onStartTrackingTouch(s: SeekBar) { dragging = true }
                override fun onStopTrackingTouch(s: SeekBar) {
                    val pl = MusicPlayer.player
                    val d = pl?.duration ?: 0L
                    if (pl != null && d > 0) pl.seekTo(d * s.progress / 1000L)
                    dragging = false
                }
            })
        }
        // slim slider (it used to be stretched 1.7x taller)
        seek.setPadding(dp(this, 10), 0, dp(this, 10), 0)
        now.addView(seek, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(this, 24)).apply { topMargin = dp(this@AudioActivity, 2) })
        val times = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(this@AudioActivity, 4), 0, dp(this@AudioActivity, 4), 0) }
        timeNow = Ui.text(this, "0:00", 11f, Ui.MUTED)
        timeEnd = Ui.text(this, "0:00", 11f, Ui.MUTED).apply { gravity = Gravity.END }
        times.addView(timeNow, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        times.addView(timeEnd, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        now.addView(times)

        // controls: five buttons of the same width, the play button is the big round one
        val ctl = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        shuffleBtn = iconBtn(Icons.SHUFFLE, Ui.MUTED) {
            val p = MusicPlayer.player
            if (p != null) { p.shuffleModeEnabled = !p.shuffleModeEnabled; refreshNow() }
        }
        val prev = iconBtn(Icons.PREV, Ui.TEXT) { MusicPlayer.player?.seekToPreviousMediaItem(); refreshNow() }
        playBtn = iconBtn(Icons.PLAY, Ui.BG) {
            val p = MusicPlayer.player
            if (p != null) { if (p.isPlaying) p.pause() else p.play(); refreshNow() }
            else if (tracks.isNotEmpty()) { MusicPlayer.play(this, tracks, 0); refreshNow() }
        }
        val big = dp(this, 48)
        playBtn.background = Ui.gradient(big / 2f)
        val pp = dp(this, 12)
        playBtn.setPadding(pp, pp, pp, pp)
        val next = iconBtn(Icons.NEXT, Ui.TEXT) { MusicPlayer.player?.seekToNextMediaItem(); refreshNow() }
        repeatBtn = iconBtn(Icons.REPEAT, Ui.MUTED) {
            val p = MusicPlayer.player
            if (p != null) {
                p.repeatMode = when (p.repeatMode) {
                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                    else -> Player.REPEAT_MODE_OFF
                }
                refreshNow()
            }
        }
        for (b in listOf(shuffleBtn, prev, playBtn, next, repeatBtn)) {
            val size = if (b === playBtn) big else dp(this, 38)
            ctl.addView(FrameLayout(this).apply { addView(b, FrameLayout.LayoutParams(size, size, Gravity.CENTER)) },
                LinearLayout.LayoutParams(0, big, 1f))
        }
        now.addView(ctl, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@AudioActivity, 2) })

        modeTv = Ui.text(this, "", 12f, Ui.MUTED).apply { gravity = Gravity.CENTER; textSize = 11f; setPadding(0, dp(this@AudioActivity, 2), 0, dp(this@AudioActivity, 2)) }
        now.addView(modeTv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val ctl2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        sleepBtn = ctlButton(getString(R.string.aud_sleep)) { sleepMenu() }
        speedBtn = ctlButton("1×") { speedMenu() }
        ctl2.addView(sleepBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(this@AudioActivity, 6) })
        ctl2.addView(speedBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(this@AudioActivity, 6) })
        ctl2.addView(ctlButton(getString(R.string.aud_queue)) { queueDialog() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        now.addView(ctl2, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@AudioActivity, 4) })
        return now
    }

    // ---- small view helpers
    private fun iconBtn(kind: Int, color: Int, onClick: () -> Unit) = ImageView(this).apply {
        setImageDrawable(LineIcon(kind, color))
        val p = dp(this@AudioActivity, 9)
        setPadding(p, p, p, p)
        setOnClickListener { onClick() }
    }

    private fun tab(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 14f
        gravity = Gravity.CENTER
        setPadding(0, dp(this@AudioActivity, 10), 0, dp(this@AudioActivity, 10))
        setOnClickListener { onClick() }
    }

    private fun ctlButton(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 13f
        maxLines = 1
        gravity = Gravity.CENTER
        setTextColor(Ui.TEXT)
        background = Ui.round(Ui.CHIP, dp(this@AudioActivity, 12).toFloat())
        setPadding(dp(this@AudioActivity, 10), dp(this@AudioActivity, 7), dp(this@AudioActivity, 10), dp(this@AudioActivity, 7))
        setOnClickListener { onClick() }
    }

    private fun toggleSearch() {
        if (showSound) setTab(false)
        if (searchBox.visibility == View.VISIBLE) {
            searchBox.setText("")
            searchBox.visibility = View.GONE
            getSystemService(android.view.inputmethod.InputMethodManager::class.java)?.hideSoftInputFromWindow(searchBox.windowToken, 0)
        } else {
            searchBox.visibility = View.VISIBLE
            searchBox.requestFocus()
            getSystemService(android.view.inputmethod.InputMethodManager::class.java)?.showSoftInput(searchBox, 0)
        }
    }

    private fun setTab(sound: Boolean) {
        showSound = sound
        val r = dp(this, 12).toFloat()
        for ((v, on) in listOf(tabTracks to !sound, tabSound to sound)) {
            if (on) { v.background = Ui.gradient(r); v.setTextColor(Ui.BG) }
            else { v.background = Ui.round(Ui.CHIP, r); v.setTextColor(Ui.MUTED) }
        }
        soundScroll.visibility = if (sound) View.VISIBLE else View.GONE
        chipScroll.visibility = if (sound) View.GONE else View.VISIBLE
        searchBox.visibility = if (sound || searchBox.text.isEmpty() && searchBox.visibility != View.VISIBLE) View.GONE else View.VISIBLE
        listView.visibility = if (sound) View.GONE else View.VISIBLE
        updateEmpty()
    }

    private fun fmt(ms: Long): String {
        val s = (ms.coerceAtLeast(0L) / 1000L).toInt()
        return if (s >= 3600) String.format(java.util.Locale.US, "%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60) else String.format(java.util.Locale.US, "%d:%02d", s / 60, s % 60)
    }

    // ---- permission + loading
    private fun audioPerms(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_AUDIO) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    private fun hasAudioAccess() = audioPerms().all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun requestAudio() {
        if (hasAudioAccess()) { loadTracks(); return }
        if (askedOnce && !shouldShowRequestPermissionRationale(audioPerms()[0])) {
            // the system no longer shows its dialog: send the person to the app's permission page
            runCatching { startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
            return
        }
        askedOnce = true
        requestPermissions(audioPerms(), REQ_PERM)
    }
    private var askedOnce = false

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == REQ_PERM && hasAudioAccess()) loadTracks() // refused: the list stays empty, "Open a file" still works
    }

    /** Refresh: music files that were added or changed since the phone last looked are found by the media scanner, then the list is read again. */
    private fun manualRefresh() {
        Toast.makeText(this, R.string.lib_refreshing, Toast.LENGTH_SHORT).show()
        val app = applicationContext
        Thread {
            val paths = ArrayList<String>()
            fun walk(d: java.io.File, depth: Int) {
                if (depth > 6 || paths.size >= 4000) return
                val kids = runCatching { d.listFiles() }.getOrNull() ?: return
                for (f in kids) {
                    if (f.isDirectory) { if (!f.name.startsWith(".")) walk(f, depth + 1) }
                    else if (Shrink.isAudioName(f.name)) paths.add(f.absolutePath)
                }
            }
            runCatching {
                val root = android.os.Environment.getExternalStorageDirectory()
                for (n in listOf("Music", "Download", "Documents", "Podcasts", "Audiobooks", "Recordings")) walk(java.io.File(root, n), 0)
                root.listFiles()?.forEach { d -> if (d.isDirectory && !d.name.startsWith(".") && d.name != "Android") walk(d, 1) }
            }
            if (paths.isEmpty()) { ui.post { if (!isDestroyed) loadTracks() }; return@Thread }
            val left = java.util.concurrent.atomic.AtomicInteger(paths.size)
            android.media.MediaScannerConnection.scanFile(app, paths.toTypedArray(), null) { _, _ ->
                if (left.decrementAndGet() == 0) ui.post { if (!isDestroyed) loadTracks() }
            }
            ui.postDelayed({ if (!isDestroyed && left.get() > 0) loadTracks() }, 8000) // the scanner did not answer for every file: read the list anyway
        }.start()
    }

    private fun loadTracks() {
        val app = applicationContext
        Thread {
            val list = MusicPlayer.scan(app)
            ui.post {
                if (isDestroyed) return@post
                allTracks = if (list.isEmpty() && MusicPlayer.handoff.isNotEmpty()) MusicPlayer.handoff else list
                loaded = true
                applyFilter()
                startUri?.let { u ->
                    startUri = null
                    startFrom(u)
                }
            }
        }.start()
    }

    /** Plays [u] and queues every other song after it (so Next / Previous and "play on" work), like any music app. */
    private fun startFrom(u: Uri) {
        val idx = allTracks.indexOfFirst { it.uri == u }
        if (idx >= 0) {
            MusicPlayer.play(this, allTracks, idx)
        } else {
            // a file that is not in the media index (picked from a folder): play it first, then the songs of the list
            val t = MusicPlayer.Track(u, audioDisplayName(this, u).substringBeforeLast('.'), "", 0L)
            MusicPlayer.play(this, listOf(t) + allTracks, 0)
        }
        refreshNow()
    }

    private fun applyFilter() {
        val q = searchBox.text.toString().trim().lowercase()
        val base: List<MusicPlayer.Track> = when (val sel = listSel) {
            null -> allTracks
            FAV -> { val f = MusicLists.favs(this).toSet(); allTracks.filter { it.uri.toString() in f } }
            else -> { // a playlist keeps the order it was made in
                val byUri = allTracks.associateBy { it.uri.toString() }
                MusicLists.items(this, sel).mapNotNull { byUri[it] }
            }
        }
        tracks = if (q.isEmpty()) base else base.filter { it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) }
        adapter.notifyDataSetChanged()
        updateEmpty()
    }

    private fun updateEmpty() {
        val show = !showSound && tracks.isEmpty()
        empty.visibility = if (show) View.VISIBLE else View.GONE
        if (show) empty.text = getString(when {
            listSel != null && allTracks.isNotEmpty() -> R.string.aud_list_empty
            !loaded && hasAudioAccess() -> R.string.lib_loading
            else -> R.string.aud_nothing
        })
    }

    /** The row above the list: All · Favorites · each playlist · + (long-press a playlist to delete it). */
    private fun rebuildChips() {
        chipsRow.removeAllViews()
        val r = dp(this, 10).toFloat()
        fun chip(label: String, on: Boolean, onClick: () -> Unit, onLong: (() -> Unit)? = null) {
            val c = TextView(this).apply {
                text = label
                textSize = 13f
                maxLines = 1
                gravity = Gravity.CENTER
                setPadding(dp(this@AudioActivity, 14), dp(this@AudioActivity, 8), dp(this@AudioActivity, 14), dp(this@AudioActivity, 8))
                if (on) { background = Ui.gradient(r); setTextColor(Ui.BG); setTypeface(null, android.graphics.Typeface.BOLD) }
                else { background = Ui.round(Ui.CHIP, r); setTextColor(Ui.MUTED) }
                setOnClickListener { onClick() }
                if (onLong != null) setOnLongClickListener { onLong(); true }
            }
            chipsRow.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(this@AudioActivity, 6) })
        }
        chip(getString(R.string.aud_all), listSel == null, { selectList(null) })
        chip("♥ " + getString(R.string.aud_fav), listSel == FAV, { selectList(FAV) })
        for (n in MusicLists.names(this)) chip(n, listSel == n, { selectList(n) }, { deleteListDialog(n) })
        chip("＋", false, { newListDialog(null) })
        // inside a playlist: pick many songs at once
        val cur = listSel
        if (cur != null && cur != FAV) chip("＋ " + getString(R.string.aud_add_songs), false, { pickSongsDialog(cur) })
    }

    private fun selectList(sel: String?) {
        listSel = sel
        rebuildChips()
        applyFilter()
    }

    /** Asks for a name and makes a playlist; [then] gets its name (used to add a song straight into the new list). */
    private fun newListDialog(then: ((String) -> Unit)?) {
        val et = android.widget.EditText(this).apply {
            hint = getString(R.string.aud_list_name_hint)
            setSingleLine()
            setPadding(dp(this@AudioActivity, 20), dp(this@AudioActivity, 14), dp(this@AudioActivity, 20), dp(this@AudioActivity, 14))
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.aud_new_list)
            .setView(et)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty() && MusicLists.create(this, n)) {
                    if (then != null) then(n) else { selectList(n); pickSongsDialog(n) } // a new list opens the picker straight away
                    rebuildChips()
                } else {
                    Toast.makeText(this, R.string.aud_list_bad_name, Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    /**
     * Multi-select picker for a playlist: every song of the phone with a check box and a search field. The songs already in the list are
     * ticked; OK adds the newly ticked ones and takes out the ones that were un-ticked.
     */
    private fun pickSongsDialog(name: String) {
        val pool = allTracks
        if (pool.isEmpty()) {
            Toast.makeText(this, R.string.aud_nothing, Toast.LENGTH_SHORT).show()
            return
        }
        val before = MusicLists.items(this, name).toSet()
        val sel = LinkedHashSet<String>(before)
        var shown: List<MusicPlayer.Track> = pool
        val pad = dp(this, 12)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad / 2, pad, 0) }
        val search = android.widget.EditText(this).apply {
            hint = getString(R.string.aud_pick_search)
            setSingleLine()
        }
        val count = TextView(this).apply { textSize = 12f; setPadding(dp(this@AudioActivity, 4), dp(this@AudioActivity, 4), 0, dp(this@AudioActivity, 4)) }
        val lv = ListView(this)
        fun paintCount() { count.text = getString(R.string.aud_pick_count, sel.size) }
        val ad = object : BaseAdapter() {
            override fun getCount() = shown.size
            override fun getItem(i: Int) = shown[i]
            override fun getItemId(i: Int) = i.toLong()
            override fun getView(i: Int, v: View?, parent: ViewGroup?): View {
                val row = (v as? android.widget.CheckedTextView) ?: android.widget.CheckedTextView(this@AudioActivity).apply {
                    setPadding(dp(this@AudioActivity, 8), dp(this@AudioActivity, 10), dp(this@AudioActivity, 8), dp(this@AudioActivity, 10))
                    textSize = 15f
                    maxLines = 2
                    checkMarkDrawable = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
                }
                val t = shown[i]
                val on = t.uri.toString() in sel
                row.text = (if (on) "✔  " else "▫  ") + t.title.replace('\n', ' ') + (if (t.artist.isNotBlank()) "  ·  " + t.artist else "")
                row.isChecked = on
                return row
            }
        }
        lv.adapter = ad
        lv.setOnItemClickListener { _, _, i, _ ->
            val k = shown[i].uri.toString()
            if (!sel.remove(k)) sel.add(k)
            ad.notifyDataSetChanged()
            paintCount()
        }
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                val q = s?.toString()?.trim()?.lowercase().orEmpty()
                shown = if (q.isEmpty()) pool else pool.filter { it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) }
                ad.notifyDataSetChanged()
            }
        })
        box.addView(search, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        box.addView(count, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        box.addView(lv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (resources.displayMetrics.heightPixels * 0.55f).toInt()))
        paintCount()
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.aud_pick_title, name))
            .setView(box)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                // new ones keep the order of the library; the ones taken out are removed
                val add = pool.map { it.uri.toString() }.filter { it in sel && it !in before }
                MusicLists.addAll(this, name, add)
                MusicLists.removeAll(this, name, before.filter { it !in sel }.toSet())
                if (add.isNotEmpty()) Toast.makeText(this, getString(R.string.aud_added_n_fmt, add.size, name), Toast.LENGTH_SHORT).show()
                if (listSel == name) applyFilter()
            }
            .setNeutralButton(R.string.aud_pick_all) { _, _ ->
                // handled below: replaced by the real listener (the dialog must stay open)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
            .also { dlg ->
                dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                    // select / clear everything that is shown (the search result when a search is typed)
                    val keys = shown.map { it.uri.toString() }
                    if (keys.all { it in sel }) sel.removeAll(keys.toSet()) else sel.addAll(keys)
                    ad.notifyDataSetChanged()
                    paintCount()
                }
            }
    }

    private fun deleteListDialog(name: String) {
        AlertDialog.Builder(this)
            .setMessage(getString(R.string.aud_list_delete_q, name))
            .setPositiveButton(R.string.trash_delete_item) { _, _ ->
                MusicLists.delete(this, name)
                if (listSel == name) listSel = null
                rebuildChips()
                applyFilter()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    /** Pick the playlist a song goes into (or make a new one). */
    private fun addToListDialog(t: MusicPlayer.Track) {
        val names = MusicLists.names(this)
        val items = (names + getString(R.string.aud_new_list)).toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(R.string.aud_menu_to_list)
            .setItems(items) { _, i ->
                if (i < names.size) {
                    MusicLists.add(this, names[i], t.uri.toString())
                    Toast.makeText(this, getString(R.string.aud_added_fmt, names[i]), Toast.LENGTH_SHORT).show()
                    if (listSel == names[i]) applyFilter()
                } else {
                    newListDialog { n ->
                        MusicLists.add(this, n, t.uri.toString())
                        Toast.makeText(this, getString(R.string.aud_added_fmt, n), Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    /** Long-press a song: play next, add to the queue, favorite, playlists, edit, share, delete. */
    
    private fun trackMenu(t: MusicPlayer.Track) {
        val key = t.uri.toString()
        val isFav = MusicLists.isFav(this, key)
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        labels.add(getString(R.string.aud_menu_next)); acts.add { MusicPlayer.playNext(this, t); Toast.makeText(this, R.string.aud_next_added, Toast.LENGTH_SHORT).show() }
        labels.add(getString(R.string.aud_menu_queue)); acts.add { MusicPlayer.enqueue(this, t); Toast.makeText(this, R.string.aud_next_added, Toast.LENGTH_SHORT).show() }
        labels.add(getString(if (isFav) R.string.aud_menu_fav_remove else R.string.aud_menu_fav_add)); acts.add {
            MusicLists.toggleFav(this, key)
            if (listSel == FAV) applyFilter() else adapter.notifyDataSetChanged()
        }
        labels.add(getString(R.string.aud_menu_to_list)); acts.add { addToListDialog(t) }
        val sel = listSel
        if (sel != null && sel != FAV) {
            labels.add(getString(R.string.aud_menu_from_list)); acts.add { MusicLists.remove(this, sel, key); applyFilter() }
        }
        labels.add(getString(R.string.aud_menu_edit)); acts.add { startActivity(Intent(this, AudioEditActivity::class.java).setData(t.uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
        labels.add(getString(R.string.share)); acts.add { Share.share(this, listOf(t.uri)) }
        labels.add(getString(R.string.trash_delete_item)); acts.add { TrashOps.confirmDelete(this, listOf(t.uri)) { loadTracks() } }
        AlertDialog.Builder(this)
            .setTitle(t.title)
            .setItems(labels.toTypedArray()) { _, w -> acts[w]() }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    /** The play queue: tap a song to jump to it, long-press to take it out. */
    private fun queueDialog() {
        val p = MusicPlayer.player
        val q = MusicPlayer.queue
        if (p == null || q.isEmpty()) {
            Toast.makeText(this, R.string.aud_nothing_playing, Toast.LENGTH_SHORT).show()
            return
        }
        val names = q.mapIndexed { i, t -> (if (i == p.currentMediaItemIndex) "▶  " else "") + t.title }.toTypedArray()
        val dlg = AlertDialog.Builder(this)
            .setTitle(getString(R.string.aud_queue_title_fmt, q.size))
            .setItems(names) { _, i -> p.seekTo(i, 0L); p.play(); refreshNow() }
            .setNegativeButton(android.R.string.cancel, null)
            .create()
        dlg.listView.setOnItemLongClickListener { _, _, i, _ ->
            MusicPlayer.removeAt(i)
            dlg.dismiss()
            queueDialog()
            true
        }
        dlg.show()
        dlg.listView.setSelection((p.currentMediaItemIndex - 2).coerceAtLeast(0))
    }

    private fun sleepMenu() {
        val mins = intArrayOf(0, 10, 20, 30, 45, 60, 90)
        val labels = mins.map { if (it == 0) getString(R.string.aud_sleep_off) else getString(R.string.aud_sleep_min_fmt, it) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(R.string.aud_sleep)
            .setItems(labels) { _, i -> MusicPlayer.setSleep(mins[i]); refreshNow() }
            .show()
    }

    private fun speedMenu() {
        val sp = floatArrayOf(0.25f, 0.5f, 0.75f, 0.9f, 1f, 1.1f, 1.25f, 1.5f, 2f, 3f, 4f)
        val labels = sp.map { (if (it == it.toInt().toFloat()) it.toInt().toString() else it.toString()) + "×" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(R.string.aud_speed)
            .setItems(labels) { _, i -> MusicPlayer.changeSpeed(sp[i]); refreshNow() }
            .show()
    }

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*")
            .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("audio/*", "video/*"))
        @Suppress("DEPRECATION")
        startActivityForResult(i, REQ_FILE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (TrashOps.handleResult(req, res)) return
        val u = data?.data
        if (req == REQ_FILE && res == RESULT_OK && u != null) {
            if (loaded) startFrom(u)
            else MusicPlayer.play(this, listOf(MusicPlayer.Track(u, audioDisplayName(this, u), "", 0L)), 0)
            refreshNow()
        }
    }

    private fun exportCurrent() {
        val t = MusicPlayer.current()
        if (t == null) {
            Toast.makeText(this, getString(R.string.aud_export_none), Toast.LENGTH_SHORT).show()
            return
        }
        runAudioExport(this, t.uri, t.title)
    }

    // ---- now playing
    private fun refreshNow() {
        val p = MusicPlayer.player
        val t = MusicPlayer.current()
        nowTitle.text = t?.title ?: getString(R.string.aud_nothing_playing)
        nowArtist.text = t?.artist ?: ""
        nowArtist.visibility = if (t == null || t.artist.isEmpty()) View.GONE else View.VISIBLE
        if (t?.uri != shownCover) {
            shownCover = t?.uri
            cover.bind(t?.uri)
        }
        val left = MusicPlayer.sleepLeftMin()
        sleepBtn.text = if (left > 0) getString(R.string.aud_sleep_left_fmt, left) else getString(R.string.aud_sleep)
        sleepBtn.setTextColor(if (left > 0) Ui.ACCENT else Ui.TEXT)
        val sp = MusicPlayer.speed
        speedBtn.text = (if (sp == sp.toInt().toFloat()) sp.toInt().toString() else sp.toString()) + "×"
        speedBtn.setTextColor(if (sp != 1f) Ui.ACCENT else Ui.TEXT)
        val playing = p != null && p.isPlaying
        playBtn.setImageDrawable(LineIcon(if (playing) Icons.PAUSE else Icons.PLAY, Ui.BG))
        nowEq.run(playing)
        if (p != null) {
            val d = p.duration.let { if (it == androidx.media3.common.C.TIME_UNSET) 0L else it }
            if (!dragging) {
                seek.progress = if (d > 0) (p.currentPosition * 1000L / d).toInt().coerceIn(0, 1000) else 0
                timeNow.text = fmt(p.currentPosition)
            }
            timeEnd.text = fmt(d)
            shuffleBtn.setImageDrawable(LineIcon(Icons.SHUFFLE, if (p.shuffleModeEnabled) Ui.ACCENT else Ui.MUTED))
            val rm = p.repeatMode
            repeatBtn.setImageDrawable(
                LineIcon(if (rm == Player.REPEAT_MODE_ONE) Icons.REPEAT_ONE else Icons.REPEAT, if (rm == Player.REPEAT_MODE_OFF) Ui.MUTED else Ui.ACCENT)
            )
            modeTv.text = getString(R.string.aud_shuffle) + (if (p.shuffleModeEnabled) ": ✓" else ": –") + "    ·    " +
                getString(when (rm) { Player.REPEAT_MODE_ALL -> R.string.aud_repeat_all; Player.REPEAT_MODE_ONE -> R.string.aud_repeat_one; else -> R.string.aud_repeat_off })
        } else {
            timeNow.text = "0:00"
            timeEnd.text = "0:00"
            seek.progress = 0
        }
        // the list only needs a repaint when the song or the play state changed
        val key = (t?.uri?.toString() ?: "") + "|" + playing
        if (key != lastKey) {
            lastKey = key
            adapter.notifyDataSetChanged()
        }
    }

    override fun onResume() {
        super.onResume()
        ui.post(ticker)
    }

    override fun onPause() {
        ui.removeCallbacks(ticker)
        super.onPause()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        super.onDestroy() // the music itself goes on: it belongs to MusicPlayer / MusicService, not to this screen
    }

    /** One song row: cover on the left, title and artist / length on the right (long names are cut with "..." and never run under the cover). */
    private inner class TrackAdapter : BaseAdapter() {
        private inner class Holder(val row: LinearLayout, val cover: Covers.CoverView, val title: TextView, val sub: TextView, val mark: EqView)

        override fun getCount() = tracks.size
        override fun getItem(position: Int) = tracks[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val t = tracks[position]
            var h = convertView?.tag as? Holder
            if (h == null) {
                val ctx = this@AudioActivity
                val size = dp(ctx, 52)
                val row = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(ctx, 6), dp(ctx, 6), dp(ctx, 6), dp(ctx, 6))
                    minimumHeight = dp(ctx, 66)
                }
                val cv = Covers.CoverView(ctx, size, 10)
                row.addView(cv, LinearLayout.LayoutParams(size, size))
                val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
                val title = Ui.text(ctx, "", 15f, Ui.TEXT).apply { isSingleLine = true; ellipsize = android.text.TextUtils.TruncateAt.END; includeFontPadding = false }
                val sub = Ui.text(ctx, "", 12f, Ui.MUTED).apply { isSingleLine = true; ellipsize = android.text.TextUtils.TruncateAt.END; includeFontPadding = false }
                col.addView(title)
                col.addView(sub, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(ctx, 2) })
                row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(ctx, 12); marginEnd = dp(ctx, 8) })
                val mark = EqView(ctx, 4)
                row.addView(mark, LinearLayout.LayoutParams(dp(ctx, 20), dp(ctx, 20)).apply { marginEnd = dp(ctx, 6) })
                h = Holder(row, cv, title, sub, mark)
                row.tag = h
            }
            h.cover.bind(t.uri)
            h.title.text = (if (MusicLists.isFav(this@AudioActivity, t.uri.toString())) "♥ " else "") + t.title.replace('\n', ' ')
            h.sub.text = (if (t.artist.isNotEmpty()) t.artist + "  ·  " else "") + (if (t.durationMs > 0) fmt(t.durationMs) else "")
            val cur = MusicPlayer.current()?.uri == t.uri
            h.title.setTextColor(if (cur) Ui.ACCENT else Ui.TEXT)
            h.mark.visibility = if (cur) View.VISIBLE else View.INVISIBLE
            h.mark.run(cur && MusicPlayer.player?.isPlaying == true)
            h.row.background = if (cur) Ui.round(Ui.CHIP, dp(this@AudioActivity, 12).toFloat()) else null
            return h.row
        }
    }

    private companion object {
        const val REQ_PERM = 31
        const val REQ_FILE = 32
        const val FAV = "\u0000fav"
    }
}
