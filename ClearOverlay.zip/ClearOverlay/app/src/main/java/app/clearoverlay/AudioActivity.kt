package app.clearoverlay

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.BaseAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.Player
import java.util.concurrent.atomic.AtomicBoolean

/** Name of a file behind a content / file uri (falls back to the last path piece). */
fun audioDisplayName(act: Activity, u: Uri): String {
    var n: String? = null
    runCatching {
        act.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) n = c.getString(0)
        }
    }
    return n ?: (u.lastPathSegment ?: "audio")
}

/** Saves an enhanced .m4a copy of [uri] with the current enhancer settings; shows a small progress dialog. */
fun runAudioExport(act: Activity, uri: Uri, name: String) {
    val cancel = AtomicBoolean(false)
    val box = LinearLayout(act).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(act, 22), dp(act, 12), dp(act, 22), dp(act, 4))
    }
    val state = TextView(act).apply { text = "0%"; textSize = 16f }
    box.addView(state)
    val dlg = AlertDialog.Builder(act)
        .setTitle(R.string.aud_export_title)
        .setView(box)
        .setCancelable(false)
        .setNegativeButton(android.R.string.cancel) { _, _ -> cancel.set(true) }
        .create()
    dlg.show()
    act.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    val params = AudioCfg.snapshot()
    val app = act.applicationContext
    val base = name.substringBeforeLast('.').replace(Regex("[\\\\/:*?\"<>|]"), "_") + "_enhanced"
    Thread {
        var last = -1
        val r = AudioExport.run(app, uri, base, params, cancel) { f ->
            val pct = (f * 100).toInt()
            if (pct != last) {
                last = pct
                act.runOnUiThread { state.text = "$pct%" }
            }
        }
        act.runOnUiThread {
            act.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            runCatching { dlg.dismiss() }
            if (!act.isDestroyed) {
                val msg = when {
                    r.uri != null -> act.getString(R.string.aud_export_done_fmt, "$base.m4a")
                    r.error == "cancelled" -> null
                    else -> act.getString(R.string.aud_export_fail_fmt, r.error ?: "?")
                }
                if (msg != null) Toast.makeText(act, msg, Toast.LENGTH_LONG).show()
            }
        }
    }.start()
}

/**
 * Music and sound player: your songs / podcasts / ASMR, played in the background (with a notification), with the
 * sound enhancer ([AudioCfg]) and a button that saves an enhanced copy as a normal .m4a file.
 * Also opens when you "Open with" an audio file.
 */
@Suppress("UnsafeOptInUsageError")
class AudioActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private var allTracks: List<MusicPlayer.Track> = emptyList()
    private var tracks: List<MusicPlayer.Track> = emptyList()
    private lateinit var searchBox: android.widget.EditText
    private lateinit var sleepBtn: TextView
    private lateinit var speedBtn: TextView
    private lateinit var listView: ListView
    private lateinit var empty: TextView
    private lateinit var soundScroll: ScrollView
    private lateinit var tabTracks: TextView
    private lateinit var tabSound: TextView
    private lateinit var nowTitle: TextView
    private lateinit var nowArtist: TextView
    private lateinit var timeText: TextView
    private lateinit var seek: SeekBar
    private lateinit var playBtn: TextView
    private lateinit var shuffleBtn: TextView
    private lateinit var repeatBtn: TextView
    private var dragging = false
    private var showSound = false
    private val adapter = TrackAdapter()

    private val ticker = object : Runnable {
        override fun run() {
            refreshNow()
            ui.postDelayed(this, 500)
        }
    }

    override fun attachBaseContext(newBase: android.content.Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Cfg.bind(this, "screen")
        Ui.init(this)
        setTheme(Ui.theme())
        super.onCreate(savedInstanceState)
        Ui.styleBars(window)
        AudioCfg.load(this)
        volumeControlStream = android.media.AudioManager.STREAM_MUSIC

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
            setPadding(dp(this@AudioActivity, 14), dp(this@AudioActivity, 12), dp(this@AudioActivity, 14), dp(this@AudioActivity, 10))
        }

        // ---- top bar
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(Ui.text(this, getString(R.string.aud_title), 20f, Ui.TEXT, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(smallButton(getString(R.string.aud_open)) { pickFile() })
        top.addView(smallButton("✕") { finish() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(this@AudioActivity, 6) })
        root.addView(top)

        // ---- tabs
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tabTracks = tab(getString(R.string.aud_tab_tracks)) { setTab(false) }
        tabSound = tab(getString(R.string.aud_tab_sound)) { setTab(true) }
        tabs.addView(tabTracks, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(this@AudioActivity, 6) })
        tabs.addView(tabSound, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(tabs, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@AudioActivity, 10) })

        // ---- search
        searchBox = android.widget.EditText(this).apply {
            hint = getString(R.string.aud_search_hint)
            textSize = 14f
            setSingleLine()
            setTextColor(Ui.TEXT)
            setHintTextColor(Ui.MUTED)
            background = Ui.round(Ui.CHIP, dp(this@AudioActivity, 10).toFloat())
            setPadding(dp(this@AudioActivity, 12), dp(this@AudioActivity, 8), dp(this@AudioActivity, 12), dp(this@AudioActivity, 8))
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) { applyFilter() }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
        }
        root.addView(searchBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@AudioActivity, 8) })

        // ---- songs list (and the message shown when it is empty)
        val frame = android.widget.FrameLayout(this)
        listView = ListView(this).apply {
            divider = null
            adapter = this@AudioActivity.adapter
            setOnItemClickListener { _, _, pos, _ -> MusicPlayer.play(this@AudioActivity, tracks, pos); refreshNow() }
            setOnItemLongClickListener { _, _, pos, _ -> tracks.getOrNull(pos)?.let { trackMenu(it) }; true }
        }
        frame.addView(listView)
        empty = Ui.text(this, getString(R.string.aud_nothing), 14f, Ui.MUTED).apply {
            gravity = Gravity.CENTER
            visibility = View.GONE
            setPadding(dp(this@AudioActivity, 20), dp(this@AudioActivity, 20), dp(this@AudioActivity, 20), dp(this@AudioActivity, 20))
            setOnClickListener { requestAudio() }
        }
        frame.addView(empty, android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // ---- sound tab
        val soundCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.round(Ui.CARD, dp(this@AudioActivity, 20).toFloat(), Ui.STROKE, dp(this@AudioActivity, 1))
            setPadding(dp(this@AudioActivity, 16), dp(this@AudioActivity, 16), dp(this@AudioActivity, 16), dp(this@AudioActivity, 16))
        }
        soundCol.addView(buildAudioPanel(this))
        soundCol.addView(Ui.text(this, getString(R.string.aud_export_hint), 12f, Ui.MUTED), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@AudioActivity, 16) })
        soundCol.addView(
            TextView(this).apply {
                text = getString(R.string.aud_export)
                gravity = Gravity.CENTER
                textSize = 14f
                setTextColor(Ui.ACCENT)
                background = Ui.round(Ui.CHIP, dp(this@AudioActivity, 12).toFloat(), Ui.ACCENT, dp(this@AudioActivity, 1))
                setPadding(0, dp(this@AudioActivity, 12), 0, dp(this@AudioActivity, 12))
                setOnClickListener { exportCurrent() }
            },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@AudioActivity, 8) }
        )
        soundScroll = ScrollView(this).apply { visibility = View.GONE; addView(soundCol) }
        frame.addView(soundScroll, android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(frame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = dp(this@AudioActivity, 10) })

        // ---- now playing
        val now = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.round(Ui.CARD, dp(this@AudioActivity, 18).toFloat(), Ui.STROKE, dp(this@AudioActivity, 1))
            setPadding(dp(this@AudioActivity, 14), dp(this@AudioActivity, 10), dp(this@AudioActivity, 14), dp(this@AudioActivity, 10))
        }
        nowTitle = Ui.text(this, "", 15f, Ui.TEXT, true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        nowArtist = Ui.text(this, "", 12f, Ui.MUTED).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        now.addView(nowTitle)
        now.addView(nowArtist)
        seek = SeekBar(this).apply {
            max = 1000
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    if (fromUser) {
                        val d = MusicPlayer.player?.duration ?: 0L
                        timeText.text = fmt(d * p / 1000L) + " / " + fmt(d)
                    }
                }

                override fun onStartTrackingTouch(s: SeekBar) { dragging = true }
                override fun onStopTrackingTouch(s: SeekBar) {
                    val pl = MusicPlayer.player
                    val d = pl?.duration ?: 0L
                    if (pl != null && d > 0) pl.seekTo(d * s.progress / 1000L)
                    dragging = false
                }
            })
        }
        now.addView(seek)
        timeText = Ui.text(this, "", 12f, Ui.MUTED).apply { gravity = Gravity.CENTER }
        now.addView(timeText)
        val ctl = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        shuffleBtn = ctlButton(getString(R.string.aud_shuffle), 12f) {
            val p = MusicPlayer.player
            if (p != null) { p.shuffleModeEnabled = !p.shuffleModeEnabled; refreshNow() }
        }
        val prev = ctlButton("◀◀", 16f) { MusicPlayer.player?.seekToPreviousMediaItem() }
        playBtn = ctlButton("▶", 20f) {
            val p = MusicPlayer.player
            if (p != null) { if (p.isPlaying) p.pause() else p.play(); refreshNow() }
            else if (tracks.isNotEmpty()) { MusicPlayer.play(this, tracks, 0); refreshNow() }
        }
        val next = ctlButton("▶▶", 16f) { MusicPlayer.player?.seekToNextMediaItem() }
        repeatBtn = ctlButton(getString(R.string.aud_repeat_off), 12f) {
            val p = MusicPlayer.player
            if (p != null) {
                p.repeatMode = when (p.repeatMode) {
                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                    else -> Player.REPEAT_MODE_OFF
                }
                refreshNow()
            }
        }
        for (b in listOf(shuffleBtn, prev, playBtn, next, repeatBtn)) {
            ctl.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(this@AudioActivity, 3); marginEnd = dp(this@AudioActivity, 3) })
        }
        now.addView(ctl, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@AudioActivity, 6) })
        val ctl2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        sleepBtn = ctlButton(getString(R.string.aud_sleep), 12f) { sleepMenu() }
        speedBtn = ctlButton("1×", 12f) { speedMenu() }
        for (b in listOf(sleepBtn, speedBtn)) {
            ctl2.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(this@AudioActivity, 3); marginEnd = dp(this@AudioActivity, 3) })
        }
        now.addView(ctl2, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@AudioActivity, 6) })
        root.addView(now, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(this@AudioActivity, 10) })

        setContentView(root)
        setTab(false)

        // "Open with" an audio file: play just that file
        val d = intent?.data
        if (d != null && savedInstanceState == null) {
            val t = MusicPlayer.Track(d, audioDisplayName(this, d), "", 0L)
            MusicPlayer.play(this, listOf(t), 0)
        }
        if (hasAudioAccess()) loadTracks() else requestAudio()
    }

    // ---- small view helpers
    private fun smallButton(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 14f
        gravity = Gravity.CENTER
        setTextColor(Ui.ACCENT)
        background = Ui.round(Ui.CHIP, dp(this@AudioActivity, 10).toFloat())
        setPadding(dp(this@AudioActivity, 12), dp(this@AudioActivity, 8), dp(this@AudioActivity, 12), dp(this@AudioActivity, 8))
        setOnClickListener { onClick() }
    }

    private fun tab(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 14f
        gravity = Gravity.CENTER
        setPadding(0, dp(this@AudioActivity, 10), 0, dp(this@AudioActivity, 10))
        setOnClickListener { onClick() }
    }

    private fun ctlButton(label: String, sp: Float, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = sp
        gravity = Gravity.CENTER
        setTextColor(Ui.TEXT)
        background = Ui.round(Ui.CHIP, dp(this@AudioActivity, 12).toFloat())
        setPadding(0, dp(this@AudioActivity, 10), 0, dp(this@AudioActivity, 10))
        setOnClickListener { onClick() }
    }

    private fun setTab(sound: Boolean) {
        showSound = sound
        val r = dp(this, 12).toFloat()
        for ((v, on) in listOf(tabTracks to !sound, tabSound to sound)) {
            if (on) { v.background = Ui.gradient(r); v.setTextColor(Ui.BG) }
            else { v.background = Ui.round(Ui.CHIP, r); v.setTextColor(Ui.MUTED) }
        }
        soundScroll.visibility = if (sound) View.VISIBLE else View.GONE
        searchBox.visibility = if (sound) View.GONE else View.VISIBLE
        listView.visibility = if (sound) View.GONE else View.VISIBLE
        empty.visibility = if (!sound && tracks.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun fmt(ms: Long): String {
        val s = (ms.coerceAtLeast(0L) / 1000L).toInt()
        return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, (s / 60) % 60, s % 60) else "%d:%02d".format(s / 60, s % 60)
    }

    // ---- permission + loading
    private fun audioPerms(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_AUDIO) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    private fun hasAudioAccess() = audioPerms().all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun requestAudio() {
        if (hasAudioAccess()) loadTracks() else requestPermissions(audioPerms(), REQ_PERM)
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == REQ_PERM && hasAudioAccess()) loadTracks() // refused: the list stays empty, "Open a file" still works
    }

    private fun loadTracks() {
        val app = applicationContext
        Thread {
            val list = MusicPlayer.scan(app)
            ui.post {
                if (isDestroyed) return@post
                allTracks = list
                applyFilter()
            }
        }.start()
    }

    private fun applyFilter() {
        val q = searchBox.text.toString().trim().lowercase()
        tracks = if (q.isEmpty()) allTracks else allTracks.filter { it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) }
        adapter.notifyDataSetChanged()
        empty.visibility = if (!showSound && tracks.isEmpty()) View.VISIBLE else View.GONE
    }

    /** Long-press a song: play next, edit, share, delete. */
    private fun trackMenu(t: MusicPlayer.Track) {
        AlertDialog.Builder(this)
            .setTitle(t.title)
            .setItems(arrayOf(getString(R.string.aud_menu_next), getString(R.string.aud_menu_edit), getString(R.string.share), getString(R.string.trash_delete_item))) { _, w ->
                when (w) {
                    0 -> { MusicPlayer.playNext(this, t); Toast.makeText(this, R.string.aud_next_added, Toast.LENGTH_SHORT).show() }
                    1 -> startActivity(Intent(this, AudioEditActivity::class.java).setData(t.uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                    2 -> Share.share(this, listOf(t.uri))
                    3 -> TrashOps.confirmDelete(this, listOf(t.uri)) { loadTracks() }
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun sleepMenu() {
        val mins = intArrayOf(0, 10, 20, 30, 45, 60, 90)
        val labels = mins.map { if (it == 0) getString(R.string.aud_sleep_off) else getString(R.string.aud_sleep_min_fmt, it) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(R.string.aud_sleep)
            .setItems(labels) { _, i -> MusicPlayer.setSleep(mins[i]); refreshNow() }
            .show()
    }

    private fun speedMenu() {
        val sp = floatArrayOf(0.75f, 0.9f, 1f, 1.1f, 1.25f, 1.5f, 2f)
        val labels = sp.map { (if (it == it.toInt().toFloat()) it.toInt().toString() else it.toString()) + "×" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(R.string.aud_speed)
            .setItems(labels) { _, i -> MusicPlayer.changeSpeed(sp[i]); refreshNow() }
            .show()
    }

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*")
            .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("audio/*", "video/*"))
        @Suppress("DEPRECATION")
        startActivityForResult(i, REQ_FILE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (TrashOps.handleResult(req, res)) return
        val u = data?.data
        if (req == REQ_FILE && res == RESULT_OK && u != null) {
            MusicPlayer.play(this, listOf(MusicPlayer.Track(u, audioDisplayName(this, u), "", 0L)), 0)
            refreshNow()
        }
    }

    private fun exportCurrent() {
        val t = MusicPlayer.current()
        if (t == null) {
            Toast.makeText(this, getString(R.string.aud_export_none), Toast.LENGTH_SHORT).show()
            return
        }
        runAudioExport(this, t.uri, t.title)
    }

    // ---- now playing
    private fun refreshNow() {
        val p = MusicPlayer.player
        val t = MusicPlayer.current()
        nowTitle.text = t?.title ?: ""
        val left = MusicPlayer.sleepLeftMin()
        sleepBtn.text = if (left > 0) getString(R.string.aud_sleep_left_fmt, left) else getString(R.string.aud_sleep)
        sleepBtn.setTextColor(if (left > 0) Ui.ACCENT else Ui.TEXT)
        MusicPlayer.speed.let { sp -> speedBtn.text = (if (sp == sp.toInt().toFloat()) sp.toInt().toString() else sp.toString()) + "×"; speedBtn.setTextColor(if (sp != 1f) Ui.ACCENT else Ui.TEXT) }
        nowArtist.text = t?.artist ?: ""
        playBtn.text = if (p != null && p.isPlaying) "❚❚" else "▶"
        if (p != null) {
            val d = p.duration.let { if (it == androidx.media3.common.C.TIME_UNSET) 0L else it }
            if (!dragging) {
                seek.progress = if (d > 0) (p.currentPosition * 1000L / d).toInt().coerceIn(0, 1000) else 0
                timeText.text = fmt(p.currentPosition) + " / " + fmt(d)
            }
            val on = Ui.ACCENT
            shuffleBtn.setTextColor(if (p.shuffleModeEnabled) on else Ui.TEXT)
            repeatBtn.text = getString(
                when (p.repeatMode) {
                    Player.REPEAT_MODE_ALL -> R.string.aud_repeat_all
                    Player.REPEAT_MODE_ONE -> R.string.aud_repeat_one
                    else -> R.string.aud_repeat_off
                }
            )
        } else {
            timeText.text = ""
            seek.progress = 0
        }
        adapter.notifyDataSetChanged()
    }

    override fun onResume() {
        super.onResume()
        ui.post(ticker)
    }

    override fun onPause() {
        ui.removeCallbacks(ticker)
        super.onPause()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        super.onDestroy() // the music itself goes on: it belongs to MusicPlayer / MusicService, not to this screen
    }

    private inner class TrackAdapter : BaseAdapter() {
        override fun getCount() = tracks.size
        override fun getItem(position: Int) = tracks[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val t = tracks[position]
            val row = (convertView as? LinearLayout) ?: LinearLayout(this@AudioActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(this@AudioActivity, 10), dp(this@AudioActivity, 9), dp(this@AudioActivity, 10), dp(this@AudioActivity, 9))
                addView(Ui.text(this@AudioActivity, "", 15f, Ui.TEXT).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
                addView(Ui.text(this@AudioActivity, "", 12f, Ui.MUTED).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
            }
            val title = row.getChildAt(0) as TextView
            val sub = row.getChildAt(1) as TextView
            title.text = t.title
            sub.text = (if (t.artist.isNotEmpty()) t.artist + "  ·  " else "") + fmt(t.durationMs)
            val playing = MusicPlayer.current()?.uri == t.uri
            title.setTextColor(if (playing) Ui.ACCENT else Ui.TEXT)
            return row
        }
    }

    private companion object {
        const val REQ_PERM = 31
        const val REQ_FILE = 32
    }
}
