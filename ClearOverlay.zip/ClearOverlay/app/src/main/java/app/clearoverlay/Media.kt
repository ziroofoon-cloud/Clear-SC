package app.clearoverlay

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Size

/** Extras understood by [PlayerActivity]: the playlist (same type only) and the position in it. */
object PlayerArgs {
    const val LIST = "app.clearoverlay.LIST"
    const val INDEX = "app.clearoverlay.INDEX"
    const val FROM_LIB = "app.clearoverlay.FROM_LIB"
}

/** Reads the phone's own media index (MediaStore), so videos and photos can be browsed without a file manager. */
object Media {
    class Item(
        val uri: Uri,
        val name: String,
        val bucketId: Long,
        val bucket: String,
        val durationMs: Long,
        val size: Long,
        val dateAdded: Long,
        val isVideo: Boolean
    )

    class Folder(val id: Long, val name: String, val count: Int, val cover: Uri?, val isVideo: Boolean)

    fun permissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_IMAGES)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    fun granted(ctx: Context): Boolean =
        permissions().any { ctx.checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    /** Natural order: "page2" before "page10". */
    fun natural(a: String, b: String): Int {
        var i = 0
        var j = 0
        while (i < a.length && j < b.length) {
            val ca = a[i]
            val cb = b[j]
            if (ca.isDigit() && cb.isDigit()) {
                var ei = i
                while (ei < a.length && a[ei].isDigit()) ei++
                var ej = j
                while (ej < b.length && b[ej].isDigit()) ej++
                val na = a.substring(i, ei).trimStart('0')
                val nb = b.substring(j, ej).trimStart('0')
                if (na.length != nb.length) return na.length - nb.length
                val c = na.compareTo(nb)
                if (c != 0) return c
                i = ei
                j = ej
            } else {
                val c = ca.lowercaseChar().compareTo(cb.lowercaseChar())
                if (c != 0) return c
                i++
                j++
            }
        }
        return (a.length - i) - (b.length - j)
    }

    fun queryVideos(ctx: Context): List<Item> {
        val out = ArrayList<Item>()
        val base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.BUCKET_ID,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME, MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE, MediaStore.Video.Media.DATE_ADDED
        )
        runCatching {
            ctx.contentResolver.query(base, proj, null, null, MediaStore.Video.Media.DATE_ADDED + " DESC")?.use { c ->
                while (c.moveToNext()) {
                    out.add(
                        Item(
                            ContentUris.withAppendedId(base, c.getLong(0)), c.getString(1) ?: "?", c.getLong(2),
                            c.getString(3) ?: "?", c.getLong(4), c.getLong(5), c.getLong(6), true
                        )
                    )
                }
            }
        }
        return out
    }

    fun queryImages(ctx: Context): List<Item> {
        val out = ArrayList<Item>()
        val base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.BUCKET_ID,
            MediaStore.Images.Media.BUCKET_DISPLAY_NAME, MediaStore.Images.Media.SIZE, MediaStore.Images.Media.DATE_ADDED
        )
        runCatching {
            ctx.contentResolver.query(base, proj, null, null, MediaStore.Images.Media.DATE_ADDED + " DESC")?.use { c ->
                while (c.moveToNext()) {
                    out.add(
                        Item(
                            ContentUris.withAppendedId(base, c.getLong(0)), c.getString(1) ?: "?", c.getLong(2),
                            c.getString(3) ?: "?", 0L, c.getLong(4), c.getLong(5), false
                        )
                    )
                }
            }
        }
        return out
    }

    /** Folders (buckets) of [items], biggest first is NOT used: alphabetical, with the newest item as the cover. */
    fun folders(items: List<Item>): List<Folder> {
        val map = LinkedHashMap<Long, MutableList<Item>>()
        for (it in items) map.getOrPut(it.bucketId) { ArrayList() }.add(it)
        return map.values
            .map { l -> Folder(l[0].bucketId, l[0].bucket, l.size, l[0].uri, l[0].isVideo) }
            .sortedWith { a, b -> natural(a.name, b.name) }
    }

    /** Items of one folder in the order used for browsing and for the player's playlist. */
    fun inFolder(items: List<Item>, bucketId: Long, byName: Boolean): List<Item> {
        val l = if (bucketId == ALL) items else items.filter { it.bucketId == bucketId }
        return if (byName) l.sortedWith { a, b -> natural(a.name, b.name) } else l
    }

    const val ALL = -1L

    /**
     * For a video / photo opened from outside the library ("Open with", file picker): the other files of the same
     * type in the same folder, so the player can still step to the next one. Null when it cannot be found.
     */
    fun siblings(ctx: Context, u: Uri, wantImage: Boolean): Pair<List<Uri>, Int>? {
        val id = runCatching {
            when (u.authority) {
                MediaStore.AUTHORITY -> ContentUris.parseId(u)
                "com.android.providers.media.documents" -> u.lastPathSegment!!.substringAfter(':').toLong()
                else -> null
            }
        }.getOrNull() ?: return null
        val base = if (wantImage) MediaStore.Images.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        return runCatching {
            var bucket = -1L
            ctx.contentResolver.query(
                ContentUris.withAppendedId(base, id), arrayOf(MediaStore.MediaColumns.BUCKET_ID), null, null, null
            )?.use { if (it.moveToFirst()) bucket = it.getLong(0) }
            if (bucket == -1L) return null
            val rows = ArrayList<Pair<Long, String>>()
            ctx.contentResolver.query(
                base, arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME),
                MediaStore.MediaColumns.BUCKET_ID + "=?", arrayOf(bucket.toString()), null
            )?.use { c -> while (c.moveToNext()) rows.add(Pair(c.getLong(0), c.getString(1) ?: "")) }
            rows.sortWith { a, b -> natural(a.second, b.second) }
            val idx = rows.indexOfFirst { it.first == id }
            if (idx < 0 || rows.size < 2) return null
            Pair(rows.map { ContentUris.withAppendedId(base, it.first) }, idx)
        }.getOrNull()
    }

    fun thumb(ctx: Context, uri: Uri, px: Int): Bitmap? =
        runCatching { ctx.contentResolver.loadThumbnail(uri, Size(px, px), null) }.getOrNull()

    /** Pages of a manga folder (images of one bucket) in reading order. */
    fun mangaPages(ctx: Context, bucketId: Long): List<Uri> {
        val base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val rows = ArrayList<Pair<Long, String>>()
        runCatching {
            ctx.contentResolver.query(
                base, arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME),
                MediaStore.MediaColumns.BUCKET_ID + "=?", arrayOf(bucketId.toString()), null
            )?.use { c -> while (c.moveToNext()) rows.add(Pair(c.getLong(0), c.getString(1) ?: "")) }
        }
        rows.sortWith { a, b -> natural(a.second, b.second) }
        return rows.map { ContentUris.withAppendedId(base, it.first) }
    }
}
