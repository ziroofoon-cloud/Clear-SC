package app.clearoverlay

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Size

/** Extras understood by [PlayerActivity]: the playlist (same type only) and the position in it. */
object PlayerArgs {
    const val LIST = "app.clearoverlay.LIST"
    const val INDEX = "app.clearoverlay.INDEX"
    const val FROM_LIB = "app.clearoverlay.FROM_LIB"
}

/** Reads the phone's own media index (MediaStore), so videos and photos can be browsed without a file manager. */
object Media {
    class Item(
        val uri: Uri,
        val name: String,
        val bucketId: Long,
        val bucket: String,
        val durationMs: Long,
        val size: Long,
        val dateAdded: Long,
        val isVideo: Boolean,
        /** Relative path inside a hand-added folder (used to order manga pages from sub-folders). */
        val path: String = name
    ) {
        /** A file of a hand-added folder that the phone's media index already lists: hidden from "All" to avoid doubles. */
        var dupe = false
    }

    /** [tree] is set for folders added by hand (a document-tree URI), null for folders from the media index. */
    class Folder(val id: Long, val name: String, val count: Int, val cover: Uri?, val isVideo: Boolean, val tree: String? = null)

    class Scan(val videos: List<Item>, val images: List<Item>)

    private const val CUSTOM_BIT = 1L shl 62
    fun customId(tree: String): Long = CUSTOM_BIT or (tree.hashCode().toLong() and 0xffffffffL)
    fun isCustom(id: Long): Boolean = id != ALL && (id and CUSTOM_BIT) != 0L

    fun permissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_IMAGES)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    fun granted(ctx: Context): Boolean =
        permissions().any { ctx.checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    /** Natural order: "page2" before "page10". */
    fun natural(a: String, b: String): Int {
        var i = 0
        var j = 0
        while (i < a.length && j < b.length) {
            val ca = a[i]
            val cb = b[j]
            if (ca.isDigit() && cb.isDigit()) {
                var ei = i
                while (ei < a.length && a[ei].isDigit()) ei++
                var ej = j
                while (ej < b.length && b[ej].isDigit()) ej++
                val na = a.substring(i, ei).trimStart('0')
                val nb = b.substring(j, ej).trimStart('0')
                if (na.length != nb.length) return na.length - nb.length
                val c = na.compareTo(nb)
                if (c != 0) return c
                i = ei
                j = ej
            } else {
                val c = ca.lowercaseChar().compareTo(cb.lowercaseChar())
                if (c != 0) return c
                i++
                j++
            }
        }
        return (a.length - i) - (b.length - j)
    }

    fun queryVideos(ctx: Context): List<Item> {
        val out = ArrayList<Item>()
        val base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.BUCKET_ID,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME, MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE, MediaStore.Video.Media.DATE_ADDED
        )
        runCatching {
            ctx.contentResolver.query(base, proj, null, null, MediaStore.Video.Media.DATE_ADDED + " DESC")?.use { c ->
                while (c.moveToNext()) {
                    out.add(
                        Item(
                            ContentUris.withAppendedId(base, c.getLong(0)), c.getString(1) ?: "?", c.getLong(2),
                            c.getString(3) ?: "?", c.getLong(4), c.getLong(5), c.getLong(6), true
                        )
                    )
                }
            }
        }
        return out
    }

    fun queryImages(ctx: Context): List<Item> {
        val out = ArrayList<Item>()
        val base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.BUCKET_ID,
            MediaStore.Images.Media.BUCKET_DISPLAY_NAME, MediaStore.Images.Media.SIZE, MediaStore.Images.Media.DATE_ADDED
        )
        runCatching {
            ctx.contentResolver.query(base, proj, null, null, MediaStore.Images.Media.DATE_ADDED + " DESC")?.use { c ->
                while (c.moveToNext()) {
                    out.add(
                        Item(
                            ContentUris.withAppendedId(base, c.getLong(0)), c.getString(1) ?: "?", c.getLong(2),
                            c.getString(3) ?: "?", 0L, c.getLong(4), c.getLong(5), false
                        )
                    )
                }
            }
        }
        return out
    }

    /** Folders (buckets) of [items], biggest first is NOT used: alphabetical, with the newest item as the cover. */
    fun folders(items: List<Item>): List<Folder> {
        val map = LinkedHashMap<Long, MutableList<Item>>()
        for (it in items) map.getOrPut(it.bucketId) { ArrayList() }.add(it)
        return map.values
            .map { l -> Folder(l[0].bucketId, l[0].bucket, l.size, l[0].uri, l[0].isVideo) }
            .sortedWith { a, b -> natural(a.name, b.name) }
    }

    /** Items of one folder in the order used for browsing and for the player's playlist. */
    fun inFolder(items: List<Item>, bucketId: Long, byName: Boolean): List<Item> {
        val l = if (bucketId == ALL) items.filter { !it.dupe } else items.filter { it.bucketId == bucketId }
        return if (byName) l.sortedWith { a, b -> natural(a.name, b.name) } else l
    }

    const val ALL = -1L

    /**
     * For a video / photo opened from outside the library ("Open with", file picker): the other files of the same
     * type in the same folder, so the player can still step to the next one. Null when it cannot be found.
     */
    fun siblings(ctx: Context, u: Uri, wantImage: Boolean): Pair<List<Uri>, Int>? {
        val id = runCatching {
            when (u.authority) {
                MediaStore.AUTHORITY -> ContentUris.parseId(u)
                "com.android.providers.media.documents" -> u.lastPathSegment!!.substringAfter(':').toLong()
                else -> null
            }
        }.getOrNull() ?: return null
        val base = if (wantImage) MediaStore.Images.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        return runCatching {
            var bucket = -1L
            ctx.contentResolver.query(
                ContentUris.withAppendedId(base, id), arrayOf(MediaStore.MediaColumns.BUCKET_ID), null, null, null
            )?.use { if (it.moveToFirst()) bucket = it.getLong(0) }
            if (bucket == -1L) return null
            val rows = ArrayList<Pair<Long, String>>()
            ctx.contentResolver.query(
                base, arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME),
                MediaStore.MediaColumns.BUCKET_ID + "=?", arrayOf(bucket.toString()), null
            )?.use { c -> while (c.moveToNext()) rows.add(Pair(c.getLong(0), c.getString(1) ?: "")) }
            rows.sortWith { a, b -> natural(a.second, b.second) }
            val idx = rows.indexOfFirst { it.first == id }
            if (idx < 0 || rows.size < 2) return null
            Pair(rows.map { ContentUris.withAppendedId(base, it.first) }, idx)
        }.getOrNull()
    }

    fun thumb(ctx: Context, uri: Uri, px: Int): Bitmap? {
        runCatching { return ctx.contentResolver.loadThumbnail(uri, Size(px, px), null) }
        // hand-added folders: the provider may not make thumbnails, so build one ourselves
        val mime = runCatching { ctx.contentResolver.getType(uri) }.getOrNull() ?: ""
        return runCatching {
            if (mime.startsWith("video/") || (mime.isEmpty() && isVideoName(uri.lastPathSegment ?: ""))) {
                val r = android.media.MediaMetadataRetriever()
                try {
                    r.setDataSource(ctx, uri)
                    val dur = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                    val f = r.getFrameAtTime(minOf(1_000_000L, dur * 300L), android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    f?.let { Bitmap.createScaledBitmap(it, px, (px * it.height / it.width.coerceAtLeast(1)).coerceAtLeast(1), true) }
                } finally {
                    r.release()
                }
            } else {
                val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                ctx.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, o) }
                var sample = 1
                while (o.outWidth / (sample * 2) >= px && o.outHeight / (sample * 2) >= px) sample *= 2
                val o2 = android.graphics.BitmapFactory.Options().apply { inSampleSize = sample }
                ctx.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, o2) }
            }
        }.getOrNull()
    }

    private val VIDEO_EXT = setOf("mp4", "mkv", "webm", "avi", "mov", "m4v", "3gp", "ts", "flv", "wmv", "mpg", "mpeg", "mts", "m2ts", "ogv")
    private val IMAGE_EXT = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif", "avif")
    private fun isVideoName(n: String) = n.substringAfterLast('.', "").lowercase() in VIDEO_EXT
    private fun isImageName(n: String) = n.substringAfterLast('.', "").lowercase() in IMAGE_EXT

    /**
     * Scans a folder added by hand (document tree), sub-folders included (depth <= 8, hidden folders skipped).
     * Both kinds are returned in one pass; items are newest first.
     */
    fun scanTree(ctx: Context, tree: Uri, bucketName: String): Scan {
        val bucket = customId(tree.toString())
        val vids = ArrayList<Item>()
        val imgs = ArrayList<Item>()
        val cols = arrayOf(
            android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            android.provider.DocumentsContract.Document.COLUMN_MIME_TYPE,
            android.provider.DocumentsContract.Document.COLUMN_SIZE,
            android.provider.DocumentsContract.Document.COLUMN_LAST_MODIFIED
        )
        fun walk(docId: String, rel: String, depth: Int) {
            if (vids.size + imgs.size > 30000) return
            val kids = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            runCatching {
                ctx.contentResolver.query(kids, cols, null, null, null)?.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getString(0) ?: continue
                        val name = c.getString(1) ?: continue
                        val mime = c.getString(2) ?: ""
                        if (name.startsWith(".")) continue
                        if (mime == android.provider.DocumentsContract.Document.MIME_TYPE_DIR) {
                            if (depth < 8) walk(id, "$rel$name/", depth + 1)
                            continue
                        }
                        val video = mime.startsWith("video/") || (!mime.startsWith("image/") && isVideoName(name))
                        val image = !video && (mime.startsWith("image/") || isImageName(name))
                        if (!video && !image) continue
                        val u = android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, id)
                        val itm = Item(u, name, bucket, bucketName, 0L, c.getLong(3), c.getLong(4) / 1000L, video, rel + name)
                        if (video) vids.add(itm) else imgs.add(itm)
                    }
                }
            }
        }
        runCatching { walk(android.provider.DocumentsContract.getTreeDocumentId(tree), "", 0) }
        vids.sortByDescending { it.dateAdded }
        imgs.sortByDescending { it.dateAdded }
        return Scan(vids, imgs)
    }

    /** Marks hand-added files that the media index already lists, so "All videos / photos" does not show them twice. */
    fun markDupes(indexed: List<Item>, extra: List<Item>) {
        if (extra.isEmpty() || indexed.isEmpty()) return
        val seen = HashSet<String>(indexed.size * 2)
        for (i in indexed) seen.add(i.name + "|" + i.size)
        for (e in extra) if (e.name + "|" + e.size in seen) e.dupe = true
    }

    /** Display name of a document tree (its folder name). */
    fun treeName(ctx: Context, tree: Uri): String = runCatching {
        val d = android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, android.provider.DocumentsContract.getTreeDocumentId(tree))
        ctx.contentResolver.query(d, arrayOf(android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    }.getOrNull() ?: (tree.lastPathSegment ?: "?").substringAfterLast(':').substringAfterLast('/')

    /** Pages of a hand-added manga folder (images of the tree and its sub-folders) in reading order. */
    fun mangaPagesTree(ctx: Context, tree: Uri): List<Uri> =
        scanTree(ctx, tree, "").images.sortedWith { a, b -> natural(a.path, b.path) }.map { it.uri }

    /** Pages of a manga folder (images of one bucket) in reading order. */
    fun mangaPages(ctx: Context, bucketId: Long): List<Uri> {
        val base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val rows = ArrayList<Pair<Long, String>>()
        runCatching {
            ctx.contentResolver.query(
                base, arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME),
                MediaStore.MediaColumns.BUCKET_ID + "=?", arrayOf(bucketId.toString()), null
            )?.use { c -> while (c.moveToNext()) rows.add(Pair(c.getLong(0), c.getString(1) ?: "")) }
        }
        rows.sortWith { a, b -> natural(a.second, b.second) }
        return rows.map { ContentUris.withAppendedId(base, it.first) }
    }
}
