package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.widget.Toast

/**
 * Deleting for every section. Files of the phone's media store (pictures, videos, GIFs, music, most manga files) go to the
 * phone's own trash (kept 30 days, can be restored) or are deleted for good; Android shows its own "allow" box for both.
 * Files that are not in the media store (a folder added with "add folder") can only be deleted for good.
 */
object TrashOps {
    const val REQ = 9101
    private var after: (() -> Unit)? = null

    private enum class Kind { TRASH, RESTORE, FOREVER }

    /** Asks "move to trash" or "delete forever" and does it; [onDone] runs when the files are really gone (or in the trash). */
    fun confirmDelete(act: Activity, uris: List<Uri>, onDone: () -> Unit) {
        if (uris.isEmpty()) return
        if (uris.none { isMedia(it) }) {
            // not in the phone's media store (a folder that was added, a picked file): no trash exists, so say so and delete for good
            AlertDialog.Builder(act)
                .setTitle(act.getString(R.string.trash_title_fmt, uris.size))
                .setMessage(R.string.trash_other_note)
                .setPositiveButton(R.string.trash_forever) { _, _ -> request(act, uris, Kind.FOREVER, onDone) }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
            return
        }
        AlertDialog.Builder(act)
            .setTitle(act.getString(R.string.trash_title_fmt, uris.size))
            .setItems(arrayOf(act.getString(R.string.trash_move), act.getString(R.string.trash_forever))) { _, w ->
                request(act, uris, if (w == 0) Kind.TRASH else Kind.FOREVER, onDone)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    fun restore(act: Activity, uris: List<Uri>, onDone: () -> Unit) = request(act, uris, Kind.RESTORE, onDone)

    fun deleteForever(act: Activity, uris: List<Uri>, onDone: () -> Unit) = request(act, uris, Kind.FOREVER, onDone)

    private fun isMedia(u: Uri) = u.authority == MediaStore.AUTHORITY

    private fun request(act: Activity, uris: List<Uri>, kind: Kind, onDone: () -> Unit) {
        val media = uris.filter { isMedia(it) }
        val others = uris.filterNot { isMedia(it) }
        var failed = 0
        if (others.isNotEmpty() && kind != Kind.RESTORE) {
            // no trash for these: they are deleted for good (the person was told in the dialog)
            for (u in others) if (!deleteOne(act, u)) failed++
            if (failed > 0) Toast.makeText(act, act.getString(R.string.trash_failed_fmt, failed.toString()), Toast.LENGTH_LONG).show()
        }
        if (media.isEmpty()) {
            if (others.isNotEmpty() && kind != Kind.RESTORE) onDone()
            return
        }
        try {
            val cr = act.contentResolver
            val pi = when (kind) {
                Kind.TRASH -> MediaStore.createTrashRequest(cr, media, true)
                Kind.RESTORE -> MediaStore.createTrashRequest(cr, media, false)
                Kind.FOREVER -> MediaStore.createDeleteRequest(cr, media)
            }
            after = onDone
            @Suppress("DEPRECATION")
            act.startIntentSenderForResult(pi.intentSender, REQ, null, 0, 0, 0)
        } catch (t: Throwable) {
            after = null
            Toast.makeText(act, act.getString(R.string.trash_failed_fmt, t.message ?: t.javaClass.simpleName), Toast.LENGTH_LONG).show()
        }
    }

    private fun deleteOne(act: Activity, u: Uri): Boolean = runCatching {
        when {
            u.scheme == "file" -> {
                val f = java.io.File(u.path ?: return false)
                val ok = f.delete()
                if (ok) android.media.MediaScannerConnection.scanFile(act, arrayOf(f.absolutePath), null, null)
                ok
            }
            DocumentsContract.isDocumentUri(act, u) -> DocumentsContract.deleteDocument(act.contentResolver, u)
            else -> act.contentResolver.delete(u, null, null) > 0
        }
    }.getOrDefault(false)

    private fun cleanName(n: String) = n.trim().replace('/', '_').replace('\\', '_').replace(Regex("[\\u0000-\\u001f]"), "")

    /**
     * Renames a file for every section: a file path, a document from the file picker, or a media-store item (video, photo, song). For a
     * song the title shown in the music list is changed too. [onDone] runs after it worked.
     */
    fun rename(act: Activity, u: Uri, newName: String, onDone: () -> Unit) {
        val name = cleanName(newName)
        if (name.isEmpty()) return
        fun fail(m: String? = null) = Toast.makeText(act, act.getString(R.string.rename_failed) + (m?.let { "\n$it" } ?: ""), Toast.LENGTH_LONG).show()
        when {
            u.scheme == "file" -> {
                val f = java.io.File(u.path ?: return fail())
                val t = java.io.File(f.parentFile, name)
                if (t.exists()) return fail(act.getString(R.string.rename_exists))
                if (f.renameTo(t)) {
                    android.media.MediaScannerConnection.scanFile(act, arrayOf(f.absolutePath, t.absolutePath), null, null)
                    onDone()
                } else fail()
            }
            isMedia(u) -> {
                fun update(): Boolean {
                    val cv = android.content.ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                        if (u.toString().contains("/audio/")) put(MediaStore.Audio.Media.TITLE, name.substringBeforeLast('.'))
                    }
                    return act.contentResolver.update(u, cv, null, null) > 0
                }
                try {
                    if (update()) onDone() else fail()
                } catch (e: SecurityException) {
                    // not the app's own file: Android asks the person for permission to change it, then the change is made
                    try {
                        val pi = MediaStore.createWriteRequest(act.contentResolver, listOf(u))
                        after = { if (runCatching { update() }.getOrDefault(false)) onDone() else fail() }
                        @Suppress("DEPRECATION")
                        act.startIntentSenderForResult(pi.intentSender, REQ, null, 0, 0, 0)
                    } catch (t: Throwable) {
                        after = null
                        fail(t.message)
                    }
                } catch (e: Exception) {
                    fail(e.message)
                }
            }
            DocumentsContract.isDocumentUri(act, u) -> {
                val r = runCatching { DocumentsContract.renameDocument(act.contentResolver, u, name) }.getOrNull()
                if (r != null) onDone() else fail()
            }
            else -> fail()
        }
    }

    /** Asks for a new name (the extension is left out of the selection) and renames. */
    fun renameDialog(act: Activity, u: Uri, current: String, onDone: () -> Unit) {
        val input = android.widget.EditText(act).apply {
            setSingleLine()
            setText(current)
            setSelection(0, current.substringBeforeLast('.', current).length)
        }
        val box = android.widget.FrameLayout(act).apply { setPadding(dp(act, 20), dp(act, 8), dp(act, 20), 0); addView(input) }
        AlertDialog.Builder(act).setTitle(R.string.fm_rename).setView(box)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val n = input.text.toString().trim()
                if (n.isNotEmpty() && n != current) rename(act, u, n, onDone)
            }
            .setNegativeButton(android.R.string.cancel, null).show()
    }

    /** Call from the activity's onActivityResult; true when the result was ours. */
    fun handleResult(req: Int, res: Int): Boolean {
        if (req != REQ) return false
        val a = after
        after = null
        if (res == Activity.RESULT_OK) a?.invoke()
        return true
    }
}
