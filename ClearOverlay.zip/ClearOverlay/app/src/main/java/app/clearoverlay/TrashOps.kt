package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.widget.Toast

/**
 * Deleting for every section. Files of the phone's media store (pictures, videos, GIFs, music, most manga files) go to the
 * phone's own trash (kept 30 days, can be restored) or are deleted for good; Android shows its own "allow" box for both.
 * Files that are not in the media store (a folder added with "add folder") can only be deleted for good.
 */
object TrashOps {
    const val REQ = 9101
    private var after: (() -> Unit)? = null

    private enum class Kind { TRASH, RESTORE, FOREVER }

    /** Asks "move to trash" or "delete forever" and does it; [onDone] runs when the files are really gone (or in the trash). */
    fun confirmDelete(act: Activity, uris: List<Uri>, onDone: () -> Unit) {
        if (uris.isEmpty()) return
        AlertDialog.Builder(act)
            .setTitle(act.getString(R.string.trash_title_fmt, uris.size))
            .setItems(arrayOf(act.getString(R.string.trash_move), act.getString(R.string.trash_forever))) { _, w ->
                request(act, uris, if (w == 0) Kind.TRASH else Kind.FOREVER, onDone)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    fun restore(act: Activity, uris: List<Uri>, onDone: () -> Unit) = request(act, uris, Kind.RESTORE, onDone)

    fun deleteForever(act: Activity, uris: List<Uri>, onDone: () -> Unit) = request(act, uris, Kind.FOREVER, onDone)

    private fun isMedia(u: Uri) = u.authority == MediaStore.AUTHORITY

    private fun request(act: Activity, uris: List<Uri>, kind: Kind, onDone: () -> Unit) {
        val media = uris.filter { isMedia(it) }
        val others = uris.filterNot { isMedia(it) }
        if (others.isNotEmpty()) {
            if (kind == Kind.FOREVER) {
                for (u in others) deleteOne(act, u)
            } else {
                Toast.makeText(act, R.string.trash_other_note, Toast.LENGTH_LONG).show()
            }
        }
        if (media.isEmpty()) {
            if (kind == Kind.FOREVER && others.isNotEmpty()) onDone()
            return
        }
        try {
            val cr = act.contentResolver
            val pi = when (kind) {
                Kind.TRASH -> MediaStore.createTrashRequest(cr, media, true)
                Kind.RESTORE -> MediaStore.createTrashRequest(cr, media, false)
                Kind.FOREVER -> MediaStore.createDeleteRequest(cr, media)
            }
            after = onDone
            @Suppress("DEPRECATION")
            act.startIntentSenderForResult(pi.intentSender, REQ, null, 0, 0, 0)
        } catch (t: Throwable) {
            after = null
            Toast.makeText(act, act.getString(R.string.trash_failed_fmt, t.message ?: t.javaClass.simpleName), Toast.LENGTH_LONG).show()
        }
    }

    private fun deleteOne(act: Activity, u: Uri) {
        runCatching {
            if (DocumentsContract.isDocumentUri(act, u)) DocumentsContract.deleteDocument(act.contentResolver, u)
            else act.contentResolver.delete(u, null, null)
        }
    }

    /** Call from the activity's onActivityResult; true when the result was ours. */
    fun handleResult(req: Int, res: Int): Boolean {
        if (req != REQ) return false
        val a = after
        after = null
        if (res == Activity.RESULT_OK) a?.invoke()
        return true
    }
}
