package app.clearoverlay

import android.opengl.GLES30

/**
 * Measures how long each pass of one frame takes on THIS phone's GPU (the "Measure speed" button in the FX settings).
 * While a measurement runs, the GPU is waited for after every pass (glFinish), so each pass can be timed; that makes the frame a little
 * slower than normal while it runs, and the numbers are relative costs: use them to see WHICH pass is the heavy one. The report can be
 * copied and sent, and the next round of "make it lighter" is then done on real numbers instead of guesses. Costs nothing when off.
 */
object PassTimer {
    @Volatile private var left = 0
    private var last = 0L
    private val sums = LinkedHashMap<String, Long>()
    private var frames = 0
    private var total = 0L
    @Volatile var report: String? = null
        private set

    val running: Boolean get() = left > 0

    /** Starts a measurement over [n] frames. */
    @Synchronized fun start(n: Int = 20) {
        sums.clear()
        frames = 0
        total = 0L
        report = null
        left = n
    }

    /** Called on the GL thread when a frame starts drawing. */
    fun begin() {
        if (left <= 0) return // (the normal case: one volatile read per call, no lock)
        beginSlow()
    }

    @Synchronized private fun beginSlow() {
        if (left <= 0) return
        GLES30.glFinish()
        last = System.nanoTime()
    }

    /** The work since the previous mark belonged to [name]. */
    fun mark(name: String) {
        if (left <= 0) return
        markSlow(name)
    }

    @Synchronized private fun markSlow(name: String) {
        if (left <= 0) return
        GLES30.glFinish()
        val now = System.nanoTime()
        val d = now - last
        last = now
        sums[name] = (sums[name] ?: 0L) + d
        total += d
    }

    /** Called when the frame is finished; builds the report after the last frame. */
    fun end() {
        if (left <= 0) return
        endSlow()
    }

    @Synchronized private fun endSlow() {
        if (left <= 0) return
        markSlow("finish (colour, sharpen, show)")
        frames++
        left--
        if (left == 0) report = build()
    }

    @Synchronized fun partial(): String? = if (frames > 0 && report == null) build() else report

    private fun build(): String {
        val n = frames.coerceAtLeast(1)
        val sb = StringBuilder()
        sb.append("+CRSC pass times, average of ").append(n).append(" frames\n")
        sb.append(android.os.Build.MANUFACTURER).append(' ').append(android.os.Build.MODEL).append('\n')
        sb.append("mode ").append(Cfg.mode).append(", CRSC level ").append(Cfg.crscLevel).append(", upscaler speed ").append(Cfg.upOpt)
            .append(", render ").append(Cfg.scalePct).append("%\n")
        for ((k, v) in sums) sb.append(String.format(java.util.Locale.US, "%-34s %6.2f ms  %4.0f%%\n", k, v / 1e6 / n, if (total > 0) v * 100.0 / total else 0.0))
        sb.append(String.format(java.util.Locale.US, "%-34s %6.2f ms\n", "total (GPU waited after each pass)", total / 1e6 / n))
        return sb.toString()
    }
}
