package app.clearoverlay

import android.opengl.GLES30

/**
 * Measures how long each pass of one frame takes on THIS phone's GPU (the "Measure speed" button in the FX settings).
 *
 * Two parts, one after the other:
 *  1. [ROUNDS] rounds of [FRAMES] frames in which the GPU is waited for after every pass (glFinish), so each pass can be timed. The first [WARM]
 *     frames of every round are thrown away (the GPU clock and the caches are still settling), a short rest sits between the rounds (so the measuring
 *     itself does not heat the GPU) and the report gives each pass's average, the spread between the rounds, and the passes sorted by cost.
 *  2. [PLAIN_FRAMES] frames timed as a whole, with no waiting between the passes: the REAL time of a frame (median, 95th percentile, slowest),
 *     the frame rate that allows, and, in the video player, whether it fits the video's frame time.
 * Costs nothing when off (one volatile read per mark).
 */
object PassTimer {
    const val ROUNDS = 3
    const val FRAMES = 24
    private const val WARM = 4
    private const val PLAIN_FRAMES = 40
    private const val PLAIN_WARM = 6
    private const val REST_MS = 800L

    @Volatile private var left = 0          // frames still to measure in the running round (0 = not measuring right now)
    @Volatile private var roundsLeft = 0    // rounds still to start (after the running one)
    @Volatile private var resumeAt = 0L
    @Volatile private var active = false
    @Volatile private var plainLeft = 0     // frames still to time as a whole (after the rounds)
    @Volatile private var plainOn = false   // a whole-frame timing is running right now
    private var plainT0 = 0L
    private var plainSeen = 0
    private val plainMs = ArrayList<Double>()
    private var last = 0L
    private val sums = LinkedHashMap<String, Long>()       // this round
    private var frames = 0
    private var total = 0L
    private val all = ArrayList<Pair<LinkedHashMap<String, Long>, Int>>() // finished rounds: sums, counted frames
    private val notes = LinkedHashMap<String, String>() // what the pipeline did that explains the numbers (AI 2x state, the big-picture path ...)
    @Volatile var report: String? = null
        private set
    /** The median real frame time of the last finished measurement in ms (0 = none): the Load panel calibrates its estimate with it. */
    @Volatile var realMedianMs = 0.0
        private set

    // what the pipeline tells while measuring
    @Volatile private var surfW = 0
    @Volatile private var surfH = 0
    @Volatile private var budgetMs = 0f
    @Volatile private var gpu: String? = null

    val running: Boolean get() = active
    val round: Int get() = all.size + 1
    /** The rounds are done and the whole-frame timing is running. */
    val inPlain: Boolean get() = active && left <= 0 && roundsLeft == 0 && plainLeft > 0

    /** Starts a measurement. */
    @Synchronized fun start() {
        sums.clear(); all.clear(); plainMs.clear(); synchronized(notes) { notes.clear() }
        frames = 0; total = 0L; plainSeen = 0
        report = null
        realMedianMs = 0.0
        roundsLeft = ROUNDS - 1
        left = FRAMES + WARM
        plainLeft = 0
        plainOn = false
        active = true
    }

    /**
     * A short measurement for "Find the fastest setting": only the whole-frame timing (no per-pass rounds, no rests), about 46 frames.
     * The result is [realMedianMs] (0 = too few frames were drawn).
     */
    @Synchronized fun startQuick() {
        sums.clear(); all.clear(); plainMs.clear()
        frames = 0; total = 0L; plainSeen = 0
        report = null
        realMedianMs = 0.0
        roundsLeft = 0
        left = 0
        resumeAt = 0L
        plainLeft = PLAIN_FRAMES + PLAIN_WARM
        plainOn = false
        active = true
    }

    /** Stops a measurement that has not finished (nothing is kept). */
    @Synchronized fun cancel() {
        active = false
        left = 0; roundsLeft = 0; plainLeft = 0; plainOn = false
    }

    /** The pipeline tells a fact that explains the numbers (the newest text of a [key] is kept; only while measuring). */
    fun note(key: String, text: String) {
        synchronized(notes) { notes[key] = text }
    }

    /** The pipeline says what it draws (called per frame, only while measuring): the output size and the video's frame time (0 = not a video). */
    fun context(w: Int, h: Int, budget: Float) {
        surfW = w
        surfH = h
        budgetMs = budget
        if (gpu == null) gpu = runCatching { GLES30.glGetString(GLES30.GL_RENDERER) }.getOrNull()
    }

    /** Called on the GL thread when a frame starts drawing. */
    fun begin() {
        if (left <= 0) {
            val now = System.nanoTime() / 1_000_000L
            if (roundsLeft > 0 && now >= resumeAt) nextRound()
            if (left <= 0) {
                if (plainLeft > 0 && !plainOn && now >= resumeAt) plainBegin()
                return
            }
        }
        beginSlow()
    }

    @Synchronized private fun nextRound() {
        if (left > 0 || roundsLeft <= 0) return
        roundsLeft--
        sums.clear(); frames = 0; total = 0L
        left = FRAMES + WARM
    }

    @Synchronized private fun beginSlow() {
        if (left <= 0) return
        GLES30.glFinish()
        last = System.nanoTime()
    }

    @Synchronized private fun plainBegin() {
        if (plainLeft <= 0 || plainOn) return
        GLES30.glFinish()
        plainT0 = System.nanoTime()
        plainOn = true
    }

    /** The work since the previous mark belonged to [name]. */
    fun mark(name: String) {
        if (left <= 0) return
        markSlow(name)
    }

    @Synchronized private fun markSlow(name: String) {
        if (left <= 0) return
        GLES30.glFinish()
        val now = System.nanoTime()
        val d = now - last
        last = now
        if (frames >= WARM) { // the first frames of a round are only warm-up
            sums[name] = (sums[name] ?: 0L) + d
            total += d
        }
    }

    /** Called when the frame is finished; closes the round after its last frame and builds the report after the last part. */
    fun end() {
        if (left > 0) endSlow()
        else if (plainOn) plainEnd()
    }

    @Synchronized private fun endSlow() {
        if (left <= 0) return
        markSlow("finish (rest)")
        frames++
        left--
        if (left == 0) {
            all.add(LinkedHashMap(sums) to (frames - WARM).coerceAtLeast(1))
            resumeAt = System.nanoTime() / 1_000_000L + REST_MS
            if (roundsLeft == 0) {
                plainLeft = PLAIN_FRAMES + PLAIN_WARM
                plainSeen = 0
            }
        }
    }

    @Synchronized private fun plainEnd() {
        if (!plainOn) return
        GLES30.glFinish()
        val ms = (System.nanoTime() - plainT0) / 1e6
        plainOn = false
        plainLeft--
        if (plainSeen++ >= PLAIN_WARM) plainMs.add(ms)
        if (plainLeft == 0) {
            report = build()
            active = false
        }
    }

    /** What there is so far (the report, or the finished rounds / the running one when it was cut short); null when nothing was drawn. */
    @Synchronized fun partial(): String? {
        if (report != null) return report
        if (all.isEmpty() && frames > WARM) all.add(LinkedHashMap(sums) to (frames - WARM))
        return if (all.isEmpty()) null else build().also { active = false; left = 0; roundsLeft = 0; plainLeft = 0; plainOn = false }
    }

    private fun f(v: Double, n: Int = 2): String = String.format(java.util.Locale.US, "%." + n + "f", v)

    private fun build(): String {
        val names = LinkedHashSet<String>()
        for ((s, _) in all) names.addAll(s.keys)
        val perRoundTotal = all.map { (s, n) -> s.values.sum() / 1e6 / n.coerceAtLeast(1) }
        val nFrames = all.sumOf { it.second }
        val avgTotal = perRoundTotal.average()
        val sb = StringBuilder()
        sb.append("+CRSC pass times: ").append(all.size).append(" rounds, ").append(nFrames).append(" frames counted (").append(WARM).append(" warm-up frames per round left out)\n")
        sb.append(android.os.Build.MANUFACTURER).append(' ').append(android.os.Build.MODEL)
        gpu?.let { sb.append(" | GPU ").append(it) }
        sb.append('\n')
        if (surfW > 0) sb.append("drawing at ").append(surfW).append('x').append(surfH).append('\n')
        sb.append("mode ").append(Cfg.mode).append(", CRSC level ").append(Cfg.crscLevel).append(", upscaler speed: ").append(arrayOf("ORIGINAL", "LIGHT", "LIGHTEST")[Cfg.upOpt.coerceIn(0, 2)]).append(" (").append(Cfg.upOpt).append(")")
            .append(", render ").append(Cfg.scalePct).append("%")
            .append(", Fine pixels ").append(if (Cfg.finePixels) "on" else "off").append(", smooth live ").append(if (Cfg.smoothLive) "on" else "off").append("\n")
        synchronized(notes) { for (v in notes.values) sb.append("• ").append(v).append('\n') }
        sb.append('\n')
        // every pass: average per frame, the share, the spread between the rounds (±), biggest first
        class Row(val name: String, val avg: Double, val sd: Double)
        val rows = names.map { k ->
            val per = all.map { (s, n) -> (s[k] ?: 0L) / 1e6 / n.coerceAtLeast(1) }
            val avg = per.average()
            val sd = if (per.size > 1) Math.sqrt(per.sumOf { (it - avg) * (it - avg) } / (per.size - 1)) else 0.0
            Row(k, avg, sd)
        }.sortedByDescending { it.avg }
        for (r in rows) {
            val share = if (avgTotal > 0) r.avg * 100.0 / avgTotal else 0.0
            val bar = "█".repeat((share / 10.0).toInt().coerceIn(0, 10))
            sb.append(String.format(java.util.Locale.US, "%-32s %6.2f ms ±%.2f  %3.0f%% %s\n", r.name, r.avg, r.sd, share, bar))
        }
        sb.append(String.format(java.util.Locale.US, "%-32s %6.2f ms\n", "SUM OF THE PASSES", avgTotal))
        if (perRoundTotal.size > 1) {
            val mn = perRoundTotal.min()
            val mx = perRoundTotal.max()
            sb.append("rounds: ").append(perRoundTotal.joinToString(" / ") { f(it, 1) })
                .append(" ms  (spread ").append(f(if (avgTotal > 0) (mx - mn) * 100.0 / avgTotal else 0.0, 1)).append("%: differences smaller than this are noise)\n")
        }
        sb.append("(the GPU is waited for after every pass, so the sum is a little higher than the real frame time)\n")
        // the real frame time
        if (plainMs.size >= 5) {
            val sorted = plainMs.sorted()
            val med = sorted[sorted.size / 2]
            realMedianMs = med
            val p95 = sorted[((sorted.size - 1) * 95 / 100)]
            val worst = sorted.last()
            sb.append("\nREAL FRAME TIME (whole frame, ").append(plainMs.size).append(" frames): median ").append(f(med)).append(" ms, 95% under ")
                .append(f(p95)).append(" ms, slowest ").append(f(worst)).append(" ms\n")
            if (med > 0.01) sb.append("this phone can draw about ").append(f(1000.0 / med, 0)).append(" frames per second with these settings (95% of the frames: ").append(f(1000.0 / p95, 0)).append(")\n")
            val b = budgetMs
            if (b > 1f) {
                val verdict = when {
                    p95 <= b * 0.7 -> "comfortable: there is room left"
                    p95 <= b * 0.95 -> "fits, but with little room (a hot phone may drop frames)"
                    med <= b -> "borderline: the median fits, the slower frames do not (some frames will drop)"
                    else -> "TOO SLOW for this video: frames will drop; lighten the settings or switch on Auto-lighten"
                }
                sb.append("the video needs a frame every ").append(f(b.toDouble(), 1)).append(" ms (").append(f(1000.0 / b, 0)).append(" fps): ").append(verdict).append('\n')
            }
        } else if (all.isNotEmpty()) sb.append("\n(the whole-frame timing did not finish: too few frames were drawn)\n")
        return sb.toString().trimEnd()
    }
}
