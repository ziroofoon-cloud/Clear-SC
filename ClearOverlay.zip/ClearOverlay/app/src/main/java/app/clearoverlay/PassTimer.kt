package app.clearoverlay

import android.opengl.GLES30

/**
 * Measures how long each pass of one frame takes on THIS phone's GPU (the "Measure speed" button in the FX settings).
 * While a round runs, the GPU is waited for after every pass (glFinish), so each pass can be timed; that makes the frame a little
 * slower than normal while it runs, and the numbers are relative costs. A measurement is [ROUNDS] rounds of [FRAMES] frames with a
 * short rest in between (so the GPU does not heat up from the measuring itself); the report gives the average of all rounds, the
 * spread between the rounds (the run-to-run noise) and the total of every round. Costs nothing when off (one volatile read per mark).
 */
object PassTimer {
    const val ROUNDS = 3
    const val FRAMES = 20
    private const val REST_MS = 800L

    @Volatile private var left = 0          // frames still to measure in the running round (0 = not measuring right now)
    @Volatile private var roundsLeft = 0    // rounds still to start (after the running one)
    @Volatile private var resumeAt = 0L
    @Volatile private var active = false
    private var last = 0L
    private val sums = LinkedHashMap<String, Long>()       // this round
    private var frames = 0
    private var total = 0L
    private val all = ArrayList<Pair<LinkedHashMap<String, Long>, Int>>() // finished rounds: sums, frames
    @Volatile var report: String? = null
        private set

    val running: Boolean get() = active
    val round: Int get() = all.size + 1

    /** Starts a measurement (3 rounds of 20 frames). */
    @Synchronized fun start() {
        sums.clear(); all.clear()
        frames = 0; total = 0L
        report = null
        roundsLeft = ROUNDS - 1
        left = FRAMES
        active = true
    }

    /** Called on the GL thread when a frame starts drawing. */
    fun begin() {
        if (left <= 0) {
            if (roundsLeft > 0 && System.nanoTime() / 1_000_000L >= resumeAt) nextRound()
            if (left <= 0) return
        }
        beginSlow()
    }

    @Synchronized private fun nextRound() {
        if (left > 0 || roundsLeft <= 0) return
        roundsLeft--
        sums.clear(); frames = 0; total = 0L
        left = FRAMES
    }

    @Synchronized private fun beginSlow() {
        if (left <= 0) return
        GLES30.glFinish()
        last = System.nanoTime()
    }

    /** The work since the previous mark belonged to [name]. */
    fun mark(name: String) {
        if (left <= 0) return
        markSlow(name)
    }

    @Synchronized private fun markSlow(name: String) {
        if (left <= 0) return
        GLES30.glFinish()
        val now = System.nanoTime()
        val d = now - last
        last = now
        sums[name] = (sums[name] ?: 0L) + d
        total += d
    }

    /** Called when the frame is finished; closes the round after its last frame and builds the report after the last round. */
    fun end() {
        if (left <= 0) return
        endSlow()
    }

    @Synchronized private fun endSlow() {
        if (left <= 0) return
        markSlow("finish (rest)")
        frames++
        left--
        if (left == 0) {
            all.add(LinkedHashMap(sums) to frames)
            if (roundsLeft > 0) resumeAt = System.nanoTime() / 1_000_000L + REST_MS
            else {
                report = build()
                active = false
            }
        }
    }

    /** What there is so far (the report, or the finished rounds / the running one when it was cut short); null when nothing was drawn. */
    @Synchronized fun partial(): String? {
        if (report != null) return report
        if (all.isEmpty() && frames > 0) all.add(LinkedHashMap(sums) to frames)
        return if (all.isEmpty()) null else build().also { active = false; left = 0; roundsLeft = 0 }
    }

    private fun build(): String {
        val names = LinkedHashSet<String>()
        for ((s, _) in all) names.addAll(s.keys)
        val perRoundTotal = all.map { (s, n) -> s.values.sum() / 1e6 / n.coerceAtLeast(1) }
        val nFrames = all.sumOf { it.second }
        val sb = StringBuilder()
        sb.append("+CRSC pass times: average of ").append(all.size).append(" rounds (").append(nFrames).append(" frames)\n")
        sb.append(android.os.Build.MANUFACTURER).append(' ').append(android.os.Build.MODEL).append('\n')
        sb.append("mode ").append(Cfg.mode).append(", CRSC level ").append(Cfg.crscLevel).append(", upscaler speed ").append(Cfg.upOpt)
            .append(", render ").append(Cfg.scalePct).append("%\n")
        val avgTotal = perRoundTotal.average()
        for (k in names) {
            // the average over the rounds of the per-frame time of this pass
            val avg = all.map { (s, n) -> (s[k] ?: 0L) / 1e6 / n.coerceAtLeast(1) }.average()
            sb.append(String.format(java.util.Locale.US, "%-34s %6.2f ms  %4.0f%%\n", k, avg, if (avgTotal > 0) avg * 100.0 / avgTotal else 0.0))
        }
        sb.append(String.format(java.util.Locale.US, "%-34s %6.2f ms\n", "TOTAL (average)", avgTotal))
        if (perRoundTotal.size > 1) {
            val mn = perRoundTotal.min()
            val mx = perRoundTotal.max()
            sb.append("rounds: ").append(perRoundTotal.joinToString(" / ") { String.format(java.util.Locale.US, "%.1f", it) })
                .append(String.format(java.util.Locale.US, " ms  (spread %.1f%%: differences smaller than this are noise)\n", if (avgTotal > 0) (mx - mn) * 100.0 / avgTotal else 0.0))
        }
        sb.append("(the GPU is waited for after every pass, so the total is a little higher than the real frame time)")
        return sb.toString()
    }
}
