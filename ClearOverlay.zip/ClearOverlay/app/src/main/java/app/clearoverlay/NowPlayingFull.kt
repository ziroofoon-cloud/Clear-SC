package app.clearoverlay

import android.app.Activity
import android.app.Dialog
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import androidx.media3.common.C
import androidx.media3.common.Player
import kotlin.math.abs
import kotlin.math.sin

/**
 * The "it is playing" animation: a few rounded bars that dance while the music plays and sink to rest when it is paused.
 * It is a decoration (it does not read the sound), drawn in the app's accent colour.
 */
class EqView(ctx: android.content.Context, private val n: Int = 4) : View(ctx) {
    private val level = FloatArray(n) { 0.12f }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var on = false

    fun run(playing: Boolean) {
        on = playing
        postInvalidateOnAnimation()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        postInvalidateOnAnimation()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val t = SystemClock.uptimeMillis() / 1000f
        val bw = w / (n * 1.7f)
        val gap = (w - bw * n) / (n - 1).coerceAtLeast(1)
        var moving = false
        paint.color = Ui.ACCENT
        for (i in 0 until n) {
            val target = if (on) (0.22f + 0.78f * abs(sin(t * (2.0f + 0.55f * i) + i * 1.7f)) * (0.65f + 0.35f * sin(t * 0.9f + i))).coerceIn(0.1f, 1f) else 0.1f
            level[i] += (target - level[i]) * 0.22f
            if (abs(target - level[i]) > 0.01f) moving = true
            val bh = (h * level[i]).coerceAtLeast(bw)
            val x = i * (bw + gap)
            rect.set(x, h - bh, x + bw, h)
            c.drawRoundRect(rect, bw / 2f, bw / 2f, paint)
        }
        if (on || moving) postInvalidateOnAnimation()
    }
}

/** Full-screen "now playing": a big album picture, title, seek bar, controls and the playing animation. */
object NowPlayingFull {
    fun show(act: Activity) {
        val dlg = Dialog(act, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val ui = Handler(Looper.getMainLooper())
        val m = act.windowManager.currentWindowMetrics.bounds
        val land = m.width() > m.height()

        val root = FrameLayout(act).apply { setBackgroundColor(Ui.BG) }
        val body = LinearLayout(act).apply {
            orientation = if (land) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(act, 20), dp(act, 12), dp(act, 20), dp(act, 12))
        }
        root.addView(body, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.setOnApplyWindowInsetsListener { v, ins ->
            val i = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            v.setPadding(i.left, i.top, i.right, i.bottom)
            ins
        }

        // cover
        val side = if (land) minOf((m.height() * 0.62f).toInt(), (m.width() * 0.4f).toInt()) else minOf((m.width() * 0.84f).toInt(), (m.height() * 0.42f).toInt())
        val cover = Covers.CoverView(act, minOf(side, 900), 24)
        body.addView(cover, LinearLayout.LayoutParams(side, side))

        val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        body.addView(col, if (land) LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(act, 24) }
        else LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(act, 18) })

        val title = Ui.text(act, "", 20f, Ui.TEXT, true).apply { gravity = Gravity.CENTER; maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END }
        val artist = Ui.text(act, "", 14f, Ui.MUTED).apply { gravity = Gravity.CENTER; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        col.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(artist, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(act, 4) })
        val eq = EqView(act, 24)
        col.addView(eq, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(act, 40)).apply { topMargin = dp(act, 14); setMargins(dp(act, 24), dp(act, 14), dp(act, 24), 0) })

        // synchronised lyrics (.lrc next to the song): the line being sung in the accent colour, one line before and after in muted
        val lyr = Ui.text(act, "", 15f, Ui.MUTED).apply { gravity = Gravity.CENTER; visibility = View.GONE; setLineSpacing(0f, 1.15f) }
        col.addView(lyr, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(act, 16), dp(act, 8), dp(act, 16), 0) })
        var lyrLines: List<Lyrics.Line>? = null
        var lyrFor: android.net.Uri? = null
        var lyrShown = -2

        var dragging = false
        val timeNow = Ui.text(act, "0:00", 12f, Ui.MUTED)
        val timeEnd = Ui.text(act, "0:00", 12f, Ui.MUTED).apply { gravity = Gravity.END }
        fun fmt(ms: Long): String {
            val s = (ms / 1000).coerceAtLeast(0)
            return if (s >= 3600) String.format(java.util.Locale.US, "%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60) else String.format(java.util.Locale.US, "%d:%02d", s / 60, s % 60)
        }
        val seek = SeekBar(act).apply {
            max = 1000
            progressTintList = android.content.res.ColorStateList.valueOf(Ui.ACCENT)
            thumbTintList = android.content.res.ColorStateList.valueOf(Ui.ACCENT)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    if (fromUser) timeNow.text = fmt((MusicPlayer.player?.duration ?: 0L).coerceAtLeast(0L) * p / 1000L)
                }
                override fun onStartTrackingTouch(s: SeekBar) { dragging = true }
                override fun onStopTrackingTouch(s: SeekBar) {
                    val pl = MusicPlayer.player
                    val d = pl?.duration ?: 0L
                    if (pl != null && d > 0 && d != C.TIME_UNSET) pl.seekTo(d * s.progress / 1000L)
                    dragging = false
                }
            })
        }
        col.addView(seek, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(act, 30)).apply { topMargin = dp(act, 10) })
        val times = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(act, 6), 0, dp(act, 6), 0) }
        times.addView(timeNow, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        times.addView(timeEnd, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        col.addView(times, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        fun icon(kind: Int, color: Int, onClick: () -> Unit) = ImageView(act).apply {
            setImageDrawable(LineIcon(kind, color))
            val p = dp(act, 10)
            setPadding(p, p, p, p)
            setOnClickListener { onClick() }
        }
        val shuffle = icon(Icons.SHUFFLE, Ui.MUTED) { MusicPlayer.player?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }
        val prev = icon(Icons.PREV, Ui.TEXT) { MusicPlayer.player?.seekToPreviousMediaItem() }
        val play = icon(Icons.PLAY, Ui.BG) {
            MusicPlayer.player?.let { if (it.isPlaying) it.pause() else it.play() }
        }
        val big = dp(act, 64)
        play.background = Ui.gradient(big / 2f)
        val pp = dp(act, 16)
        play.setPadding(pp, pp, pp, pp)
        val next = icon(Icons.NEXT, Ui.TEXT) { MusicPlayer.player?.seekToNextMediaItem() }
        val repeat = icon(Icons.REPEAT, Ui.MUTED) {
            MusicPlayer.player?.let {
                it.repeatMode = when (it.repeatMode) {
                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                    else -> Player.REPEAT_MODE_OFF
                }
            }
        }
        val ctl = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        for (b in listOf(shuffle, prev, play, next, repeat)) {
            val size = if (b === play) big else dp(act, 48)
            ctl.addView(FrameLayout(act).apply { addView(b, FrameLayout.LayoutParams(size, size, Gravity.CENTER)) }, LinearLayout.LayoutParams(0, big, 1f))
        }
        col.addView(ctl, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(act, 10) })

        // top corner buttons
        val close = Icons.button(act, Icons.CLOSE, Ui.TEXT, 44) { dlg.dismiss() }
        val share = Icons.button(act, Icons.SHARE, Ui.TEXT, 44) { MusicPlayer.current()?.let { Share.share(act, listOf(it.uri)) } }
        root.addView(close, FrameLayout.LayoutParams(dp(act, 44), dp(act, 44), Gravity.TOP or Gravity.START).apply { setMargins(dp(act, 8), dp(act, 8), 0, 0) })
        root.addView(share, FrameLayout.LayoutParams(dp(act, 44), dp(act, 44), Gravity.TOP or Gravity.END).apply { setMargins(0, dp(act, 8), dp(act, 8), 0) })

        var shown: android.net.Uri? = null
        var lastPlaying: Boolean? = null
        val tick = object : Runnable {
            override fun run() {
                val p = MusicPlayer.player
                val t = MusicPlayer.current()
                title.text = t?.title ?: act.getString(R.string.aud_nothing_playing)
                artist.text = t?.artist ?: ""
                artist.visibility = if (t == null || t.artist.isEmpty()) View.GONE else View.VISIBLE
                if (t?.uri != shown) {
                    shown = t?.uri
                    cover.bind(t?.uri)
                    lyrLines = null
                    lyrShown = -2
                    lyr.visibility = View.GONE
                    eq.visibility = View.VISIBLE
                    val lu = t?.uri
                    lyrFor = lu
                    if (lu != null) Thread {
                        val l = Lyrics.load(act.applicationContext, lu)
                        ui.post { if (lyrFor == lu) { lyrLines = l; lyrShown = -2 } }
                    }.start()
                }
                val ll = lyrLines
                if (ll != null && p != null) {
                    val idx = Lyrics.indexAt(ll, p.currentPosition)
                    if (idx != lyrShown) {
                        lyrShown = idx
                        val sb = android.text.SpannableStringBuilder()
                        fun addLine(i: Int, cur: Boolean) {
                            val tx = ll.getOrNull(i)?.text.orEmpty()
                            if (sb.isNotEmpty()) sb.append('\n')
                            val st = sb.length
                            sb.append(if (tx.isEmpty()) "♪" else tx)
                            if (cur) {
                                sb.setSpan(android.text.style.ForegroundColorSpan(Ui.ACCENT), st, sb.length, 0)
                                sb.setSpan(android.text.style.StyleSpan(android.graphics.Typeface.BOLD), st, sb.length, 0)
                                sb.setSpan(android.text.style.RelativeSizeSpan(1.2f), st, sb.length, 0)
                            }
                        }
                        if (idx > 0) addLine(idx - 1, false)
                        if (idx >= 0) addLine(idx, true)
                        if (idx + 1 < ll.size) addLine(idx + 1, false)
                        lyr.text = sb
                        lyr.visibility = View.VISIBLE
                        eq.visibility = View.GONE // the lyrics take the place of the dancing bars
                    }
                }
                val playing = p != null && p.isPlaying
                if (playing != lastPlaying) {
                    lastPlaying = playing
                    play.setImageDrawable(LineIcon(if (playing) Icons.PAUSE else Icons.PLAY, Ui.BG))
                    eq.run(playing)
                    cover.animate().scaleX(if (playing) 1f else 0.92f).scaleY(if (playing) 1f else 0.92f).setDuration(350).start()
                }
                if (p != null) {
                    val d = p.duration.let { if (it == C.TIME_UNSET) 0L else it }
                    if (!dragging) {
                        seek.progress = if (d > 0) (p.currentPosition * 1000L / d).toInt().coerceIn(0, 1000) else 0
                        timeNow.text = fmt(p.currentPosition)
                    }
                    timeEnd.text = fmt(d)
                    shuffle.setImageDrawable(LineIcon(Icons.SHUFFLE, if (p.shuffleModeEnabled) Ui.ACCENT else Ui.MUTED))
                    val rm = p.repeatMode
                    repeat.setImageDrawable(LineIcon(if (rm == Player.REPEAT_MODE_ONE) Icons.REPEAT_ONE else Icons.REPEAT, if (rm == Player.REPEAT_MODE_OFF) Ui.MUTED else Ui.ACCENT))
                }
                ui.postDelayed(this, if (lyrLines != null) 250L else 400L) // fast only while lyrics are shown
            }
        }
        dlg.setContentView(root)
        dlg.setOnDismissListener { ui.removeCallbacks(tick) }
        dlg.show()
        dlg.window?.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Ui.BG))
        ui.post(tick)
    }
}
