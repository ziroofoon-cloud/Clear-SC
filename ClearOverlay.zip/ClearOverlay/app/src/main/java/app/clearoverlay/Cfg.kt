package app.clearoverlay

import android.content.Context

/** Shared settings (service and activity live in the same process). */
object Cfg {
    const val MODE_SHARP = 0 // sharpen only (FSR 1 RCAS)
    const val MODE_FSR = 1   // FSR 1: EASU upscale + RCAS
    const val MODE_SGSR = 2  // SGSR 1
    const val MODE_FAST = 3  // hardware bilinear upscale + RCAS (cheapest, best for very weak GPUs)
    const val MODE_LANCZOS = 5 // own upscaler: Lanczos-3 with anti-ringing + RCAS
    const val MODE_NIS = 6   // NVIDIA Image Scaling (MIT licence): directional polyphase upscale with its own adaptive sharpening
    const val MODE_NIS_SHARP = 20 // Aura sharp: NIS Lite with a much stronger, cleaned push (as sharp as NIS original or sharper, with a tighter limit against halos)
    const val MODE_NIS_SOFT = 8 // NIS Lite with a gentler push: for dark / soft pictures where the normal push amplifies noise more than it helps
    const val MODE_NIS_FAST = 9 // NIS (fast): the original NIS algorithm and the same picture (largest difference 1/255), computed with less work (see README 3.88.0)
    const val MODE_NIS_MID = 10 // NIS (mid): NIS with 4x4 windows and 4-tap filters, about 10% less edge sharpness than NIS, much less work (see README 3.89.9)
    const val MODE_NIS_ORIG = 7 // the original NVIDIA Image Scaling port (heavy, very sharp; kept next to NIS Lite for comparing)
    const val MODE_PIXEL = 12 // "Fine pixels": square blocks like Raw, but on a finer grid (Cfg.pixelFactor blocks per source pixel), each block filled by a Catmull-Rom sample (Shaders.PIXEL)
    const val MODE_CLEAR = 11 // own upscaler "Clear": edge-directed 4x4 kernel that smooths stair-steps and flat compression noise, keeps real detail, no halos (see Shaders.CLEAR)
    const val MODE_ART = 13 // own upscaler "Wow": edge-preserving 4x4 rebuild + a finishing pass (steeper edges, clarity, fine detail, vibrance), made to look good rather than faithful (see Shaders.ART_UP / ART_STYLE)
    const val MODE_NIS_FINE = 14 // "NIS fast (clean)": NIS fast with a less eager edge-direction detector (no wavy lines on noisy video) and a noise gate on the sharpening (no oily look); see Shaders.NIS_FAST NF_REFINE
    const val MODE_TEMPORAL = 18 // own upscaler "Temporal": Clear upscale + the earlier frames (moved along the motion) accumulated at the OUTPUT size; strength Cfg.tuLevel
    const val MODE_NOVA3 = 19 // own upscaler "Nova 3x": a second family of three-times networks (Ai3Shaders levels 7..); the same options as AI 3x (strength, skip flat, similar frames, light + heavy, half precision), its own level Cfg.nvTier
    fun isAi3(m: Int): Boolean = m == MODE_AI3X || m == MODE_NOVA3
    private fun novaOn(): Boolean = mode == MODE_NOVA3
    /** The settings of the 3x upscaler that is on now (Nova 3x when [mode] is [MODE_NOVA3], else AI 3x): reading and writing go to that one's own value. */
    var a3Gain: Float
        get() = if (novaOn()) nvGain else ai3Gain
        set(v) { if (novaOn()) nvGain = v else ai3Gain = v }
    /** "Lite 8" storage (the feature maps in 8 bits, lighter than half precision): the setting of the section that is in use (AI 3x or Nova 3x). */
    var a3Map8: Boolean
        get() = if (novaOn()) nvMap8 else ai3Map8
        set(v) { if (novaOn()) nvMap8 = v else ai3Map8 = v }
    var a3Fp16: Boolean
        get() = if (novaOn()) nvFp16 else ai3Fp16
        set(v) { if (novaOn()) nvFp16 = v else ai3Fp16 = v }
    var a3Skip: Int
        get() = if (novaOn()) nvSkip else ai3Skip
        set(v) { if (novaOn()) nvSkip = v else ai3Skip = v }
    var a3Same: Boolean
        get() = if (novaOn()) nvSame else ai3Same
        set(v) { if (novaOn()) nvSame = v else ai3Same = v }
    var a3Sim: Int
        get() = if (novaOn()) nvSim else ai3Sim
        set(v) { if (novaOn()) nvSim = v else ai3Sim = v }
    var a3Hyb: Int
        get() = if (novaOn()) nvHyb else ai3Hyb
        set(v) { if (novaOn()) nvHyb = v else ai3Hyb = v }
    var a3HybNet: Int
        get() = if (novaOn()) nvHybNet else ai3HybNet
        set(v) { if (novaOn()) nvHybNet = v else ai3HybNet = v }
    var a3Lite: Boolean
        get() = if (novaOn()) nvLite else ai3Lite
        set(v) { if (novaOn()) nvLite = v else ai3Lite = v }
    var a3LightOn: Boolean
        get() = if (novaOn()) nvLightOn else ai3LightOn
        set(v) { if (novaOn()) nvLightOn = v else ai3LightOn = v }
    // what the picture really uses: the lightening options only count while "lightening" is on (half precision [a3Fp16] is not one of them)
    fun e3Skip(): Int = if (a3LightOn) a3Skip.coerceIn(0, 3) else 0
    fun e3Same(): Boolean = a3LightOn && a3Same
    fun e3Sim(): Int = if (a3LightOn) a3Sim.coerceIn(0, 3) else 0
    fun e3Hyb(): Int = if (a3LightOn) a3Hyb.coerceIn(0, 3) else 0
    fun e3HybNet(): Int = if (e3Hyb() > 0) a3HybNet else 0
    fun e3Lite(): Boolean = a3LightOn && a3Lite
    /** The level (Ai3Shaders) of the 3x upscaler that [m] is: [ai3Tier] for AI 3x, [nvTier] for Nova 3x. */
    fun ai3TierFor(m: Int): Int = (if (m == MODE_NOVA3) nvTier else ai3Tier).coerceIn(0, Ai3Shaders.TIERS - 1)
    const val MODE_AI3X = 17 // own upscaler "AI 3x": the three-times networks (Ai3Shaders), a part of its own apart from the AI 2x ones; level Cfg.ai3Tier, sharpness Cfg.ai3Gain
    const val MODE_AI2X = 16 // own upscaler "AI 2x": the AI 2x network (srStage) as the upscaler itself; it can be stacked with the live AI 2x switch (Cfg.aiUpTier picks the level)
    const val MODE_NEURAL = 15 // own upscaler "Neural": a tiny network (luma, 4 layers) run as shaders, 2x (see NeuralNet). 14 is "NIS fast (clean)".
    const val MODE_RAW = 4   // capture at the render scale and show it with NO upscaling filter / sharpening (for comparing)

    /** Anti-aliasing modes (post-process on the captured frame, applied before upscale/sharpen). */
    const val AA_OFF = 0
    const val AA_FXAA_FAST = 1
    const val AA_FXAA_QUALITY = 2
    const val AA_EDGE = 3
    const val AA_SMART = 4

    /** Render-resolution presets, in target pixel height. CUSTOM means "use the scalePct slider". */
    const val PRESET_CUSTOM = 0
    const val PRESET_1080 = 1080
    const val PRESET_1440 = 1440
    const val PRESET_4K = 2160
    /** Quick presets shown as swipeable chips: low ones upscale, high ones supersample. */
    val PRESETS = listOf(360, 480, 540, 720, 900, PRESET_1080, PRESET_1440, PRESET_4K)

    /** Render-scale range in percent of the panel. Above 100 = supersampling (render bigger, shrink back). */
    const val SCALE_MIN = 25
    const val SCALE_MAX = 200

    /** Floating-bubble size range, in dp. */
    const val BUBBLE_MIN_DP = 36
    const val BUBBLE_MAX_DP = 84
    const val BUBBLE_DEFAULT_DP = 52
    /** Fraction of the bubble's own size that pokes past the screen edge while asleep. */
    const val BUBBLE_SLEEP_FRACTION = 0.37f
    /** Idle time (seconds) before the bubble goes to sleep: see [bubbleSleepSec]. */
    const val BUBBLE_SLEEP_DEFAULT_SEC = 3
    const val BUBBLE_SLEEP_MIN_SEC = 1
    const val BUBBLE_SLEEP_MAX_SEC = 30

    /** 0..1 sharpening strength. Read every frame, so changes apply live. */
    @Volatile var sharp = 0.7f
    /** Capture size in percent of the screen (ignored in sharpen-only mode). */
    @Volatile var scalePct = 100
    @Volatile var mode = MODE_SHARP

    /** CRSC Edge quality: 0 light, 1 balanced, 2 strong, 3 crisp, 4 ultra, each one visibly sharper than the last. 5 maximum (3 rounds, heavy) exists in file export only. */
    @Volatile var crscLevel = 1
    /** CRSC Edge + "NIS crispness": 0 off, 1 soft, 2 medium, 3 strong. The NIS (original) sharpener runs on the finished CRSC Edge picture. */
    @Volatile var crscNis = 0
    @Volatile var crscNisFast = false // "Crisp Fast": NIS crispness drawn with Shaders.NIS_CRISP_FAST (same picture as Standard / NIS_SHARP1, less work); the key keeps its old name
    /** CRSC Edge "exact mode": no flat-area shortcuts, every pixel gets the full computation (the same picture as before the lighter update). */
    @Volatile var crscExact = false
    /** NIS fast quality: 0 exact (same picture as before), 1 medium (flat areas read 16 taps instead of 36, nearly the same picture), 2 light (medium + one edge detector call instead of four, about 38 dB against NIS original). */
    @Volatile var nisFastLevel = 0
    /** NIS fast Mid quality: 0 exact (NIS mid as it always was = the "medium" shader), 1 medium (the "light" shader: one edge detector call instead of four; Mid pushes gently, so the difference is small and it is the lightest NIS). */
    /** NIS fast mid quality, the shader level itself: 0 exact, 1 medium (how Mid always looked and ran), 2 light. Key "nismidq" (older versions: "nismidq" 0 / 1 = these 1 / 2). */
    @Volatile var nisMidLevel = 1
    /** Adds a second sharpening pass. */
    @Volatile var boost = false
    /** Player: frame generation (an extra in-between frame for every video frame). */
    @Volatile var playerFg = false
    @Volatile var playerFgN = 2
    /** 0 light, 1 normal, 2 high. */
    @Volatile var playerFgQ = 1
    /** Player: temporal clean-up (0 off, 1 light, 2 strong). */
    @Volatile var playerTemporal = 0
    /** Auto and the quick profiles may switch the temporal clean-up on (they do for a heavily compressed video, a repair profile, Game HQ). Off = only the person does. */
    @Volatile var temporalAutoOk = true
    @Volatile var bubble = true
    @Volatile var bubbleX = -1
    @Volatile var bubbleY = -1
    /** Side edge the bubble rests on, and its relative height (0..1 of the usable range; -1 = not saved yet). */
    @Volatile var bubbleRight = true
    @Volatile var bubbleYf = -1f
    /** Which resolution preset chip is selected in the UI; PRESET_CUSTOM means "manual slider". */
    @Volatile var renderPreset = PRESET_CUSTOM
    /** 0..1 color-enhance (saturation + contrast) strength. 0 = off. Read every frame. */
    @Volatile var vivid = 0f
    /** -1..1 contrast around mid-grey (0 = unchanged). Read every frame. */
    @Volatile var contrast = 0f
    /** -1..1 shadows (lift / crush) and highlights (recover / boost), independent saturation, warmth (blue-light <-> warm), 0..1 film grain. */
    @Volatile var shadows = 0f
    @Volatile var highlights = 0f
    @Volatile var saturation = 0f
    @Volatile var warmth = 0f
    /** -1..1 brightness (exposure), vibrance (saturation that spares the already strong colours) and tint (green <-> magenta). */
    @Volatile var brightness = 0f
    @Volatile var vibrance = 0f
    @Volatile var tint = 0f
    @Volatile var grain = 0f
    /** -1..1 vignette (+ darkens the corners, - lightens them) and 0..1 fade (matte, lifted blacks). Live player / screen layer only, not in a file export. */
    @Volatile var vignette = 0f
    @Volatile var fade = 0f
    /** 0..1 how fast Smart fix follows a changing scene (0 = very calm, 1 = quick). */
    @Volatile var fixSpeed = 0.3f
    /** -1..1 clarity (large-scale local contrast; negative = soften), 0..1 anti-ringing (limits halos next to hard edges), 0..2 deinterlace (0 off, 1 / 2 = rebuild the odd / even lines where combing shows). */
    @Volatile var clarity = 0f
    @Volatile var antiRing = 0f
    @Volatile var deint = 0
    /** Video player: cut black bars (letterbox / pillarbox) off the picture automatically. */
    @Volatile var autoCrop = false
    /** "Adapt clean-up to the video size": Denoise, Colour clean-up and Deband are scaled by the height of the source (low resolution = more compression damage = stronger; HD = weaker). */
    @Volatile var cleanAuto = false
    /** "Smooth live": in the video player the heavy effects are lightened step by step while the phone cannot keep up (see [GovFx]). */
    @Volatile var smoothLive = false
    /** Split-screen compare in the player (not saved: off again after a restart): 0 off, 1..3 = the left 25 / 50 / 75 % shows the picture with no effects, the rest shows it with them. */
    @Volatile var splitCmp = 0
    /**
     * Player / photo resolution chain, in pixels of the SHORT side (so portrait and landscape files behave the same).
     * inRes: what the source really is (0 = auto = its own size). A smaller value than the file's size makes the file
     * be brought down to that size first (soft "fake HD" content is then upscaled from clean pixels).
     * outRes: the size the picture is rendered at (0 = auto = the screen). Bigger than the screen = supersampling,
     * smaller than the source = downscaling (a good anti-aliasing), both then shown on the screen.
     */
    @Volatile var inRes = 0
    @Volatile var outRes = 0
    /**
     * midRes: the MIDDLE step (short side, 0 = off). After the clean-up stages the picture is brought to this size: smaller than the
     * work size = shrunk (a clean anti-aliasing), bigger = made bigger by the chosen upscaler. Then the output step goes on from there.
     */
    @Volatile var midRes = 0
    /** Latest resolution chain of the player's pipeline ("source -> work -> output -> screen"), for the settings panel. */
    @Volatile var resInfo = ""
    /** Measured time (ms) the live pipeline needs per frame, averaged; 0 when nothing is being drawn. Set by [GlPipeline]. */
    @Volatile var drawMs = 0f
    @Volatile var drawMsAt = 0L
    /** Floating-bubble diameter in dp. */
    @Volatile var bubbleSizeDp = BUBBLE_DEFAULT_DP
    /** Whether the bubble dims and slides toward the edge after being left idle. */
    @Volatile var bubbleSleep = true
    /** Seconds of idle time before the bubble goes to sleep. */
    @Volatile var bubbleSleepSec = BUBBLE_SLEEP_DEFAULT_SEC
    /** How visible the sleeping bubble stays, in percent (15-90). */
    @Volatile var bubbleIdleAlpha = 45
    /** 0..1 "Detail / deblur" strength (wide unsharp mask for blurry, upscaled sources). 0 = off. */
    @Volatile var detail = 0f
    /** 0..1 size of that effect: 0 = 1 px, 1 = 4 px blur radius. */
    @Volatile var detailSize = 0.4f
    /** 0..1 edge-preserving denoise / deblock strength (cleans compression noise before sharpening). 0 = off. */
    @Volatile var denoise = 0f
    /** 0..1 "Colour clean-up": smooths colour blotches / bleeding / coloured noise only (brightness, and so detail, is kept). 0 = off. */
    @Volatile var chromaClean = 0f
    /** 0..1 "Protect noise": sharpens noise-like pixels less (RCAS). 0 = stock sharpening. */
    @Volatile var sharpProtect = 0f
    /** 0..1 debanding strength (smooths the stair-steps low-bitrate video makes in gradients). 0 = off. */
    @Volatile var deband = 0f
    /** 0..1 "Game Light": a lighting / material touch for game pictures (texture, local tone, depth, glow, vibrance; see Shaders.GAME_LIGHT). 0 = off. */
    @Volatile var gameLight = 0f
    /** 0..1 "Faint detail": lifts faint, low-contrast structure (a grey pole against a grey sky) on the output of any upscaler; see Shaders.FAINT_LIFT. 0 = off. */
    @Volatile var faintLift = 0f
    /** Smart fix: white balance, levels and a shadow lift measured from the picture itself (video, photo, GIF; every section keeps its own). */
    @Volatile var smartFix = false
    /** 0..1 strength of Smart fix (1 = as measured). */
    @Volatile var fixLevel = 1f
    /** Clean upscale: denoise -> sharpen -> anti-aliasing -> upscale -> colour restore (see GlPipeline). */
    @Volatile var cleanUp = false
    /** 0..1 strength of the clean upscale chain (denoise, sharpen and colour restore together). Read every frame. */
    @Volatile var cleanLevel = 0.6f
    /** "Fine pixels" mode: blocks per source pixel along each side (1 = the source pixels themselves, 2 = squares half the size, 0.5 = squares of 2 x 2 source pixels ...). 0.1..8. */
    /** Largest "Fine pixels" factor (squares per source pixel along a side). */
    const val PIXEL_MAX = 8f
    /** Smallest "Fine pixels" factor: below 1 the squares are BIGGER than a source pixel (0.1 = 10 x 10 source pixels per square). */
    const val PIXEL_MIN = 0.1f
    @Volatile var pixelFactor = 2f
    /** Neural upscaler: 0 = Lite (8 channels, fast), 1 = Plus (16 channels, better, slower). */
    @Volatile var neuralModel = 0 // 0 Lite (8 channels), 1 Plus (16), 2 Medium (12); the numbers 0 / 1 are what older versions saved, so Medium got 2 (the chips show Lite, Medium, Plus)
    fun neuralCost(model: Int = neuralModel): Float = when (model) { 1 -> 5.0f; 2 -> 4.0f; else -> 3.0f }
    /** Chip position (Lite, Medium, Plus) <-> the saved model number. */
    val NEURAL_ORDER = intArrayOf(0, 2, 1)
    /** "Fine pixels" as its own option: the finished picture of ANY upscaler is cut into square blocks ([pixelFactor] blocks per source pixel). */
    @Volatile var finePixels = false
    @Volatile var srWide = false // "AI upscaler 2x": the wider 12-channel network (a little better, about 1.8x the work)
    @Volatile var srBig = true // AI 2x also when the doubled picture is bigger than the screen (then the chosen upscaler / Fine pixels are skipped for that video); off = only when it fits
    @Volatile var auraBoost = false // "Aura sharper" (only with MODE_NIS_SHARP): Aura sharp with a still stronger push (x1.5), a tighter overshoot limit and a little more calming of flat noise; live only
    @Volatile var auraAuto = false // "Aura sharp": the strength follows the noise of the scene (measured from the frames, GlPipeline.auraMeasure): clean picture sharper, noisy picture gentler; not in a file export
    @Volatile var aiGain = 1.0f // AI 2x upscaler (MODE_AI2X, every level incl. Lumen): strength of the learned part (its own setting, not srGain of the live AI 2x; 1.0 = as trained)
    @Volatile var aiSkip = 0 // AI 2x upscaler (MODE_AI2X): skip flat areas, 0 off .. 3 Strong (its own setting, not srSkip)
    @Volatile var aiSame = false // AI 2x upscaler: skip unchanged areas (own setting)
    @Volatile var aiSim = 0 // AI 2x upscaler: similar frames, 0 off .. 3 Strong (own setting)
    // "Neural" upscaler: its own sharpness and its own lightening options (nothing shared with the AI upscalers)
    @Volatile var neuralGain = 1.0f // strength of what the network adds to the plain 2x picture (1.0 = as trained; its chips are the AI 2x ones)
    @Volatile var neuralLightOn = false // the lightening options below are hidden and NOT used while this is off
    @Volatile var neuralSkip = 0 // skip flat areas, 0 off .. 3 Strong
    @Volatile var neuralSame = false // skip unchanged areas
    @Volatile var neuralSim = 0 // similar frames, 0 off .. 3 Strong
    @Volatile var srSame = false // AI 2x: skip unchanged areas (experimental, live only): where the source is exactly as in the frame before (in the whole window the network looks at) the result of the frame before is kept
    @Volatile var srSim = 0 // AI 2x: similar frames (experimental, live only): 0 off, 1 Fine (+-1 of 255), 2 Normal (+-2), 3 Strong (+-4); the network runs on the earlier picture where this frame is only a little different
    @Volatile var srSkip = 0 // AI 2x: skip flat areas (experimental, its own setting, not tied to AI 3x): 0 off, 1 Safe, 2 Normal, 3 Strong (same thresholds as AI 3x); the network does not run where the picture is flat
    @Volatile var srMap8 = false // AI 2x: the feature maps between the passes are kept in 8 bits (RGBA8, companded) and not in 16-bit floats: half the memory and memory traffic (offline: mean error 0.3 of 255, largest 7); off until measured on a phone
    @Volatile var srFp16 = false // AI 2x: the networks run with half-precision (mediump) maths in the three big passes: the same picture (checked: error <= 0.84 of 255), usually faster on Adreno; not measured on a phone, so off
    @Volatile var srAuto = false // AI 2x: swap a level that is too slow for a lighter one by itself (off = the chosen level always stays, so it can be tested; only a network that cannot be built on this phone is replaced)
    @Volatile var srPlain = true // AI 2x: the rest of the way from the AI picture to the screen is a plain resize + sharpening (not FSR / NIS / CRSC Edge), so the AI does the whole upscale
    @Volatile var srNet = 0 // "AI upscaler 2x": which family of networks: 0 Standard (aio8 / aio12), 1 Classic (the older 8 / 12 channel ones), 2 the 16-channel (aio16), 3 the 24-channel (aio24), 4 the 4-channel (aio4) (these three ignore Light / Medium)
    @Volatile var srGain = 1.0f // "AI upscaler 2x": strength of the learned part (1.0 = as trained; its own list of chips, see Sharp; 0.3 .. 7)
    @Volatile var tuLevel = 1 // strength of the "Temporal" upscaler: 0 Light, 1 Normal, 2 Strong
    @Volatile var nvTier = Ai3Shaders.NOVA_FIRST // level of the "Nova 3x" upscaler (Ai3Shaders.NOVA_FIRST ..)
    @Volatile var ai3Tier = 1 // level of the "AI 3x" upscaler: 0 Light (4 ch), 1 Balanced (8 ch), 2 Quality (32 ch), 3 Balanced+ (12 ch), 4 High (20 ch), 5 Plus (16 ch), 6 Ultra (24 ch) (chips: 0, 1, 3, 5, 4, 6, 2)
    @Volatile var ai3Skip = 0 // "AI 3x": skip flat areas (experimental): 0 off, 1 Safe, 2 Normal, 3 Strong (how flat a place must be, 1.5 / 3 / 6 of 255); the networks do not run where the picture around is flat
    @Volatile var ai3Same = false // "AI 3x": skip unchanged areas (experimental): where the source is exactly as in the frame before (in the whole window the network looks at) the result of the frame before is kept
    @Volatile var ai3Map8 = false // "AI 3x": the same 8-bit storage of the feature maps (see srMap8)
    @Volatile var nvMap8 = false // "Nova 3x": the same
    @Volatile var ai3Fp16 = false // "AI 3x": the networks run with half-precision (mediump) maths: usually lighter on Adreno, the same picture (offline check: error <= 0.2 of 255 on all levels); off until measured on the phone
    @Volatile var ai3Sim = 0 // "AI 3x": similar frames (experimental): 0 off, 1 Fine (+-1 of 255), 2 Normal (+-2), 3 Strong (+-4); where the source is only a little different from the frame before the result of the frame before is kept
    @Volatile var ai3Hyb = 0 // "AI 3x": light + heavy (experimental): 0 off, 1 Gentle, 2 Normal, 3 Strong; the light network (Light 4 ch) runs on the whole picture, the chosen heavy one only where there is detail (the rest of the picture takes the light one's result, not a plain enlargement)
    @Volatile var ai3HybNet = 0 // "AI 3x" light + heavy: which network is the light one: 0 = the 3x Light (4 ch), 11..16 = another 3x level of the person's choice (value - 10; lighter than the heavy one), 1..5 = an AI 2x network (level aiUpTier + 1: Ultra Performance 4 ch, Performance 8 ch, Balanced 12 ch, Quality 16 ch, Ultra Quality 24 ch) whose 2x picture is fitted to 3x
    @Volatile var ai3Lite = false // "AI 3x": smart lite: one switch for the savings that are not seen (skip flat areas Safe + skip unchanged areas + similar frames Normal +-2); the single switches can still ask for more
    // "Nova 3x" has its own copy of every setting of "AI 3x" (nothing is shared); [a3Gain] ... [a3LightOn] below are the ones of the upscaler that is on now
    @Volatile var nvGain = 0.5f // "Nova 3x": strength of the learned part (its networks have the sharpness 3.5 trained in: 1.0 = as trained is very sharp, about 0.5 was the best against the real picture in the offline test)
    @Volatile var nvFp16 = false
    @Volatile var nvSkip = 0
    @Volatile var nvSame = false
    @Volatile var nvSim = 0
    @Volatile var nvHyb = 0
    @Volatile var nvHybNet = 0
    @Volatile var nvLite = false
    /** "Lightening" of AI 3x / Nova 3x (light + heavy, smart lite, skip flat / unchanged areas, similar frames; NOT half precision): while it is off the options are hidden and none of them is used, whatever is saved in them. */
    @Volatile var ai3LightOn = false
    @Volatile var nvLightOn = false
    @Volatile var ai3Gain = 1.0f // "AI 3x": strength of the learned part (0 = plain bilinear, 1.0 = as trained, up to 3.5 much sharper)
    @Volatile var aiUpTier = 1 // level of the "AI 2x" upscaler: 0 Ultra Performance .. 4 Ultra Quality (SrShaders.tierFamily / tierWide)
    @Volatile var srLive = false // "AI upscaler 2x" (player): a tiny neural network doubles small videos before the chosen upscaler
    /** Anti-aliasing mode (AA_*). */
    @Volatile var aaMode = AA_OFF
    /** 0..1 anti-aliasing strength. Read every frame. */
    @Volatile var aaStrength = 0.75f
    /** UI language: Lang.SYSTEM / Lang.EN / Lang.FA. */
    @Volatile var lang = Lang.SYSTEM
    /** Built-in player: effects on (true) or bypassed = original picture (false). Quick A/B compare. */
    @Volatile var playerFx = true
    /** While the built-in player is open the screen-capture overlay is paused, so the picture is never processed twice. */
    @Volatile var pauseOverlayInPlayer = true
    /** Settings panels turn almost transparent while a slider is held (so the picture can be judged) and the player's one hides itself when idle. */
    @Volatile var panelFade = true
    /** Player: when the controls hide themselves, the FX button stays on screen. */
    @Volatile var fxPinned = false
    /** Manga reader: run the picture effects on every page. */
    @Volatile var mangaFx = false
    /** GIF viewer: run the picture effects on every frame (a free, local alternative to cloud upscaling). */
    @Volatile var gifFx = false
    /** App look: 0 follow the phone, 1 dark, 2 light. */
    @Volatile var themeMode = 0
    /** Screen direction of the app (not the player / manga reader): 0 follow the phone, 1 portrait, 2 landscape. See [AppDirection]. */
    @Volatile var appDir = 0
    /** Text level: 0 full, 1 light (explanations cut short), 2 minimal (explanations hidden). */
    @Volatile var uiMode = 0
    /** App look: 0 modern (rounded, gradient), 1 classic (flat, square-ish). */
    @Volatile var themeStyle = 0
    /** Accent colour of the app (0 = the default cyan / violet, 1..7 = the colours in [Ui.ACCENTS]). */
    @Volatile var themeAccent = 0
    /** Size of the manga reader's top bar (FX, gear, cloud ...): 0 small, 1 medium, 2 large. */
    @Volatile var mangaBar = 1
    /** Player settings panel size: 0 small, 1 medium, 2 large. */
    @Volatile var panelSize = 1
    /** Selected quick profile (see Profiles: 0 video, 1 stream, 2 game, 3 photo, 4 HD movie, 5 anime; -1 = none / edited by hand). */
    @Volatile var profileType = -1
    /** Profile strength: 0 light, 1 balanced, 2 strong, 3 auto (player only: chosen from the upscale ratio). */
    @Volatile var profileLevel = 1
    /** The strength in force as a number 0..2 (Auto strength is smooth: 1.4 = 40 % of the way from Balanced to Strong). Not saved; shown in the panel. */
    @Volatile var strengthNow = 1f
    /** GPU budget of the quick profiles (see Profiles): 0 performance, 1 balanced, 2 quality. */
    @Volatile var profileBudget = 1
    /** GPU budget "Auto": the app picks the budget itself (from the picture and, in the player, from dropped frames); [profileBudget] holds what it picked. */
    @Volatile var budgetAuto = false

    /** Opacity (0.1..1) of the processed screen layer over the real screen (screen overlay). 1 = fully the processed picture. */
    @Volatile var layerAlpha = 1f
    /** Screen dimmer of the overlay, 0 (clear) .. 1 (black). The bubble and the settings panel stay above it. */
    @Volatile var dim = 0f
    /** Opacity (0.05..1) the settings panel dims to while a slider is held. 1 = never dims. */
    @Volatile var panelFadeLevel = 0.12f
    /** The player's settings panel closes itself after a few idle seconds. */
    @Volatile var panelAutoClose = true
    /** The player's settings panel is pinned in place (false = it can be dragged by its title). */
    @Volatile var panelLocked = true
    /** Auto: the app picks profile, strength, GPU budget, anti-aliasing, mode and AI model by itself (see Auto). */
    @Volatile var autoMode = false
    /** Player: "live auto-tuning" - small changes on top of the person's own settings, followed while the video plays. */
    @Volatile var autoLive = false
    /** Strength of the live auto-tuning: 0 light, 1 normal, 2 strong (see [FxAuto]). */
    @Volatile var autoLiveLevel = 1
    /** The live changes themselves (added in [LiveFx]; never saved, zero when the switch is off or nothing is open). */
    @Volatile var tShadows = 0f
    @Volatile var tHighlights = 0f
    @Volatile var tContrast = 0f
    @Volatile var tSaturation = 0f
    @Volatile var tSharp = 0f
    @Volatile var tDenoise = 0f
    /** With Auto: a very small photo is AI-upscaled right after it opens. */
    @Volatile var autoAiSmall = false // opt-in since 3.99.14 (it used to be on by default and started the AI by itself on every small photo)
    /** Player: start the next video of the folder when one ends. */
    @Volatile var autoNext = true

    /** Name of the saved user profile ([UserProfiles]) whose values are currently in force; null once anything is changed by hand. */
    @Volatile var userProfile: String? = null

    /** Upscaler speed tricks: 0 Original (the shaders of 3.99.13), 1 Light (default: the GPU is told not to read the old picture of a target, one read less in CRSC Edge, textureGather for NIS fast / mid),
     *  2 Lightest (also the rewritten FSR 1 / CRSC Edge / Aura shaders of 3.99.45 - 3.99.49). Shared by every section. */
    @Volatile var upOpt = 1

    /**
     * Settings are kept per SECTION, so what is chosen for manga does not change photos, videos, GIFs or the screen
     * layer: "screen" (the overlay over other apps, the original keys), "video", "photo", "manga" and "gif".
     * Only the picture / player settings below are per section; the bubble, language and theme are shared.
     * A section starts as a copy of the screen settings the first time it is used, so nothing is lost.
     */
    @Volatile var section = "screen"
        private set

    val SECTION_KEYS = setOf("aigain", "neugain", "neulighton", "neuskip", "neusame", "neusim", "srskip", "srsame", "srsim", "srfp16", "srmap8", "ai3map8", "nvmap8", "srauto", "srplain", "auraauto", "aurasharper", "aiskip", "aisame", "aisim", "vig", "nmodel", "fade", "fixspd", "fixlv", "sharp", "scale", "mode", "nvtier", "crsclv", "crscnis", "crscnisfast", "nisfastlevel", "nismidq", "crscexact", "boost", "preset", "vivid", "contrast", "shadows", "highlights", "saturation", "warmth", "bright", "vibr", "tint", "grain", "clarity", "antiring", "deint", "autocrop", "cleanauto", "smoothlive", "inres", "midres", "outres", "detail", "detailsz", "denoise", "chroma", "sprot", "deband", "glight", "faint", "srlive", "aiuptier", "ai3tier", "ai3fp16", "ai3skip", "ai3same", "ai3sim", "ai3lite", "ai3hyb", "ai3hybnet", "tulv", "ai3gain", "srwide", "srbig", "srgain", "srnet", "smartfix", "cleanup", "cleanlv", "pixfac", "finepix", "aa", "aastr", "pfx", "pfade", "fxpin", "mfx", "gfx", "panelsize", "ptype", "plevel", "pbudget", "pbudgetauto", "uprof", "pfadelvl", "lalpha", "dim", "pautoclose", "plocked", "auto", "autoai2", "pfg", "pfgn", "pfgq", "ptmp", "autolive", "autolivelvl", "nvgain", "nvfp16", "nvskip", "nvsame", "nvsim", "nvlite", "nvhyb", "nvhybnet", "nvlighton", "ai3lighton")

    private fun pk(k: String) = if (section == "screen") k else "sec_${section}_$k"

    /** Keys of SECTION_KEYS that are panel / state settings, not picture settings: a saved profile does not carry them. */
    private val NOT_IN_PROFILE = setOf("pfx", "pfade", "fxpin", "mfx", "gfx", "panelsize", "ptype", "uprof", "pfadelvl", "pautoclose", "plocked", "auto", "autoai2", "pfg", "pfgn", "pfgq", "ptmp", "autolive", "autolivelvl")

    /**
     * EVERY picture setting of the active section as one JSON object (value text with a type letter: "f:0.5", "i:3", "b:true", "s:..", "l:..").
     * "My profiles" keeps this next to its own hand-written list, so a setting that is added to SECTION_KEYS later is saved and loaded by a
     * profile without anyone having to remember to add it there. Call [save] first: this reads what is stored.
     */
    fun pictureDump(c: Context): org.json.JSONObject {
        val p = prefs(c)
        val all = p.all
        val o = org.json.JSONObject()
        for (k in SECTION_KEYS) {
            if (k in NOT_IN_PROFILE) continue
            val v = all[pk(k)] ?: continue
            when (v) {
                is Float -> o.put(k, "f:$v")
                is Int -> o.put(k, "i:$v")
                is Boolean -> o.put(k, "b:$v")
                is Long -> o.put(k, "l:$v")
                is String -> o.put(k, "s:$v")
            }
        }
        return o
    }

    /** Writes a [pictureDump] back into the active section's stored settings and reads them in. Unknown keys and wrong-typed values are skipped. */
    fun pictureRestore(c: Context, o: org.json.JSONObject?) {
        if (o == null) return
        val e = prefs(c).edit()
        val keys = o.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            if (k !in SECTION_KEYS || k in NOT_IN_PROFILE) continue
            val t = o.optString(k)
            if (t.length < 2 || t[1] != ':') continue
            val v = t.substring(2)
            runCatching {
                when (t[0]) {
                    'f' -> e.putFloat(pk(k), v.toFloat())
                    'i' -> e.putInt(pk(k), v.toInt())
                    'b' -> e.putBoolean(pk(k), v.toBoolean())
                    'l' -> e.putLong(pk(k), v.toLong())
                    's' -> e.putString(pk(k), v)
                    else -> e
                }
            }
        }
        e.apply()
        load(c)
    }

    /** Label of the section whose settings are in force (for panel titles). */
    fun sectionLabel(c: Context): String = c.getString(
        when (section) {
            "video" -> R.string.sec_video
            "photo" -> R.string.sec_photo
            "manga" -> R.string.sec_manga
            "gif" -> R.string.sec_gif
            "stream" -> R.string.sec_stream
            else -> R.string.sec_screen
        }
    )

    /**
     * The key "bright" was used for TWO things in the screen section: the side of the screen the bubble sits on (a Boolean, since long
     * ago) and, since the brightness slider, the brightness (a Float; pk() leaves the key unchanged in the screen section). The last
     * save wrote the Float over the Boolean, and the next start died in getBoolean / getFloat with a ClassCastException (also in the
     * video / photo sections, whose settings are copied from the screen section). The bubble side has its own key now
     * ("bubble_right"); this puts old data right: a Boolean found under "bright" (or "sec_..._bright") is the bubble side or nothing.
     */
    private fun fixBrightKeys(p: android.content.SharedPreferences) {
        var e: android.content.SharedPreferences.Editor? = null
        for ((k, v) in p.all) {
            if (!(k == "bright" || (k.startsWith("sec_") && k.endsWith("_bright")))) continue
            if (v is Float) continue
            val ed = e ?: p.edit().also { e = it }
            if (k == "bright" && v is Boolean && !p.contains("bubble_right")) ed.putBoolean("bubble_right", v)
            ed.remove(k)
        }
        e?.apply()
    }

    /** Switches to a section's settings (loads them). Does nothing when it is already the active one. */
    fun bind(c: Context, name: String) {
        if (name == section && loadedOnce) return
        section = name
        fixBrightKeys(prefs(c))
        seed(c, name)
        load(c)
    }

    private var loadedOnce = false

    private fun seed(c: Context, name: String) {
        if (name == "screen") return
        val p = prefs(c)
        val flag = "sec_${name}_seeded"
        if (!p.getBoolean(flag, false)) {
            val all = p.all
            val e = p.edit()
            for (k in SECTION_KEYS) {
                val v = all[k] ?: continue
                if (k == "bright" && v !is Float) continue
                val nk = "sec_${name}_$k"
                when (v) {
                    is Float -> e.putFloat(nk, v)
                    is Int -> e.putInt(nk, v)
                    is Boolean -> e.putBoolean(nk, v)
                    is String -> e.putString(nk, v)
                    is Long -> e.putLong(nk, v)
                }
            }
            e.putBoolean(flag, true).apply()
        }
        // content defaults, once per section (offline test: CRSC Edge is the best upscaler for these)
        val cdef = "sec_${name}_cdef1"
        if (!p.getBoolean(cdef, false)) {
            val lv = when (name) { "manga" -> 2; "photo", "video" -> 1; else -> -1 }
            val e0 = p.edit()
            if (lv >= 0) e0.putInt("sec_${name}_mode", MODE_LANCZOS).putInt("sec_${name}_crsclv", lv)
            e0.putBoolean(cdef, true).apply()
        }
    }

    private fun prefs(c: Context) = c.getSharedPreferences("crsc", Context.MODE_PRIVATE)

    /** The AI 3x level and strength saved for the section [sec] ("video" ...), read without binding it: a video export keeps the ones of the player's own section. */
    fun peekAi3(c: Context, sec: String): Pair<Int, Float> {
        val p = prefs(c)
        val pre = if (sec == "screen") "" else "sec_${sec}_"
        return Pair(p.getInt(pre + "ai3tier", 1).coerceIn(0, Ai3Shaders.TIERS - 1), p.getFloat(pre + "ai3gain", 1.0f).coerceIn(0f, Sharp.MAX))
    }

    /** The Nova 3x level and strength saved for the section [sec], read without binding it (a video export keeps the ones of the player's own section). */
    fun peekNova(c: Context, sec: String): Pair<Int, Float> {
        val p = prefs(c)
        val pre = if (sec == "screen") "" else "sec_${sec}_"
        return Pair(p.getInt(pre + "nvtier", Ai3Shaders.NOVA_FIRST).coerceIn(Ai3Shaders.NOVA_FIRST, Ai3Shaders.TIERS - 1), p.getFloat(pre + "nvgain", 0.5f).coerceIn(0f, Sharp.MAX))
    }

    /** A small text value kept per kind of picture (video / photo / screen), like the colour settings. */
    fun kindGet(c: Context, k: String): String? = prefs(c).getString(pk(k), null)

    fun kindPut(c: Context, k: String, v: String?) {
        val e = prefs(c).edit()
        if (v == null) e.remove(pk(k)) else e.putString(pk(k), v)
        e.apply()
    }

    /** Loads the saved values only the first time in this process: a screen that is opened later must not throw away changes that are
     *  still only in memory (Auto's choices, a Quick profile that was just applied, a slider that is still moving). */
    fun ensureLoaded(c: Context) {
        if (!loadedOnce) load(c)
    }

    fun load(c: Context) {
        loadedOnce = true
        Diag.init(c)
        AppDirection.install(c)
        val p = prefs(c)
        appDir = p.getInt("appdir", 0).coerceIn(0, 2)
        fixBrightKeys(p)
        sharp = p.getFloat(pk("sharp"), 0.7f)
        scalePct = p.getInt(pk("scale"), 100)
        neuralModel = p.getInt(pk("nmodel"), 0).coerceIn(0, 2)
        NeuralNet.attach(c)
        aiUpTier = p.getInt(pk("aiuptier"), 1).coerceIn(0, 5)
        tuLevel = p.getInt(pk("tulv"), 1).coerceIn(0, 2)
        nvTier = p.getInt(pk("nvtier"), Ai3Shaders.NOVA_FIRST).coerceIn(Ai3Shaders.NOVA_FIRST, Ai3Shaders.TIERS - 1)
        ai3Tier = p.getInt(pk("ai3tier"), 1).coerceIn(0, Ai3Shaders.TIERS - 1)
        ai3Gain = p.getFloat(pk("ai3gain"), 1.0f).coerceIn(0f, Sharp.MAX)
        ai3Fp16 = p.getBoolean(pk("ai3fp16"), false)
        ai3Map8 = p.getBoolean(pk("ai3map8"), false)
        nvMap8 = p.getBoolean(pk("nvmap8"), false)
        ai3Skip = p.getInt(pk("ai3skip"), 0).coerceIn(0, 3)
        ai3Same = p.getBoolean(pk("ai3same"), false)
        ai3Sim = p.getInt(pk("ai3sim"), 0).coerceIn(0, 3)
        ai3Lite = p.getBoolean(pk("ai3lite"), false)
        ai3Hyb = p.getInt(pk("ai3hyb"), 0).coerceIn(0, 3)
        ai3HybNet = Ai3Shaders.hybNetNorm(p.getInt(pk("ai3hybnet"), 0))
        // an older version had no "lightening" switch: whoever already used one of the options keeps them on
        ai3LightOn = p.getBoolean(pk("ai3lighton"), ai3Skip > 0 || ai3Same || ai3Sim > 0 || ai3Hyb > 0 || ai3Lite)
        nvGain = p.getFloat(pk("nvgain"), 0.5f).coerceIn(0f, Sharp.MAX)
        nvFp16 = p.getBoolean(pk("nvfp16"), false)
        nvSkip = p.getInt(pk("nvskip"), 0).coerceIn(0, 3)
        nvSame = p.getBoolean(pk("nvsame"), false)
        nvSim = p.getInt(pk("nvsim"), 0).coerceIn(0, 3)
        nvLite = p.getBoolean(pk("nvlite"), false)
        nvHyb = p.getInt(pk("nvhyb"), 0).coerceIn(0, 3)
        nvHybNet = Ai3Shaders.hybNetNorm(p.getInt(pk("nvhybnet"), 0))
        nvLightOn = p.getBoolean(pk("nvlighton"), false)
        mode = p.getInt(pk("mode"), MODE_SHARP).coerceIn(0, 20)
        crscLevel = p.getInt(pk("crsclv"), 1).coerceIn(0, 5)
        crscNis = p.getInt(pk("crscnis"), 0).coerceIn(0, 4)
        crscNisFast = p.getBoolean(pk("crscnisfast"), false)
        crscExact = p.getBoolean(pk("crscexact"), false)
        nisFastLevel = p.getInt(pk("nisfastlevel"), 0).coerceIn(0, 2)
        nisMidLevel = if (p.contains(pk("nismidq"))) p.getInt(pk("nismidq"), 1).coerceIn(0, 2) else p.getInt(pk("nismidlevel"), 0).coerceIn(0, 1) + 1 // an older save: its Exact was the shader's level 1
        boost = p.getBoolean(pk("boost"), false)
        // per section since 3.99.107 (video, photo, GIF ... each its own); a section that has no value of its own yet starts from the old shared one
        playerFg = p.getBoolean(pk("pfg"), p.getBoolean("pfg", false))
        playerFgN = p.getInt(pk("pfgn"), p.getInt("pfgn", 2)).coerceIn(2, 4)
        playerFgQ = p.getInt(pk("pfgq"), p.getInt("pfgq", 1)).coerceIn(0, 3)
        playerTemporal = p.getInt(pk("ptmp"), p.getInt("ptmp", 0)).coerceIn(0, 2)
        temporalAutoOk = p.getBoolean("tmpauto", true)
        bubble = p.getBoolean("bubble", true)
        bubbleX = p.getInt("bx", -1)
        bubbleY = p.getInt("by", -1)
        bubbleRight = p.getBoolean("bubble_right", true)
        bubbleYf = p.getFloat("byf", -1f)
        renderPreset = p.getInt(pk("preset"), PRESET_CUSTOM)
        vivid = p.getFloat(pk("vivid"), 0f)
        contrast = p.getFloat(pk("contrast"), 0f).coerceIn(-1f, 1f)
        shadows = p.getFloat(pk("shadows"), 0f).coerceIn(-1f, 1f)
        highlights = p.getFloat(pk("highlights"), 0f).coerceIn(-1f, 1f)
        saturation = p.getFloat(pk("saturation"), 0f).coerceIn(-1f, 1f)
        warmth = p.getFloat(pk("warmth"), 0f).coerceIn(-1f, 1f)
        brightness = p.getFloat(pk("bright"), 0f).coerceIn(-1f, 1f)
        vibrance = p.getFloat(pk("vibr"), 0f).coerceIn(-1f, 1f)
        tint = p.getFloat(pk("tint"), 0f).coerceIn(-1f, 1f)
        grain = p.getFloat(pk("grain"), 0f).coerceIn(0f, 1f)
        vignette = p.getFloat(pk("vig"), 0f).coerceIn(-1f, 1f)
        fade = p.getFloat(pk("fade"), 0f).coerceIn(0f, 1f)
        fixSpeed = p.getFloat(pk("fixspd"), 0.3f).coerceIn(0f, 1f)
        clarity = p.getFloat(pk("clarity"), 0f).coerceIn(-1f, 1f)
        antiRing = p.getFloat(pk("antiring"), 0f).coerceIn(0f, 1f)
        deint = p.getInt(pk("deint"), 0).coerceIn(0, 2)
        autoCrop = p.getBoolean(pk("autocrop"), false)
        cleanAuto = p.getBoolean(pk("cleanauto"), false)
        smoothLive = p.getBoolean(pk("smoothlive"), false)
        inRes = 0 // the Input choice was removed: the app reads the real size of the file itself
        outRes = p.getInt(pk("outres"), 0)
        midRes = p.getInt(pk("midres"), 0)
        bubbleSizeDp = p.getInt("bsize", BUBBLE_DEFAULT_DP).coerceIn(BUBBLE_MIN_DP, BUBBLE_MAX_DP)
        bubbleSleep = p.getBoolean("bsleep", true)
        bubbleSleepSec = p.getInt("bsleepsec", BUBBLE_SLEEP_DEFAULT_SEC).coerceIn(BUBBLE_SLEEP_MIN_SEC, BUBBLE_SLEEP_MAX_SEC)
        bubbleIdleAlpha = p.getInt("bidlea", 45).coerceIn(15, 90)
        detail = p.getFloat(pk("detail"), 0f).coerceIn(0f, 1f)
        detailSize = p.getFloat(pk("detailsz"), 0.4f).coerceIn(0f, 1f)
        denoise = p.getFloat(pk("denoise"), 0f).coerceIn(0f, 1f)
        chromaClean = p.getFloat(pk("chroma"), 0f).coerceIn(0f, 1f)
        sharpProtect = p.getFloat(pk("sprot"), 0f).coerceIn(0f, 1f)
        deband = p.getFloat(pk("deband"), 0f).coerceIn(0f, 1f)
        gameLight = p.getFloat(pk("glight"), 0f).coerceIn(0f, 1f)
        faintLift = p.getFloat(pk("faint"), 0f).coerceIn(0f, 1f)
        smartFix = p.getBoolean(pk("smartfix"), false)
        fixLevel = p.getFloat(pk("fixlv"), 1f).coerceIn(0f, 1f)
        cleanUp = p.getBoolean(pk("cleanup"), false)
        cleanLevel = p.getFloat(pk("cleanlv"), 0.6f).coerceIn(0f, 1f)
        pixelFactor = p.getFloat(pk("pixfac"), 2f).coerceIn(PIXEL_MIN, PIXEL_MAX)
        finePixels = p.getBoolean(pk("finepix"), false)
        srLive = p.getBoolean(pk("srlive"), false)
        srWide = p.getBoolean(pk("srwide"), false)
        srBig = p.getBoolean(pk("srbig"), true)
        srAuto = p.getBoolean(pk("srauto"), false)
        srFp16 = p.getBoolean(pk("srfp16"), false)
        srMap8 = p.getBoolean(pk("srmap8"), false)
        srSkip = p.getInt(pk("srskip"), 0).coerceIn(0, 3)
        auraAuto = p.getBoolean(pk("auraauto"), false)
        auraBoost = p.getBoolean(pk("aurasharper"), false)
        srSame = p.getBoolean(pk("srsame"), false)
        aiGain = p.getFloat(pk("aigain"), 1.0f).coerceIn(0.3f, Sharp.MAX)
        aiSkip = p.getInt(pk("aiskip"), 0).coerceIn(0, 3)
        aiSame = p.getBoolean(pk("aisame"), false)
        aiSim = p.getInt(pk("aisim"), 0).coerceIn(0, 3)
        neuralGain = p.getFloat(pk("neugain"), 1.0f).coerceIn(0.3f, Sharp.MAX)
        neuralLightOn = p.getBoolean(pk("neulighton"), false)
        neuralSkip = p.getInt(pk("neuskip"), 0).coerceIn(0, 3)
        neuralSame = p.getBoolean(pk("neusame"), false)
        neuralSim = p.getInt(pk("neusim"), 0).coerceIn(0, 3)
        srSim = p.getInt(pk("srsim"), 0).coerceIn(0, 3)
        srPlain = p.getBoolean(pk("srplain"), true)
        srNet = p.getInt(pk("srnet"), 0).coerceIn(0, 5)
        srGain = p.getFloat(pk("srgain"), 1.0f).coerceIn(0.3f, Sharp.MAX)
        // "Fine pixels" used to be an upscaler of its own: now it is an option on top of every upscaler (FSR 1 gives the colours of the blocks)
        if (mode == MODE_PIXEL) { mode = MODE_FSR; finePixels = true }
        aaMode = p.getInt(pk("aa"), AA_OFF).coerceIn(0, 4)
        aaStrength = p.getFloat(pk("aastr"), 0.75f).coerceIn(0f, 1f)
        lang = p.getString("lang", Lang.SYSTEM) ?: Lang.SYSTEM
        playerFx = p.getBoolean(pk("pfx"), true)
        pauseOverlayInPlayer = p.getBoolean("pauseov", true)
        panelFade = p.getBoolean(pk("pfade"), true)
        fxPinned = p.getBoolean(pk("fxpin"), false)
        mangaFx = p.getBoolean(pk("mfx"), false)
        gifFx = p.getBoolean(pk("gfx"), false)
        themeMode = p.getInt("thememode", 0).coerceIn(0, 2)
        uiMode = p.getInt("uimode", 0).coerceIn(0, 2)
        themeStyle = p.getInt("themestyle", 0).coerceIn(0, 1)
        themeAccent = p.getInt("themeaccent", 0).coerceIn(0, 7)
        mangaBar = p.getInt("mangabar", 1).coerceIn(0, 2)
        panelSize = p.getInt(pk("panelsize"), 1).coerceIn(0, 2)
        profileType = p.getInt(pk("ptype"), -1).coerceIn(-1, Profiles.COUNT - 1)
        profileLevel = p.getInt(pk("plevel"), 1).coerceIn(0, 3)
        profileBudget = p.getInt(pk("pbudget"), 1).coerceIn(0, 2)
        budgetAuto = p.getBoolean(pk("pbudgetauto"), false)
        userProfile = p.getString(pk("uprof"), null)
        upOpt = p.getInt("upopt", 1).coerceIn(0, 2)
        panelFadeLevel = p.getFloat(pk("pfadelvl"), 0.12f).coerceIn(0.05f, 1f)
        layerAlpha = p.getFloat(pk("lalpha"), 1f).coerceIn(0.1f, 1f)
        dim = p.getFloat(pk("dim"), 0f).coerceIn(0f, 1f)
        panelAutoClose = p.getBoolean(pk("pautoclose"), true)
        panelLocked = p.getBoolean(pk("plocked"), true)
        autoMode = p.getBoolean(pk("auto"), false)
        autoAiSmall = p.getBoolean(pk("autoai2"), false)
        autoNext = p.getBoolean("autonext", true)
        autoLive = p.getBoolean(pk("autolive"), p.getBoolean("autolive", false))
        autoLiveLevel = p.getInt(pk("autolivelvl"), p.getInt("autolivelvl", 1)).coerceIn(0, 2)
    }

    fun save(c: Context) {
        prefs(c).edit()
            .putFloat(pk("sharp"), sharp)
            .putInt(pk("scale"), scalePct)
            .putInt(pk("mode"), mode)
            .putInt(pk("nmodel"), neuralModel)
            .putInt(pk("aiuptier"), aiUpTier)
            .putInt(pk("tulv"), tuLevel)
            .putInt(pk("nvtier"), nvTier)
            .putInt(pk("ai3tier"), ai3Tier)
            .putFloat(pk("ai3gain"), ai3Gain)
            .putBoolean(pk("ai3fp16"), ai3Fp16)
            .putBoolean(pk("ai3map8"), ai3Map8)
            .putBoolean(pk("nvmap8"), nvMap8)
            .putInt(pk("ai3skip"), ai3Skip)
            .putBoolean(pk("ai3same"), ai3Same)
            .putInt(pk("ai3sim"), ai3Sim)
            .putBoolean(pk("ai3lite"), ai3Lite)
            .putInt(pk("ai3hyb"), ai3Hyb)
            .putInt(pk("ai3hybnet"), ai3HybNet)
            .putBoolean(pk("ai3lighton"), ai3LightOn)
            .putFloat(pk("nvgain"), nvGain)
            .putBoolean(pk("nvfp16"), nvFp16)
            .putInt(pk("nvskip"), nvSkip)
            .putBoolean(pk("nvsame"), nvSame)
            .putInt(pk("nvsim"), nvSim)
            .putBoolean(pk("nvlite"), nvLite)
            .putInt(pk("nvhyb"), nvHyb)
            .putInt(pk("nvhybnet"), nvHybNet)
            .putBoolean(pk("nvlighton"), nvLightOn)
            .putInt(pk("crsclv"), crscLevel)
            .putInt(pk("crscnis"), crscNis)
            .putBoolean(pk("crscnisfast"), crscNisFast)
            .putBoolean(pk("crscexact"), crscExact)
            .putInt(pk("nisfastlevel"), nisFastLevel)
            .putInt(pk("nismidq"), nisMidLevel)
            .putBoolean(pk("boost"), boost)
            .putBoolean(pk("pfg"), playerFg)
            .putInt(pk("pfgn"), playerFgN)
            .putInt(pk("pfgq"), playerFgQ)
            .putInt(pk("ptmp"), playerTemporal)
            .putBoolean("tmpauto", temporalAutoOk)
            .putBoolean("bubble", bubble)
            .putInt("bx", bubbleX)
            .putInt("by", bubbleY)
            .putBoolean("bubble_right", bubbleRight)
            .putFloat("byf", bubbleYf)
            .putInt(pk("preset"), renderPreset)
            .putFloat(pk("vivid"), vivid)
            .putFloat(pk("contrast"), contrast)
            .putFloat(pk("shadows"), shadows)
            .putFloat(pk("highlights"), highlights)
            .putFloat(pk("saturation"), saturation)
            .putFloat(pk("warmth"), warmth)
            .putFloat(pk("bright"), brightness)
            .putFloat(pk("vibr"), vibrance)
            .putFloat(pk("tint"), tint)
            .putFloat(pk("grain"), grain)
            .putFloat(pk("vig"), vignette)
            .putFloat(pk("fade"), fade)
            .putFloat(pk("fixspd"), fixSpeed)
            .putFloat(pk("clarity"), clarity)
            .putFloat(pk("antiring"), antiRing)
            .putInt(pk("deint"), deint)
            .putBoolean(pk("autocrop"), autoCrop)
            .putBoolean(pk("cleanauto"), cleanAuto)
            .putBoolean(pk("smoothlive"), smoothLive)
            .putInt(pk("inres"), inRes)
            .putInt(pk("outres"), outRes)
            .putInt(pk("midres"), midRes)
            .putInt("bsize", bubbleSizeDp)
            .putBoolean("bsleep", bubbleSleep)
            .putInt("bsleepsec", bubbleSleepSec)
            .putInt("bidlea", bubbleIdleAlpha)
            .putFloat(pk("detail"), detail)
            .putFloat(pk("detailsz"), detailSize)
            .putFloat(pk("denoise"), denoise)
            .putFloat(pk("chroma"), chromaClean)
            .putFloat(pk("sprot"), sharpProtect)
            .putFloat(pk("deband"), deband)
            .putFloat(pk("glight"), gameLight)
            .putFloat(pk("faint"), faintLift)
            .putBoolean(pk("smartfix"), smartFix)
            .putFloat(pk("fixlv"), fixLevel)
            .putBoolean(pk("cleanup"), cleanUp)
            .putFloat(pk("cleanlv"), cleanLevel)
            .putFloat(pk("pixfac"), pixelFactor)
            .putBoolean(pk("finepix"), finePixels)
            .putBoolean(pk("srlive"), srLive)
            .putBoolean(pk("srwide"), srWide)
            .putBoolean(pk("srbig"), srBig)
            .putBoolean(pk("srauto"), srAuto)
            .putBoolean(pk("srfp16"), srFp16)
            .putBoolean(pk("srmap8"), srMap8)
            .putInt(pk("srskip"), srSkip)
            .putBoolean(pk("auraauto"), auraAuto)
            .putBoolean(pk("aurasharper"), auraBoost)
            .putBoolean(pk("srsame"), srSame)
            .putFloat(pk("aigain"), aiGain)
            .putInt(pk("aiskip"), aiSkip)
            .putBoolean(pk("aisame"), aiSame)
            .putInt(pk("aisim"), aiSim)
            .putFloat(pk("neugain"), neuralGain)
            .putBoolean(pk("neulighton"), neuralLightOn)
            .putInt(pk("neuskip"), neuralSkip)
            .putBoolean(pk("neusame"), neuralSame)
            .putInt(pk("neusim"), neuralSim)
            .putInt(pk("srsim"), srSim)
            .putBoolean(pk("srplain"), srPlain)
            .putInt(pk("srnet"), srNet)
            .putFloat(pk("srgain"), srGain)
            .putInt(pk("aa"), aaMode)
            .putFloat(pk("aastr"), aaStrength)
            .putString("lang", lang)
            .putBoolean(pk("pfx"), playerFx)
            .putBoolean("pauseov", pauseOverlayInPlayer)
            .putBoolean(pk("pfade"), panelFade)
            .putBoolean(pk("fxpin"), fxPinned)
            .putBoolean(pk("mfx"), mangaFx)
            .putBoolean(pk("gfx"), gifFx)
            .putInt("appdir", appDir)
            .putInt("thememode", themeMode)
            .putInt("uimode", uiMode)
            .putInt("themestyle", themeStyle)
            .putInt("themeaccent", themeAccent)
            .putInt("mangabar", mangaBar)
            .putInt(pk("panelsize"), panelSize)
            .putInt(pk("ptype"), profileType)
            .putInt(pk("plevel"), profileLevel)
            .putInt(pk("pbudget"), profileBudget)
            .putBoolean(pk("pbudgetauto"), budgetAuto)
            .putString(pk("uprof"), userProfile)
            .putInt("upopt", upOpt)
            .putFloat(pk("pfadelvl"), panelFadeLevel)
            .putFloat(pk("lalpha"), layerAlpha)
            .putFloat(pk("dim"), dim)
            .putBoolean(pk("pautoclose"), panelAutoClose)
            .putBoolean(pk("plocked"), panelLocked)
            .putBoolean(pk("auto"), autoMode)
            .putBoolean(pk("autoai2"), autoAiSmall)
            .putBoolean("autonext", autoNext)
            .putBoolean(pk("autolive"), autoLive)
            .putInt(pk("autolivelvl"), autoLiveLevel)
            .apply()
    }

    /** Converts a target-height preset into a capture-scale percentage for the given native screen height. */
    fun pctForPreset(preset: Int, nativeH: Int): Int {
        if (preset <= 0 || nativeH <= 0) return scalePct
        return ((preset * 100f) / nativeH).toInt().coerceIn(SCALE_MIN, SCALE_MAX)
    }
}
