package app.clearoverlay

import android.content.Context

/** Shared settings (service and activity live in the same process). */
object Cfg {
    const val MODE_SHARP = 0 // sharpen only (FSR 1 RCAS)
    const val MODE_FSR = 1   // FSR 1: EASU upscale + RCAS
    const val MODE_SGSR = 2  // SGSR 1
    const val MODE_FAST = 3  // hardware bilinear upscale + RCAS (cheapest, best for very weak GPUs)
    const val MODE_RAW = 4   // capture at the render scale and show it with NO upscaling filter / sharpening (for comparing)

    /** Anti-aliasing modes (post-process on the captured frame, applied before upscale/sharpen). */
    const val AA_OFF = 0
    const val AA_FXAA_FAST = 1
    const val AA_FXAA_QUALITY = 2
    const val AA_EDGE = 3

    /** Render-resolution presets, in target pixel height. CUSTOM means "use the scalePct slider". */
    const val PRESET_CUSTOM = 0
    const val PRESET_1080 = 1080
    const val PRESET_1440 = 1440
    const val PRESET_4K = 2160
    /** Quick presets shown as swipeable chips: low ones upscale, high ones supersample. */
    val PRESETS = listOf(360, 480, 540, 720, 900, PRESET_1080, PRESET_1440, PRESET_4K)

    /** Render-scale range in percent of the panel. Above 100 = supersampling (render bigger, shrink back). */
    const val SCALE_MIN = 25
    const val SCALE_MAX = 200

    /** Floating-bubble size range, in dp. */
    const val BUBBLE_MIN_DP = 36
    const val BUBBLE_MAX_DP = 84
    const val BUBBLE_DEFAULT_DP = 52
    /** Fraction of the bubble's own size that pokes past the screen edge while asleep. */
    const val BUBBLE_SLEEP_FRACTION = 0.37f
    /** Idle time (seconds) before the bubble goes to sleep: see [bubbleSleepSec]. */
    const val BUBBLE_SLEEP_DEFAULT_SEC = 3
    const val BUBBLE_SLEEP_MIN_SEC = 1
    const val BUBBLE_SLEEP_MAX_SEC = 30

    /** 0..1 sharpening strength. Read every frame, so changes apply live. */
    @Volatile var sharp = 0.7f
    /** Capture size in percent of the screen (ignored in sharpen-only mode). */
    @Volatile var scalePct = 100
    @Volatile var mode = MODE_SHARP
    /** Adds a second sharpening pass. */
    @Volatile var boost = false
    @Volatile var bubble = true
    @Volatile var bubbleX = -1
    @Volatile var bubbleY = -1
    /** Side edge the bubble rests on, and its relative height (0..1 of the usable range; -1 = not saved yet). */
    @Volatile var bubbleRight = true
    @Volatile var bubbleYf = -1f
    /** Which resolution preset chip is selected in the UI; PRESET_CUSTOM means "manual slider". */
    @Volatile var renderPreset = PRESET_CUSTOM
    /** 0..1 color-enhance (saturation + contrast) strength. 0 = off. Read every frame. */
    @Volatile var vivid = 0f
    /** Floating-bubble diameter in dp. */
    @Volatile var bubbleSizeDp = BUBBLE_DEFAULT_DP
    /** Whether the bubble dims and slides toward the edge after being left idle. */
    @Volatile var bubbleSleep = true
    /** Seconds of idle time before the bubble goes to sleep. */
    @Volatile var bubbleSleepSec = BUBBLE_SLEEP_DEFAULT_SEC
    /** 0..1 "Detail / deblur" strength (wide unsharp mask for blurry, upscaled sources). 0 = off. */
    @Volatile var detail = 0f
    /** 0..1 size of that effect: 0 = 1 px, 1 = 4 px blur radius. */
    @Volatile var detailSize = 0.4f
    /** Anti-aliasing mode (AA_*). */
    @Volatile var aaMode = AA_OFF
    /** 0..1 anti-aliasing strength. Read every frame. */
    @Volatile var aaStrength = 0.75f
    /** UI language: Lang.SYSTEM / Lang.EN / Lang.FA. */
    @Volatile var lang = Lang.SYSTEM

    private fun prefs(c: Context) = c.getSharedPreferences("crsc", Context.MODE_PRIVATE)

    fun load(c: Context) {
        val p = prefs(c)
        sharp = p.getFloat("sharp", 0.7f)
        scalePct = p.getInt("scale", 100)
        mode = p.getInt("mode", MODE_SHARP).coerceIn(0, 4)
        boost = p.getBoolean("boost", false)
        bubble = p.getBoolean("bubble", true)
        bubbleX = p.getInt("bx", -1)
        bubbleY = p.getInt("by", -1)
        bubbleRight = p.getBoolean("bright", true)
        bubbleYf = p.getFloat("byf", -1f)
        renderPreset = p.getInt("preset", PRESET_CUSTOM)
        vivid = p.getFloat("vivid", 0f)
        bubbleSizeDp = p.getInt("bsize", BUBBLE_DEFAULT_DP).coerceIn(BUBBLE_MIN_DP, BUBBLE_MAX_DP)
        bubbleSleep = p.getBoolean("bsleep", true)
        bubbleSleepSec = p.getInt("bsleepsec", BUBBLE_SLEEP_DEFAULT_SEC).coerceIn(BUBBLE_SLEEP_MIN_SEC, BUBBLE_SLEEP_MAX_SEC)
        detail = p.getFloat("detail", 0f).coerceIn(0f, 1f)
        detailSize = p.getFloat("detailsz", 0.4f).coerceIn(0f, 1f)
        aaMode = p.getInt("aa", AA_OFF).coerceIn(0, 3)
        aaStrength = p.getFloat("aastr", 0.75f).coerceIn(0f, 1f)
        lang = p.getString("lang", Lang.SYSTEM) ?: Lang.SYSTEM
    }

    fun save(c: Context) {
        prefs(c).edit()
            .putFloat("sharp", sharp)
            .putInt("scale", scalePct)
            .putInt("mode", mode)
            .putBoolean("boost", boost)
            .putBoolean("bubble", bubble)
            .putInt("bx", bubbleX)
            .putInt("by", bubbleY)
            .putBoolean("bright", bubbleRight)
            .putFloat("byf", bubbleYf)
            .putInt("preset", renderPreset)
            .putFloat("vivid", vivid)
            .putInt("bsize", bubbleSizeDp)
            .putBoolean("bsleep", bubbleSleep)
            .putInt("bsleepsec", bubbleSleepSec)
            .putFloat("detail", detail)
            .putFloat("detailsz", detailSize)
            .putInt("aa", aaMode)
            .putFloat("aastr", aaStrength)
            .putString("lang", lang)
            .apply()
    }

    /** Converts a target-height preset into a capture-scale percentage for the given native screen height. */
    fun pctForPreset(preset: Int, nativeH: Int): Int {
        if (preset <= 0 || nativeH <= 0) return scalePct
        return ((preset * 100f) / nativeH).toInt().coerceIn(SCALE_MIN, SCALE_MAX)
    }
}
