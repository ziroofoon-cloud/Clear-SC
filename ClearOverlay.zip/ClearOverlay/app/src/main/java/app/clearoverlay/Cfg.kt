package app.clearoverlay

import android.content.Context

/** Shared settings (service and activity live in the same process). */
object Cfg {
    const val MODE_SHARP = 0 // sharpen only (FSR 1 RCAS)
    const val MODE_FSR = 1   // FSR 1: EASU upscale + RCAS
    const val MODE_SGSR = 2  // SGSR 1
    const val MODE_FAST = 3  // hardware bilinear upscale + RCAS (cheapest, best for very weak GPUs)
    const val MODE_LANCZOS = 5 // own upscaler: Lanczos-3 with anti-ringing + RCAS
    const val MODE_NIS = 6   // NVIDIA Image Scaling (MIT licence): directional polyphase upscale with its own adaptive sharpening
    const val MODE_NIS_SOFT = 8 // NIS Lite with a gentler push: for dark / soft pictures where the normal push amplifies noise more than it helps
    const val MODE_NIS_FAST = 9 // NIS (fast): the original NIS algorithm and the same picture (largest difference 1/255), computed with less work (see README 3.88.0)
    const val MODE_NIS_MID = 10 // NIS (mid): NIS with 4x4 windows and 4-tap filters, about 10% less edge sharpness than NIS, much less work (see README 3.89.9)
    const val MODE_NIS_ORIG = 7 // the original NVIDIA Image Scaling port (heavy, very sharp; kept next to NIS Lite for comparing)
    const val MODE_CLEAR = 11 // own upscaler "Clear": edge-directed 4x4 kernel that smooths stair-steps and flat compression noise, keeps real detail, no halos (see Shaders.CLEAR)
    const val MODE_RAW = 4   // capture at the render scale and show it with NO upscaling filter / sharpening (for comparing)

    /** Anti-aliasing modes (post-process on the captured frame, applied before upscale/sharpen). */
    const val AA_OFF = 0
    const val AA_FXAA_FAST = 1
    const val AA_FXAA_QUALITY = 2
    const val AA_EDGE = 3
    const val AA_SMART = 4

    /** Render-resolution presets, in target pixel height. CUSTOM means "use the scalePct slider". */
    const val PRESET_CUSTOM = 0
    const val PRESET_1080 = 1080
    const val PRESET_1440 = 1440
    const val PRESET_4K = 2160
    /** Quick presets shown as swipeable chips: low ones upscale, high ones supersample. */
    val PRESETS = listOf(360, 480, 540, 720, 900, PRESET_1080, PRESET_1440, PRESET_4K)

    /** Render-scale range in percent of the panel. Above 100 = supersampling (render bigger, shrink back). */
    const val SCALE_MIN = 25
    const val SCALE_MAX = 200

    /** Floating-bubble size range, in dp. */
    const val BUBBLE_MIN_DP = 36
    const val BUBBLE_MAX_DP = 84
    const val BUBBLE_DEFAULT_DP = 52
    /** Fraction of the bubble's own size that pokes past the screen edge while asleep. */
    const val BUBBLE_SLEEP_FRACTION = 0.37f
    /** Idle time (seconds) before the bubble goes to sleep: see [bubbleSleepSec]. */
    const val BUBBLE_SLEEP_DEFAULT_SEC = 3
    const val BUBBLE_SLEEP_MIN_SEC = 1
    const val BUBBLE_SLEEP_MAX_SEC = 30

    /** 0..1 sharpening strength. Read every frame, so changes apply live. */
    @Volatile var sharp = 0.7f
    /** Capture size in percent of the screen (ignored in sharpen-only mode). */
    @Volatile var scalePct = 100
    @Volatile var mode = MODE_SHARP

    /** CRSC Edge quality: 0 light, 1 balanced, 2 strong, 3 crisp, 4 ultra, each one visibly sharper than the last. 5 maximum (3 rounds, heavy) exists in file export only. */
    @Volatile var crscLevel = 1
    /** CRSC Edge + "NIS crispness": 0 off, 1 soft, 2 medium, 3 strong. The NIS (original) sharpener runs on the finished CRSC Edge picture. */
    @Volatile var crscNis = 0
    @Volatile var crscNisFast = false // "Crisp Fast": NIS crispness drawn with Shaders.NIS_CRISP_FAST (same picture as Standard / NIS_SHARP1, less work); the key keeps its old name
    /** CRSC Edge "exact mode": no flat-area shortcuts, every pixel gets the full computation (the same picture as before the lighter update). */
    @Volatile var crscExact = false
    /** NIS fast quality: 0 exact (same picture as before), 1 medium (flat areas read 16 taps instead of 36, nearly the same picture), 2 light (medium + one edge detector call instead of four, about 38 dB against NIS original). */
    @Volatile var nisFastLevel = 0
    /** Adds a second sharpening pass. */
    @Volatile var boost = false
    /** Player: frame generation (an extra in-between frame for every video frame). */
    @Volatile var playerFg = false
    @Volatile var playerFgN = 2
    /** 0 light, 1 normal, 2 high. */
    @Volatile var playerFgQ = 1
    /** Player: temporal clean-up (0 off, 1 light, 2 strong). */
    @Volatile var playerTemporal = 0
    @Volatile var bubble = true
    @Volatile var bubbleX = -1
    @Volatile var bubbleY = -1
    /** Side edge the bubble rests on, and its relative height (0..1 of the usable range; -1 = not saved yet). */
    @Volatile var bubbleRight = true
    @Volatile var bubbleYf = -1f
    /** Which resolution preset chip is selected in the UI; PRESET_CUSTOM means "manual slider". */
    @Volatile var renderPreset = PRESET_CUSTOM
    /** 0..1 color-enhance (saturation + contrast) strength. 0 = off. Read every frame. */
    @Volatile var vivid = 0f
    /** -1..1 contrast around mid-grey (0 = unchanged). Read every frame. */
    @Volatile var contrast = 0f
    /** -1..1 shadows (lift / crush) and highlights (recover / boost), independent saturation, warmth (blue-light <-> warm), 0..1 film grain. */
    @Volatile var shadows = 0f
    @Volatile var highlights = 0f
    @Volatile var saturation = 0f
    @Volatile var warmth = 0f
    /** -1..1 brightness (exposure), vibrance (saturation that spares the already strong colours) and tint (green <-> magenta). */
    @Volatile var brightness = 0f
    @Volatile var vibrance = 0f
    @Volatile var tint = 0f
    @Volatile var grain = 0f
    /** -1..1 clarity (large-scale local contrast; negative = soften), 0..1 anti-ringing (limits halos next to hard edges), 0..2 deinterlace (0 off, 1 / 2 = rebuild the odd / even lines where combing shows). */
    @Volatile var clarity = 0f
    @Volatile var antiRing = 0f
    @Volatile var deint = 0
    /** Video player: cut black bars (letterbox / pillarbox) off the picture automatically. */
    @Volatile var autoCrop = false
    /** "Smooth live": in the video player the heavy effects are lightened step by step while the phone cannot keep up (see [GovFx]). */
    @Volatile var smoothLive = false
    /**
     * Player / photo resolution chain, in pixels of the SHORT side (so portrait and landscape files behave the same).
     * inRes: what the source really is (0 = auto = its own size). A smaller value than the file's size makes the file
     * be brought down to that size first (soft "fake HD" content is then upscaled from clean pixels).
     * outRes: the size the picture is rendered at (0 = auto = the screen). Bigger than the screen = supersampling,
     * smaller than the source = downscaling (a good anti-aliasing), both then shown on the screen.
     */
    @Volatile var inRes = 0
    @Volatile var outRes = 0
    /**
     * midRes: the MIDDLE step (short side, 0 = off). After the clean-up stages the picture is brought down to this size
     * (a clean anti-aliasing), then the chosen upscaler builds it up to the output size. Only used when smaller than the work size.
     */
    @Volatile var midRes = 0
    /** Latest resolution chain of the player's pipeline ("source -> work -> output -> screen"), for the settings panel. */
    @Volatile var resInfo = ""
    /** Measured time (ms) the live pipeline needs per frame, averaged; 0 when nothing is being drawn. Set by [GlPipeline]. */
    @Volatile var drawMs = 0f
    @Volatile var drawMsAt = 0L
    /** Floating-bubble diameter in dp. */
    @Volatile var bubbleSizeDp = BUBBLE_DEFAULT_DP
    /** Whether the bubble dims and slides toward the edge after being left idle. */
    @Volatile var bubbleSleep = true
    /** Seconds of idle time before the bubble goes to sleep. */
    @Volatile var bubbleSleepSec = BUBBLE_SLEEP_DEFAULT_SEC
    /** 0..1 "Detail / deblur" strength (wide unsharp mask for blurry, upscaled sources). 0 = off. */
    @Volatile var detail = 0f
    /** 0..1 size of that effect: 0 = 1 px, 1 = 4 px blur radius. */
    @Volatile var detailSize = 0.4f
    /** 0..1 edge-preserving denoise / deblock strength (cleans compression noise before sharpening). 0 = off. */
    @Volatile var denoise = 0f
    /** 0..1 debanding strength (smooths the stair-steps low-bitrate video makes in gradients). 0 = off. */
    @Volatile var deband = 0f
    /** Smart fix: white balance, levels and a shadow lift measured from the picture itself (video, photo, GIF; every section keeps its own). */
    @Volatile var smartFix = false
    /** Clean upscale: denoise -> sharpen -> anti-aliasing -> upscale -> colour restore (see GlPipeline). */
    @Volatile var cleanUp = false
    /** 0..1 strength of the clean upscale chain (denoise, sharpen and colour restore together). Read every frame. */
    @Volatile var cleanLevel = 0.6f
    /** Anti-aliasing mode (AA_*). */
    @Volatile var aaMode = AA_OFF
    /** 0..1 anti-aliasing strength. Read every frame. */
    @Volatile var aaStrength = 0.75f
    /** UI language: Lang.SYSTEM / Lang.EN / Lang.FA. */
    @Volatile var lang = Lang.SYSTEM
    /** Built-in player: effects on (true) or bypassed = original picture (false). Quick A/B compare. */
    @Volatile var playerFx = true
    /** While the built-in player is open the screen-capture overlay is paused, so the picture is never processed twice. */
    @Volatile var pauseOverlayInPlayer = true
    /** Settings panels turn almost transparent while a slider is held (so the picture can be judged) and the player's one hides itself when idle. */
    @Volatile var panelFade = true
    /** Player: when the controls hide themselves, the FX button stays on screen. */
    @Volatile var fxPinned = false
    /** Manga reader: run the picture effects on every page. */
    @Volatile var mangaFx = false
    /** GIF viewer: run the picture effects on every frame (a free, local alternative to cloud upscaling). */
    @Volatile var gifFx = false
    /** App look: 0 follow the phone, 1 dark, 2 light. */
    @Volatile var themeMode = 0
    /** Text level: 0 full, 1 light (explanations cut short), 2 minimal (explanations hidden). */
    @Volatile var uiMode = 0
    /** App look: 0 modern (rounded, gradient), 1 classic (flat, square-ish). */
    @Volatile var themeStyle = 0
    /** Accent colour of the app (0 = the default cyan / violet, 1..7 = the colours in [Ui.ACCENTS]). */
    @Volatile var themeAccent = 0
    /** Size of the manga reader's top bar (FX, gear, cloud ...): 0 small, 1 medium, 2 large. */
    @Volatile var mangaBar = 1
    /** Player settings panel size: 0 small, 1 medium, 2 large. */
    @Volatile var panelSize = 1
    /** Selected quick profile (see Profiles: 0 video, 1 stream, 2 game, 3 photo, 4 HD movie, 5 anime; -1 = none / edited by hand). */
    @Volatile var profileType = -1
    /** Profile strength: 0 light, 1 balanced, 2 strong, 3 auto (player only: chosen from the upscale ratio). */
    @Volatile var profileLevel = 1
    /** GPU budget of the quick profiles (see Profiles): 0 performance, 1 balanced, 2 quality. */
    @Volatile var profileBudget = 1

    /** Opacity (0.1..1) of the processed screen layer over the real screen (screen overlay). 1 = fully the processed picture. */
    @Volatile var layerAlpha = 1f
    /** Screen dimmer of the overlay, 0 (clear) .. 1 (black). The bubble and the settings panel stay above it. */
    @Volatile var dim = 0f
    /** Opacity (0.05..1) the settings panel dims to while a slider is held. 1 = never dims. */
    @Volatile var panelFadeLevel = 0.12f
    /** The player's settings panel closes itself after a few idle seconds. */
    @Volatile var panelAutoClose = true
    /** The player's settings panel is pinned in place (false = it can be dragged by its title). */
    @Volatile var panelLocked = true
    /** Auto: the app picks profile, strength, GPU budget, anti-aliasing, mode and AI model by itself (see Auto). */
    @Volatile var autoMode = false
    /** Player: "live auto-tuning" - small changes on top of the person's own settings, followed while the video plays. */
    @Volatile var autoLive = false
    /** Strength of the live auto-tuning: 0 light, 1 normal, 2 strong (see [FxAuto]). */
    @Volatile var autoLiveLevel = 1
    /** The live changes themselves (added in [LiveFx]; never saved, zero when the switch is off or nothing is open). */
    @Volatile var tShadows = 0f
    @Volatile var tHighlights = 0f
    @Volatile var tContrast = 0f
    @Volatile var tSaturation = 0f
    @Volatile var tSharp = 0f
    @Volatile var tDenoise = 0f
    /** With Auto: a very small photo is AI-upscaled right after it opens. */
    @Volatile var autoAiSmall = false // opt-in since 3.99.14 (it used to be on by default and started the AI by itself on every small photo)
    /** Player: start the next video of the folder when one ends. */
    @Volatile var autoNext = true

    /** Name of the saved user profile ([UserProfiles]) whose values are currently in force; null once anything is changed by hand. */
    @Volatile var userProfile: String? = null

    /** Upscaler speed tricks: 0 Original (the shaders of 3.99.13), 1 Light (default: the GPU is told not to read the old picture of a target, one read less in CRSC Edge, textureGather for NIS fast / mid),
     *  2 Lightest (also the rewritten FSR 1 / CRSC Edge / Aura shaders of 3.99.45 - 3.99.49). Shared by every section. */
    @Volatile var upOpt = 1

    /**
     * Settings are kept per SECTION, so what is chosen for manga does not change photos, videos, GIFs or the screen
     * layer: "screen" (the overlay over other apps, the original keys), "video", "photo", "manga" and "gif".
     * Only the picture / player settings below are per section; the bubble, language and theme are shared.
     * A section starts as a copy of the screen settings the first time it is used, so nothing is lost.
     */
    @Volatile var section = "screen"
        private set

    val SECTION_KEYS = setOf("sharp", "scale", "mode", "crsclv", "crscnis", "crscnisfast", "nisfastlevel", "crscexact", "boost", "preset", "vivid", "contrast", "shadows", "highlights", "saturation", "warmth", "bright", "vibr", "tint", "grain", "clarity", "antiring", "deint", "autocrop", "smoothlive", "inres", "midres", "outres", "detail", "detailsz", "denoise", "deband", "smartfix", "cleanup", "cleanlv", "aa", "aastr", "pfx", "pfade", "fxpin", "mfx", "gfx", "panelsize", "ptype", "plevel", "pbudget", "uprof", "pfadelvl", "lalpha", "dim", "pautoclose", "plocked", "auto", "autoai2")

    private fun pk(k: String) = if (section == "screen") k else "sec_${section}_$k"

    /** Label of the section whose settings are in force (for panel titles). */
    fun sectionLabel(c: Context): String = c.getString(
        when (section) {
            "video" -> R.string.sec_video
            "photo" -> R.string.sec_photo
            "manga" -> R.string.sec_manga
            "gif" -> R.string.sec_gif
            "stream" -> R.string.sec_stream
            else -> R.string.sec_screen
        }
    )

    /**
     * The key "bright" was used for TWO things in the screen section: the side of the screen the bubble sits on (a Boolean, since long
     * ago) and, since the brightness slider, the brightness (a Float; pk() leaves the key unchanged in the screen section). The last
     * save wrote the Float over the Boolean, and the next start died in getBoolean / getFloat with a ClassCastException (also in the
     * video / photo sections, whose settings are copied from the screen section). The bubble side has its own key now
     * ("bubble_right"); this puts old data right: a Boolean found under "bright" (or "sec_..._bright") is the bubble side or nothing.
     */
    private fun fixBrightKeys(p: android.content.SharedPreferences) {
        var e: android.content.SharedPreferences.Editor? = null
        for ((k, v) in p.all) {
            if (!(k == "bright" || (k.startsWith("sec_") && k.endsWith("_bright")))) continue
            if (v is Float) continue
            val ed = e ?: p.edit().also { e = it }
            if (k == "bright" && v is Boolean && !p.contains("bubble_right")) ed.putBoolean("bubble_right", v)
            ed.remove(k)
        }
        e?.apply()
    }

    /** Switches to a section's settings (loads them). Does nothing when it is already the active one. */
    fun bind(c: Context, name: String) {
        if (name == section && loadedOnce) return
        section = name
        fixBrightKeys(prefs(c))
        seed(c, name)
        load(c)
    }

    private var loadedOnce = false

    private fun seed(c: Context, name: String) {
        if (name == "screen") return
        val p = prefs(c)
        val flag = "sec_${name}_seeded"
        if (!p.getBoolean(flag, false)) {
            val all = p.all
            val e = p.edit()
            for (k in SECTION_KEYS) {
                val v = all[k] ?: continue
                if (k == "bright" && v !is Float) continue
                val nk = "sec_${name}_$k"
                when (v) {
                    is Float -> e.putFloat(nk, v)
                    is Int -> e.putInt(nk, v)
                    is Boolean -> e.putBoolean(nk, v)
                    is String -> e.putString(nk, v)
                    is Long -> e.putLong(nk, v)
                }
            }
            e.putBoolean(flag, true).apply()
        }
        // content defaults, once per section (offline test: CRSC Edge is the best upscaler for these)
        val cdef = "sec_${name}_cdef1"
        if (!p.getBoolean(cdef, false)) {
            val lv = when (name) { "manga" -> 2; "photo", "video" -> 1; else -> -1 }
            val e0 = p.edit()
            if (lv >= 0) e0.putInt("sec_${name}_mode", MODE_LANCZOS).putInt("sec_${name}_crsclv", lv)
            e0.putBoolean(cdef, true).apply()
        }
    }

    private fun prefs(c: Context) = c.getSharedPreferences("crsc", Context.MODE_PRIVATE)

    /** Loads the saved values only the first time in this process: a screen that is opened later must not throw away changes that are
     *  still only in memory (Auto's choices, a Quick profile that was just applied, a slider that is still moving). */
    fun ensureLoaded(c: Context) {
        if (!loadedOnce) load(c)
    }

    fun load(c: Context) {
        loadedOnce = true
        val p = prefs(c)
        fixBrightKeys(p)
        sharp = p.getFloat(pk("sharp"), 0.7f)
        scalePct = p.getInt(pk("scale"), 100)
        mode = p.getInt(pk("mode"), MODE_SHARP).coerceIn(0, 11)
        crscLevel = p.getInt(pk("crsclv"), 1).coerceIn(0, 5)
        crscNis = p.getInt(pk("crscnis"), 0).coerceIn(0, 4)
        crscNisFast = p.getBoolean(pk("crscnisfast"), false)
        crscExact = p.getBoolean(pk("crscexact"), false)
        nisFastLevel = p.getInt(pk("nisfastlevel"), 0).coerceIn(0, 2)
        boost = p.getBoolean(pk("boost"), false)
        playerFg = p.getBoolean("pfg", false)
        playerFgN = p.getInt("pfgn", 2).coerceIn(2, 4)
        playerFgQ = p.getInt("pfgq", 1).coerceIn(0, 3)
        playerTemporal = p.getInt("ptmp", 0).coerceIn(0, 2)
        bubble = p.getBoolean("bubble", true)
        bubbleX = p.getInt("bx", -1)
        bubbleY = p.getInt("by", -1)
        bubbleRight = p.getBoolean("bubble_right", true)
        bubbleYf = p.getFloat("byf", -1f)
        renderPreset = p.getInt(pk("preset"), PRESET_CUSTOM)
        vivid = p.getFloat(pk("vivid"), 0f)
        contrast = p.getFloat(pk("contrast"), 0f).coerceIn(-1f, 1f)
        shadows = p.getFloat(pk("shadows"), 0f).coerceIn(-1f, 1f)
        highlights = p.getFloat(pk("highlights"), 0f).coerceIn(-1f, 1f)
        saturation = p.getFloat(pk("saturation"), 0f).coerceIn(-1f, 1f)
        warmth = p.getFloat(pk("warmth"), 0f).coerceIn(-1f, 1f)
        brightness = p.getFloat(pk("bright"), 0f).coerceIn(-1f, 1f)
        vibrance = p.getFloat(pk("vibr"), 0f).coerceIn(-1f, 1f)
        tint = p.getFloat(pk("tint"), 0f).coerceIn(-1f, 1f)
        grain = p.getFloat(pk("grain"), 0f).coerceIn(0f, 1f)
        clarity = p.getFloat(pk("clarity"), 0f).coerceIn(-1f, 1f)
        antiRing = p.getFloat(pk("antiring"), 0f).coerceIn(0f, 1f)
        deint = p.getInt(pk("deint"), 0).coerceIn(0, 2)
        autoCrop = p.getBoolean(pk("autocrop"), false)
        smoothLive = p.getBoolean(pk("smoothlive"), false)
        inRes = 0 // the Input choice was removed: the app reads the real size of the file itself
        outRes = p.getInt(pk("outres"), 0)
        midRes = p.getInt(pk("midres"), 0)
        bubbleSizeDp = p.getInt("bsize", BUBBLE_DEFAULT_DP).coerceIn(BUBBLE_MIN_DP, BUBBLE_MAX_DP)
        bubbleSleep = p.getBoolean("bsleep", true)
        bubbleSleepSec = p.getInt("bsleepsec", BUBBLE_SLEEP_DEFAULT_SEC).coerceIn(BUBBLE_SLEEP_MIN_SEC, BUBBLE_SLEEP_MAX_SEC)
        detail = p.getFloat(pk("detail"), 0f).coerceIn(0f, 1f)
        detailSize = p.getFloat(pk("detailsz"), 0.4f).coerceIn(0f, 1f)
        denoise = p.getFloat(pk("denoise"), 0f).coerceIn(0f, 1f)
        deband = p.getFloat(pk("deband"), 0f).coerceIn(0f, 1f)
        smartFix = p.getBoolean(pk("smartfix"), false)
        cleanUp = p.getBoolean(pk("cleanup"), false)
        cleanLevel = p.getFloat(pk("cleanlv"), 0.6f).coerceIn(0f, 1f)
        aaMode = p.getInt(pk("aa"), AA_OFF).coerceIn(0, 4)
        aaStrength = p.getFloat(pk("aastr"), 0.75f).coerceIn(0f, 1f)
        lang = p.getString("lang", Lang.SYSTEM) ?: Lang.SYSTEM
        playerFx = p.getBoolean(pk("pfx"), true)
        pauseOverlayInPlayer = p.getBoolean("pauseov", true)
        panelFade = p.getBoolean(pk("pfade"), true)
        fxPinned = p.getBoolean(pk("fxpin"), false)
        mangaFx = p.getBoolean(pk("mfx"), false)
        gifFx = p.getBoolean(pk("gfx"), false)
        themeMode = p.getInt("thememode", 0).coerceIn(0, 2)
        uiMode = p.getInt("uimode", 0).coerceIn(0, 2)
        themeStyle = p.getInt("themestyle", 0).coerceIn(0, 1)
        themeAccent = p.getInt("themeaccent", 0).coerceIn(0, 7)
        mangaBar = p.getInt("mangabar", 1).coerceIn(0, 2)
        panelSize = p.getInt(pk("panelsize"), 1).coerceIn(0, 2)
        profileType = p.getInt(pk("ptype"), -1).coerceIn(-1, Profiles.COUNT - 1)
        profileLevel = p.getInt(pk("plevel"), 1).coerceIn(0, 3)
        profileBudget = p.getInt(pk("pbudget"), 1).coerceIn(0, 2)
        userProfile = p.getString(pk("uprof"), null)
        upOpt = p.getInt("upopt", 1).coerceIn(0, 2)
        panelFadeLevel = p.getFloat(pk("pfadelvl"), 0.12f).coerceIn(0.05f, 1f)
        layerAlpha = p.getFloat(pk("lalpha"), 1f).coerceIn(0.1f, 1f)
        dim = p.getFloat(pk("dim"), 0f).coerceIn(0f, 1f)
        panelAutoClose = p.getBoolean(pk("pautoclose"), true)
        panelLocked = p.getBoolean(pk("plocked"), true)
        autoMode = p.getBoolean(pk("auto"), false)
        autoAiSmall = p.getBoolean(pk("autoai2"), false)
        autoNext = p.getBoolean("autonext", true)
        autoLive = p.getBoolean("autolive", false)
        autoLiveLevel = p.getInt("autolivelvl", 1).coerceIn(0, 2)
    }

    fun save(c: Context) {
        prefs(c).edit()
            .putFloat(pk("sharp"), sharp)
            .putInt(pk("scale"), scalePct)
            .putInt(pk("mode"), mode)
            .putInt(pk("crsclv"), crscLevel)
            .putInt(pk("crscnis"), crscNis)
            .putBoolean(pk("crscnisfast"), crscNisFast)
            .putBoolean(pk("crscexact"), crscExact)
            .putInt(pk("nisfastlevel"), nisFastLevel)
            .putBoolean(pk("boost"), boost)
            .putBoolean("pfg", playerFg)
            .putInt("pfgn", playerFgN)
            .putInt("pfgq", playerFgQ)
            .putInt("ptmp", playerTemporal)
            .putBoolean("bubble", bubble)
            .putInt("bx", bubbleX)
            .putInt("by", bubbleY)
            .putBoolean("bubble_right", bubbleRight)
            .putFloat("byf", bubbleYf)
            .putInt(pk("preset"), renderPreset)
            .putFloat(pk("vivid"), vivid)
            .putFloat(pk("contrast"), contrast)
            .putFloat(pk("shadows"), shadows)
            .putFloat(pk("highlights"), highlights)
            .putFloat(pk("saturation"), saturation)
            .putFloat(pk("warmth"), warmth)
            .putFloat(pk("bright"), brightness)
            .putFloat(pk("vibr"), vibrance)
            .putFloat(pk("tint"), tint)
            .putFloat(pk("grain"), grain)
            .putFloat(pk("clarity"), clarity)
            .putFloat(pk("antiring"), antiRing)
            .putInt(pk("deint"), deint)
            .putBoolean(pk("autocrop"), autoCrop)
            .putBoolean(pk("smoothlive"), smoothLive)
            .putInt(pk("inres"), inRes)
            .putInt(pk("outres"), outRes)
            .putInt(pk("midres"), midRes)
            .putInt("bsize", bubbleSizeDp)
            .putBoolean("bsleep", bubbleSleep)
            .putInt("bsleepsec", bubbleSleepSec)
            .putFloat(pk("detail"), detail)
            .putFloat(pk("detailsz"), detailSize)
            .putFloat(pk("denoise"), denoise)
            .putFloat(pk("deband"), deband)
            .putBoolean(pk("smartfix"), smartFix)
            .putBoolean(pk("cleanup"), cleanUp)
            .putFloat(pk("cleanlv"), cleanLevel)
            .putInt(pk("aa"), aaMode)
            .putFloat(pk("aastr"), aaStrength)
            .putString("lang", lang)
            .putBoolean(pk("pfx"), playerFx)
            .putBoolean("pauseov", pauseOverlayInPlayer)
            .putBoolean(pk("pfade"), panelFade)
            .putBoolean(pk("fxpin"), fxPinned)
            .putBoolean(pk("mfx"), mangaFx)
            .putBoolean(pk("gfx"), gifFx)
            .putInt("thememode", themeMode)
            .putInt("uimode", uiMode)
            .putInt("themestyle", themeStyle)
            .putInt("themeaccent", themeAccent)
            .putInt("mangabar", mangaBar)
            .putInt(pk("panelsize"), panelSize)
            .putInt(pk("ptype"), profileType)
            .putInt(pk("plevel"), profileLevel)
            .putInt(pk("pbudget"), profileBudget)
            .putString(pk("uprof"), userProfile)
            .putInt("upopt", upOpt)
            .putFloat(pk("pfadelvl"), panelFadeLevel)
            .putFloat(pk("lalpha"), layerAlpha)
            .putFloat(pk("dim"), dim)
            .putBoolean(pk("pautoclose"), panelAutoClose)
            .putBoolean(pk("plocked"), panelLocked)
            .putBoolean(pk("auto"), autoMode)
            .putBoolean(pk("autoai2"), autoAiSmall)
            .putBoolean("autonext", autoNext)
            .putBoolean("autolive", autoLive)
            .putInt("autolivelvl", autoLiveLevel)
            .apply()
    }

    /** Converts a target-height preset into a capture-scale percentage for the given native screen height. */
    fun pctForPreset(preset: Int, nativeH: Int): Int {
        if (preset <= 0 || nativeH <= 0) return scalePct
        return ((preset * 100f) / nativeH).toInt().coerceIn(SCALE_MIN, SCALE_MAX)
    }
}
