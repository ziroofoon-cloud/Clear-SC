package app.clearoverlay

import android.content.Context

/** Tiny shared settings holder (service and activity live in the same process). */
object Cfg {
    /** 0..1 sharpening strength. Read every frame, so changes apply live. */
    @Volatile var sharp = 0.5f

    /** Capture size in percent of the screen. 100 = sharpen only, <100 = upscale mode. */
    @Volatile var scalePct = 100

    fun load(c: Context) {
        val p = c.getSharedPreferences("s", Context.MODE_PRIVATE)
        sharp = p.getFloat("sharp", 0.5f)
        scalePct = p.getInt("scale", 100)
    }

    fun save(c: Context) {
        c.getSharedPreferences("s", Context.MODE_PRIVATE).edit()
            .putFloat("sharp", sharp)
            .putInt("scale", scalePct)
            .apply()
    }
}
