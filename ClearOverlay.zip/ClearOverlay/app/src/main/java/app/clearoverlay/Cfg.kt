package app.clearoverlay

import android.content.Context

/** Shared settings (service and activity live in the same process). */
object Cfg {
    const val MODE_SHARP = 0 // sharpen only (FSR 1 RCAS)
    const val MODE_FSR = 1   // FSR 1: EASU upscale + RCAS
    const val MODE_SGSR = 2  // SGSR 1

    /** 0..1 sharpening strength. Read every frame, so changes apply live. */
    @Volatile var sharp = 0.7f
    /** Capture size in percent of the screen (ignored in sharpen-only mode). */
    @Volatile var scalePct = 100
    @Volatile var mode = MODE_SHARP
    /** Adds a second sharpening pass. */
    @Volatile var boost = false
    @Volatile var bubble = true
    @Volatile var bubbleX = -1
    @Volatile var bubbleY = -1

    private fun prefs(c: Context) = c.getSharedPreferences("crsc", Context.MODE_PRIVATE)

    fun load(c: Context) {
        val p = prefs(c)
        sharp = p.getFloat("sharp", 0.7f)
        scalePct = p.getInt("scale", 100)
        mode = p.getInt("mode", MODE_SHARP).coerceIn(0, 2)
        boost = p.getBoolean("boost", false)
        bubble = p.getBoolean("bubble", true)
        bubbleX = p.getInt("bx", -1)
        bubbleY = p.getInt("by", -1)
    }

    fun save(c: Context) {
        prefs(c).edit()
            .putFloat("sharp", sharp)
            .putInt("scale", scalePct)
            .putInt("mode", mode)
            .putBoolean("boost", boost)
            .putBoolean("bubble", bubble)
            .putInt("bx", bubbleX)
            .putInt("by", bubbleY)
            .apply()
    }
}
