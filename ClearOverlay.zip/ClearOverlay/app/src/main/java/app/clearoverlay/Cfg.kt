package app.clearoverlay

import android.content.Context

/** Shared settings (service and activity live in the same process). */
object Cfg {
    const val MODE_SHARP = 0 // sharpen only (FSR 1 RCAS)
    const val MODE_FSR = 1   // FSR 1: EASU upscale + RCAS
    const val MODE_SGSR = 2  // SGSR 1
    const val MODE_FAST = 3  // hardware bilinear upscale + RCAS (cheapest, best for very weak GPUs)
    const val MODE_RAW = 4   // capture at the render scale and show it with NO upscaling filter / sharpening (for comparing)

    /** Anti-aliasing modes (post-process on the captured frame, applied before upscale/sharpen). */
    const val AA_OFF = 0
    const val AA_FXAA_FAST = 1
    const val AA_FXAA_QUALITY = 2
    const val AA_EDGE = 3

    /** Render-resolution presets, in target pixel height. CUSTOM means "use the scalePct slider". */
    const val PRESET_CUSTOM = 0
    const val PRESET_1080 = 1080
    const val PRESET_1440 = 1440
    const val PRESET_4K = 2160
    /** Quick presets shown as swipeable chips: low ones upscale, high ones supersample. */
    val PRESETS = listOf(360, 480, 540, 720, 900, PRESET_1080, PRESET_1440, PRESET_4K)

    /** Render-scale range in percent of the panel. Above 100 = supersampling (render bigger, shrink back). */
    const val SCALE_MIN = 25
    const val SCALE_MAX = 200

    /** Floating-bubble size range, in dp. */
    const val BUBBLE_MIN_DP = 36
    const val BUBBLE_MAX_DP = 84
    const val BUBBLE_DEFAULT_DP = 52
    /** Fraction of the bubble's own size that pokes past the screen edge while asleep. */
    const val BUBBLE_SLEEP_FRACTION = 0.37f
    /** Idle time (seconds) before the bubble goes to sleep: see [bubbleSleepSec]. */
    const val BUBBLE_SLEEP_DEFAULT_SEC = 3
    const val BUBBLE_SLEEP_MIN_SEC = 1
    const val BUBBLE_SLEEP_MAX_SEC = 30

    /** 0..1 sharpening strength. Read every frame, so changes apply live. */
    @Volatile var sharp = 0.7f
    /** Capture size in percent of the screen (ignored in sharpen-only mode). */
    @Volatile var scalePct = 100
    @Volatile var mode = MODE_SHARP
    /** Adds a second sharpening pass. */
    @Volatile var boost = false
    @Volatile var bubble = true
    @Volatile var bubbleX = -1
    @Volatile var bubbleY = -1
    /** Side edge the bubble rests on, and its relative height (0..1 of the usable range; -1 = not saved yet). */
    @Volatile var bubbleRight = true
    @Volatile var bubbleYf = -1f
    /** Which resolution preset chip is selected in the UI; PRESET_CUSTOM means "manual slider". */
    @Volatile var renderPreset = PRESET_CUSTOM
    /** 0..1 color-enhance (saturation + contrast) strength. 0 = off. Read every frame. */
    @Volatile var vivid = 0f
    /** Floating-bubble diameter in dp. */
    @Volatile var bubbleSizeDp = BUBBLE_DEFAULT_DP
    /** Whether the bubble dims and slides toward the edge after being left idle. */
    @Volatile var bubbleSleep = true
    /** Seconds of idle time before the bubble goes to sleep. */
    @Volatile var bubbleSleepSec = BUBBLE_SLEEP_DEFAULT_SEC
    /** 0..1 "Detail / deblur" strength (wide unsharp mask for blurry, upscaled sources). 0 = off. */
    @Volatile var detail = 0f
    /** 0..1 size of that effect: 0 = 1 px, 1 = 4 px blur radius. */
    @Volatile var detailSize = 0.4f
    /** 0..1 edge-preserving denoise / deblock strength (cleans compression noise before sharpening). 0 = off. */
    @Volatile var denoise = 0f
    /** 0..1 debanding strength (smooths the stair-steps low-bitrate video makes in gradients). 0 = off. */
    @Volatile var deband = 0f
    /** Anti-aliasing mode (AA_*). */
    @Volatile var aaMode = AA_OFF
    /** 0..1 anti-aliasing strength. Read every frame. */
    @Volatile var aaStrength = 0.75f
    /** UI language: Lang.SYSTEM / Lang.EN / Lang.FA. */
    @Volatile var lang = Lang.SYSTEM
    /** Built-in player: effects on (true) or bypassed = original picture (false). Quick A/B compare. */
    @Volatile var playerFx = true
    /** While the built-in player is open the screen-capture overlay is paused, so the picture is never processed twice. */
    @Volatile var pauseOverlayInPlayer = true
    /** Settings panels turn almost transparent while a slider is held (so the picture can be judged) and the player's one hides itself when idle. */
    @Volatile var panelFade = true
    /** Selected quick profile (see Profiles: 0 video, 1 stream, 2 game, 3 photo, 4 HD movie, 5 anime; -1 = none / edited by hand). */
    @Volatile var profileType = -1
    /** Profile strength: 0 light, 1 balanced, 2 strong, 3 auto (player only: chosen from the upscale ratio). */
    @Volatile var profileLevel = 1
    /** GPU budget of the quick profiles (see Profiles): 0 performance, 1 balanced, 2 quality. */
    @Volatile var profileBudget = 1

    /** Opacity (0.05..1) the settings panel dims to while a slider is held. 1 = never dims. */
    @Volatile var panelFadeLevel = 0.12f
    /** The player's settings panel closes itself after a few idle seconds. */
    @Volatile var panelAutoClose = true
    /** The player's settings panel is pinned in place (false = it can be dragged by its title). */
    @Volatile var panelLocked = true
    /** Auto: the app picks profile, strength, GPU budget, anti-aliasing, mode and AI model by itself (see Auto). */
    @Volatile var autoMode = false
    /** With Auto: a very small photo is AI-upscaled right after it opens. */
    @Volatile var autoAiSmall = true
    /** Player: start the next video of the folder when one ends. */
    @Volatile var autoNext = true

    /** Name of the saved user profile ([UserProfiles]) whose values are currently in force; null once anything is changed by hand. */
    @Volatile var userProfile: String? = null

    private fun prefs(c: Context) = c.getSharedPreferences("crsc", Context.MODE_PRIVATE)

    fun load(c: Context) {
        val p = prefs(c)
        sharp = p.getFloat("sharp", 0.7f)
        scalePct = p.getInt("scale", 100)
        mode = p.getInt("mode", MODE_SHARP).coerceIn(0, 4)
        boost = p.getBoolean("boost", false)
        bubble = p.getBoolean("bubble", true)
        bubbleX = p.getInt("bx", -1)
        bubbleY = p.getInt("by", -1)
        bubbleRight = p.getBoolean("bright", true)
        bubbleYf = p.getFloat("byf", -1f)
        renderPreset = p.getInt("preset", PRESET_CUSTOM)
        vivid = p.getFloat("vivid", 0f)
        bubbleSizeDp = p.getInt("bsize", BUBBLE_DEFAULT_DP).coerceIn(BUBBLE_MIN_DP, BUBBLE_MAX_DP)
        bubbleSleep = p.getBoolean("bsleep", true)
        bubbleSleepSec = p.getInt("bsleepsec", BUBBLE_SLEEP_DEFAULT_SEC).coerceIn(BUBBLE_SLEEP_MIN_SEC, BUBBLE_SLEEP_MAX_SEC)
        detail = p.getFloat("detail", 0f).coerceIn(0f, 1f)
        detailSize = p.getFloat("detailsz", 0.4f).coerceIn(0f, 1f)
        denoise = p.getFloat("denoise", 0f).coerceIn(0f, 1f)
        deband = p.getFloat("deband", 0f).coerceIn(0f, 1f)
        aaMode = p.getInt("aa", AA_OFF).coerceIn(0, 3)
        aaStrength = p.getFloat("aastr", 0.75f).coerceIn(0f, 1f)
        lang = p.getString("lang", Lang.SYSTEM) ?: Lang.SYSTEM
        playerFx = p.getBoolean("pfx", true)
        pauseOverlayInPlayer = p.getBoolean("pauseov", true)
        panelFade = p.getBoolean("pfade", true)
        profileType = p.getInt("ptype", -1).coerceIn(-1, Profiles.COUNT - 1)
        profileLevel = p.getInt("plevel", 1).coerceIn(0, 3)
        profileBudget = p.getInt("pbudget", 1).coerceIn(0, 2)
        userProfile = p.getString("uprof", null)
        panelFadeLevel = p.getFloat("pfadelvl", 0.12f).coerceIn(0.05f, 1f)
        panelAutoClose = p.getBoolean("pautoclose", true)
        panelLocked = p.getBoolean("plocked", true)
        autoMode = p.getBoolean("auto", false)
        autoAiSmall = p.getBoolean("autoai", true)
        autoNext = p.getBoolean("autonext", true)
    }

    fun save(c: Context) {
        prefs(c).edit()
            .putFloat("sharp", sharp)
            .putInt("scale", scalePct)
            .putInt("mode", mode)
            .putBoolean("boost", boost)
            .putBoolean("bubble", bubble)
            .putInt("bx", bubbleX)
            .putInt("by", bubbleY)
            .putBoolean("bright", bubbleRight)
            .putFloat("byf", bubbleYf)
            .putInt("preset", renderPreset)
            .putFloat("vivid", vivid)
            .putInt("bsize", bubbleSizeDp)
            .putBoolean("bsleep", bubbleSleep)
            .putInt("bsleepsec", bubbleSleepSec)
            .putFloat("detail", detail)
            .putFloat("detailsz", detailSize)
            .putFloat("denoise", denoise)
            .putFloat("deband", deband)
            .putInt("aa", aaMode)
            .putFloat("aastr", aaStrength)
            .putString("lang", lang)
            .putBoolean("pfx", playerFx)
            .putBoolean("pauseov", pauseOverlayInPlayer)
            .putBoolean("pfade", panelFade)
            .putInt("ptype", profileType)
            .putInt("plevel", profileLevel)
            .putInt("pbudget", profileBudget)
            .putString("uprof", userProfile)
            .putFloat("pfadelvl", panelFadeLevel)
            .putBoolean("pautoclose", panelAutoClose)
            .putBoolean("plocked", panelLocked)
            .putBoolean("auto", autoMode)
            .putBoolean("autoai", autoAiSmall)
            .putBoolean("autonext", autoNext)
            .apply()
    }

    /** Converts a target-height preset into a capture-scale percentage for the given native screen height. */
    fun pctForPreset(preset: Int, nativeH: Int): Int {
        if (preset <= 0 || nativeH <= 0) return scalePct
        return ((preset * 100f) / nativeH).toInt().coerceIn(SCALE_MIN, SCALE_MAX)
    }
}
