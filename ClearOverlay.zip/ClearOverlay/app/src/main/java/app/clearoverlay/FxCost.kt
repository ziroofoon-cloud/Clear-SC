package app.clearoverlay

import android.content.Context
import android.util.DisplayMetrics

/**
 * A rough "how heavy are these picture settings" number, so the settings can be matched to what the phone can carry.
 * The unit is the work of FSR 1 (the usual upscaler) on a 1080p picture = 1.0. It is an ESTIMATE from the passes that are switched on
 * (every pass has a typical weight, scaled by the size it works at); real speed depends on the phone's GPU. Next to it the panel shows
 * the measured time of a real frame ([Cfg.drawMs]) when something is being drawn.
 */
object FxCost {
    class Part(val label: Int, val cost: Float)
    class Result(val total: Float, val parts: List<Part>)

    /** 0 light, 1 medium, 2 heavy, 3 very heavy. */
    fun level(total: Float): Int = when {
        total < 1.8f -> 0
        total < 3.5f -> 1
        total < 6f -> 2
        else -> 3
    }

    fun estimate(ctx: Context, video: Boolean): Result {
        val dm: DisplayMetrics = ctx.resources.displayMetrics
        val screenShort = minOf(dm.widthPixels, dm.heightPixels).toFloat()
        // size the finished picture is made at, compared with 1080 p (the work of the upscaler and the passes after it grows with the pixels)
        val outShort = if (Cfg.outRes > 0) Cfg.outRes.toFloat() else screenShort
        val outF = ((outShort / 1080f) * (outShort / 1080f)).coerceIn(0.1f, 9f)
        // the clean-up passes before the upscaler work at the capture / source size, which is smaller
        val preF = if (video) {
            val s = if (Cfg.inRes > 0) Cfg.inRes.toFloat() else minOf(outShort, 1080f)
            ((s / 1080f) * (s / 1080f)).coerceIn(0.05f, 4f)
        } else {
            val k = Cfg.scalePct / 100f
            (k * k * outF).coerceIn(0.05f, 9f)
        }
        val up = ArrayList<Part>()
        val pre = ArrayList<Part>()

        val m = when (Cfg.mode) {
            Cfg.MODE_RAW -> 0.25f
            Cfg.MODE_SHARP -> 0.5f
            Cfg.MODE_FAST -> 0.8f
            Cfg.MODE_FSR -> 1.0f
            Cfg.MODE_SGSR -> 1.2f
            Cfg.MODE_NIS_MID -> 1.2f
            Cfg.MODE_NIS_FAST -> floatArrayOf(1.7f, 1.4f, 1.15f)[Cfg.nisFastLevel.coerceIn(0, 2)]
            Cfg.MODE_NIS, Cfg.MODE_NIS_SOFT -> 1.7f
            Cfg.MODE_NIS_ORIG -> 3.2f
            Cfg.MODE_LANCZOS -> {
                val base = 1.6f + 0.45f * Cfg.crscLevel.coerceIn(0, 5)
                val nis = when (Cfg.crscNis) { 0 -> 0f; else -> if (Cfg.crscNisFast) 0.6f else 0.9f }
                base + nis + (if (Cfg.crscExact) 0.4f else 0f)
            }
            else -> 1.0f
        }
        up.add(Part(R.string.fxc_upscaler, m))
        if (Cfg.boost) up.add(Part(R.string.fxc_boost, 0.4f))
        if (Cfg.detail > 0f) up.add(Part(R.string.fxc_detail, 0.5f + 0.5f * Cfg.detailSize))
        if (Cfg.clarity != 0f) up.add(Part(R.string.fxc_clarity, 0.6f))
        if (Cfg.antiRing > 0f) up.add(Part(R.string.fxc_antiring, 0.25f))
        if (Cfg.deint > 0) up.add(Part(R.string.fxc_deint, if (Cfg.deint >= 2) 0.7f else 0.4f))
        val color = Cfg.vivid > 0f || Cfg.contrast != 0f || Cfg.shadows != 0f || Cfg.highlights != 0f || Cfg.saturation != 0f ||
            Cfg.warmth != 0f || Cfg.brightness != 0f || Cfg.vibrance != 0f || Cfg.tint != 0f || Cfg.smartFix
        if (color) up.add(Part(R.string.fxc_color, 0.2f + (if (Cfg.smartFix) 0.1f else 0f)))
        if (Cfg.grain > 0f) up.add(Part(R.string.fxc_grain, 0.15f))

        if (Cfg.denoise > 0f) pre.add(Part(R.string.fxc_denoise, 0.4f + 0.6f * Cfg.denoise))
        if (Cfg.deband > 0f) pre.add(Part(R.string.fxc_deband, 0.3f))
        if (Cfg.aaMode != Cfg.AA_OFF) pre.add(Part(R.string.fxc_aa, when (Cfg.aaMode) { Cfg.AA_FXAA_FAST -> 0.3f; Cfg.AA_FXAA_QUALITY -> 0.5f; else -> 0.6f }))
        if (video && Cfg.playerTemporal > 0) pre.add(Part(R.string.fxc_temporal, if (Cfg.playerTemporal >= 2) 0.8f else 0.4f))

        val parts = ArrayList<Part>()
        for (p in up) parts.add(Part(p.label, p.cost * outF))
        for (p in pre) parts.add(Part(p.label, p.cost * preF))
        var total = parts.sumOf { it.cost.toDouble() }.toFloat()
        if (video && Cfg.playerFg) {
            // frame generation: an extra picture (or more) for every video frame, plus the motion search
            val n = Cfg.playerFgN.coerceIn(2, 4)
            val q = floatArrayOf(0.6f, 1.0f, 2.2f)[Cfg.playerFgQ.coerceIn(0, 2)]
            val extra = total * (n - 1) * 0.5f + q * outF * (n - 1)
            parts.add(Part(R.string.fxc_fg, extra))
            total += extra
        }
        parts.sortByDescending { it.cost }
        return Result(total, parts)
    }
}
