package app.clearoverlay

import android.content.Context
import android.util.DisplayMetrics

/**
 * A rough "how heavy are these picture settings" number, so the settings can be matched to what the phone can carry.
 * The unit is the work of FSR 1 (the usual upscaler) on a 1080p picture = 1.0. It is an ESTIMATE from the passes that are switched on
 * (every pass has a typical weight, scaled by the size it works at); real speed depends on the phone's GPU. Next to it the panel shows
 * the measured time of a real frame ([Cfg.drawMs]) when something is being drawn.
 */
object FxCost {
    class Part(val label: Int, val cost: Float)
    class Result(val total: Float, val parts: List<Part>)

    // ---- calibration: "Measure speed" gives the REAL frame time of the current settings; with the estimate of the same settings that makes the
    // number of milliseconds one unit costs on THIS phone, and from then on the load shows milliseconds instead of a guess in units
    private const val PREF = "fxcal"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    /**
     * One measurement per UPSCALER (and its own level): the weights in [estimate] are estimates, and a single number taken from one upscaler
     * made every other one look lighter or heavier than it runs (an option that ran smoother could show a higher load). Now an upscaler that was
     * measured shows its own milliseconds; the others show the middle of the measured ones until they are measured too.
     */
    private fun variantKey(): String {
        val sub = when (Cfg.mode) {
            Cfg.MODE_NIS_FAST -> Cfg.nisFastLevel
            Cfg.MODE_NIS_FINE -> 20 + Cfg.nisFastLevel // its own measurements
            Cfg.MODE_NIS_MID -> 10 + Cfg.nisMidLevel // 10 +: the old measurements of Mid used another numbering
            Cfg.MODE_LANCZOS -> Cfg.crscLevel
            else -> 0
        }
        return "u_${Cfg.mode}_${sub}_${Cfg.upOpt}"
    }

    /** True when the current upscaler has its own measurement (the number is then exact for this phone, not an extrapolation). */
    fun hasOwn(ctx: Context): Boolean = runCatching { prefs(ctx).getFloat(variantKey(), 0f) > 0f }.getOrDefault(false)

    /** Milliseconds one unit costs on this phone for the current upscaler (0 = nothing measured yet). */
    fun msPerUnit(ctx: Context): Float = runCatching {
        val p = prefs(ctx)
        val own = p.getFloat(variantKey(), 0f)
        if (own > 0f) own
        else {
            val vals = p.all.entries.filter { it.key.startsWith("u_") }.mapNotNull { it.value as? Float }.filter { it > 0f }.sorted()
            if (vals.isNotEmpty()) vals[vals.size / 2] else p.getFloat("ms_per_unit", 0f)
        }
    }.getOrDefault(0f)

    /** Remembers the measurement: the settings that were on gave [realMs] per frame. */
    fun calibrate(ctx: Context, video: Boolean, realMs: Double): Boolean {
        val t = estimate(ctx, video).total
        if (t < 0.05f || realMs < 0.3 || realMs > 400.0) return false
        val unit = (realMs / t).toFloat()
        prefs(ctx).edit().putFloat("ms_per_unit", unit).putFloat(variantKey(), unit).putLong("at", System.currentTimeMillis()).apply()
        return true
    }

    /** How heavy a frame time is: 0 light (60 fps video with room), 1 medium (60 fps), 2 heavy (30 fps), 3 very heavy. */
    fun levelMs(ms: Float): Int = when {
        ms < 6f -> 0
        ms < 13f -> 1
        ms < 28f -> 2
        else -> 3
    }

    /** 0 light, 1 medium, 2 heavy, 3 very heavy. */
    fun level(total: Float): Int = when {
        total < 1.8f -> 0
        total < 3.5f -> 1
        total < 6f -> 2
        else -> 3
    }

    fun estimate(ctx: Context, video: Boolean): Result {
        val dm: DisplayMetrics = ctx.resources.displayMetrics
        val screenShort = minOf(dm.widthPixels, dm.heightPixels).toFloat()
        // size the finished picture is made at, compared with 1080 p (the work of the upscaler and the passes after it grows with the pixels)
        val outShort = if (Cfg.outRes > 0) Cfg.outRes.toFloat() else screenShort
        val outF = ((outShort / 1080f) * (outShort / 1080f)).coerceIn(0.1f, 9f)
        // the clean-up passes before the upscaler work at the capture / source size, which is smaller
        val preF = if (video) {
            val s = if (Cfg.inRes > 0) Cfg.inRes.toFloat() else minOf(outShort, 1080f)
            ((s / 1080f) * (s / 1080f)).coerceIn(0.05f, 4f)
        } else {
            val k = Cfg.scalePct / 100f
            (k * k * outF).coerceIn(0.05f, 9f)
        }
        val up = ArrayList<Part>()
        val pre = ArrayList<Part>()

        val m = when (Cfg.mode) {
            Cfg.MODE_RAW -> 0.25f
            Cfg.MODE_SHARP -> 0.5f
            Cfg.MODE_FAST -> 0.8f
            Cfg.MODE_FSR -> 1.0f
            Cfg.MODE_SGSR -> 1.2f
            Cfg.MODE_NIS_MID -> floatArrayOf(1.45f, 1.2f, 0.95f)[Cfg.nisMidLevel.coerceIn(0, 2)]
            Cfg.MODE_NIS_FAST, Cfg.MODE_NIS_FINE -> floatArrayOf(1.7f, 1.4f, 1.15f)[Cfg.nisFastLevel.coerceIn(0, 2)]
            Cfg.MODE_NIS, Cfg.MODE_NIS_SOFT -> 1.7f
            Cfg.MODE_NIS_ORIG -> 3.2f
            Cfg.MODE_CLEAR -> 1.4f
            Cfg.MODE_ART -> 2.6f
            Cfg.MODE_NEURAL -> if (Cfg.neuralModel == 1) 5.0f else 3.0f
            Cfg.MODE_PIXEL -> 1.2f
            Cfg.MODE_LANCZOS -> {
                val base = 1.6f + 0.45f * Cfg.crscLevel.coerceIn(0, 5)
                val nis = when (Cfg.crscNis) { 0 -> 0f; else -> if (Cfg.crscNisFast) 0.6f else 0.9f }
                base + nis + (if (Cfg.crscExact) 0.4f else 0f)
            }
            else -> 1.0f
        }
        // "Upscaler speed" (Original / Light / Lightest) changes the work of the upscaler, so it changes the number too. The factors are an
        // ESTIMATE (not measured per phone): Light = every upscaler saves a little memory traffic, CRSC Edge and NIS fast / mid a bit more;
        // (Light measured on a Redmi Note 9 Pro, CRSC Edge level 5: 133.4 ms Original -> 128.7 ms Light, about 3.5 %, close to the run-to-run noise.)
        // Lightest = FSR 1 / CRSC Edge / Aura with the rewritten shaders. Compare with the measured frame time shown next to the number.
        val upF = when (Cfg.upOpt.coerceIn(0, 2)) {
            0 -> 1f
            1 -> if (Cfg.mode == Cfg.MODE_LANCZOS) 0.97f else if (Cfg.mode == Cfg.MODE_NIS_FAST || Cfg.mode == Cfg.MODE_NIS_FINE || Cfg.mode == Cfg.MODE_NIS_MID) 0.96f else if (Cfg.mode == Cfg.MODE_RAW) 1f else 0.98f
            // Lightest: measured on a Redmi Note 9 Pro (CRSC Edge level 5): 144.7 ms against 136.8 Light and about 140 Original, i.e. NOT lighter
            // there (edge smoothing 12.8 vs 9.9 ms, edge steepening 11.6 vs 8.8). Other modes are not measured: they keep the Light factor.
            else -> when (Cfg.mode) {
                Cfg.MODE_LANCZOS -> 0.94f // since 3.99.81: Lightest skips about 4x more flat pixels and Max uses 2 rounds (an estimate, not measured on a phone yet)
                Cfg.MODE_NIS_FAST, Cfg.MODE_NIS_FINE, Cfg.MODE_NIS_MID -> 0.96f
                Cfg.MODE_RAW -> 1f
                else -> 0.98f
            }
        }
        up.add(Part(R.string.fxc_upscaler, m * upF))
        // NIS crispness runs after EVERY upscaler (CRSC Edge already has its share in the number above)
        if (Cfg.crscNis > 0 && Cfg.mode != Cfg.MODE_LANCZOS && Cfg.mode != Cfg.MODE_CLEAR && Cfg.mode != Cfg.MODE_ART && Cfg.mode != Cfg.MODE_NEURAL && Cfg.mode != Cfg.MODE_PIXEL && Cfg.mode != Cfg.MODE_RAW) up.add(Part(R.string.fxc_crisp, if (Cfg.crscNisFast) 0.6f else 0.9f))
        // "Fine pixels" on top of the upscaler: one cheap pass at the output size (the old upscaler of that name is counted in the number above)
        if (Cfg.finePixels && Cfg.mode != Cfg.MODE_RAW && Cfg.mode != Cfg.MODE_PIXEL) up.add(Part(R.string.fxc_pixel, 0.3f))
        if (Cfg.autoCrop) up.add(Part(R.string.fxc_autocrop, 0.1f))
        if (Cfg.boost) up.add(Part(R.string.fxc_boost, 0.4f))
        if (Cfg.detail > 0f) up.add(Part(R.string.fxc_detail, 0.5f + 0.5f * Cfg.detailSize))
        if (Cfg.clarity != 0f) up.add(Part(R.string.fxc_clarity, 0.6f))
        if (Cfg.antiRing > 0f) up.add(Part(R.string.fxc_antiring, 0.25f))
        if (Cfg.deint > 0) up.add(Part(R.string.fxc_deint, if (Cfg.deint >= 2) 0.8f else 0.5f))
        // Clean upscale (denoise -> sharpen -> upscale -> anti-aliasing -> colour restore): its sharpen pass works at the capture size,
        // its anti-aliasing and colour restore run on the enlarged picture (see GlPipeline)
        if (Cfg.cleanUp && Cfg.mode != Cfg.MODE_RAW) pre.add(Part(R.string.fxc_cleanup, 0.3f))
        val color = Cfg.vivid > 0f || Cfg.contrast != 0f || Cfg.shadows != 0f || Cfg.highlights != 0f || Cfg.saturation != 0f ||
            Cfg.warmth != 0f || Cfg.brightness != 0f || Cfg.vibrance != 0f || Cfg.tint != 0f || Cfg.smartFix || Cfg.cleanUp || Cfg.vignette != 0f || Cfg.fade > 0f
        if (color) up.add(Part(R.string.fxc_color, 0.2f + (if (Cfg.smartFix) 0.1f else 0f)))
        if (Cfg.grain > 0f) up.add(Part(R.string.fxc_grain, 0.15f))
        if (Cfg.faintLift > 0.004f) up.add(Part(R.string.fxc_faint, 0.7f))
        if (Cfg.gameLight > 0.004f) up.add(Part(R.string.fxc_gamelight, 0.6f))

        // with Clean upscale the denoise pass always runs, at least as strong as the chain asks (GlPipeline: max(denoise, 0.08 + 0.25 * level))
        val dnAmt = if (Cfg.cleanUp) maxOf(Cfg.denoise, 0.08f + 0.25f * Cfg.cleanLevel) else Cfg.denoise
        if (dnAmt > 0f) pre.add(Part(R.string.fxc_denoise, 0.4f + 0.6f * dnAmt))
        // Colour clean-up: one pass at the capture size, 16 taps (a bit more than the denoise)
        if (Cfg.chromaClean > 0f) pre.add(Part(R.string.fxc_chroma, 0.45f + 0.25f * Cfg.chromaClean))
        // Protect noise: a few more operations inside the sharpening pass at the output size
        if (Cfg.sharpProtect > 0f && Cfg.mode != Cfg.MODE_RAW) up.add(Part(R.string.fxc_protect, 0.06f))
        if (Cfg.deband > 0f) pre.add(Part(R.string.fxc_deband, 0.3f))
        // AI upscaler 2x (player, small videos): four passes of a tiny network at the capture size (8 channels: 1700 weights, 12 channels about 1.8x that)
        if (video && Cfg.srLive && Cfg.mode != Cfg.MODE_RAW && Cfg.mode != Cfg.MODE_PIXEL) pre.add(Part(R.string.fxc_ai2x, if (Cfg.srWide) 1.1f else 0.6f))
        // anti-aliasing: before the upscale, except with Clean upscale (then it runs on the enlarged picture, FXAA Quality when none is chosen)
        val aaSel = if (Cfg.aaMode != Cfg.AA_OFF) Cfg.aaMode else if (Cfg.cleanUp && Cfg.mode != Cfg.MODE_RAW) Cfg.AA_FXAA_QUALITY else Cfg.AA_OFF
        if (aaSel != Cfg.AA_OFF) {
            val aaPart = Part(R.string.fxc_aa, when (aaSel) { Cfg.AA_FXAA_FAST -> 0.3f; Cfg.AA_FXAA_QUALITY -> 0.5f; Cfg.AA_SMART -> 0.8f; else -> 0.6f })
            if (Cfg.cleanUp && Cfg.mode != Cfg.MODE_RAW) up.add(aaPart) else pre.add(aaPart)
        }
        if (video && Cfg.playerTemporal > 0) pre.add(Part(R.string.fxc_temporal, if (Cfg.playerTemporal >= 2) 0.8f else 0.4f))

        val parts = ArrayList<Part>()
        for (p in up) parts.add(Part(p.label, p.cost * outF))
        for (p in pre) parts.add(Part(p.label, p.cost * preF))
        var total = parts.sumOf { it.cost.toDouble() }.toFloat()
        if (video && Cfg.playerFg) {
            // frame generation: an extra picture (or more) for every video frame, plus the motion search
            val n = Cfg.playerFgN.coerceIn(2, 4)
            val q = floatArrayOf(0.6f, 1.0f, 2.2f)[Cfg.playerFgQ.coerceIn(0, 2)]
            val extra = total * (n - 1) * 0.5f + q * outF * (n - 1)
            parts.add(Part(R.string.fxc_fg, extra))
            total += extra
        }
        parts.sortByDescending { it.cost }
        return Result(total, parts)
    }
}
