package app.clearoverlay

import android.content.Context
import android.util.DisplayMetrics

/**
 * A rough "how heavy are these picture settings" number, so the settings can be matched to what the phone can carry.
 * The unit is the work of FSR 1 (the usual upscaler) on a 1080p picture = 1.0. It is an ESTIMATE from the passes that are switched on
 * (every pass has a typical weight, scaled by the size it works at); real speed depends on the phone's GPU. Next to it the panel shows
 * the measured time of a real frame ([Cfg.drawMs]) when something is being drawn.
 */
object FxCost {
    class Part(val label: Int, val cost: Float)
    class Result(val total: Float, val parts: List<Part>)

    // ---- calibration: "Measure speed" gives the REAL frame time of the current settings; with the estimate of the same settings that makes the
    // number of milliseconds one unit costs on THIS phone, and from then on the load shows milliseconds instead of a guess in units
    private const val PREF = "fxcal"

    /** Milliseconds one unit costs on this phone (0 = not measured yet). */
    fun msPerUnit(ctx: Context): Float = runCatching { ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getFloat("ms_per_unit", 0f) }.getOrDefault(0f)

    /** Remembers the measurement: the settings that were on gave [realMs] per frame. */
    fun calibrate(ctx: Context, video: Boolean, realMs: Double): Boolean {
        val t = estimate(ctx, video).total
        if (t < 0.05f || realMs < 0.3 || realMs > 400.0) return false
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putFloat("ms_per_unit", (realMs / t).toFloat()).putLong("at", System.currentTimeMillis()).apply()
        return true
    }

    /** How heavy a frame time is: 0 light (60 fps video with room), 1 medium (60 fps), 2 heavy (30 fps), 3 very heavy. */
    fun levelMs(ms: Float): Int = when {
        ms < 6f -> 0
        ms < 13f -> 1
        ms < 28f -> 2
        else -> 3
    }

    /** 0 light, 1 medium, 2 heavy, 3 very heavy. */
    fun level(total: Float): Int = when {
        total < 1.8f -> 0
        total < 3.5f -> 1
        total < 6f -> 2
        else -> 3
    }

    fun estimate(ctx: Context, video: Boolean): Result {
        val dm: DisplayMetrics = ctx.resources.displayMetrics
        val screenShort = minOf(dm.widthPixels, dm.heightPixels).toFloat()
        // size the finished picture is made at, compared with 1080 p (the work of the upscaler and the passes after it grows with the pixels)
        val outShort = if (Cfg.outRes > 0) Cfg.outRes.toFloat() else screenShort
        val outF = ((outShort / 1080f) * (outShort / 1080f)).coerceIn(0.1f, 9f)
        // the clean-up passes before the upscaler work at the capture / source size, which is smaller
        val preF = if (video) {
            val s = if (Cfg.inRes > 0) Cfg.inRes.toFloat() else minOf(outShort, 1080f)
            ((s / 1080f) * (s / 1080f)).coerceIn(0.05f, 4f)
        } else {
            val k = Cfg.scalePct / 100f
            (k * k * outF).coerceIn(0.05f, 9f)
        }
        val up = ArrayList<Part>()
        val pre = ArrayList<Part>()

        val m = when (Cfg.mode) {
            Cfg.MODE_RAW -> 0.25f
            Cfg.MODE_SHARP -> 0.5f
            Cfg.MODE_FAST -> 0.8f
            Cfg.MODE_FSR -> 1.0f
            Cfg.MODE_SGSR -> 1.2f
            Cfg.MODE_NIS_MID -> floatArrayOf(1.2f, 0.95f)[Cfg.nisMidLevel.coerceIn(0, 1)]
            Cfg.MODE_NIS_FAST -> floatArrayOf(1.7f, 1.4f, 1.15f)[Cfg.nisFastLevel.coerceIn(0, 2)]
            Cfg.MODE_NIS, Cfg.MODE_NIS_SOFT -> 1.7f
            Cfg.MODE_NIS_ORIG -> 3.2f
            Cfg.MODE_CLEAR -> 1.4f
            Cfg.MODE_PIXEL -> 1.2f
            Cfg.MODE_LANCZOS -> {
                val base = 1.6f + 0.45f * Cfg.crscLevel.coerceIn(0, 5)
                val nis = when (Cfg.crscNis) { 0 -> 0f; else -> if (Cfg.crscNisFast) 0.6f else 0.9f }
                base + nis + (if (Cfg.crscExact) 0.4f else 0f)
            }
            else -> 1.0f
        }
        // "Upscaler speed" (Original / Light / Lightest) changes the work of the upscaler, so it changes the number too. The factors are an
        // ESTIMATE (not measured per phone): Light = every upscaler saves a little memory traffic, CRSC Edge and NIS fast / mid a bit more;
        // (Light measured on a Redmi Note 9 Pro, CRSC Edge level 5: 133.4 ms Original -> 128.7 ms Light, about 3.5 %, close to the run-to-run noise.)
        // Lightest = FSR 1 / CRSC Edge / Aura with the rewritten shaders. Compare with the measured frame time shown next to the number.
        val upF = when (Cfg.upOpt.coerceIn(0, 2)) {
            0 -> 1f
            1 -> if (Cfg.mode == Cfg.MODE_LANCZOS) 0.97f else if (Cfg.mode == Cfg.MODE_NIS_FAST || Cfg.mode == Cfg.MODE_NIS_MID) 0.96f else if (Cfg.mode == Cfg.MODE_RAW) 1f else 0.98f
            // Lightest: measured on a Redmi Note 9 Pro (CRSC Edge level 5): 144.7 ms against 136.8 Light and about 140 Original, i.e. NOT lighter
            // there (edge smoothing 12.8 vs 9.9 ms, edge steepening 11.6 vs 8.8). Other modes are not measured: they keep the Light factor.
            else -> when (Cfg.mode) {
                Cfg.MODE_LANCZOS -> 0.94f // since 3.99.81: Lightest skips about 4x more flat pixels and Max uses 2 rounds (an estimate, not measured on a phone yet)
                Cfg.MODE_NIS_FAST, Cfg.MODE_NIS_MID -> 0.96f
                Cfg.MODE_RAW -> 1f
                else -> 0.98f
            }
        }
        up.add(Part(R.string.fxc_upscaler, m * upF))
        // NIS crispness runs after EVERY upscaler (CRSC Edge already has its share in the number above)
        if (Cfg.crscNis > 0 && Cfg.mode != Cfg.MODE_LANCZOS && Cfg.mode != Cfg.MODE_CLEAR && Cfg.mode != Cfg.MODE_PIXEL && Cfg.mode != Cfg.MODE_RAW) up.add(Part(R.string.fxc_crisp, if (Cfg.crscNisFast) 0.6f else 0.9f))
        if (Cfg.autoCrop) up.add(Part(R.string.fxc_autocrop, 0.1f))
        if (Cfg.boost) up.add(Part(R.string.fxc_boost, 0.4f))
        if (Cfg.detail > 0f) up.add(Part(R.string.fxc_detail, 0.5f + 0.5f * Cfg.detailSize))
        if (Cfg.clarity != 0f) up.add(Part(R.string.fxc_clarity, 0.6f))
        if (Cfg.antiRing > 0f) up.add(Part(R.string.fxc_antiring, 0.25f))
        if (Cfg.deint > 0) up.add(Part(R.string.fxc_deint, if (Cfg.deint >= 2) 0.7f else 0.4f))
        // Clean upscale (denoise -> sharpen -> upscale -> anti-aliasing -> colour restore): its sharpen pass works at the capture size,
        // its anti-aliasing and colour restore run on the enlarged picture (see GlPipeline)
        if (Cfg.cleanUp && Cfg.mode != Cfg.MODE_RAW) pre.add(Part(R.string.fxc_cleanup, 0.3f))
        val color = Cfg.vivid > 0f || Cfg.contrast != 0f || Cfg.shadows != 0f || Cfg.highlights != 0f || Cfg.saturation != 0f ||
            Cfg.warmth != 0f || Cfg.brightness != 0f || Cfg.vibrance != 0f || Cfg.tint != 0f || Cfg.smartFix || Cfg.cleanUp
        if (color) up.add(Part(R.string.fxc_color, 0.2f + (if (Cfg.smartFix) 0.1f else 0f)))
        if (Cfg.grain > 0f) up.add(Part(R.string.fxc_grain, 0.15f))

        // with Clean upscale the denoise pass always runs, at least as strong as the chain asks (GlPipeline: max(denoise, 0.08 + 0.25 * level))
        val dnAmt = if (Cfg.cleanUp) maxOf(Cfg.denoise, 0.08f + 0.25f * Cfg.cleanLevel) else Cfg.denoise
        if (dnAmt > 0f) pre.add(Part(R.string.fxc_denoise, 0.4f + 0.6f * dnAmt))
        if (Cfg.deband > 0f) pre.add(Part(R.string.fxc_deband, 0.3f))
        // anti-aliasing: before the upscale, except with Clean upscale (then it runs on the enlarged picture, FXAA Quality when none is chosen)
        val aaSel = if (Cfg.aaMode != Cfg.AA_OFF) Cfg.aaMode else if (Cfg.cleanUp && Cfg.mode != Cfg.MODE_RAW) Cfg.AA_FXAA_QUALITY else Cfg.AA_OFF
        if (aaSel != Cfg.AA_OFF) {
            val aaPart = Part(R.string.fxc_aa, when (aaSel) { Cfg.AA_FXAA_FAST -> 0.3f; Cfg.AA_FXAA_QUALITY -> 0.5f; Cfg.AA_SMART -> 0.8f; else -> 0.6f })
            if (Cfg.cleanUp && Cfg.mode != Cfg.MODE_RAW) up.add(aaPart) else pre.add(aaPart)
        }
        if (video && Cfg.playerTemporal > 0) pre.add(Part(R.string.fxc_temporal, if (Cfg.playerTemporal >= 2) 0.8f else 0.4f))

        val parts = ArrayList<Part>()
        for (p in up) parts.add(Part(p.label, p.cost * outF))
        for (p in pre) parts.add(Part(p.label, p.cost * preF))
        var total = parts.sumOf { it.cost.toDouble() }.toFloat()
        if (video && Cfg.playerFg) {
            // frame generation: an extra picture (or more) for every video frame, plus the motion search
            val n = Cfg.playerFgN.coerceIn(2, 4)
            val q = floatArrayOf(0.6f, 1.0f, 2.2f)[Cfg.playerFgQ.coerceIn(0, 2)]
            val extra = total * (n - 1) * 0.5f + q * outF * (n - 1)
            parts.add(Part(R.string.fxc_fg, extra))
            total += extra
        }
        parts.sortByDescending { it.cost }
        return Result(total, parts)
    }
}
