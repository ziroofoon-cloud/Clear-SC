package app.clearoverlay

import android.content.Context
import com.hierynomus.msdtyp.AccessMask
import com.hierynomus.msfscc.FileAttributes
import com.hierynomus.mssmb2.SMB2CreateDisposition
import com.hierynomus.mssmb2.SMB2ShareAccess
import com.hierynomus.smbj.SMBClient
import com.hierynomus.smbj.SmbConfig
import com.hierynomus.smbj.auth.AuthenticationContext
import com.hierynomus.smbj.auth.NtlmAuthenticator
import com.hierynomus.smbj.connection.Connection
import com.hierynomus.smbj.session.Session
import com.hierynomus.smbj.share.DiskShare
import org.apache.commons.net.ftp.FTPClient
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.lang.reflect.InvocationTargetException
import java.util.EnumSet
import java.util.concurrent.TimeUnit

/**
 * The storages of the file manager besides the phone's own files ([LocalFs]) and WebDAV ([WebDavFs]): shared folders on the
 * network (SMB) and FTP servers, this time with writing (copy to / from the phone, new folder, rename, delete). The servers are the
 * ones saved in [Net]; browsing them in the network screen and in the file manager shows the same list.
 */

// ---------------------------------------------------------------------------------------------------------------------------------
// SMB
// ---------------------------------------------------------------------------------------------------------------------------------

class SmbFs(private val s: Net.Server) : FmFs {
    private val client = SMBClient(
        // NTLM only: the Kerberos classes smbj would otherwise try to load do not exist on Android
        SmbConfig.builder()
            .withTimeout(20, TimeUnit.SECONDS)
            .withSoTimeout(60, TimeUnit.SECONDS)
            .withAuthenticators(NtlmAuthenticator.Factory())
            .build()
    )
    private var conn: Connection? = null
    private var session: Session? = null
    private var share: DiskShare? = null

    init {
        try {
            if (s.share.isBlank()) throw IOException("share name is empty")
            val c = client.connect(s.host, if (s.port > 0) s.port else 445)
            conn = c
            val auth = if (s.user.isEmpty()) AuthenticationContext.guest() else AuthenticationContext(s.user, s.pass.toCharArray(), "")
            val ses = c.authenticate(auth)
            session = ses
            share = ses.connectShare(s.share) as DiskShare
        } catch (e: Exception) {
            close()
            throw if (e is IOException) e else IOException(e.message ?: e.javaClass.simpleName, e)
        }
    }

    private fun sh(): DiskShare = share ?: throw IOException("not connected")

    private fun p(path: String) = path.trim('/').replace('/', '\\')

    /** The less common smbj calls go through reflection: a different smbj version then fails with a message instead of breaking the build. */
    private fun call(target: Any, name: String, vararg args: Any?): Any? {
        val m = target.javaClass.methods.firstOrNull { it.name == name && it.parameterTypes.size == args.size }
            ?: throw IOException("this SMB library has no $name")
        try {
            return m.invoke(target, *args)
        } catch (e: InvocationTargetException) {
            throw (e.targetException as? IOException) ?: IOException(e.targetException?.message ?: e.targetException?.javaClass?.simpleName, e.targetException)
        }
    }

    override fun root(): String = s.path.ifEmpty { "/" }

    override fun parent(path: String): String? = if (path.trim('/').isEmpty()) null else Net.parent(path)

    override fun join(dir: String, name: String): String = Net.join(dir, name)

    override fun list(dir: String): List<FmItem> {
        return sh().list(p(dir)).mapNotNull { f ->
            val n = f.fileName
            if (n == "." || n == "..") return@mapNotNull null
            val isDir = (f.fileAttributes and FileAttributes.FILE_ATTRIBUTE_DIRECTORY.value) != 0L
            FmItem(n, isDir, if (isDir) -1L else f.endOfFile, 0L)
        }
    }

    override fun open(path: String): InputStream {
        val f = sh().openFile(
            p(path), EnumSet.of(AccessMask.GENERIC_READ), null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_OPEN, null
        )
        return object : InputStream() {
            private var pos = 0L
            private var closed = false
            override fun read(): Int {
                val b = ByteArray(1)
                return if (read(b, 0, 1) <= 0) -1 else b[0].toInt() and 0xFF
            }

            override fun read(b: ByteArray, off: Int, len: Int): Int {
                if (len == 0) return 0
                val n = f.read(b, pos, off, len)
                if (n <= 0) return -1
                pos += n
                return n
            }

            override fun close() {
                if (closed) return
                closed = true
                runCatching { f.close() }
            }
        }
    }

    override fun create(path: String, size: Long): OutputStream {
        val f = sh().openFile(
            p(path), EnumSet.of(AccessMask.GENERIC_WRITE), null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_OVERWRITE_IF, null
        )
        val wm = f.javaClass.methods.firstOrNull { it.name == "write" && it.parameterTypes.size == 4 && it.parameterTypes[1] == java.lang.Long.TYPE }
        if (wm == null) {
            runCatching { f.close() }
            throw IOException("this SMB library cannot write files")
        }
        return object : OutputStream(), FmAbortable {
            private var pos = 0L
            private var closed = false
            override fun write(b: Int) {
                write(byteArrayOf(b.toByte()), 0, 1)
            }

            override fun write(b: ByteArray, off: Int, len: Int) {
                if (len == 0) return
                try {
                    wm.invoke(f, b, pos, off, len)
                } catch (e: InvocationTargetException) {
                    throw (e.targetException as? IOException) ?: IOException(e.targetException?.message ?: "write failed", e.targetException)
                }
                pos += len
            }

            override fun close() {
                if (closed) return
                closed = true
                f.close()
            }

            override fun abort() {
                if (closed) return
                closed = true
                runCatching { f.close() }
                runCatching { delete(path) } // no half file left behind
            }
        }
    }

    override fun mkdir(path: String) {
        if (exists(path)) return
        call(sh(), "mkdir", p(path))
    }

    override fun delete(path: String) {
        val sh = sh()
        val q = p(path)
        try {
            call(sh, "rm", q)
        } catch (e: IOException) {
            // not a file: a folder, with everything in it
            call(sh, "rmdir", q, true)
        }
    }

    override fun rename(path: String, newName: String) {
        if (!moveWithin(path, join(parent(path) ?: "/", newName))) throw IOException("cannot rename " + path)
    }

    override fun moveWithin(from: String, to: String): Boolean {
        val sh = sh()
        val acc = EnumSet.of(AccessMask.DELETE, AccessMask.GENERIC_READ)
        val entry: Any = try {
            sh.openFile(p(from), acc, null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_OPEN, null)
        } catch (e: Exception) {
            val m = sh.javaClass.methods.firstOrNull { it.name == "openDirectory" && it.parameterTypes.size == 6 }
                ?: throw IOException("this SMB library cannot rename folders")
            try {
                m.invoke(sh, p(from), acc, null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_OPEN, null) as Any
            } catch (t: InvocationTargetException) {
                throw (t.targetException as? IOException) ?: IOException(t.targetException?.message ?: "cannot open " + from, t.targetException)
            }
        }
        try {
            call(entry, "rename", p(to))
            return true
        } finally {
            runCatching { call(entry, "close") }
        }
    }

    override fun exists(path: String): Boolean {
        val q = p(path)
        if (q.isEmpty()) return true
        return try {
            sh().getFileInformation(q)
            true
        } catch (e: Exception) {
            false
        }
    }

    override fun localFile(path: String): File? = null

    override fun freeSpace(): Long = -1L

    override fun close() {
        runCatching { share?.close() }
        runCatching { session?.close() }
        runCatching { conn?.close() }
        runCatching { client.close() }
        share = null
        session = null
        conn = null
    }
}

// ---------------------------------------------------------------------------------------------------------------------------------
// FTP
// ---------------------------------------------------------------------------------------------------------------------------------

/**
 * One control connection for folder work (list / mkdir / delete / rename); every file transfer opens its own connection, so a copy
 * inside the same server (read one file while writing another) works and a long transfer never blocks browsing.
 */
class FtpFs(private val s: Net.Server) : FmFs {
    private var main: FTPClient? = null

    private fun newClient(): FTPClient {
        val ftp = FTPClient()
        try {
            ftp.controlEncoding = "UTF-8"
            ftp.connectTimeout = 15000
            ftp.connect(s.host, if (s.port > 0) s.port else 21)
            ftp.soTimeout = 30000
            val user = s.user.ifEmpty { "anonymous" }
            val pass = if (s.user.isEmpty()) "anonymous@" else s.pass
            if (!ftp.login(user, pass)) throw IOException("FTP login failed: " + ftp.replyString.trim())
            ftp.enterLocalPassiveMode()
            ftp.setFileType(org.apache.commons.net.ftp.FTP.BINARY_FILE_TYPE)
            ftp.setDataTimeout(30000)
            return ftp
        } catch (e: Exception) {
            runCatching { if (ftp.isConnected) ftp.disconnect() }
            throw if (e is IOException) e else IOException(e.message ?: e.javaClass.simpleName, e)
        }
    }

    @Synchronized
    private fun ctl(): FTPClient {
        val c = main
        if (c != null && c.isConnected && runCatching { c.sendNoOp() }.getOrDefault(false)) return c
        if (c != null) runCatching { c.disconnect() }
        val n = newClient()
        main = n
        return n
    }

    override fun root(): String = s.path.ifEmpty { "/" }

    override fun parent(path: String): String? = if (path.trim('/').isEmpty()) null else Net.parent(path)

    override fun join(dir: String, name: String): String = Net.join(dir, name)

    @Synchronized
    override fun list(dir: String): List<FmItem> {
        val a = ctl().listFiles(if (dir.isEmpty()) "/" else dir) ?: return emptyList()
        return a.filter { it != null && it.name != "." && it.name != ".." }.map {
            FmItem(it.name.substringAfterLast('/'), it.isDirectory, if (it.isDirectory) -1L else it.size, it.timestamp?.timeInMillis ?: 0L)
        }
    }

    override fun open(path: String): InputStream {
        val c = newClient()
        try {
            val ins = c.retrieveFileStream(path) ?: throw IOException("FTP: " + c.replyString.trim())
            return object : InputStream() {
                override fun read(): Int = ins.read()
                override fun read(b: ByteArray, off: Int, len: Int): Int = ins.read(b, off, len)
                override fun close() {
                    runCatching { ins.close() }
                    runCatching { c.abort() }
                    runCatching { c.disconnect() }
                }
            }
        } catch (e: Exception) {
            runCatching { c.disconnect() }
            throw if (e is IOException) e else IOException(e.message ?: e.javaClass.simpleName, e)
        }
    }

    override fun create(path: String, size: Long): OutputStream {
        val c = newClient()
        try {
            val out = c.storeFileStream(path) ?: throw IOException("FTP: " + c.replyString.trim())
            return object : OutputStream(), FmAbortable {
                private var fin = false
                override fun write(b: Int) = out.write(b)
                override fun write(b: ByteArray, off: Int, len: Int) = out.write(b, off, len)
                override fun close() {
                    if (fin) return
                    fin = true
                    try {
                        out.close()
                        if (!c.completePendingCommand()) throw IOException("FTP: " + c.replyString.trim())
                    } finally {
                        runCatching { c.logout() }
                        runCatching { c.disconnect() }
                    }
                }

                override fun abort() {
                    if (fin) return
                    fin = true
                    runCatching { out.close() }
                    runCatching { c.abort() }
                    runCatching { c.disconnect() }
                    runCatching { delete(path) } // no half file left behind
                }
            }
        } catch (e: Exception) {
            runCatching { c.disconnect() }
            throw if (e is IOException) e else IOException(e.message ?: e.javaClass.simpleName, e)
        }
    }

    @Synchronized
    override fun mkdir(path: String) {
        val c = ctl()
        if (c.makeDirectory(path)) return
        if (!exists(path)) throw IOException("FTP: " + c.replyString.trim())
    }

    @Synchronized
    override fun delete(path: String) {
        val c = ctl()
        if (c.deleteFile(path)) return
        // not a file: a folder, emptied first
        val kids = c.listFiles(path)
        if (kids != null) {
            for (k in kids) {
                if (k == null || k.name == "." || k.name == "..") continue
                delete(join(path, k.name.substringAfterLast('/')))
            }
        }
        if (!c.removeDirectory(path)) throw IOException("FTP: " + c.replyString.trim())
    }

    override fun rename(path: String, newName: String) {
        if (!moveWithin(path, join(parent(path) ?: "/", newName))) throw IOException("cannot rename " + path)
    }

    @Synchronized
    override fun moveWithin(from: String, to: String): Boolean = ctl().rename(from, to)

    @Synchronized
    override fun exists(path: String): Boolean {
        if (path.trim('/').isEmpty()) return true
        val c = ctl()
        val parent = parent(path) ?: "/"
        val name = path.trimEnd('/').substringAfterLast('/')
        val l = c.listFiles(parent) ?: return false
        return l.any { it != null && it.name.substringAfterLast('/') == name }
    }

    override fun localFile(path: String): File? = null

    override fun freeSpace(): Long = -1L

    @Synchronized
    override fun close() {
        val c = main
        main = null
        if (c != null) {
            runCatching { if (c.isConnected) c.logout() }
            runCatching { if (c.isConnected) c.disconnect() }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------------------------
// cloud accounts and the factory
// ---------------------------------------------------------------------------------------------------------------------------------

/** Cloud accounts of the file manager (saved in the app's own preferences). */
object FmAccounts {
    const val WEBDAV = "webdav"
    const val S3 = "s3"

    class Account(
        val id: String,
        val name: String,
        val type: String,
        val url: String,
        val user: String,
        val pass: String,
        /** Accept a certificate nobody vouches for (a NAS at home). */
        val insecure: Boolean,
        /** S3: "region|bucket" (url = endpoint, user = access key, pass = secret key). */
        val extra: String = ""
    )

    private const val PREF = "crsc_fm"

    fun all(ctx: Context): List<Account> {
        val s = ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("accounts", null) ?: return emptyList()
        return runCatching {
            val a = JSONArray(s)
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Account(
                    o.getString("id"), o.optString("n"), o.optString("t", WEBDAV), o.optString("u"),
                    o.optString("l"), o.optString("w"), o.optBoolean("i", false), o.optString("x")
                )
            }
        }.getOrDefault(emptyList())
    }

    fun get(ctx: Context, id: String): Account? = all(ctx).firstOrNull { it.id == id }

    private fun saveAll(ctx: Context, l: List<Account>) {
        val a = JSONArray()
        for (x in l) {
            a.put(JSONObject().put("id", x.id).put("n", x.name).put("t", x.type).put("u", x.url).put("l", x.user).put("w", x.pass).put("i", x.insecure).put("x", x.extra))
        }
        ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("accounts", a.toString()).apply()
    }

    /** Adds the account, or replaces the one with the same id. */
    fun put(ctx: Context, x: Account) {
        val l = all(ctx).toMutableList()
        val i = l.indexOfFirst { it.id == x.id }
        if (i >= 0) l[i] = x else l.add(x)
        saveAll(ctx, l)
    }

    fun remove(ctx: Context, id: String) = saveAll(ctx, all(ctx).filter { it.id != id })
}

/** Opens a storage by its place id: "local:<folder>", "net:<server id>" (SMB / FTP saved in [Net]) or "acc:<account id>". Background thread only. */
object Fm {
    const val LOCAL = "local:"
    const val NET = "net:"
    const val ACC = "acc:"

    fun tmpDir(ctx: Context): File = File(ctx.cacheDir, "fm").also { it.mkdirs() }

    fun open(ctx: Context, id: String): FmFs {
        return when {
            id.startsWith(LOCAL) -> LocalFs(id.substring(LOCAL.length))
            id.startsWith(NET) -> {
                val s = Net.server(ctx, id.substring(NET.length)) ?: throw IOException("server not found")
                if (s.proto == Net.SMB) SmbFs(s) else FtpFs(s)
            }
            id.startsWith(ACC) -> {
                val a = FmAccounts.get(ctx, id.substring(ACC.length)) ?: throw IOException("account not found")
                if (a.type == FmAccounts.S3) {
                    val region = a.extra.substringBefore('|')
                    val bucket = a.extra.substringAfter('|', "")
                    S3Fs(a.url, region, bucket, a.user, a.pass, a.insecure, tmpDir(ctx))
                } else {
                    WebDavFs(a.url, a.user, a.pass, a.insecure, tmpDir(ctx))
                }
            }
            else -> throw IOException("unknown storage")
        }
    }
}
