package app.clearoverlay;

import android.os.ParcelFileDescriptor;

/** File access done by a helper that Shizuku starts as the "shell" user (the user that may open Android/data and Android/obb). */
interface IShellFs {
    /** Shizuku asks for this one to stop the helper (the number is fixed by Shizuku). */
    void destroy() = 16777114;

    /** One line per entry: "d" or "f", size (-1 for a folder), last change, name, separated by tabs. null when the folder cannot be read. */
    String[] list(String dir) = 1;

    boolean exists(String path) = 2;

    boolean mkdirs(String path) = 3;

    /** Deletes a file, or a folder with everything in it. */
    boolean deleteTree(String path) = 4;

    /** Renames / moves inside the same storage. */
    boolean rename(String from, String to) = 5;

    /** mode "r" = read, "w" = create / replace and write. null when it cannot be opened. */
    ParcelFileDescriptor open(String path, String mode) = 6;

    long free(String path) = 7;
}
