# Only framework classes are accessed via reflection; nothing to keep.
-dontwarn **

# LiteRT / TensorFlow Lite uses JNI and looks classes up by name.
-keep class org.tensorflow.lite.** { *; }
-keep class com.google.ai.edge.litert.** { *; }

# Network sources (SMB / FTP): loaded through reflection / service files.
-keep class com.hierynomus.** { *; }
-keep class org.bouncycastle.** { *; }
-keep class net.engio.mbassy.** { *; }
-keep class org.apache.commons.net.** { *; }
-keep class com.rapid7.** { *; }
