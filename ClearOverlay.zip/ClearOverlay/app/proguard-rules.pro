# Only framework classes are accessed via reflection; nothing to keep.
-dontwarn **

# LiteRT / TensorFlow Lite uses JNI and looks classes up by name.
-keep class org.tensorflow.lite.** { *; }
-keep class com.google.ai.edge.litert.** { *; }
