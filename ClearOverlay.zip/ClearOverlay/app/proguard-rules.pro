# Only framework classes are accessed via reflection; nothing to keep.
-dontwarn **
