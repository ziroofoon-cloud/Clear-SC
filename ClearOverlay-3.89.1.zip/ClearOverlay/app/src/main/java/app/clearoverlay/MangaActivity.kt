package app.clearoverlay

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.InputStream
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipFile
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Manga / comic reader for an image folder (opened from the library) or a .cbz / .zip file.
 *  - Scroll: pages one under the other (webtoon style), position remembered.
 *  - Pages: one page at a time with pinch zoom; swipe or tap the screen edges to turn; right-to-left switch for manga.
 * Center tap shows / hides the top bar. Pages are decoded at screen size, so even large scans stay light.
 */
class MangaActivity : Activity() {

    /** One page: a picture file ([uri]), an entry of a .cbz / .zip ([entry]) or a page of a PDF ([pdf] >= 0). */
    private class Page(val uri: Uri?, val entry: String?, val pdf: Int = -1) {
        /** Position in [pages] (set once the list is built); used to find a page's enhanced version. */
        var idx = 0
    }

    private val ui = Handler(Looper.getMainLooper())
    private val pool = Executors.newFixedThreadPool(2)
    private val prefs by lazy { getSharedPreferences("crsc_player", Context.MODE_PRIVATE) }

    private lateinit var content: FrameLayout
    private lateinit var top: LinearLayout
    private lateinit var titleTv: TextView
    private lateinit var progressTv: TextView
    /** Format and size of the opened file, shown after the page number. */
    private var infoExtra = ""
    private lateinit var titlesBox: LinearLayout
    private lateinit var bottomBar: LinearLayout
    private lateinit var pageSeek: SeekBar
    private lateinit var seekLeft: TextView
    private lateinit var seekRight: TextView
    private var seekGuard = false
    private var seekDragging = false
    private var barsOn = true
    private lateinit var modeBtn: TextView
    private lateinit var rtlBtn: TextView
    private lateinit var list: ListView
    private lateinit var zoom: ZoomView
    private lateinit var fxBtn: TextView
    private lateinit var fxPanel: ScrollView
    private var fxPanelBuilt = false
    private var insT = 0      // system bar / camera cut-out sizes, so the panel keeps clear of them
    private var insR = 0
    private var insB = 0
    private var mangaFxSwitch: android.widget.Switch? = null
    private val fx = MangaFx()
    private val onlineCancel = AtomicBoolean(false)
    @Volatile private var onlineBusy = false
    @Volatile private var fxGen = 0
    private val fxApply = Runnable { reloadPages() }

    private var pages: List<Page> = emptyList()
    private var zip: ZipFile? = null
    /** The entries of the open archive by name: names that are not valid UTF-8 would not be found again by getEntry(name). */
    private val zipEntries = HashMap<String, java.util.zip.ZipEntry>()
    private var pdf: PdfRenderer? = null
    private val pdfLock = Any()
    private var histSrc = ""
    private var histRef = ""
    private var key = ""
    private var scrollMode = true
    private var rtl = true
    private var current = 0
    private var screenW = 1080
    private var barBox = 0
    private var fxFailShown = false
    private var screenH = 1920
    private var closed = false
    private var sliding = false

    private val cache = object : LruCache<Int, Bitmap>(96 * 1024 * 1024) {
        override fun sizeOf(key: Int, value: Bitmap): Int = value.byteCount
    }
    private val ratios = HashMap<Int, Float>()

    /** Pages the reader enhanced by hand (smart fix / AI / online): shown instead of the plain page until "Original". */
    private val enhanced = object : LruCache<Int, Bitmap>(128 * 1024 * 1024) {
        override fun sizeOf(key: Int, value: Bitmap): Int = value.byteCount
    }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Cfg.bind(this, "manga")
        Ui.init(this, forceDark = true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        scrollMode = prefs.getBoolean("manga_scroll", true)
        rtl = prefs.getBoolean("manga_rtl", true)
        val b = windowManager.currentWindowMetrics.bounds
        screenW = b.width()
        screenH = b.height()

        content = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        list = ListView(this).apply {
            divider = null
            setBackgroundColor(Color.BLACK)
            isVerticalScrollBarEnabled = false
            visibility = View.GONE
            setOnItemClickListener { _, _, _, _ -> toggleBar() }
            setOnScrollListener(object : AbsListView.OnScrollListener {
                override fun onScrollStateChanged(v: AbsListView, state: Int) {}
                override fun onScroll(v: AbsListView, first: Int, visible: Int, total: Int) {
                    if (scrollMode && pages.isNotEmpty()) {
                        current = first.coerceIn(0, pages.size - 1)
                        paintProgress()
                    }
                }
            })
        }
        content.addView(list, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        zoom = ZoomView(this).apply {
            visibility = View.GONE
            onSwipe = { dir -> turn(if (rtl) dir else -dir) }
            onTap = { x ->
                when {
                    x < 0.3f -> turn(if (rtl) 1 else -1)
                    x > 0.7f -> turn(if (rtl) -1 else 1)
                    else -> toggleBar()
                }
            }
        }
        content.addView(zoom, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        top = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#CC0B1020"))
            setPadding(dp(this@MangaActivity, 10), dp(this@MangaActivity, 2), dp(this@MangaActivity, 4), dp(this@MangaActivity, 2))
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titlesBox = titles
        titleTv = Ui.text(this, "", 14f, Ui.TEXT, true).apply {
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        progressTv = Ui.text(this, "", 11f, Ui.MUTED).apply {
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        titles.addView(titleTv)
        titles.addView(progressTv)
        top.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        modeBtn = barBtn("") { setScrollMode(!scrollMode) }
        rtlBtn = barBtn("") { setRtl(!rtl) }
        fxBtn = barBtn("FX") { setMangaFx(!Cfg.mangaFx) }
        fxBtn.minWidth = dp(this, 34)
        // FX (the switch) and the gear (the settings) are two different things: a gap between them and a clear on / off look for FX
        top.addView(fxBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(this@MangaActivity, 10) })
        top.addView(Icons.button(this, Icons.GEAR, sizeDp = BAR_ICON[Cfg.mangaBar]) { toggleFxPanel() })
        top.addView(Icons.button(this, Icons.CLOUD, sizeDp = BAR_ICON[Cfg.mangaBar]) { showOnlineMenu() })
        top.addView(modeBtn)
        top.addView(rtlBtn)
        top.addView(Icons.button(this, Icons.CLOSE, sizeDp = BAR_ICON[Cfg.mangaBar]) { finish() })
        applyBarSize()
        content.addView(top, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))
        // page slider (like a comic app's page bar): drag or tap the track to jump far; flipped for right-to-left reading
        bottomBar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#CC0B1020"))
            setPadding(dp(this@MangaActivity, 14), dp(this@MangaActivity, 6), dp(this@MangaActivity, 14), dp(this@MangaActivity, 8))
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        seekLeft = Ui.text(this, "1", 13f, Ui.TEXT, true).apply {
            gravity = Gravity.CENTER
            minWidth = dp(this@MangaActivity, 38)
        }
        seekRight = Ui.text(this, "1", 13f, Ui.MUTED, true).apply {
            gravity = Gravity.CENTER
            minWidth = dp(this@MangaActivity, 38)
        }
        pageSeek = SeekBar(this).apply {
            max = 0
            progressTintList = android.content.res.ColorStateList.valueOf(Ui.ACCENT)
            thumbTintList = android.content.res.ColorStateList.valueOf(Ui.ACCENT)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    if (fromUser && !seekGuard) setSeekLabels(p)
                }

                override fun onStartTrackingTouch(s: SeekBar) {
                    seekDragging = true
                }

                override fun onStopTrackingTouch(s: SeekBar) {
                    seekDragging = false
                    jumpTo(s.progress)
                }
            })
        }
        bottomBar.addView(seekLeft)
        bottomBar.addView(pageSeek, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bottomBar.addView(seekRight)
        content.addView(bottomBar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        fxPanel = ScrollView(this).apply {
            visibility = View.GONE
            isClickable = true
            background = Ui.round(Color.parseColor("#F5101522"), dp(this@MangaActivity, 22).toFloat(), Ui.STROKE, dp(this@MangaActivity, 1))
            setPadding(dp(this@MangaActivity, 14), dp(this@MangaActivity, 12), dp(this@MangaActivity, 14), dp(this@MangaActivity, 12))
        }
        content.addView(
            fxPanel,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (screenH * 0.58f).toInt(), Gravity.BOTTOM).apply {
                setMargins(dp(this@MangaActivity, 8), 0, dp(this@MangaActivity, 8), dp(this@MangaActivity, 8))
            }
        )
        layoutFxPanel()
        setContentView(content)
        content.setOnApplyWindowInsetsListener { _, ins ->
            val hh = windowManager.currentWindowMetrics.bounds.height()
            val ww = windowManager.currentWindowMetrics.bounds.width()
            if (ww != screenW) {
                screenW = ww
                applyBarSize()
            }
            val ft = Edge.full(this, ins)
            val ti = Edge.insets(this, ins, 0, dp(this, 70) + ft[1])
            val bi = Edge.insets(this, ins, hh - dp(this, 110) - ft[3], hh)
            top.setPadding(dp(this, 10) + ti[0], dp(this, 2) + ti[1], dp(this, 4) + ti[2], dp(this, 2))
            bottomBar.setPadding(dp(this, 14) + bi[0], dp(this, 6), dp(this, 14) + bi[2], dp(this, 8) + bi[3])
            if (insT != ft[1] || insR != ft[2] || insB != ft[3]) {
                insT = ft[1]
                insR = ft[2]
                insB = ft[3]
                layoutFxPanel()
            }
            ins
        }
        paintButtons()
        paintFx()
        load()
    }

    /** Sizes of the top bar buttons for the three choices (small / medium / large) of the setting in the manga panel. */
    private val BAR_ICON = intArrayOf(46, 56, 66)
    private val BAR_TEXT = intArrayOf(20, 24, 28)
    private val BAR_FX = intArrayOf(16, 18, 21)

    /** Applies the chosen size to every button of the top bar (also while the reader is open). */
    private fun applyBarSize() {
        val n = Cfg.mangaBar.coerceIn(0, 2)
        val gap = dp(this, 4)
        // six buttons (the FX chip counts 1.3) must leave room for the title: on a narrow screen the buttons shrink instead of
        // pushing the title away and the last button off the screen
        val avail = screenW - dp(this, 14) - dp(this, 100) - gap * 6 - dp(this, 8)
        val s = minOf(dp(this, BAR_ICON[n]), (avail / 6.3f).toInt()).coerceAtLeast(dp(32))
        barBox = s
        val r = dp(this, 12).toFloat()
        for (i in 0 until top.childCount) {
            val v = top.getChildAt(i)
            when {
                v is ImageView -> {
                    // every button of the bar is the same rounded chip (the gear / cloud / close icons had none, the others had)
                    v.background = Ui.round(Ui.CHIP, r)
                    v.layoutParams = LinearLayout.LayoutParams(s, s).apply { marginStart = gap }
                }
                v === fxBtn -> {
                    fxBtn.textSize = BAR_FX[n].toFloat()
                    fxBtn.minWidth = 0
                    fxBtn.minHeight = 0
                    fxBtn.layoutParams = LinearLayout.LayoutParams((s * 1.3f).toInt(), s).apply {
                        marginStart = gap
                        marginEnd = dp(this@MangaActivity, 8)
                    }
                }
                // the page-mode and reading-direction buttons: the same square chip as the icon buttons next to them
                v is TextView && v !== titleTv && v !== progressTv -> {
                    v.minWidth = 0
                    v.minHeight = 0
                    v.background = Ui.round(Ui.CHIP, r)
                    v.layoutParams = LinearLayout.LayoutParams(s, s).apply { marginStart = gap }
                }
            }
        }
        paintButtons()
        top.requestLayout()
    }

    // top buttons: their size follows the setting in the manga panel (Panel > Top bar size)
    private fun barBtn(label: String, onClick: () -> Unit) = Ui.text(this, label, 15f, Ui.ACCENT, true).apply {
        gravity = Gravity.CENTER
        minHeight = dp(this@MangaActivity, 30)
        setPadding(dp(this@MangaActivity, 5), dp(this@MangaActivity, 3), dp(this@MangaActivity, 5), dp(this@MangaActivity, 3))
        setOnClickListener { onClick() }
    }

    private fun paintButtons() {
        // the two chips next to the icon buttons use the same line icons (they were text glyphs: ≡ ▭ ⇠ ⇢)
        val box = if (barBox > 0) barBox else dp(this, BAR_ICON[Cfg.mangaBar.coerceIn(0, 2)])
        val boxDp = (box / resources.displayMetrics.density).toInt()
        val icDp = (boxDp - 18).coerceAtLeast(14)
        Icons.glyphCentered(modeBtn, if (scrollMode) Icons.STRIP else Icons.PAGE, Ui.ACCENT, icDp, boxDp)
        Icons.glyphCentered(rtlBtn, if (rtl) Icons.ARROW_L else Icons.ARROW_R, Ui.ACCENT, icDp, boxDp)
        rtlBtn.alpha = if (scrollMode) 0.4f else 1f
        if (::pageSeek.isInitialized) paintSlider()
    }

    private fun paintFx() {
        mangaFxSwitch?.let { if (it.isChecked != Cfg.mangaFx) it.isChecked = Cfg.mangaFx }
        val r = dp(this, 12).toFloat()
        fxBtn.alpha = 1f
        if (Cfg.mangaFx) {
            fxBtn.background = Ui.gradient(r)
            fxBtn.setTextColor(Ui.BG)
        } else {
            fxBtn.background = Ui.round(Ui.CHIP, r)
            fxBtn.setTextColor(Ui.MUTED)
        }
    }

    private fun setMangaFx(on: Boolean) {
        if (Cfg.mangaFx == on) return
        Cfg.mangaFx = on
        Cfg.save(this)
        fxFailShown = false
        paintFx()
        scheduleReload(0)
    }

    /** Panel size (Settings chips at the top of the panel): small / medium / large. */
    private fun layoutFxPanel() {
        val sz = Cfg.panelSize.coerceIn(0, 2)
        val lp = fxPanel.layoutParams as FrameLayout.LayoutParams
        val m = dp(this, 8)
        if (screenW > screenH) {
            // landscape: the panel sits at the right edge, as tall as the screen allows (a wide, short panel in the middle of the page looked lost)
            lp.width = (screenW * floatArrayOf(0.40f, 0.52f, 0.66f)[sz]).toInt()
            lp.height = ViewGroup.LayoutParams.MATCH_PARENT
            lp.gravity = Gravity.END
            lp.setMargins(m, insT + m, insR + m, insB + m)
        } else {
            lp.height = (screenH * floatArrayOf(0.38f, 0.58f, 0.80f)[sz]).toInt()
            lp.width = if (sz == 0) (screenW * 0.84f).toInt() else ViewGroup.LayoutParams.MATCH_PARENT
            lp.gravity = if (sz == 0) Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL else Gravity.BOTTOM
            lp.setMargins(m, 0, m, m + insB)
        }
        fxPanel.layoutParams = lp
    }

    /** Keeps a dragged settings panel inside the window. */
    private fun clampFxPanel() {
        val par = fxPanel.parent as? View ?: return
        if (fxPanel.width <= 0) return
        val l = fxPanel.left.toFloat()
        val t = fxPanel.top.toFloat()
        fxPanel.translationX = fxPanel.translationX.coerceIn(-l, (par.width - fxPanel.right).toFloat().coerceAtLeast(-l))
        fxPanel.translationY = fxPanel.translationY.coerceIn(-t, (par.height - fxPanel.bottom).toFloat().coerceAtLeast(-t))
    }

    /** Top of the reader's settings panel, grouped like the player's: effect / screen effect / panel. */
    private fun buildMangaHeader(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(
            panelHeader(this, getString(R.string.manga_panel_title) + " · " + Cfg.sectionLabel(this), fxPanel, { clampFxPanel() }, { fxPanel.visibility = View.GONE }) {
                Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
            }
        )
        fun gap(v: Int) = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(this@MangaActivity, v) }

        col.addView(panelSection(this, getString(R.string.panel_sec_effect)), gap(14))
        val fxSw = panelSwitch(this, getString(R.string.manga_fx_switch), Cfg.mangaFx) { setMangaFx(it) }
        mangaFxSwitch = fxSw
        col.addView(fxSw, gap(10))
        col.addView(
            panelSwitch(this, getString(R.string.player_fx_pin_switch), Cfg.fxPinned) {
                Cfg.fxPinned = it
                Cfg.save(this)
                setBars(barsOn)
            },
            gap(10)
        )

        col.addView(panelSection(this, getString(R.string.panel_sec_overlay)), gap(16))
        col.addView(
            panelSwitch(this, getString(R.string.player_pause_overlay_switch), Cfg.pauseOverlayInPlayer) {
                Cfg.pauseOverlayInPlayer = it
                Cfg.save(this)
                OverlayService.instance?.pauseForPlayer(it)
            },
            gap(10)
        )
        col.addView(Ui.text(this, getString(R.string.player_pause_overlay_hint), 12f, Ui.MUTED), gap(2))

        col.addView(panelSection(this, getString(R.string.panel_sec_panel)), gap(16))
        col.addView(panelSizeRow(this) {
            layoutFxPanel()
            fxPanel.post { clampFxPanel() }
        }, gap(10))
        col.addView(Ui.text(this, getString(R.string.panel_lock_hint), 12f, Ui.MUTED), gap(6))
        col.addView(Ui.text(this, getString(R.string.manga_bar_size), 12f, Ui.MUTED), gap(12))
        col.addView(chipRow(this, listOf(getString(R.string.panel_size_small), getString(R.string.panel_size_medium), getString(R.string.panel_size_large)), Cfg.mangaBar) {
            Cfg.mangaBar = it
            Cfg.save(this)
            applyBarSize()
        }, gap(6))
        col.addView(panelSection(this, getString(R.string.player_effects_label)), gap(16))
        return col
    }

    private fun toggleFxPanel() {
        if (fxPanel.visibility == View.VISIBLE) {
            fxPanel.visibility = View.GONE
            return
        }
        if (!fxPanelBuilt) {
            fxPanelBuilt = true
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            box.addView(buildMangaHeader())
            box.addView(
                buildControls(
                    this,
                    onAdjust = { active -> fxPanel.animate().alpha(if (active) 0.35f else 1f).setDuration(120).start() },
                    inPlayer = true,
                    sourceScale = { 1.5f }
                ) { if (Cfg.mangaFx) scheduleReload(350) },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )
            fxPanel.addView(box, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        fxPanel.visibility = View.VISIBLE // opening the settings does not switch FX on; the FX switch does
    }

    /** Effects settings changed: pages are decoded and processed again (a short delay while a slider is moving). */
    private fun scheduleReload(delayMs: Long) {
        fxGen++
        ui.removeCallbacks(fxApply)
        ui.postDelayed(fxApply, delayMs)
    }

    private fun reloadPages() {
        if (closed || pages.isEmpty()) return
        cache.evictAll()
        if (scrollMode) {
            adapter.notifyDataSetChanged()
        } else {
            zoom.setBitmap(null)
            showPage(current)
        }
    }

    /** A decoded page, run through the picture effects when they are on for the reader. */
    private fun fetch(p: Page, fitW: Int): Bitmap? {
        enhanced.get(p.idx)?.let { if (!it.isRecycled) return it }
        val g0 = fxGen
        val b = try {
            decode(p, fitW)
        } catch (t: Throwable) {
            if (!shownDecodeErr && !closed) {
                shownDecodeErr = true
                val msg = t.javaClass.simpleName + ": " + (t.message ?: "")
                ui.post { if (!closed) Toast.makeText(this, getString(R.string.manga_page_err_fmt, p.idx + 1, msg), Toast.LENGTH_LONG).show() }
            }
            null
        } ?: return null
        if (!Cfg.mangaFx) return b
        var out = runCatching { fx.process(b) }.getOrNull()
        // a failed or too slow first try is repeated once (the effect renderer rebuilds itself); only then the plain page is shown
        if (out == null && g0 == fxGen) out = runCatching { fx.process(b) }.getOrNull()
        if (out == null) {
            if (!fxFailShown) {
                fxFailShown = true
                ui.post { if (!closed) Toast.makeText(this, R.string.manga_fx_failed, Toast.LENGTH_LONG).show() }
            }
            return b
        }
        if (g0 != fxGen) return null // settings changed meanwhile: this result is stale, the page is rebuilt anyway
        return out
    }

    // ---- online enhance of the current page (cloud, paid) ------------------------------------------

    /** Everything the photo viewer's Enhance button offers, for the current page. */
    private fun showOnlineMenu() {
        if (onlineBusy) {
            onlineCancel.set(true)
            return
        }
        val items = arrayOf(
            getString(R.string.enh_auto),
            getString(R.string.enh_ai_fmt, if (Cfg.autoMode) getString(R.string.auto_word) else AiSr.activeLabel(this)),
            getString(R.string.enh_models),
            getString(R.string.online_photo),
            getString(R.string.online_text),
            getString(R.string.enh_original),
            getString(R.string.manga_save_page),
            getString(R.string.online_settings)
        )
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.manga_enhance_title) + "  (" + getString(R.string.manga_progress_fmt, current + 1, pages.size) + ")")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> enhanceCurrent(0)
                    1 -> if (AiSr.hasModel(this)) enhanceCurrent(1) else showCatalogDialog()
                    2 -> showModelsDialog()
                    3 -> enhanceCurrent(2)
                    4 -> enhanceCurrent(3)
                    5 -> restoreOriginalPage()
                    6 -> savePage()
                    else -> Online.showSettings(this)
                }
            }
            .show()
    }

    /** Back to the plain (decoded + FX) version of the current page. */
    private fun restoreOriginalPage() {
        val idx = current
        if (enhanced.get(idx) == null) {
            Toast.makeText(this, R.string.enh_is_original, Toast.LENGTH_SHORT).show()
            return
        }
        enhanced.remove(idx)
        cache.remove(idx)
        ratios.remove(idx)
        if (scrollMode) {
            adapter.notifyDataSetChanged()
        } else {
            zoom.setBitmap(null)
            showPage(idx)
        }
    }

    /**
     * [what]: 0 = smart fix, 1 = offline AI upscale, 2 = online photo x4, 3 = online clearer writing x2.
     * Runs on a worker thread; the top bar shows the progress, the cloud button cancels.
     */
    private fun enhanceCurrent(what: Int) {
        if (what >= 2 && !Online.hasKey(this)) {
            Toast.makeText(this, getString(R.string.online_need_key), Toast.LENGTH_LONG).show()
            Online.showSettings(this)
            return
        }
        if (onlineBusy || pages.isEmpty()) return
        val idx = current
        val page = pages[idx]
        onlineBusy = true
        onlineCancel.set(false)
        progressTv.text = "☁ " + getString(R.string.online_working_fmt, "")
        Thread {
            var err: String? = null
            var out: Bitmap? = null
            var same = false
            try {
                val src = enhanced.get(idx)?.takeIf { !it.isRecycled } ?: decode(page, 0)
                if (src != null) {
                    when (what) {
                        0 -> {
                            val r = Enhance.auto(src)
                            if (r === src) same = true else out = r
                        }
                        1 -> {
                            if (Cfg.autoMode) AiSr.setActive(this, Auto.aiModel(this, src.width, src.height))
                            out = AiSr.upscale(
                                this, src,
                                { pr -> ui.post { if (!closed && onlineBusy) progressTv.text = getString(R.string.ai_progress_fmt, pr) } },
                                onlineCancel, maxOutPx = 16_000_000L
                            )
                        }
                        else -> {
                            out = Online.enhance(this, src, if (what == 3) Online.TEXT else Online.PHOTO, onlineCancel) { st ->
                                ui.post { if (!closed && onlineBusy) progressTv.text = "☁ " + getString(R.string.online_working_fmt, st) }
                            }
                        }
                    }
                }
            } catch (t: Throwable) {
                err = t.javaClass.simpleName + ": " + (t.message ?: "") + "\n" + t.stackTrace.take(4).joinToString("\n") { "  at " + it.fileName + ":" + it.lineNumber }
            }
            val e = err
            val o = out
            ui.post {
                onlineBusy = false
                if (closed) return@post
                paintProgress()
                when {
                    e != null -> if (what == 1) Toast.makeText(this, getString(R.string.ai_error_fmt, e), Toast.LENGTH_LONG).show() else Online.showError(this, e)
                    same -> Toast.makeText(this, R.string.enh_nochange, Toast.LENGTH_SHORT).show()
                    o == null -> Toast.makeText(this, getString(R.string.ai_cancelled), Toast.LENGTH_SHORT).show()
                    else -> {
                        enhanced.put(idx, o)
                        cache.put(idx, o)
                        ratios[idx] = o.height.toFloat() / o.width
                        if (scrollMode) adapter.notifyDataSetChanged() else if (current == idx) zoom.setBitmap(o)
                        Toast.makeText(this, getString(if (what == 1) R.string.ai_done else if (what == 0) R.string.enh_auto_done else R.string.online_done), Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }.start()
    }

    // ---- AI models (offline upscaler) --------------------------------------------------------------

    private fun showModelsDialog() {
        if (onlineBusy) { Toast.makeText(this, R.string.manga_model_busy, Toast.LENGTH_SHORT).show(); return }
        val list = AiSr.list(this)
        val active = AiSr.activeId(this)
        val labels = ArrayList<String>()
        for (m in list) labels.add((if (m.id == active) "✓  " else "     ") + m.label)
        labels.add(getString(R.string.model_catalog))
        labels.add(getString(R.string.model_add_file))
        labels.add(getString(R.string.model_add_link))
        labels.add(getString(R.string.model_export))
        if (list.any { !it.builtin }) labels.add(getString(R.string.model_remove))
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.model_title))
            .setItems(labels.toTypedArray()) { _, which ->
                when {
                    which < list.size -> {
                        AiSr.setActive(this, list[which].id)
                        Toast.makeText(this, getString(R.string.model_selected_fmt, list[which].label), Toast.LENGTH_SHORT).show()
                    }
                    which == list.size -> showCatalogDialog()
                    which == list.size + 1 -> {
                        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
                        @Suppress("DEPRECATION")
                        startActivityForResult(i, REQ_MODEL)
                    }
                    which == list.size + 2 -> showModelLinkDialog()
                    which == list.size + 3 -> ModelFiles.start(this)
                    else -> showRemoveModel()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showCatalogDialog() {
        if (onlineBusy) { Toast.makeText(this, R.string.manga_model_busy, Toast.LENGTH_SHORT).show(); return }
        val cat = AiSr.CATALOG
        val labels = cat.map { c ->
            val state = if (AiSr.isInstalled(this, c)) "✓ " else "⬇ "
            val size = if (c.sizeKb >= 1000) "%.1f MB".format(c.sizeKb / 1000f) else "${c.sizeKb} KB"
            state + c.label + "  (" + size + ")\n    " + getString(c.descRes)
        }
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.model_catalog))
            .setItems(labels.toTypedArray()) { _, which ->
                val c = cat[which]
                runModelJob({ pr -> AiSr.installCatalog(this, c, pr) }, c.label)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showRemoveModel() {
        val removable = AiSr.list(this).filter { !it.builtin }
        if (removable.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.model_remove))
            .setItems(removable.map { it.label }.toTypedArray()) { _, which ->
                AiSr.remove(this, removable[which].id)
                Toast.makeText(this, getString(R.string.model_removed_fmt, removable[which].label), Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showModelLinkDialog() {
        val input = android.widget.EditText(this).apply {
            hint = "https://…/model.tflite"
            setSingleLine()
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val pad = dp(this, 20)
        val box = FrameLayout(this).apply { setPadding(pad, dp(this@MangaActivity, 8), pad, 0) }
        box.addView(input, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.model_add_link))
            .setView(box)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val t = input.text.toString().trim()
                if (t.startsWith("http://") || t.startsWith("https://")) runModelJob({ pr -> AiSr.download(this, t, null, pr) }, "")
                else Toast.makeText(this, R.string.player_error, Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (ModelFiles.handle(this, req, res, data)) return
        val u = data?.data
        if (req == REQ_MODEL && res == RESULT_OK && u != null) {
            val name = (u.lastPathSegment ?: "model").substringAfterLast('/').substringAfterLast(':')
            runModelJob({ _ -> AiSr.importModel(this, u, name) }, "")
        }
    }

    /** Installs a model on a worker thread; [job] returns the new model's id. [label] is shown in the "added" toast (empty = use the id). */
    private fun runModelJob(job: ((Int) -> Unit) -> String, label: String) {
        // job gets a progress callback taking 0..100
        onlineBusy = true
        onlineCancel.set(false)
        progressTv.text = getString(R.string.ai_downloading_fmt, 0)
        Thread {
            var err: String? = null
            var id: String? = null
            try {
                id = job { pr -> ui.post { if (!closed && onlineBusy) progressTv.text = getString(R.string.ai_downloading_fmt, pr) } }
            } catch (t: Throwable) {
                err = t.message ?: t.javaClass.simpleName
            }
            val e = err
            val added = id
            ui.post {
                onlineBusy = false
                if (closed) return@post
                paintProgress()
                if (e != null || added == null) {
                    Toast.makeText(this, getString(R.string.ai_download_fail_fmt, e ?: "?"), Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, getString(R.string.model_added_fmt, label.ifEmpty { added }), Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    /** Writes the page as it is shown now (with FX / online result) to Pictures/ClearOverlay. */
    private fun savePage() {
        val idx = current
        val b = cache.get(idx)
        if (b == null) {
            Toast.makeText(this, getString(R.string.save_fail), Toast.LENGTH_SHORT).show()
            return
        }
        val bookTitle = titleTv.text.toString()
        Thread {
            var ok = false
            runCatching {
                val name = Stamp.name(bookTitle.ifBlank { "manga" }, "p" + (idx + 1), b.width.toString() + "x" + b.height, Stamp.modeName(Cfg.mode)) + ".jpg"
                val values = android.content.ContentValues().apply {
                    put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ClearOverlay")
                    put(android.provider.MediaStore.Images.Media.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: error("insert")
                try {
                    contentResolver.openOutputStream(uri)!!.use { b.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                    values.clear()
                    values.put(android.provider.MediaStore.Images.Media.IS_PENDING, 0)
                    contentResolver.update(uri, values, null, null)
                    ok = true
                } catch (t: Throwable) {
                    runCatching { contentResolver.delete(uri, null, null) }
                }
            }
            ui.post { if (!closed) Toast.makeText(this, getString(if (ok) R.string.save_ok else R.string.save_fail), Toast.LENGTH_SHORT).show() }
        }.start()
    }

    private fun toggleBar() = setBars(!barsOn)

    /** Shows / hides the bars. With "keep the FX button on screen" on, only the FX button stays when they hide. */
    private fun setBars(on: Boolean) {
        barsOn = on
        val pin = Cfg.fxPinned
        bottomBar.visibility = if (on) View.VISIBLE else View.GONE
        top.visibility = if (on || pin) View.VISIBLE else View.GONE
        for (i in 0 until top.childCount) {
            val ch = top.getChildAt(i)
            ch.visibility = when {
                on || ch === fxBtn -> View.VISIBLE
                !pin -> View.VISIBLE
                ch === titlesBox -> View.INVISIBLE
                else -> View.GONE
            }
        }
        top.setBackgroundColor(if (on) Color.parseColor("#CC0B1020") else Color.TRANSPARENT)
        paintFx()
    }

    // ---- loading the page list -------------------------------------------------------------------

    private fun load() {
        val u = intent?.data
        val bucket = intent?.getLongExtra(EXTRA_BUCKET, Long.MIN_VALUE) ?: Long.MIN_VALUE
        val tree = intent?.getStringExtra(EXTRA_TREE)
        titleTv.text = intent?.getStringExtra(EXTRA_NAME) ?: ""
        if (u != null) runCatching {
            contentResolver.query(u, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME, android.provider.OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val nm = c.getString(0) ?: ""
                    val sz = c.getLong(1)
                    if (titleTv.text.isEmpty() && nm.isNotEmpty()) titleTv.text = nm.substringBeforeLast('.')
                    val ext = nm.substringAfterLast('.', "").uppercase()
                    infoExtra = listOf(ext, if (sz > 0) String.format("%.1f MB", sz / 1048576.0) else "").filter { it.isNotEmpty() }.joinToString(" · ")
                }
            }
        }
        Thread {
            var err: String? = null
            var out: List<Page> = emptyList()
            var outNames: List<String> = emptyList()
            var k = ""
            try {
                if (u != null) {
                    val f: File
                    if (u.scheme == Net.SCHEME) {
                        // network file: downloaded once into the cache (with progress), so opening it again is instant
                        var lastT = 0L
                        f = Net.download(this, u, { done, total ->
                            val now = System.currentTimeMillis()
                            if (now - lastT > 300) {
                                lastT = now
                                val t = if (total > 0) "${done shr 20} / ${total shr 20} MB" else "${done shr 20} MB"
                                ui.post { if (!closed) progressTv.text = getString(R.string.manga_dl_fmt, t) }
                            }
                        }, { !closed })
                    } else {
                        f = File(cacheDir, "manga_src.bin")
                        // the archive is copied to the cache once; opening the same file again reuses that copy
                        val size = runCatching { contentResolver.openAssetFileDescriptor(u, "r")?.use { it.length } }.getOrNull() ?: -1L
                        val stamp = u.toString() + "|" + size
                        if (!(f.exists() && size > 0 && f.length() == size && prefs.getString("manga_src_stamp", "") == stamp)) {
                            runCatching { prefs.edit().remove("manga_src_stamp").apply() }
                            ui.post { if (!closed) progressTv.text = getString(R.string.manga_preparing) }
                            (contentResolver.openInputStream(u) ?: error("cannot open")).use { ins -> f.outputStream().use { ins.copyTo(it) } }
                            if (size > 0) prefs.edit().putString("manga_src_stamp", stamp).apply()
                        }
                    }
                    srcFile = f
                    val head = ByteArray(8)
                    f.inputStream().use { it.read(head) }
                    val isPdf = head[0] == 0x25.toByte() && head[1] == 0x50.toByte() && head[2] == 0x44.toByte() && head[3] == 0x46.toByte()
                    val isZip = head[0] == 0x50.toByte() && head[1] == 0x4B.toByte()
                    val isRar = head[0] == 0x52.toByte() && head[1] == 0x61.toByte() && head[2] == 0x72.toByte()
                    val is7z = head[0] == 0x37.toByte() && head[1] == 0x7A.toByte()
                    when {
                        isPdf -> {
                            val r = PdfRenderer(ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY))
                            pdf = r
                            out = List(r.pageCount) { Page(null, null, it) }
                            k = "pdf_" + u.toString().hashCode()
                        }
                        isZip -> {
                          try {
                            val z = try {
                                ZipFile(f)
                            } catch (e: Exception) {
                                ZipFile(f, java.nio.charset.Charset.forName("ISO-8859-1")) // names that are not UTF-8
                            }
                            zip = z
                            val names = ArrayList<String>()
                            val others = ArrayList<String>()
                            val rest = ArrayList<String>()
                            var total = 0
                            val en = z.entries()
                            while (en.hasMoreElements()) {
                                val e = en.nextElement()
                                val n = e.name
                                val l = n.lowercase()
                                if (e.isDirectory || n.contains("__MACOSX")) continue
                                zipEntries[n] = e
                                total++
                                val base = l.substringAfterLast('/').substringAfterLast('\\')
                                if (base.startsWith(".") || base == "thumbs.db") continue
                                // pictures in any sub-folder count (chapter folders inside the archive are fine)
                                if (base.endsWith(".jpg") || base.endsWith(".jpeg") || base.endsWith(".jfif") || base.endsWith(".png") ||
                                    base.endsWith(".webp") || base.endsWith(".gif") || base.endsWith(".bmp") ||
                                    base.endsWith(".avif") || base.endsWith(".heic") || base.endsWith(".heif")
                                ) names.add(n) else {
                                    if (others.size < 10) others.add(n)
                                    if ((e.size > 2048L || e.size < 0L) && rest.size < 20000) rest.add(n)
                                }
                            }
                            // files whose name has no picture extension (or an odd one): keep those that really are pictures
                            for (rn in rest) {
                                if (closed) break
                                val e = zipEntries[rn] ?: continue
                                val hd = ByteArray(16)
                                val n = runCatching { z.getInputStream(e).use { it.read(hd) } }.getOrDefault(-1)
                                if (n >= 4 && looksLikeImage(hd)) names.add(rn)
                            }
                            if (names.isEmpty()) {
                                error(getString(R.string.manga_zip_noimages_fmt, total, others.joinToString("\n  ", "\n  ")))
                            }
                            names.sortWith { a, b -> pageOrder(a, b) }
                            out = names.map { Page(null, it) }
                            outNames = names
                            k = "cbz_" + u.toString().hashCode()
                          } catch (t: Throwable) {
                            // the archive could not be opened as a random-access zip (odd zip64 / damaged directory): read it from the start instead
                            if (closed) throw t
                            runCatching { zip?.close() }
                            zip = null
                            zipEntries.clear()
                            val dir = File(cacheDir, "manga_rar")
                            dir.deleteRecursively()
                            dir.mkdirs()
                            val files = ArrayList<Pair<String, File>>()
                            java.util.zip.ZipInputStream(f.inputStream().buffered(), java.nio.charset.Charset.forName("ISO-8859-1")).use { zi ->
                                var n = 0
                                while (!closed) {
                                    val e = zi.nextEntry ?: break
                                    if (e.isDirectory) continue
                                    val nm = e.name.replace('\\', '/')
                                    val base = nm.substringAfterLast('/').lowercase()
                                    if (nm.contains("__MACOSX") || base.startsWith(".")) continue
                                    val known = base.endsWith(".jpg") || base.endsWith(".jpeg") || base.endsWith(".jfif") ||
                                        base.endsWith(".png") || base.endsWith(".webp") || base.endsWith(".gif") || base.endsWith(".bmp")
                                    val target = File(dir, "p" + (n++) + "." + (if (known) base.substringAfterLast('.') else "img"))
                                    target.outputStream().use { o -> zi.copyTo(o) }
                                    if (!known) {
                                        // an unknown name: keep it only when the content is a picture
                                        val hd = ByteArray(16)
                                        val rn = target.inputStream().use { it.read(hd) }
                                        if (rn < 12 || !looksLikeImage(hd)) {
                                            target.delete()
                                            continue
                                        }
                                    }
                                    files.add(Pair(nm, target))
                                    if (n % 10 == 0) ui.post { if (!closed) progressTv.text = getString(R.string.manga_preparing) + " " + n }
                                }
                            }
                            if (files.isEmpty()) throw t
                            files.sortWith { x, y -> pageOrder(x.first, y.first) }
                            out = files.map { Page(Uri.fromFile(it.second), null) }
                            outNames = files.map { it.first }
                            k = "cbz_" + u.toString().hashCode()
                          }
                        }
                        isRar -> run rarBlock@{
                            // a .cbr (or a RAR renamed to .cbz): the pictures are unpacked once into the cache
                            val dir = File(cacheDir, "manga_rar")
                            dir.deleteRecursively()
                            dir.mkdirs()
                            val files = ArrayList<Pair<String, File>>()
                            if (Rar5.isRar5(head)) {
                                // the new RAR format: files stored without compression can be read; compressed ones cannot
                                var n5 = 0
                                var packedPics = 0
                                var total5 = 0
                                val up = Rar5Unpacker()
                                var solidBroken = false
                                for (en in Rar5.list(f)) {
                                    if (closed) break
                                    if (en.dir) continue
                                    total5++
                                    val nm = en.name.replace('\\', '/')
                                    val base = nm.substringAfterLast('/').lowercase()
                                    val pic = !base.startsWith(".") && (base.endsWith(".jpg") || base.endsWith(".jpeg") || base.endsWith(".jfif") || base.endsWith(".png") ||
                                        base.endsWith(".webp") || base.endsWith(".gif") || base.endsWith(".bmp") || base.endsWith(".avif"))
                                    // a solid archive must also unpack the other files: later ones continue from their data
                                    if (!pic && !(en.solid && en.method != 0)) continue
                                    if (en.method == 0) {
                                        if (!pic) continue
                                        val target = File(dir, "p" + (n5++) + "." + base.substringAfterLast('.'))
                                        Rar5.extractStored(f, en, target)
                                        files.add(Pair(nm, target))
                                    } else {
                                        val data = if (solidBroken) null else Rar5.unpack(f, en, up)
                                        if (data == null) {
                                            if (en.solid) solidBroken = true
                                            if (pic) packedPics++
                                            continue
                                        }
                                        if (!pic) continue
                                        val target = File(dir, "p" + (n5++) + "." + base.substringAfterLast('.'))
                                        target.outputStream().use { it.write(data) }
                                        files.add(Pair(nm, target))
                                    }
                                    if (n5 % 10 == 0) ui.post { if (!closed) progressTv.text = getString(R.string.manga_preparing) + " " + n5 }
                                }
                                if (files.isEmpty()) error(getString(if (packedPics > 0) R.string.manga_rar5_unsupported else R.string.manga_zip_noimages_fmt, total5, "rar5"))
                                if (packedPics > 0) ui.post { Toast.makeText(this, getString(R.string.manga_pages_failed_fmt, packedPics), Toast.LENGTH_LONG).show() }
                                files.sortWith { x, y -> pageOrder(x.first, y.first) }
                                out = files.map { Page(Uri.fromFile(it.second), null) }
                                outNames = files.map { it.first }
                                k = "cbz_" + u.toString().hashCode()
                                return@rarBlock
                            }
                            val arc = try { com.github.junrar.Archive(f) } catch (t: Throwable) { error(getString(R.string.manga_rar5_unsupported) + "\n" + (t.message ?: "")) }
                            var a0n = 0
                            arc.use { a ->
                                a0n = a.fileHeaders.size
                                var n = 0
                                for (fh in a.fileHeaders) {
                                    if (closed) break
                                    if (fh.isDirectory) continue
                                    val nm = fh.fileName.replace('\\', '/')
                                    val base = nm.substringAfterLast('/').lowercase()
                                    if (base.startsWith(".") || !(base.endsWith(".jpg") || base.endsWith(".jpeg") || base.endsWith(".jfif") || base.endsWith(".png") ||
                                            base.endsWith(".webp") || base.endsWith(".gif") || base.endsWith(".bmp"))) continue
                                    val target = File(dir, "p" + (n++) + "." + base.substringAfterLast('.'))
                                    target.outputStream().use { o -> a.extractFile(fh, o) }
                                    files.add(Pair(nm, target))
                                    if (n % 10 == 0) ui.post { if (!closed) progressTv.text = getString(R.string.manga_preparing) + " " + n }
                                }
                            }
                            if (files.isEmpty()) error(getString(R.string.manga_zip_noimages_fmt, a0n, "rar"))
                            files.sortWith { x, y -> pageOrder(x.first, y.first) }
                            out = files.map { Page(Uri.fromFile(it.second), null) }
                            outNames = files.map { it.first }
                            k = "cbz_" + u.toString().hashCode()
                        }
                        is7z -> error(getString(R.string.manga_rar_unsupported))
                        else -> error(getString(R.string.manga_unknown_file))
                    }
                    histSrc = "file"
                    histRef = u.toString()
                    if (titleTv.text.isEmpty()) ui.post { titleTv.text = (u.lastPathSegment ?: "").substringAfterLast('/').substringAfterLast(':') }
                } else if (tree != null) {
                    out = Media.mangaPagesTree(this, Uri.parse(tree)).map { Page(it, null) }
                    k = "bt_" + tree.hashCode()
                    histSrc = "tree"
                    histRef = tree
                } else if (bucket != Long.MIN_VALUE) {
                    out = Media.mangaPages(this, bucket).map { Page(it, null) }
                    k = "bk_$bucket"
                    histSrc = "bucket"
                    histRef = bucket.toString()
                }
            } catch (t: Throwable) {
                err = t.message ?: t.javaClass.simpleName
            }
            val e = err
            val result = out
            val kk = k
            val names = outNames
            ui.post {
                if (closed) return@post
                if (e != null || result.isEmpty()) {
                    // a dialog (not a toast that disappears): the text can be copied and sent
                    val text = getString(R.string.manga_empty) + (if (e != null) "\n\n$e" else "") + "\n\n" + (intent?.data?.toString() ?: "")
                    AlertDialog.Builder(this)
                        .setMessage(text)
                        .setPositiveButton(android.R.string.ok) { _, _ -> finish() }
                        .setNeutralButton(android.R.string.copy) { _, _ ->
                            (getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("error", text))
                            finish()
                        }
                        .setOnCancelListener { finish() }
                        .show()
                    return@post
                }
                // an archive that holds several books (one folder per volume): ask which one to read
                val vols = if (names.size == result.size) volumesOf(names) else emptyList()
                if (vols.size > 1) {
                    val labels = ArrayList<String>()
                    labels.add(getString(R.string.manga_all_pages_fmt, result.size))
                    for (v in vols) labels.add((if (v.first.isEmpty()) "…" else v.first) + "  (" + v.second.size + ")")
                    val last = prefs.getInt("manga_vol_" + kk.hashCode(), 0).coerceIn(0, labels.size - 1)
                    AlertDialog.Builder(this)
                        .setTitle(R.string.manga_pick_volume)
                        .setSingleChoiceItems(labels.toTypedArray(), last) { d, which ->
                            d.dismiss()
                            prefs.edit().putInt("manga_vol_" + kk.hashCode(), which).apply()
                            if (which == 0) startReading(result, kk) else startReading(vols[which - 1].second.map { result[it] }, kk + "|" + vols[which - 1].first)
                        }
                        .setOnCancelListener { finish() }
                        .show()
                } else startReading(result, kk)
            }
        }.start()
    }

    /** True when [h] (the first bytes of a file) starts like a JPEG, PNG, GIF, WebP, BMP, AVIF / HEIC picture. */
    private fun looksLikeImage(h: ByteArray): Boolean {
        fun b(i: Int) = h[i].toInt() and 0xFF
        if (h.size < 12) return false
        if (b(0) == 0xFF && b(1) == 0xD8) return true // JPEG
        if (b(0) == 0x89 && b(1) == 0x50 && b(2) == 0x4E && b(3) == 0x47) return true // PNG
        if (b(0) == 0x47 && b(1) == 0x49 && b(2) == 0x46) return true // GIF
        if (b(0) == 0x42 && b(1) == 0x4D) return true // BMP
        if (b(0) == 0x52 && b(1) == 0x49 && b(2) == 0x46 && b(3) == 0x46 && b(8) == 0x57 && b(9) == 0x45) return true // WebP
        if (b(4) == 0x66 && b(5) == 0x74 && b(6) == 0x79 && b(7) == 0x70) return true // AVIF / HEIC (ftyp)
        return false
    }

    private fun startReading(list: List<Page>, k: String) {
        if (closed) return
        list.forEachIndexed { i, pg -> pg.idx = i }
        pages = list
        key = k
        current = prefs.getInt("manga_pos_$key", 0).coerceIn(0, pages.size - 1)
        showMode()
    }

    /** The books of an archive: its pictures grouped by the first folder below their common folder (in the given order). */
    private fun volumesOf(names: List<String>): List<Pair<String, List<Int>>> {
        val parts = names.map { it.replace('\\', '/').split('/').dropLast(1) }
        if (parts.isEmpty()) return emptyList()
        var common = parts[0]
        for (p in parts) {
            var n = 0
            while (n < common.size && n < p.size && common[n] == p[n]) n++
            common = common.take(n)
        }
        val map = LinkedHashMap<String, ArrayList<Int>>()
        parts.forEachIndexed { idx, p -> map.getOrPut(if (p.size > common.size) p[common.size] else "") { ArrayList() }.add(idx) }
        return map.map { Pair(it.key, it.value as List<Int>) }
    }

    // ---- decoding --------------------------------------------------------------------------------

    /**
     * Order of the pictures of an archive: by path (natural numbers), but folders that only hold covers / variants /
     * extras go after the real pages, so a book with a "Covers" folder still opens on its first page.
     */
    private val extraRx = Regex("cover|jacket|variant|extra|bonus|special|omake|\u062c\u0644\u062f")

    private fun pageOrder(a0: String, b0: String): Int {
        val a = a0.replace('\\', '/')
        val b = b0.replace('\\', '/')
        fun extra(x: String): Int {
            val dir = x.substringBeforeLast('/', "").lowercase()
            return if (dir.isNotEmpty() && extraRx.containsMatchIn(dir)) 1 else 0
        }
        val c = extra(a).compareTo(extra(b))
        return if (c != 0) c else Media.natural(a, b)
    }

    /** The archive file on disk (the cached copy, or the downloaded file), for reading a page the random-access way cannot give. */
    private var srcFile: File? = null
    private var shownDecodeErr = false

    private fun open(p: Page): InputStream? {
        if (p.entry == null) return p.uri?.let { contentResolver.openInputStream(it) }
        val z = zip
        if (z != null) {
            try {
                val e = zipEntries[p.entry] ?: z.getEntry(p.entry)
                if (e != null) return z.getInputStream(e)
            } catch (t: Throwable) {
                // fall through: read the archive from the start up to that entry
            }
        }
        return streamEntry(p.entry)
    }

    /** Slow but tolerant: scans the archive from its start with a streaming reader (odd directories, names in another encoding). */
    private fun streamEntry(name: String): InputStream? {
        val f = srcFile ?: return null
        for (cs in listOf(Charsets.UTF_8, java.nio.charset.Charset.forName("ISO-8859-1"))) {
            try {
                java.util.zip.ZipInputStream(f.inputStream().buffered(), cs).use { zi ->
                    while (true) {
                        val e = zi.nextEntry ?: break
                        val en = if (cs == Charsets.UTF_8) e.name else String(e.name.toByteArray(Charsets.ISO_8859_1), Charsets.UTF_8)
                        if (e.name == name || en == name) return java.io.ByteArrayInputStream(zi.readBytes())
                    }
                }
            } catch (t: Throwable) {
            }
        }
        return null
    }

    /** [fitW]: wanted width in pixels (scroll mode) or 0 for "long side up to about 3000 px" (page mode). */
    /** A PDF page rendered on white, at [fitW] pixels wide (or about 2x the screen width when 0). */
    private fun decodePdf(i: Int, fitW: Int): Bitmap? {
        val r = pdf ?: return null
        synchronized(pdfLock) {
            val pg = r.openPage(i)
            try {
                var w = if (fitW > 0) fitW else minOf(maxOf(screenW * 2, 1400), 2400)
                var h = (w.toFloat() * pg.height / pg.width.coerceAtLeast(1)).toInt().coerceAtLeast(1)
                while (w.toLong() * h > 9_000_000L) {
                    w = w * 4 / 5
                    h = h * 4 / 5
                }
                val bmp = Bitmap.createBitmap(w.coerceAtLeast(1), h.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
                bmp.eraseColor(Color.WHITE)
                pg.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                return bmp
            } finally {
                pg.close()
            }
        }
    }

    private fun decode(p: Page, fitW: Int): Bitmap? {
        if (p.pdf >= 0) return decodePdf(p.pdf, fitW)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        open(p)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        val w = bounds.outWidth
        val h = bounds.outHeight
        var sample = 1
        if (fitW > 0) {
            while (w / (sample * 2) >= fitW) sample *= 2
        } else {
            while (max(w, h) / sample > 3000) sample *= 2
        }
        // very long strips: keep the decoded size within about 8 megapixels
        val px = w.toDouble() * h
        val need = ceil(sqrt(px / 8_000_000.0)).toInt().coerceAtLeast(1)
        while (sample < need) sample *= 2
        val o = BitmapFactory.Options().apply { inSampleSize = sample }
        return open(p)?.use { BitmapFactory.decodeStream(it, null, o) }
    }

    // ---- modes -----------------------------------------------------------------------------------

    private fun setScrollMode(on: Boolean) {
        scrollMode = on
        prefs.edit().putBoolean("manga_scroll", on).apply()
        cache.evictAll()
        ratios.clear()
        paintButtons()
        showMode()
    }

    private fun setRtl(on: Boolean) {
        rtl = on
        prefs.edit().putBoolean("manga_rtl", on).apply()
        paintButtons()
    }

    private fun showMode() {
        if (pages.isEmpty()) return
        sliding = false
        zoom.animate().cancel()
        zoom.translationX = 0f
        if (scrollMode) {
            zoom.visibility = View.GONE
            list.visibility = View.VISIBLE
            list.adapter = adapter
            list.setSelection(current)
        } else {
            list.visibility = View.GONE
            zoom.visibility = View.VISIBLE
            showPage(current)
        }
        paintProgress()
    }

    private fun paintProgress() {
        progressTv.text = getString(R.string.manga_progress_fmt, current + 1, pages.size) + (if (infoExtra.isEmpty()) "" else "  ·  $infoExtra")
        if (::pageSeek.isInitialized && !seekDragging) paintSlider()
    }

    private fun paintSlider() {
        val n = pages.size
        val flip = !scrollMode && rtl
        pageSeek.scaleX = if (flip) -1f else 1f
        seekGuard = true
        pageSeek.max = (n - 1).coerceAtLeast(0)
        pageSeek.progress = current.coerceIn(0, pageSeek.max)
        seekGuard = false
        setSeekLabels(current)
    }

    private fun setSeekLabels(cur: Int) {
        val flip = !scrollMode && rtl
        val c = (cur + 1).toString()
        val t = pages.size.toString()
        seekLeft.text = if (flip) t else c
        seekRight.text = if (flip) c else t
        seekLeft.setTextColor(if (flip) Ui.MUTED else Ui.TEXT)
        seekRight.setTextColor(if (flip) Ui.TEXT else Ui.MUTED)
    }

    /** Jump straight to page [i] (0-based) from the slider. */
    private fun jumpTo(i: Int) {
        if (pages.isEmpty()) return
        val n = i.coerceIn(0, pages.size - 1)
        if (scrollMode) {
            list.setSelection(n)
        } else {
            sliding = false
            zoom.animate().cancel()
            zoom.translationX = 0f
            if (cache.get(n) == null) zoom.setBitmap(null)
            showPage(n)
        }
    }

    // ---- page mode -------------------------------------------------------------------------------

    private fun turn(d: Int) {
        if (sliding) return
        val n = current + d
        if (n < 0 || n >= pages.size) {
            Toast.makeText(this, getString(if (d > 0) R.string.list_last else R.string.list_first), Toast.LENGTH_SHORT).show()
            return
        }
        slideTo(n, d)
    }

    /** Horizontal slide: the old page leaves in the reading direction, the new one comes in from the other side. */
    private fun slideTo(n: Int, d: Int) {
        val w = zoom.width.toFloat().coerceAtLeast(1f)
        // exit side: next page with right-to-left reading slides the old page off to the right, and so on
        val s = if (d > 0) (if (rtl) 1f else -1f) else (if (rtl) -1f else 1f)
        zoom.animate().cancel()
        sliding = true
        zoom.animate().translationX(s * w).setDuration(120).withEndAction {
            if (closed) return@withEndAction
            if (cache.get(n) == null) zoom.setBitmap(null)
            showPage(n)
            zoom.translationX = -s * w
            zoom.animate().translationX(0f).setDuration(160).withEndAction { sliding = false }.start()
        }.start()
    }

    private fun showPage(i: Int) {
        current = i
        paintProgress()
        prefs.edit().putInt("manga_pos_$key", i).apply()
        val c = cache.get(i)
        if (c != null) {
            zoom.setBitmap(c)
        } else {
            pool.execute {
                val b = fetch(pages[i], 0)
                ui.post {
                    if (closed || b == null) return@post
                    cache.put(i, b)
                    if (current == i && !scrollMode) zoom.setBitmap(b)
                }
            }
        }
        // preload the neighbours so turning either way is instant
        for (nx in intArrayOf(i + 1, i - 1)) {
            if (nx in 0 until pages.size && cache.get(nx) == null) {
                pool.execute {
                    val b = fetch(pages[nx], 0)
                    if (b != null && !closed) cache.put(nx, b)
                }
            }
        }
    }

    // ---- scroll mode -----------------------------------------------------------------------------

    private val adapter = object : BaseAdapter() {
        override fun getCount() = pages.size
        override fun getItem(position: Int): Any = pages[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val iv = (convertView as? ImageView) ?: ImageView(this@MangaActivity).apply {
                scaleType = ImageView.ScaleType.FIT_XY
                setBackgroundColor(Color.parseColor("#101018"))
            }
            iv.tag = position
            val r = ratios[position]
            val h = if (r != null) (screenW * r).toInt() else screenW * 3 / 2
            iv.layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h)
            val hit = cache.get(position)
            if (hit != null) {
                iv.setImageBitmap(hit)
            } else {
                iv.setImageDrawable(null)
                val page = pages[position]
                pool.execute {
                    val b = fetch(page, screenW) ?: return@execute
                    cache.put(position, b)
                    val ratio = b.height.toFloat() / b.width
                    ui.post {
                        if (closed) return@post
                        val changed = ratios[position] != ratio
                        ratios[position] = ratio
                        if (iv.tag == position) {
                            iv.setImageBitmap(b)
                            iv.layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (screenW * ratio).toInt())
                            if (changed) iv.requestLayout()
                        }
                    }
                }
            }
            return iv
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }
    }

    override fun onResume() {
        super.onResume()
        Cfg.bind(this, "manga")
        if (Cfg.pauseOverlayInPlayer) OverlayService.instance?.pauseForPlayer(true)
    }

    override fun onPause() {
        OverlayService.instance?.pauseForPlayer(false)
        Cfg.bind(this, "screen")
        if (pages.isNotEmpty() && key.isNotEmpty()) {
            prefs.edit().putInt("manga_pos_$key", current).apply()
            // History: left half way = listed so it can be continued; read to the last page = removed
            if (current >= pages.size - 1) History.remove(this, 1, key)
            else History.put(this, History.Entry(1, key, titleTv.text.toString(), current.toLong(), pages.size.toLong(), System.currentTimeMillis(), histSrc, histRef))
        }
        super.onPause()
    }

    override fun onDestroy() {
        Ui.init(this)
        closed = true
        pool.shutdownNow()
        ui.removeCallbacks(fxApply)
        fx.release()
        ui.removeCallbacksAndMessages(null)
        runCatching { zip?.close() }
        runCatching { pdf?.close() }
        // unpacked RAR pages are only needed while reading; they are made again on the next opening
        val appCtx = applicationContext
        Thread { runCatching { File(appCtx.cacheDir, "manga_rar").deleteRecursively() } }.start()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_BUCKET = "app.clearoverlay.BUCKET"
        const val EXTRA_NAME = "app.clearoverlay.NAME"
        const val EXTRA_TREE = "app.clearoverlay.TREE"
        private const val REQ_MODEL = 24
    }
}
